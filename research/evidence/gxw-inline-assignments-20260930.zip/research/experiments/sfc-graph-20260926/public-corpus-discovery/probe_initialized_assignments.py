"""Read-only stored assignment oracle with native-owned address converter context."""
from pathlib import Path
import base64,json,os,subprocess,sys

P=Path(__file__).resolve().parent
ROOT=P.parents[3]

def main():
    out=P/(sys.argv[1] if len(sys.argv)>1 else 'inline-assignment-owned-native-20260930')
    out.mkdir(exist_ok=False)
    source=out/'InitializedAssignmentOracle.cs';source.write_bytes((P/source.name).read_bytes())
    exe=out/'InitializedAssignmentOracle.exe'
    build=subprocess.run([str(Path(os.environ['WINDIR'])/'Microsoft.NET/Framework/v4.0.30319/csc.exe'),'/nologo','/platform:x86','/r:System.Web.Extensions.dll','/out:'+str(exe),str(source)],capture_output=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
    (out/'build.txt').write_bytes(build.stdout+build.stderr);assert build.returncode==0
    rows=json.loads((P/'opaque-real-assignments-20260930.json').read_text(encoding='utf-8'))
    captures=P/'assignment-address-context-capture-20260930'
    for cpu,code in (('FX3G',521),('Q03UDV',209)):
        saved=captures/cpu/'context-plan.json'
        group=out/cpu;group.mkdir();work=group/'isolated-work';work.mkdir()
        assert work.resolve().is_relative_to(out.resolve())
        records=[r for r in rows if r['cpu']==cpu and bytes.fromhex(r['raw'])[0]==7]
        (group/'input-provenance.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        plan=group/'context-plan.json'
        plan.write_bytes(saved.read_bytes())
        inputs=group/'inputs.txt';inputs.write_text(''.join(base64.b64encode(bytes.fromhex(r['raw'])).decode()+'\n' for r in records),encoding='ascii')
        command=[str(exe),'D:/GXWORKS2/Easysocket/Compiler/ECCompiler.dll',str(code),str(work),str(inputs),str(group/'outputs.jsonl'),str(plan)]
        try:
            run=subprocess.run(command,capture_output=True,timeout=40,creationflags=subprocess.CREATE_NO_WINDOW)
            result=dict(returncode=run.returncode,stdout=run.stdout.decode('utf-8',errors='replace'),stderr=run.stderr.decode('utf-8',errors='replace'))
            (group/'stdout.bin').write_bytes(run.stdout);(group/'stderr.bin').write_bytes(run.stderr)
        except subprocess.TimeoutExpired as exc:
            (group/'stdout.bin').write_bytes(exc.stdout or b'');(group/'stderr.bin').write_bytes(exc.stderr or b'')
            result=dict(returncode='timeout')
        (group/'process.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(cpu=cpu,**result)),flush=True)
        if result['returncode']!=0:continue
        answers=[json.loads(s) for s in (group/'outputs.jsonl').read_text(encoding='utf-8-sig').splitlines()]
        assert len(answers)==len(records)
        combined=[]
        for record,answer in zip(records,answers,strict=True):
            assert base64.b64decode(answer['input_base64']).hex()==record['raw']
            combined.append(dict(record,formatted=base64.b64decode(answer['output_base64']).decode('ascii'),native_operand=base64.b64decode(answer['operand_base64']).decode('ascii'),after_hex=base64.b64decode(answer['after_base64']).hex()))
        (group/'formatted-bindings.json').write_text(json.dumps(combined,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        print(json.dumps(dict(records=len(combined),formats=sorted(set(r['formatted'] for r in combined)))),flush=True)

if __name__=='__main__':main()
