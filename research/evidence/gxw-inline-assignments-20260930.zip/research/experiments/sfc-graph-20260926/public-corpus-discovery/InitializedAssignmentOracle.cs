// Native-owned compiler/CPU context; format copies of stored UserInfo only.
// No source build, project, simulator or device-operation API is invoked.
using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Collections.Generic;
using System.Web.Script.Serialization;

public static class InitializedAssignmentOracle {
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode)] static extern IntPtr LoadLibraryEx(string path,IntPtr file,uint flags);
    [DllImport("kernel32.dll",CharSet=CharSet.Ansi)] static extern IntPtr GetProcAddress(IntPtr module,string name);
    [DllImport("kernel32.dll")] static extern uint SetErrorMode(uint flags);
    [DllImport("ole32.dll")] static extern int CoInitializeEx(IntPtr reserved,uint mode);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate IntPtr NewFn(IntPtr path);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate void DeleteFn(IntPtr self);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int InitFn(IntPtr self,IntPtr path,int cpu,int flags);
    [StructLayout(LayoutKind.Sequential)] struct Params96 {
        [MarshalAs(UnmanagedType.ByValArray,SizeConst=24)] public uint[] words;
    }
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int AddressFn(IntPtr self,Params96 parameters);
    [UnmanagedFunctionPointer(CallingConvention.ThisCall)] delegate IntPtr Construct(IntPtr self);
    [UnmanagedFunctionPointer(CallingConvention.ThisCall)] delegate void Destroy(IntPtr self);
    [UnmanagedFunctionPointer(CallingConvention.ThisCall)] delegate void Format(IntPtr self,IntPtr table,IntPtr user,IntPtr text);
    [UnmanagedFunctionPointer(CallingConvention.ThisCall)] delegate void OperandFormat(IntPtr self,IntPtr operand,IntPtr text,int mode,int options);
    static byte[] TextBytes(IntPtr text) {
        IntPtr chars=Marshal.ReadIntPtr(text,4);int length=0;
        while(length<4096&&Marshal.ReadByte(chars,length)!=0)length++;
        if(length>=4096)throw new Exception("Native output outside bound");
        byte[] data=new byte[length];Marshal.Copy(chars,data,0,length);return data;
    }
    static T At<T>(IntPtr pointer) where T:class {return Marshal.GetDelegateForFunctionPointer(pointer,typeof(T)) as T;}
    static T Export<T>(IntPtr module,string name) where T:class {
        IntPtr p=GetProcAddress(module,name);if(p==IntPtr.Zero)throw new Exception("Missing export: "+name);return At<T>(p);
    }
    static void Guard(IntPtr module,int offset,byte[] bytes) {
        for(int i=0;i<bytes.Length;i++)if(Marshal.ReadByte(module,offset+i)!=bytes[i])throw new Exception("Uninspected formatter code");
    }
    [STAThread] public static int Main(string[] args) {
        if(IntPtr.Size!=4||args.Length!=6)return 2;
        SetErrorMode(3);if(CoInitializeEx(IntPtr.Zero,2)<0)throw new Exception("COM initialization failed");
        if(FileVersionInfo.GetVersionInfo(args[0]).FileVersion!="15.22")throw new Exception("Uninspected native version");
        IntPtr module=LoadLibraryEx(args[0],IntPtr.Zero,8);if(module==IntPtr.Zero)throw new Exception("Native load failed");
        Guard(module,0x51650,new byte[]{0x64,0xa1,0,0,0,0,0x6a,0xff});
        Guard(module,0x5167e,new byte[]{0x8a,0x06,0x3c,0x07,0x0f,0x85});
        IntPtr library=Marshal.StringToHGlobalAnsi(Path.GetDirectoryName(args[0])+"\\");
        IntPtr work=Marshal.StringToHGlobalAnsi(args[2]);
        IntPtr self=Export<NewFn>(module,"ObjectNew")(library);
        if(self==IntPtr.Zero)throw new Exception("ObjectNew failed");
        IntPtr user=Marshal.AllocHGlobal(26),text=Marshal.AllocHGlobal(12);
        Construct textCtor=At<Construct>(IntPtr.Add(module,0x6b90));
        Destroy textDestroy=At<Destroy>(Marshal.ReadIntPtr(module,0x11024c));
        Format format=At<Format>(IntPtr.Add(module,0x51650));
        OperandFormat operandFormat=At<OperandFormat>(IntPtr.Add(module,0x51130));
        List<IntPtr> buffers=new List<IntPtr>();
        try {
            int code=Export<InitFn>(module,"ChangeInit")(self,work,int.Parse(args[1]),1024);
            Console.WriteLine("ChangeInit="+code);if(code!=0)throw new Exception("ChangeInit failed");
            Dictionary<string,object> plan=new JavaScriptSerializer().Deserialize<Dictionary<string,object>>(File.ReadAllText(args[5]));
            Dictionary<string,object> parameters=(Dictionary<string,object>)plan["parameters"];
            byte[] parameterRaw=Convert.FromBase64String((string)parameters["raw"]);
            if(parameterRaw.Length!=96)throw new Exception("Unexpected parameter size");
            IntPtr parameter=Marshal.AllocHGlobal(96);buffers.Add(parameter);Marshal.Copy(parameterRaw,0,parameter,96);
            foreach(Dictionary<string,object> relocation in (System.Collections.IEnumerable)parameters["relocations"]) {
                int offset=Convert.ToInt32(relocation["offset"]);
                if(offset<0||offset>92||offset%4!=0)throw new Exception("Invalid parameter relocation");
                byte[] data=Convert.FromBase64String((string)relocation["data"]);
                IntPtr buffer=Marshal.AllocHGlobal(data.Length);buffers.Add(buffer);Marshal.Copy(data,0,buffer,data.Length);Marshal.WriteIntPtr(parameter,offset,buffer);
            }
            uint[] words=new uint[24];for(int i=0;i<24;i++)words[i]=unchecked((uint)Marshal.ReadInt32(parameter,i*4));
            code=Export<AddressFn>(module,"InitializeAddressConverter")(self,new Params96{words=words});
            Console.WriteLine("InitializeAddressConverter="+code);if(code!=0)throw new Exception("Address initialization failed");
            IntPtr wrapper=Marshal.ReadIntPtr(self,0x164);
            if(wrapper==IntPtr.Zero||Marshal.ReadIntPtr(wrapper)!=IntPtr.Add(module,0x1142fc))throw new Exception("Unexpected address wrapper class");
            IntPtr backend=IntPtr.Add(wrapper,0x4c);
            if(backend==IntPtr.Zero||Marshal.ReadIntPtr(backend)!=IntPtr.Add(module,0x114014))throw new Exception("Unexpected native backend class");
            IntPtr cpu=Marshal.ReadIntPtr(backend,0x3a2);
            if(cpu==IntPtr.Zero)throw new Exception("CPU description missing after native initialization");
            Console.WriteLine("CPUInfo.code="+unchecked((ushort)Marshal.ReadInt16(cpu,0x782)));
            if(unchecked((ushort)Marshal.ReadInt16(cpu,0x782))!=int.Parse(args[1]))throw new Exception("CPU code mismatch");
            using(StreamWriter output=new StreamWriter(args[4])) {
                foreach(string line in File.ReadAllLines(args[3])) {
                    byte[] raw=Convert.FromBase64String(line);
                    if(raw.Length!=26||raw[0]!=7)throw new Exception("Outside inspected inline form");
                    for(int i=1;i<26;i++)if((i<9||(i>=13&&i<21)||i>=22)&&raw[i]!=0)throw new Exception("Inline modifier outside profile");
                    if("KMDW".IndexOf(Char.ToUpperInvariant((char)raw[21]))<0)throw new Exception("Inline family outside profile");
                    Marshal.Copy(raw,0,user,26);textCtor(text);
                    try {
                        format(backend,IntPtr.Zero,user,text);
                        byte[] result=TextBytes(text),after=new byte[26];Marshal.Copy(user,after,0,26);
                        operandFormat(backend,IntPtr.Add(user,1),text,1,0xf1);
                        byte[] operand=TextBytes(text);
                        output.WriteLine("{\"input_base64\":\""+line+"\",\"output_base64\":\""+Convert.ToBase64String(result)+"\",\"operand_base64\":\""+Convert.ToBase64String(operand)+"\",\"after_base64\":\""+Convert.ToBase64String(after)+"\"}");output.Flush();
                    } finally {textDestroy(IntPtr.Add(text,4));}
                }
            }
        } finally {
            Export<DeleteFn>(module,"ObjectDelete")(self);
            foreach(IntPtr buffer in buffers)Marshal.FreeHGlobal(buffer);
            Marshal.FreeHGlobal(library);Marshal.FreeHGlobal(work);Marshal.FreeHGlobal(user);Marshal.FreeHGlobal(text);
        }
        return 0;
    }
}
