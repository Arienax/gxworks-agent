"""Capture actual address parameters from checked copies of offline projects."""
from pathlib import Path
import base64,json,struct,sys
ROOT=Path(__file__).resolve().parents[4];P=Path(__file__).resolve().parent
sys.path[:0]=[str(P),str(ROOT/'research'),str(ROOT/'src')]
from probe_minimal_conditional_port_writes import observe,save
from probe_gxw_program_check_resources import SCRIPT

CAPTURE=r'''
Process.attachModuleObserver({onAdded(m){
  if(m.name.toLowerCase()!=='eccompiler_iec.dll')return;
  const f=m.findExportByName('InitializeAddressConverter');if(f===null)return;
  Interceptor.attach(f,{onEnter(a){
    try {
      const size=a[1].toInt32();if(size<0||size>0x100000)throw Error('Parameter size outside bound');
      const values=[];for(let i=1;i<=24;i++)values.push(a[i].toUInt32());
      const data=size?Array.from(new Uint8Array(a[2].readByteArray(size))).map(x=>x.toString(16).padStart(2,'0')).join(''):'';
      send({event:'assignment-address-parameters',module:m.path,words:values,data_hex:data});
    }catch(e){send({event:'assignment-address-capture-error',error:String(e)});}
  }});
}});
'''

def main():
    out=P/'assignment-address-context-capture-20260930';out.mkdir(exist_ok=False)
    groups=[('FX3G',521,P/'fx3g-library-source-roundtrip-v6/original-library/candidate.gxw'),('Q03UDV',209,P/'minimal-conditional-port-writes-20260930/int-device/input.gxw')]
    for cpu,code,original in groups:
        directory=out/cpu;directory.mkdir();candidate=directory/'input.gxw';candidate.write_bytes(original.read_bytes())
        trace=directory/'trace.js';trace.write_text('(()=>{'+SCRIPT+'\n})();\n(()=>{'+CAPTURE+'\n})();',encoding='utf-8')
        save(directory/'provenance.json',dict(context_project=str(original),cpu_code=code,scope='Compile/check/save copied offline engineering project only'))
        native,result,process=observe(candidate,directory,trace)
        captures=[];errors=[]
        for line in (native/'events.jsonl').read_text(encoding='utf-8').splitlines():
            event=json.loads(line).get('payload',{})
            if event.get('event')=='assignment-address-parameters':captures.append(event)
            if event.get('event')=='assignment-address-capture-error':errors.append(event)
        save(directory/'capture-result.json',dict(process=process,check=result['check'],captures=captures,errors=errors))
        print(json.dumps(dict(cpu=cpu,captures=len(captures),errors=errors,check=result['check'])),flush=True)
        if captures and not errors:
            selected=captures[-1];raw=bytearray(struct.pack('<24I',*selected['words']));raw[4:8]=b'\0'*4
            save(directory/'context-plan.json',dict(actual_cpu=code,parameter_origin=str(native/'events.jsonl'),scope='Actual copied-project address converter parameters',parameters=dict(raw=base64.b64encode(raw).decode(),relocations=[dict(offset=4,data=base64.b64encode(bytes.fromhex(selected['data_hex'])).decode())])))

if __name__=='__main__':main()
