"""Measure remaining lexical and stored-compiler gaps, without native runs.

Use current original-project inventory. Raw gap tokens and unknown assignment
forms remain preserved; compiler state is not current-source freshness proof.
"""
from collections import Counter
from pathlib import Path
import json
import sys

ROOT=Path(__file__).resolve().parents[4];P=Path(__file__).resolve().parent
sys.path[:0]=[str(P),str(ROOT/'src'),str(ROOT/'research')]
from probe_minimal_conditional_port_writes import streams
from gxw.compiler_tables import parse_compiler_tables
from gxw.compiler_symbols import compiler_symbols
from gxw.lossless import inspect_program
from gxw.project_metadata import read_project_text_context
from gxw.token_listing import TokenListing


def main():
    inventory=json.loads((P/'current-real-source-gaps-20260930.json').read_text(encoding='utf-8'))
    files=sorted(set(r['file'] for r in inventory['programs']))
    projects=[];gapcounts=Counter();cachetypes=Counter();assignments=Counter();unknownforms=Counter();errors=[]
    for name in files:
        content=streams((ROOT/name).read_bytes())
        context=read_project_text_context(next(v for n,v in content.items() if n.endswith('.prj')))
        cpu=context['cpu'];profile={'Q03UDV':'q03udv','Q02/Q02H':'q02','FX3U/FX3UC':'fx3u','FX1S':'fx1s','FX3G':'fx3g'}.get(cpu)
        row=dict(file=name,cpu=cpu,programs=[])
        for n,raw in content.items():
            if not n.endswith('.pou'):continue
            image=inspect_program(raw,logical_name=n,token_profile=profile,text_encoding=context['text_encoding'])
            ir=image.projection
            if isinstance(ir,TokenListing):
                gaps=[dict(reason=g.reason,offset=g.tokens[0].offset,raw=b''.join(t.raw for t in g.tokens).hex()) for g in ir.gaps]
                gapcounts.update(g['reason'] for g in gaps)
                row['programs'].append(dict(name=n,instructions=len(ir.instructions),gaps=gaps))
        if content.get('CGTable.dat'):
            try:
                raw=content['CGTable.dat'];t=parse_compiler_tables(raw);symbols=compiler_symbols(t)
                for s in symbols:
                    typ=t.component_type(s.component);a=s.assignment
                    cachetypes[(cpu,typ)]+=1;assignments[(cpu,a.status)]+=1
                    if a.status=='opaque':unknownforms[(cpu,a.raw[:2].hex(),typ)]+=1
                row['compiler_cache']=dict(bytes=len(raw),components=len(symbols),
                    types=dict(Counter(str(t.component_type(s.component)) for s in symbols)),
                    assignment_handling=dict(Counter(s.assignment.status for s in symbols)))
            except Exception as e:errors.append(dict(file=name,error=str(e)))
        projects.append(row)
    result=dict(scope='Current lexical and stored compiler assignment gaps in original projects. Cache does not certify current source freshness.',
        projects=projects,gap_reason_counts=dict(gapcounts),
        compiler_type_counts=[dict(cpu=k[0],type=k[1],count=v) for k,v in cachetypes.most_common()],
        assignment_handling=[dict(cpu=k[0],handling=k[1],count=v) for k,v in assignments.most_common()],
        opaque_assignment_forms=[dict(cpu=k[0],prefix=k[1],type=k[2],count=v) for k,v in unknownforms.most_common()],errors=errors)
    target=P/(sys.argv[1] if len(sys.argv)>1 else 'current-real-semantic-gaps-20260930.json')
    target.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='projects'}),flush=True)
    print(json.dumps(dict(projects=len(projects),projects_with_cache=sum('compiler_cache' in r for r in projects))),flush=True)


if __name__=='__main__':main()
