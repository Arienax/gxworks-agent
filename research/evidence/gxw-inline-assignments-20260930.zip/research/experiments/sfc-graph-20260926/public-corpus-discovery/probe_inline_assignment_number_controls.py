"""Prospective controls for operand numbering; no compilation or device calls."""
from pathlib import Path
import base64,json,subprocess,sys
P=Path(__file__).resolve().parent

def main():
    out=P/(sys.argv[1] if len(sys.argv)>1 else 'inline-assignment-number-controls-v2-20260930');out.mkdir(exist_ok=False)
    exe=P/'inline-assignment-owned-native-v3-20260930/InitializedAssignmentOracle.exe'
    for cpu,code,families in [('FX3G',521,'KMD'),('Q03UDV',209,'KMDW')]:
        g=out/cpu;g.mkdir();w=g/'isolated-work';w.mkdir();assert w.resolve().is_relative_to(out.resolve())
        inputs=[];predictions=[]
        for family in families:
            numbers=tuple(map(int,sys.argv[2].split(','))) if len(sys.argv)>2 else (0,1,15,16,7999,8000,8001,8028,8029,8180,8191,8192,65535,65536,2147483647,2147483648,4294967295)
            for number in numbers:
                raw=bytearray(26);raw[0]=7;raw[9:13]=number.to_bytes(4,'little');raw[21]=ord(family)
                inputs.append(base64.b64encode(raw).decode())
                prefix='X0' if family=='M' else 'W1' if family=='W' else 'W0'
                digits=f'{number:X}' if family=='W' else str(number-(1<<32) if family=='K' and number>0x7fffffff else number)
                unsupported=family=='K' or (cpu=='FX3G' and family=='M' and 7680<=number<8000)
                predictions.append(dict(family=family,number=number,operand=family+digits,iec=None if unsupported else f'%M{prefix}.{number}'))
        (g/'prospective.json').write_text(json.dumps(predictions,indent=2)+'\n',encoding='utf-8')
        inp=g/'inputs.txt';inp.write_text('\n'.join(inputs)+'\n',encoding='ascii')
        plan=P/'assignment-address-context-capture-20260930'/cpu/'context-plan.json'
        r=subprocess.run([str(exe),'D:/GXWORKS2/Easysocket/Compiler/ECCompiler.dll',str(code),str(w),str(inp),str(g/'outputs.jsonl'),str(plan)],capture_output=True,timeout=40,creationflags=subprocess.CREATE_NO_WINDOW)
        (g/'stdout.bin').write_bytes(r.stdout);(g/'stderr.bin').write_bytes(r.stderr)
        (g/'process.json').write_text(json.dumps(dict(returncode=r.returncode),indent=2)+'\n',encoding='utf-8')
        print(cpu,r.returncode,r.stdout.decode('ascii',errors='replace'),flush=True)
        if r.returncode:continue
        answers=[json.loads(s) for s in (g/'outputs.jsonl').read_text(encoding='utf-8-sig').splitlines()];comp=[]
        for pred,a in zip(predictions,answers,strict=True):
            actual=base64.b64decode(a['output_base64']).decode('ascii');operand=base64.b64decode(a['operand_base64']).decode('ascii')
            comp.append(dict(pred,actual=actual,native_operand=operand,match=(pred['iec'] or '')==actual and pred['operand']==operand))
        (g/'comparison.json').write_text(json.dumps(comp,indent=2)+'\n',encoding='utf-8')
        print('different',[a for a in comp if not a['match']],flush=True)
        print('matches',sum(a['match'] for a in comp),len(comp),flush=True)

if __name__=='__main__':main()
