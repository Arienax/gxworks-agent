"""Offline native CGTable restore/dump/replay; no project or device APIs."""
from __future__ import annotations

import argparse
import base64
import json
import os
from pathlib import Path
import re
import subprocess
import struct
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from gxw.lossless import sha256
from gxw.compiler_tables import parse_compiler_tables

DLL = Path("D:/GXWORKS2/Easysocket/Compiler/ECCompiler.dll")
DLL_SHA256 = "4f7b2398874c7a921f49f13f25a9a603562032b039de8a5bb74114df27fadf16"


def compare_component_reads(raw, rows):
    """Compare initialized scalar fields and the separate raw UserInfo block.

    The native union includes pointers and unused stack bytes for some types.
    Those bytes remain recorded but must not become a portable equality claim.
    """
    tables = parse_compiler_tables(raw)
    offsets = [r.table_offset for r in tables.tables[2].records]
    complete = ([r["requested_offset"] for r in rows] == offsets
                and all(r["return_code"] == 1 for r in rows))
    mismatches = []
    for row in rows:
        component = tables.component_at(row["requested_offset"])
        record = base64.b64decode(row["record_base64"], validate=True)
        user = base64.b64decode(row["user_info_base64"], validate=True)
        if len(record) != 0x129:
            mismatches.append({"offset": row["requested_offset"], "field": "native struct size"})
            continue
        checks = {"name": record[:261].split(b"\0", 1)[0] == component.name_bytes,
                  "scope": struct.unpack_from("<I", record, 0x105)[0] == component.scope_code,
                  "type": struct.unpack_from("<I", record, 0x10D)[0] == tables.component_type(component),
                  "user_info": user == component.user_info,
                  "next_offset": row["next_offset"] == component.record.table_offset + len(component.record.raw)}
        mismatches.extend({"offset": row["requested_offset"], "field": key} for key, equal in checks.items() if not equal)
    return {"component_reads_complete": complete, "component_count": len(rows),
            "component_field_mismatches": mismatches}


def compare_table_dump(raw, dump):
    """Compare ordered native POU/component names, byte indexes and FB targets.

    Ignore the native textual rendering of binary UserInfo; retain its original
    bytes in the input and replay. This comparison does not cover every field.
    """
    tables = parse_compiler_tables(raw)
    pous = [tables.pou_at(r.table_offset) for r in tables.tables[1].records]
    components = [c for p in pous for c in tables.components(p)]
    native_pous = [(int(m[1]), m[2]) for m in re.finditer(rb"^Index\s+(\d+): ([^\r\n]+) \(POU_[^)]+\)", dump, re.M)]
    native_components = [(int(m[1]), m[2]) for m in re.finditer(rb"^ +Index\s+(\d+): ([^\r\n]+) \(TYPE_[^)]+\)", dump, re.M)]
    native_references = [int(m[1]) for m in re.finditer(rb"^ +PouIdx = (-?\d+)", dump, re.M)]
    references = [c.instance_pou_offset for c in components if c.instance_pou_offset is not None]
    for reference in references:
        tables.pou_at(reference)
    return {"pous_equal": native_pous == [(p.record.table_offset, p.name_bytes) for p in pous],
            "components_equal": native_components == [(c.record.table_offset, c.name_bytes) for c in components],
            "instance_refs_equal": native_references == references,
            "pous": len(pous), "components": len(components), "instances": len(references)}


def native_table_dump(raw, directory, *, dll=DLL, read_components=False):
    if os.name != "nt" or sha256(dll.read_bytes()) != DLL_SHA256:
        raise ValueError("requires Windows and the inspected ECCompiler.dll 15.22 hash")
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=False)
    source = directory / "CompilerTableOracle.cs"
    source.write_bytes((ROOT / "research/native/CompilerTableOracle.cs").read_bytes())
    input_path = directory / "CGTable.dat"
    input_path.write_bytes(raw)
    request = {"input_sha256": sha256(raw), "dll_sha256": DLL_SHA256,
               "adapter_source_sha256": sha256(source.read_bytes()),
               "scope": "offline table restore/dump/replay; no source freshness, execution or project acceptance claim"}
    if read_components:
        request["component_offsets"] = [r.table_offset for r in parse_compiler_tables(raw).tables[2].records]
        (directory / "component-offsets.txt").write_text("".join(str(p) + "\n" for p in request["component_offsets"]), encoding="ascii")
    (directory / "request.json").write_text(json.dumps(request, indent=2) + "\n", encoding="utf-8")
    executable = directory / "CompilerTableOracle.exe"
    compiler = Path(os.environ["WINDIR"]) / "Microsoft.NET/Framework/v4.0.30319/csc.exe"
    build = subprocess.run([str(compiler), "/nologo", "/platform:x86", "/out:" + str(executable), str(source)],
                           capture_output=True, timeout=30, creationflags=subprocess.CREATE_NO_WINDOW)
    (directory / "build-output.bin").write_bytes(build.stdout + build.stderr)
    if build.returncode:
        raise RuntimeError("native compiler-table adapter build failed; evidence retained")
    try:
        command = [str(executable.resolve()), str(dll.resolve()), str(input_path.resolve()), str(directory.resolve())]
        if read_components:
            command.append(str((directory / "component-offsets.txt").resolve()))
        run = subprocess.run(command,
                             capture_output=True, timeout=40, creationflags=subprocess.CREATE_NO_WINDOW)
        stdout, stderr, code = run.stdout, run.stderr, run.returncode
    except subprocess.TimeoutExpired as exc:
        stdout, stderr, code = exc.stdout or b"", exc.stderr or b"", "timeout"
    (directory / "stdout.txt").write_bytes(stdout)
    (directory / "stderr.txt").write_bytes(stderr)
    result = dict(request, returncode=code, adapter_sha256=sha256(executable.read_bytes()))
    replay = directory / "native-replay.bin"
    result["replay_equal"] = replay.exists() and replay.read_bytes() == raw
    (directory / "process.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    if code:
        raise RuntimeError("native compiler-table process failed; inputs and partial output retained")
    result.update(compare_table_dump(raw, (directory / "native-table-dump.txt").read_bytes()))
    if read_components:
        rows = [json.loads(line) for line in (directory / "native-components.jsonl").read_text().splitlines()]
        result.update(compare_component_reads(raw, rows))
    (directory / "comparison.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path, help="extracted CGTable.dat")
    parser.add_argument("-o", "--output", type=Path, required=True)
    parser.add_argument("--dll", type=Path, default=DLL)
    parser.add_argument("--components", action="store_true", help="also read native CMP_LINE and UserInfo for each component")
    args = parser.parse_args()
    print(json.dumps(native_table_dump(args.input.read_bytes(), args.output, dll=args.dll, read_components=args.components)))
