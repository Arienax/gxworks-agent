"""Prospective label-reference contact edits in copied original Q projects.

Existing labels are resolved solely from source declarations and project
configuration. Source, compiled PCode and raw machine changes are predicted
before native operations. Declaration documents, cached resources and every
unrelated input stream remain byte-identical. Full project acceptance is a
separate native experiment; the memory helper does not execute PLC programs.
"""
from pathlib import Path
from collections import Counter
import base64
import json
import os
import struct
import subprocess
import sys

P = Path(__file__).resolve().parent
ROOT = P.parents[3]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'research')]
from gxw.container import CompoundFile
from gxw.container_writer import replace_stream_within_allocation
from gxw.project_resolver import GXWProjectResolver
from gxw.project_metadata import read_project_text_context
from gxw.token_listing import decode_token_listing
from gxw.token_pou import frame_token_pou
from probe_gxw_parameters import device_allocation_record
from source_q_direct_projection import project_projection
from source_q_allocation import groups
from source_q_read_context import build_read_context
from source_q_machine_reader import load_read_tables
from source_q_contact_patch import patch_bit_contact

OUTPUT = P/'q-label-contact-candidates-20261001-v1'
BIT_DEVICES = (0x90,0x92,0x93,0x94,0x98,0x9C,0x9D,0xA0,0xA1)


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=True, indent=2)+'\n', encoding='utf-8')


def scalar(token):
    if len(token) < 4 or token[0] != len(token) or token[-1] != len(token) or token[1] not in BIT_DEVICES:
        return None
    return token[1], int.from_bytes(token[2:-1], 'little')


def propose(case, bound):
    native = P/'noeul-native-batch'/case
    raw = (native/'input.gxw').read_bytes()
    resolver = GXWProjectResolver(CompoundFile(raw))
    parameter = device_allocation_record(resolver.read_logical_file('Param.wpa')).raw
    profile = load_read_tables(P/'q-machine-static-read-tables-20261001-v3.json', build_read_context(parameter).devices)
    capacities = {struct.unpack_from('<H',parameter,at)[0]&255:struct.unpack_from('<H',parameter,at+2)[0]&~15
        for at in range(6,len(parameter),4) if struct.unpack_from('<H',parameter,at)[0]>>8 == 1}
    metadata = next(resolver.hdb.read_stream(f.stream_name) for f in resolver.logical_files() if f.logical_name.endswith('.prj'))
    encoding = read_project_text_context(metadata)['text_encoding']
    original = project_projection(raw)
    if not all(r['output'] == (native/f'pcode-{r["resource_index"]}-0.bin').read_bytes() for r in original):
        raise ValueError('Complete source projection differs from retained original compiler bytes')
    refusals = []
    for file in resolver.logical_files():
        if not file.logical_name.endswith('.Program.pou'):
            continue
        owner = file.logical_name[:-len('.Program.pou')]
        owned = [r for r in original if r['program'] == owner]
        if len(owned) != 1:
            continue
        resource = owned[0]
        # Alternative names must already resolve in this source owner; do not
        # invent declaration types, namespaces or addresses for unused labels.
        aliases = {}
        for item in resource['bindings']:
            operand = scalar(bytes.fromhex(item['operand']))
            if operand is not None:
                key = bytes.fromhex(item['label_hex'])
                aliases.setdefault(key,set()).add(operand)
        aliases = {key:next(iter(values)) for key,values in aliases.items() if len(values) == 1}
        source = resolver.hdb.read_stream(file.stream_name)
        listing = decode_token_listing(source, profile='q03udv', text_encoding=encoding)
        if listing.gaps:
            refusals.append(dict(logical=file.logical_name,reason='Source lexical gaps'))
            continue
        for source_index, instruction in enumerate(listing.instructions):
            if instruction.mnemonic not in ('LD','LDI','AND','ANI','OR','ORI') or len(instruction.operands) != 1 or len(instruction.operands[0].tokens) != 1:
                continue
            token = instruction.operands[0].tokens[0]
            if token.raw[1] != 0xDF or token.raw[2:-1] not in aliases:
                continue
            old_label = token.raw[2:-1]
            old_device, old_number = aliases[old_label]
            choices = [(sum(a != b for a,b in zip(old_label,label)),label,number)
                       for label,(code,number) in aliases.items() if len(label) == len(old_label) and code == old_device and
                       number != old_number and 0 <= number < capacities.get(code,0)]
            for _,new_label,new_number in sorted(choices):
                replacement = token.raw[:2]+new_label+token.raw[-1:]
                changed_source = source[:token.offset]+replacement+source[token.offset+len(token.raw):]
                inner = replace_stream_within_allocation(resolver.outer.read_stream('_hdb'),file.stream_name,changed_source)
                candidate = replace_stream_within_allocation(raw,'_hdb',inner)
                expected = project_projection(candidate)
                changed_records = []
                for before,after in zip(original,expected,strict=True):
                    a,b = [b''.join(g) for g in groups(before['output'])],[b''.join(g) for g in groups(after['output'])]
                    if len(a) != len(b):
                        raise ValueError('Reference edit changed compiled record count')
                    changed_records.extend((before,after,i) for i,(x,y) in enumerate(zip(a,b,strict=True)) if x != y)
                if len(changed_records) != 1:
                    refusals.append(dict(logical=file.logical_name,source_index=source_index,reason='Reference affects zero/multiple resource records'))
                    continue
                before,after,record_index = changed_records[0]
                words = {r['machine_hex'] for r in bound['bodies'] if r['parameter_hex'] == parameter.hex() and r['original_pcode_hex'] == before['output'].hex()}
                if len(words) != 1:
                    refusals.append(dict(logical=file.logical_name,source_index=source_index,reason='Original machine witness absent/ambiguous'))
                    continue
                original_machine = bytes.fromhex(words.pop())
                try:
                    expected_machine,mutation = patch_bit_contact(original_machine,profile,record_index=record_index,device_code=old_device,
                        before_number=old_number,after_number=new_number,allocated_count=capacities[old_device],expected_pcode=after['output'])
                except ValueError as exc:
                    refusals.append(dict(logical=file.logical_name,source_index=source_index,reason=str(exc)))
                    continue
                rebuilt = GXWProjectResolver(CompoundFile(candidate))
                for entry in resolver.hdb.iter_streams():
                    if entry.name != file.stream_name and resolver.hdb.read_stream(entry.name) != rebuilt.hdb.read_stream(entry.name):
                        raise ValueError('Unrelated inner payload changed')
                for entry in resolver.outer.iter_streams():
                    if entry.name != '_hdb' and resolver.outer.read_stream(entry.name) != rebuilt.outer.read_stream(entry.name):
                        raise ValueError('Unrelated outer payload changed')
                physical = [i for i,(a,b) in enumerate(zip(raw,candidate,strict=True)) if a != b]
                if len(physical) != sum(a != b for a,b in zip(token.raw,replacement,strict=True)):
                    raise ValueError('Physical changes exceed the selected reference name bytes')
                directory = OUTPUT/case
                directory.mkdir()
                (directory/'original.gxw').write_bytes(raw)
                (directory/'candidate.gxw').write_bytes(candidate)
                (directory/'expected-source-body.bin').write_bytes(frame_token_pou(changed_source).body)
                (directory/'project-parameters.bin').write_bytes(parameter)
                resources = []
                for a,b in zip(original,expected,strict=True):
                    index = a['resource_index']
                    (directory/f'original-pcode-{index}.bin').write_bytes(a['output'])
                    (directory/f'expected-pcode-{index}.bin').write_bytes(b['output'])
                    resources.append(dict(index=index,name=a['resource'],program=a['program'],bytes=len(b['output']),
                        changed_records=[record_index] if a['resource_index'] == before['resource_index'] else []))
                index = before['resource_index']
                (directory/f'original-machine-{index}.bin').write_bytes(original_machine)
                (directory/f'expected-machine-{index}.bin').write_bytes(expected_machine)
                row = dict(case=case,logical=file.logical_name,stream=file.stream_name,instruction=instruction.mnemonic,
                    source_instruction=source_index,source_token_offset=token.offset,original_token_hex=token.raw.hex(),replacement_token_hex=replacement.hex(),
                    before_label=old_label.decode(encoding),after_label=new_label.decode(encoding),device_code=old_device,
                    before_number=old_number,after_number=new_number,capacity=capacities[old_device],
                    parameter_hex=parameter.hex(),physical_changed_offsets=physical,input_length_unchanged=True,
                    unchanged_inner_streams=sum(e.name != file.stream_name for e in resolver.hdb.iter_streams()),
                    unchanged_outer_streams=sum(e.name != '_hdb' for e in resolver.outer.iter_streams()),unrelated_input_payloads_exact=True,
                    source_declarations_and_cached_resources_exact=True,resources=resources,machine_resource_index=index,machine_mutation=mutation,
                    refused_candidates=refusals,scope='Same-length existing label reference; source declarations and opaque input regions are untouched.')
                save(directory/'proposal-before-native.json',row)
                return row
    return dict(case=case,unsupported=True,refused_candidates=refusals)


def main():
    OUTPUT.mkdir()
    for name in (Path(__file__).name,'source_q_contact_patch.py','source_q_read_context.py','source_q_machine_reader.py','QMachineOracle.cs'):
        (OUTPUT/name).write_bytes((P/name).read_bytes())
    bound = json.loads((P/'q-machine-project-bound-corpus-20261001-v1/before-reverse.json').read_text())
    rows = []
    for case in sorted(bound['projects']):
        try:
            row = propose(case,bound)
        except ValueError as exc:
            row = dict(case=case,unsupported=True,reason=str(exc),native_called=False)
            directory = OUTPUT/(case+'-unsupported')
            directory.mkdir()
            (directory/'input.gxw').write_bytes((P/'noeul-native-batch'/case/'input.gxw').read_bytes())
            save(directory/'failure.json',row)
        rows.append(row)
        save(OUTPUT/'before-native.json',dict(scope=__doc__,proposals=rows,prepared_complete=False))
    controls = []
    for row in rows:
        if row.get('unsupported'):
            continue
        for stage in ('original','expected'):
            index = row['machine_resource_index']
            pcode = (OUTPUT/row['case']/f'{stage}-pcode-{index}.bin').read_bytes()
            controls.append(dict(id=len(controls),case=row['case'],stage=stage,resource_index=index,pcode_hex=pcode.hex(),parameter_hex=row['parameter_hex']))
    save(OUTPUT/'before-native.json',dict(scope=__doc__,proposals=rows,prepared_complete=True))
    save(OUTPUT/'controls-before-native.json',controls)
    executable = OUTPUT/'QMachineOracle.exe'
    build = subprocess.run([str(Path(os.environ['WINDIR'])/'Microsoft.NET/Framework/v4.0.30319/csc.exe'),'/nologo','/platform:x86',
        '/out:'+str(executable),str(OUTPUT/'QMachineOracle.cs')],capture_output=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
    (OUTPUT/'build.txt').write_bytes(build.stdout+build.stderr)
    if build.returncode:
        raise RuntimeError('Owned memory helper build failed; retained')
    requests = OUTPUT/'requests.tsv'
    requests.write_text('\n'.join(str(r['id'])+'\t'+base64.b64encode(bytes.fromhex(r['pcode_hex'])).decode()+'\t'+
        base64.b64encode(bytes.fromhex(r['parameter_hex'])).decode() for r in controls)+'\n',encoding='ascii')
    process = subprocess.run([str(executable),'D:/GXWORKS2/Easysocket/CodeGenerator/ECCodeGenerator2.dll','forward',str(requests),str(OUTPUT/'output.jsonl')],
        capture_output=True,timeout=45,creationflags=subprocess.CREATE_NO_WINDOW)
    (OUTPUT/'stdout.bin').write_bytes(process.stdout)
    (OUTPUT/'stderr.bin').write_bytes(process.stderr)
    if process.returncode:
        raise RuntimeError('Owned memory controls failed; retained')
    native = [json.loads(line) for line in (OUTPUT/'output.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    comparison = []
    for row,result in zip(controls,native,strict=True):
        comparison.append(dict(id=row['id'],case=row['case'],stage=row['stage'],native_complete=result['code'] == 0 and
            result['consumed'] == len(row['pcode_hex'])//2 and result['remaining'] == 0,
            machine_exact=base64.b64decode(result['output_base64']) == (OUTPUT/row['case']/f'{row["stage"]}-machine-{row["resource_index"]}.bin').read_bytes(),
            input_unchanged=result['input_unchanged'] and result['guards_intact']))
    save(OUTPUT/'comparison.json',comparison)
    failures = [r for r in comparison if not all(r[k] for k in ('native_complete','machine_exact','input_unchanged'))]
    summary = dict(original_projects=len(rows),proposals=sum(not r.get('unsupported',False) for r in rows),
        memory_controls=len(comparison),whole_machine_predictions_exact=sum(r['machine_exact'] for r in comparison),failures=failures,
        device_codes=dict(Counter(str(r['device_code']) for r in rows if not r.get('unsupported'))),
        physical_byte_changes=dict(Counter(str(len(r['physical_changed_offsets'])) for r in rows if not r.get('unsupported'))),
        scope='Memory conversion only; candidate GXW files still await native compile/check/save/reopen.')
    save(OUTPUT/'summary.json',summary)
    print(json.dumps(summary),flush=True)
    if failures:
        raise ValueError('Prospective label contact machine prediction differs; retained')


if __name__ == '__main__':
    main()
