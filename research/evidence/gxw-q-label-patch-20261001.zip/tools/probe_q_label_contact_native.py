"""Compile, observe actual checked code, and persist original-label proposals.

Full-mask checks retain original rejection and public projection failures.
Compile/save/reopen is measured separately; no diagnostic or native API result
is replaced. Old untouched controls are reused only after direct input/PCode
comparison and project-owned compiler correspondence checks.
"""
from pathlib import Path
import json
import sys

P = Path(__file__).resolve().parent
ROOT = P.parents[3]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'research')]
from gxw.container import CompoundFile
from gxw.project_resolver import GXWProjectResolver
from gxw.token_pou import frame_token_pou
from source_q_direct_projection import project_projection
from probe_fx1s_lossless_project_patch import native_run
from probe_fx_operand_rules import traced_run
import probe_q_project_patch_check_save as observation

PRIOR = P/'q-label-contact-candidates-20261001-v1'
OUTPUT = P/'q-label-contact-native-20261001-v1'
observation.PRIOR = PRIOR


def save(path,value):
    path.write_text(json.dumps(value,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')


def owned_check(case, stage, proposal):
    directory = OUTPUT/case
    source = PRIOR/case/(stage+'.gxw')
    if stage == 'original' and case in ('case-16','case-18','case-23','case-30','case-31'):
        existing = P/'q-lossless-project-patch-check-save-20261001-v3'/case/'original-check-1'
        result = json.loads((existing/'observation.json').read_text())
        if ((existing/'input.gxw').read_bytes() != source.read_bytes() or not result['project_owned_compiler'] or
            result['observation_errors'] or not all(r['checked_current_pcode'] for r in result['resources'])):
            raise ValueError('Untouched native control cannot be reused')
        for resource in proposal['resources']:
            index = resource['index']
            if (existing/f'pcode-{index}-0.bin').read_bytes() != (PRIOR/case/f'original-pcode-{index}.bin').read_bytes():
                raise ValueError('Old untouched compiler output differs')
        row = dict(reused_from=str(existing), result=result)
        save(directory/'original-check.json', row)
        return row
    plan = json.loads((P/'noeul-native-batch'/case/'plan.json').read_text())
    plan['project_owned_compiler'] = True
    attempts = []
    for attempt in range(1,5):
        native = directory/f'{stage}-check-{attempt}'
        prepared = native_run(source,native,plan,compile=True,export=False,check=True,alias='QPATCH',prepare_only=True)
        (native/'check-observer.js').write_text(observation.SCRIPT,encoding='utf-8')
        traced_run([prepared['executable'],prepared['plan_file']],observation.SCRIPT,native,timeout=50)
        events = [json.loads(line) for line in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
        collision = any(e.get('operation') == 'NativeTemporaryDirectoryCollision' for e in events)
        attempts.append(dict(attempt=attempt,directory=str(native),temporary_collision=collision))
        if not collision:
            break
    result = observation.inspect_trace(native,source,proposal,'original' if stage == 'original' else 'expected')
    row = dict(attempts=attempts,result=result)
    save(directory/(stage+'-check.json'),row)
    return row


def process(case):
    proposal = json.loads((PRIOR/case/'proposal-before-native.json').read_text())
    directory = OUTPUT/case
    directory.mkdir()
    checks = {stage:owned_check(case,stage,proposal) for stage in ('original','candidate')}
    results = [checks[stage]['result'] for stage in ('original','candidate')]
    if any(r['observation_errors'] or not r['project_owned_compiler'] or not all(s['compiler_pcode_exact'] for s in r['resources']) for r in results):
        raise ValueError('Whole native compile or observation differs; retained')
    complete_binding = all(r['backend_complete'] and all(s['checked_current_pcode'] for s in r['resources']) for r in results)
    row = dict(case=case,checks=checks,whole_compile_pcode_exact=True,
        full_check_current_code_bound=complete_binding,
        observed_backend_diagnostics_unchanged=(results[0]['backend_diagnostics'] == results[1]['backend_diagnostics']) if complete_binding else None,
        public_check_complete=all(r['public_check_complete'] for r in results),
        scope='Separate persistence does not resolve, suppress or reclassify original full-check rejection.')
    save(directory/'check-comparison.json',row)
    plan = json.loads((P/'noeul-native-batch'/case/'plan.json').read_text())
    plan['project_owned_compiler'] = True
    native = directory/'candidate-save-separate'
    row['save'] = native_run(PRIOR/case/'candidate.gxw',native,plan,compile=True,export=True,check=False,alias='QPATCH')
    saved = native/'native-saved.gxw'
    resources = []
    for resource in proposal['resources']:
        index = resource['index']
        actual = native/f'pcode-{index}-0.bin'
        expected = (PRIOR/case/f'expected-pcode-{index}.bin').read_bytes()
        resources.append(dict(index=index,name=resource['name'],save_pcode_exact=actual.exists() and actual.read_bytes() == expected))
    if saved.exists():
        resolver = GXWProjectResolver(CompoundFile(saved.read_bytes()))
        row['saved_source_body_exact'] = frame_token_pou(resolver.read_logical_file(proposal['logical'])).body == (PRIOR/case/'expected-source-body.bin').read_bytes()
        row['saved_complete_source_predictions_exact'] = all(r['output'] == (PRIOR/case/f'expected-pcode-{r["resource_index"]}.bin').read_bytes()
                                                            for r in project_projection(saved.read_bytes()))
        reopen = directory/'candidate-reopen-compile-separate'
        row['reopen'] = native_run(saved,reopen,plan,compile=True,export=False,check=False,alias='QPATCH')
        for resource in resources:
            index = resource['index']
            actual = reopen/f'pcode-{index}-0.bin'
            resource['reopen_pcode_exact'] = actual.exists() and actual.read_bytes() == (PRIOR/case/f'expected-pcode-{index}.bin').read_bytes()
    row['resources'] = resources
    save(directory/'comparison.json',row)
    compact = dict(case=case,whole_compile_pcode_exact=row['whole_compile_pcode_exact'],full_check_current_code_bound=complete_binding,
        backend_diagnostics_unchanged=row['observed_backend_diagnostics_unchanged'],
        original_backend_errors=len(results[0]['backend_diagnostics']),candidate_backend_errors=len(results[1]['backend_diagnostics']),
        backend_rejected=[r['backend_rejected'] for r in results],public_check_complete=row['public_check_complete'],
        projection_failures=[len(r['projection_failures']) for r in results],
        save_exported=row['save']['exported'],save_failures=row['save']['failures'],
        saved_source_exact=row.get('saved_source_body_exact'),saved_source_predictions_exact=row.get('saved_complete_source_predictions_exact'),
        reopen_failures=row.get('reopen',{}).get('failures'),resources=resources)
    print(json.dumps(compact),flush=True)
    if (not row['save']['exported'] or row['save']['failures'] or not row.get('saved_source_body_exact') or
        not row.get('saved_complete_source_predictions_exact') or row.get('reopen',{}).get('failures') or
        not all(r.get('save_pcode_exact') and r.get('reopen_pcode_exact') for r in resources)):
        raise ValueError('Native persistence differs; retained, subsequent cases stopped')
    return row


if __name__ == '__main__':
    OUTPUT.mkdir(exist_ok=True)
    (OUTPUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    cases = sys.argv[1:]
    if not cases:
        raise ValueError('Choose explicit prepared cases')
    if any(not (PRIOR/case/'proposal-before-native.json').exists() for case in cases):
        raise ValueError('Invocation includes a case without a bounded prospective proposal')
    for case in cases:
        process(case)
