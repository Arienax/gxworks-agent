"""Check unvisited Q resources in separate owned helpers without masking errors.

The full invocation's public projection failure remains an incomplete outcome.
This selects only an originally unvisited target through the same public API;
native diagnostics, return values, and project bytes are unchanged.
"""
from pathlib import Path
import json
import os
import subprocess
import sys

P = Path(__file__).resolve().parent
ROOT = P.parents[3]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'research')]
from probe_q_label_contact_native import PRIOR, OUTPUT as FULL, owned_check, save
from probe_fx1s_lossless_project_patch import native_run
from probe_fx_operand_rules import traced_run
import probe_q_project_patch_check_save as observer
observer.PRIOR = PRIOR
OUTPUT = P/'q-label-contact-remaining-checks-20261001-v2'


def main():
    OUTPUT.mkdir()
    (OUTPUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    before = []
    for directory in sorted(FULL.glob('case-*')):
        if not (directory/'comparison.json').exists():
            continue
        row = json.loads((directory/'comparison.json').read_text())
        if row['full_check_current_code_bound']:
            continue
        proposal = json.loads((PRIOR/directory.name/'proposal-before-native.json').read_text())
        for stage in ('original','candidate'):
            observed = row['checks'][stage]['result']
            native = directory/(stage+'-check-1')
            events = [json.loads(line) for line in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
            names = {tuple(e['id']):e['name'] for e in events if e.get('operation') == 'NativeObject'}
            indices = {e['name']:e['index'] for e in events if e.get('operation') == 'Resource'}
            targets = [e for e in events if e.get('operation') == 'ProgramCheckTarget']
            # A checker may read another resource as a dependency. A matching
            # PCode read does not prove that resource's own check completed.
            visited = {indices[names[tuple(target['id'])]] for i,target in enumerate(targets)
                       if i in observed['backend_completed_indices']}
            missing = [r for r in proposal['resources'] if r['index'] not in visited]
            previous = P/'q-label-contact-remaining-checks-20261001-v1'/(directory.name+'-'+stage+'-'+str(missing[0]['index'])) if missing else None
            if previous is not None and (previous/'observation.json').exists():
                captured = json.loads((previous/'observation.json').read_text())
                if captured['backend_complete'] and all(r['compiler_pcode_exact'] and r['checked_current_pcode'] for r in captured['resources']):
                    missing = [r for r in missing if r['index'] != captured['resources'][0]['index']]
            before.extend(dict(case=directory.name,stage=stage,target_index=r['index'],resource=r['name']) for r in missing)
    save(OUTPUT/'before-native.json',dict(scope=__doc__,selections=before,
        retained_predecessor='q-label-contact-remaining-checks-20261001-v1',
        correction='v1 selected unvisited PCode reads. v2 selects resources without a completed own-target check; dependency reads are not check completion. Completed v1 target checks remain reused.'))
    results = []
    for selection in before:
        case,stage,index = selection['case'],selection['stage'],selection['target_index']
        directory = OUTPUT/(case+'-'+stage+'-'+str(index))
        proposal = json.loads((PRIOR/case/'proposal-before-native.json').read_text())
        resource = next(r for r in proposal['resources'] if r['index'] == index)
        plan = json.loads((P/'noeul-native-batch'/case/'plan.json').read_text())
        plan['project_owned_compiler'] = True
        prepared = native_run(PRIOR/case/(stage+'.gxw'),directory,plan,compile=True,export=False,check=True,alias='QPATCH',prepare_only=True)
        source = directory/'WorkspaceReplayOracle.cs'
        raw = source.read_text()
        marker = '                var targets=Inventory(workspace,collection);'
        if raw.count(marker) != 1:
            raise ValueError('Inspected check target enumeration differs')
        raw = raw.replace(marker,marker+'\n'+
            '                if(targets.Count<='+str(index)+')throw new Exception("Selected public check target absent");\n'+
            '                targets=new List<ObjectId>{targets['+str(index)+']};\n'+
            '                Record(new {operation="ProgramCheckTargetSelection",selected_index='+str(index)+'});')
        source.write_text(raw,encoding='utf-8')
        command = [str(Path(os.environ['WINDIR'])/'Microsoft.NET/Framework/v4.0.30319/csc.exe'),'/nologo','/platform:x86',
            '/r:System.Web.Extensions.dll','/r:System.Windows.Forms.dll','/out:'+prepared['executable']]
        command.extend(str(directory/name) for name in ('WorkspaceReplayOracle.cs','NativeFrontendSnapshot.cs','NativeSfcGraphOracle.cs','NativeWorkspaceCopyOracle.cs'))
        build = subprocess.run(command,capture_output=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
        (directory/'selected-build.txt').write_bytes(build.stdout+build.stderr)
        if build.returncode:
            raise RuntimeError('Owned selected-target helper build failed; retained')
        (directory/'check-observer.js').write_text(observer.SCRIPT,encoding='utf-8')
        traced_run([prepared['executable'],prepared['plan_file']],observer.SCRIPT,directory,timeout=50)
        # Native inventory index selects the observed resource; the comparison
        # still uses its full-compile resource index and independent prediction.
        result = observer.inspect_trace(directory,PRIOR/case/(stage+'.gxw'),dict(case=case,resources=[resource]),
                                        'original' if stage == 'original' else 'expected')
        if (result['observation_errors'] or not result['backend_complete'] or
            not all(r['compiler_pcode_exact'] and r['checked_current_pcode'] for r in result['resources'])):
            raise ValueError('Selected target correspondence incomplete; retained')
        row = dict(selection=selection,result=result)
        results.append(row)
        save(OUTPUT/'comparison.json',results)
        print(json.dumps(dict(**selection,backend_complete=result['backend_complete'],backend_rejected=result['backend_rejected'],
            public_complete=result['public_check_complete'],backend_errors=len(result['backend_diagnostics']),
            projection_failures=len(result['projection_failures']),current_code_exact=True)),flush=True)


if __name__ == '__main__':
    main()
