"""Bounded ST contact mutation in an independently read Q machine body.

The address table must come from the same project's parameter record. Exactly
one ordinary kind-1 word and its parity bit change; every other raw word remains
untouched. A matching independent PCode prediction is required. This is a
research operation on a conversion input, not a project-cache or PLC writer.
"""
import struct
from source_q_machine_reader import read_machine


def patch_bit_contact(machine, profile, *, record_index, device_code, before_number,
                      after_number, allocated_count, expected_pcode):
    """Prospective ordinary kind-1 bit contact; no project acceptance claim.

    The source allocation and machine read table are supplied by the same
    original project. Only the address, bit number and parity fields change.
    Unsupported subtypes, instruction branches or device ranges are refused.
    """
    if device_code not in (0x90, 0x92, 0x93, 0x94, 0x98, 0x9C, 0x9D, 0xA0, 0xA1):
        raise ValueError('Device is outside the inspected configurable bit ranges')
    if not 0 <= before_number < allocated_count or not 0 <= after_number < allocated_count or before_number == after_number:
        raise ValueError('Contact proposal is outside allocation or has no effect')
    records = read_machine(machine, profile)
    if any(r['handling'] != 'decoded' for r in records):
        raise ValueError('Selected body has unresolved machine semantics')
    if type(record_index) is not int or not 0 <= record_index < len(records):
        raise ValueError('Contact record index outside body')
    record = records[record_index]
    if record['kinds'] != [1] or record['word_count'] != 1:
        raise ValueError('Contact is outside the single-word kind-1 branch')
    rows = [struct.unpack_from('<HBB', profile.devices, 1+4*i) for i in range(profile.devices[0])]
    positions = [i for i, row in enumerate(rows) if row[2] == device_code]
    if len(positions) != 1:
        raise ValueError('Contact device range is absent or ambiguous')
    position = positions[0]
    start, kind, _ = rows[position]
    stop = rows[position+1][0] if position+1 < len(rows) else 0xFFFF
    if kind != 1 or allocated_count > (stop-start)*16:
        raise ValueError('Source allocation exceeds the bound bit range')
    old_word, = struct.unpack('<I', bytes.fromhex(record['raw_hex']))
    if (old_word >> 24) & 0x7F not in (0, 1, 8, 9, 16, 17):
        raise ValueError('Word is outside ordinary load/AND/OR branches')
    if (old_word >> 16) & 0xF != 3 or old_word & 0xFFFF != start+(before_number >> 4):
        raise ValueError('Existing contact address or subtype differs')
    if (old_word >> 20) & 15 != before_number & 15:
        raise ValueError('Existing bit differs from the source operand')
    word = (old_word & ~0x80F0FFFF) | ((after_number & 15) << 20) | (start+(after_number >> 4))
    word |= (word.bit_count() & 1) << 31
    output = bytearray(machine)
    struct.pack_into('<I', output, record['offset'], word)
    after = bytes(output)
    decoded = read_machine(after, profile)
    if any(r['handling'] != 'decoded' for r in decoded) or b''.join(bytes.fromhex(r['pcode_hex']) for r in decoded) != expected_pcode:
        raise ValueError('Machine proposal differs from the independent source prediction')
    if len(decoded) != len(records) or any(a['raw_hex'] != b['raw_hex'] for i,(a,b) in enumerate(zip(records,decoded)) if i != record_index):
        raise ValueError('An unrelated machine record changed')
    return after, dict(record_index=record_index, machine_offset=record['offset'], device_code=device_code,
                       before_number=before_number, after_number=after_number, before_word=old_word, after_word=word,
                       raw_words_preserved=len(records)-1)


def patch_st_contact(machine, profile, *, record_index, before_number, after_number,
                     allocated_count, expected_pcode):
    if not 0<=before_number<allocated_count or not 0<=after_number<allocated_count:
        raise ValueError('ST contact outside the bound source allocation')
    if before_number==after_number:
        raise ValueError('Contact mutation has no effect')
    records=read_machine(machine,profile)
    if any(r['handling']!='decoded' for r in records):
        raise ValueError('Selected body has unresolved machine semantics')
    record=records[record_index]
    if record['kinds']!=[1] or record['word_count']!=1:
        raise ValueError('Selected contact is outside the ordinary single-word branch')
    rows=[struct.unpack_from('<HBB',profile.devices,1+4*i) for i in range(profile.devices[0])]
    start,kind,device=next(row for row in rows if row[2]==0xC6)
    if kind!=2:raise ValueError('ST contact table is not the inspected kind')
    old_word,=struct.unpack('<I',bytes.fromhex(record['raw_hex']))
    if ((old_word>>24)&0x7F) not in (0,1,8,9,16,17):
        raise ValueError('Selected word is not an ordinary load/AND/OR contact')
    if (old_word>>16)&0xF!=3 or (old_word&0xFFFF)!=start+(before_number>>3):
        raise ValueError('Existing ST contact address or subtype differs')
    old_bit=(old_word>>20)&15
    if old_bit>>1!=before_number&7:
        raise ValueError('Existing ST bit does not match the bound operand')
    bit=((after_number&7)<<1)|(old_bit&1)
    word=(old_word&~(0x80F0FFFF))|(bit<<20)|(start+(after_number>>3))
    word|=(word.bit_count()&1)<<31
    after=bytearray(machine)
    struct.pack_into('<I',after,record['offset'],word)
    result=bytes(after)
    decoded=read_machine(result,profile)
    if any(r['handling']!='decoded' for r in decoded):
        raise ValueError('Proposed machine body has an unresolved record')
    if b''.join(bytes.fromhex(r['pcode_hex']) for r in decoded)!=expected_pcode:
        raise ValueError('Independent machine mutation differs from source prediction')
    if len(records)!=len(decoded) or any(a['raw_hex']!=b['raw_hex'] for i,(a,b) in enumerate(zip(records,decoded)) if i!=record_index):
        raise ValueError('Machine mutation changed an unrelated record')
    return result,dict(record_index=record_index,machine_offset=record['offset'],
        before_word=old_word,after_word=word,before_number=before_number,after_number=after_number,
        raw_words_preserved=len(records)-1)
