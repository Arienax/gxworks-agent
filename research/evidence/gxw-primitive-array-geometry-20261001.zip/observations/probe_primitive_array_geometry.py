"""Source-first typed array extents against offline native compilation.

Only copied project declarations and ST are edited. No PLC or simulator is
executed. Predictions precede native use; failed builds/checks remain saved.
"""
from pathlib import Path
import json, math, re, sys

P = Path(__file__).resolve().parent
ROOT = P.parents[3]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'research'), str(P)]
from gxw.declarations import parse_declarations, edit_declarations, serialize_declarations
from gxw.project_metadata import mark_observed_source_compile_pending
from gxw.compiler_tables import parse_compiler_tables
from gxw.compiler_assignment import parse_compiler_assignment
from probe_gxw_st_sources import replace_observed_st
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_program_check_resources import SCRIPT
from probe_minimal_conditional_port_writes import streams, observe
from witness_st_conditional_transfers import decode


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def numeric_operand(text):
    if text.startswith('K'):
        return int(text[1:])
    if text.startswith('H'):
        return int(text[1:], 16)
    if text.startswith('E'):
        return float(text[1:])
    return text


def literal_value(text):
    if text.startswith("'"):
        return '"'+text[1:-1]+'"'
    if text.startswith('T#'):
        return int(text[2:-1])*1000
    if text in ('TRUE', 'FALSE'):
        return None
    if '16#' in text:
        return int(text.split('16#')[-1], 16)
    if '#' in text:
        return int(text.split('#')[-1])
    return float(text) if '.' in text else int(text)


def main():
    out = P / (sys.argv[1] if len(sys.argv) > 1 else 'primitive-array-geometry-20261001')
    out.mkdir(exist_ok=False)
    literal_style = sys.argv[2] if len(sys.argv) > 2 else 'typed'
    assert literal_style in ('typed', 'plain')
    block_style = sys.argv[3] if len(sys.argv) > 3 else 'flat'
    assert block_style in ('flat', 'branches')
    specs = [
        ('bits', 'BOOL', 0, 1, ['TRUE', 'FALSE', 'TRUE']),
        ('ints', 'INT', 2, 1, ['201', '202', '203']),
        ('words', 'WORD', 17, 1, ['WORD#16#121', 'WORD#16#122', 'WORD#16#123']),
        ('dwords', 'DWORD', 18, 2, ['DWORD#16#1000010', 'DWORD#16#1000020', 'DWORD#16#1000030']),
        ('dints', 'DINT', 3, 2, ['DINT#100001', 'DINT#100002', 'DINT#100003']),
        ('reals', 'REAL', 9, 2, ['1.25', '2.5', '3.75']),
        ('times', 'TIME', 11, 2, ['T#1s', 'T#2s', 'T#3s']),
        ('shorts', 'STRING[1]', 15, 1, ["'A'", "'B'", "'C'"]),
        ('even', 'STRING[4]', 15, 3, ["'D0'", "'D1'", "'D2'"]),
        ('odd', 'STRING[5]', 15, 3, ["'E0'", "'E1'", "'E2'"]),
        ('longer', 'STRING[12]', 15, 7, ["'F0'", "'F1'", "'F2'"]),
        ('matrix', 'STRING[4]', 15, 3, ["'G0'", "'G1'", "'G2'"]),
        ('cube', 'DINT', 3, 2, ['DINT#200001', 'DINT#200002', 'DINT#200003']),
    ]
    selection = sys.argv[4] if len(sys.argv) > 4 else None
    if selection is not None:
        first_spec, last_spec = map(int, selection.split(':'))
        specs = specs[first_spec:last_spec]
    coordinate_style = sys.argv[5] if len(sys.argv) > 5 else 'endpoints'
    assert coordinate_style in ('endpoints', 'axes')
    rows, declarations, body = [], [], []
    for name, typ, code, width, literals in specs:
        bounds = [(-2, 0), (3, 4)] if name == 'matrix' else [(1, 2), (-1, 1), (4, 5)] if name == 'cube' else [(-5, -3)]
        first = [low for low, high in bounds]
        second = first[:-1] + [first[-1] + 1]
        last = [high for low, high in bounds]
        count = math.prod(high-low+1 for low, high in bounds)
        coordinates = (first, second, last)
        relatives = (0, 1, count-1)
        if coordinate_style == 'axes' and name == 'matrix':
            coordinates = ([-2,3],[-2,4],[-1,3],[0,3],[0,4])
            relatives = (0,1,2,4,5)
            literals = ["'G0'","'G1'","'G2'","'G3'","'G4'"]
        elif coordinate_style == 'axes' and name == 'cube':
            coordinates = ([1,-1,4],[1,-1,5],[1,0,4],[2,-1,4],[2,0,5],[2,1,5])
            relatives = (0,1,2,6,9,11)
            literals = [f'DINT#{value}' for value in range(300001,300007)]
        if literal_style == 'plain' and code in (3,17,18):
            literals = [str(literal_value(value)) for value in literals]
        datatype = 'ARRAY[' + ','.join(f'{low}..{high}' for low,high in bounds) + '] OF ' + typ
        declarations += [dict(name=name, data_type=datatype), dict(name=name+'Result', data_type=typ)]
        points = []
        if block_style == 'branches' and code != 0:
            body.append('IF bits[-5] THEN')
        for indices, literal, relative in zip(coordinates, literals, relatives, strict=True):
            expr = name + '[' + ','.join(map(str, indices)) + ']'
            body.append(expr + ' := ' + literal + ';')
            points.append(dict(indices=indices, literal=literal, expected_native_literal=literal_value(literal),
                               expected_relative=relative*width))
        body.append(name+'Result := '+name+'['+','.join(map(str,last))+'];')
        if block_style == 'branches' and code != 0:
            body.append('END_IF;')
        rows.append(dict(name=name, data_type=datatype, primitive_type=code, width=width, count=count,
                         expected_reservation=count*width, points=points))
    plan = dict(scope=__doc__, literal_style=literal_style, block_style=block_style, selection=selection,
        coordinate_style=coordinate_style,
        arrays=rows, source='\r\n'.join(body)+'\r\n',
        hypotheses=['Each scalar element is rounded to allocation words before multiplying by array count.',
                    'BOOL remains a separate bit allocation; DINT/REAL/TIME use two words.',
                    'Static negative lower bounds and rank 2/3 coordinates use row-major offsets.'])
    original_path = P / 'st-string-intrinsic-index-controls-20260930/right-dynamic-source-static-target/native-1/native-saved.gxw'
    original = original_path.read_bytes()
    before = streams(original)
    logical = 'MAIN.Labels.lh'
    document = parse_declarations(before[logical], logical_name=logical)
    document = edit_declarations(document, remove=[r.name for r in document.rows], upserts=declarations)
    program, _ = replace_observed_st(before['MAIN.Program.pou'], plan['source'])
    changes = {logical:mark_observed_source_compile_pending(serialize_declarations(document), logical_name=logical),
               'MAIN.Program.pou':mark_observed_source_compile_pending(program, logical_name='MAIN.Program.pou')}
    source = original
    for name, raw in changes.items():
        source, _ = patch_raw(source, name, before[name], raw)
    assert streams(source) == dict(before, **changes)
    plan.update(input_provenance=original_path.relative_to(ROOT).as_posix(),
                changed_streams=list(changes), unrelated_payloads='byte-identical')
    save(out / 'prediction-before-native.json', plan)
    path = out / 'input.gxw'
    path.write_bytes(source)
    (out / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    observer = (P / 'native-allocation-bitmap-v2/observer.js').read_text(encoding='utf-8')
    trace = out / 'trace.js'
    trace.write_text('(()=>{'+observer+'\n})();\n(()=>{'+SCRIPT+'\n})();', encoding='utf-8')
    print(json.dumps(dict(stage='predictions-saved', arrays=len(rows), point_predictions=sum(len(r['points']) for r in rows))), flush=True)
    native, result, process = observe(path, out, trace)
    messages = [json.loads(line) for line in (native/'events.jsonl').read_text(encoding='utf-8').splitlines()]
    events = [r['payload'] for r in messages if r.get('type') == 'send']
    errors = [r for r in messages if r.get('type') == 'error'] + [r for r in events if 'error' in r.get('event','') or r.get('observation_error')]
    comparison = dict(check=result['check'], compiler_rejected=result['backend_check_rejected'],
        diagnostics=result['diagnostics'], process=process, trace_errors=errors, arrays=[])
    save(out/'comparison.json', comparison)
    if errors or not (native/'native-saved.gxw').exists():
        print(json.dumps(dict(stage='native-refused-or-incomplete', check=result['check'],
            diagnostic_codes=sorted({hex(r['code']) for r in result['diagnostics']}),
            positions=sorted({r['top'] for r in result['diagnostics']}),errors=errors)), flush=True)
        return
    saved_raw = streams((native/'native-saved.gxw').read_bytes())['CGTable.dat']
    tables = parse_compiler_tables(saved_raw)
    assert tables.reconstruct() == saved_raw
    owner = next(tables.pou_at(r.table_offset) for r in tables.tables[1].records if tables.pou_at(r.table_offset).name_bytes == b'MAIN')
    components = {c.name_bytes.decode('ascii'):c for c in tables.components(owner)}
    listing = decode((native/'pcode-0-0.bin').read_bytes())
    save(out/'core-listing.json', listing)
    for expected in rows:
        component = components[expected['name']]
        descriptor = tables.array_at(tables.component_array_offset(component))
        base = parse_compiler_assignment(component.user_info)
        assert base.status == 'decoded'
        allocations = [e for e in events if e.get('event') == 'typed-allocation' and e.get('after') == component.user_info.hex()]
        assert len(allocations) == 1
        writes = [e for e in events if e.get('event') == 'component-userinfo-write' and e.get('component_offset') == component.record.table_offset and e.get('raw') == component.user_info.hex()]
        assert writes
        points = []
        for point in expected['points']:
            operand = base.device_family+str(base.number+point['expected_relative'])
            value = point['expected_native_literal']
            if value is None:
                found = [r for r in listing if r.get('args') and operand in r['args']]
                points.append(dict(point, expected_operand=operand, native_records=found,
                    handling='bit-address-presence-only', address_present=bool(found)))
            else:
                found = [r for r in listing if len(r.get('args',[]))==2 and numeric_operand(r['args'][0])==value]
                actual = found[0]['args'][1] if len(found)==1 else None
                points.append(dict(point, expected_operand=operand, native_records=found,
                    handling='unique-native-literal-write', actual_operand=actual, address_present=actual==operand))
        comparison['arrays'].append(dict(name=expected['name'], component_offset=component.record.table_offset,
            expected=expected, actual_type=descriptor.element_type, actual_count=descriptor.total_count,
            assignment=dict(family=base.device_family, number=base.number, count=base.reserved_count, raw=base.raw.hex()),
            extent_equal=base.reserved_count == expected['expected_reservation'] and descriptor.total_count == expected['count'] and descriptor.element_type == expected['primitive_type'] and base.device_family == ('M' if expected['primitive_type']==0 else 'D'),
            native_allocation=allocations[0], points=points))
    save(out/'comparison.json', comparison)
    reopen = out/'reopen'
    reopen.mkdir()
    reopened, reopen_result, reopen_process = observe(native/'native-saved.gxw', reopen, trace)
    comparison['reopen'] = dict(check=reopen_result['check'], process=reopen_process,
        pcode_identical=(native/'pcode-0-0.bin').read_bytes() == (reopened/'pcode-0-0.bin').read_bytes())
    save(out/'comparison.json', comparison)
    print(json.dumps(dict(stage='complete', arrays=len(comparison['arrays']),
        extent_matches=sum(r['extent_equal'] for r in comparison['arrays']),
        point_addresses_present=sum(p['address_present'] for r in comparison['arrays'] for p in r['points']),
        check=comparison['check'], reopen=comparison['reopen'])), flush=True)


if __name__ == '__main__':
    main()
