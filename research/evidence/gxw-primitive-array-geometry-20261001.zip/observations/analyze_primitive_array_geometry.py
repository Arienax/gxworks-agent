"""Separate native acceptance, allocation matches and current-code checks."""
from pathlib import Path
import json, sys

P = Path(__file__).resolve().parent
ROOT = P.parents[3]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'research'), str(P)]
from probe_minimal_conditional_port_writes import streams
from probe_gxw_parameters import project_allocation_ranges

GROUPS = (
    'primitive-array-geometry-20261001',
    'primitive-array-geometry-plain-20261001',
    'primitive-array-geometry-branches-20261001',
    'primitive-array-geometry-types-20261001',
    'primitive-array-geometry-strings-time-20261001',
    'primitive-array-geometry-multirank-20261001',
    'primitive-array-geometry-axes-20261001',
)


def current_code_reads(native):
    operations = [json.loads(line) for line in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    generated = {r['name']:r['index'] for r in operations if r.get('operation')=='Resource'}
    names = {tuple(r['id']):r['name'] for r in operations if r.get('operation')=='NativeObject'}
    messages = [json.loads(line) for line in (native/'events.jsonl').read_text(encoding='utf-8').splitlines()]
    records = []
    for message in messages:
        row = message.get('payload',{})
        if row.get('event')!='workspace-pcode-read' or row['phase']!='check':continue
        name = names.get(tuple(row['target']))
        index = generated.get(name)
        for channel, buffer in enumerate(row['buffers']):
            if buffer['raw_hex'] is None or not buffer['size']:continue
            assert index is not None and row['hresult']>=0 and row['code']==0
            actual = bytes.fromhex(buffer['raw_hex'])
            expected = (native/f'pcode-{index}-{channel}.bin').read_bytes()
            records.append(dict(serial=row['serial'],resource=name,channel=channel,bytes=len(actual),
                matches_current=actual==expected,target=row['target']))
    return dict(reads=records,nonempty_reads=len(records),all_match=bool(records) and all(r['matches_current'] for r in records),
        published_before_check=any(r.get('operation')=='Workspace.UpdatePCodeBeforeProgramCheck' for r in operations))


def main():
    cases=[]
    for group in GROUPS:
        directory=P/group
        comparison=json.loads((directory/'comparison.json').read_text(encoding='utf-8'))
        plan=json.loads((directory/'prediction-before-native.json').read_text(encoding='utf-8'))
        native=directory/'native-1'
        content=streams((directory/'input.gxw').read_bytes())
        project=next(raw for name,raw in content.items() if name.endswith('.prj'))
        pointer=next(r for r in project_allocation_ranges(project)['ranges'] if r['name']=='P')
        reads=current_code_reads(native)
        check=comparison['check']
        accepted=check is not None and not check['rejected']
        record=dict(case=group,check=check,handling='native-accepted' if accepted else 'backend-rejected' if check else 'frontend-refused',
            diagnostic_codes=sorted({hex(r['code']) for r in comparison['diagnostics']}),
            diagnostic_positions=sorted({r['top'] for r in comparison['diagnostics']}),
            source_literal_style=plan.get('literal_style','typed'),block_style=plan.get('block_style','flat'),
            pointer_range={k:pointer[k] for k in ('lower','upper','handling')},
            current_check_code=reads,observed_arrays=len(comparison['arrays']),
            extent_matches=sum(r['extent_equal'] for r in comparison['arrays']),
            unique_literal_addresses=sum(p['address_present'] for r in comparison['arrays'] for p in r['points'] if p['handling']=='unique-native-literal-write'),
            bit_presence_only=sum(p['address_present'] for r in comparison['arrays'] for p in r['points'] if p['handling']=='bit-address-presence-only'),
            observations=(directory/'comparison.json').relative_to(ROOT).as_posix())
        if accepted:
            assert reads['all_match'] and reads['published_before_check']
            reopen=current_code_reads(directory/'reopen/native-1')
            assert reopen['all_match'] and reopen['published_before_check']
            assert comparison['reopen']['check']['rejected'] is False and comparison['reopen']['pcode_identical']
            assert record['observed_arrays']==record['extent_matches']
            record['reopen']=dict(check=comparison['reopen']['check'],pcode_identical=True,current_check_code=reopen)
        cases.append(record)
    result=dict(scope=__doc__,cases=cases,
        summary=dict(observations=len(cases),native_accepted=sum(r['handling']=='native-accepted' for r in cases),
            frontend_refused=sum(r['handling']=='frontend-refused' for r in cases),backend_rejected=sum(r['handling']=='backend-rejected' for r in cases),
            accepted_array_instances=sum(r['observed_arrays'] for r in cases),extent_matches=sum(r['extent_matches'] for r in cases),
            independent_literal_addresses=sum(r['unique_literal_addresses'] for r in cases),bit_presence_only=sum(r['bit_presence_only'] for r in cases)),
        inference='The 48-word-operation flat case is rejected at its long instruction segment. Smaller cases with 16, 20 and 12 word operations pass. The exact length limit and interaction with instruction mix are not determined. Branch splitting refuses with the existing unset P range; no range is changed here.',
        boundaries='Prospective reservations and relative offsets; absolute bases are retrospective. Q lexical PCode decoding has prior native converter cross-checks, but this experiment does not call that converter again. No PLC execution.')
    output=P/'primitive-array-geometry-analysis-20261001.json'
    assert not output.exists(), 'preserve the existing analysis'
    output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result['summary']))


if __name__=='__main__':main()
