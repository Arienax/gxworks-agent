"""Observe native compiler calls in an explicitly selected GX Works2 process.

The injected code only reads bounded arguments and attaches listeners. It does
not call the compiler, replace functions, alter arguments, or automate the UI.
Use an isolated public project; trace output may contain its source and paths.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys
import threading
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "research/experiments/re-tools"))
import frida

DLL = Path("D:/GXWORKS2/Easysocket/Compiler/ECCompiler.dll")
DLL_HASH = "4f7b2398874c7a921f49f13f25a9a603562032b039de8a5bb74114df27fadf16"
IEC_DLL = DLL.with_name("ECCompiler_IEC.dll")
IEC_DLL_HASH = "f58e7c70b855526bf2f943399a14089f771a43109b13ee9af34c88fb065cf4d7"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pid", type=int)
    parser.add_argument("output", type=Path)
    parser.add_argument("--seconds", type=int, default=1200)
    args = parser.parse_args()
    if hashlib.sha256(DLL.read_bytes()).hexdigest() != DLL_HASH:
        raise ValueError("native DLL differs from inspected version")
    if hashlib.sha256(IEC_DLL.read_bytes()).hexdigest() != IEC_DLL_HASH:
        raise ValueError("native IEC DLL differs from inspected version")
    device = frida.get_local_device()
    process = next((p for p in device.enumerate_processes() if p.pid == args.pid), None)
    if process is None or process.name.lower() != "gd2.exe":
        raise ValueError("explicit PID must identify GX Works2 GD2.exe")
    args.output.mkdir(parents=True, exist_ok=False)
    source = (ROOT / "research/native/CompilerTrace.js").read_bytes()
    (args.output / "CompilerTrace.js").write_bytes(source)
    request = dict(pid=args.pid, process=process.name, dll_sha256=DLL_HASH,
                   iec_dll_sha256=IEC_DLL_HASH,
                   script_sha256=hashlib.sha256(source).hexdigest(),
                   frida_version=frida.__version__, seconds=args.seconds,
                   scope="bounded read-only compiler argument observations")
    (args.output / "request.json").write_text(json.dumps(request, indent=2) + "\n")
    lock = threading.Lock()
    with (args.output / "events.jsonl").open("w", encoding="utf-8") as output:
        def receive(message, data):
            with lock:
                output.write(json.dumps(dict(time_ns=time.time_ns(), message=message), ensure_ascii=True) + "\n")
                output.flush()
            if message.get("type") == "error":
                print(json.dumps(message), flush=True)
        session = device.attach(args.pid)
        script = session.create_script(source.decode("utf-8"))
        script.on("message", receive)
        try:
            script.load()
            print("Trace attached; create STOP in output directory to detach.", flush=True)
            deadline = time.monotonic() + min(args.seconds, 3600)
            while time.monotonic() < deadline and not (args.output / "STOP").exists():
                time.sleep(.25)
        finally:
            script.unload()
            session.detach()
    print("Trace detached.", flush=True)


if __name__ == "__main__":
    main()
