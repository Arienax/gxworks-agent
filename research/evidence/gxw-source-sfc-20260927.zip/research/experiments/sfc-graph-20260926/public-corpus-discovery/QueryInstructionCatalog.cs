// Read-only offline query of the inspected ECCodeGenerator2 15.41 export ABI.
using System;
using System.Runtime.InteropServices;
using System.Text;
public static class QueryInstructionCatalog {
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]
 static extern IntPtr LoadLibraryEx(string path,IntPtr file,uint flags);
 [DllImport("kernel32.dll",CharSet=CharSet.Ansi,ExactSpelling=true)]
 static extern IntPtr GetProcAddress(IntPtr module,string name);
 [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate IntPtr NewObject();
 [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int OpenObject(IntPtr h,int cpu,int mode);
 [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int CloseObject(IntPtr h);
 [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate void DeleteObject(IntPtr h);
 // Export 0x60b9 -> 0x47e9 -> 0x8806 -> 0x2bc6b -> 0x3e7c7.
 // The first two values are read as unsigned bytes; output copies 10 bytes.
 [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int FindInstruction(
   IntPtr h,int family,int variant,[Out] byte[] descriptor);
 static T Export<T>(IntPtr module,string name) where T:class {
  IntPtr p=GetProcAddress(module,name);if(p==IntPtr.Zero)throw new Exception(name);
  return Marshal.GetDelegateForFunctionPointer(p,typeof(T)) as T;
 }
 static string Hex(byte[] b) {return BitConverter.ToString(b).Replace("-","").ToLowerInvariant();}
 public static int Main(string[] args) {
  if(IntPtr.Size!=4||args.Length!=1)return 2;
  IntPtr module=LoadLibraryEx(args[0],IntPtr.Zero,8);if(module==IntPtr.Zero)throw new Exception("LoadLibraryEx");
  uint moduleBase=unchecked((uint)module.ToInt32());
  int peOffset=Marshal.ReadInt32(module,0x3c);
  uint moduleSize=unchecked((uint)Marshal.ReadInt32(module,peOffset+0x50));
  NewObject create=Export<NewObject>(module,"ObjectNew");
  OpenObject open=Export<OpenObject>(module,"Open");
  CloseObject close=Export<CloseObject>(module,"Close");
  DeleteObject destroy=Export<DeleteObject>(module,"ObjectDelete");
  FindInstruction find=Export<FindInstruction>(module,"FindInstructionList");
  IntPtr h=create();if(h==IntPtr.Zero)throw new Exception("ObjectNew");
  try {
   int result=open(h,209,0);if(result!=0)throw new Exception("Open "+result.ToString("X8"));
   string line;
   while((line=Console.ReadLine())!=null){
    string[] fields=line.Split('\t');if(fields.Length!=2)throw new Exception("Protocol");
    int family=int.Parse(fields[0]),variant=int.Parse(fields[1]);
    if(family<0||family>127||variant<0||variant>254)throw new Exception("Uninspected query range");
    byte[] data=new byte[10];result=find(h,family,variant,data);
    uint address=BitConverter.ToUInt32(data,0);uint rva=address-moduleBase;
    string name="";
    if(result==0){
     if(rva>=moduleSize)throw new Exception("Name pointer outside module");
     StringBuilder s=new StringBuilder();bool terminated=false;
     for(uint i=0;i<64&&rva+i<moduleSize;i++){
      byte c=Marshal.ReadByte(new IntPtr(unchecked((int)(address+i))));
      if(c==0){terminated=true;break;}
      if(c<32||c>126)throw new Exception("Non-ASCII mnemonic");s.Append((char)c);
     }
     if(!terminated)throw new Exception("Unbounded mnemonic");
     name=s.ToString().Replace("\\","\\\\").Replace("\"","\\\"");
    }
    Console.WriteLine("{\"family\":"+family+",\"variant\":"+variant+",\"result\":\"0x"+
      unchecked((uint)result).ToString("x8")+"\",\"descriptor_hex\":\""+Hex(data)+
      "\",\"name_rva\":"+(result==0?rva:0)+",\"name\":\""+name+
      "\",\"active_cpu_word\":"+unchecked((ushort)Marshal.ReadInt16(module,0x16d188))+"}");
   }
  }finally{close(h);destroy(h);}
  return 0;
 }
}
