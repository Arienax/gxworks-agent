// Read-only Workspace2 getters, pinned typelib signatures. Owned offline copy.
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
partial class WorkspaceReplayOracle {
    static void CompileStatusNode(IntPtr workspace,ObjectId id,string path,int depth) {
        int status,code;int hr=Slot<IdOutIntFn>(workspace,1556)(workspace,id,out status,out code);
        IntPtr p;int nameCode;int nameHr=Slot<IdNameFn>(workspace,64)(workspace,id,out p,out nameCode);
        string name=nameHr>=0&&nameCode==0?ReadBStr(p):null;
        if(p!=IntPtr.Zero)Marshal.FreeBSTR(p);
        Record(new {operation="CompileStatusSnapshotNode",path=path,name=name,id=id.words,status=status,hresult=hr,code=code});
        if(depth<=0)return;
        int index=0;foreach(ObjectId child in Inventory(workspace,id))CompileStatusNode(workspace,child,path+"/"+(index++),depth-1);
    }
    static void CompileStatusSnapshot(IntPtr workspace,ObjectId project,string phase) {
        Record(new {operation="CompileStatusSnapshotBegin",phase=phase});
        int mode,modeCode;int modeHr=Slot<IdOutIntFn>(workspace,2800)(workspace,project,out mode,out modeCode);
        Record(new {operation="LabelModeSnapshot",value=mode,hresult=modeHr,code=modeCode});
        int value,code;int hr=Slot<IdOutIntFn>(workspace,4140)(workspace,project,out value,out code);
        Record(new {operation="CompileAllAfterSnapshot",value=value,hresult=hr,code=code});
        CompileStatusNode(workspace,project,"project",0);
        foreach(int kind in new int[]{7,25,13}) {
            ObjectId collection;Check("CompileStatusSnapshot.GetCollection",Slot<CollectionFn>(workspace,36)(workspace,project,kind,out collection,out code),code);
            int index=0;foreach(ObjectId child in Inventory(workspace,collection))
                CompileStatusNode(workspace,child,kind+"/"+(index++),kind==7?1:0);
        }
        Record(new {operation="CompileStatusSnapshotEnd",phase=phase});
    }
}
