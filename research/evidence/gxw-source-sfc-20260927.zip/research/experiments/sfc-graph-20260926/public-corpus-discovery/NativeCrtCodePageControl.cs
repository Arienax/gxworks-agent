// CRT state is confined to this owned offline process. No project/registry edit.
using System;
using System.Runtime.InteropServices;
using System.Text;
partial class WorkspaceReplayOracle {
    [DllImport("msvcr71.dll",CallingConvention=CallingConvention.Cdecl)] static extern int _getmbcp();
    [DllImport("msvcr71.dll",CallingConvention=CallingConvention.Cdecl)] static extern int _setmbcp(int value);
    [DllImport("msvcr71.dll",CallingConvention=CallingConvention.Cdecl)] static extern int _mbctolower(int value);
    [DllImport("msvcr71.dll",CallingConvention=CallingConvention.Cdecl)] static extern int _ismbclower(int value);
    [DllImport("kernel32",CharSet=CharSet.Unicode)] static extern IntPtr GetModuleHandle(string name);
    [DllImport("kernel32",CharSet=CharSet.Unicode)] static extern uint GetModuleFileName(IntPtr module,StringBuilder path,int capacity);
    static void CrtCodePageSnapshot(string phase) {
        var path=new StringBuilder(2048);GetModuleFileName(GetModuleHandle("msvcr71.dll"),path,path.Capacity);
        Record(new {operation="CrtCodePageSnapshot",phase=phase,module=path.ToString(),codepage=_getmbcp(),
            lower_N=_mbctolower(78),lower_R=_mbctolower(82),lower_F=_mbctolower(70),is_lower_n=_ismbclower(110)});
    }
    static void CrtCodePageControl(int value) {
        int result=_setmbcp(value);Record(new {operation="CrtSetCodePage",requested=value,result=result});
        if(result!=0)throw new Exception("CRT rejected the controlled code page");
    }
}
