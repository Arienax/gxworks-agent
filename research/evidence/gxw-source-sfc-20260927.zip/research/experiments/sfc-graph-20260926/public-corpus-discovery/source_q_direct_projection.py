"""Direct Q source projection without reading CGTable.dat or native libraries."""
from gxw.lossless import inspect_project, sha256
from gxw.project_metadata import read_project_text_context
from probe_gxw_task_graph import inspect_task_graph
from probe_gxw_simple_fb import frame_source, observe_calls
from source_q_allocation import groups
from source_q_call_connections import source_connections
from source_q_direct_declarations import DirectDeclarations
from source_q_label_binding import scalar
from source_q_width import rewrite


def project_projection(source, *, allow_scpi=False, resource_limit=None):
    streams = {s.logical_name: s.raw for s in inspect_project(source).streams
               if s.logical_name and s.logical_name != 'CGTable.dat'}
    context = read_project_text_context(next(v for k, v in streams.items() if k.endswith('.prj')))
    if context['cpu'] != 'Q03UDV':
        raise ValueError('outside Q03UDV direct projection')
    encoding = context['text_encoding']; graph = inspect_task_graph(source)
    if graph['gaps']:
        raise ValueError('task graph gaps')
    declarations = DirectDeclarations(streams, encoding, allow_scpi=allow_scpi); results = []
    resources = sorted(graph['resources'], key=lambda r: r['resource'].encode(encoding))
    if resource_limit is not None:
        if not isinstance(resource_limit, int) or resource_limit <= 0:
            raise ValueError('resource limit must select a positive prefix')
        resources = resources[:resource_limit]
    for index, resource in enumerate(resources):
        entries = graph['tasks'][resource['task']]['entries']
        if len(entries) != 1:
            raise ValueError('multiple task programs not handled')
        entry = entries[0]; root = entry['program_reference']
        frame = frame_source(streams[entry['source_program']])
        observed = observe_calls(frame)
        if observed['gaps'] or observed['calls'] and not allow_scpi:
            raise ValueError('FB calls outside direct source profile')
        declarations.add_owner(root)
        parts = []; bindings = []
        def emit(raw, owner, aliases=None, placeholder=False):
          for tokens in groups(raw):
            record = len(parts)
            changed = []; count = 0
            for token in tokens:
                if token[1] != 0xdf:
                    changed.append(token); continue
                label = token[2:-1]
                if placeholder:
                    if not label.startswith(b'_'):
                        raise ValueError('caller label lacks placeholder')
                    label = label[1:]
                key = label.decode(encoding).casefold()
                if aliases and key in aliases:
                    replacement = aliases[key]
                elif placeholder and key == 'true':
                    replacement = scalar('SM', 400)
                else:
                    replacement = declarations.bind(owner, label)
                changed.append(replacement); count += 1
                bindings.append(dict(record=record, label_hex=token[2:-1].hex(), operand=replacement.hex()))
            raw = b''.join(changed); parts.append(rewrite(raw) if count else raw)
        cursor = frame.body_offset
        for call in observed['calls']:
            if call['definition'] != 'SCPI' or call['gaps']:
                raise ValueError('outside observed SCPI direct-call profile')
            declarations.validate_scpi_signature(call)
            emit(frame.raw[cursor:call['offset']], root)
            aliases, materialized = source_connections(frame, call)
            owner, aliases = declarations.begin_scpi_call(root, call['instance'], aliases, [m['port'] for m in materialized])
            for item in materialized:
                if item.get('phase') == 'output':
                    continue
                for g in item['groups']:
                    emit(b''.join(g), owner, aliases, placeholder=True)
            body = frame_source(streams[call['definition']+'.Program.pou'])
            nested = observe_calls(body)
            if nested['calls'] or nested['gaps']:
                raise ValueError('nested callable projection not modeled')
            emit(body.body, owner, aliases)
            for item in materialized:
                if item.get('phase') == 'output':
                    for g in item['groups']:
                        emit(b''.join(g), owner, aliases, placeholder=True)
            cursor = call['offset']+call['length']
        emit(frame.raw[cursor:frame.body_end], root)
        output = b''.join(parts)
        allocations = list(declarations.allocations)
        results.append(dict(resource_index=index, resource=resource['resource'], program=root,
            output=output, sha256=sha256(output), records=len(parts), bindings=bindings,
            allocations=allocations, assignments={a['identity']: a['raw'] for a in allocations}))
    return results
