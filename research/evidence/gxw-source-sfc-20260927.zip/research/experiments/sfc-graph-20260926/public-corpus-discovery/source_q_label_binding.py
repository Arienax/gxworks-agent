"""Source label projection using predicted allocations and source declarations."""
import re
from gxw.declarations import parse_declarations
from probe_gxw_operand_bindings import observed_q_address

def scalar(family,number):
    codes={'SM':0x91,'M':0x90,'D':0xa8,'T':0xc2,'C':0xc5,'X':0x9c,'Y':0x9d,'W':0xb4,'B':0xa0}
    n=max(1,(number.bit_length()+7)//8)
    if family not in codes or number<0 or n>3:raise ValueError('unrecovered scalar operand encoding')
    return bytes([n+3,codes[family]])+number.to_bytes(n,'little')+bytes([n+3])

def integer16(value):
    if not -32768<=value<=32767:raise ValueError('INT constant out of range')
    size=1 if 0<=value<=255 else 2
    return bytes([size+3,0xe8])+value.to_bytes(size,'little',signed=value<0)+bytes([size+3])

def binder(streams,tables,allocations,root,encoding):
    assigned={a['component_offset']:a for a in allocations}
    declarations=[]
    for name,raw in streams.items():
        if not name.endswith('.Labels.lh'):continue
        doc=parse_declarations(raw,logical_name=name)
        if doc.scope=='local' and doc.owner_name.encode(encoding)==root:declarations.extend(doc.rows)
    def bind(label):
        text=label.decode(encoding)
        match=re.fullmatch(r'([^\[\]]+)(?:\[(-?[0-9]+(?:\s*,\s*-?[0-9]+)*)\])?',text)
        if not match:raise ValueError('label outside literal-index grammar: '+text)
        key=match[1].casefold();hits=[]
        for r in tables.tables[1].records:
            pou=tables.pou_at(r.table_offset)
            if pou.name_bytes not in (root,b'@GLOBALS'):continue
            for c in tables.components(pou):
                if c.name_bytes.decode(encoding).casefold()!=key:continue
                if c.scope_code==14:
                    declared=[d for d in declarations if d.name.casefold()==key]
                    if len(declared)!=1 or declared[0].class_code!=2 or declared[0].data_type!='INT':raise ValueError('unrecovered source constant declaration')
                    value=declared[0].initial_value
                    if match[2] is not None or not re.fullmatch(r'[+-]?[0-9]+',value):raise ValueError('unrecovered source constant expression')
                    hits.append(integer16(int(value)));continue
                relative=0
                if c.record.table_offset in assigned:
                    a=assigned[c.record.table_offset];family=a['family'];number=a['number']
                    if match[2] is not None:
                        array=tables.array_at(tables.component_array_offset(c));indices=[int(v) for v in match[2].split(',')]
                        if len(indices)!=len(array.dimensions):raise ValueError('array index rank')
                        for value,dimension in zip(indices,array.dimensions):
                            ix=value-dimension.lower
                            if not 0<=ix<dimension.extent:raise ValueError('array index bound')
                            relative=relative*dimension.extent+ix
                        if a['count']%array.total_count:raise ValueError('array element allocation is fractional')
                        relative*=a['count']//array.total_count
                else:
                    off=tables.component_address_offset(c)
                    if off<0:raise ValueError('label has neither declaration address nor predicted allocation: '+text)
                    a=observed_q_address(tables.address_at(off).iec_address_bytes)
                    if a['handling']=='opaque' or a.get('addressing') or match[2] is not None:raise ValueError('unrecovered declared-address form')
                    family=a['family'];number=a['number']
                hits.append(scalar(family,number+relative))
        if not hits or len(set(hits))!=1:raise ValueError('unresolved or ambiguous label: '+text)
        return hits[0]
    return bind
