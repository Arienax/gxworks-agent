"""Q71 width discovery model, from CodeGenerator2 15.50 function boundaries.

Not an instruction validator. The caller must bind and validate source separately.
No saved widths, trace outputs, native execution, or per-input output lookup used.
"""
import json
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[4]
sys.path.insert(0,str(ROOT/'src'))
from gxw.token_q import q_instruction_header

TABLES = json.loads(Path(__file__).with_name('q-width-static-tables.json').read_text(encoding='utf-8'))
APP = {(r['family'],r['variant']):r for r in TABLES['application']}
GROUP = {(r['family'],r['variant']):r['mask'] for r in TABLES['groups']}
FLAGS = bytes.fromhex(TABLES['operand_flags'])
QFLAGS = bytes.fromhex(TABLES['q71_operand_flags'])
DEVICE_CLASSES = bytes.fromhex(TABLES['device_classes'])
BASIC_WIDTHS = bytes.fromhex(TABLES['basic_device_widths'])

class Unsupported(ValueError):
    pass

def u32(d,off=9):
    return int.from_bytes(d[off:off+4],'little')

def tokens(raw):
    out=[]
    at=0
    while at<len(raw):
        n=raw[at]
        if n<3 or at+n>len(raw) or raw[at+n-1]!=n:
            raise Unsupported('malformed token framing')
        out.append(raw[at:at+n])
        at+=n
    return out

def operand(raw):
    """5129f before 515f9. Extended-device mapping intentionally unsupported."""
    ts=tokens(raw)
    d=bytearray([255]*18);d[1]=d[17]=0
    cost=0
    for i,t in enumerate(ts):
        code=t[1]
        v=int.from_bytes(t[2:6] if len(t)>6 else t[2:-1],'little')
        if i<len(ts)-1:
            if code in (0xf0,0xf4):
                d[4]=v&255
                if d[3]==255 and ts[i+1][1] not in (0xe9,0xeb):cost+=1
            elif code==0xf1:
                d[3]=v&255
                if d[4]==255:cost+=1
            elif code==0xf2:d[5]=v&255
            elif code==0xf3:d[0]=code
            elif code in (0xf8,0xf9,0xfc,0xff):
                d[1]=code;d[13:17]=v.to_bytes(4,'little')
                if d[4]!=255:d[2]=d[4];d[4]=255
                # 513bf is reached from both branches, including index transfer.
                cost+=1
            else:raise Unsupported(f'modifier {code:02x}')
            continue
        if not 0x90<=code<0xf0 or code in (0xdf,0xad):raise Unsupported(f'base {code:02x}')
        if (d[1]==0xf8 and code!=0xab) or (d[1]==0xf9 and code not in (0x9c,0x9d,0xa0,0xa1,0xa2,0xa3,0xb4,0xb5)) or (d[1]==0xfc and code not in (0x98,0x99)):
            raise Unsupported('incompatible prefix')
        d[6]=code;d[9:13]=v.to_bytes(4,'little')
        if d[1]==0xf9:cost+=1
        elif code==0xee:cost+=1 if len(t)==4 and t[2]==0 else (len(t)-2)//2+1
        else:cost+=(len(t)-2)//2
        if d[1]:
            if d[1]==0xf9 and code==0xb4 and v+0x1220>65535 and d[4]==255:cost+=1
            special=(d[1]==0xf8 and 0x3e0<=u32(d,13)<=0x3e3 and code==0xab and v>=10000 and d[2]==255)
            if special:
                if d[4]!=255:cost-=1
            elif d[0]!=255:cost+=1
        if d[3] in (4,8) and d[4]==255 and v%16==0:cost-=1
        if code==0xb0 and d[4]!=255 and v>65535:cost-=1
    return bytes(d),cost

def validate_descriptor(d):
    """515f9 CPU class 60 / internal CPU71 modifier capability and type flags."""
    d=bytearray(d)
    i=(d[6]-0x90)*3
    cap=FLAGS[i];flags=int.from_bytes(FLAGS[i+1:i+3],'little')
    if d[0]!=255 and not cap&32:raise Unsupported('indirect not permitted')
    if d[5]!=255:
        if not cap&1:raise Unsupported('bit selector not permitted')
        flags=1
    if d[3]!=255:
        if not flags&1 or not cap&16:raise Unsupported('group not permitted')
        if d[3]<=4:flags=2
        elif d[3]<=8:flags=4
        else:raise Unsupported('group count')
    if d[4]!=255 and (d[5]!=255 or not QFLAGS[i]&2):raise Unsupported('index not permitted')
    if d[1] and (not cap&8 or (d[2]!=255 and not QFLAGS[(d[1]-0x90)*3]&4)):raise Unsupported('prefix not permitted')
    if d[0]==255 and d[1]==0 and d[3]==255 and d[5]==255:
        flags|=64
        if d[4]==255:flags|=128
    d[7:9]=flags.to_bytes(2,'little')
    return bytes(d)

def expected_group(f,v,i):
    return (GROUP.get((f,v),0) >> ((7-i)*2))&3 if i<8 else 0

def group_ok(f,v,i,d):
    if d[3]==255:return True
    if d[4]!=255 or d[3] not in (4,8) or u32(d)%16:return False
    expected=expected_group(f,v,i)
    return expected<=1 if d[3]==4 else expected==2

def group_extra(f,v,i,d):
    return int(d[3] in (4,8) and d[4]==255 and u32(d)%16==0 and not group_ok(f,v,i,d))

def compact(f,v,i,d):
    return (group_ok(f,v,i,d) and d[4]==255 and d[6] not in (0xe9,0xeb)
        and not (d[6]==0xb0 and u32(d)>65535)
        and not (d[1]==0xf8 and 0x3e0<=u32(d,13)<=0x3e3 and d[6]==0xab and u32(d)>=10000))

def operand_rule_status(f,v,i,d):
    """5190a CPU class60/internal71 stage only; zero does not prove instruction validity.

    Negative values preserve the native distinctions (including literal width
    promotion requests -4 / -5). i is zero-based.
    """
    dev=d[6];flags=int.from_bytes(d[7:9],'little')
    if dev in (0xad,0xe7):return 0
    if f==0x3c:return 0 if dev in (0xd0,0xd1,0xdf) else -1
    for row in TABLES['operand_rules']:
        if row['family']!=f or (f>=0x40 and row['variant']!=v):continue
        if row['offset']==0x7fff:return -3
        if i>=len(row['parameters']):return -2
        rule=row['parameters'][i];mask=rule['mask'];bitmap=int.from_bytes(bytes.fromhex(rule['devices']),'little')
        def allowed(code):return bool(bitmap & (1<<(code-0x90)))
        if dev==0xdf and bitmap & ~(1<<(0xad-0x90)):return 0
        if mask==1 and d[0]!=255 and dev in (0xc2,0xc5,0xc8):return -1
        if mask==2 and dev in (0xe9,0xeb) and allowed(dev-1):return -5
        if not (mask&flags or (dev in (0x98,0x99,0xdc) and mask&0x80)):
            if f in (0x20,0x23,0x24):continue
            return -1
        if f==0x65 and rule['class_id'] in (0x46,0x4d,0x4f) and dev not in (0xc2,0xc5,0xc8) and flags&1 and d[3]==255:return -1
        if mask&0xc0 and not mask&0x8000 and (d[5]!=255 or d[3]!=255):return -1
        if mask&0x80 and not mask&0x8000 and d[4]!=255 and dev not in (0x98,0xdc):return -1
        if mask!=0xffff:
            if mask&4 and dev in (0xe8,0xea):return -4
            if mask==0x1e and dev in (0xec,0xed):return -1
            if mask==0x16:
                if dev in (0xe3,0xe4):return -4
                if dev==0xcc:return 0
        effective=d[1] or dev
        if mask in (0x16,0x2e,0x1e) and effective==0xf9 and dev in (0x9c,0x9d,0xa0,0xa1):return -1
        if allowed(effective):return 0
        if dev in (0x98,0x99,0xdc) and mask==1 and dev!=0x99 and f<0x40:continue
        return -1
    return -1

def application(f,v,ds,cost):
    """6e7b7 optimized path. -1 selects the caller's fallback, not unsupported."""
    row=APP.get((f,v))
    if row is None:return -1
    if f in (0x50,0x51) and not group_ok(f,v,0,ds[0]):return -1
    for d in ds:
        if d[6] in (0xa2,0xa3) or d[1] in (0xf9,0xfc):return -1
        if d[1]==0xf8 and (not 0x3e0<=u32(d,13)<=0x3e3 or (d[6]==0xab and (u32(d)<10000 or d[2]!=255))):return -1
        if d[6]==0x98 and (f,v)!=(0x42,1):return -1
        if d[6]==0xdc and (f,v)!=(0x6c,2):return -1
    base,source,dest,indirect=row['values'];kind=row['kind']
    if kind==4 and ds[0]==ds[2]:kind=5
    if ds and all(d[6]==0xcc for d in ds):
        return 2 if kind==5 else (1 if kind<=9 else (base+1 if kind<=12 or kind==15 else (3 if kind==13 else 1)))
    cost+=2*sum(d[0]!=255 for d in ds)
    g=[group_ok(f,v,i,d) for i,d in enumerate(ds)]
    z=[d[6]==0xcc for d in ds]
    ind=[d[0]!=255 for d in ds]
    def src(i):return source if not g[i] and ds[i][3]<=4 else 0
    def dst(i):return dest if not g[i] else (indirect if ind[i] else 0)
    if kind==1:
        cost+=src(0)+src(1)
        return cost if any(z) else base+cost
    if kind==2:
        cost+=src(0)+src(1)+dst(1)
        if not compact(f,v,1,ds[1]) and not ind[1]:cost+=1
        return cost if z[1] or (z[0] and (not g[1] or ind[1])) else base+cost
    if kind in (3,4):
        cost+=src(0)+src(1)+dst(2)
        if z[0] and z[1]:
            if not g[2] or ind[2]:return cost-2
            return cost-1
        if z[0] or z[1]:
            if not g[2] or ind[2] or z[2]:return cost-1
        return base+cost
    if kind==5:
        if ind[2]:
            cost-=1
            if not compact(f,v,2,ds[2]):cost-=1
        cost+=1
        if all(ind):return cost
        cost+=src(0)+src(1)+(dest if not g[2] else 0)
        if (not g[0] or ind[0]) and z[1]:return cost-1
        if z[0] and not z[1]:return cost-1
        return base+cost
    if kind in (6,8):
        cost+=src(0)+dst(0)
        if not compact(f,v,0,ds[0]) and not ind[0]:cost+=1
        return base+cost
    if kind==7:
        cost+=src(0)+dst(1)
        return cost-1 if z[0] and (not g[1] or ind[1]) else base+cost
    if kind==9:
        if z[0]:
            if not g[1]:return cost
            if ind[1]:return cost-1
        return base+cost+src(0)
    if kind==10:
        if z[0] and (not g[1] or ind[1]):return cost
        return base+cost+src(0)+dst(1)
    if kind in (11,12):
        cost+=base+(indirect if ind[0] else 0)
        return cost-1 if (not g[0] or ind[0]) and z[1] else cost
    if kind==13:
        if not g[0]:cost+=dest
        elif ind[0]:cost+=indirect
        elif z[0]:cost+=1
        if (not g[0] or ind[0]) and z[1]:return cost
        if not compact(f,v,0,ds[0]) and not ind[0] and g[0]:cost+=1
        return base+cost
    if kind==14:return base+cost+src(0)-int(z[0])-int(z[1])
    if kind==15:return base+cost
    raise Unsupported(f'optimized kind {kind}')

def basic(f,ds,cost):
    """52ef9 internal CPU71 branches; cost includes 52e73 extension words."""
    original=f
    if f in (0x29,0x2b):f-=1
    if not ds:return 2 if f==0x34 else 1
    kind=TABLES['basic'][f]['kind']
    d=ds[0]
    def matrix(d):
        c=DEVICE_CLASSES[d[6]*2]
        if c>=23:raise Unsupported(f'device class {c}')
        return BASIC_WIDTHS[kind*23+c]
    def special(d):
        return d[1]==0xf8 and 0x3e0<=u32(d,13)<=0x3e3 and d[6]==0xab and u32(d)>=10000 and d[2]==255
    def plain(d):return d[0]==255 and d[1]==0
    def small(i):return compact(f,0,i,ds[i])
    if kind in (1,10):return 1 if small(0) else 2
    if kind==11:return 1
    if kind==2:
        if plain(d):
            width=matrix(d)
            if width:return width+int(not small(0))
        elif special(d):return 2
        return cost+1
    if kind in (3,5):
        if plain(d):
            width=matrix(d)
            if width and not (f==0x23 and d[6]==0x93):
                if f==0x23:width=1
                return width+int(not small(0))
        elif special(d):return 3 if f in (0x25,0x26,0x27) else 2
        return cost+1+int((f==0x23 and d[6]==0x93) or f in (0x25,0x26,0x27))
    if kind==4:
        d2=ds[1]
        if any(o[0]!=255 for o in ds):raise Unsupported('indirect timer/counter')
        if d2[1]==0:
            width=matrix(d2)
            if width:return width+3*int(not small(0))+int(not small(1))
        elif special(d2):return 5+3*int(not small(0))
        return cost+3+2*int(not small(0))
    if kind==6:
        if plain(d):
            width=matrix(d)
            if width:
                if not d[7]&1 and d[6]!=0xcc:width=2
                if not small(0):width+=3 if 0xc0<=d[6]<=0xc8 else 1
                return width
        elif d[1]==0:return 3+int(not small(0))
        elif special(d):return 2 if d[7]&1 else 3+int(d[0]!=255)
        return cost+1+int(d[6]==0x93)
    if kind==9:
        d2=ds[1]
        if plain(d2):
            width=matrix(d2)
            if width:return width+int(not small(1))
        elif special(d2):return 3
        return cost+1
    if kind in (7,8):
        if f in (0x28,0x2a):return cost+1+int(original in (0x29,0x2b))
        if plain(d) and d[7]&1:
            width=matrix(d)
            if width:return width+int(not small(0))
        elif special(d):return 3
        return cost+2+(2 if f in (4,5) else (3 if f in (0xa,0xb,0x15,0x16) else 0))
    return cost+(1 if kind==12 else 2)

def decode_operands(raw):
    ts=tokens(raw);header=ts.pop(0);groups=[];pending=[]
    for t in ts:
        pending.append(t)
        if t[1]<0xf0:
            groups.append(b''.join(pending));pending=[]
    if pending:raise Unsupported('unfinished modifier group')
    return header,groups

def operand_checks(raw):
    """Recovered arity, Z span, modifier, operand-type and basic OUT checks.

    Zero covers these stages only; it is not a complete CPU/project/device
    validator. Unknown context-dependent forms raise Unsupported.
    """
    if raw==bytes([2,2]):return 0
    h,gs=decode_operands(raw)
    f=h[1];v=h[3] if len(h)>=5 else 0
    _,lexical_arity=q_instruction_header(h)
    n=TABLES['dispatch_arity'].get(f'{f:02x}:{v:02x}',lexical_arity)
    if not 0<=n<=10 or len(gs)!=n:return -1
    ds=[]
    for g in gs:
        d,_=operand(g)
        try:d=validate_descriptor(d)
        except Unsupported:return -1
        ds.append(d)
    # 522e5 precheck reserves enough consecutive Z registers for wide operands.
    limit=next((r for r in TABLES['z_limits'] if r['family']==f and (f<0x40 or r['variant']==v)),None)
    if limit:
        for i,d in enumerate(ds):
            words=limit['words'][i]
            if d[6]==0xcc and words!=255 and u32(d)>20-words:return -1
    normalized=f-1 if f in (0x29,0x2b) else f
    if f<0x70:
        for i,d in enumerate(ds):
            status=operand_rule_status(normalized,v,i,d)
            if status<0:return status
    else:raise Unsupported('named-instruction validation not yet recovered')
    if f<0x40 and TABLES['basic'][normalized]['kind']==4:
        # 52ef9 stores the first token's signed value before consuming modifiers;
        # 53403 checks it only if the terminal token is E8/E9.
        first=tokens(gs[-1])[0]
        if len(first)==4:value=first[2]
        elif len(first)==5:value=int.from_bytes(first[2:4],'little',signed=True)
        else:value=(first[4]<<12)+int.from_bytes(first[2:4],'little',signed=True)
        if ds[-1][6] in (0xe8,0xe9) and value<0:return -1
        if ds[1][1] and 0x90<=ds[1][6]<0xa8:return -1
        if any(d[0]!=255 for d in ds):return -1
    return 0

def rewrite(raw):
    """Compute stored width for already valid, fully bound Q71 source instruction.

    Context: no extended-device mappings; same version-independent lexical
    catalog as the source binder. Not suitable for arbitrary saved instructions.
    """
    if raw==bytes([2,2]):return raw
    header,groups=decode_operands(raw)
    _,arity=q_instruction_header(header)
    f=header[1];v=header[3] if len(header)>=5 else 0
    arity=TABLES['dispatch_arity'].get(f'{f:02x}:{v:02x}',arity)
    if len(groups)!=arity:raise Unsupported(f'arity {len(groups)} != {arity}')
    ds=[];cost=0
    for rawgroup in groups:
        d,c=operand(rawgroup);ds.append(validate_descriptor(d));cost+=c
    extra=sum(t[1] in (0xe9,0xeb) and len(t) in (4,5) for t in tokens(raw)[1:])
    pulse=len(header)>=6 and header[4]==2
    if f<0x40:
        width=basic(f,ds,cost+extra)
        out=bytes([3,f,3]) if width==1 else bytes([4,f,width,4])
    elif f<0x70:
        if f==0x41:raise Unsupported('special application dispatcher')
        if f in (0x42,0x62,0x6c):
            width=bytes.fromhex(TABLES['special_widths'][f'{f:02x}'])[v*3]
            if width==255:raise Unsupported('unavailable special application')
            if not width and f!=0x42:width=1
            width+=sum(not compact(f,v,i,d) for i,d in enumerate(ds[:2]))
        elif (f,v)==(0x4c,0):
            optimized=application(f,v,ds,cost+extra)
            width=(optimized if optimized>0 else cost+extra+1)+pulse
        else:
            cost+=sum(group_extra(f,v,i,d) for i,d in enumerate(ds))
            optimized=application(f,v,ds,cost)
            if optimized>=0:width=optimized+extra+pulse
            else:
                base=2 if (f,v) in ((0x45,1),(0x47,2),(0x67,0)) else 1
                width=base+cost+extra
                if pulse:width+=1
                elif f==0x63:
                    width+=int(v<=3 or 5<=v<=9)
                elif f==0x54:width+=int(0x1a<=v<=0x1f)
                elif (f,v) in ((0x57,4),(0x61,1),(0x58,0xa),(0x4d,1),(0x53,0x11),(0x53,0x12),(0x65,1),(0x65,2)):
                    width+=1
                if (f,v)==(0x6a,0):width+=1
        out=header[:2]+bytes([width])+header[3:]
    elif f in (0x72,0x73,0x74):
        if f in (0x72,0x73) and ds[0][6]!=(0xd8 if f==0x72 else 0xd9):raise Unsupported('unresolved callable target')
        if any(d[6] in (0xe8,0xea,0xd2) for d in ds):raise Unsupported('invalid callable value')
        width=(len(header)-5)//2+2+cost+extra+pulse
        out=header[:2]+bytes([width])+header[3:]
    else:raise Unsupported(f'family {f:02x}')
    return out+raw[len(header):]
