"""Experimental direct-program source declarations; no compiler-cache access.

The direct profile excludes general FB instances, latch pools and overlapping
explicitly addressed variables; an optional SCPI call profile is bounded separately.
Resource and global-document ordering are hypotheses checked
against native output, not general locale collation or project-validity rules.
"""
import math
import re
import struct
from gxw.declarations import parse_declarations, _type_parts
from probe_gxw_parameters import project_allocation_ranges
from probe_gxw_operand_bindings import observed_q_address
from source_q_label_binding import scalar, integer16


def source_layout(row):
    base, bounds = _type_parts(row.data_type)
    sizes = {'BOOL': ('M', 1), 'INT': ('D', 1), 'WORD': ('D', 1),
             'DINT': ('D', 2), 'DWORD': ('D', 2), 'REAL': ('D', 2),
             'TIMER': ('T', 1), 'COUNTER': ('C', 1)}
    if base == 'STRING':
        if bounds:
            raise ValueError('STRING array outside native-accepted simple-label profile')
        sized = re.search(r'STRING\s*\[\s*([0-9]+)\s*\]\s*$', row.data_type)
        if not sized:
            raise ValueError('default STRING length not modeled')
        sizes['STRING'] = ('D', (int(sized[1])+2)//2)
    if base not in sizes:
        raise ValueError('unrecovered direct declaration type: ' + row.data_type)
    family, stride = sizes[base]
    dimensions = [dict(lower=lo, upper=hi, extent=hi-lo+1) for lo, hi in bounds]
    count = math.prod(d['extent'] for d in dimensions)
    return dict(family=family, stride=stride, dimensions=dimensions,
                elements=count, count=count*stride, data_type=row.data_type)


class DirectDeclarations:
    def __init__(self, streams, encoding, *, allow_scpi=False):
        # Explicitly disallow cache input to this experimental path.
        if 'CGTable.dat' in streams:
            raise ValueError('compiler cache must be excluded from declaration input')
        self.encoding = encoding; self.allow_scpi = allow_scpi
        metadata = next(v for k, v in streams.items() if k.endswith('.prj'))
        self.ranges = {r['name']: r for r in project_allocation_ranges(metadata)['ranges']}
        for family in ('R', 'ZR'):
            if self.ranges[family]['handling'] == 'range':
                raise ValueError('unrecovered alternate word pool order')
        self.documents = {}
        for name, raw in streams.items():
            if not (name.endswith('.Labels.lh') or name.endswith('.gh')):
                continue
            doc = parse_declarations(raw, logical_name=name)
            owner = doc.owner_name if doc.scope == 'local' else '@GLOBALS'
            self.documents.setdefault(owner, []).append(doc)
        self.bound = {}; self.maps = {}; self.allocations = []; self.active = set()
        self.add_owner('@GLOBALS')

    def add_owner(self, owner, *, definition=None):
        if owner in self.active:
            raise ValueError('repeated program allocation')
        self.active.add(owner)
        self.bound[owner] = {}
        for doc in sorted(self.documents.get(definition or owner, []), key=lambda d: d.logical_name.encode(self.encoding)):
            if len({r.record_id for r in doc.rows}) != len(doc.rows):
                raise ValueError('duplicate declaration record IDs')
            for row in sorted(doc.rows, key=lambda r: r.record_id):
                key = row.name.casefold()
                if key in self.bound[owner]:
                    raise ValueError('ambiguous declaration name')
                item = dict(row=row)
                self.bound[owner][key] = item
                if row.type_code == 15 and row.data_type == 'SCPI' and self.allow_scpi:
                    if row.class_code != 1 or owner == '@GLOBALS' or definition is not None:
                        raise ValueError('outside local direct SCPI instance profile')
                    item['instance'] = owner+'.'+row.name
                    self.add_owner(item['instance'], definition='SCPI')
                    continue
                if definition is not None and row.class_code in (3, 4):
                    item.update(source_layout(row), port=True)
                    continue
                if row.class_code in (2, 9):
                    if row.data_type != 'INT' or not re.fullmatch(r'[+-]?[0-9]+', row.initial_value):
                        raise ValueError('unrecovered constant expression')
                    item['constant'] = integer16(int(row.initial_value))
                    continue
                expected_class = 8 if owner == '@GLOBALS' else 1
                if row.class_code != expected_class:
                    raise ValueError('unrecovered source declaration class')
                layout = source_layout(row); item.update(layout)
                if row.iec_address:
                    address = observed_q_address(row.iec_address.encode(self.encoding))
                    if address['handling'] == 'opaque' or address.get('addressing') or layout['dimensions']:
                        raise ValueError('unrecovered explicit address form')
                    family = address['family']; number = address['number']
                    if family in self.ranges:
                        pool = self.ranges[family]
                        if pool['handling'] == 'range' and pool['lower'] <= number <= pool['upper']:
                            raise ValueError('explicit address overlaps system pool')
                    item.update(family=family, number=number)
                    continue
                if row.device:
                    raise ValueError('device has no IEC declaration')
                self.allocate_item(owner, item)

    def allocate_item(self, owner, item):
        row = item['row']; layout = source_layout(row)
        family, number, raw = self.allocate(layout['family'], layout['count'])
        item.update(family=family, number=number)
        identity = owner.encode(self.encoding).hex()+':'+row.name.encode(self.encoding).hex()
        self.allocations.append(dict(identity=identity, owner=owner, name=row.name,
            **layout, allocated_family=family, number=number, raw=raw.hex()))

    def begin_scpi_call(self, parent, instance, aliases, materialized_ports=()):
        item = self.bound[parent].get(instance.casefold())
        if not item or 'instance' not in item:
            raise ValueError('source instance declaration missing')
        owner = item['instance']; aliases = dict(aliases)
        materialized_ports = {p.casefold() for p in materialized_ports}
        for key, item in sorted(self.bound[owner].items(), key=lambda pair: (pair[1]['row'].class_code, pair[1]['row'].record_id)):
            if not item.get('port') or key in aliases:
                continue
            row = item['row']
            if row.class_code == 3 and row.data_type == 'BOOL' and key not in materialized_ports:
                aliases[key] = scalar('SM', 400)
            elif 'number' not in item:
                self.allocate_item(owner, item)
        return owner, aliases

    def validate_scpi_signature(self, call):
        documents = self.documents.get(call['definition'], [])
        if len(documents) != 1:
            raise ValueError('callable declaration is not unique')
        markers = {'BOOL': 'B', 'INT': 'W', 'WORD': 'W', 'DINT': 'D',
                   'DWORD': 'D', 'REAL': 'D', 'STRING': 'S'}
        for direction, scope in [('input', 3), ('output', 4)]:
            declared = []
            for row in sorted(documents[0].rows, key=lambda r: r.record_id):
                if row.class_code != scope:
                    continue
                base, bounds = _type_parts(row.data_type)
                if bounds or base not in markers:
                    raise ValueError('callable port type is outside observed markers')
                declared.append((row.name.casefold(), markers[base]))
            saved = [(p['name'].casefold(), p['type_marker']) for p in call['ports'] if p['direction'] == direction]
            if saved != declared:
                raise ValueError('source callable signature differs from saved call markers')

    def allocate(self, family, count):
        candidates = {'D': [('D', 0x24, 5), ('W', 0x24, 6)],
                      'M': [('M', 0x21, 0), ('B', 0x21, 3)],
                      'T': [('T', 5, 11)], 'C': [('C', 10, 14)]}[family]
        for family, tag, code in candidates:
            pool = self.ranges[family]
            if pool['handling'] == 'unset':
                continue
            if pool['handling'] != 'range':
                raise ValueError('unavailable allocation pool')
            used = self.maps.setdefault(family, bytearray(pool['upper']-pool['lower']+1))
            run = 0
            for end, value in enumerate(used):
                run = 0 if value else run+1
                if run != count:
                    continue
                start = end-count+1
                used[start:start+count] = b'\1'*count
                number = pool['upper']-start-count+1
                raw = bytearray(26); raw[0] = tag; raw[1] = code
                raw[2:5] = number.to_bytes(3, 'little', signed=True)
                struct.pack_into('<I', raw, 6, count)
                return family, number, bytes(raw)
        raise ValueError('system pool exhausted')

    def bind(self, owner, label):
        text = label.decode(self.encoding)
        match = re.fullmatch(r'([^\[\]]+)(?:\[(-?[0-9]+(?:\s*,\s*-?[0-9]+)*)\])?', text)
        if not match:
            raise ValueError('label outside literal-index grammar: '+text)
        key = match[1].casefold()
        hits = [self.bound[o][key] for o in (owner, '@GLOBALS') if key in self.bound[o]]
        if len(hits) != 1:
            raise ValueError('unresolved or ambiguous source label: '+text)
        item = hits[0]
        if 'constant' in item:
            if match[2] is not None:
                raise ValueError('indexed constant')
            return item['constant']
        relative = 0
        if match[2] is not None:
            indices = [int(i) for i in match[2].split(',')]
            if len(indices) != len(item['dimensions']):
                raise ValueError('array index rank')
            for index, d in zip(indices, item['dimensions']):
                value = index-d['lower']
                if not 0 <= value < d['extent']:
                    raise ValueError('array index bound')
                relative = relative*d['extent']+value
        return scalar(item['family'], item['number']+relative*item['stride'])
