"""Observed Q03UDV token spellings, separate from the FX binary grammar.

Descriptor lookup and independent native text conversion establish names and
lexical operand boundaries. They do not establish executable instructions,
device ranges, stored-width correctness or permission to write a project.
The hash-bound descriptor facts ship with the other native GXW templates.
"""
from __future__ import annotations

from functools import lru_cache
import json
from pathlib import Path

from .models import GXWFormatError
from .token_pou import LadderToken


@lru_cache(maxsize=1)
def _catalog() -> dict:
    return json.loads((Path(__file__).with_name("templates") /
                       "q03udv-token-grammar.json").read_text(encoding="utf-8"))


def q_instruction_header(raw: bytes) -> tuple[str, int]:
    """Read a bounded header without inferring an application opcode formula."""
    if raw == b"\x02\x02":
        return "NOP", 0
    if len(raw) < 3 or raw[0] != len(raw) or raw[-1] != len(raw):
        raise GXWFormatError("unsupported Q instruction header")
    family = raw[1]
    variant = raw[3] if len(raw) >= 5 else 0
    modifier = raw[4] if len(raw) >= 6 else 0xff
    if family in (0x3c, 0x3f) or family >= 0x80:
        raise GXWFormatError("not an observed Q instruction header")
    if f"{family:02x}" in _catalog()["version_dependent_families"]:
        raise GXWFormatError("Q instruction requires explicit native version context")
    descriptor = _catalog()["headers"].get(f"{family:02x}:{variant:02x}")
    if descriptor is None:
        raise GXWFormatError("unknown Q instruction family/variant")
    name, arity = descriptor
    named = len(name) > 1 and name[1] == "."
    if modifier not in ((0xff, 2, 0x0a) if named else (0xff, 2, 0x10, 0x11, 0x12)):
        raise GXWFormatError("unsupported Q instruction modifier")
    if named:
        suffix = raw[5:-1]
        if not suffix or any(c < 0x21 or c > 0x7e for c in suffix):
            raise GXWFormatError("unsupported Q named-instruction suffix")
        name += suffix.decode("ascii")
    elif len(raw) > 6:
        raise GXWFormatError("unexpected Q instruction header suffix")
    if modifier == 2:
        if named:
            name = name[0] + "P" + name[1:]
        elif family != 0x65 or variant not in (5, 6, 7, 0x22, 0x23, 0x48, 0x49):
            name += "P"
    elif modifier in (0x10, 0x11, 0x12):
        name = {0x10: "LD", 0x11: "AND", 0x12: "OR"}[modifier] + name
    else:
        name = name.removeprefix(",")
    return name, arity


def q_operand_text(raw: bytes, *, text_encoding: str | None) -> str:
    """Render lexical values; unsupported types retain their original tokens."""
    if len(raw) < 3 or raw[0] != len(raw) or raw[-1] != len(raw):
        raise GXWFormatError("unsupported Q operand framing")
    code, value = raw[1], raw[2:-1]
    if code in (0xdf, 0xee):
        if text_encoding is None:
            raise GXWFormatError("Q label/string requires an explicit text encoding")
        # The Q formatter replaces one final NUL with its closing quote.
        # Native empty strings therefore have the payload 00, not no token.
        if code == 0xee and value.endswith(b"\0"):
            value = value[:-1]
        try:
            text = value.decode(text_encoding)
        except (UnicodeError, LookupError) as exc:
            raise GXWFormatError("undecodable Q label/string") from exc
        if "\0" in text:
            raise GXWFormatError("embedded NUL in Q label/string")
        return "'" + text if code == 0xdf else '"' + text + '"'
    descriptor = _catalog()["operands"].get(f"{code:02x}")
    if descriptor is None:
        raise GXWFormatError("unknown Q operand type")
    prefix, kind = descriptor
    if kind == 6 and code == 0xf3:
        return prefix
    if kind not in (0, 1, 4) or not 1 <= len(value) <= 4:
        raise GXWFormatError("unsupported Q operand format/width")
    if code == 0xe8 and len(value) > 2:
        raise GXWFormatError("unsupported Q short-integer width")
    # Shorter encodings are zero-extended, including one-byte E8 FF = K255.
    signed = kind == 1 and len(value) == (2 if code == 0xe8 else 4)
    number = int.from_bytes(value, "little", signed=signed)
    if kind == 4:
        digits = format(number, "X")
        return prefix + ("0" if code != 0xf2 and digits[0] in "ABCDEF" else "") + digits
    return prefix + str(number)


def q_operand_groups(tokens: tuple[LadderToken, ...], *, text_encoding: str | None
                     ) -> tuple[tuple[tuple[LadderToken, ...], str], ...]:
    """Bind modifiers to a base while retaining every token's order/offset."""
    groups, start, prefix, index, bit = [], 0, "", None, None
    for end, token in enumerate(tokens):
        code = token.raw[1]
        text = q_operand_text(token.raw, text_encoding=text_encoding)
        if code in (0xf0, 0xf6):
            if index is not None:
                raise GXWFormatError("duplicate Q index modifier")
            index = text
        elif code == 0xf2:
            if bit is not None:
                raise GXWFormatError("duplicate Q bit selector")
            bit = text
        elif code in (0xf1, 0xf3):
            prefix += text
        elif code in (0xf8, 0xf9, 0xfc):
            prefix += text + "\\"
        elif 0x90 <= code <= 0xef:
            groups.append((tokens[start:end + 1], prefix + text + (index or "") + (bit or "")))
            start, prefix, index, bit = end + 1, "", None, None
        else:
            raise GXWFormatError("unsupported Q operand modifier")
    if start != len(tokens):
        raise GXWFormatError("Q operand modifier lacks a base token")
    return tuple(groups)
