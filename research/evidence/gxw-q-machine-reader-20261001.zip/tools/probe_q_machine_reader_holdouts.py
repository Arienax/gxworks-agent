"""Predict Q reader results on new address/literal/mode boundary controls.

Inputs are machine fragments; predictions precede native reverse. A native
forward re-emission is a separate canonicalization observation, not an oracle
for independent decoding or evidence of project/device acceptance.
"""
from pathlib import Path
from collections import Counter
import base64
import json
import os
import struct
import subprocess

P = Path(__file__).resolve().parent
from source_q_machine_reader import load_profile, read_machine


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=True, indent=2) + '\n', encoding='utf-8')


def parity(word):
    value = word & 0x7FFFFFFF
    return value | ((value.bit_count() & 1) << 31)


def main():
    output = P / 'q-machine-reader-holdouts-20261001-v1'
    output.mkdir()
    previous = P / 'q-machine-original-corpus-20261001-v3'
    for name in ('source_q_machine_reader.py', 'QMachineOracle.cs', Path(__file__).name):
        (output / name).write_bytes((P / name).read_bytes())
    for name in ('static-read-tables.json', 'default-device-context.json'):
        (output / name).write_bytes((previous / name).read_bytes())
    profile = load_profile(output / 'static-read-tables.json', output / 'default-device-context.json')
    requests, seen = [], set()
    def add(family, words, description, odd=False, suffix=b''):
        raw = b''.join(struct.pack('<I', parity(w) ^ (0x80000000 if odd and i == 0 else 0)) for i, w in enumerate(words)) + suffix
        if raw in seen:
            return
        seen.add(raw)
        requests.append(dict(id=len(requests), family=family, description=description, machine_hex=raw.hex(),
                             prediction=read_machine(raw, profile)))
    ranges = []
    for i in range(profile.devices[0]):
        start, kind, device = struct.unpack_from('<HBB', profile.devices, 1 + 4 * i)
        end, = struct.unpack_from('<H', profile.devices, 5 + 4 * i)
        ranges.append(dict(start=start, end=end, kind=kind, device=device))
        points = sorted(set((start, start + 1, end - 1)))
        if kind in (1, 2):
            for address in points:
                for bit in ((0, 1, 7, 15) if kind == 1 else (0, 2, 14)):
                    for opcode in (0x00, 0x08, 0x23, 0x24):
                        add('ordinary-bit', [opcode << 24 | bit << 20 | 3 << 16 | address],
                            dict(address=address, bit=bit, opcode=opcode, device_range=i))
        elif kind == 3:
            for address in points:
                for value in (0, 1, 255, 256, 32767, 32768, 65535):
                    for literal in (0x5D210000, 0x5D240000):
                        add('literal-move', [literal | value, 0x56130000 | address],
                            dict(address=address, value=value, literal_header=literal, device_range=i))
            for address in (start, end - 1):
                for relation in range(6):
                    for operation in range(3, 6):
                        for value in (0, 256, 65535):
                            command = 0x68000000 | operation << 21 | relation << 15 | 0x411
                            add('comparison', [0x55030000 | address, 0x5D000000 | value, command],
                                dict(address=address, value=value, operation=operation, relation=relation, device_range=i))
    add('odd-parity', [0x00030E00], 'LD M0 with a toggled parity bit', odd=True)
    add('odd-parity', [0x5D210100, 0x56132540], 'MOV K256 D0 with a toggled literal parity bit', odd=True)
    for name, words, suffix in (
            ('terminal-control-lookahead', [0x5E110000], b''),
            ('missing-prefix-word', [0x70000000], b''),
            ('extended-word-without-prefix', [0x6C000000], b''),
            ('unsupported-basic-table-entry', [0x02030E00], b''),
            ('partial-final-word', [0x00030E00], b'\x01\x02'),
            ('outside-table-sentinel', [0x0003FFFF], b'')):
        add('opaque-control', words, name, suffix=suffix)
    save(output / 'before-native.json', dict(scope=__doc__, ranges=ranges, requests=requests))
    executable = output / 'QMachineOracle.exe'
    built = subprocess.run([str(Path(os.environ['WINDIR']) / 'Microsoft.NET/Framework/v4.0.30319/csc.exe'), '/nologo',
                            '/platform:x86', '/out:' + str(executable), str(output / 'QMachineOracle.cs')],
                           capture_output=True, timeout=30, creationflags=subprocess.CREATE_NO_WINDOW)
    (output / 'build.txt').write_bytes(built.stdout + built.stderr)
    if built.returncode:
        raise RuntimeError('Owned helper build failed; retained')
    def run(mode, inputs, name):
        directory = output / name
        directory.mkdir()
        result = []
        for start in range(0, len(inputs), 400):
            batch = directory / f'batch-{start // 400:03d}'
            batch.mkdir()
            request = batch / 'requests.tsv'
            request.write_text('\n'.join(str(i)+'\t'+base64.b64encode(data).decode() for i,data in inputs[start:start+400])+'\n', encoding='ascii')
            process = subprocess.run([str(executable), 'D:/GXWORKS2/Easysocket/CodeGenerator/ECCodeGenerator2.dll', mode,
                                      str(request), str(batch / 'output.jsonl')], capture_output=True, timeout=45,
                                     creationflags=subprocess.CREATE_NO_WINDOW)
            (batch / 'stdout.bin').write_bytes(process.stdout)
            (batch / 'stderr.bin').write_bytes(process.stderr)
            save(batch / 'process.json', dict(returncode=process.returncode))
            if process.returncode:
                raise RuntimeError('Owned native conversion failed; retained')
            result.extend(json.loads(l) for l in (batch / 'output.jsonl').read_text(encoding='utf-8-sig').splitlines())
            print(json.dumps(dict(stage=mode, processed=len(result), total=len(inputs))), flush=True)
        return {r['id']:r for r in result}
    reverse = run('reverse', [(r['id'], bytes.fromhex(r['machine_hex'])) for r in requests if len(r['machine_hex']) % 8 == 0], 'reverse')
    reemission = run('forward', [(i, base64.b64decode(r['output_base64'])) for i,r in reverse.items()
                               if r['code']==0 and r['remaining']==0 and r['consumed']==len(requests[i]['machine_hex'])//2], 'reemission')
    comparisons, counts, by_family, failures = [], Counter(), {}, []
    for row in requests:
        prediction = row['prediction']
        decoded = bool(prediction) and all(r['handling']=='decoded' for r in prediction)
        pcode = b''.join(bytes.fromhex(r['pcode_hex']) for r in prediction) if decoded else None
        n, again = reverse.get(row['id']), reemission.get(row['id'])
        complete = n is not None and n['code']==0 and n['remaining']==0 and n['consumed']==len(row['machine_hex'])//2
        native_raw = base64.b64decode(n['output_base64']) if complete else None
        compare = dict(id=row['id'], family=row['family'], decoded=decoded, native_reverse=n, reemission=again,
                       native_input_complete=complete, independent_native_raw_exact=decoded and pcode==native_raw,
                       raw_preserved=b''.join(bytes.fromhex(r['raw_hex']) for r in prediction).hex()==row['machine_hex'],
                       machine_reemission_exact=again is not None and again['code']==0 and base64.b64decode(again['output_base64']).hex()==row['machine_hex'])
        comparisons.append(compare)
        family = by_family.setdefault(row['family'], Counter())
        for counter in (counts, family):
            counter['controls']+=1
            counter['decoded']+=decoded
            counter['native_input_complete']+=complete
            counter['independent_native_raw_exact']+=compare['independent_native_raw_exact']
            counter['raw_preserved']+=compare['raw_preserved']
            counter['machine_reemission_exact']+=compare['machine_reemission_exact']
        if decoded and pcode != native_raw:
            failures.append(dict(request=row, result=compare))
    save(output / 'comparisons.json', comparisons)
    save(output / 'failures.json', failures)
    result = dict(scope=__doc__, counts=dict(counts), by_family={k:dict(v) for k,v in by_family.items()}, independent_mismatches=len(failures))
    save(output / 'summary.json', result)
    print(json.dumps(result, ensure_ascii=True), flush=True)
    if failures:
        raise ValueError('Independent prediction differs; failure controls retained')


if __name__=='__main__':
    main()
