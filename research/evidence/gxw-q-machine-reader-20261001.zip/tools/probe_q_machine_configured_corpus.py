"""Predict original Q PCode bodies in one observed real compiler read profile.

The case-16 parameter input is passed unchanged to each fresh memory-only native
conversion. It is a conversion profile for this experiment, not proof that every
original project's saved machine cache uses this allocation. Independent machine
predictions are saved before native reverse. Both the default-context refusal and
the wrong-context semantic alias are retained as separate controls.
"""
from pathlib import Path
from collections import Counter
import base64
import json
import os
import subprocess

P = Path(__file__).resolve().parent
from source_q_machine_reader import load_profile, read_machine


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=True, indent=2) + '\n', encoding='utf-8')


def predicted(records):
    if not records or any(r['handling'] != 'decoded' for r in records):
        return None
    return b''.join(bytes.fromhex(r['pcode_hex']) for r in records)


def complete(row, size):
    return (row is not None and row['code'] == 0 and row['remaining'] == 0 and
            row['consumed'] == size and row['input_unchanged'] and row['guards_intact'])


def main():
    output = P / 'q-machine-configured-corpus-20261001-v1'
    output.mkdir()
    original = json.loads((P / 'q-machine-original-corpus-20261001-v1/before-forward.json').read_text())
    observed = P / 'q-machine-observed-project-profile-20261001-v1'
    for name in ('source_q_machine_reader.py', 'QMachineOracle.cs', Path(__file__).name):
        (output / name).write_bytes((P / name).read_bytes())
    (output / 'static-read-tables.json').write_bytes((P / 'q-machine-static-read-tables-20261001-v3.json').read_bytes())
    (output / 'observed-device-context.json').write_bytes((observed / 'comparison.json').read_bytes())
    (output / 'default-device-context.json').write_bytes((P / 'q-machine-default-device-table-20261001-v2/comparison.json').read_bytes())
    parameters = output / 'project-parameters.bin'
    parameters.write_bytes((observed / parameters.name).read_bytes())
    profile = load_profile(output / 'static-read-tables.json', output / 'observed-device-context.json')
    default = load_profile(output / 'static-read-tables.json', output / 'default-device-context.json')
    save(output / 'before-forward.json', dict(scope=__doc__, parameter_hex=parameters.read_bytes().hex(),
                                            adapter_cpu=209, versions=[25], requests=original['requests']))
    executable = output / 'QMachineOracle.exe'
    built = subprocess.run([str(Path(os.environ['WINDIR']) / 'Microsoft.NET/Framework/v4.0.30319/csc.exe'),
                            '/nologo', '/platform:x86', '/out:' + str(executable), str(output / 'QMachineOracle.cs')],
                           capture_output=True, timeout=30, creationflags=subprocess.CREATE_NO_WINDOW)
    (output / 'build.txt').write_bytes(built.stdout + built.stderr)
    if built.returncode:
        raise RuntimeError('Owned helper build failed; retained')

    def run(mode, inputs, name, configured=True):
        directory = output / name
        directory.mkdir()
        request = directory / 'requests.tsv'
        request.write_text('\n'.join(str(i)+'\t'+base64.b64encode(raw).decode() for i, raw in inputs)+'\n', encoding='ascii')
        args = [str(executable), 'D:/GXWORKS2/Easysocket/CodeGenerator/ECCodeGenerator2.dll', mode,
                str(request), str(directory / 'output.jsonl')]
        if configured:
            args.append(str(parameters))
        process = subprocess.run(args, capture_output=True, timeout=45, creationflags=subprocess.CREATE_NO_WINDOW)
        (directory / 'stdout.bin').write_bytes(process.stdout)
        (directory / 'stderr.bin').write_bytes(process.stderr)
        save(directory / 'process.json', dict(returncode=process.returncode, configured=configured))
        if process.returncode:
            raise RuntimeError('Owned native conversion failed; retained')
        rows = [json.loads(l) for l in (directory / 'output.jsonl').read_text(encoding='utf-8-sig').splitlines()]
        if len(rows) != len(inputs) or {r['id'] for r in rows} != {i for i, _ in inputs}:
            raise ValueError('Native result identifiers differ; retained')
        print(json.dumps(dict(stage=name, requests=len(rows), accepted=sum(r['code']==0 for r in rows))), flush=True)
        return {r['id']: r for r in rows}

    forward = run('forward', [(r['id'], bytes.fromhex(r['raw_hex'])) for r in original['requests']], 'forward')
    records, bodies, reverse_inputs = [], [], []
    for request in original['requests']:
        row = dict(id=request['id'], original_pcode_hex=request['raw_hex'], mnemonic=request['mnemonic'], args=request['args'])
        f = forward[row['id']]
        row['forward_code'] = f['code']
        if complete(f, len(request['raw_hex'])//2):
            machine = base64.b64decode(f['output_base64'])
            row.update(machine_hex=machine.hex(), prediction=read_machine(machine, profile))
            reverse_inputs.append((row['id'], machine))
        records.append(row)
    original_bodies = output / 'original-pcode'
    original_bodies.mkdir()
    for source in original['programs']:
        if 'records' not in source:
            continue
        raw = Path(source['source']).read_bytes()
        expected = b''.join(bytes.fromhex(original['requests'][ref['id']]['raw_hex']) for ref in source['records'])
        if expected != raw or source['parse_gaps']:
            raise ValueError('Original program reconstruction differs; retained')
        i = len(bodies)
        saved = original_bodies / f'{i:03d}.bin'
        saved.write_bytes(raw)
        row = dict(id=100000+i, source=source['source'], original_entry=saved.relative_to(output).as_posix(),
                   original_pcode_hex=raw.hex(), instruction_ids=[ref['id'] for ref in source['records']])
        if all('machine_hex' in records[ref['id']] for ref in source['records']):
            machine = b''.join(bytes.fromhex(records[ref['id']]['machine_hex']) for ref in source['records'])
            if len(machine) > 4096:
                raise ValueError('Whole body exceeds owned conversion envelope')
            row.update(machine_hex=machine.hex(), prediction=read_machine(machine, profile))
            reverse_inputs.append((row['id'], machine))
        bodies.append(row)
    wrong_context = []
    for identifier in (343, 344, 354, 378):
        row = records[identifier]
        if 'machine_hex' not in row:
            raise ValueError('Observed ST context control was refused')
        machine = bytes.fromhex(row['machine_hex'])
        wrong_context.append(dict(id=identifier, machine_hex=machine.hex(), original_pcode_hex=row['original_pcode_hex'],
                                  configured_prediction=row['prediction'], default_prediction=read_machine(machine, default)))
    save(output / 'before-reverse.json', dict(scope=__doc__, records=records, bodies=bodies, wrong_context=wrong_context))
    reverse = run('reverse', reverse_inputs, 'reverse')
    wrong_reverse = run('reverse', [(r['id'], bytes.fromhex(r['machine_hex'])) for r in wrong_context], 'wrong-context-reverse', False)
    wrong_forward = run('forward', [(r['id'], base64.b64decode(wrong_reverse[r['id']]['output_base64']))
                                   for r in wrong_context if complete(wrong_reverse[r['id']], len(r['machine_hex'])//2)],
                        'wrong-context-reemission', False)
    comparisons, counts, weighted = [], Counter(), Counter()
    for row in records + bodies:
        raw = predicted(row.get('prediction', []))
        native = reverse.get(row['id'])
        full = complete(native, len(row.get('machine_hex', ''))//2)
        nr = base64.b64decode(native['output_base64']) if full else None
        result = dict(id=row['id'], decoded=raw is not None, native_input_complete=full,
                      independent_native_raw_exact=raw is not None and raw==nr,
                      independent_source_raw_exact=raw is not None and raw.hex()==row['original_pcode_hex'],
                      raw_preserved=b''.join(bytes.fromhex(r['raw_hex']) for r in row.get('prediction',[])).hex()==row.get('machine_hex'),
                      native_reverse_code=native['code'] if native else None)
        comparisons.append(result)
        prefix = 'instructions_' if row['id'] < 100000 else 'full_bodies_'
        for key in ('decoded', 'native_input_complete', 'independent_native_raw_exact', 'independent_source_raw_exact', 'raw_preserved'):
            counts[prefix+key] += result[key]
        counts[prefix+'inputs'] += 'machine_hex' in row
        counts[prefix+'independent_mismatches'] += raw is not None and raw != nr
    by_id = {r['id']:r for r in comparisons}
    for body in bodies:
        for identifier in body['instruction_ids']:
            weighted['original_instructions'] += 1
            for key in ('decoded', 'independent_native_raw_exact', 'independent_source_raw_exact'):
                weighted[key] += by_id[identifier][key]
    aliases = []
    for row in wrong_context:
        nr = wrong_reverse[row['id']]
        f = wrong_forward.get(row['id'])
        dr = predicted(row['default_prediction'])
        cr = predicted(row['configured_prediction'])
        aliases.append(dict(id=row['id'], default_native_complete=complete(nr, len(row['machine_hex'])//2),
                            default_prediction_native_exact=dr is not None and base64.b64decode(nr['output_base64'])==dr,
                            configured_original_exact=cr is not None and cr.hex()==row['original_pcode_hex'],
                            default_semantics_differ=dr!=cr,
                            default_reemission_machine_exact=f is not None and f['code']==0 and
                                base64.b64decode(f['output_base64']).hex()==row['machine_hex'],
                            default_pcode_hex=dr.hex() if dr is not None else None))
    save(output / 'comparisons.json', dict(records=comparisons[:len(records)], bodies=comparisons[len(records):], aliases=aliases))
    save(output / 'failures.json', [dict(prediction=row, comparison=by_id[row['id']]) for row in records+bodies
                                   if by_id[row['id']]['decoded'] and not by_id[row['id']]['independent_native_raw_exact']])
    result = dict(scope=__doc__, counts=dict(counts), weighted=dict(weighted), aliases=aliases,
                  original_source_bodies=len(original['programs']), distinct_nonempty_bodies=len(bodies),
                  native_inputs_unchanged=all(r['input_unchanged'] and r['guards_intact'] for group in
                      (forward, reverse, wrong_reverse, wrong_forward) for r in group.values()))
    save(output / 'summary.json', result)
    print(json.dumps(result, ensure_ascii=True), flush=True)
    if counts['instructions_independent_mismatches'] or counts['full_bodies_independent_mismatches']:
        raise ValueError('Independent reader differs; retained')


if __name__ == '__main__':
    main()
