// Owned memory-only Q conversion. ECCodeGenerator2 15.41 public exports and
// kind-1 adapters 1758C/173AB copy six DWORD fields; reverse returns byte count.
using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;

public static class QMachineOracle {
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode)] static extern IntPtr LoadLibraryEx(string p,IntPtr f,uint flags);
    [DllImport("kernel32.dll",CharSet=CharSet.Ansi,ExactSpelling=true)] static extern IntPtr GetProcAddress(IntPtr m,string n);
    [DllImport("kernel32.dll")] static extern uint SetErrorMode(uint mode);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate IntPtr Create();
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Open(IntPtr h,int cpu,int mode);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Version(IntPtr h,int count,[In] uint[] versions);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Close(IntPtr h);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate void Destroy(IntPtr h);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int ErrorOffset(IntPtr h,ref int offset);
    [StructLayout(LayoutKind.Sequential,Pack=1)] struct Buffers {
        public IntPtr machine; public int remaining; public IntPtr pcode;
        public IntPtr deviceOffsets; public int reserved16,reserved20;
    }
    [StructLayout(LayoutKind.Sequential,Pack=1)] struct Packed {public uint low;public ushort high;}
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Forward(IntPtr h,ref Buffers b,IntPtr context,ref int words,int a,int c);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Reverse(IntPtr h,ref Buffers b,IntPtr context,ref int bytes,int a,int c,Packed one,Packed two);
    static T Export<T>(IntPtr m,string n) where T:class {
        IntPtr p=GetProcAddress(m,n);if(p==IntPtr.Zero)throw new Exception("Missing export: "+n);
        return Marshal.GetDelegateForFunctionPointer(p,typeof(T)) as T;
    }
    sealed class Arena:IDisposable {
        public const int Guard=32;public byte[] data;public int capacity;GCHandle pin;
        public Arena(int size){capacity=size;data=new byte[size+2*Guard];for(int i=0;i<Guard;i++){data[i]=0xA5;data[Guard+size+i]=0xA5;}pin=GCHandle.Alloc(data,GCHandleType.Pinned);}
        public IntPtr Pointer{get{return IntPtr.Add(pin.AddrOfPinnedObject(),Guard);}}
        public void Verify(){for(int i=0;i<Guard;i++)if(data[i]!=0xA5||data[Guard+capacity+i]!=0xA5)throw new Exception("Owned buffer extent changed");}
        public void Dispose(){pin.Free();}
    }
    public static int Main(string[] args) {
        if(IntPtr.Size!=4||(args.Length!=4&&args.Length!=5))return 2;SetErrorMode(3);
        if(args[1]!="forward"&&args[1]!="reverse")return 2;
        if(FileVersionInfo.GetVersionInfo(args[0]).FileVersion!="15.41")throw new Exception("Uninspected Q provider version");
        IntPtr m=LoadLibraryEx(args[0],IntPtr.Zero,8);if(m==IntPtr.Zero)throw new Exception("Provider load failed");
        Create create=Export<Create>(m,"ObjectNew");Open open=Export<Open>(m,"Open");Version version=Export<Version>(m,"SetVersion");
        Close close=Export<Close>(m,"Close");Destroy destroy=Export<Destroy>(m,"ObjectDelete");ErrorOffset error=Export<ErrorOffset>(m,"GetErrorOffset");
        Forward forward=Export<Forward>(m,"ChangePToMcode");Reverse reverse=Export<Reverse>(m,"ChangeMToPcode");
        byte[] contextRaw=args.Length==5?File.ReadAllBytes(args[4]):new byte[0];
        if(contextRaw.Length!=0) {
            if(contextRaw.Length<6||contextRaw.Length>518)throw new Exception("Outside observed parameter table envelope");
            int count=BitConverter.ToUInt16(contextRaw,4);
            if(count>128||contextRaw.Length!=6+4*count)throw new Exception("Parameter table framing differs");
        }
        using(StreamWriter output=new StreamWriter(args[3]))foreach(string line in File.ReadLines(args[2])) {
            string[] fields=line.Split('\t');if(fields.Length!=2)throw new Exception("Request framing");
            int id=int.Parse(fields[0]);byte[] raw=Convert.FromBase64String(fields[1]);
            if(raw.Length<3||raw.Length>4096||(args[1]=="reverse"&&(raw.Length&3)!=0))throw new Exception("Outside bounded Q conversion envelope");
            using(Arena input=new Arena(8192))using(Arena result=new Arena(1048576))using(Arena offsets=new Arena(128))using(Arena context=new Arena(4096)) {
                Array.Copy(contextRaw,0,context.data,Arena.Guard,contextRaw.Length);
                IntPtr contextPointer=contextRaw.Length==0?IntPtr.Zero:context.Pointer;
                Array.Copy(raw,0,input.data,Arena.Guard,raw.Length);IntPtr h=create();if(h==IntPtr.Zero)throw new Exception("Provider object absent");
                try {
                    int code=open(h,209,0);if(code!=0)throw new Exception("Open: "+code);
                    code=version(h,1,new uint[]{25});if(code!=0)throw new Exception("SetVersion: "+code);
                    Buffers b=new Buffers();b.remaining=raw.Length;b.deviceOffsets=offsets.Pointer;
                    int nativeValue,bytes,consumed;
                    if(args[1]=="forward") {
                        b.machine=result.Pointer;b.pcode=input.Pointer;nativeValue=result.capacity/4;
                        code=forward(h,ref b,contextPointer,ref nativeValue,0,0);
                        consumed=b.pcode.ToInt32()-input.Pointer.ToInt32();bytes=b.machine.ToInt32()-result.Pointer.ToInt32();
                    } else {
                        b.machine=input.Pointer;b.pcode=result.Pointer;nativeValue=result.capacity;
                        code=reverse(h,ref b,contextPointer,ref nativeValue,0,0,new Packed(),new Packed());
                        consumed=b.machine.ToInt32()-input.Pointer.ToInt32();bytes=code==0?nativeValue:0;
                    }
                    if(consumed<0||consumed>input.capacity||bytes<0||bytes>result.capacity)throw new Exception("Returned extent exceeds owned allocation");
                    input.Verify();result.Verify();offsets.Verify();context.Verify();bool unchanged=true;
                    for(int i=0;i<raw.Length;i++)if(input.data[Arena.Guard+i]!=raw[i])unchanged=false;
                    for(int i=0;i<contextRaw.Length;i++)if(context.data[Arena.Guard+i]!=contextRaw[i])throw new Exception("Observed parameter input was changed");
                    int errorAt=-1,errorCode=code==0?0:error(h,ref errorAt);
                    if(code!=0) {
                        byte[] captured=new byte[result.capacity];Array.Copy(result.data,Arena.Guard,captured,0,captured.Length);
                        File.WriteAllBytes(Path.Combine(Path.GetDirectoryName(args[3]),"untrusted-output-"+id+".bin"),captured);
                    }
                    output.WriteLine("{\"id\":"+id+",\"code\":"+code+",\"consumed\":"+consumed+",\"remaining\":"+b.remaining+",\"bytes\":"+bytes+",\"native_value\":"+nativeValue+",\"input_unchanged\":"+(unchanged?"true":"false")+",\"guards_intact\":true,\"error_offset\":"+(code==0||errorCode!=0?"null":errorAt.ToString())+",\"output_base64\":\""+(code==0?Convert.ToBase64String(result.data,Arena.Guard,bytes):"")+"\"}");output.Flush();
                } finally {close(h);destroy(h);}
            }
        }
        return 0;
    }
}
