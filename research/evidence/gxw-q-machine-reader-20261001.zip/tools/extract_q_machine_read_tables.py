"""Read tables used by the separately inspected Q reverse implementation.

This reads the installed PE without loading it. No instruction outputs or
source PCode are used to infer table contents, and no digests are calculated.
"""
from pathlib import Path
import json
import sys

P = Path(__file__).resolve().parent
sys.path.insert(0, str(P.parents[3] / 'research/experiments/re-tools'))
import pefile

DLL = Path('D:/GXWORKS2/Easysocket/CodeGenerator/ECCodeGenerator2.dll')


def main():
    revision = sys.argv[1] if len(sys.argv) > 1 else 'v1'
    if revision not in ('v1', 'v2', 'v3'):
        raise ValueError('Unknown extraction revision')
    output = P / f'q-machine-static-read-tables-20261001-{revision}.json'
    if output.exists():
        raise FileExistsError('An earlier static table observation is retained')
    pe = pefile.PE(str(DLL))
    versions = [t.entries.get(b'FileVersion') for files in pe.FileInfo for b in files
                if b.Key == b'StringFileInfo' for t in b.StringTable]
    if b'15.41' not in versions or pe.OPTIONAL_HEADER.ImageBase != 0x10000000:
        raise ValueError('Uninspected Q provider version or image context')
    tables = {
        'basic_reverse': (0x118638, 64 * 3, 0x76029),
        'basic_start_flags': (0x1186F8, 64 * 3, 0x76F52),
        'control_reverse': (0x118370, 4 * 16 * 2, 0x74A5E),
    }
    if revision in ('v2', 'v3'):
        tables.update(literal_devices=(0x1183F4, 9 * 4, 0x752CF),
                      word_reverse=(0x1187B8, 0x1B * 4 * 3, 0x776A3),
                      comparison_reverse=(0x116E6C, 6 * 5, 0x73A41))
    if revision == 'v3':
        tables.update(application_reverse=(0x116FF0, 0x2CA * 7, 0x748A2))
    result = dict(provider=str(DLL), file_version='15.41', image_base=0x10000000,
                  file_bytes=DLL.stat().st_size, adapter_cpu=209, versions=[25],
                  scope='Static reverse tables, distinct from forward templates', tables={})
    for name, (rva, size, reader) in tables.items():
        raw = pe.get_data(rva, size)
        if len(raw) != size:
            raise ValueError('Incomplete table read')
        result['tables'][name] = dict(rva=rva, bytes=size, reader_rva=reader, raw_hex=raw.hex())
    output.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(dict(output=str(output), tables={k:(v['rva'],v['bytes']) for k,v in result['tables'].items()})), flush=True)


if __name__ == '__main__':
    main()
