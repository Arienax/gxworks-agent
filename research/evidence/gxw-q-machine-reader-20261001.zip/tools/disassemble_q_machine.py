"""Bounded static inspection of the installed Q code provider, without loading it."""
from pathlib import Path
import sys

P = Path(__file__).resolve().parent
sys.path.insert(0, str(P.parents[3] / 'research/experiments/re-tools'))
import capstone
import pefile

DLL = Path('D:/GXWORKS2/Easysocket/CodeGenerator/ECCodeGenerator2.dll')


def main():
    start, stop = (int(value, 16) for value in sys.argv[1:3])
    if not 0 <= start < stop <= 0x180000 or stop - start > 0x2000:
        raise ValueError('Outside the bounded static inspection envelope')
    pe = pefile.PE(str(DLL))
    versions = [table.entries.get(b'FileVersion') for files in pe.FileInfo for block in files
                if block.Key == b'StringFileInfo' for table in block.StringTable]
    if b'15.41' not in versions or pe.OPTIONAL_HEADER.ImageBase != 0x10000000:
        raise ValueError('Uninspected Q provider version or image context')
    dis = capstone.Cs(capstone.CS_ARCH_X86, capstone.CS_MODE_32)
    rows = [f'{i.address:06x} {i.mnemonic:8s} {i.op_str}' for i in dis.disasm(pe.get_data(start, stop - start), start)]
    result = '\n'.join(rows) + '\n'
    output = P / f'q-machine-{start:06x}-{stop:06x}-20261001.txt'
    if output.exists() and output.read_text(encoding='utf-8') != result:
        raise FileExistsError('An earlier static observation differs')
    if not output.exists():
        output.write_text(result, encoding='utf-8')
    print(result, end='')


if __name__ == '__main__':
    main()
