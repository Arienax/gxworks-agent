"""Inspect saved split-structure layout observations, never recompile inputs.

Compare predictions, independent/native listings and observed allocation blocks;
retain raw native cells, component info and duplicate type POU identities. Cache
tables are post-observation evidence only, never source predictor inputs.
"""
from pathlib import Path
import json,re,sys
ROOT=Path(__file__).resolve().parents[4];P=Path(__file__).resolve().parent
sys.path[:0]=[str(P),str(ROOT/'src'),str(ROOT/'research')]
from probe_minimal_conditional_port_writes import save,streams
from gxw.compiler_tables import parse_compiler_tables
from gxw.text_pou import parse_st_pou
from source_fx_user_functions import predict
from source_fx_structure_layout import Globals
from probe_gxw_parameters import project_allocation_ranges

GROUPS=['fx3g-structure-globals-forward-20260930','fx3g-structure-bounds-forward-20260930',
        'fx3g-structure-instances-forward-20260930','fx3g-global-documents-forward-20260930',
        'fx3g-global-mixed-order-forward-20260930']


def address(raw_hex):
    raw=bytes.fromhex(raw_hex)
    if len(raw)!=26 or raw[0] not in (0x21,0x24):raise ValueError('outside observed pool address')
    return dict(family={0x21:'M',0x24:'D'}[raw[0]],number=int.from_bytes(raw[2:5],'little'),count=int.from_bytes(raw[6:10],'little'))


def cache_member_reference(tables,globals_pou,text):
    m=re.fullmatch(r'(\w+)\[([+-]?\d+(?:\s*,\s*[+-]?\d+)*)\]\.(\w+)(?:\[([+-]?\d+(?:\s*,\s*[+-]?\d+)*)\])?',text)
    components=[c for c in tables.components(globals_pou) if c.name_bytes.decode('cp1252').casefold()==m[1].casefold()]
    assert len(components)==1
    variable=components[0];descriptor=tables.array_at(tables.component_array_offset(variable))
    assert descriptor.element_type==0x34 and descriptor.count_matches_dimensions
    target=tables.pou_at(descriptor.element_parameter)
    members=[c for c in tables.components(target) if c.name_bytes.decode('cp1252').casefold()==m[3].casefold()]
    assert len(members)==1
    member=members[0];base=address(member.user_info.hex());indices=[int(v) for v in m[2].split(',')]
    assert len(indices)==len(descriptor.dimensions)
    relative=0
    for index,dimension in zip(indices,descriptor.dimensions,strict=True):
        assert dimension.lower<=index<=dimension.upper
        relative=relative*dimension.extent+index-dimension.lower
    raw=variable.user_info;assert len(raw)==26 and raw[0]==0x0c
    stride=int.from_bytes(raw[5:9] if base['family']=='D' else raw[13:17],'little')
    assert stride>0
    compiled_type=tables.component_type(member);member_relative=0;member_descriptor=None
    if compiled_type==0x33:
        assert m[4] is not None
        member_descriptor=tables.array_at(tables.component_array_offset(member));assert member_descriptor.count_matches_dimensions
        compiled_type=member_descriptor.element_type
        member_indices=[int(v) for v in m[4].split(',')];assert len(member_indices)==len(member_descriptor.dimensions)
        for index,dimension in zip(member_indices,member_descriptor.dimensions,strict=True):
            assert dimension.lower<=index<=dimension.upper
            member_relative=member_relative*dimension.extent+index-dimension.lower
    else:assert m[4] is None
    width={0:1,2:1,17:1,18:2}[compiled_type]
    return dict(text=text,family=base['family'],number=base['number']+relative*stride+member_relative*width,
                type={0:'BOOL',2:'INT',17:'WORD',18:'DWORD'}[compiled_type],
                variable_component_offset=variable.record.table_offset,array_descriptor_offset=descriptor.record.table_offset,
                resolved_type_pou_offset=target.record.table_offset,member_component_offset=member.record.table_offset,
                native_family_stride=stride,variable_user_info_hex=raw.hex(),member_user_info_hex=member.user_info.hex(),
                descriptor_raw_hex=descriptor.record.payload.hex(),
                member_array_descriptor_offset=member_descriptor.record.table_offset if member_descriptor else None,
                member_descriptor_raw_hex=member_descriptor.record.payload.hex() if member_descriptor else None)


def main():
    findings=[]
    groups=sys.argv[1:] or GROUPS
    for group in groups:
        out=P/group;options=json.loads((out/'experiment-plan.json').read_text())['prediction_options'];group_rows=[]
        for row in json.loads((out/'comparison.json').read_text()):
            name=row['case'];directory=out/name;native=Path(row['native_directory'])
            assert row['check'] and not row['check']['rejected'] and not row['reopen']['check']['rejected'] and row['reopen']['bytes_identical']
            assert row['independent_address_projection_match']
            code=(native/'pcode-0-0.bin').read_bytes();prediction=predict(streams((directory/'input.gxw').read_bytes()),**options)
            assert code==prediction['output']
            payloads=[];errors=[]
            for line in (native/'events.jsonl').read_text().splitlines():
                event=json.loads(line);payload=event.get('payload',{});payloads.append(payload)
                if event.get('type')=='error' or payload.get('observation_error') or 'error' in payload.get('event',''):errors.append(event)
            assert not errors
            wrappers=[r for r in payloads if r.get('event')=='block-walk' and r.get('name')=='wrapper' and r.get('phase')=='enter']
            assert wrappers and not any(r.get('graph_truncated') for r in wrappers)
            typed={r['allocation_id']:r for r in payloads if r.get('event')=='typed-allocation'}
            global_pools=[r for r in payloads if r.get('event')=='pool-allocation' and (
                          r.get('caller',{}).get('rva') in ('0x544c0','0x54535') or
                          typed.get(r.get('allocation_id'),{}).get('category')==9)]
            observed=[address(r['after']) for r in global_pools]
            expected=[{k:r[k] for k in ('family','number','count')} for r in prediction['global_blocks']]
            assert observed==expected,(group,name,observed,expected)
            writes=[r for r in payloads if r.get('event')=='component-userinfo-write']
            save(directory/'structure-allocation-native-ir.json',dict(global_pool_calls=global_pools,
                 component_writes=writes,typed_allocations=list(typed.values()),wrapper_entries=wrappers,
                 temporary_events=[r for r in payloads if r.get('event','').startswith('temporary-')],
                 sink_records=[r for r in payloads if r.get('event')=='sink-record'],
                 handling='Raw cells, opaque pointer values and all saved pool fields preserved. Source layout is cross-checked only against known address projections.'))
            tables=parse_compiler_tables(streams((native/'native-saved.gxw').read_bytes())['CGTable.dat'])
            pous=[tables.pou_at(r.table_offset) for r in tables.tables[1].records]
            type_records=[dict(name=p.name_bytes.decode('cp1252'),pou_offset=p.record.table_offset,
                               raw_hex=p.record.payload.hex(),
                               members=[dict(name=c.name_bytes.decode('cp1252'),component_offset=c.record.table_offset,
                                             user_info_hex=c.user_info.hex(),raw_hex=c.record.payload.hex()) for c in tables.components(p)])
                          for p in pous if p.name_bytes.startswith(b'ST_')]
            # Type names need not be unique: two distinct instances cause two
            # POU records with the same name. Preserve table offsets as identity.
            save(directory/'native-structure-type-records.json',dict(scope='Post-observation compiler table evidence only; predictor does not read it.',
                 name_uniqueness='not assumed',records=type_records))
            source=streams((directory/'input.gxw').read_bytes());metadata=next(v for n,v in source.items() if n.endswith('.prj'))
            ranges={r['name']:r for r in project_allocation_ranges(metadata)['ranges']}
            pools={n:[ranges[n]['lower'],ranges[n]['upper']] for n in ('D','M','P')};cursor={n:pools[n][1] for n in ('D','M')}
            layout=Globals(source,pools,cursor,allow_multiple_documents=options.get('allow_multiple_global_documents',False),
                           allow_member_arrays=options.get('allow_structure_member_arrays',False))
            global_pous=[p for p in pous if p.name_bytes==b'@GLOBALS'];assert len(global_pous)==1
            references=[]
            for text in re.findall(r'\b\w+\[[+-]?\d+(?:\s*,\s*[+-]?\d+)*\]\.\w+(?:\[[+-]?\d+(?:\s*,\s*[+-]?\d+)*\])?',parse_st_pou(source['MAIN.Program.pou']).text):
                observed_reference=cache_member_reference(tables,global_pous[0],text);expected_reference=layout.resolve(text)
                assert all(observed_reference[k]==expected_reference[k] for k in ('family','number','type'))
                references.append(observed_reference)
            save(directory/'independent-cache-member-references.json',dict(scope='Post-observation independent cache traversal follows array element POU offsets, never first matching type name. Source model computes addresses independently.',
                 references=references,all_equal=True,composite_user_info_handling='Partially decoded: family strides at 5/13; all remaining bytes retained.'))
            finding=dict(group=group,case=name,prospective_equal=row['prospective_equal'],current_source_model_equal=True,
                         fresh_check_and_reopen_accepted=True,generated_bytes=len(code),independent_address_projection_match=True,
                         global_block_projection_equal=True,global_blocks=prediction['global_blocks'],routine_order=prediction['routine_order'],
                         independent_cache_member_reference_matches=len(references),
                         native_type_pou_identities=[dict(name=r['name'],offset=r['pou_offset']) for r in type_records])
            group_rows.append(finding);findings.append(finding)
        save(out/'structure-layout-findings.json',dict(cases=group_rows,boundary='One FX3G lineage, auto-allocated flat primitive structure members; no PLC execution evidence.'))
    summary=dict(scope='Source-only original FX3G global layout, separate same-type instances, static literal structure-array member references and primitive user functions.',
                 observations=len(findings),prospective_full_byte_matches=sum(r['prospective_equal'] is True for r in findings),
                 prospective_failures=sum(r['prospective_equal'] is False for r in findings),cases=findings,
                 boundaries=['One real FX3G library lineage.','No nested structures, explicit member locations or dynamically indexed members. Primitive member arrays require a separate source-model opt-in.',
                             'Multiple global documents are limited to source library catalog order, one storage document per library and one project global document.',
                             'No device/PLC execution or product integration.'])
    save(P/(groups[0]+'-layout-summary.json' if sys.argv[1:] else 'fx3g-source-structure-layout-summary-20260930.json'),summary)
    print(json.dumps({k:v for k,v in summary.items() if k!='cases'}),flush=True)


if __name__=='__main__':main()
