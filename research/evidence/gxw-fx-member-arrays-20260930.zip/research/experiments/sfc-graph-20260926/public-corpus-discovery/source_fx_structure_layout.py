"""Source-only hypothesis for split word/bit storage of FX3G structures.

Each structure array gets one contiguous block per family, with ascending
member offsets and an element stride in each block. Global declarations follow
library catalog/document order and then record IDs, mixing scalar and structure
storage. Original .lns/.gh/.lng remain untouched. The flat primitive-member
profile excludes explicit member addresses and nesting.
"""
import math,re
from gxw.declarations import parse_structure_declarations,_type_parts
from probe_fx3g_library_declarations import source_rows
from source_q_label_binding import scalar

TYPES={'BOOL':('M',1),'INT':('D',1),'WORD':('D',1),'DWORD':('D',2)}


class Globals:
    def __init__(self,streams,pools,cursor,*,allow_multiple_documents=False,allow_member_arrays=False):
        self.bindings={};self.blocks=[];self.pools=pools;self.cursor=cursor;definitions={}
        for name,raw in streams.items():
            if not name.endswith('.lns'):continue
            owner=name.split('\\')[0].casefold()
            if owner in definitions:raise ValueError('ambiguous global structure definition')
            definitions[owner]=(name,parse_structure_declarations(raw,logical_name=name))
        documents=[]
        for name,raw in streams.items():
            if not name.endswith(('.gh','.lng')):continue
            rows=source_rows(raw,False)['rows']
            if len({r['record_id'] for r in rows})!=len(rows):raise ValueError('duplicate source global ID')
            storage=[]
            for r in sorted(rows,key=lambda r:r['record_id']):
                if r['class_code'] in (2,9):continue
                if r['class_code']!=8 or r['device'] or r['iec_address']:
                    raise ValueError('outside auto-allocated global source profile')
                if r['initial_value'] not in ('','0','FALSE'):
                    raise ValueError('unmodeled nonzero global initialization')
                base,bounds=_type_parts(r['data_type'])
                dims=[dict(lower=lo,upper=hi,extent=hi-lo+1) for lo,hi in bounds]
                elements=math.prod(d['extent'] for d in dims)
                if elements<1 or elements>65536:raise ValueError('unbounded global source array')
                storage.append(dict(row=r,base=base,dimensions=dims,elements=elements,document=name))
            documents.append((name,storage))
        primitive_docs={n for n,rows in documents if any(r['base'] in TYPES for r in rows)}
        structure_docs={n for n,rows in documents if any(r['base'] not in TYPES for r in rows)}
        if not allow_multiple_documents and (len(primitive_docs)>1 or len(structure_docs)>1):
            raise ValueError('global document ordering outside bounded single-document profile')
        if allow_multiple_documents:
            libraries=[n[:-4].casefold() for n in streams if n.endswith('.lif')]
            if len(libraries)!=len(set(libraries)):raise ValueError('ambiguous source library catalog order')
            storage_docs=[n for n,rows in documents if rows]
            if sum(n.endswith('.gh') for n in storage_docs)>1:
                raise ValueError('multiple project global documents outside initial catalog profile')
            doc_libraries=[n.rsplit('\\',1)[1][:-4].casefold() for n in storage_docs if n.endswith('.lng')]
            if len(doc_libraries)!=len(set(doc_libraries)):
                raise ValueError('multiple storage documents in a library outside initial catalog profile')
            def order(item):
                name=item[0]
                if name.endswith('.gh'):return (1,0)
                library=name.rsplit('\\',1)[1][:-4].casefold()
                if library not in libraries:raise ValueError('global library absent from source catalog')
                return (0,libraries.index(library))
            documents=sorted(documents,key=order)
        else:documents=sorted(documents)
        for name,rows in documents:
            for item in rows:
                r=item['row'];base=item['base'];key=r['name'].casefold()
                if key in self.bindings:raise ValueError('ambiguous source global variable')
                if base in TYPES:
                    if r['mode']!=0 or item['dimensions']:raise ValueError('primitive global arrays outside first layout profile')
                    family,width=TYPES[base];number=self.reserve(family,width,key,name)
                    self.bindings[key]=dict(type=base,operand=scalar(family,number),name=r['name'])
                    continue
                if base.casefold() not in definitions or r['type_reference'].casefold()!=base.casefold():
                    raise ValueError('unresolved source global structure')
                if r['mode']!=2 or r['extension_slots']!=['','',0,'',''] or not item['dimensions']:
                    raise ValueError('structure source storage outside measured unlocated array profile')
                type_name,doc=definitions[base.casefold()]
                if len({m.record_id for m in doc.members})!=len(doc.members):raise ValueError('duplicate structure member ID')
                members={};strides={'D':0,'M':0}
                for m in sorted(doc.members,key=lambda m:m.record_id):
                    member_base,member_bounds=_type_parts(m.data_type)
                    if member_base not in TYPES or m.type_reference or bool(m.array_marker)!=bool(member_bounds):
                        raise ValueError('nested/nonprimitive structure member outside profile')
                    if member_bounds and not allow_member_arrays:
                        raise ValueError('nested/nonprimitive structure member outside profile')
                    member_dims=[dict(lower=lo,upper=hi,extent=hi-lo+1) for lo,hi in member_bounds]
                    member_elements=math.prod(d['extent'] for d in member_dims)
                    if len(member_dims)>2 or member_elements>65536:
                        raise ValueError('member array outside bounded rank/size profile')
                    if m.name.casefold() in members:raise ValueError('duplicate structure member name')
                    family,width=TYPES[member_base]
                    members[m.name.casefold()]=dict(type=member_base,family=family,offset=strides[family],width=width,
                                                  dimensions=member_dims,elements=member_elements)
                    strides[family]+=width*member_elements
                starts={family:self.reserve(family,strides[family]*item['elements'],key,name)
                        for family in ('D','M') if strides[family]}
                self.bindings[key]=dict(structure=base,source_type_stream=type_name,members=members,
                                       dimensions=item['dimensions'],strides=strides,starts=starts,elements=item['elements'])

    def reserve(self,family,count,owner,document):
        number=self.cursor[family]-count+1
        if number<self.pools[family][0]:raise ValueError('global allocation capacity exhausted: '+family)
        self.cursor[family]=number-1
        self.blocks.append(dict(owner=owner,document=document,family=family,number=number,count=count))
        return number

    def resolve(self,text):
        m=re.fullmatch(r'([A-Za-z_]\w*)(?:\[([+-]?\d+(?:\s*,\s*[+-]?\d+)*)\]\.([A-Za-z_]\w*)(?:\[([+-]?\d+(?:\s*,\s*[+-]?\d+)*)\])?)?',text)
        if not m:return None
        value=self.bindings.get(m[1].casefold())
        if value is None:return None
        if 'structure' not in value:
            if m[2] is not None:raise ValueError('indexed scalar global')
            return value
        if m[2] is None:raise ValueError('unmeasured whole-structure expression')
        indices=[int(v) for v in m[2].split(',')]
        if len(indices)!=len(value['dimensions']):raise ValueError('global structure array rank')
        relative=0
        for index,dimension in zip(indices,value['dimensions'],strict=True):
            if not dimension['lower']<=index<=dimension['upper']:raise ValueError('global structure array index outside source bounds')
            relative=relative*dimension['extent']+index-dimension['lower']
        member=value['members'].get(m[3].casefold())
        if member is None:raise ValueError('unresolved global structure member')
        member_relative=0
        if member['dimensions']:
            if m[4] is None:raise ValueError('array member requires literal indices')
            member_indices=[int(v) for v in m[4].split(',')]
            if len(member_indices)!=len(member['dimensions']):raise ValueError('structure member array rank')
            for index,dimension in zip(member_indices,member['dimensions'],strict=True):
                if not dimension['lower']<=index<=dimension['upper']:raise ValueError('structure member array index outside source bounds')
                member_relative=member_relative*dimension['extent']+index-dimension['lower']
        elif m[4] is not None:raise ValueError('indexed scalar structure member')
        family=member['family'];number=value['starts'][family]+relative*value['strides'][family]+member['offset']
        number+=member_relative*member['width']
        return dict(type=member['type'],operand=scalar(family,number),family=family,number=number,name=text)
