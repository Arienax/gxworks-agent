"""Replay original native observations using the frozen source reader only."""
from pathlib import Path
import base64
import collections
import json
from source_fx_record_reader import FXRecordReader
from source_fx_lossless_reader import FXLosslessReader
from source_fx_operand_rules import Unsupported

p = Path(__file__).resolve().parent
model, lossless = FXRecordReader(), FXLosslessReader()
counts, descriptors, header_descriptors = collections.Counter(), set(), set()
for witness in json.loads((p / 'native-synthetic-witnesses.json').read_text(encoding='utf-8')):
    raw = bytes.fromhex(witness['raw'])
    body = lossless.read(raw, cpu=witness['cpu'])
    if lossless.reconstruct(body) != raw:
        raise ValueError('A native success/refusal witness lost source bytes')
    counts['raw-round-trips'] += 1
    try:
        prediction = model.read(raw, cpu=witness['cpu'])
    except Unsupported as exc:
        if witness.get('unsupported') != str(exc) or witness['public']['code'] == 0:
            raise
        counts['explicit-unsupported'] += 1
        continue
    if witness.get('unsupported'):
        raise ValueError('Explicitly unsupported edge widened silently')
    expected = witness['prediction_before_native']
    # The path-only cleanup of the header module and equivalent decimal
    # trimming cleanup do not alter any prior prediction.
    if prediction != expected:
        raise ValueError('Frozen reader differs from prospective source prediction')
    header = witness.get('header_observation')
    if header is not None:
        predicted = prediction['header']
        if (predicted['raw_header'], predicted['result'], predicted['arity'], predicted['native_text_token']) != (header['raw'], header['result'], header['arity'], header['output']):
            raise ValueError('Native header name/arity observation differs')
        if predicted['descriptor_index'] is not None:
            header_descriptors.add(predicted['descriptor_index'])
        counts['header-exact'] += 1
    groups = witness['native_groups']
    atoms = witness['native_atoms']
    if len(groups) != len(prediction['operands']):
        raise ValueError('Native group boundary count differs')
    predicted_atoms = [a for group in prediction['operands'] for a in group['atoms']]
    if len(atoms) != len(predicted_atoms):
        raise ValueError('Native text atom call count differs')
    for predicted, native in zip(prediction['operands'], groups, strict=True):
        if (predicted['result'], predicted['consumed'], predicted['native_text_token']) != (native['result'], native['consumed'], native['output']):
            raise ValueError('Native operand result/extent/text differs')
        if (native['cpu'], native['descriptor_class']) != (witness['cpu'],32):
            raise ValueError('Unmeasured native group context')
        counts['groups-exact'] += 1
    for predicted,native in zip(predicted_atoms, atoms, strict=True):
        if (predicted['raw_token'], predicted['result'], predicted['display_bytes'], predicted['descriptor_index']) != (native['raw'], native['result'], native['output'], native['descriptor_index']):
            raise ValueError('Native operand text table observation differs')
        if native['descriptor_index'] is not None:
            descriptors.add(native['descriptor_index'])
        counts['atoms-exact'] += 1
    public = witness['public']
    if prediction['native_text_record'] is not None:
        if public['code'] != 0 or public['output'] != prediction['native_text_record']:
            raise ValueError('Independent public record decoding differs')
        counts['full-records-exact'] += 1
    elif prediction['handling'] == 'native-operand-text-refused' and public['code'] != 0:
        counts['native-refusals-exact'] += 1
    else:
        raise ValueError('Unclassified public/source reader outcome')
for witness in json.loads((p / 'opaque-preservation-witnesses.json').read_text(encoding='utf-8')):
    before = lossless.read(bytes.fromhex(witness['source_body']), cpu=witness['cpu'])
    plan = witness['patch']
    proposal = lossless.replace_same_extent_token(before, token_index=plan['token_index'], expected_raw=plan['before'], replacement_raw=plan['after'])
    if proposal != plan:
        raise ValueError('Local proposal touch span differs')
    after = lossless.read(bytes.fromhex(proposal['candidate']), cpu=witness['cpu'])
    if before != witness['before'] or after != witness['after']:
        raise ValueError('Lossless known/opaque partition differs')
    if lossless.reconstruct(after).hex() != plan['candidate']:
        raise ValueError('Changed body reconstruction differs')
    for token in before['physical_tokens']:
        if token['index'] != plan['token_index'] and token['raw'] != after['physical_tokens'][token['index']]['raw']:
            raise ValueError('Untouched physical token was rewritten')
    before_opaque = [r['raw'] for r in before['records'] if r['handling'] != 'decoded-native-record']
    after_opaque = [r['raw'] for r in after['records'] if r['handling'] != 'decoded-native-record']
    if before_opaque != after_opaque:
        raise ValueError('Opaque regions were rewritten')
    record = after['records'][after['physical_tokens'][plan['token_index']]['owner_record']]
    if witness['native_check']['code'] != 0 or witness['native_check']['status'] not in (0,1) or base64.b64decode(witness['native_check']['output_base64']).hex() != record['raw']:
        raise ValueError('Native changed-record check differs')
    if witness['native_text']['code'] != 0 or base64.b64decode(witness['native_text']['output_base64']).hex() != record['lexical_projection']['native_text_record']:
        raise ValueError('Independent changed-record text read differs')
    if witness.get('unframed_replacement_refused'):
        token = before['physical_tokens'][-1]
        try:
            lossless.replace_same_extent_token(before, token_index=token['index'], expected_raw=token['raw'], replacement_raw=token['raw'])
        except Unsupported:
            counts['unframed-edit-refused'] += 1
        else:
            raise ValueError('Unframed region became editable')
    counts['opaque-preserving-proposals'] += 1
result = dict(counts=dict(counts), reached_header_descriptors=len(header_descriptors), reached_text_descriptors=sorted(descriptors))
expected = json.loads((p / 'expected-replay.json').read_text(encoding='utf-8'))
if expected is not None and result != expected:
    raise ValueError('Frozen native witness coverage differs')
print(json.dumps(result, ensure_ascii=True))
