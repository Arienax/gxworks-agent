"""Bind native header and lexical operand projections to an unchanged record."""
from source_fx_header_reader import FXHeaderReader
from source_fx_operand_reader import FXOperandReader
from source_fx_operand_rules import Unsupported


class FXRecordReader:
    def __init__(self, header_tables=None, operand_tables=None):
        self.headers = FXHeaderReader(header_tables)
        self.operands = FXOperandReader(operand_tables)

    def read(self, raw, *, cpu=521):
        if not raw or raw[0] < 2 or raw[0] > len(raw):
            raise Unsupported('Instruction header outside owned record')
        header = self.headers.read(raw[:raw[0]])
        result = dict(raw_record=raw.hex(), cpu=cpu, header=header, operands=[],
                      handling='native-header-refused', native_text_record=None)
        if header['result'] < 0:
            return result
        offset = raw[0]
        output = bytes.fromhex(header['native_text_token'])
        for i in range(header['arity']):
            if offset == len(raw):
                return result | dict(handling='partially-decoded/missing-operands', missing_operands=header['arity'] - i)
            operand = self.operands.read(raw[offset:], cpu=cpu)
            result['operands'].append(dict(offset=offset, **operand))
            if operand['result'] <= 0:
                return result | dict(handling='native-operand-text-refused')
            offset += operand['consumed']
            output += bytes.fromhex(operand['native_text_token'])
        if offset != len(raw):
            return result | dict(handling='partially-decoded/extra-tokens', extra_raw=raw[offset:].hex())
        return result | dict(handling='decoded-native-record', native_text_record=(output + b'\0').hex(),
                             consumed=offset, name=header['name'], arity=header['arity'])
