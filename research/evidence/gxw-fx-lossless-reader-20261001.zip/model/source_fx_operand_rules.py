"""Bounded FX 15.31 CPU 521 model of two inspected type-check routines.

These predicates reproduce one native layer. Passing them is not a claim
about numeric ranges, whole instructions, project validity or runtime effects.
"""
from pathlib import Path
import collections
import json
import struct

P = Path(__file__).resolve().parent
TABLE_PATH = P / 'fx-operand-rule-encode-trace-20261001-v1/static-tables-before-native.json'


class Unsupported(ValueError):
    pass


class FXOperandRules:
    def __init__(self, tables=None):
        self.tables = tables if tables is not None else json.loads(TABLE_PATH.read_text(encoding='utf-8'))
        if (self.tables['file_version'], self.tables['cpu'], self.tables['cpu_class']) != ('15.31', 521, 32):
            raise Unsupported('Unmeasured converter context')
        self.rows = self.tables['map_rows']
        self.roles = self.tables['roles']
        self.capabilities = self.tables['capabilities']

    def capability(self, raw):
        """Return native short status and the mutated nine bytes, even on failure."""
        if len(raw) != 9 or not 0x90 <= raw[6] <= 0xff:
            raise Unsupported('Unmeasured nine-byte descriptor')
        d = bytearray(raw)
        if d[6] in (0xdf, 0xad):
            return 0, bytes(d)
        info = self.capabilities[str(d[6])]
        cap, flags = info['capabilities'], info['flags']
        def result(status):
            struct.pack_into('<H', d, 7, flags)
            return status, bytes(d)
        if d[0] != 0xff:
            return result(-1)
        if d[5] != 0xff:  # CPU 521 rejects bit selectors at this layer.
            return result(-1)
        if d[3] != 0xff:
            if not flags & 1 or not cap & 0x10:
                return result(-1)
            if d[3] <= 4:
                flags = 2
            elif d[3] <= 8:
                flags = 4
            else:
                raise Unsupported('Digit group above the measured lexical range')
        if d[4] != 0xff and not cap & 2:
            return result(-1)
        if d[1]:  # CPU 521 rejects prefixed operands.
            return result(-1)
        if d[3] == 0xff and d[5] == 0xff:
            flags |= 0x40
        if d[3] == d[4] == d[5] == 0xff:
            flags |= 0x80
        return result(0)

    def rule(self, family, variant, index, descriptors):
        """Return the exact inspected rule status and the decision provenance."""
        if not 1 <= index <= 8 or len(descriptors) != index * 9:
            raise Unsupported('Unmeasured rule index or descriptor framing')
        d = descriptors[(index - 1) * 9:index * 9]
        code = d[6]
        if code in (0xad, 0xe7):
            return 0, dict(handling='opaque-bypass', base_code=code)
        if family == 0x3c:
            return (0 if code in (0xd0, 0xd1, 0xdf) else -1), dict(handling='special-label-path')
        flags = struct.unpack_from('<H', d, 7)[0]
        ordinary = False
        decisions = []
        cursor = 0
        excluded = {0x98, 0x99, 0x9e, 0x9f, 0xaa, 0xad, 0xcc, 0xd2, *range(0xe8, 0xef)}
        def answer(status, reason):
            return status, dict(handling='decoded-type-layer', reason=reason, alternatives=decisions)
        while cursor < len(self.rows):
            while cursor < len(self.rows):
                row = self.rows[cursor]
                if row['family'] == family and (family <= 0x3f or row['variant'] == variant):
                    break
                cursor += 1
            if cursor >= len(self.rows):
                return answer(-3, 'no further matching schema')
            row = self.rows[cursor]
            if row['schema_offset'] == 0x7fff:
                return answer(-3, 'explicit unsupported schema')
            if index > row['arity']:
                return answer(-2, 'operand exceeds schema arity')
            role = row['roles'][index - 1]
            mask = self.roles[str(role)]
            allowed = set(mask['allowed_codes'])
            ordinary |= bool(allowed - excluded)
            decisions.append(dict(map_index=cursor, schema_offset=row['schema_offset'], role=role))
            if ordinary and code == 0xdf:
                return answer(0, 'opaque ordinary-device bypass')
            if family == 0x21 and index == 2 and mask['flags'] == 0xffff and descriptors[14] != 0xff:
                return answer(-1, 'special second OUT operand bit selector')
            if mask['flags'] & flags:
                if mask['flags'] != 0xffff and mask['flags'] & 4 and code in (0xe8, 0xea):
                    return answer(-4, 'word literal requires double-word form')
                effective = d[1] or code
                if not 0x90 <= effective <= 0xff:
                    raise Unsupported('Device bitmap index outside inspected range')
                if effective in allowed:
                    return answer(0, 'flags and device bitmap match')
            cursor += 1
            # This distinct native branch precedes the search loop and is kept
            # literally; the final row is the raw all-zero sentinel.
            if cursor >= len(self.rows) - 1:
                return answer(0, 'native end-of-map fallthrough')
        return answer(-3, 'search exhausted')

    def plain(self, code, *, group=0xff, index=0xff, prefix=0, prefix_index=0xff,
              bit=0xff, indirect=0xff):
        return bytes([indirect, prefix, prefix_index, group, index, bit, code, 0, 0])

    def compare_events(self, path):
        counts, matches, statuses = collections.Counter(), collections.Counter(), collections.Counter()
        failures, gaps, coverage = [], [], set()
        role_ids = set()
        for line in path.read_text(encoding='utf-8').splitlines():
            packet = json.loads(line)
            if packet['type'] != 'send':
                failures.append(packet)
                continue
            e = packet['payload']
            kind = e['event']
            if kind not in ('operand-capability', 'operand-rule'):
                continue
            counts[kind] += 1
            statuses[f'{kind}:{e["result"]}'] += 1
            if (e['cpu'], e['cpu_class']) != (521, 32):
                gaps.append(dict(native=e, reason='Unmeasured converter context'))
                continue
            try:
                if kind == 'operand-capability':
                    status, after = self.capability(bytes.fromhex(e['before']))
                    equal = status == e['result'] and after.hex() == e['after']
                    prediction = dict(status=status, after=after.hex())
                else:
                    status, provenance = self.rule(e['family'], e['variant'], e['index'], bytes.fromhex(e['descriptors']))
                    equal = status == e['result']
                    prediction = dict(status=status, provenance=provenance)
                    coverage.add((e['family'], e['variant']))
                    role_ids.update(d['role'] for d in provenance.get('alternatives', []))
                if equal:
                    matches[kind] += 1
                else:
                    failures.append(dict(native=e, prediction=prediction))
            except Unsupported as exc:
                gaps.append(dict(native=e, reason=str(exc)))
        return dict(counts=dict(counts), matched=dict(matches), native_statuses=dict(statuses),
                    instruction_keys=[list(k) for k in sorted(coverage)], reached_roles=sorted(role_ids),
                    failures=failures, unsupported=gaps)


if __name__ == '__main__':
    import sys
    model = FXOperandRules()
    path = Path(sys.argv[1]) if len(sys.argv) > 1 else P / 'fx-operand-rule-encode-trace-20261001-v1/events.jsonl'
    result = model.compare_events(path)
    destination = path.parent / 'model-boundary-comparison.json'
    if destination.exists():
        raise FileExistsError('Prior model evidence must not be replaced')
    destination.write_text(json.dumps(result, indent=2, ensure_ascii=True) + '\n', encoding='utf-8')
    print(json.dumps({k:(len(v) if k in ('instruction_keys', 'reached_roles', 'failures', 'unsupported') else v)
                      for k, v in result.items()}, ensure_ascii=True))
    if result['failures']:
        raise ValueError('Model/native boundary mismatch retained')
