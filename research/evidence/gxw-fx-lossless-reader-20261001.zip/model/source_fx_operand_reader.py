"""Inspected FX lexical reader; all source tokens remain independently bound.

Display text can round, truncate or omit raw values/modifiers. It is never an
input to reconstruction, role validation or a writer.
"""
import json
import math
import struct
from decimal import Decimal
from pathlib import Path

from source_fx_operand_rules import Unsupported

P = Path(__file__).resolve().parent


def framed_token(raw, offset=0):
    if offset + 2 > len(raw):
        raise Unsupported('Incomplete lexical token')
    n = raw[offset]
    if n < 3 or offset + n > len(raw) or raw[offset + n - 1] != n:
        raise Unsupported('Token outside preserved lexical framing')
    return raw[offset:offset + n]


def native_float_text(payload, *, scientific):
    if len(payload) != 4:
        raise Unsupported('Float outside inspected four-byte payload')
    bits = int.from_bytes(payload, 'little')
    value = struct.unpack('<f', payload)[0]
    if not math.isfinite(value):
        return None
    if value == 0:
        return '0.0' if scientific else ('0' if bits == 0 else None)
    mantissa, exponent = format(value, '.6e').split('e')
    exponent = int(exponent)
    if scientific:
        mantissa = mantissa.rstrip('0').rstrip('.')
        if '.' not in mantissa:
            mantissa += '.0'
        return mantissa + (format(exponent, '+d') if exponent else '')
    if not -10 <= exponent <= 11:
        return None
    if exponent < -4:
        text = format(value, '.10f')
        if not any(c in '123456789' for c in text):
            text = text[:-1] + '1'
        return text.rstrip('0').rstrip('.')
    text = format(Decimal(mantissa + 'e' + str(exponent)), 'f')
    return text.rstrip('0').rstrip('.') if '.' in text else text


class FXOperandReader:
    def __init__(self, tables=None):
        self.tables = tables if tables is not None else json.loads((P / 'fx-operand-reader-tables-20261001-v1.json').read_text(encoding='utf-8'))
        if (self.tables['file_version'], self.tables['descriptor_class']) != ('15.31', 32):
            raise Unsupported('Unmeasured operand text descriptor class')
        self.lookup = bytes.fromhex(self.tables['lookup_raw'])

    def atom(self, token):
        """RVA 3d514 returns the text extent before its final NUL."""
        token = framed_token(token)
        code, payload = token[1], token[2:-1]
        result = dict(raw_token=token.hex(), code=code, descriptor_index=None,
                      display_bytes=None, result=-5)
        if code in (0xdf, 0xee):
            if len(payload) > 64 or b'\0' in payload[:-1]:
                raise Unsupported('String extent/interior NUL outside deterministic owned output model')
            if code == 0xdf:
                text = b"'" + payload
            else:
                text = b'"' + payload.removesuffix(b'\0') + b'"'
            return result | dict(result=len(text), display_bytes=text.hex(), handling='raw-string-bytes-preserved')
        if not 0x90 <= code <= 0xf8:
            raise Unsupported('Operand name edge outside inspected descriptor domain')
        index = self.lookup[code - 0x90]
        if index == 255:
            return result | dict(handling='native-operand-text-refused')
        row = self.tables['rows'][index]
        result['descriptor_index'] = index
        mode, prefix = row['format'], row['prefix']
        if mode == 6:
            text = prefix
        elif mode in (2, 3):
            number = native_float_text(payload, scientific=mode == 3)
            if number is None:
                return result | dict(handling='native-float-display-refused')
            text = prefix + number
        elif mode in (0, 1, 4, 7):
            if not 1 <= len(payload) <= 4:
                raise Unsupported('Numeric token outside inspected one-to-four-byte payload')
            number = int.from_bytes(payload, 'little')
            if mode == 1:
                # The word literal reader consumes at most the first WORD,
                # even if the framed raw token carries further value bytes.
                if code == 0xe8:
                    number = number & 65535
                    if len(payload) != 1 and number >= 32768:
                        number -= 65536
                elif len(payload) == 4 and number >= 0x80000000:
                    number -= 0x100000000
                digits = str(number)
            elif mode == 4:
                digits = format(number, 'X')
                if code != 0xf2 and digits[0] in 'ABCDEF':
                    digits = '0' + digits
            elif mode == 7:
                digits = format(number, '03o')
            else:
                digits = str(number)
            text = prefix + digits
        else:
            raise Unsupported('Uninterpreted descriptor text format')
        raw_text = text.encode('ascii')
        return result | dict(result=len(raw_text), display_bytes=raw_text.hex(),
                             handling='opaque-native-name' if mode == 6 else 'decoded-native-text-atom')

    def read(self, raw, *, cpu=521):
        """RVA 3d7b9 groups raw tokens without using type-parser assumptions."""
        if cpu not in (520, 521):
            raise Unsupported('Unmeasured lexical reader CPU')
        offset, index, bit, text, tokens, atoms = 0, None, None, b'', [], []
        while offset < len(raw) and raw[offset] != 0:
            token = framed_token(raw, offset)
            code = token[1]
            tokens.append(dict(offset=offset, raw=token.hex()))
            if len(tokens) > 12:
                raise Unsupported('Operand chain outside bounded reader experiment')
            if code in (0xf0, 0xf4):
                index = token
            elif code == 0xf2:
                bit = token
            elif code in (0xf1, 0xf3):
                atom = self.atom(token)
                atoms.append(atom)
                if atom['result'] <= 0:
                    return dict(result=atom['result'], consumed=None, native_text_token='', tokens=tokens, atoms=atoms, handling='native-operand-text-refused')
                text += bytes.fromhex(atom['display_bytes'])
            elif 0x90 <= code <= 0xef or 0xf8 <= code <= 0xff:
                for part in (token, index, bit):
                    if part is None:
                        continue
                    atom = self.atom(part)
                    atoms.append(atom)
                    if atom['result'] <= 0:
                        return dict(result=atom['result'], consumed=None, native_text_token='', tokens=tokens, atoms=atoms, handling='native-operand-text-refused')
                    text += bytes.fromhex(atom['display_bytes'])
                index = bit = None
                if code >= 0xf8:
                    text += b'\\'
                else:
                    extent = len(text) + 3
                    if extent > 255:
                        raise Unsupported('Native BYTE text extent outside bounded projection')
                    output = bytes([extent, code]) + text + b'\0'
                    printable = all(32 <= c <= 126 for c in text)
                    return dict(result=extent, consumed=offset + len(token), raw_operand=raw[:offset + len(token)].hex(),
                                native_text_token=output.hex(), text=text.decode('ascii') if printable else None,
                                tokens=tokens, atoms=atoms, handling='decoded-native-operand' if printable else 'raw-display-bytes-preserved')
            else:
                return dict(result=-5, consumed=None, native_text_token='', tokens=tokens, atoms=atoms, handling='native-operand-text-refused')
            offset += len(token)
        return dict(result=-5, consumed=None, native_text_token='', tokens=tokens, atoms=atoms, handling='native-modifier-chain-without-base')
