"""Inspected class-20 PCode header reader, retaining raw header identity."""
import json
from pathlib import Path

from source_fx_operand_rules import Unsupported

P = Path(__file__).resolve().parent


class FXHeaderReader:
    def __init__(self, tables=None):
        self.tables = tables if tables is not None else json.loads((P / 'fx-native-instruction-catalog-20261001-v1/before-native.json').read_text(encoding='utf-8'))
        if (self.tables['file_version'], self.tables['static_cpu_class']) != ('15.31', 32):
            raise Unsupported('Unmeasured native header descriptor class')
        self.edges = {(r['family'], r['variant']):r['expected'] for r in self.tables['queries']}

    def read(self, raw):
        if len(raw) < 2 or raw[0] != len(raw):
            raise Unsupported('Unframed native opcode header')
        family = raw[1]
        result = dict(raw_header=raw.hex(), descriptor_class=32, family=family, arity=0,
                      variant=None, extra=None, descriptor_index=None, name=None)
        if len(raw) == 2:
            return result | dict(result=6, native_text_token='063b4e4f5000', name='NOP', handling='decoded-native-header')
        if family == 0x3c:
            return result | dict(result=0, arity=1, native_text_token='', handling='label-header/no-native-mnemonic-write')
        if family == 0x3f:
            return result | dict(result=2, native_text_token='023f', handling='native-raw-marker/no-mnemonic')
        variant = raw[3] if len(raw) >= 5 else 0
        extra = raw[4] if len(raw) >= 6 else 255
        result.update(variant=variant, extra=extra)
        if (family, variant) not in self.edges:
            raise Unsupported('Header edge outside inspected class-20 prefix graph')
        descriptor = self.edges[(family, variant)]
        if descriptor is None:
            return result | dict(result=-4, native_text_token='', handling='native-header-refused')
        name = descriptor['name']
        arity = descriptor['uninterpreted_fields'][0]
        result.update(arity=arity, descriptor_index=descriptor['index'])
        dot = len(name) >= 2 and name[1] == '.'
        if dot and len(raw) < 6:
            raise Unsupported('Dot header lacks its bounded embedded-name envelope')
        payload = raw[5:-1] if dot else b''
        if b'\0' in payload:
            raise Unsupported('Embedded NUL can leave unspecified native output bytes')
        if extra == 2:
            text = name[0].encode('ascii') + b'P.' + payload if dot else name.encode('ascii') + b'P'
        elif extra in (16, 17, 18):
            text = {16:b'LD', 17:b'AND', 18:b'OR'}[extra] + name.encode('ascii')
        else:
            text = name.removeprefix(',').encode('ascii') + payload
        token = bytes([len(text) + 3, family]) + text + b'\0'
        # Raw embedded names are bytes; only printable ASCII is projected as
        # text. The raw header and text token remain exact either way.
        printable = all(32 <= c <= 126 for c in text)
        return result | dict(result=len(token), native_text_token=token.hex(),
                             name=text.decode('ascii') if printable else None,
                             handling='decoded-native-header' if printable else 'raw-name-preserved')
