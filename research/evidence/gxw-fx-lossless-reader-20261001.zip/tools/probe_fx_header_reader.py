"""Source-only full catalog/header predictions versus original public decode."""
import base64
import collections
import json
import os
import subprocess

from probe_fx_operand_rules import DLL, P, save, traced_run
from source_fx_header_reader import FXHeaderReader
from source_fx_operand_rules import Unsupported


def requests_for_reader():
    rows = []
    def add(cpu, raw, provenance):
        rows.append(dict(id=len(rows), cpu=cpu, raw=raw.hex(), raw_header=raw[:raw[0]].hex(),
                         input_base64=base64.b64encode(raw).decode(), provenance=provenance))
    for name, cpu in [('fx-machine-step-emission-full-corpus-20261001-v1', 521), ('fx3u-original-machine-corpus-20261001-v1', 520)]:
        for request in json.loads((P / name / 'before-native.json').read_text(encoding='utf-8'))['requests']:
            add(cpu, bytes.fromhex(request['raw']), dict(origin=name, id=request['id']))
    catalog = json.loads((P / 'fx-native-instruction-catalog-20261001-v1/before-native.json').read_text(encoding='utf-8'))
    for descriptor in catalog['rows'][:-1]:
        arity, family, variant = descriptor['uninterpreted_fields'][:3]
        operands = b''.join(bytes.fromhex('04a86404') for _ in range(arity))
        if descriptor['name'] in ('M.', 'U.'):
            text = b'UnitFn17'
            for extra in (0, 2):
                header = bytes([6 + len(text), family, 7, variant, extra]) + text + bytes([6 + len(text)])
                add(521, header + operands, dict(descriptor=descriptor['index'], shape='embedded-name', extra=extra))
        else:
            if family < 0x40:
                headers = [bytes([3, family, 3]), bytes([4, family, 7, 4])]
            else:
                headers = [bytes([5, family, 7, variant, 5]), bytes([6, family, 7, variant, 2, 6])]
                if family == 0x40:
                    headers += [bytes([6, family, 7, variant, extra, 6]) for extra in (16, 17, 18)]
            for header in headers:
                add(521, header + operands, dict(descriptor=descriptor['index'], shape='ordinary', header=header.hex()))
    for raw in (b'\x02\x02', b'\x02\x7f', bytes.fromhex('033f03'), bytes.fromhex('037703')):
        add(521, raw, dict(shape='bounded-special-header'))
    return rows


def main():
    out = P / 'fx-header-reader-20261001-v1'
    out.mkdir()
    rows, model = requests_for_reader(), FXHeaderReader()
    predictions, gaps = {}, []
    for row in rows:
        try:
            predictions[str(row['id'])] = model.read(bytes.fromhex(row['raw_header']))
        except Unsupported as exc:
            gaps.append(dict(id=row['id'], raw_header=row['raw_header'], reason=str(exc)))
    save(out / 'before-native.json', dict(contexts=[dict(cpu=520, mode=0), dict(cpu=521, mode=0)], file_version='15.31',
        descriptor_class=32, versions=[], requests=rows,
        scope='Header names/argument counts only. Fresh object for every public read; copied original PCode and synthetic known catalog headers. No type, project or execution acceptance inferred.'))
    save(out / 'predictions-before-native.json', predictions)
    save(out / 'source-generation-gaps.json', gaps)
    for name in ('source_fx_header_reader.py', 'probe_fx_header_reader.py', 'FXReadRecordOracle.cs', 'TraceFXHeaderReader.js'):
        (out / name).write_bytes((P / name).read_bytes())
    (out / 'static-descriptors-before-native.json').write_bytes((P / 'fx-native-instruction-catalog-20261001-v1/before-native.json').read_bytes())
    (out / 'requests.tsv').write_text('\n'.join(f'{r["id"]}\t{r["cpu"]}\t{r["input_base64"]}' for r in rows) + '\n', encoding='ascii')
    exe = out / 'FXReadRecordOracle.exe'
    build = subprocess.run([str(os.path.join(os.environ['WINDIR'], 'Microsoft.NET/Framework/v4.0.30319/csc.exe')),
                            '/nologo', '/platform:x86', '/out:' + str(exe), str(out / 'FXReadRecordOracle.cs')],
                           capture_output=True, timeout=30, creationflags=subprocess.CREATE_NO_WINDOW)
    (out / 'build.txt').write_bytes(build.stdout + build.stderr)
    if build.returncode:
        raise RuntimeError('Owned header-reader helper build failed')
    args = [str(exe), str(DLL), str(out / 'requests.tsv'), str(out / 'baseline.jsonl')]
    baseline = subprocess.run(args, capture_output=True, timeout=45, creationflags=subprocess.CREATE_NO_WINDOW)
    (out / 'baseline-stdout.bin').write_bytes(baseline.stdout)
    (out / 'baseline-stderr.bin').write_bytes(baseline.stderr)
    save(out / 'baseline-process.json', dict(returncode=baseline.returncode))
    if baseline.returncode:
        raise RuntimeError('Owned public header read failed; observations retained')
    traced_run(args[:-1] + [str(out / 'traced.jsonl')], (out / 'TraceFXHeaderReader.js').read_text(encoding='utf-8'), out)
    observations, errors = collections.defaultdict(list), []
    for line in (out / 'events.jsonl').read_text(encoding='utf-8').splitlines():
        packet = json.loads(line)
        if packet['type'] != 'send':
            errors.append(packet)
        else:
            event = packet['payload']
            if event['event'] == 'header-reader':
                observations[event['request']].append(event)
    answers = [json.loads(l) for l in (out / 'baseline.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    if len(answers) != len(rows):
        raise ValueError('Header-reader public request count differs')
    comparisons, differences, unavailable, counts, descriptors = [], [], [], collections.Counter(), set()
    for row, answer in zip(rows, answers, strict=True):
        if row['id'] != answer['id'] or row['cpu'] != answer['cpu']:
            raise ValueError('Public header reader framing differs')
        events = observations[row['id']]
        predicted = predictions.get(str(row['id']))
        if len(events) != 1 or predicted is None:
            unavailable.append(dict(id=row['id'], native=events, public_code=answer['code'], prediction=predicted))
            continue
        native = events[0]
        same = dict(raw=predicted['raw_header'] == native['raw'], result=predicted['result'] == native['result'],
                    arity=predicted['arity'] == native['arity'], native_text_token=predicted['native_text_token'] == native['output'],
                    context=native['cpu'] == row['cpu'] and native['descriptor_class'] == 32)
        comparison = dict(id=row['id'], predicted=predicted, native=native, matches=same, public_code=answer['code'])
        comparisons.append(comparison)
        counts['observed'] += 1
        for key, value in same.items():
            counts[key] += value
        if predicted['descriptor_index'] is not None:
            descriptors.add(predicted['descriptor_index'])
        if not all(same.values()):
            differences.append(comparison)
    save(out / 'header-comparisons.json', comparisons)
    save(out / 'differences.json', differences)
    save(out / 'no-header-observation.json', unavailable)
    summary = dict(requests=len(rows), predictions=len(predictions), source_generation_gaps=len(gaps), counts=dict(counts),
        reached_descriptors=len(descriptors), differences=len(differences), unavailable=len(unavailable),
        public_codes=dict(collections.Counter(a['code'] for a in answers)),
        all_guards_intact=all(a['guards_intact'] for a in answers), all_original_inputs_preserved=all(a['input_preserved'] for a in answers),
        baseline_traced_exact=(out / 'baseline.jsonl').read_bytes() == (out / 'traced.jsonl').read_bytes(), hook_errors=errors,
        scope='Predictions and model snapshots precede native calls. Original header reader invoked by public read only; no replacement/private native calls. Header arity/name is a lexical projection; public full record failures retained separately.')
    save(out / 'comparison.json', summary)
    print(json.dumps(summary, ensure_ascii=True), flush=True)
    if differences or errors or not summary['baseline_traced_exact']:
        raise ValueError('Native header-reader differences retained')


if __name__ == '__main__':
    main()
