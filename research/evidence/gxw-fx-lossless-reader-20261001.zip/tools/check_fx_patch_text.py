"""Independent public read of previously predicted local byte proposals."""
import base64
import json
import subprocess

from probe_fx_operand_rules import DLL, P, save


def main():
    origin = P / 'fx-lossless-patch-20261001-v1'
    out = origin / 'independent-text-read'
    out.mkdir()
    rows = json.loads((origin / 'before-native.json').read_text(encoding='utf-8'))['requests']
    (out / 'requests.tsv').write_text('\n'.join(f'{r["id"]}\t{r["cpu"]}\t{r["input_base64"]}' for r in rows) + '\n', encoding='ascii')
    save(out / 'predictions-before-native.json', [dict(id=r['id'], cpu=r['cpu'], raw=r['raw'], native_text_record=r['after_text']) for r in rows])
    exe = P / 'fx-header-reader-20261001-v1/FXReadRecordOracle.exe'
    process = subprocess.run([str(exe), str(DLL), str(out / 'requests.tsv'), str(out / 'answers.jsonl')],
                             capture_output=True, timeout=30, creationflags=subprocess.CREATE_NO_WINDOW)
    (out / 'stdout.bin').write_bytes(process.stdout)
    (out / 'stderr.bin').write_bytes(process.stderr)
    if process.returncode:
        raise RuntimeError('Owned changed-record text read failed')
    answers = [json.loads(line) for line in (out / 'answers.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    comparisons = []
    for row, answer in zip(rows, answers, strict=True):
        same = answer['id'] == row['id'] and answer['cpu'] == row['cpu'] and answer['code'] == 0 and answer['guards_intact'] and answer['input_preserved'] and base64.b64decode(answer['output_base64']).hex() == row['after_text']
        comparisons.append(dict(id=row['id'], case=row['case'], exact=same, original_native_read=answer))
    save(out / 'comparisons.json', comparisons)
    result = dict(changed_record_reads=len(rows), native_text_exact=sum(r['exact'] for r in comparisons), predictions_precede_native=True,
                  scope='Fresh public PCode-to-text reads of the local changed records; whole GXW acceptance remains separate.')
    save(out / 'comparison.json', result)
    (out / 'check_fx_patch_text.py').write_bytes((P / 'check_fx_patch_text.py').read_bytes())
    print(json.dumps(result, ensure_ascii=True))
    if not all(r['exact'] for r in comparisons):
        raise ValueError('Changed-record independent text differences retained')


if __name__ == '__main__':
    main()
