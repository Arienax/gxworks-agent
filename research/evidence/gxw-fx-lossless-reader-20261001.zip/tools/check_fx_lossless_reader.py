"""Whole copied compiler bodies versus independent native record output."""
import base64
import collections
import json
from pathlib import Path

from probe_fx_operand_rules import P, save
from source_fx_lossless_reader import FXLosslessReader


def main():
    out = P / 'fx-lossless-reader-original-corpus-20261001-v1'
    out.mkdir()
    oracle_dir = P / 'fx-header-reader-20261001-v1'
    oracle_rows = json.loads((oracle_dir / 'before-native.json').read_text(encoding='utf-8'))['requests']
    answers = [json.loads(line) for line in (oracle_dir / 'baseline.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    native = {}
    for row, answer in zip(oracle_rows, answers, strict=True):
        origin = row['provenance'].get('origin')
        if origin:
            native[(origin, row['provenance']['id'])] = dict(raw=row['raw'], code=answer['code'], text=base64.b64decode(answer['output_base64']).hex())
    full_name = 'fx-machine-step-emission-full-corpus-20261001-v1'
    full = json.loads((P / full_name / 'before-native.json').read_text(encoding='utf-8'))
    # File resolution is explicit; source offsets and the actual compiler body
    # are checked independently of record framing and the semantic reader.
    full_path = Path(full['source_project']) / 'native-1/pcode-0-0.bin'
    projects = [dict(case='full-fx3g', cpu=521, repository='accepted copied FX3G source',
                     local_compiled_body=str(full_path), origin=full_name, requests=full['requests'])]
    mode8_name = 'fx3u-original-machine-corpus-20261001-v1'
    mode8 = json.loads((P / mode8_name / 'before-native.json').read_text(encoding='utf-8'))
    for project in mode8['projects']:
        projects.append(dict(**project, cpu=520, origin=mode8_name,
                             requests=[r for r in mode8['requests'] if r['case'] == project['case']]))
    model = FXLosslessReader()
    comparisons, differences, corpus = [], [], collections.Counter()
    for project in projects:
        body = Path(project['local_compiled_body']).read_bytes()
        result = model.read(body, cpu=project['cpu'])
        expected = {r['offset']:r for r in project['requests']}
        decoded = [r for r in result['records'] if r['handling'] == 'decoded-native-record']
        exact = 0
        for record in decoded:
            request = expected.get(record['offset'])
            observation = None if request is None else native[(project['origin'], request['id'])]
            same = observation is not None and request['raw'] == record['raw'] == observation['raw'] and observation['code'] == 0 and record['lexical_projection']['native_text_record'] == observation['text']
            exact += same
            if not same:
                differences.append(dict(case=project['case'], offset=record['offset'], raw=record['raw'], native=observation))
        if len(decoded) != len(expected) or result['coverage']['critical_gaps']:
            differences.append(dict(case=project['case'], coverage=result['coverage'], expected_records=len(expected)))
        result.update(provenance={k:v for k,v in project.items() if k != 'requests'}, round_trip='byte-identical', native_text_exact=exact)
        save(out / (project['case'] + '.json'), result)
        comparisons.append(dict(case=project['case'], cpu=project['cpu'], repository=project['repository'],
                                coverage=result['coverage'], native_text_exact=exact, byte_identical=True))
        corpus.update(result['coverage'])
    save(out / 'differences.json', differences)
    summary = dict(projects=len(projects), comparisons=comparisons, total=dict(corpus), differences=len(differences),
                   all_round_trips_byte_identical=True, all_instruction_text_native_exact=not differences,
                   scope='Whole compiler bodies and source-bound physical offsets, not re-encoded strings. Original metadata is opaque-preserved. Full FX3G is an accepted copied variant, seven FX3U projects are original independent sources. No new project mutation or PLC execution.')
    save(out / 'comparison.json', summary)
    (out / 'source_fx_lossless_reader.py').write_bytes((P / 'source_fx_lossless_reader.py').read_bytes())
    (out / 'check_fx_lossless_reader.py').write_bytes((P / 'check_fx_lossless_reader.py').read_bytes())
    print(json.dumps(summary, ensure_ascii=True), flush=True)
    if differences:
        raise ValueError('Whole-body native annotation differences retained')


if __name__ == '__main__':
    main()
