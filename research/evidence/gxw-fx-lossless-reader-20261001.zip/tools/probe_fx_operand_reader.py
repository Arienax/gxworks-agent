"""Prospective lexical reader boundaries, with independent public decode."""
import base64
import collections
import json
import os
import random
import struct
import subprocess

from extract_fx_reader_tables import extract
from probe_fx_operand_rules import DLL, P, save, traced_run
from source_fx_record_reader import FXRecordReader
from source_fx_operand_rules import Unsupported


def requests_for_reader():
    rows = []
    def add(cpu, raw, provenance):
        rows.append(dict(id=len(rows), cpu=cpu, raw=raw.hex(), input_base64=base64.b64encode(raw).decode(), provenance=provenance))
    prior = json.loads((P / 'fx-header-reader-20261001-v1/before-native.json').read_text(encoding='utf-8'))
    for row in prior['requests']:
        add(row['cpu'], bytes.fromhex(row['raw']), dict(origin='prior-header-reader', prior_id=row['id']))
    def token(code, payload):
        n = len(payload) + 3
        return bytes([n, code]) + payload + bytes([n])
    def numeric(code, width, value):
        return token(code, value.to_bytes(width, 'little'))
    def operand(raw, source):
        add(521, bytes.fromhex('030003') + raw, source)
    tables = extract()
    value_edges = (0, 1, 7, 8, 15, 16, 127, 128, 255, 256, 32767, 32768,
                   65535, 65536, 0x7fffff, 0xffffff, 0x7fffffff, 0x80000000, 0xffffffff)
    for row in tables['rows']:
        code = row['code']
        if code >= 0xf0 or row['format'] not in (0, 1, 4, 6, 7):
            continue
        for width in (1, 2, 3, 4):
            for value in value_edges:
                if value < 1 << (8 * width):
                    operand(numeric(code, width, value), dict(shape='numeric-value-boundary', descriptor=row['index'], code=code, width=width, value=value))
    float_bits = {0, 0x80000000, 1, 0x80000001, 0x007fffff, 0x00800000,
                  0x7f7fffff, 0x7f800000, 0x7fc00000, 0xff800000, 0xffc00000}
    for value in (1/3, 999.99995, 16777217.0, 1.2345675, 9.9999995):
        bits = int.from_bytes(struct.pack('<f', value), 'little')
        float_bits.update((bits - 1, bits, bits + 1))
    for power in (-38, -11, -10, -5, -4, -1, 0, 1, 5, 6, 11, 12, 38):
        for value in (10.0**power, 1.234567 * 10.0**power):
            bits = int.from_bytes(struct.pack('<f', value), 'little')
            float_bits.update((bits - 1, bits, bits + 1))
    rng = random.Random(20261001)
    float_bits.update(rng.getrandbits(31) for _ in range(64))
    float_bits |= {bits | 0x80000000 for bits in tuple(float_bits)}
    for code in (0xec, 0xed):
        for bits in sorted(float_bits):
            operand(token(code, bits.to_bytes(4, 'little')), dict(shape='float-display-boundary', code=code, bits=bits))
    for code in (0xdf, 0xee):
        for payload in (b'', b'\0', b'A', b'Hello', b'Hello\0', b'"a"', b'line\r\nend',
                        bytes.fromhex('b2e2cad4'), b'A'*32, b'A'*33):
            # Empty raw payload would give a three-byte token; native text
            # code handles it, but the structured type parser does not.
            operand(token(code, payload), dict(shape='raw-text-payload', code=code, payload=payload.hex()))
    for code in range(0x90, 0xf0):
        if code in (0xdf, 0xee) or tables['lookup_raw'][2*(code-0x90):2*(code-0x90)+2] != 'ff':
            continue
        operand(numeric(code, 1, 17), dict(shape='unmapped-text-descriptor', code=code))
    base = numeric(0xa8, 2, 1234)
    for code in (0xf0, 0xf1, 0xf2, 0xf4):
        for width in (1, 2, 3, 4):
            for value in (0, 1, 7, 8, 15, 255, 256, 65535):
                if value < 1 << (8 * width):
                    operand(numeric(code, width, value) + base, dict(shape='modifier-value-boundary', code=code, width=width, value=value))
    z, v, group, bit, unit = [numeric(code, 1, value) for code, value in [(0xf0, 3), (0xf4, 5), (0xf1, 4), (0xf2, 10), (0xf8, 7)]]
    modifier_sequences = [z+v, v+z, z+z, bit+bit, group+group, z+bit, bit+z,
                          group+z+bit, bit+z+group, z+group+v+bit,
                          group+unit+z, z+unit+v, bit+unit+bit, unit+unit,
                          z+bit+unit+v+group+bit, numeric(0xf3, 1, 0)]
    for i, raw in enumerate(modifier_sequences):
        for code in (0x90, 0xa8, 0xab, 0xe8, 0xee):
            payload = b'ABC' if code == 0xee else b'\x64'
            operand(raw + token(code, payload), dict(shape='ordered-modifier-chain', sequence=i, base_code=code))
    for code in (0xf0, 0xf1, 0xf2, 0xf3, 0xf4, 0xf8):
        operand(numeric(code, 1, 1), dict(shape='modifier-without-base', code=code))
    return rows, tables


def main():
    out = P / 'fx-operand-reader-20261001-v1'
    out.mkdir()
    rows, tables = requests_for_reader()
    model = FXRecordReader(operand_tables=tables)
    predictions, gaps = {}, []
    for row in rows:
        try:
            predictions[str(row['id'])] = model.read(bytes.fromhex(row['raw']), cpu=row['cpu'])
        except Unsupported as exc:
            gaps.append(dict(id=row['id'], reason=str(exc), provenance=row['provenance']))
    save(out / 'before-native.json', dict(file_version='15.31', cpus=[520, 521], descriptor_class=32,
        mode=0, versions=[], requests=rows, scope='Lexical read only; copied originals and bounded synthetic records. Predictions precede native calls. No operand role, device range, project or execution validity inferred.'))
    save(out / 'predictions-before-native.json', predictions)
    save(out / 'source-generation-gaps.json', gaps)
    save(out / 'operand-tables-before-native.json', tables)
    (out / 'header-tables-before-native.json').write_bytes((P / 'fx-native-instruction-catalog-20261001-v1/before-native.json').read_bytes())
    for name in ('source_fx_header_reader.py', 'source_fx_operand_reader.py', 'source_fx_record_reader.py',
                 'extract_fx_reader_tables.py', 'probe_fx_operand_reader.py', 'FXReadRecordOracle.cs', 'TraceFXOperandReader.js'):
        (out / name).write_bytes((P / name).read_bytes())
    (out / 'requests.tsv').write_text('\n'.join(f'{r["id"]}\t{r["cpu"]}\t{r["input_base64"]}' for r in rows) + '\n', encoding='ascii')
    exe = out / 'FXReadRecordOracle.exe'
    build = subprocess.run([str(os.path.join(os.environ['WINDIR'], 'Microsoft.NET/Framework/v4.0.30319/csc.exe')),
                            '/nologo', '/platform:x86', '/out:' + str(exe), str(out / 'FXReadRecordOracle.cs')],
                           capture_output=True, timeout=30, creationflags=subprocess.CREATE_NO_WINDOW)
    (out / 'build.txt').write_bytes(build.stdout + build.stderr)
    if build.returncode:
        raise RuntimeError('Owned lexical reader helper build failed')
    args = [str(exe), str(DLL), str(out / 'requests.tsv'), str(out / 'baseline.jsonl')]
    baseline = subprocess.run(args, capture_output=True, timeout=45, creationflags=subprocess.CREATE_NO_WINDOW)
    (out / 'baseline-stdout.bin').write_bytes(baseline.stdout)
    (out / 'baseline-stderr.bin').write_bytes(baseline.stderr)
    save(out / 'baseline-process.json', dict(returncode=baseline.returncode))
    if baseline.returncode:
        raise RuntimeError('Owned public lexical read failed; observations retained')
    traced_run(args[:-1] + [str(out / 'traced.jsonl')], (out / 'TraceFXOperandReader.js').read_text(encoding='utf-8'), out)
    compare(out)


def compare(out):
    rows = json.loads((out / 'before-native.json').read_text(encoding='utf-8'))['requests']
    predictions = json.loads((out / 'predictions-before-native.json').read_text(encoding='utf-8'))
    native, errors = collections.defaultdict(list), []
    for line in (out / 'events.jsonl').read_text(encoding='utf-8').splitlines():
        packet = json.loads(line)
        if packet['type'] != 'send':
            errors.append(packet)
        else:
            event = packet['payload']
            if event['event'] in ('operand-reader', 'operand-text-atom'):
                native[event['request']].append(event)
    answers = [json.loads(line) for line in (out / 'baseline.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    counts, differences, gaps, descriptor_ids = collections.Counter(), [], [], set()
    for row, answer in zip(rows, answers, strict=True):
        if (row['id'], row['cpu']) != (answer['id'], answer['cpu']):
            raise ValueError('Public request framing differs')
        prediction = predictions.get(str(row['id']))
        if prediction is None:
            gaps.append(dict(id=row['id'], public_code=answer['code'], native=native[row['id']]))
            continue
        events = native[row['id']]
        groups = [e for e in events if e['event'] == 'operand-reader']
        atoms = [e for e in events if e['event'] == 'operand-text-atom']
        expected_groups = prediction['operands']
        expected_atoms = [a for group in expected_groups for a in group['atoms']]
        if len(groups) != len(expected_groups) or len(atoms) != len(expected_atoms):
            differences.append(dict(id=row['id'], field='call-counts', expected_groups=len(expected_groups), native_groups=len(groups), expected_atoms=len(expected_atoms), native_atoms=len(atoms)))
        for expected, observed in zip(expected_groups, groups):
            counts['groups'] += 1
            same = dict(result=expected['result'] == observed['result'], consumed=expected['consumed'] == observed['consumed'],
                        output=expected['native_text_token'] == observed['output'], context=(observed['cpu'], observed['descriptor_class']) == (row['cpu'], 32))
            for key, value in same.items():
                counts['group_' + key] += value
            if not all(same.values()):
                differences.append(dict(id=row['id'], field='operand-group', expected=expected, observed=observed, matches=same))
        for expected, observed in zip(expected_atoms, atoms):
            counts['atoms'] += 1
            same = dict(raw=expected['raw_token'] == observed['raw'], result=expected['result'] == observed['result'],
                        output=expected['display_bytes'] == observed['output'], descriptor=expected['descriptor_index'] == observed['descriptor_index'],
                        context=(observed['cpu'], observed['descriptor_class']) == (row['cpu'], 32))
            for key, value in same.items():
                counts['atom_' + key] += value
            if observed['descriptor_index'] is not None:
                descriptor_ids.add(observed['descriptor_index'])
            if not all(same.values()):
                differences.append(dict(id=row['id'], field='operand-text-atom', expected=expected, observed=observed, matches=same))
        if prediction['native_text_record'] is not None:
            counts['full_records'] += 1
            exact = answer['code'] == 0 and prediction['native_text_record'] == base64.b64decode(answer['output_base64']).hex()
            counts['full_record_exact'] += exact
            if not exact:
                differences.append(dict(id=row['id'], field='public-record-text', expected=prediction['native_text_record'], observed=answer))
        else:
            counts[prediction['handling']] += 1
    save(out / 'differences.json', differences)
    save(out / 'no-prediction.json', gaps)
    summary = dict(requests=len(rows), predictions=len(predictions), source_generation_gaps=len(rows)-len(predictions),
        counts=dict(counts), reached_text_descriptors=sorted(descriptor_ids), differences=len(differences), unavailable=len(gaps),
        public_codes=dict(collections.Counter(a['code'] for a in answers)),
        all_guards_intact=all(a['guards_intact'] for a in answers), all_inputs_preserved=all(a['input_preserved'] for a in answers),
        baseline_traced_exact=(out / 'baseline.jsonl').read_bytes() == (out / 'traced.jsonl').read_bytes(), hook_errors=errors,
        scope='Every prediction/model snapshot precedes these native calls. Lexical read does not establish instruction/type/project validity. Reader refusals, prediction differences and generation gaps retained.')
    save(out / 'comparison.json', summary)
    print(json.dumps(summary, ensure_ascii=True), flush=True)
    if differences or errors or not summary['baseline_traced_exact']:
        raise ValueError('Native lexical reader differences retained')


if __name__ == '__main__':
    main()
