// Owned, guarded, read-only public PCode-to-IL calls. No project or device APIs.
using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;

public static class FXReadRecordOracle {
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode)] static extern IntPtr LoadLibraryEx(string p,IntPtr f,uint flags);
    [DllImport("kernel32.dll",CharSet=CharSet.Ansi,ExactSpelling=true)] static extern IntPtr GetProcAddress(IntPtr m,string n);
    [DllImport("kernel32.dll")] static extern uint SetErrorMode(uint mode);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate IntPtr Create();
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Open(IntPtr h,int cpu,int mode);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Version(IntPtr h,int count,[In]uint[] values);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Close(IntPtr h);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate void Destroy(IntPtr h);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Decode(IntPtr h,IntPtr input,ref int size,IntPtr output,ref int capacity);
    static T Export<T>(IntPtr m,string n) where T:class {
        IntPtr p=GetProcAddress(m,n);if(p==IntPtr.Zero)throw new Exception(n);
        return Marshal.GetDelegateForFunctionPointer(p,typeof(T)) as T;
    }
    public static int Main(string[] args) {
        if(IntPtr.Size!=4||args.Length!=3)return 2;SetErrorMode(3);
        if(FileVersionInfo.GetVersionInfo(args[0]).FileVersion!="15.31")throw new Exception("Uninspected converter");
        IntPtr m=LoadLibraryEx(args[0],IntPtr.Zero,8);if(m==IntPtr.Zero)throw new Exception("Load failed");
        Create create=Export<Create>(m,"ObjectNew");Open open=Export<Open>(m,"Open");
        Version version=Export<Version>(m,"SetVersion");Close close=Export<Close>(m,"Close");Destroy destroy=Export<Destroy>(m,"ObjectDelete");
        Decode decode=Export<Decode>(m,"ChangePToILcode");
        using(StreamWriter writer=new StreamWriter(args[2])) {
            foreach(string line in File.ReadLines(args[1])) {
                string[] fields=line.Split('\t');if(fields.Length!=3)throw new Exception("Request framing");
                int id=int.Parse(fields[0]),cpu=int.Parse(fields[1]);byte[] raw=Convert.FromBase64String(fields[2]);
                if((cpu!=520&&cpu!=521)||raw.Length<2||raw.Length>512)throw new Exception("Outside inspected input context");
                const int guard=32,incap=4096,outcap=8192;
                byte[] input=new byte[incap+2*guard],output=new byte[outcap+2*guard];
                for(int i=0;i<guard;i++){input[i]=input[guard+incap+i]=output[i]=output[guard+outcap+i]=0xa5;}
                Array.Copy(raw,0,input,guard,raw.Length);
                GCHandle pin=GCHandle.Alloc(input,GCHandleType.Pinned),pout=GCHandle.Alloc(output,GCHandleType.Pinned);
                IntPtr h=create();if(h==IntPtr.Zero)throw new Exception("Create failed");
                try {
                    int code=open(h,cpu,0);if(code!=0)throw new Exception("Open failed "+code);
                    code=version(h,0,new uint[0]);if(code!=0)throw new Exception("Version failed "+code);
                    int size=raw.Length+1,capacity=outcap;
                    code=decode(h,IntPtr.Add(pin.AddrOfPinnedObject(),guard),ref size,IntPtr.Add(pout.AddrOfPinnedObject(),guard),ref capacity);
                    if(size<0||size>raw.Length+1||capacity<0||capacity>outcap)throw new Exception("Public extent outside owned buffers");
                    for(int i=0;i<guard;i++)if(input[i]!=0xa5||input[guard+incap+i]!=0xa5||output[i]!=0xa5||output[guard+outcap+i]!=0xa5)throw new Exception("Owned guard changed");
                    for(int i=0;i<raw.Length;i++)if(input[guard+i]!=raw[i])throw new Exception("Read-only source changed");
                    writer.WriteLine("{\"id\":"+id+",\"cpu\":"+cpu+",\"code\":"+code+",\"size\":"+size+",\"capacity\":"+capacity+
                        ",\"guards_intact\":true,\"input_preserved\":true,\"output_base64\":\""+Convert.ToBase64String(output,guard,code==0?capacity:0)+"\"}");writer.Flush();
                }finally {close(h);destroy(h);pin.Free();pout.Free();}
            }
        }
        return 0;
    }
}
