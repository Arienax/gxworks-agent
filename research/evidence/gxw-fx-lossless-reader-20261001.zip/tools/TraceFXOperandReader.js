'use strict';
let readerRequest = -1, readerGroup = -1, readerAtom = -1, activeAtom = null;
function readerHex(p, n) { return Array.from(new Uint8Array(p.readByteArray(n)), b => b.toString(16).padStart(2, '0')).join(''); }
function readerShort(r) { return (r.toInt32() << 16) >> 16; }
Process.attachModuleObserver({ onAdded(m) {
    if (m.name.toLowerCase() !== 'eccodegeneratorfx2.dll') return;
    const base = m.base;
    function context() { return {cpu:base.add(0x928a8).readU16(), descriptor_class:base.add(0x928ac).readU16()}; }
    Interceptor.attach(m.findExportByName('ChangePToILcode'), {
        onEnter() { readerRequest++; readerGroup = readerAtom = -1; },
        onLeave(r) { send({event:'public-decode', request:readerRequest, code:r.toInt32()}); }
    });
    Interceptor.attach(base.add(0x3d7b9), {
        onEnter(a) {
            this.input = a[0]; this.consumed = a[2]; this.output = a[3];
            const n = a[1].toInt32() & 65535;
            if (n < 1 || n > 513) throw new Error('Operand reader outside owned record extent');
            this.row = {event:'operand-reader', request:readerRequest, group:++readerGroup,
                input_extent:n, raw_remaining:readerHex(a[0], n),
                output_extent:a[4].toInt32() & 65535, initial_consumed:this.consumed.readU16(), ...context()};
        },
        onLeave(r) {
            const n = readerShort(r);
            if (n > 255) throw new Error('Reader text exceeds its native BYTE extent');
            this.row.result = n;
            this.row.consumed = n > 0 ? this.consumed.readU16() : null;
            this.row.raw = n > 0 ? readerHex(this.input, this.row.consumed) : null;
            this.row.output = n > 0 ? readerHex(this.output, n) : '';
            send(this.row);
        }
    });
    Interceptor.attach(base.add(0x3d514), {
        onEnter(a) {
            const token = this.context.edx, n = token.readU8();
            if (n < 3 || n > 100) throw new Error('Text atom outside owned token extent');
            this.output = this.context.ecx;
            this.row = {event:'operand-text-atom', request:readerRequest, group:readerGroup, atom:++readerAtom,
                raw:readerHex(token, n), input_extent:a[0].toInt32() & 65535,
                output_extent:this.context.eax.toInt32() & 65535, descriptor_index:null, ...context()};
            this.previous = activeAtom; activeAtom = this.row;
        },
        onLeave(r) {
            const n = readerShort(r);
            if (n > 100) throw new Error('Text atom outside owned output envelope');
            this.row.result = n;
            this.row.output = n > 0 ? readerHex(this.output, n) : null;
            activeAtom = this.previous;
            send(this.row);
        }
    });
    Interceptor.attach(base.add(0x3c47b), {
        onEnter(a) { this.row = activeAtom; this.code = a[0].toInt32() & 255; },
        onLeave(r) {
            if (!this.row) return;
            this.row.lookup_code = this.code;
            if (!r.isNull()) {
                const delta = r.sub(base.add(0x8c658)).toInt32();
                if (delta < 0 || delta >= 32 * 8 || delta % 8 !== 0) throw new Error('Unmeasured text descriptor row');
                this.row.descriptor_index = delta / 8;
                this.row.descriptor_raw = readerHex(r, 8);
            }
        }
    });
} });
