'use strict';
let headerRequest = -1;
function headerHex(p, n) { return Array.from(new Uint8Array(p.readByteArray(n)), b => b.toString(16).padStart(2, '0')).join(''); }
Process.attachModuleObserver({ onAdded(m) {
    if (m.name.toLowerCase() !== 'eccodegeneratorfx2.dll') return;
    const base = m.base;
    Interceptor.attach(m.findExportByName('ChangePToILcode'), {
        onEnter() { headerRequest++; },
        onLeave(r) { send({ event: 'public-decode', request: headerRequest, code: r.toInt32() }); }
    });
    Interceptor.attach(base.add(0x3d9d5), {
        onEnter(a) {
            const n = a[0].readU8();
            if (n < 2 || n > 160) throw new Error('Header outside owned input envelope');
            this.output = a[2]; this.arity = a[4];
            this.row = { event: 'header-reader', request: headerRequest, raw: headerHex(a[0], n),
                input_extent: a[1].toInt32() & 65535, output_extent: a[3].toInt32() & 65535,
                cpu: base.add(0x928a8).readU16(), descriptor_class: base.add(0x928ac).readU16() };
        },
        onLeave(r) {
            this.row.result = (r.toInt32() << 16) >> 16;
            this.row.arity = this.arity.readU8();
            this.row.output = this.row.result > 0 ? headerHex(this.output, this.row.result) : '';
            send(this.row);
        }
    });
} });
