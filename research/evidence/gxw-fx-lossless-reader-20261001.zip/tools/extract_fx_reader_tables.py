"""Retain the inspected class-20 operand text table and its lookup bytes."""
import json
from pathlib import Path

import pefile

P = Path(__file__).resolve().parent
DLL = Path('D:/GXWORKS2/Easysocket/CodeGenerator/ECCodeGeneratorFX2.dll')


def extract():
    pe = pefile.PE(str(DLL))
    versions = [entry.entries.get(b'FileVersion', b'').decode('ascii')
                for group in pe.FileInfo for block in group
                if block.Key == b'StringFileInfo' for entry in block.StringTable]
    if versions != ['15.31']:
        raise ValueError('Uninspected native converter version')
    image = pe.get_memory_mapped_image()
    rows = []
    for index in range(32):
        rva = 0x8c658 + index * 8
        raw = image[rva:rva + 8]
        end = raw.index(0)
        if end > 2:
            raise ValueError('Name exceeds inspected inline prefix field')
        rows.append(dict(index=index, rva=rva, raw=raw.hex(),
                         prefix=raw[:end].decode('ascii'), format=(raw[3] >> 4) & 7,
                         uninterpreted_fields=list(raw[3:]), code=raw[7]))
    lookup = image[0x8c758:0x8c758 + 112]
    if any(i != 255 and i >= len(rows) for i in lookup):
        raise ValueError('Lookup points outside inspected text rows')
    return dict(file_version='15.31', descriptor_class=32, cpus=[520, 521],
                table_rva=0x8c658, lookup_rva=0x8c758, rows=rows, lookup_raw=lookup.hex(),
                function_prefixes={hex(rva):image[rva:rva + 16].hex()
                    for rva in (0x3c47b, 0x3d1e5, 0x3d201, 0x3d276, 0x3d331, 0x3d514, 0x3d7b9, 0x3cddb, 0x3dc19)},
                scope='Raw table and original lexical reader implementation. Descriptor formats do not establish device ranges, operand roles or project validity.')


if __name__ == '__main__':
    tables = extract()
    (P / 'fx-operand-reader-tables-20261001-v1.json').write_text(
        json.dumps(tables, indent=2, ensure_ascii=True) + '\n', encoding='utf-8')
    print(json.dumps(dict(rows=len(tables['rows']), mapped=sum(v != 255 for v in bytes.fromhex(tables['lookup_raw'])))))
