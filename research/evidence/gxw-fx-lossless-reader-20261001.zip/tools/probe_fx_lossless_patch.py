"""Same-extent local byte proposals versus original native checking/emission."""
import base64
import collections
import json
import os
import subprocess

from probe_fx_operand_rules import DLL, P, save, traced_run
from source_fx_lossless_reader import FXLosslessReader
from source_fx_machine import FXMachine
from source_fx3u_machine import FX3UCells, FX3UMachine
from source_fx_operand_rules import Unsupported


def main():
    out = P / 'fx-lossless-patch-20261001-v1'
    out.mkdir()
    reader = FXLosslessReader()
    prior = P / 'fx-lossless-reader-original-corpus-20261001-v1'
    manifest = json.loads((prior / 'comparison.json').read_text(encoding='utf-8'))
    models = {521:FXMachine(), 520:FX3UMachine(
        json.loads((P / 'fx3u-original-machine-corpus-20261001-v1/fx3u-machine-tables-before-native.json').read_text(encoding='utf-8')),
        FX3UCells(json.loads((P / 'fx3u-original-machine-corpus-20261001-v1/fx3u-cell-tables-before-native.json').read_text(encoding='utf-8'))))}
    inputs = []
    for project in manifest['comparisons']:
        original = json.loads((prior / (project['case'] + '.json')).read_text(encoding='utf-8'))
        inputs.append(dict(case=project['case'], cpu=project['cpu'], body=bytes.fromhex(original['raw_body']), distribution='local-only original body'))
    # Both unknown framed data and a broken remainder are deliberately present.
    # They stay opaque even while the separate known instruction is changed.
    for case, suffix in [('synthetic-unknown', b''), ('synthetic-broken-tail', bytes.fromhex('07a810'))]:
        inputs.append(dict(case=case, cpu=521, body=bytes.fromhex('0780004142430703770306a80000010603000304906404033403') + suffix,
                           distribution='self-authored bounded synthetic preservation witness'))
    rows, skipped, artifacts = [], [], []
    for source in inputs:
        before = reader.read(source['body'], cpu=source['cpu'])
        eligible = []
        for record in before['records']:
            if record['handling'] != 'decoded-native-record':
                continue
            projection = record['lexical_projection']
            for operand in projection['operands']:
                if len(operand['tokens']) != 1:
                    continue
                raw = bytes.fromhex(operand['tokens'][0]['raw'])
                if len(raw) not in (4, 5) or raw[1] not in (0xa8, 0x90):
                    continue
                offset = record['offset'] + operand['offset']
                token = next(t for t in before['physical_tokens'] if t['offset'] == offset)
                eligible.append((raw[1] != 0xa8, token, record))
        if not eligible:
            skipped.append(dict(case=source['case'], reason='No measured single plain D/M operand to change'))
            continue
        _, token, record = sorted(eligible, key=lambda row:(row[0], row[1]['offset']))[0]
        replacement = bytearray.fromhex(token['raw'])
        replacement[2] ^= 1
        patch = reader.replace_same_extent_token(before, token_index=token['index'], expected_raw=token['raw'], replacement_raw=replacement.hex())
        candidate = bytes.fromhex(patch['candidate'])
        after = reader.read(candidate, cpu=source['cpu'])
        untouched_tokens = all(t['raw'] == after['physical_tokens'][t['index']]['raw'] for t in before['physical_tokens'] if t['index'] != token['index'])
        opaque_before = [r['raw'] for r in before['records'] if r['handling'] != 'decoded-native-record']
        opaque_after = [r['raw'] for r in after['records'] if r['handling'] != 'decoded-native-record']
        new_record = after['records'][record['index']]
        raw = bytes.fromhex(new_record['raw'])
        prediction = models[source['cpu']].record(raw)
        rewrite = models[source['cpu']].width_rewrite(raw)
        change = dict(id=len(rows), case=source['case'], cpu=source['cpu'], input_base64=base64.b64encode(raw).decode(),
                      raw=raw.hex(), before_record=record['raw'], offset=record['offset'], source_distribution=source['distribution'],
                      source_prediction=prediction, source_rewrite=rewrite,
                      before_text=record['lexical_projection']['native_text_record'], after_text=new_record['lexical_projection']['native_text_record'])
        rows.append(change)
        artifact = dict(case=source['case'], cpu=source['cpu'], distribution=source['distribution'],
                        source_body=source['body'].hex(), patch=patch, before=before, after=after,
                        changed_bytes=sum(a != b for a,b in zip(source['body'], candidate, strict=True)),
                        untouched_physical_tokens_preserved=untouched_tokens, opaque_regions_byte_exact=opaque_before == opaque_after,
                        all_original_offsets_preserved=[t['offset'] for t in before['physical_tokens']] == [t['offset'] for t in after['physical_tokens']],
                        round_trip_byte_identical=reader.reconstruct(after) == candidate)
        if not all(artifact[k] for k in ('untouched_physical_tokens_preserved', 'opaque_regions_byte_exact', 'all_original_offsets_preserved', 'round_trip_byte_identical')) or artifact['changed_bytes'] != 1:
            raise ValueError('Local byte proposal widened its touch scope')
        if source['case'] == 'synthetic-broken-tail':
            broken = before['physical_tokens'][-1]
            try:
                reader.replace_same_extent_token(before, token_index=broken['index'], expected_raw=broken['raw'], replacement_raw=broken['raw'])
            except Unsupported:
                artifact['unframed_replacement_refused'] = True
            else:
                raise ValueError('Unframed source became an editable token')
        save(out / (source['case'] + '.json'), artifact)
        artifacts.append(artifact)
    save(out / 'before-native.json', dict(requests=rows, skipped=skipped,
        scope='One-byte same-extent proposals in copied compiler bodies; unknown/metadata/remainder preserved. Public checks use owned record buffers with null allocation context. Full GXW compile/save/reopen and PLC execution are not claimed.'))
    for name in ('probe_fx_lossless_patch.py', 'source_fx_lossless_reader.py', 'TraceFXInstructionCells.js'):
        (out / name).write_bytes((P / name).read_bytes())
    cs = (P / 'FXOperandCheckOracle.cs').read_text(encoding='utf-8')
    for old,new in [('args.Length!=3','args.Length!=4'), ('File.ReadLines(args[1])','File.ReadLines(args[2])'),
                    ('new StreamWriter(args[2])','new StreamWriter(args[3])'), ('open(h,521,0)','open(h,int.Parse(args[1]),0)')]:
        if cs.count(old) != 1:
            raise ValueError('Owned helper adaptation site differs')
        cs = cs.replace(old,new)
    cs = cs.replace('SetErrorMode(3);', 'if(args[1]!="520"&&args[1]!="521") throw new Exception("Unmeasured CPU"); SetErrorMode(3);')
    (out / 'FXRawProfileOracle.cs').write_text(cs, encoding='utf-8')
    exe = out / 'FXRawProfileOracle.exe'
    build = subprocess.run([str(os.path.join(os.environ['WINDIR'], 'Microsoft.NET/Framework/v4.0.30319/csc.exe')),
                            '/nologo', '/platform:x86', '/out:' + str(exe), str(out / 'FXRawProfileOracle.cs')],
                           capture_output=True, timeout=30, creationflags=subprocess.CREATE_NO_WINDOW)
    (out / 'build.txt').write_bytes(build.stdout + build.stderr)
    if build.returncode:
        raise RuntimeError('Owned raw-profile helper build failed')
    comparisons, differences, errors, counts = [], [], [], collections.Counter()
    for cpu in (520, 521):
        requests = [r for r in rows if r['cpu'] == cpu]
        directory = out / ('cpu-' + str(cpu))
        directory.mkdir()
        (directory / 'requests.tsv').write_text('\n'.join(f'{r["id"]}\t{r["input_base64"]}' for r in requests) + '\n', encoding='ascii')
        args = [str(exe), str(DLL), str(cpu), str(directory / 'requests.tsv'), str(directory / 'baseline.jsonl')]
        baseline = subprocess.run(args, capture_output=True, timeout=30, creationflags=subprocess.CREATE_NO_WINDOW)
        (directory / 'baseline-stdout.bin').write_bytes(baseline.stdout)
        (directory / 'baseline-stderr.bin').write_bytes(baseline.stderr)
        save(directory / 'baseline-process.json', dict(returncode=baseline.returncode))
        if baseline.returncode:
            raise RuntimeError('Owned changed-record check failed')
        traced_run(args[:-1] + [str(directory / 'traced.jsonl')], (out / 'TraceFXInstructionCells.js').read_text(encoding='utf-8'), directory)
        if (directory / 'baseline.jsonl').read_bytes() != (directory / 'traced.jsonl').read_bytes():
            raise ValueError('Native original/traced changed-record outputs differ')
        emissions = collections.defaultdict(list)
        for line in (directory / 'events.jsonl').read_text(encoding='utf-8').splitlines():
            packet = json.loads(line)
            if packet['type'] != 'send':
                errors.append(packet)
            elif packet['payload']['event'] == 'machine-emission':
                emissions[packet['payload']['request']].append(packet['payload'])
        answers = [json.loads(line) for line in (directory / 'baseline.jsonl').read_text(encoding='utf-8-sig').splitlines()]
        for ordinal, (row, answer) in enumerate(zip(requests, answers, strict=True)):
            if row['id'] != answer['id'] or len(emissions[ordinal]) != 1:
                raise ValueError('Changed-record native request/emission framing differs')
            native, prediction = emissions[ordinal][0], row['source_prediction']
            emission = prediction['emission']
            same = dict(public_accepted=answer['code'] == 0 and answer['status'] in (0,1),
                public_rewrite_exact=base64.b64decode(answer['output_base64']).hex() == row['source_rewrite']['candidate'],
                native_cells_exact=prediction['native_cells'] == native['before'], auxiliary_exact=prediction['auxiliary'] == native['auxiliary'],
                native_width_exact=emission['words'] == native['words'], native_cells_after_exact=emission['cells_after'] == native['after'],
                machine_bytes_exact=emission['machine_output'] == native['output'], context=native['cpu'] == cpu and native['mode'] == (8 if cpu == 520 else 9),
                guards_intact=answer['guards_intact'])
            comparison = dict(id=row['id'], case=row['case'], matches=same, original_native_emission=native, public=answer)
            comparisons.append(comparison)
            counts.update({key:int(value) for key,value in same.items()})
            if not all(same.values()):
                differences.append(comparison)
    save(out / 'native-comparisons.json', comparisons)
    save(out / 'differences.json', differences)
    summary = dict(proposals=len(rows), original_bodies=sum(not r['case'].startswith('synthetic') for r in rows),
        synthetic_opaque_witnesses=sum(r['case'].startswith('synthetic') for r in rows), skipped=skipped,
        changed_bytes=sum(a['changed_bytes'] for a in artifacts), untouched_regions_preserved=all(a['untouched_physical_tokens_preserved'] and a['opaque_regions_byte_exact'] for a in artifacts),
        counts=dict(counts), differences=len(differences), hook_errors=errors,
        scope='Source-bound local byte proposals, independently checked only at the native raw-record/type/emission layer. Unknown regions are preserved. No full GXW project mutation, compile/save/reopen or PLC execution.')
    save(out / 'comparison.json', summary)
    print(json.dumps(summary, ensure_ascii=True), flush=True)
    if differences or errors:
        raise ValueError('Local byte proposal native differences retained')


if __name__ == '__main__':
    main()
