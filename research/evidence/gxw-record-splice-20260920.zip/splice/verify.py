import csv, io, json, sys
from pathlib import Path
sys.path[:0] = ['research', 'src']
from gxw.container import CompoundFile
from gxw.lossless import inspect_project, sha256
from gxw.token_listing import decode_token_listing, TokenLabel
from gxw.token_resource import parse_token_resource
from align_gxw_tokens import canonical_operand
from gxw_corpus import independent_cfb
from native_gxw_tokens import check_programs

p = Path(__file__).parent
programs = []
for key, folder in [('c', 'native'), ('u', 'u-native')]:
    values = [(p / (key + suffix + '.gxw')).read_bytes() for suffix in ('-base', '-input', '')]
    groups = [{s.logical_name: s.raw for s in inspect_project(b).streams if s.logical_name and s.raw is not None} for b in values]
    raw_before, raw_input, raw_saved = [g['MAIN.Program.pou'] for g in groups]
    assert raw_input == raw_saved
    listing = decode_token_listing(raw_saved, text_encoding='cp936')
    assert not listing.gaps
    patch = json.loads((p / folder / 'patch.json').read_text('utf-8'))
    for preserved in patch['preserved_records']:
        a, b, n = preserved['old_offset'], preserved['new_offset'], preserved['length']
        assert raw_before[a:a+n] == raw_input[b:b+n]
        assert sha256(raw_before[a:a+n]) == preserved['sha256']
    def rows(data):
        result = list(csv.reader(io.StringIO(data.decode('utf-16')), delimiter='\t'))[3:]
        for row in result:
            if len(row) > 3: row[3] = canonical_operand(row[3])
        return result
    assert rows(listing.csv_bytes()) == rows((p / (key + '-reopened.csv')).read_bytes())
    compiled = []
    for name, raw in groups[-1].items():
        if name.endswith('.res'):
            resource = parse_token_resource(raw)
            if resource.observed_program_names == ('MAIN',):
                for region in resource.code_regions:
                    assert region.body == listing.source.body
                    compiled.append({'name': name, 'offset': region.body_offset, 'length': len(region.body), 'body_equals_source': True})
    assert compiled
    independent = []
    for raw in values:
        independent.extend([independent_cfb(raw), independent_cfb(CompoundFile(raw).read_stream('_hdb'))])
    assert all(c['status'] == 'agrees' for c in independent)
    result = {'case': key, 'project_hashes': [sha256(b) for b in values],
              'pou_sha256': sha256(raw_saved), 'input_pou_equals_saved': True,
              'preserved_records_at_edit': len(patch['preserved_records']),
              'opaque_records_preserved_at_edit': patch['source_gaps_preserved'],
              'gaps_after_family_decoder': len(listing.gaps),
              'csv_all_cells_agree_except_XY_padding': True,
              'instructions': len(listing.instructions),
              'labels': [{'text': r.text, 'step': r.step, 'step_width': r.step_width} for r in listing.records if isinstance(r, TokenLabel)],
              'steps': listing.instructions[-1].step + 1,
              'resource_checks': compiled,
              'native_changed_logical_streams': [k for k,v in groups[1].items() if groups[2].get(k) != v],
              'independent_readers': independent}
    (p / (key + '-verification.json')).write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n','utf-8')
    programs.append((raw_saved, {'case': key, 'native_project_sha256': sha256(values[-1])}))
    print(key, result['instructions'], result['steps'], len(independent), compiled)
print(check_programs(programs, p / 'whole-native-decode')['summary'])
