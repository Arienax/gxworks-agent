// Offline byte conversion only. This helper has no project, UI or device APIs.
// ABI recovered from ECCodeGeneratorFX2.dll 15.31; the Python caller pins its hash.
using System;
using System.Runtime.InteropServices;

public static class TokenOracle {
    [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
    static extern IntPtr LoadLibraryEx(string path, IntPtr file, uint flags);
    [DllImport("kernel32.dll", CharSet=CharSet.Ansi, ExactSpelling=true)]
    static extern IntPtr GetProcAddress(IntPtr module, string name);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate IntPtr NewObject();
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int OpenObject(IntPtr h, int cpu, int mode);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int CloseObject(IntPtr h);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate void DeleteObject(IntPtr h);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Decode(IntPtr h,
        [In] byte[] input, ref int inputSize, [Out] byte[] output, ref int outputSize);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Encode(IntPtr h,
        [In] byte[] input, int inputSize, int option1, int option2,
        [Out] byte[] output, ref int outputSize, ref int lastKind, IntPtr context);

    static T Export<T>(IntPtr module, string name) where T : class {
        IntPtr address = GetProcAddress(module, name);
        if (address == IntPtr.Zero) throw new Exception("Missing export: " + name);
        return Marshal.GetDelegateForFunctionPointer(address, typeof(T)) as T;
    }

    public static int Main(string[] args) {
        if (IntPtr.Size != 4 || args.Length != 3) return 2;
        IntPtr module = LoadLibraryEx(args[0], IntPtr.Zero, 8);
        if (module == IntPtr.Zero) throw new Exception("LoadLibraryEx: " + Marshal.GetLastWin32Error());
        NewObject create = Export<NewObject>(module, "ObjectNew");
        OpenObject open = Export<OpenObject>(module, "Open");
        CloseObject close = Export<CloseObject>(module, "Close");
        DeleteObject destroy = Export<DeleteObject>(module, "ObjectDelete");
        Decode decode = Export<Decode>(module, "ChangePToILcode");
        Encode encode = Export<Encode>(module, "ChangeILToPcode");
        IntPtr handle = create();
        if (handle == IntPtr.Zero) throw new Exception("ObjectNew failed");
        try {
            int result = open(handle, int.Parse(args[1]), 0);
            if (result != 0) throw new Exception("Open: " + result.ToString("X8"));
            string line;
            while ((line = Console.ReadLine()) != null) {
                string[] fields = line.Split('\t');
                if (fields.Length != 3) throw new Exception("Invalid request framing");
                int id = int.Parse(fields[1]);
                byte[] input = Convert.FromBase64String(fields[2]);
                if (input.Length == 0 || input.Length > 32768) throw new Exception("Input size outside tested envelope");
                byte[] output = new byte[1048576];
                int inputSize = input.Length, outputSize = output.Length, lastKind = 0;
                if (fields[0] == "decode") result = decode(handle, input, ref inputSize, output, ref outputSize);
                else if (fields[0] == "encode") result = encode(handle, input, inputSize, int.Parse(args[2]), 0, output, ref outputSize, ref lastKind, IntPtr.Zero);
                else throw new Exception("Unsupported operation");
                if (result == 0 && (outputSize < 0 || outputSize > output.Length)) throw new Exception("Invalid returned output size");
                string payload = result == 0 ? Convert.ToBase64String(output, 0, outputSize) : "";
                Console.WriteLine("{\"id\":" + id + ",\"return_code\":\"0x" + result.ToString("X8")
                    + "\",\"consumed_bytes\":" + inputSize + ",\"output_bytes\":" + outputSize
                    + ",\"last_kind\":" + lastKind + ",\"output_base64\":\"" + payload + "\"}");
                Console.Out.Flush();
            }
        } finally { close(handle); destroy(handle); }
        return 0;
    }
}
