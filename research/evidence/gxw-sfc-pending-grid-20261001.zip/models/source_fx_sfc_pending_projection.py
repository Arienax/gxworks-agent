"""Source-only assembly of pending FX SFC grids and their owned child bodies."""
import struct
from gxw.sfc_pou import parse_sfc_pou
from source_fx_sfc_grid_encoder import encode_grid,UnsupportedGrid
from source_fx_sfc_multireg_projection import expand_block

def source_grid(raw):
    source=parse_sfc_pou(raw);graph=source.layout['graph'];start,size=graph['offset'],graph['size']
    if struct.unpack_from('<III',raw,start+4)!=(0,1,21516):raise UnsupportedGrid('Outside observed pending grid framing')
    chars=raw[start+16:start+21528]
    if len(chars)!=21512:raise UnsupportedGrid('Pending source character buffer is truncated')
    cache_start=start+21528;cache_size=struct.unpack_from('<I',raw,cache_start)[0]
    if cache_size<4 or cache_start+cache_size+8!=start+size or raw[start+size-8:start+size]!=bytes(8):
        raise UnsupportedGrid('Outside observed pending opaque cache framing')
    return source,chars,dict(start=start,size=size,chars_offset=start+16,cache_offset=cache_start,cache_bytes=cache_size)

def reference_view(raw,tokens,extent):
    """An internal parser view; the stored source and entire opaque cache remain raw."""
    start,size=extent['start'],extent['size'];at=extent['cache_offset'];n=extent['cache_bytes']
    # Fold the mode-specific eight zero bytes into the opaque cache's extent.
    cache=struct.pack('<I',n+8)+raw[at+4:at+n+8]
    block=struct.pack('<IIII',16+len(tokens)+len(cache),0,0,len(tokens)+4)+tokens+cache
    return raw[:start-4]+struct.pack('<I',len(block))+block+raw[start+size:]

def project_projection(data):
    from gxw.container import CompoundFile
    from gxw.project_resolver import GXWProjectResolver
    from gxw.project_metadata import read_project_text_context
    from probe_gxw_task_graph import inspect_task_graph,_text
    resolver=GXWProjectResolver(CompoundFile(data));physical={e.name for e in resolver.hdb.iter_streams()}
    streams={f.logical_name:resolver.hdb.read_stream(f.stream_name) for f in resolver.logical_files() if f.stream_name in physical}
    metadata,=[v for k,v in streams.items() if k.lower().endswith('.prj')]
    if read_project_text_context(metadata)['cpu']!='FX3U/FX3UC':raise UnsupportedGrid('Pending source projection is bound to FX3U/FX3UC')
    task_graph=inspect_task_graph(data)
    if task_graph['gaps'] or len(task_graph['resources'])!=1:raise UnsupportedGrid('Compile-root task graph is incomplete')
    task=task_graph['tasks'][task_graph['resources'][0]['task']]
    if not task['entries']:raise UnsupportedGrid('An empty task can return stale native resource code')
    ordered=[]
    for entry in task['entries']:
        declaration=streams[entry['declarations']];_,end=_text(declaration,54)
        if declaration[end:end+20]!=bytes.fromhex('0000000100000000010000000000010000000000'):
            raise UnsupportedGrid('Unmeasured SFC block declaration shape')
        number=struct.unpack_from('<I',declaration,end+20)[0]
        if number>255 or any(n==number for n,_ in ordered):raise UnsupportedGrid('Block number is duplicate or unmeasured')
        ordered.append((number,entry))
    output=[bytes.fromhex('056c010005')];blocks=[]
    for number,entry in sorted(ordered,key=lambda r:r[0]):
        raw=streams[entry['source_program']];source=parse_sfc_pou(raw)
        start=source.layout['graph']['offset'];mode=struct.unpack_from('<II',raw,start+4)
        if mode==(0,1):
            _,chars,extent=source_grid(raw);model=encode_grid(chars)
            view=reference_view(raw,model.tokens,extent)
            body,ownership=expand_block(view,registration_policy='first')
            graph=dict(storage_words=list(mode),source_bytes=len(raw),raw_reconstruction_exact=source.reconstruct()==raw,
                       encoded_reference_bytes=len(model.tokens),source_step_records=len(model.records),extent=extent)
        elif mode==(0,0):
            body,ownership=expand_block(raw,registration_policy='first')
            graph=dict(storage_words=list(mode),source_bytes=len(raw),raw_reconstruction_exact=source.reconstruct()==raw)
        else:raise UnsupportedGrid('SFC source graph storage mode is unmeasured')
        output.extend((bytes.fromhex('056c01020504dc')+bytes((number,4)),body,bytes.fromhex('056c010305')))
        blocks.append(dict(program=entry['source_program'],block=number,graph=graph,ownership=ownership))
    output.append(bytes.fromhex('056c010105033403'))
    return b''.join(output),dict(cpu='FX3U/FX3UC',blocks=blocks,
        scope='Pending raw grid -> reference graph -> first registered owned bodies; no compiler PCode/cache input or execution claim')
