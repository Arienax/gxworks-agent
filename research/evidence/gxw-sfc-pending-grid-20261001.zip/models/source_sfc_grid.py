"""Read observed SFC character cells while retaining the entire raw allocation.

The cell kinds, bit fields and indirect action-reference lookup are cross-checked
against native ReadSymbol outputs. Other tables and unused cells remain opaque. This
does not validate topology, encode graph PCode, or reconstruct native internals.
"""
from dataclasses import dataclass
import struct


@dataclass(frozen=True)
class SfcGridImage:
    raw: bytes
    width: int
    height: int
    symbols: tuple
    gaps: tuple

    def reconstruction(self):
        return self.raw

    def inventory(self):
        from gxw.lossless import sha256
        return dict(bytes=len(self.raw), sha256=sha256(self.raw), width=self.width, height=self.height,
            symbols=list(self.symbols), gaps=list(self.gaps), handling='partially-decoded',
            opaque_tables=dict(offset=9224, bytes=len(self.raw) - 9224,
                sha256=sha256(self.raw[9224:]), interpreted_fields='referenced step index uint16 and action-reference uint16 only'))


def read_grid(raw):
    raw = bytes(raw)
    if len(raw) != 21512:
        raise ValueError('outside observed 21512-byte SFC character allocation')
    width, height = struct.unpack_from('<HH', raw)
    if not width or not height or width * height > 3072:
        raise ValueError('SFC grid dimensions exceed fixed allocation')
    symbols, gaps = [], []
    for index in range(width * height):
        offset = 8 + index * 3; cell = raw[offset:offset + 3]
        if cell == b'\0' * 3:
            continue
        kind = cell[0] >> 6
        value = int.from_bytes(cell[1:], 'little', signed=True)
        item = dict(x=index % width, y=index // width, source_offset=offset, raw_hex=cell.hex(), result=kind)
        if kind == 1:
            type_code = cell[0] & 31
            item.update(type=type_code, undefined=(cell[0] >> 5) & 1, number=value)
            if type_code not in (0, 1, 2, 3, 4, 5, 6, 7, 10, 12, 13, 14, 15, 26):
                gaps.append(dict(offset=offset, reason='unobserved step type', type=type_code))
            elif type_code not in (14, 15):
                if not 0 <= value < 512:
                    gaps.append(dict(offset=offset, reason='step action table index outside allocation'))
                else:
                    index_address=9224+2*value
                    record_index=struct.unpack_from('<H',raw,index_address)[0]
                    item.update(action_index_offset=index_address,action_record_index=record_index)
                    if record_index==0xffff:
                        item['substep']=None
                        gaps.append(dict(offset=index_address,reason='step action index is absent; native output field is unwritten'))
                    elif record_index>=512:
                        item['substep']=None
                        gaps.append(dict(offset=index_address,reason='step action record index outside allocation'))
                    else:
                        address=15368+7*record_index+1
                        item.update(substep=struct.unpack_from('<h',raw,address)[0],action_reference_offset=address)
        elif kind == 2:
            item['number'] = value
            if cell[0] != 0x80:
                gaps.append(dict(offset=offset, reason='unobserved transition flags'))
        elif kind == 3:
            item['branch'] = value
            if cell[0] != 0xc0:
                gaps.append(dict(offset=offset, reason='unobserved branch flags'))
        else:
            gaps.append(dict(offset=offset, reason='unobserved nonempty cell kind'))
        symbols.append(item)
    return SfcGridImage(raw, width, height, tuple(symbols), tuple(gaps))


def symbol_projection(symbol):
    """Only fields the native API writes for the returned symbol category.

    Earlier oracle revisions reused output variables, so inactive out-fields
    contain previous values. They are not part of the returned symbol's data.
    """
    kind = symbol['result']
    if kind == 0:
        return None
    fields = ['x', 'y', 'result']
    if kind == 1:
        fields += ['type', 'undefined', 'number']
        if symbol['type'] not in (14, 15):
            fields += ['substep']
    elif kind == 2:
        fields += ['number']
    elif kind == 3:
        fields += ['branch']
    else:
        raise ValueError('unobserved native symbol result')
    return {field: symbol[field] for field in fields}


def flow_connections(grid):
    """Follow downward diagram paths through observed connector port bits.

    This reports geometric paths and explicit jump references, not execution
    order, simultaneous-branch semantics or a substitute for native checking.
    Step/transition records terminate paths; opaque cells/flags remain gaps.
    """
    cells = {(s['x'], s['y']): s for s in grid.symbols}
    gaps = list(grid.gaps); nodes = {}; edges = []; jumps = []
    directions = {'down': (0, 1, 'up'), 'up': (0, -1, 'down'),
                  'right': (1, 0, 'left'), 'left': (-1, 0, 'right')}

    def ports(symbol):
        if symbol['result'] == 3:
            branch = symbol['branch']
            if branch & ~0xff or branch & 0xf0 not in (0, 0x50, 0x60, 0x90, 0xa0):
                raise ValueError('unobserved connector flags')
            return {name for name, mask in [('down', 1), ('up', 2), ('right', 4), ('left', 8)] if branch & mask}
        if symbol['result'] == 1 and symbol['type'] in (14, 15):
            return {'up'}
        if symbol['result'] in (1, 2):
            return {'up', 'down'}
        raise ValueError('opaque cell has no inferred ports')

    for point, symbol in cells.items():
        if symbol['result'] == 3:
            continue
        if symbol['result'] == 2:
            kind = 'transition'
        elif symbol['result'] == 1:
            kind = {14: 'end', 15: 'jump'}.get(symbol['type'], 'step')
        else:
            continue
        nodes[point] = dict(kind=kind, number=symbol['number'], x=point[0], y=point[1])
    for point, node in nodes.items():
        if node['kind'] == 'jump':
            targets = [target for target in nodes.values() if target['kind'] == 'step' and target['number'] == node['number']]
            jumps.append(dict(source=node, targets=targets, resolved=len(targets) == 1))
        if node['kind'] in ('jump', 'end'):
            continue
        pending = [(point, 'down', [])]; visited = set(); targets = set()
        while pending:
            origin, direction, path = pending.pop()
            dx, dy, back = directions[direction]; target = (origin[0] + dx, origin[1] + dy)
            segment = (origin, direction)
            if segment in visited:
                continue
            visited.add(segment)
            try:
                valid = target in cells and back in ports(cells[target])
            except ValueError as exc:
                gaps.append(dict(source=node, at=list(target), reason=str(exc)))
                continue
            if not valid:
                gaps.append(dict(source=node, at=list(origin), direction=direction, reason='dangling geometric connection'))
                continue
            if target in nodes:
                if target not in targets:
                    edges.append(dict(source=node, target=nodes[target], connector_path=path))
                    targets.add(target)
                continue
            symbol = cells[target]
            path = path + [dict(x=target[0], y=target[1], flags=symbol['branch'], raw_hex=symbol['raw_hex'])]
            for outgoing in sorted(ports(symbol) - {'up', back}):
                pending.append((target, outgoing, path))
    return dict(nodes=list(nodes.values()), edges=edges, jumps=jumps, gaps=gaps,
        scope='geometric downward paths and explicit jump references; no execution-semantics claim')
