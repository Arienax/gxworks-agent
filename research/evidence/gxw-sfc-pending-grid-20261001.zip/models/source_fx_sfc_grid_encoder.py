"""Source-only FX reference graph encoder, recovered from the 15.31 backend.

This retains all input characters, reads the observed cell/action-table fields,
and reproduces the reference-only intermediate record pass. External action and
transition ladder buffers are deliberately outside this character-grid input.
No compiled cache, native work record, or native output is an encoder input.
The native complete graph checker remains a separate admission condition.
"""
from dataclasses import dataclass
import struct
from source_sfc_grid import read_grid

class UnsupportedGrid(ValueError):pass

STEP_CODES=(0x6c0f,0x6c11,0x6c12,0x6c13,0x6c14,0x6c10,0x6c17,
            0x6c19,0x6c1a,0x6c1b,0x6c1c,0x6c18,0x6c15,0x6c16,
            None,None,0x6c0f,0x6c11,0x6c12,0x6c13,0x6c14,0x6c10,
            0x6c17,0x6c19,0x6c1a,0x6c1b,0x6c1c,0x6c18)

def word(raw,offset,signed=False):
    if offset<0 or offset+2>len(raw):raise UnsupportedGrid('Work or traversal state exceeds recovered allocation')
    return struct.unpack_from('<h' if signed else '<H',raw,offset)[0]

def put(raw,offset,value):
    if offset<0 or offset+2>len(raw):raise UnsupportedGrid('Work or traversal state exceeds recovered allocation')
    struct.pack_into('<H',raw,offset,value&0xffff)

def add(raw,offset,delta=1):put(raw,offset,word(raw,offset)+delta)

def append(work,count_offset,values_offset,index,value):
    if not 0<=index<=32:raise UnsupportedGrid('Transition record exceeds recovered allocation')
    offset=count_offset+2*index;count=word(work,offset)+1
    if count>32:raise UnsupportedGrid('Reference list exceeds recovered allocation')
    put(work,offset,count);put(work,values_offset+2*(index*33+count),value)

def refs(work,count_offset,values_offset,index):
    count=word(work,count_offset+2*index)
    if count>32:raise UnsupportedGrid('Reference list exceeds recovered allocation')
    return [word(work,values_offset+2*(index*33+j)) for j in range(1,count+1)]

def step_record(symbol,cell,used_x,used_y):
    work=bytearray(0x3dec);state=bytearray(26)
    for offset in (4,6,8,10,12,14):put(state,offset,-1)
    put(work,0,STEP_CODES[symbol['type']]);put(work,2,symbol['number']);put(work,4,symbol['substep'])
    put(state,0,symbol['x']);put(state,2,symbol['y']+1)
    if used_x==used_y==1 and symbol['x']==symbol['y']==0:return bytes(work)

    def above():
        x,y=word(state,0),word(state,2)-1
        while y>=0:
            candidate=cell(x,y)
            if candidate['result']==1:return candidate['number']
            y-=1
        raise UnsupportedGrid('Convergence has no preceding step')

    for _ in range(3072*8):
        x,y=word(state,0),word(state,2);s=cell(x,y);n=word(work,12)
        if s['result']==1:
            append(work,0x158,0x19a,n,s['number'])
            if s['type']==15:put(work,0x1ba4+2*n,1)
            pending=word(state,6,signed=True)
            if pending==-1:break
            put(state,0,word(state,8+2*pending)+1);put(state,2,word(state,12+2*pending))
            put(state,8+2*pending,-1);put(state,12+2*pending,-1);add(state,6,-1)
        elif s['result']==2:
            if n>=32:raise UnsupportedGrid('Too many transitions for one native step record')
            add(work,12);put(work,0x50+2*(n+1),s['number']);add(state,2)
        elif s['result']==3:
            flags=s['branch'];low=flags&15;high=flags&0xf0
            if flags&0x10:
                if low==7:
                    add(state,4);depth=word(state,4,signed=True);put(state,16+2*depth,high)
                if flags&5==5:
                    add(state,6);pending=word(state,6,signed=True)
                    put(state,8+2*pending,x);put(state,12+2*pending,y)
                add(state,0 if low==12 else 2)
                if word(state,16)==0xa0:
                    values=refs(work,0xa1c,0xa5e,n+1)
                    put(work,0xa1c+2*(n+2),len(values))
                    for j,value in enumerate(values,1):put(work,0xa5e+2*((n+2)*33+j),value)
            elif flags&0x20:
                if low==7:
                    add(state,4);depth=word(state,4,signed=True);put(state,16+2*depth,high)
                put(state,20,high)
                if low==10:
                    put(state,24,1)
                    if high==0x60:put(state,22,1)
                elif flags&2:
                    number=above()
                    if word(state,24)==1:
                        if high==0xa0:append(work,0xa1c,0xa5e,n+1,number)
                        elif high==0x60 and (not word(work,0xa1c+2*n) or word(state,22)==1):
                            append(work,0x12e0,0x1322,n,number)
                if high==0xa0 and word(state,24)!=1:break
                add(state,2) if flags&1 else add(state,0,-1)
            else:add(state,2)
        else:raise UnsupportedGrid('Traversal reaches an opaque or empty cell')
    else:raise UnsupportedGrid('Traversal exceeds observed grid bound')

    depth=word(state,4,signed=True)
    for i in range(1,word(work,12)+1):
        marker=word(work,0x1ba4+2*i);first=word(state,16);second=word(state,18)
        if depth==-1:code=0x6c1d if marker==1 else 0x6c04
        elif depth==0:
            codes={0x50:(0x6c05,0x6c1e),0x60:(0x6c0b,0x6c1f),0x90:(0x6c06,0x6c06),0xa0:(0x6c07,0x6c20)}
            if first not in codes:raise UnsupportedGrid('Unmapped branch classification')
            code=codes[first][marker==1]
        elif first==0x50:
            code=0x6c09 if word(work,0x158+2*i)>1 else (0x6c1e if marker==1 else 0x6c05)
        elif first==0x60:code=0x6c0c
        elif first==0xa0:
            if second==0x50:code=0x6c21 if marker==1 else 0x6c0d
            elif second==0x60:
                others=word(work,0xa1c+2*i)
                code=(0x6c22 if others else 0x6c1f) if marker==1 else (0x6c0e if others else 0x6c0b)
            elif second==0x90:code=0x6c08
            else:raise UnsupportedGrid('Unmapped nested branch classification')
        else:raise UnsupportedGrid('Unmapped nested branch classification')
        put(work,0xe+2*i,code)
    return bytes(work)

def operand(kind,number):
    if not 0<=number<=0xffff:raise UnsupportedGrid('Reference number exceeds native word')
    return bytes((4,kind,number,4)) if number<256 else bytes((5,kind))+struct.pack('<H',number)+b'\x05'

def header(code,count=2):return bytes((5,code>>8,count,code&255,5))

def emit_record(work):
    code=word(work,0);extra=code in (0x6c14,0x6c15,0x6c16,0x6c1c)
    out=bytearray(header(code,4 if extra else 2)+operand(0x98,word(work,2)))
    if extra:out.extend(operand(0xdc if code in (0x6c15,0x6c16) else 0x98,word(work,4)))
    for i in range(1,word(work,12)+1):
        out.extend(header(word(work,0xe+2*i))+operand(0x99,word(work,0x50+2*i)))
        for count_offset,values_offset,subtype,mode in [(0xa1c,0xa5e,2,0),(0x12e0,0x1322,1,1)]:
            for j,number in enumerate(refs(work,count_offset,values_offset,i)):
                out.extend(bytes((6,0x42,subtype,mode,0x11,6)) if j else bytes((5,0x42,subtype,mode,5)))
                out.extend(operand(0x98,number))
        for number in refs(work,0x158,0x19a,i):out.extend(header(0x6200)+operand(0x98,number))
    out.extend(header(0x6c0a,1));return bytes(out)

@dataclass(frozen=True)
class GridProjection:
    source_chars: bytes
    tokens: bytes
    records: tuple
    opaque_suffix_offset: int=9224

    def reconstruction(self):return self.source_chars

def encode_grid(raw,*,cpu='FX3U/FX3UC'):
    if cpu!='FX3U/FX3UC':raise UnsupportedGrid('Unmeasured graph encoder CPU profile')
    raw=bytes(raw);grid=read_grid(raw)
    if grid.gaps:raise UnsupportedGrid('Character inventory has unresolved fields: '+'; '.join(g['reason'] for g in grid.gaps))
    used_x,used_y=struct.unpack_from('<HH',raw,4)
    if not 0<used_x<=grid.width or not 0<used_y<=grid.height:raise UnsupportedGrid('Used grid extent outside allocation')
    cells={(s['x'],s['y']):s for s in grid.symbols}
    if any(s['result']==3 and (s['branch']&~0xff or s['branch']&0xf0 not in (0,0x50,0x60,0x90,0xa0)) for s in grid.symbols):
        raise UnsupportedGrid('Unmapped connector flags')
    def cell(x,y):
        if not 0<=x<used_x or not 0<=y<used_y or (x,y) not in cells:raise UnsupportedGrid('Traversal leaves the used grid or reaches a blank cell')
        return cells[x,y]
    work=[]
    for y in range(0,used_y,3):
        for x in range(used_x):
            s=cells.get((x,y))
            if not s or s['result']!=1 or s['type'] in (14,15):continue
            if s['type']>=len(STEP_CODES) or STEP_CODES[s['type']] is None:raise UnsupportedGrid('Unmapped step attribute')
            if not 0<=s['number']<512:raise UnsupportedGrid('Step table index outside allocation')
            record=step_record(s,cell,used_x,used_y)
            work.append(dict(x=x,y=y,raw=record))
    if not work:raise UnsupportedGrid('No source step records')
    return GridProjection(raw,b''.join(emit_record(r['raw']) for r in work),tuple(work))
