(()=>{
'use strict';
const attached=new Set();
function hex(p,n){return Array.from(new Uint8Array(p.readByteArray(n)),v=>v.toString(16).padStart(2,'0')).join('');}
function where(p){const m=Process.findModuleByAddress(p);return m?{module:m.name,path:m.path,rva:p.sub(m.base).toUInt32(),prefix:hex(p,16)}:{unknown_address:p.toString()};}
function attachQuery(p,wanted){
 const key=p.toString();if(attached.has(key))return;attached.add(key);
 send({event:'backend-query-entry',target:where(p),wanted});
 Interceptor.attach(p,{
  onEnter(a){this.matches=hex(a[1],16)===wanted;if(this.matches)this.out=a[2];},
  onLeave(r){if(!this.matches||r.toInt32()<0)return;const iface=this.out.readPointer(),table=iface.readPointer();
   send({event:'backend-graph-interface',interface:iface.toString(),
    check:where(table.add(0x16c).readPointer()),encode:where(table.add(0x174).readPointer()),decode:where(table.add(0x180).readPointer())});
  }
 });
}
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='dzdataabs_codegenerator.dll')return;
 const wanted=hex(m.base.add(0x1336c),16);
 for(const [role,rva] of [['check',0xf540],['encode',0xf589]]){
  Interceptor.attach(m.base.add(rva),{
   onEnter(a){const backend=a[0].add(12).readPointer();send({event:'adapter-graph-entry',role,rva,backend:backend.toString()});
    attachQuery(backend.readPointer().readPointer(),wanted);},
   onLeave(r){send({event:'adapter-graph-return',role,hresult:r.toInt32()});}
  });
 }
}});
})();
