"""Resolve the graph implementation beyond the native COM server."""
from pathlib import Path
import json
from probe_fx1s_lossless_project_patch import native_run
from probe_fx_operand_rules import traced_run

P=Path(__file__).resolve().parent

def save(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')

def main():
    out=P/'sfc-graph-implementation-20261001-v6';out.mkdir()
    for name in (Path(__file__).name,'TraceSFCGraphImplementation.js'):(out/name).write_bytes((P/name).read_bytes())
    prior=P/'pending-sfc-source-chars-v3/three-steps-reopen/native-1'
    source=P.parent/'three-steps-reopen.gxw'
    chars=(prior/'sfc-input-chars.bin').read_bytes()
    if len(chars)!=21512:raise ValueError('Outside observed source grid extent')
    (out/'source-chars.bin').write_bytes(chars)
    plan=json.loads((prior/'plan.json').read_text(encoding='utf-8'));plan['sfc_graph_chars']=str(out/'source-chars.bin')
    native=out/'native'
    prepared=native_run(source,native,plan,compile=False,export=False,check=False,alias='SFCIMPL',prepare_only=True)
    save(out/'before-native.json',prepared)
    traced_run([prepared['executable'],prepared['plan_file']],(out/'TraceSFCGraphImplementation.js').read_text(encoding='utf-8'),native)
    messages=[json.loads(line) for line in (native/'events.jsonl').read_text(encoding='utf-8').splitlines()]
    events=[json.loads(line) for line in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    encoded=native/'sfc-encoded-tokens.bin'
    row=dict(hook_errors=[m for m in messages if m['type']!='send'],trace=[m['payload'] for m in messages if m['type']=='send'],
             encoded_prior_exact=encoded.exists() and encoded.read_bytes()==(prior/'sfc-encoded-tokens.bin').read_bytes(),
             source_unchanged=(native/'input.gxw').read_bytes()==source.read_bytes(),last_native_event=events[-1])
    save(out/'comparison.json',row);print(json.dumps(row,ensure_ascii=True),flush=True)
    if row['hook_errors'] or not row['encoded_prior_exact'] or not row['source_unchanged']:raise ValueError('Retained graph trace mismatch')

if __name__=='__main__':main()
