(()=>{
'use strict';
function hex(p,n){return Array.from(new Uint8Array(p.readByteArray(n)),v=>v.toString(16).padStart(2,'0')).join('');}
function where(p,depth=0){const m=Process.findModuleByAddress(p);if(!m)return {unknown_address:p.toString()};
 const value={module:m.name,path:m.path,rva:p.sub(m.base).toUInt32(),prefix:hex(p,16),exports:m.enumerateExports().filter(e=>e.address.equals(p)).map(e=>e.name)};
 if(depth<3&&p.readU16()===0x25ff)value.jump_target=where(ptr(p.add(2).readU32()).readPointer(),depth+1);
 return value;
}
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()==='_dnavi.dll'){
  for(const [role,rva,offset] of [['check',0x29210,0x1d0],['encode',0x292d0,0x1d8]]){
   Interceptor.attach(m.base.add(rva),{
    onEnter(){const backend=this.context.ecx.add(0x44).readPointer();send({event:'graph-service-implementation',role,
     target:where(backend.readPointer().add(offset).readPointer())});}
   });
  }
  return;
 }
 if(m.name.toLowerCase()!=='dzdatanavigatorserver.dll')return;
 for(const [role,rva,offset] of [['check',0x4bae,0x918],['encode',0x4d97,0x920]]){
  Interceptor.attach(m.base.add(rva),{
   onEnter(a){const backend=a[0].add(0x34).readPointer();
    send({event:'graph-implementation',role,server:where(m.base.add(rva)),target:where(backend.readPointer().add(offset).readPointer())});
    try{const handler=backend.add(0x48).readPointer(),service=handler.add(0x44).readPointer();
     send({event:'graph-owned-service',role,target:where(service.readPointer().add(role==='encode'?0x1d8:0x1d0).readPointer())});
     const inner=service.add(0x28).readPointer();send({event:'graph-owned-library',role,
      target:where(inner.readPointer().add(role==='encode'?0x10c:0x108).readPointer())});
     const socket=inner.add(4).readPointer(),provider=Process.findModuleByAddress(socket.add(0x20).readPointer());
     send({event:'graph-provider',role,module:provider.name,path:provider.path,
      functions:provider.enumerateExports().filter(e=>/ConvertSFCToPcode|CheckSFCError/.test(e.name)).map(e=>({name:e.name,target:where(e.address)}))});
    }catch(e){send({event:'graph-owned-service-unobserved',role,error:String(e)});}
   },
   onLeave(r){send({event:'server-graph-return',role,hresult:r.toInt32()});}
  });
 }
}});
})();
