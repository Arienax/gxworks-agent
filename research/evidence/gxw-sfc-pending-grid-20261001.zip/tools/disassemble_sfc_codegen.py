"""Bounded static inspection of the installed SFC code-generator adapter."""
from pathlib import Path
import json
import sys

ROOT=Path(__file__).resolve().parents[4]
sys.path.insert(0,str(ROOT/'research/experiments/re-tools'))
import pefile
import capstone


def main():
    start,stop=(int(x,16) for x in sys.argv[1:3])
    if not 0<=start<stop<=0x50000 or stop-start>0x1800:raise ValueError('Code-generator inspection extent exceeds its bound')
    path=Path('D:/GXWORKS2/DNaviZero/DataAbsorber/DZDataABS_CodeGenerator.dll');pe=pefile.PE(str(path))
    versions=[t.entries.get(b'FileVersion') for f in pe.FileInfo for b in f if b.Key==b'StringFileInfo' for t in b.StringTable]
    if b'1.635.0.1' not in versions:raise ValueError('Uninspected code-generator adapter version')
    base=pe.OPTIONAL_HEADER.ImageBase
    cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32)
    source='\n'.join(f'{i.address-base:05x} {i.mnemonic:8s} {i.op_str}' for i in cs.disasm(pe.get_data(start,stop-start),base+start))+'\n'
    destination=Path(__file__).with_name(f'dz-sfc-codegen-{start:05x}-{stop:05x}-20261001.txt')
    if destination.exists() and destination.read_text(encoding='utf-8')!=source:raise FileExistsError('Earlier static evidence differs')
    if not destination.exists():destination.write_text(source,encoding='utf-8')
    print(json.dumps(dict(path=str(path),version='1.635.0.1',image_base=hex(base),file_bytes=path.stat().st_size,image_bytes=pe.OPTIONAL_HEADER.SizeOfImage)))
    print(source,end='')


if __name__=='__main__':main()
