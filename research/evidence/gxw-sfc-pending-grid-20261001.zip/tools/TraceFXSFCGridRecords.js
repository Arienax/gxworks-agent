(()=>{
'use strict';
let installed=false,active=false;
function hex(p,n){return Array.from(new Uint8Array(p.readByteArray(n)),v=>v.toString(16).padStart(2,'0')).join('');}
function install(m){
 if(installed)return;installed=true;
 if(m.name.toLowerCase()!=='eccodegeneratorfx2.dll')throw new Error('Unobserved graph provider');
 for(const [rva,prefix] of Object.entries(EXPECTED_PREFIXES)){
  const current=hex(m.base.add(Number(rva)),prefix.length/2);
  if(current!==prefix)throw new Error('Uninspected graph entry prefix '+rva);
 }
 send({event:'graph-record-hooks',module:m.name,path:m.path,entries:EXPECTED_PREFIXES});
 Interceptor.attach(m.base.add(0x52fe2),{
  onEnter(){active=true;send({event:'grid-encode-entry'});},
  onLeave(r){active=false;send({event:'grid-encode-return',bytes:r.toUInt32()});}
 });
 Interceptor.attach(m.base.add(0x5c524),{
  onEnter(a){this.enabled=active;if(!this.enabled)return;this.x=a[0].toUInt32();this.y=a[1].toUInt32();this.work=a[2];},
  onLeave(r){if(!this.enabled||r.toUInt32()!==0)return;send({event:'grid-step-record',x:this.x,y:this.y,
   opcode:this.work.readU16(),number:this.work.add(2).readU16(),action:this.work.add(4).readU16(),transitions:this.work.add(12).readU16()});}
 });
 Interceptor.attach(m.base.add(0x5cc9c),{
  onEnter(a){this.enabled=active;if(!this.enabled)return;this.work=a[0];this.output=a[1];this.offset=a[2];this.begin=this.offset.readU32();
   send({event:'grid-record-output-entry',offset:this.begin,work_hex:hex(this.work,0x3dec)});},
  onLeave(r){if(!this.enabled)return;const end=this.offset.readU32();
   if(end<this.begin||end>65536)throw new Error('Outside owned graph output extent');
   send({event:'grid-record-output-return',offset:this.begin,end,bytes:r.toUInt32(),encoded_hex:hex(this.output.add(this.begin),end-this.begin)});}
 });
}
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='dzdatanavigatorserver.dll')return;
 Interceptor.attach(m.base.add(0x4d97),{
  onEnter(a){const nav=a[0].add(0x34).readPointer(),handler=nav.add(0x48).readPointer(),service=handler.add(0x44).readPointer(),inner=service.add(0x28).readPointer();
   const socket=inner.add(4).readPointer(),provider=Process.findModuleByAddress(socket.add(0x20).readPointer());install(provider);}
 });
}});
})();
