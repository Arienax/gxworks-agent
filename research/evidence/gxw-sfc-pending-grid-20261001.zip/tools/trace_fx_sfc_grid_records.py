"""Capture native intermediate records for independent grid-model comparisons."""
from pathlib import Path
import json
import struct
import sys
from probe_fx1s_lossless_project_patch import native_run
from probe_fx_operand_rules import traced_run

P=Path(__file__).resolve().parent
ROOT=P.parents[3]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research/experiments/re-tools')]
import pefile
from source_sfc_grid import read_grid,flow_connections

def save(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')

def work_projection(raw):
    u=lambda o:struct.unpack_from('<H',raw,o)[0]
    n=u(12)
    if n>32:raise ValueError('Outside observed native transition work allocation')
    edges=[]
    for i in range(1,n+1):
        arrays={}
        for role,count_offset,values_offset in [('targets',0x158,0x19a),('jump_s',0xa1c,0xa5e),('jump_set',0x12e0,0x1322)]:
            count=u(count_offset+2*i)
            if count>32:raise ValueError('Outside native edge work allocation')
            arrays[role]=[u(values_offset+2*(i*33+j)) for j in range(1,count+1)]
        edges.append(dict(opcode=u(0xe+2*i),number=u(0x50+2*i),incoming_marker=u(0x1ba4+2*i),**arrays))
    return dict(opcode=u(0),number=u(2),action=u(4),edges=edges)

def main():
    out=P/'fx-sfc-grid-records-20261001-v2';out.mkdir()
    for name in (Path(__file__).name,'TraceFXSFCGridRecords.js','source_sfc_grid.py'):(out/name).write_bytes((P/name).read_bytes())
    pe=pefile.PE('D:/GXWORKS2/Easysocket/CodeGenerator/ECCodeGeneratorFX2.dll')
    versions=[t.entries.get(b'FileVersion') for f in pe.FileInfo for b in f if b.Key==b'StringFileInfo' for t in b.StringTable]
    if b'15.31' not in versions:raise ValueError('Uninspected FX graph provider version')
    # These six-byte normal prologues have no absolute-address relocation.
    prefixes={str(rva):pe.get_data(rva,6).hex() for rva in (0x52fe2,0x5c524,0x5cc9c)}
    hook=(out/'TraceFXSFCGridRecords.js').read_text(encoding='utf-8').replace("'use strict';","'use strict';\nconst EXPECTED_PREFIXES="+json.dumps(prefixes)+';')
    (out/'resolved-hook.js').write_text(hook,encoding='utf-8')
    prior=P/'pending-sfc-source-chars-v3/three-steps-reopen/native-1'
    source=P.parent/'three-steps-reopen.gxw'
    base_plan=json.loads((prior/'plan.json').read_text(encoding='utf-8'))
    controls=[('linear',prior),('jump',P/'pending-sfc-source-chars-v3/jump3-pending/native-1'),
              ('parallel',P.parent/'decode-parallel-roundtrip'),('selective',P.parent/'decode-selective-roundtrip')]
    rows=[]
    for name,old in controls:
        directory=out/name;directory.mkdir()
        grid_raw=(old/'sfc-buffer-0.bin').read_bytes()[:21512]
        (directory/'source-chars.bin').write_bytes(grid_raw)
        image=read_grid(grid_raw)
        save(directory/'geometric-prediction-before-native.json',flow_connections(image))
        plan=dict(base_plan,sfc_graph_chars=str(directory/'source-chars.bin'))
        plan.pop('sfc_graph_edits',None);plan.pop('sfc_graph_tokens',None)
        native=directory/'native'
        prepared=native_run(source,native,plan,compile=False,export=False,check=False,alias='SFCGRIDIR',prepare_only=True)
        save(directory/'before-native.json',prepared)
        traced_run([prepared['executable'],prepared['plan_file']],hook,native)
        packets=[json.loads(line) for line in (native/'events.jsonl').read_text(encoding='utf-8').splitlines()]
        events=[p['payload'] for p in packets if p['type']=='send']
        records=[]
        for event in events:
            if event['event']!='grid-record-output-entry':continue
            raw=bytes.fromhex(event['work_hex']);index=len(records);(directory/f'work-{index}.bin').write_bytes(raw)
            records.append(dict(index=index,offset=event['offset'],**work_projection(raw)))
        enc=native/'sfc-encoded-tokens.bin';old_enc=old/'sfc-encoded-tokens.bin'
        native_events=[json.loads(line) for line in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
        row=dict(case=name,cpu='FX3U/FX3UC',provider_version='15.31',hook_errors=[p for p in packets if p['type']!='send'],records=records,
                 generated_encoded_bytes=enc.stat().st_size if enc.exists() else None,
                 encoded_prior_exact=enc.exists() and old_enc.exists() and enc.read_bytes()==old_enc.read_bytes(),
                 native_check=[e for e in native_events if e['operation'] in ('SFC.CheckResult','SFC.EncodeResult')],
                 source_unchanged=(native/'input.gxw').read_bytes()==source.read_bytes(),last_native_event=native_events[-1])
        save(directory/'comparison.json',row);rows.append(row);save(out/'comparison.json',rows)
        print(json.dumps(row,ensure_ascii=True),flush=True)
        if row['hook_errors'] or not row['source_unchanged'] or not records:raise ValueError('Retained grid trace incomplete')

if __name__=='__main__':main()
