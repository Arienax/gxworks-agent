"""Prospective FX source-grid predictions versus fresh native graph conversion."""
from pathlib import Path
import json
import struct
import sys
from probe_fx1s_lossless_project_patch import native_run
from probe_fx_operand_rules import traced_run
from trace_fx_sfc_grid_records import work_projection
from source_fx_sfc_grid_encoder import encode_grid,UnsupportedGrid
from source_sfc_grid import read_grid,flow_connections

P=Path(__file__).resolve().parent

def save(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')

def setcell(raw,x,y,kind,number):
    width=struct.unpack_from('<H',raw)[0];offset=8+3*(y*width+x)
    raw[offset:offset+3]=bytes((kind,))+struct.pack('<H',number)

def renumber(raw,steps,transitions):
    image=read_grid(raw);old=bytes(raw)
    for s in image.symbols:
        n=s.get('number')
        if s['result']==1 and n in steps:
            value=steps[n];setcell(raw,s['x'],s['y'],old[s['source_offset']],value)
            if s['type'] not in (14,15):struct.pack_into('<H',raw,9224+2*value,s['action_record_index'])
        elif s['result']==2 and n in transitions:setcell(raw,s['x'],s['y'],0x80,transitions[n])

def variants():
    previous=P/'fx-sfc-grid-records-20261001-v2'
    base={n:(previous/n/'source-chars.bin').read_bytes() for n in ('linear','parallel','selective')}
    rows=[]
    raw=bytearray(base['linear']);renumber(raw,{1:255,2:256},{1:255,2:256})
    rows.append(('linear-reference-boundaries',bytes(raw),base['linear']))
    raw=bytearray(base['linear']);struct.pack_into('<H',raw,15369+7,255);struct.pack_into('<H',raw,15369+14,256)
    rows.append(('linear-action-boundaries',bytes(raw),base['linear']))
    raw=bytearray(base['selective']);renumber(raw,{1:255,2:256},{1:255,2:256,3:511})
    rows.append(('selective-reference-boundaries',bytes(raw),base['selective']))
    for tag in ('parallel','selective'):
        raw=bytearray(base[tag]);struct.pack_into('<H',raw,4,3)
        # New step 3 deliberately reuses the existing action record of step 2.
        setcell(raw,2,3,0x64,3);struct.pack_into('<H',raw,9224+2*3,2)
        if tag=='parallel':
            setcell(raw,1,2,0xc0,0x9d);setcell(raw,2,2,0xc0,0x99)
            setcell(raw,1,4,0xc0,0xae);setcell(raw,2,4,0xc0,0xaa)
        else:
            setcell(raw,1,1,0xc0,0x5d);setcell(raw,2,1,0xc0,0x59)
            setcell(raw,2,2,0x80,4);setcell(raw,2,4,0x80,5)
            setcell(raw,1,5,0xc0,0x6e);setcell(raw,2,5,0xc0,0x6a)
        rows.append((tag+'-three-paths',bytes(raw),base[tag]))
    raw=bytearray(base['selective']);raw[-1]=0x73
    rows.append(('opaque-suffix-preserved',bytes(raw),base['selective']))
    raw=bytearray(base['linear']);setcell(raw,0,9,0,0)
    rows.append(('incomplete-source',bytes(raw),base['linear']))
    missing=(P/'fx-sfc-grid-prospective-20261001-v1/linear-reference-boundaries/source-chars.bin').read_bytes()
    rows.append(('missing-action-index',missing,base['linear']))
    return rows

def main():
    out=P/'fx-sfc-grid-prospective-20261001-v2';out.mkdir()
    for name in (Path(__file__).name,'source_fx_sfc_grid_encoder.py','source_sfc_grid.py','TraceFXSFCGridRecords.js'):
        (out/name).write_bytes((P/name).read_bytes())
    prior=P/'pending-sfc-source-chars-v3/three-steps-reopen/native-1'
    source=P.parent/'three-steps-reopen.gxw'
    plan=json.loads((prior/'plan.json').read_text(encoding='utf-8'))
    hook=(P/'fx-sfc-grid-records-20261001-v2/resolved-hook.js').read_text(encoding='utf-8')
    (out/'resolved-hook.js').write_text(hook,encoding='utf-8')
    ready=[]
    # All source-only predictions are saved before the first native run.
    for name,raw,base in variants():
        directory=out/name;directory.mkdir();(directory/'source-chars.bin').write_bytes(raw)
        save(directory/'geometric-prediction.json',flow_connections(read_grid(raw)))
        prediction=dict(case=name,input_bytes=len(raw),changed_offsets=[i for i in range(len(raw)) if raw[i]!=base[i]],scope='FX reference graph only; no external ladder bodies or project acceptance claim')
        try:
            model=encode_grid(raw);(directory/'expected-tokens.bin').write_bytes(model.tokens)
            for i,r in enumerate(model.records):(directory/f'expected-work-{i}.bin').write_bytes(r['raw'])
            prediction.update(handling='reference-projected',records=len(model.records),encoded_bytes=len(model.tokens),raw_preserved=model.reconstruction()==raw)
        except UnsupportedGrid as e:prediction.update(handling='unsupported/opaque-preserved',reason=str(e))
        save(directory/'before-native.json',prediction);ready.append((directory,prediction))
    rows=[]
    for directory,prediction in ready:
        own_plan=dict(plan,sfc_graph_chars=str(directory/'source-chars.bin'));own_plan.pop('sfc_graph_edits',None);own_plan.pop('sfc_graph_tokens',None)
        native=directory/'native'
        prepared=native_run(source,native,own_plan,compile=False,export=False,check=False,alias='SFCGRIDNEW',prepare_only=True)
        save(directory/'owned-helper.json',prepared)
        traced_run([prepared['executable'],prepared['plan_file']],hook,native)
        packets=[json.loads(line) for line in (native/'events.jsonl').read_text(encoding='utf-8').splitlines()]
        native_events=[json.loads(line) for line in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
        records=[bytes.fromhex(p['payload']['work_hex']) for p in packets if p['type']=='send' and p['payload']['event']=='grid-record-output-entry']
        for i,raw in enumerate(records):(directory/f'native-work-{i}.bin').write_bytes(raw)
        enc=native/'sfc-encoded-tokens.bin';expected=directory/'expected-tokens.bin'
        predicted=prediction['handling']=='reference-projected'
        row=dict(case=prediction['case'],prediction=prediction,hook_errors=[p for p in packets if p['type']!='send'],
                 native_check=[e for e in native_events if e['operation'] in ('SFC.CheckResult','SFC.EncodeResult','SFC.EncodeSkipped')],
                 native_encoded_bytes=enc.stat().st_size if enc.exists() else None,
                 encoded_prediction_exact=enc.read_bytes()==expected.read_bytes() if enc.exists() and expected.exists() else None,
                 work_prediction_exact=len(records)==prediction.get('records') and all(raw==(directory/f'expected-work-{i}.bin').read_bytes() for i,raw in enumerate(records)) if predicted else None,
                 native_source_chars_preserved=(native/'sfc-buffer-0.bin').read_bytes()[:21512]==(directory/'source-chars.bin').read_bytes(),
                 source_project_unchanged=(native/'input.gxw').read_bytes()==source.read_bytes(),
                 intermediate_records=[work_projection(raw) for raw in records],last_native_event=native_events[-1])
        save(directory/'comparison.json',row);rows.append(row);save(out/'comparison.json',rows)
        print(json.dumps({k:v for k,v in row.items() if k not in ('prediction','intermediate_records','last_native_event')},ensure_ascii=True),flush=True)
    if any(r['hook_errors'] or not r['source_project_unchanged'] for r in rows):raise ValueError('Retained native grid run failed')
    if any(r['prediction']['handling']=='reference-projected' and
           (r['encoded_prediction_exact'] is not True or r['work_prediction_exact'] is not True) for r in rows):
        raise ValueError('Prospective graph prediction differs; complete source and native failure retained')

if __name__=='__main__':main()
