"""Full pending-source assembly predictions and native save/reopen controls."""
from pathlib import Path
import json
import struct
from probe_fx_sfc_shared_child import P,source_programs,child_identity,read,save
from probe_fx1s_lossless_project_patch import native_run
from gxw.container_writer import replace_stream_within_allocation
from source_fx_sfc_pending_projection import source_grid,project_projection
from source_fx_sfc_grid_encoder import encode_grid
from source_fx_sfc_lossless_reader import FXSfcLosslessReader

def prepare(out):
    original=(P.parent/'three-steps-reopen.gxw').read_bytes();resolver,programs=source_programs(original)
    if len(programs)!=1:raise ValueError('Expected one owned pending SFC block')
    owner,selected=next(iter(programs.items()));stored=selected['source'].raw
    source,chars,extent=source_grid(stored);at=extent['chars_offset']
    variants=[('untouched-control',stored)]
    raw=bytearray(stored);old0,old2=struct.unpack_from('<H',chars,9224)[0],struct.unpack_from('<H',chars,9228)[0]
    struct.pack_into('<H',raw,at+9224,old2);struct.pack_into('<H',raw,at+9228,old0)
    variants.append(('action-index-swap',bytes(raw)))
    raw=bytearray(stored);index2=struct.unpack_from('<H',chars,9228)[0]
    struct.pack_into('<H',raw,at+15369+7*index2,256)
    action,=[a for a in source.layout['actions'] if a['number']==20]
    struct.pack_into('<I',raw,action['number_offset'],256)
    variants.append(('action-reference-256',bytes(raw)))
    ready=[]
    for name,replacement in variants:
        directory=out/name;directory.mkdir();after_source,after_chars,after_extent=source_grid(replacement)
        graph=encode_grid(after_chars)
        inner=replace_stream_within_allocation(resolver.outer.read_stream('_hdb'),selected['stream'],replacement)
        candidate=replace_stream_within_allocation(original,'_hdb',inner);after,_=source_programs(candidate)
        untouched_inner=[e.name for e in resolver.hdb.iter_streams() if e.name!=selected['stream']]
        untouched_outer=[e.name for e in resolver.outer.iter_streams() if e.name!='_hdb']
        if any(resolver.hdb.read_stream(n)!=after.hdb.read_stream(n) for n in untouched_inner):raise ValueError('Unrelated inner stream changed')
        if any(resolver.outer.read_stream(n)!=after.outer.read_stream(n) for n in untouched_outer):raise ValueError('Unrelated outer stream changed')
        cache=extent['cache_offset'];cache_end=extent['start']+extent['size']
        if replacement[cache:cache_end]!=stored[cache:cache_end]:raise ValueError('Opaque cache or pending suffix changed')
        expected,projection=project_projection(candidate);decoded=FXSfcLosslessReader().read(expected,cpu=520)
        (directory/'input.gxw').write_bytes(candidate);(directory/'source-pou.bin').write_bytes(replacement)
        (directory/'source-chars.bin').write_bytes(after_chars);(directory/'expected-graph.bin').write_bytes(graph.tokens)
        (directory/'expected-pcode.bin').write_bytes(expected)
        proof=dict(case=name,owner=owner,logical=selected['logical'],source_bytes=len(replacement),
                   changed_source_offsets=[i for i,(a,b) in enumerate(zip(stored,replacement,strict=True)) if a!=b],
                   opaque_cache_and_suffix_exact=True,unrelated_inner_streams=len(untouched_inner),unrelated_outer_streams=len(untouched_outer),
                   unrelated_payloads_exact=True,expected_graph_bytes=len(graph.tokens),expected_resource_bytes=len(expected),
                   expected_partition_raw_exact=FXSfcLosslessReader.reconstruct(decoded)==expected,coverage=decoded['coverage'],projection=projection)
        save(directory/'prediction-before-native.json',proof);ready.append((directory,proof))
    save(out/'predictions-before-native.json',[proof for _,proof in ready]);return ready

def main():
    out=P/'fx-sfc-pending-source-projection-20261001-v1';out.mkdir()
    for name in (Path(__file__).name,'source_fx_sfc_pending_projection.py','source_fx_sfc_grid_encoder.py','source_sfc_grid.py'):
        (out/name).write_bytes((P/name).read_bytes())
    ready=prepare(out);plan=read(P/'pending-sfc-source-chars-v3/three-steps-reopen/native-1/plan.json');rows=[]
    for directory,proof in ready:
        own_plan=dict(plan,sfc_graph_chars=str(directory/'source-chars.bin'))
        native=directory/'compile';result=native_run(directory/'input.gxw',native,own_plan,compile=True,export=True,alias='SFCPENDING')
        expected=(directory/'expected-pcode.bin').read_bytes();body=native/'pcode-0-0.bin';saved=native/'native-saved.gxw'
        row=dict(case=proof['case'],compile=result,resource_pcode_exact=body.exists() and body.read_bytes()==expected,
                 independent_graph_exact=(native/'sfc-encoded-tokens.bin').read_bytes()==(directory/'expected-graph.bin').read_bytes())
        if saved.exists():
            original_sources=source_programs((directory/'input.gxw').read_bytes())[1];saved_sources=source_programs(saved.read_bytes())[1]
            row['saved_child_bodies_exact']={k:child_identity(v['source'])['children'] for k,v in original_sources.items()}=={k:child_identity(v['source'])['children'] for k,v in saved_sources.items()}
            row['saved_action_registrations_exact']={k:[(a['name'],a['number'],a['registrations']) for a in v['source'].layout['actions']] for k,v in original_sources.items()}=={k:[(a['name'],a['number'],a['registrations']) for a in v['source'].layout['actions']] for k,v in saved_sources.items()}
            saved_expected,_=project_projection(saved.read_bytes());row['saved_source_prediction_exact']=saved_expected==expected
            reopen_plan=dict(plan);reopen_plan.pop('sfc_graph_chars',None)
            reopened=native_run(saved,directory/'reopen',reopen_plan,compile=True,export=False,alias='SFCPENDING')
            row['reopen']=reopened;row['fresh_saved_compile_exact']=(directory/'reopen/pcode-0-0.bin').read_bytes()==saved_expected
        save(directory/'comparison.json',row);rows.append(row);save(out/'comparison.json',rows)
        print(json.dumps(dict(case=proof['case'],resource_pcode_exact=row['resource_pcode_exact'],independent_graph_exact=row['independent_graph_exact'],
              compile_rejected=result['compiler_rejected'],exported=result['exported'],program_check=result['program_check'],
              saved_child_bodies_exact=row.get('saved_child_bodies_exact'),saved_action_registrations_exact=row.get('saved_action_registrations_exact'),
              saved_source_prediction_exact=row.get('saved_source_prediction_exact'),fresh_saved_compile_exact=row.get('fresh_saved_compile_exact'),
              reopened_rejected=row.get('reopen',{}).get('compiler_rejected'),reopen_program_check=row.get('reopen',{}).get('program_check')),ensure_ascii=True),flush=True)
    for row in rows:
        exact=('resource_pcode_exact','independent_graph_exact','saved_child_bodies_exact',
               'saved_action_registrations_exact','saved_source_prediction_exact','fresh_saved_compile_exact')
        if not all(row.get(k) is True for k in exact):raise ValueError('Retained pending source prediction mismatch')
        for stage in ('compile','reopen'):
            result=row[stage]
            if result['compiler_rejected'] or not result['program_check'] or any(r['rejected'] for r in result['program_check']):
                raise ValueError('Retained pending source native check failure')

if __name__=='__main__':main()
