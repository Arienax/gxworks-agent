"""Inspect saved IF-tree observations; finite witnesses, no compiler rerun.

Raw 73-byte node cells and opaque fields remain in the original event files.
This identifies only the measured IF/ELSE and branch-pair child relationships.
"""
from pathlib import Path
import base64,json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.token_pou import LadderToken,TokenProgram
from gxw.token_listing import decode_token_program,TokenInstruction,TokenLabel
from gxw.project_metadata import read_project_text_context
from probe_minimal_conditional_port_writes import streams,save
from source_q_direct_declarations import DirectDeclarations
from source_q_st_calls import predict
from native_gxw_tokens import native_batch,native_il_records
from witness_st_conditional_transfers import evaluate
P=Path(__file__).resolve().parent


def decode(raw,profile):
    tokens=[];at=0
    while at<len(raw):
        size=raw[at];part=raw[at:at+size]
        if size<2 or len(part)!=size or part[-1]!=size:raise ValueError('framing')
        tokens.append(LadderToken(at,part));at+=size
    listing=decode_token_program(TokenProgram(raw,tuple(tokens),0,len(raw)),profile=profile,text_encoding='cp932')
    rows=[]
    for r in listing.records:
        row=dict(offset=r.tokens[0].offset,raw=''.join(t.raw.hex() for t in r.tokens))
        if isinstance(r,TokenInstruction):row.update(kind='instruction',op=r.mnemonic,args=list(r.args))
        elif isinstance(r,TokenLabel):row.update(kind='label',text=r.text)
        else:raise ValueError('independent decoder gap '+str(r))
        rows.append(row)
    return rows


def main():
    q_expected={'Else-nested':'FX','Non-tail':'FXY','Tail-no-else':'T','Loop':'TX'}
    fx_expected={'Else-nested':'TX','Non-tail':'TXY','Tail-no-else':'TX','Loop':'TX'}
    for group,fx,expected in [('q-st-branch-tree-forward-20260930',False,q_expected),('fx-st-branch-tree-forward-20260930',True,fx_expected)]:
        out=P/group;comparison=json.loads((out/'comparison.json').read_text());plan=json.loads((out/'experiment-plan.json').read_text())
        if fx:
            requests=[dict(mode='decode',input_base64=base64.b64encode((Path(r['native_directory'])/'pcode-0-0.bin').read_bytes()+b'\0').decode()) for r in comparison]
            answers=native_batch(requests,out/'independent-native-decode',cpu_code=520)
            native={}
            for row,request,answer in zip(comparison,requests,answers,strict=True):
                assert answer['return_code']=='0x00000000' and answer['consumed_bytes']==len(base64.b64decode(request['input_base64']))-1
                native[row['case']]=native_il_records(base64.b64decode(answer['output_base64']),encoding='cp932')
            save(out/'native-listings.json',[dict(case=k,records=v) for k,v in native.items()])
        else:native={r['case']:r['records'] for r in json.loads((out/'native-listings.json').read_text())}
        findings=[]
        for row in comparison:
            name=row['case'];n=Path(row['native_directory']);raw=(n/'pcode-0-0.bin').read_bytes();source=(n/'input.gxw').read_bytes()
            records=decode(raw,'fx3u' if fx else 'q03udv')
            lexical=[{k:v for k,v in r.items() if k not in ('offset','raw')} for r in records]
            assert lexical==native[name],(name,'independent/native lexical mismatch')
            opts=plan['prediction_options'];defs=('Keypad',) if fx else ('SCPI',);owner='POU_01' if fx else 'MAIN'
            if fx:prediction=predict(source,defs,owner=owner,**opts)
            else:prediction=predict(source,defs,owner=owner,allow_inputs=True,allow_omitted=True,allow_members=True,**opts)
            assert prediction['output']==raw==(out/name/'predicted-0.bin').read_bytes()
            content={k:v for k,v in streams(source).items() if k!='CGTable.dat'}
            context=read_project_text_context(next(v for k,v in content.items() if k.endswith('.prj')))
            declarations=DirectDeclarations(content,context['text_encoding'],local_fb_definitions=defs,allow_string_arrays=True);declarations.add_owner(owner)
            selections={'result':(owner,'number_buffer' if fx else 'prober1'),'key_iterator':('POU_01.keypad_a' if fx else 'MAIN.First','key_iterator')}
            if not fx:selections['copied']=(owner,'prober2')
            bindings={}
            for key,(scope,var) in selections.items():
                item=declarations.bound[scope][var];bindings[key]=dict(address=item['family']+str(item['number']),type=item['row'].data_type)
            witness=evaluate(records,bindings,allow_boolean=True,profile='fx3u' if fx else 'q03udv')
            observed=dict(result=expected[name],key_iterator=2 if name=='Loop' else 0)
            if not fx:observed['copied']=expected[name]
            assert witness['observations']==observed,(group,name,witness['observations'],observed)
            events=[json.loads(line).get('payload',{}) for line in (n/'events.jsonl').read_text().splitlines()]
            errors=[r for r in events if r.get('event') in ('block-walk-guard-error','block-walk-observation-error')]
            assert not errors,(name,errors)
            graphs=[r for r in events if r.get('event')=='block-walk' and r.get('phase')=='enter' and r.get('name')=='wrapper' and any(x['type']==0x17e for x in r.get('graph',[]))]
            assert graphs
            graph=graphs[-1]['graph'];by_id={r['id']:r for r in graph};branches=[]
            for node in graph:
                if node['type']!=0x17e:continue
                pair=by_id[node['link16']];assert pair['type']==0x185
                branches.append(dict(node=node,pair=pair,condition=by_id[node['link12']],else_child=by_id[pair['link12']] if pair['link12'] else None,then_child=by_id[pair['link16']] if pair['link16'] else None))
            save(out/name/'finite-branch-witness.json',dict(bindings=bindings,expected=observed,**witness))
            save(out/name/'branch-node-ir.json',dict(scope='Measured 17e -> condition/185 pair; 185 -> ELSE/THEN. Other fields retained opaque, not interpreted.',graphs=graphs,branches=branches))
            result=dict(case=name,before_native_byte_match=True,independent_lexical_match=True,compile_check_reopen=not row['check']['rejected'] and not row['reopen']['check']['rejected'],labels=[r['text'] for r in records if r['kind']=='label'],witness=witness['observations'],if_else_nodes=len(branches),graph_cell_inventory_truncated=any(g['graph_truncated'] for g in graphs),observer_errors=errors)
            findings.append(result);print(json.dumps(dict(group=group,**result)),flush=True)
        save(out/'branch-tree-findings.json',dict(scope='Prospective bounded two-level scalar INT/WORD IF trees, finite initialized ASCII/word witnesses; no PLC execution, no general ST semantics claim.',cases=findings))
        (out/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
        (out/'witness_st_conditional_transfers.py').write_bytes((P/'witness_st_conditional_transfers.py').read_bytes())


if __name__=='__main__':main()
