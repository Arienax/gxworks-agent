"""Extract the inspected native opcode and operand-cell mapping tables."""
from pathlib import Path
import json
import struct
import pefile

P = Path(__file__).resolve().parent


def main():
    path = P / 'fx-instruction-cell-tables-20261001-v1.json'
    if path.exists():
        raise FileExistsError('Prior table evidence must not be replaced')
    dll = Path('D:/GXWORKS2/Easysocket/CodeGenerator/ECCodeGeneratorFX2.dll')
    pe = pefile.PE(str(dll))
    image = pe.get_memory_mapped_image()
    base = pe.OPTIONAL_HEADER.ImageBase
    opcodes = []
    for index in range(451):
        raw = image[0x8c840 + 6 * index:0x8c840 + 6 * (index + 1)]
        family, variant, kind, function, flags = struct.unpack('<BBBHB', raw)
        opcodes.append(dict(index=index, family=family, variant=variant, kind=kind,
                            function=function, flags=flags, raw=raw.hex()))
    devices = {}
    for code in range(0x90, 0x100):
        raw = image[0x8d2d8 + 6 * (code - 0x90):0x8d2d8 + 6 * (code - 0x90 + 1)]
        pointer = struct.unpack_from('<I', raw, 2)[0]
        rva, name = pointer - base, None
        if 0 <= rva < len(image):
            end = image.find(b'\0', rva, rva + 32)
            if end >= rva:
                name = image[rva:end].decode('ascii')
        devices[str(code)] = dict(recognized=raw[0], category=raw[1], name=name,
                                 name_rva=rva, raw=raw.hex())
    tables = dict(dll=str(dll), file_version='15.31', cpu=521, mode=0, versions=[],
                  opcode_rva=0x8c840, opcode_rows=451, device_rva=0x8d2d8,
                  instruction_state_bytes=88, unit_bytes=8, auxiliary_bytes=68,
                  opcodes=opcodes, devices=devices,
                  scope='Inspected native mapping tables. Native cell projection retains source tokens and is not an execution or whole-instruction validity oracle.')
    path.write_text(json.dumps(tables, indent=2, ensure_ascii=True) + '\n', encoding='utf-8')
    print(json.dumps(dict(opcodes=len(opcodes), devices=len(devices)), ensure_ascii=True))


if __name__ == '__main__':
    main()
