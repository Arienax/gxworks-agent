"""Source-only machine predictions, persisted before reading retained answers."""
import argparse
import collections
import json

from probe_fx_operand_rules import P, save
from source_fx_machine import FXMachine
from source_fx_operand_rules import Unsupported


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--attempt', type=int, required=True)
    args = parser.parse_args()
    out = P / f'fx-source-machine-crosscheck-20261001-v{args.attempt}'
    out.mkdir()
    origins = [P / 'fx-machine-step-emission-full-corpus-20261001-v1', P / 'fx-instruction-cell-holdouts-20261001-v1']
    model = FXMachine()
    predictions, gaps = [], []
    for origin in origins:
        requests = json.loads((origin / 'before-native.json').read_text(encoding='utf-8'))['requests']
        for request in requests:
            try:
                predictions.append(dict(origin=origin.name, id=request['id'], prediction=model.record(bytes.fromhex(request['raw']))))
            except Unsupported as exc:
                gaps.append(dict(origin=origin.name, id=request['id'], raw=request['raw'], reason=str(exc)))
    save(out / 'predictions-before-answer.json', predictions)
    save(out / 'generation-gaps.json', gaps)
    for name in ('source_fx_machine.py', 'fx-machine-tables-20261001-v1.json', 'source_fx_instruction_cells.py', 'fx-instruction-cell-tables-20261001-v1.json'):
        (out / name).write_bytes((P / name).read_bytes())
    answers = {}
    for origin in origins:
        if origin == origins[0]:
            for row in json.loads((origin / 'machine-width-comparison.json').read_text(encoding='utf-8')):
                answers[(origin.name, row['id'])] = dict(words=row['machine_words'], output=row['machine_output'], before=row['header'], after=row['header'])
        else:
            for row in json.loads((origin / 'emissions.json').read_text(encoding='utf-8')):
                answers[(origin.name, row['id'])] = row['native']
    differences, matched, unavailable = [], collections.defaultdict(collections.Counter), []
    for row in predictions:
        answer = answers.get((row['origin'], row['id']))
        if answer is None:
            unavailable.append(dict(origin=row['origin'], id=row['id'], reason='Public check did not reach the emitter'))
            continue
        predicted = row['prediction']['emission']
        same = dict(words=answer['words'] == predicted['words'], cells_before=answer['before'] == row['prediction']['native_cells'],
                    cells_after=answer['after'] == predicted['cells_after'])
        if predicted['machine_output'] is not None:
            same['machine_bytes'] = predicted['machine_output'] == answer['output']
        else:
            matched[row['origin']]['undefined_output_words'] += 1
        for key, value in same.items():
            if value:
                matched[row['origin']][key] += 1
        matched[row['origin']]['observed'] += 1
        if not all(same.values()):
            differences.append(dict(origin=row['origin'], id=row['id'], matches=same, predicted=row['prediction'], native=answer))
    save(out / 'differences.json', differences)
    save(out / 'no-emitter-observation.json', unavailable)
    summary = dict(predictions=len(predictions), generation_gaps=len(gaps), comparison={k:dict(v) for k,v in matched.items()},
                   differences=len(differences), no_emitter_observation=len(unavailable),
                   gap_reasons=dict(collections.Counter(r['reason'] for r in gaps)),
                   scope='CPU 521/version 15.31/mode 9. Static source-derived rules versus retained original machine emission. Undefined output words are not normalized to zero. Native emission acceptance does not establish source range or project validity.')
    save(out / 'comparison.json', summary)
    print(json.dumps(summary, ensure_ascii=True), flush=True)
    if differences:
        raise ValueError('Machine encoding differences retained before any repair')


if __name__ == '__main__':
    main()
