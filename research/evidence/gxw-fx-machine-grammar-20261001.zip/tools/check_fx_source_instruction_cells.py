"""Source-only lowering predictions against the retained native emission trace."""
from pathlib import Path
import collections
import json

from source_fx_instruction_cells import FXInstructionCells
from source_fx_operand_rules import Unsupported

P = Path(__file__).resolve().parent


def main():
    out = P / 'fx-source-instruction-cells-full-corpus-20261001-v1'
    out.mkdir()
    origin = P / 'fx-machine-step-emission-full-corpus-20261001-v1'
    raw_requests = json.loads((origin / 'before-native.json').read_text(encoding='utf-8'))['requests']
    model = FXInstructionCells()
    predictions, gaps = [], []
    for request in raw_requests:
        try:
            prediction = model.record(bytes.fromhex(request['raw']))
            predictions.append(dict(id=request['id'], native_listing=request['native_listing'], prediction=prediction))
        except Unsupported as exc:
            gaps.append(dict(id=request['id'], raw=request['raw'], native_listing=request['native_listing'], reason=str(exc)))
    # Do not read native machine-state answers until all predictions are saved.
    (out / 'predictions-before-answer.json').write_text(json.dumps(predictions, indent=2, ensure_ascii=True) + '\n', encoding='utf-8')
    (out / 'generation-gaps.json').write_text(json.dumps(gaps, indent=2, ensure_ascii=True) + '\n', encoding='utf-8')
    for name in ('source_fx_instruction_cells.py', 'fx-instruction-cell-tables-20261001-v1.json'):
        (out / name).write_bytes((P / name).read_bytes())
    answers = {r['id']:r for r in json.loads((origin / 'machine-width-comparison.json').read_text(encoding='utf-8'))}
    differences, matches = [], []
    for row in predictions:
        native, predicted = answers[row['id']], row['prediction']
        same = native['header'] == predicted['native_cells'] and native['devices'] == predicted['auxiliary']
        if same:
            matches.append(row['id'])
        else:
            a, b = bytes.fromhex(predicted['native_cells']), bytes.fromhex(native['header'])
            differences.append(dict(id=row['id'], native_listing=row['native_listing'], raw=predicted['raw'],
                predicted=predicted, native=native,
                cell_differences=[dict(offset=i, predicted=x, native=y) for i,(x,y) in enumerate(zip(a,b,strict=True)) if x != y]))
    (out / 'differences.json').write_text(json.dumps(differences, indent=2, ensure_ascii=True) + '\n', encoding='utf-8')
    summary = dict(records=len(raw_requests), predictions=len(predictions), gaps=len(gaps),
                   native_instruction_cells_exact=len(matches), differences=len(differences),
                   kinds=dict(collections.Counter(bytes.fromhex(r['prediction']['native_cells'])[2] for r in predictions)),
                   cell_counts=dict(collections.Counter(r['prediction']['used_cells'] for r in predictions)),
                   gap_reasons=dict(collections.Counter(r['reason'] for r in gaps)),
                   scope='Static native opcode/device tables and source-only token mapping versus prior original-function emission observations. No native answers are used to construct cell contents.')
    (out / 'comparison.json').write_text(json.dumps(summary, indent=2, ensure_ascii=True) + '\n', encoding='utf-8')
    print(json.dumps(summary, ensure_ascii=True), flush=True)
    if differences:
        raise ValueError('Source-only native instruction-state differences retained')


if __name__ == '__main__':
    main()
