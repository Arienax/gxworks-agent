"""Prospective source-only predictions versus owned public FX raw checks.

New operand values and modifier spellings exercise prior reachable instruction
keys, plus explicit raw alias and counter boundaries. No controller is opened.
"""
import base64
import collections
import json
import struct
import subprocess

from probe_fx_operand_rules import DLL, P, save, traced_run
from source_fx_instruction_cells import FXInstructionCells
from source_fx_operand_rules import Unsupported


def numeric(code, value, width=None):
    width = width or max(1, (value.bit_length() + 7) // 8)
    n = width + 3
    return bytes([n, code]) + value.to_bytes(width, 'little') + bytes([n])


def new_requests():
    prior = P / 'fx-operand-rule-raw-holdouts-20261001-v1'
    rows = json.loads((prior / 'before-native.json').read_text(encoding='utf-8'))['requests']
    accepted = {r['id'] for r in json.loads((prior / 'outcomes.json').read_text(encoding='utf-8')) if r['check_accepted']}
    old_raw = {r['raw'] for r in rows}
    requests, seen, repeats = [], set(), []
    def add(raw, name, profile, family, variant, origin=None):
        if raw.hex() in seen or raw.hex() in old_raw:
            repeats.append(dict(raw=raw.hex(), name=name, profile=profile, origin=origin))
            return
        seen.add(raw.hex())
        requests.append(dict(id=len(requests), name=name, profile=profile, family=family, variant=variant,
                             raw=raw.hex(), input_base64=base64.b64encode(raw).decode(), origin=origin))
    for row in rows:
        if row['id'] not in accepted:
            continue
        raw = bytes.fromhex(row['raw'])
        header, at, tokens = raw[:raw[0]], raw[0], []
        position = 0
        while at < len(raw):
            n, code = raw[at], raw[at + 1]
            old = raw[at:at + n]
            value = int.from_bytes(old[2:-1], 'little')
            if code == 0xec:
                token = bytes([7, code]) + struct.pack('<f', -3.25) + bytes([7])
            elif code == 0xf0:
                token = numeric(0xf4, 1 + row['id'] % 7)
            elif code == 0xf1:
                token = numeric(code, 3 if value == 4 else 7)
            elif code in (0xe8, 0xea):
                token = numeric(code, 0x8123, 2)
            elif code in (0xe9, 0xeb):
                token = numeric(code, 0x89abcdef, 4)
            elif code in (0xa8, 0xaf):
                token = numeric(code, 256 + position * 3, 2)
            elif code == 0x90:
                token = numeric(code, 31 + position)
            elif code in (0x9c, 0x9d):
                token = numeric(code, 7 + position)
            elif code in (0xd0, 0xd1, 0xd2):
                token = numeric(code, 1)
            elif code in (0xc2, 0xc5):
                token = numeric(code, 199)
            else:
                token = old
            if code < 0xf0:
                position += 1
            tokens.append(token)
            at += n
        add(header + b''.join(tokens), row['name'], 'new-values/' + row['profile'], row['family'], row['variant'], row['id'])
        if header[1] >= 0x40 and len(header) == 5 and row['profile'] == 'table-selected':
            pulse = bytes([6, header[1], 127, header[3], 2, 6])
            add(pulse + b''.join(tokens), row['name'], 'pulse-header/new-values', row['family'], row['variant'], row['id'])
    mov, dmov = bytes.fromhex('054c7f0005'), bytes.fromhex('054c7f0105')
    for name, header in [('MOV', mov), ('DMOV', dmov)]:
        for address in (0, 255, 256, 999, 1000, 7999, 8000, 32767, 32768, 65535, 65536, 65537, 0x1000000):
            for width in sorted({max(1, (address.bit_length() + 7) // 8), 4}):
                add(header + numeric(0xa8, address, width) + numeric(0xa8, 304, 2), name,
                    f'address-{address}/payload-{width}', 0x4c, header[3])
        for code in (0xe8, 0xe9, 0xea, 0xeb):
            for value in (0, 0x7fff, 0x8000, 0xffff, 0x10000, 0x12345678, 0xffffffff):
                add(header + numeric(code, value, 4) + numeric(0xa8, 304, 2), name,
                    f'literal-{code:02x}-{value}/payload-4', 0x4c, header[3])
    for code in (0xc2, 0xc5):
        for address in (0, 199, 200, 255, 256, 32767, 32768, 65535):
            for preset_code, preset in [(0xe8, 0x8001), (0xe8, 0xffff), (0xe9, 0x12345678), (0xa8, 301)]:
                add(bytes.fromhex('04217f04') + numeric(code, address) + numeric(preset_code, preset), 'OUT',
                    f'counter-timer-{code:02x}-{address}/preset-{preset_code:02x}', 0x21, 0)
    for output in (numeric(0x90, 33), numeric(0x9d, 2)):
        add(bytes.fromhex('042c7f04') + numeric(0xd2, 2) + output, 'MC', 'fresh-MC-operands', 0x2c, 0)
    return requests, repeats


def main():
    out = P / 'fx-instruction-cell-holdouts-20261001-v1'
    out.mkdir()
    model = FXInstructionCells()
    requests, repeats = new_requests()
    predictions, gaps = {}, []
    for row in requests:
        try:
            prediction = model.record(bytes.fromhex(row['raw']))
            phases = []
            raw = bytes.fromhex(row['raw'])
            state, count = model.instruction(raw[:raw[0]])
            phases.append(dict(event='instruction-cells', raw=raw[:raw[0]].hex(), after=state.hex(), count_after=count))
            aux = bytes(68)
            for t in prediction['raw_tokens']:
                state, count, aux = model.token(bytes.fromhex(t['raw']), state, count, aux)
                phases.append(dict(event='operand-cells', raw=t['raw'], after=state.hex(), count_after=count,
                                   auxiliary_after=aux.hex()))
            predictions[str(row['id'])] = dict(prediction=prediction, phases=phases)
        except Unsupported as exc:
            gaps.append(dict(id=row['id'], raw=row['raw'], reason=str(exc)))
    # All predictions and raw input witnesses precede every native call.
    save(out / 'before-native.json', dict(cpu=521, mode=0, versions=[], file_version='15.31', requests=requests))
    save(out / 'predictions-before-native.json', predictions)
    save(out / 'generation-gaps.json', gaps)
    save(out / 'excluded-repeats.json', repeats)
    for name in ('probe_fx_instruction_cell_holdouts.py', 'source_fx_instruction_cells.py',
                 'fx-instruction-cell-tables-20261001-v1.json', 'TraceFXInstructionCells.js'):
        (out / name).write_bytes((P / name).read_bytes())
    prior = P / 'fx-operand-rule-full-corpus-20261001-v1'
    for name in ('FXOperandCheckOracle.cs', 'FXOperandCheckOracle.exe'):
        (out / name).write_bytes((prior / name).read_bytes())
    (out / 'requests.tsv').write_text('\n'.join(f'{r["id"]}\t{r["input_base64"]}' for r in requests) + '\n', encoding='ascii')
    args = [str(out / 'FXOperandCheckOracle.exe'), str(DLL), str(out / 'requests.tsv'), str(out / 'baseline.jsonl')]
    baseline = subprocess.run(args, capture_output=True, timeout=45, creationflags=subprocess.CREATE_NO_WINDOW)
    (out / 'baseline-stdout.bin').write_bytes(baseline.stdout)
    (out / 'baseline-stderr.bin').write_bytes(baseline.stderr)
    save(out / 'baseline-process.json', dict(returncode=baseline.returncode))
    if baseline.returncode:
        raise RuntimeError('Owned raw check helper failed; experiment retained')
    traced_run(args[:-1] + [str(out / 'traced.jsonl')], (out / 'TraceFXInstructionCells.js').read_text(encoding='utf-8'), out)
    events, errors = collections.defaultdict(list), []
    for line in (out / 'events.jsonl').read_text(encoding='utf-8').splitlines():
        packet = json.loads(line)
        if packet['type'] != 'send':
            errors.append(packet)
        else:
            event = packet['payload']
            events[event['request']].append(event)
    answers = [json.loads(l) for l in (out / 'baseline.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    if len(answers) != len(requests):
        raise ValueError('Public check framing differs')
    differences, boundaries, rewrites, no_emission, emissions = [], [], [], [], []
    phase_counts, phase_matches = collections.Counter(), collections.Counter()
    for row, answer in zip(requests, answers, strict=True):
        if answer['id'] != row['id']:
            raise ValueError('Public answer identity differs')
        predicted = predictions.get(str(row['id']))
        observed = [e for e in events[row['id']] if e['event'] in ('instruction-cells', 'operand-cells')]
        phases = predicted['phases'] if predicted else []
        for i, event in enumerate(observed):
            phase_counts[event['event']] += 1
            if event['result'] < 0:
                boundaries.append(dict(id=row['id'], phase=i, native=event))
            elif i < len(phases) and event['raw'] == phases[i]['raw']:
                p = phases[i]
                keys = ('after', 'count_after') + (('auxiliary_after',) if event['event'] == 'operand-cells' else ())
                same = all(event[k] == p[k] for k in keys)
                if same:
                    phase_matches[event['event']] += 1
                else:
                    differences.append(dict(id=row['id'], phase=i, source_prediction=p, native=event))
            else:
                rewrites.append(dict(id=row['id'], phase=i, source_phase=phases[i] if i < len(phases) else None, native=event))
        emit = [e for e in events[row['id']] if e['event'] == 'machine-emission']
        if len(emit) != 1:
            no_emission.append(dict(id=row['id'], code=answer['code'], status=answer['status'], emissions=len(emit)))
        else:
            e = emit[0]
            same = predicted and e['before'] == predicted['prediction']['native_cells'] and e['auxiliary'] == predicted['prediction']['auxiliary']
            emissions.append(dict(id=row['id'], cells_exact=bool(same), public_code=answer['code'], status=answer['status'], native=e))
            if predicted and not same:
                differences.append(dict(id=row['id'], source_prediction=predicted['prediction'], native=e))
    save(out / 'cell-differences.json', differences)
    save(out / 'cell-boundary-refusals.json', boundaries)
    save(out / 'native-source-phase-gaps.json', rewrites)
    save(out / 'no-emission.json', no_emission)
    save(out / 'emissions.json', emissions)
    summary = dict(requests=len(requests), excluded_repeats=len(repeats), predictions=len(predictions), generation_gaps=len(gaps),
                   reached_instruction_keys=len({(r['family'], r['variant']) for r in requests}),
                   phase_counts=dict(phase_counts), phase_matches=dict(phase_matches), differences=len(differences),
                   phase_refusals=len(boundaries), phase_gaps=len(rewrites), emissions=len(emissions),
                   emission_cells_exact=sum(r['cells_exact'] for r in emissions),
                   public_accepted=sum(a['code'] == 0 and a['status'] in (0, 1) for a in answers),
                   public_statuses=dict(collections.Counter(a['status'] for a in answers)),
                   baseline_traced_exact=(out / 'baseline.jsonl').read_bytes() == (out / 'traced.jsonl').read_bytes(),
                   hook_errors=errors,
                   scope='Fresh raw token combinations via owned public CheckInstructionCode2; CPU 521/version 15.31. Original initializer, operand lowering and emitter observed. Raw aliases are retained, not normalized. No PLC execution or whole-project validity claim.')
    save(out / 'comparison.json', summary)
    print(json.dumps(summary, ensure_ascii=True), flush=True)
    if errors or differences or not summary['baseline_traced_exact']:
        raise ValueError('Prospective instruction cell differences retained')


if __name__ == '__main__':
    main()
