"""Independent machine-emission counts versus saved full FX record widths."""
import collections
import json
import subprocess

from probe_fx_operand_rules import DLL, P, save, traced_run


def main():
    out = P / 'fx-machine-step-emission-full-corpus-20261001-v1'
    out.mkdir()
    prior = P / 'fx-operand-rule-full-corpus-20261001-v1'
    for name in ('before-native.json', 'requests.tsv', 'FXOperandCheckOracle.cs', 'FXOperandCheckOracle.exe'):
        (out / name).write_bytes((prior / name).read_bytes())
    hook = (P / 'TraceFXMachineSteps.js').read_text(encoding='utf-8')
    (out / 'TraceFXMachineSteps.js').write_text(hook, encoding='utf-8')
    args = [str(out / 'FXOperandCheckOracle.exe'), str(DLL), str(out / 'requests.tsv'), str(out / 'baseline.jsonl')]
    baseline = subprocess.run(args, capture_output=True, timeout=45, creationflags=subprocess.CREATE_NO_WINDOW)
    (out / 'baseline-stdout.bin').write_bytes(baseline.stdout)
    (out / 'baseline-stderr.bin').write_bytes(baseline.stderr)
    save(out / 'baseline-process.json', dict(returncode=baseline.returncode))
    if baseline.returncode:
        raise RuntimeError('Owned machine-step observation helper failed')
    traced_run(args[:-1] + [str(out / 'traced.jsonl')], hook, out)
    events, errors = collections.defaultdict(list), []
    for line in (out / 'events.jsonl').read_text(encoding='utf-8').splitlines():
        packet = json.loads(line)
        if packet['type'] != 'send':
            errors.append(packet)
        else:
            e = packet['payload']
            events[e['request']].append(e)
    requests = json.loads((out / 'before-native.json').read_text(encoding='utf-8'))['requests']
    comparison, gaps = [], []
    for row in requests:
        emissions = [e for e in events[row['id']] if e['event'] == 'machine-step-emission']
        if len(emissions) != 1:
            gaps.append(dict(id=row['id'], native_listing=row['native_listing'], emissions=emissions,
                             reason='Machine emitter cardinality is not one'))
            continue
        emission = emissions[0]
        comparison.append(dict(id=row['id'], native_listing=row['native_listing'], raw=row['raw'],
            saved_width=row['saved_width'], machine_words=emission['words'], equal=row['saved_width'] == emission['words'],
            mode=emission['mode'], header=emission['header'], devices=emission['devices'], machine_output=emission['output']))
    save(out / 'machine-width-comparison.json', comparison)
    save(out / 'machine-emission-gaps.json', gaps)
    differences = [r for r in comparison if not r['equal']]
    save(out / 'machine-width-differences.json', differences)
    summary = dict(records=len(requests), observed_emitters=len(comparison), gaps=len(gaps),
                   saved_width_matches=sum(r['equal'] for r in comparison), differences=len(differences),
                   modes=dict(collections.Counter(r['mode'] for r in comparison)),
                   emission_widths=dict(collections.Counter(r['machine_words'] for r in comparison)),
                   header_formats=dict(collections.Counter(r['header'][:12] for r in comparison)),
                   baseline_prior_exact=(out / 'baseline.jsonl').read_bytes() == (prior / 'baseline.jsonl').read_bytes(),
                   baseline_traced_exact=(out / 'baseline.jsonl').read_bytes() == (out / 'traced.jsonl').read_bytes(),
                   hook_errors=errors)
    save(out / 'comparison.json', summary)
    print(json.dumps({k:v for k,v in summary.items() if k != 'header_formats'} |
                     dict(distinct_header_prefixes=len(summary['header_formats'])), ensure_ascii=True), flush=True)
    if errors or not summary['baseline_traced_exact'] or not summary['baseline_prior_exact']:
        raise ValueError('Machine-step observation changed public behavior; retained')


if __name__ == '__main__':
    main()
