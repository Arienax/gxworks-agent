"""Extract FX3G type constraints and observe original function boundaries.

Static tables are kept raw alongside interpretations. This is a type-check
experiment, not a universal project validator or a PLC execution oracle.
"""
from pathlib import Path
import collections
import json
import os
import struct
import subprocess
import sys
import time

P = Path(__file__).resolve().parent
ROOT = P.parents[3]
sys.path.insert(0, str(ROOT / 'research/experiments/re-tools'))
import frida
import pefile

DLL = Path('D:/GXWORKS2/Easysocket/CodeGenerator/ECCodeGeneratorFX2.dll')


def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=True) + '\n', encoding='utf-8')


def extract():
    pe = pefile.PE(str(DLL))
    image = pe.get_memory_mapped_image()
    map_rva, schema_rva, mask_rva, cap_rva = 0x7a750, 0x7af98, 0x7b358, 0x68c60
    count = (schema_rva - map_rva) // 4
    if count != 530 or map_rva + count * 4 != schema_rva:
        raise ValueError('Uninspected map extent')
    schema = image[schema_rva:mask_rva]
    rows, role_ids = [], set()
    for index in range(count):
        raw = image[map_rva + 4 * index:map_rva + 4 * (index + 1)]
        family, variant, offset = struct.unpack('<BBH', raw)
        row = dict(index=index, family=family, variant=variant, schema_offset=offset, raw=raw.hex())
        if offset != 0x7fff:
            if offset >= len(schema):
                raise ValueError('Schema outside observed pool')
            arity = schema[offset]
            if arity > 8 or offset + arity + 1 > len(schema):
                raise ValueError('Uninspected schema arity/extent')
            roles = list(schema[offset + 1:offset + arity + 1])
            row.update(arity=arity, roles=roles, schema_raw=schema[offset:offset + arity + 1].hex())
            role_ids.update(roles)
        rows.append(row)
    roles = {}
    for role in sorted(role_ids):
        raw = image[mask_rva + 16 * role:mask_rva + 16 * (role + 1)]
        words = struct.unpack('<8H', raw)
        devices = [code for code in range(0x90, 0x100)
                   if words[1 + (code - 0x90) // 16] & (1 << ((code - 0x90) % 16))]
        roles[str(role)] = dict(raw=raw.hex(), words=list(words), flags=words[0], allowed_codes=devices)
    capabilities = {}
    for code in range(0x90, 0x100):
        raw = image[cap_rva + 3 * (code - 0x90):cap_rva + 3 * (code - 0x90 + 1)]
        capabilities[str(code)] = dict(raw=raw.hex(), capabilities=raw[0], flags=struct.unpack_from('<H', raw, 1)[0])
    return dict(dll=str(DLL), file_version='15.31', cpu=521, cpu_class=32, mode=0, versions=[],
                map_rva=map_rva, schema_rva=schema_rva, mask_rva=mask_rva, capability_rva=cap_rva,
                map_rows=rows, schema_pool_raw=schema.hex(), roles=roles, capabilities=capabilities,
                function_prefixes={str(rva):image[rva:rva + 13].hex() for rva in (0x251ab, 0x25546)},
                scope='Native type and modifier layer only; range, cross-operand, version and project validity remain separate.')


def traced_run(args, hook, out, timeout=45):
    device = frida.get_local_device()
    output = {1:bytearray(), 2:bytearray()}
    ended = []
    pid = device.spawn(args, cwd=str(out), stdio='pipe')
    def receive(pid_, fd, data):
        if pid_ == pid and fd in output:
            output[fd].extend(data)
    device.on('output', receive)
    try:
        session = device.attach(pid)
        session.on('detached', lambda *a:ended.append(str(a)))
        with (out / 'events.jsonl').open('w', encoding='utf-8') as log:
            agent = session.create_script(hook)
            def message(row, data):
                log.write(json.dumps(row, ensure_ascii=True) + '\n')
                log.flush()
            agent.on('message', message)
            agent.load()
            device.resume(pid)
            deadline = time.monotonic() + timeout
            while not ended and time.monotonic() < deadline:
                time.sleep(.05)
            if not ended:
                device.kill(pid)
                raise TimeoutError('Owned helper exceeded time bound; trace retained')
    finally:
        device.off('output', receive)
        if not ended:
            try:
                device.kill(pid)
            except frida.ProcessNotFoundError:
                pass
    (out / 'trace-stdout.bin').write_bytes(output[1])
    (out / 'trace-stderr.bin').write_bytes(output[2])
    save(out / 'trace-process.json', dict(pid=pid, detached=ended))


def main():
    out = P / 'fx-operand-rule-encode-trace-20261001-v1'
    out.mkdir()
    tables = extract()
    save(out / 'static-tables-before-native.json', tables)
    prior = P / 'numeric-native-operand-boundary-20261001-v1/fx3g'
    for name in ('before-native.json', 'requests.tsv', 'NumericOperandOracle.cs'):
        (out / name).write_bytes((prior / name).read_bytes())
    source, exe = out / 'NumericOperandOracle.cs', out / 'NumericOperandOracle.exe'
    build = subprocess.run([str(Path(os.environ['WINDIR']) / 'Microsoft.NET/Framework/v4.0.30319/csc.exe'),
                            '/nologo', '/platform:x86', '/out:' + str(exe), str(source)],
                           capture_output=True, timeout=30, creationflags=subprocess.CREATE_NO_WINDOW)
    (out / 'build.txt').write_bytes(build.stdout + build.stderr)
    if build.returncode:
        raise RuntimeError('Owned public helper build failed')
    args = [str(exe), str(DLL), '521', str(out / 'requests.tsv'), str(out / 'baseline.jsonl')]
    baseline = subprocess.run(args, capture_output=True, timeout=45, creationflags=subprocess.CREATE_NO_WINDOW)
    (out / 'baseline-stdout.bin').write_bytes(baseline.stdout)
    (out / 'baseline-stderr.bin').write_bytes(baseline.stderr)
    save(out / 'baseline-process.json', dict(returncode=baseline.returncode))
    if baseline.returncode:
        raise RuntimeError('Public helper failed; output retained')
    hook = (P / 'TraceFXOperandRules.js').read_text(encoding='utf-8')
    (out / 'TraceFXOperandRules.js').write_text(hook, encoding='utf-8')
    traced_run(args[:-1] + [str(out / 'traced.jsonl')], hook, out)
    events, errors = [], []
    for line in (out / 'events.jsonl').read_text(encoding='utf-8').splitlines():
        packet = json.loads(line)
        (events if packet['type'] == 'send' else errors).append(packet.get('payload', packet))
    modules = [e for e in events if e['event'] == 'module']
    prefixes_equal = len(modules) == 1 and all(modules[0][name] == tables['function_prefixes'][str(rva)]
        for name, rva in [('capability_prefix', 0x251ab), ('rule_prefix', 0x25546)])
    summary = dict(requests=len((out / 'requests.tsv').read_text(encoding='ascii').splitlines()),
                   baseline_prior_exact=(out / 'baseline.jsonl').read_bytes() == (prior / 'outputs.jsonl').read_bytes(),
                   traced_baseline_exact=(out / 'traced.jsonl').read_bytes() == (out / 'baseline.jsonl').read_bytes(),
                   native_function_prefixes_exact=prefixes_equal,
                   map_rows=len(tables['map_rows']), schemas=len({r['schema_offset'] for r in tables['map_rows'] if r['schema_offset'] != 0x7fff}),
                   roles=len(tables['roles']), counts=dict(collections.Counter(e['event'] for e in events)), hook_errors=errors)
    save(out / 'comparison.json', summary)
    print(json.dumps(summary, ensure_ascii=True), flush=True)
    if errors or not prefixes_equal or not summary['traced_baseline_exact']:
        raise ValueError('Boundary instrumentation mismatch; retained')


if __name__ == '__main__':
    main()
