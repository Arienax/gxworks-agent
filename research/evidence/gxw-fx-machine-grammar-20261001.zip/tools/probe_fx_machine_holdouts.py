"""Fresh machine predictions before original native emission, with raw witnesses."""
import base64
import collections
import json
import struct
import subprocess

from probe_fx_operand_rules import DLL, P, save, traced_run
from probe_fx_instruction_cell_holdouts import numeric
from source_fx_machine import FXMachine
from source_fx_operand_rules import Unsupported


def build_requests():
    first = P / 'fx-instruction-cell-holdouts-20261001-v1'
    prior_rows = json.loads((first / 'before-native.json').read_text(encoding='utf-8'))['requests']
    native_rows = json.loads((first / 'emissions.json').read_text(encoding='utf-8'))
    reached = {r['id'] for r in native_rows if r['native']['words'] > 0}
    prior_raw = {r['raw'] for r in prior_rows}
    for name in ('fx-operand-rule-raw-holdouts-20261001-v1', 'fx-machine-step-emission-full-corpus-20261001-v1'):
        prior_raw.update(r['raw'] for r in json.loads((P / name / 'before-native.json').read_text(encoding='utf-8'))['requests'])
    rows, seen, repeated = [], set(), []
    def add(raw, category, description):
        if raw.hex() in seen or raw.hex() in prior_raw:
            repeated.append(dict(raw=raw.hex(), category=category, description=description))
            return
        seen.add(raw.hex())
        rows.append(dict(id=len(rows), raw=raw.hex(), category=category, description=description,
                         input_base64=base64.b64encode(raw).decode()))
    # Reachable applications use new values, both index families and token widths.
    for row in prior_rows:
        if row['id'] not in reached or not row['profile'].startswith('new-values/'):
            continue
        raw = bytes.fromhex(row['raw'])
        at, tokens, position = raw[0], [], 0
        while at < len(raw):
            old = raw[at:at + raw[at]]
            code = old[1]
            if code in (0xf0, 0xf4):
                token = numeric(0xf0 if code == 0xf4 else 0xf4, 7, 2)
            elif code == 0xf1:
                token = numeric(code, 2 if old[2] <= 4 else 6, 2)
            elif code in (0xe8, 0xea):
                token = numeric(code, 0x7fed, 4)
            elif code in (0xe9, 0xeb):
                token = numeric(code, 0xfedcba98, 4)
            elif code == 0xec:
                token = bytes([7, code]) + struct.pack('<f', 256.5) + bytes([7])
            elif code in (0xa8, 0xaf):
                token = numeric(code, 1001 + position * 3, 4)
            elif code == 0x90:
                token = numeric(code, 1536 + position * 16, 4)
            elif code in (0x9c, 0x9d):
                token = numeric(code, 256 + position, 4)
            elif code in (0xd0, 0xd1, 0xd2):
                token = numeric(code, 3, 4)
            elif code in (0xc2, 0xc5):
                token = numeric(code, 198, 4)
            else:
                token = old
            tokens.append(token)
            if code < 0xf0:
                position += 1
            at += len(old)
        add(raw[:raw[0]] + b''.join(tokens), 'reachable-key/new-values', dict(origin=row['id'], name=row['name'], profile=row['profile']))
    addresses = {
        0x90:(0, 1535, 1536, 3583, 3584, 7999, 8000, 8255, 8256, 8511, 8512, 32767, 65535, 65536),
        0x98:(0, 1023, 1024, 65535, 65536), 0x9c:(0, 255, 256, 65535, 65536),
        0x9d:(0, 255, 256, 65535, 65536), 0xc2:(0, 199, 200, 1023, 1024, 65535, 65536),
        0xc5:(0, 199, 200, 255, 32767, 32768, 65535, 65536)}
    # Raw basics and pulse contacts; range-check claims are deliberately separate.
    for family in list(range(12)) + [0x20, 0x29, 0x2a, 0x27, 0x28]:
        for code, values in addresses.items():
            for value in values:
                add(bytes([3, family, 127]) + numeric(code, value, 4), 'basic/address-boundary',
                    dict(family=family, code=code, value=value))
    for code in (0xc2, 0xc5):
        for value in addresses[code]:
            for preset_code, preset in ((0xe8, 0xfffe), (0xe9, 0x80000123), (0xa8, 1002)):
                add(bytes.fromhex('04217f04') + numeric(code, value, 4) + numeric(preset_code, preset, 4),
                    'out/preset-boundary', dict(code=code, value=value, preset_code=preset_code, preset=preset))
    for variant in (0, 1):
        header = bytes([5, 0x4c, 127, variant, 5])
        for code in (0xf0, 0xf4):
            for index in (0, 7, 8, 15, 16, 31, 32, 63, 64, 127, 255):
                add(header + numeric(code, index, 4) + numeric(0xa8, 1000, 4) + numeric(0xa8, 1002, 4),
                    'index/raw-boundary', dict(variant=variant, code=code, index=index))
        for group in (0, 1, 2, 4, 5, 7, 8, 9, 255):
            for address in (3583, 3584, 8255, 8256):
                add(header + numeric(0xf1, group, 4) + numeric(0x90, address, 4) + numeric(0xa8, 1002, 4),
                    'group/raw-boundary', dict(variant=variant, group=group, address=address))
        for code in (0xcc, 0xcd):
            for value in (0, 7, 8, 32767, 32768, 65535, 65536):
                add(header + numeric(code, value, 4) + numeric(0xa8, 1002, 4), 'register/alias-boundary',
                    dict(variant=variant, code=code, value=value))
    for code in (0xd0, 0xd1):
        for value in (0, 255, 256, 65535, 65536):
            add(bytes.fromhex('033c03') + numeric(code, value, 4), 'label/address-boundary', dict(code=code, value=value))
    for value in (0, 1, 7, 8, 255, 256, 65535):
        add(bytes.fromhex('032d7f') + numeric(0xd2, value, 4), 'mcr/raw-boundary', dict(value=value))
        for code, address in ((0x90, 1536), (0x90, 3584), (0x90, 8000), (0x9d, 256)):
            add(bytes.fromhex('042c7f04') + numeric(0xd2, value, 4) + numeric(code, address, 4),
                'mc/raw-boundary', dict(value=value, code=code, address=address))
    return rows, repeated


def main():
    out = P / 'fx-machine-prospective-holdouts-20261001-v1'
    out.mkdir()
    requests, repeated = build_requests()
    model = FXMachine()
    predictions, gaps = {}, []
    for row in requests:
        try:
            predictions[str(row['id'])] = model.record(bytes.fromhex(row['raw']))
        except Unsupported as exc:
            gaps.append(dict(id=row['id'], raw=row['raw'], reason=str(exc)))
    save(out / 'before-native.json', dict(cpu=521, file_version='15.31', mode=0, emission_mode=9, versions=[], requests=requests))
    save(out / 'predictions-before-native.json', predictions)
    save(out / 'generation-gaps.json', gaps)
    save(out / 'excluded-repeats.json', repeated)
    for name in ('probe_fx_machine_holdouts.py', 'source_fx_machine.py', 'source_fx_instruction_cells.py',
                 'fx-machine-tables-20261001-v1.json', 'fx-instruction-cell-tables-20261001-v1.json', 'TraceFXInstructionCells.js'):
        (out / name).write_bytes((P / name).read_bytes())
    prior = P / 'fx-operand-rule-full-corpus-20261001-v1'
    for name in ('FXOperandCheckOracle.cs', 'FXOperandCheckOracle.exe'):
        (out / name).write_bytes((prior / name).read_bytes())
    (out / 'requests.tsv').write_text('\n'.join(f'{r["id"]}\t{r["input_base64"]}' for r in requests) + '\n', encoding='ascii')
    args = [str(out / 'FXOperandCheckOracle.exe'), str(DLL), str(out / 'requests.tsv'), str(out / 'baseline.jsonl')]
    baseline = subprocess.run(args, capture_output=True, timeout=45, creationflags=subprocess.CREATE_NO_WINDOW)
    (out / 'baseline-stdout.bin').write_bytes(baseline.stdout)
    (out / 'baseline-stderr.bin').write_bytes(baseline.stderr)
    save(out / 'baseline-process.json', dict(returncode=baseline.returncode))
    if baseline.returncode:
        raise RuntimeError('Owned public machine helper failed; retained')
    traced_run(args[:-1] + [str(out / 'traced.jsonl')], (out / 'TraceFXInstructionCells.js').read_text(encoding='utf-8'), out)
    events, errors = collections.defaultdict(list), []
    for line in (out / 'events.jsonl').read_text(encoding='utf-8').splitlines():
        packet = json.loads(line)
        if packet['type'] != 'send':
            errors.append(packet)
        else:
            event = packet['payload']
            events[event['request']].append(event)
    answers = [json.loads(l) for l in (out / 'baseline.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    if len(answers) != len(requests):
        raise ValueError('Public output framing differs')
    differences, observations, unavailable = [], [], []
    counts = collections.Counter()
    for row, answer in zip(requests, answers, strict=True):
        if row['id'] != answer['id']:
            raise ValueError('Public request identity differs')
        emissions = [e for e in events[row['id']] if e['event'] == 'machine-emission']
        if len(emissions) != 1:
            unavailable.append(dict(id=row['id'], code=answer['code'], status=answer['status'], emissions=len(emissions)))
            continue
        native = emissions[0]
        prediction = predictions.get(str(row['id']))
        if prediction is None:
            unavailable.append(dict(id=row['id'], reason='Source projection unsupported', native=native))
            continue
        p = prediction['emission']
        same = dict(cells_before=prediction['native_cells'] == native['before'], words=p['words'] == native['words'],
                    cells_after=p['cells_after'] == native['after'])
        if p['machine_output'] is not None:
            same['machine_bytes'] = p['machine_output'] == native['output']
        else:
            counts['undefined_output_words'] += 1
        counts['observed'] += 1
        for key, value in same.items():
            counts[key] += value
        observation = dict(id=row['id'], public_code=answer['code'], status=answer['status'], matches=same, native=native)
        observations.append(observation)
        if not all(same.values()):
            differences.append(dict(id=row['id'], source_prediction=prediction, observation=observation))
    save(out / 'observations.json', observations)
    save(out / 'differences.json', differences)
    save(out / 'no-emitter-observation.json', unavailable)
    summary = dict(requests=len(requests), predictions=len(predictions), generation_gaps=len(gaps), excluded_repeats=len(repeated),
                   categories=dict(collections.Counter(r['category'] for r in requests)), counts=dict(counts),
                   differences=len(differences), no_emitter_observation=len(unavailable),
                   public_accepted=sum(a['code'] == 0 and a['status'] in (0, 1) for a in answers),
                   public_statuses=dict(collections.Counter(a['status'] for a in answers)),
                   baseline_traced_exact=(out / 'baseline.jsonl').read_bytes() == (out / 'traced.jsonl').read_bytes(), hook_errors=errors,
                   scope='All predictions and model snapshots saved before native calls. Independent new raw cases; owned offline public helper; original emitter only, no replacement native calls. Undefined words stay explicit. No address-range, project-validity or PLC-execution claim.')
    save(out / 'comparison.json', summary)
    print(json.dumps(summary, ensure_ascii=True), flush=True)
    if errors or differences or not summary['baseline_traced_exact']:
        raise ValueError('Prospective machine differences retained')


if __name__ == '__main__':
    main()
