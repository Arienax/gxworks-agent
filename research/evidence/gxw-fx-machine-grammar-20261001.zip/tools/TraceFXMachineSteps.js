'use strict';
let request = -1;
function hex(p, n) { return Array.from(new Uint8Array(p.readByteArray(n)), b => b.toString(16).padStart(2, '0')).join(''); }
function result16(r) { return (r.toInt32() << 16) >> 16; }
Process.attachModuleObserver({ onAdded(m) {
    if (m.name.toLowerCase() !== 'eccodegeneratorfx2.dll') return;
    const base = m.base;
    Interceptor.attach(m.findExportByName('CheckInstructionCode2'), {
        onEnter(a) { request++; this.row = { event: 'check', request }; this.status = a[4]; },
        onLeave(r) { this.row.result = r.toInt32(); this.row.status = this.status.readS16(); send(this.row); }
    });
    Interceptor.attach(base.add(0x3e339), {
        onEnter(a) { this.header = a[1]; this.row = { event: 'instruction-state', request }; },
        onLeave(r) { this.row.result = result16(r); this.row.header = hex(this.header, 88); send(this.row); }
    });
    Interceptor.attach(base.add(0x2ff3f), {
        onEnter(a) {
            this.output = a[2];
            this.row = { event: 'machine-step-emission', request, mode: a[3].toInt32(),
                cpu: base.add(0x928a8).readU16(), header: hex(a[0], 88), devices: hex(a[1], 68) };
        },
        onLeave(r) {
            this.row.words = result16(r);
            if (this.row.words > 256) throw new Error('Machine emission exceeds caller temporary buffer');
            this.row.output = this.row.words > 0 ? hex(this.output, this.row.words * 2) : '';
            send(this.row);
        }
    });
} });
