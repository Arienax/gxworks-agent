"""Header-only native rewrite cross-check; rejected records stay separate."""
import base64
import collections
import json

from probe_fx_operand_rules import P, save
from source_fx_machine import FXMachine
from source_fx_operand_rules import Unsupported


def main():
    out = P / 'fx-source-width-rewrite-20261001-v1'
    out.mkdir()
    names = ('fx-machine-step-emission-full-corpus-20261001-v1', 'fx-instruction-cell-holdouts-20261001-v1',
             'fx-machine-prospective-holdouts-20261001-v1')
    model = FXMachine()
    predictions, generation_gaps = [], []
    for name in names:
        for request in json.loads((P / name / 'before-native.json').read_text(encoding='utf-8'))['requests']:
            try:
                prediction = model.width_rewrite(bytes.fromhex(request['raw']))
                predictions.append(dict(origin=name, id=request['id'], raw=request['raw'], prediction=prediction))
            except Unsupported as exc:
                generation_gaps.append(dict(origin=name, id=request['id'], raw=request['raw'], reason=str(exc)))
    save(out / 'predictions-before-answer.json', predictions)
    save(out / 'generation-gaps.json', generation_gaps)
    (out / 'source_fx_machine.py').write_bytes((P / 'source_fx_machine.py').read_bytes())
    answers = {}
    for name in names:
        for line in (P / name / 'baseline.jsonl').read_text(encoding='utf-8-sig').splitlines():
            answer = json.loads(line)
            answers[(name, answer['id'])] = answer
    matched, differences, refusals, initial_hypothesis_failures = collections.defaultdict(collections.Counter), [], [], []
    for row in predictions:
        answer = answers[(row['origin'], row['id'])]
        if answer['code'] or answer['status'] not in (0, 1):
            refusals.append(dict(origin=row['origin'], id=row['id'], code=answer['code'], status=answer['status']))
            continue
        raw = bytes.fromhex(row['raw'])
        p = row['prediction']
        actual = base64.b64decode(answer['output_base64']).hex()
        same = p['candidate'] == actual and p['operand_bytes_preserved']
        matched[row['origin']]['accepted'] += 1
        matched[row['origin']]['exact'] += same
        if not same:
            differences.append(dict(origin=row['origin'], id=row['id'], source=row, native=answer))
        # Retain the rejected canonical-short-header hypothesis as a failure
        # corpus. It is not used by the final source model.
        header = raw[:raw[0]]
        if len(header) == 3 and p['machine_words'] == 1:
            canonical = bytes([3, header[1], 3]) + raw[3:]
            if canonical.hex() != actual:
                initial_hypothesis_failures.append(dict(origin=row['origin'], id=row['id'], raw=row['raw'],
                                                       rejected_prediction=canonical.hex(), native_output=actual))
    save(out / 'differences.json', differences)
    save(out / 'public-refusals.json', refusals)
    save(out / 'rejected-short-header-canonicalization.json', initial_hypothesis_failures)
    summary = dict(predictions=len(predictions), generation_gaps=len(generation_gaps), comparisons={k:dict(v) for k,v in matched.items()},
                   differences=len(differences), public_refusals=len(refusals),
                   rejected_short_header_hypothesis=len(initial_hypothesis_failures),
                   scope='Post-hoc rule recovered from native 3e534 and independently matched against public record output. Every operand byte preserved; no claim to predict earlier role, version or range checks.')
    save(out / 'comparison.json', summary)
    print(json.dumps(summary, ensure_ascii=True))
    if differences:
        raise ValueError('Raw record rewrite differences retained')


if __name__ == '__main__':
    main()
