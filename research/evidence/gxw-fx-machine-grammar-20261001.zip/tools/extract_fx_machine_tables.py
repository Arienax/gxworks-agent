"""Extract inspected mode-9 dispatch, operation and operand-class tables."""
import struct

from probe_fx_operand_rules import DLL, P, save
import pefile


def main():
    path = P / 'fx-machine-tables-20261001-v1.json'
    if path.exists():
        raise FileExistsError('Prior static evidence must not be replaced')
    pe = pefile.PE(str(DLL))
    image, base = pe.get_memory_mapped_image(), pe.OPTIONAL_HEADER.ImageBase
    dispatch = []
    for index in range(36):
        at = 0x7cbf8 + index * 5
        raw = image[at:at + 5]
        dispatch.append(dict(index=index, kind=raw[0], function_rva=struct.unpack_from('<I', raw, 1)[0] - base,
                             raw=raw.hex()))
    if dispatch[-1]['kind'] != 255:
        raise ValueError('Uninspected dispatch extent')
    operations = []
    for index in range(256):
        at = 0x7d711 + index * 10
        raw = image[at:at + 10]
        operations.append(dict(index=index, kind=raw[0], selector1=struct.unpack_from('<H', raw, 1)[0],
                               selector2=struct.unpack_from('<H', raw, 3)[0], value=struct.unpack_from('<H', raw, 7)[0],
                               raw=raw.hex()))
        if raw[0] == 255:
            break
    if operations[-1]['kind'] != 255:
        raise ValueError('Uninspected operation table extent')
    applications = [dict(function=i, flags=image[0x7da18 + 2 * i], arity=image[0x7da19 + 2 * i],
                         raw=image[0x7da18 + 2 * i:0x7da1a + 2 * i].hex()) for i in range(310)]
    targets = {0x33594:4, 0x33598:3, 0x3359c:2, 0x335a0:1, 0x335a4:6, 0x335a8:5, 0x335ac:7, 0x335b0:0}
    classes = {}
    for code in range(0x22, 0x5b):
        index = image[0x335d3 + code - 0x22]
        target = struct.unpack_from('<I', image, 0x335b3 + 4 * index)[0] - base
        classes[chr(code)] = dict(class_id=targets[target], index=index, target_rva=target)
    save(path, dict(dll=str(DLL), file_version='15.31', cpu=521, emission_mode=9,
                    dispatch_rva=0x7cbf8, operation_rva=0x7d711, application_rva=0x7da18,
                    class_switch_rva=0x335d3, dispatch=dispatch, operations=operations,
                    applications=applications, classes=classes,
                    scope='Native machine-code emission tables. Coverage and public check acceptance remain separate from operand address and project validity.'))
    print(dict(dispatch=len(dispatch), operations=len(operations), applications=len(applications)))


if __name__ == '__main__':
    main()
