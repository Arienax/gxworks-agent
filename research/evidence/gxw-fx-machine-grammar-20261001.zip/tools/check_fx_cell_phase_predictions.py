"""Check saved prospective token phases; header width rewriting stays explicit."""
import collections
import json

from probe_fx_operand_rules import P, save


def main():
    origin = P / 'fx-instruction-cell-holdouts-20261001-v1'
    out = P / 'fx-instruction-cell-phase-crosscheck-20261001-v1'
    out.mkdir()
    predictions = json.loads((origin / 'predictions-before-native.json').read_text(encoding='utf-8'))
    counts, matches, differences, raw_changes = collections.Counter(), collections.Counter(), [], []
    positions = collections.Counter()
    for line in (origin / 'events.jsonl').read_text(encoding='utf-8').splitlines():
        packet = json.loads(line)
        if packet['type'] != 'send':
            raise ValueError('Original instrumentation error retained')
        event = packet['payload']
        if event['event'] not in ('instruction-cells', 'operand-cells'):
            continue
        at = positions[event['request']]
        positions[event['request']] += 1
        predicted = predictions[str(event['request'])]['phases'][at]
        counts[event['event']] += 1
        keys = ('after', 'count_after') + (('auxiliary_after',) if event['event'] == 'operand-cells' else ())
        same = event['event'] == predicted['event'] and event['result'] >= 0 and all(event[key] == predicted[key] for key in keys)
        if same:
            matches[event['event']] += 1
        else:
            differences.append(dict(id=event['request'], phase=at, source_prediction=predicted, native=event))
        if predicted['raw'] != event['raw']:
            original, changed = bytes.fromhex(predicted['raw']), bytes.fromhex(event['raw'])
            width_only = event['event'] == 'instruction-cells' and len(original) == len(changed) and original[:2] == changed[:2] and original[3:] == changed[3:]
            raw_changes.append(dict(id=event['request'], phase=at, source_raw=predicted['raw'], native_raw=event['raw'], width_byte_only=width_only))
    save(out / 'differences.json', differences)
    save(out / 'header-rewrite-observations.json', raw_changes)
    summary = dict(counts=dict(counts), matches=dict(matches), differences=len(differences), raw_header_changes=len(raw_changes),
                   width_byte_only=sum(row['width_byte_only'] for row in raw_changes),
                   scope='Uses phases saved before native calls. Raw width-byte rewrites are separately retained, not hidden by the cell comparison.')
    save(out / 'comparison.json', summary)
    print(json.dumps(summary, ensure_ascii=True))
    if differences or any(not r['width_byte_only'] for r in raw_changes):
        raise ValueError('Instruction phase or raw rewrite difference retained')


if __name__ == '__main__':
    main()
