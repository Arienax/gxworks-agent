"""Replay frozen original native observations with no native binary or hooks."""
from pathlib import Path
import collections
import json
from source_fx_machine import FXMachine
from source_fx_operand_rules import Unsupported

p = Path(__file__).resolve().parent
model = FXMachine()
counts = collections.Counter()
keys, kinds = set(), set()
for witness in json.loads((p / 'native-witnesses.json').read_text(encoding='utf-8')):
    raw = bytes.fromhex(witness['raw'])
    try:
        prediction = model.record(raw)
    except Unsupported as exc:
        if witness.get('unsupported') != str(exc) or witness['native_emissions']:
            raise
        counts['explicit-unsupported'] += 1
        continue
    if witness.get('unsupported'):
        raise ValueError('Unsupported scope silently widened')
    counts['source-projections'] += 1
    if bytes.fromhex(prediction['raw']) != raw:
        raise ValueError('Original raw record changed')
    if len(witness['native_emissions']) != 1:
        counts['pre-emission-refusals'] += 1
        continue
    native = witness['native_emissions'][0]
    emission = prediction['emission']
    if prediction['native_cells'] != native['before'] or prediction['auxiliary'] != native['auxiliary']:
        raise ValueError('Native input representation differs')
    if emission['words'] != native['words'] or emission['cells_after'] != native['after']:
        raise ValueError('Native count or representation after emission differs')
    if emission['machine_output'] is None:
        counts['undefined-output-words'] += 1
    elif emission['machine_output'] != native['output']:
        raise ValueError('Native machine words differ')
    else:
        counts['machine-bytes-exact'] += 1
    counts['native-emission-exact'] += 1
    keys.add((raw[1], raw[3] if raw[0] >= 5 else 0))
    kinds.add(bytes.fromhex(native['before'])[2])
    public = witness['public']
    if public['code'] == 0 and public['status'] in (0, 1):
        rewrite = model.width_rewrite(raw)
        if rewrite['candidate'] != public['output'] or not rewrite['operand_bytes_preserved']:
            raise ValueError('Public record rewrite or raw operand preservation differs')
        counts['header-rewrite-exact'] += 1
    else:
        counts['native-emitter-refusals'] += 1
result = dict(counts=dict(counts), reached_instruction_keys=len(keys), observed_kinds=sorted(kinds))
expected = json.loads((p / 'expected-replay.json').read_text(encoding='utf-8'))
if result != expected:
    raise ValueError('Frozen witness coverage differs')
print(json.dumps(result, ensure_ascii=True))
