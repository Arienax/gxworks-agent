"""Inspected FX operand token parser; unknown fields and tokens stay raw."""
from pathlib import Path
import collections
import json

from source_fx_operand_rules import Unsupported

P = Path(__file__).resolve().parent
SELECTORS = bytes.fromhex('00010203000505050404050504050504')


def parse(raw, initial_descriptor):
    """Mirror RVA25011 for caller-framed tokens on CPU class20.

The native routine initializes eight bytes of its nine-byte slot. The ninth
byte is retained from the caller and has no type meaning until capability
validation overwrites the complete flags word.
    """
    if len(initial_descriptor) != 9:
        raise Unsupported('Unmeasured descriptor slot')
    d = bytearray(b'\xff' * 8 + initial_descriptor[8:])
    d[1] = 0
    offset, cost, modifiers = 0, 0, []
    while offset < len(raw):
        if offset + 2 > len(raw):
            raise Unsupported('Incomplete lexical token')
        length, code = raw[offset:offset + 2]
        if code < 0x90:
            return dict(status=-3, descriptor=bytes(d), base_offset=offset,
                        last_value=None, raw=raw, modifiers=modifiers, handling='unsupported-token-family')
        if length < 3 or offset + length > len(raw) or raw[offset + length - 1] != length:
            raise Unsupported('Token outside preserved lexical framing')
        token = raw[offset:offset + length]
        if length < 4:
            raise Unsupported('Operand value token below the inspected byte-read extent')
        value_width = {4:1, 5:2, 6:3}.get(length, 4)
        if length < value_width + 3:
            raise Unsupported('Operand value outside framed token')
        value = int.from_bytes(token[2:2 + value_width], 'little')
        selector = SELECTORS[code - 0xf0] if code >= 0xf0 else 5
        if selector != 5:
            modifiers.append(dict(code=code, raw=token.hex(), raw_value=value))
            if len(modifiers) > 8:
                raise Unsupported('Modifier chain above caller-bounded experiment')
            if selector == 0:
                d[4] = value & 255
            elif selector == 1:
                d[3] = value & 255
            elif selector == 2:
                d[5] = value & 255
            elif selector == 3:
                d[0] = code
                cost += 1
            elif selector == 4:
                d[1] = code
                if d[4] != 0xff:
                    d[2] = d[4]
                    d[4] = 0xff
                cost += 1
            offset += length
            continue
        valid_prefix = ((d[1] != 0xf8 or code == 0xab)
            and (d[1] != 0xf9 or code in (0x9c, 0x9d, 0xa0, 0xa1, 0xa2, 0xa3, 0xb4, 0xb5))
            and (d[1] != 0xfc or code in (0x98, 0x99)))
        if not valid_prefix:
            return dict(status=-1, descriptor=bytes(d), base_offset=offset,
                        last_value=None, raw=raw, modifiers=modifiers, handling='invalid-prefix-base-pair')
        d[6] = code
        if code == 0xdf:
            cost = 1
        elif code == 0xee:
            cost += 1 if length == 4 and token[2] == 0 else (length - 2) // 2 + 1
        else:
            cost += (length - 2) // 2
        if cost > 127:
            raise Unsupported('Signed parser cost outside measured range')
        return dict(status=cost, descriptor=bytes(d), base_offset=offset, last_value=value,
                    raw=raw, modifiers=modifiers,
                    initialized_descriptor_bytes=8, caller_preserved_flag_high_byte=d[8],
                    handling='opaque-base' if code in (0xad, 0xdf) or code >= 0xf0 else 'decoded-native-parser-path')
    raise Unsupported('Modifier chain lacks a base token')


def compare_events(path):
    counts = collections.Counter()
    failures, gaps = [], []
    for line in path.read_text(encoding='utf-8').splitlines():
        packet = json.loads(line)
        if packet['type'] != 'send':
            failures.append(packet)
            continue
        e = packet['payload']
        if e['event'] != 'operand-parse':
            continue
        counts['parser_calls'] += 1
        if (e['cpu'], e['cpu_class']) != (521, 32):
            gaps.append(dict(native=e, reason='Unmeasured parser context'))
            continue
        try:
            predicted = parse(bytes.fromhex(e['raw']), bytes.fromhex(e['initial_descriptor']))
            equal = (predicted['status'] == e['result']
                and predicted['descriptor'].hex() == e['descriptor']
                and predicted['base_offset'] == e['base_offset']
                and (predicted['last_value'] is None or predicted['last_value'] == e['last_value']))
            if equal:
                counts['matched'] += 1
            else:
                failures.append(dict(native=e, prediction={k:v.hex() if isinstance(v, bytes) else v for k,v in predicted.items()}))
            counts[f'base-{predicted["descriptor"][6]:02x}'] += 1
            counts[f'modifier-count-{len(predicted["modifiers"])}'] += 1
            counts[f'parser-status-{predicted["status"]}'] += 1
        except Unsupported as exc:
            gaps.append(dict(native=e, reason=str(exc)))
    return dict(counts=dict(counts), failures=failures, unsupported=gaps)
