"""Replay frozen native function-boundary witnesses without GX Works2."""
from pathlib import Path
import collections
import json
from source_fx_operand_rules import FXOperandRules, Unsupported
from source_fx_operand_parser import parse

P = Path(__file__).resolve().parent
model = FXOperandRules(json.loads((P / 'fx-operand-tables.json').read_text(encoding='utf-8')))
counts = collections.Counter()
roles = set()
for row in json.loads((P / 'native-boundary-witnesses.json').read_text(encoding='utf-8')):
    e = row['native']
    try:
        if e['event'] == 'operand-capability':
            status, after = model.capability(bytes.fromhex(e['before']))
            equal = status == e['result'] and after.hex() == e['after']
        elif e['event'] == 'operand-rule':
            status, provenance = model.rule(e['family'], e['variant'], e['index'], bytes.fromhex(e['descriptors']))
            equal = status == e['result']
            roles.update(r['role'] for r in provenance.get('alternatives', []))
        else:
            result = parse(bytes.fromhex(e['raw']), bytes.fromhex(e['initial_descriptor']))
            equal = (result['status'] == e['result'] and result['descriptor'].hex() == e['descriptor']
                and result['base_offset'] == e['base_offset']
                and (result['last_value'] is None or result['last_value'] == e['last_value']))
        if row.get('unsupported') or not equal:
            raise ValueError('Frozen boundary mismatch: ' + str(row['id']))
        counts[e['event']] += 1
    except Unsupported as exc:
        if row.get('unsupported') != str(exc):
            raise
        counts['explicit-unsupported'] += 1
if len(roles) != 82:
    raise ValueError('Frozen role coverage differs')
print(json.dumps(dict(matched=dict(counts), reached_roles=len(roles)), ensure_ascii=True))
