"""Raw modifier ordering, lexical boundaries and descriptor collisions."""
import base64
import collections
import json
import subprocess

from probe_fx_operand_rules import DLL, P, save, traced_run
from probe_fx_operand_rule_raw_holdouts import token
from source_fx_operand_rules import FXOperandRules
from source_fx_operand_parser import compare_events


def main():
    out = P / 'fx-operand-modifier-boundaries-20261001-v1'
    out.mkdir()
    candidates = []
    header, destination = bytes([5, 0x4c, 127, 0, 5]), token(0xa8, 200)
    def case(name, source):
        candidates.append((name, header + source + destination))
    for code in range(0xf0, 0x100):
        case(f'modifier-{code:02x}-then-D100', token(code, 0) + token(0xa8, 100))
    for name, modifiers, base in [
        ('Z0-D100', token(0xf0, 0), token(0xa8, 100)),
        ('V0-D100', token(0xf4, 0), token(0xa8, 100)),
        ('group4-Z0-M16', token(0xf1, 4) + token(0xf0, 0), token(0x90, 16)),
        ('group4-V0-M16', token(0xf1, 4) + token(0xf4, 0), token(0x90, 16)),
        ('Z0-group4-M16', token(0xf0, 0) + token(0xf1, 4), token(0x90, 16)),
        ('V0-group4-M16', token(0xf4, 0) + token(0xf1, 4), token(0x90, 16)),
        ('Z0-prefixF8-AB0', token(0xf0, 0) + token(0xf8, 0), token(0xab, 0)),
        ('prefixF8-Z0-AB0', token(0xf8, 0) + token(0xf0, 0), token(0xab, 0)),
        ('prefixF9-X0', token(0xf9, 0), token(0x9c, 0)),
        ('prefixFC-S0', token(0xfc, 0), token(0x98, 0)),
        ('prefixFF-D100', token(0xff, 0), token(0xa8, 100)),
        ('indirectF3-D100', token(0xf3, 0), token(0xa8, 100)),
        ('index-overwrite', token(0xf0, 1) + token(0xf4, 2), token(0xa8, 100)),
        ('digit-overwrite', token(0xf1, 1) + token(0xf1, 4), token(0x90, 16)),
        ('bit-overwrite', token(0xf2, 1) + token(0xf2, 3), token(0xa8, 100))]:
        case(name, modifiers + base)
    for group in (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 255):
        case(f'group-{group}-M16', token(0xf1, group) + token(0x90, 16))
    for length in (4, 5, 6, 7):
        width = length - 3
        case(f'word-literal-token-length-{length}', bytes([length, 0xe8]) + (1).to_bytes(width, 'little') + bytes([length]))
    for name, raw in [('empty-string', bytes([4, 0xee, 0, 4])),
                      ('A-string', bytes([5, 0xee, 65, 0, 5]))]:
        case(name, raw)
    requests = [dict(id=i, name=name, raw=raw.hex(), input_base64=base64.b64encode(raw).decode())
                for i, (name, raw) in enumerate(candidates)]
    save(out / 'before-native.json', dict(cpu=521, mode=0, versions=[], file_version='15.31', requests=requests,
        scope='Caller-framed raw token experiments. Identical temporary type descriptors do not establish identical operands or execution semantics.'))
    (out / 'requests.tsv').write_text('\n'.join(f'{r["id"]}\t{r["input_base64"]}' for r in requests) + '\n', encoding='ascii')
    prior = P / 'fx-operand-rule-full-corpus-20261001-v1'
    for name in ('FXOperandCheckOracle.cs', 'FXOperandCheckOracle.exe', 'static-tables-before-native.json'):
        (out / name).write_bytes((prior / name).read_bytes())
    for name in ('source_fx_operand_rules.py', 'source_fx_operand_parser.py', 'TraceFXOperandRules.js',
                 'TraceFXOperandParser.js', 'TraceFXInstructionPhases.js'):
        (out / name).write_bytes((P / name).read_bytes())
    args = [str(out / 'FXOperandCheckOracle.exe'), str(DLL), str(out / 'requests.tsv'), str(out / 'baseline.jsonl')]
    baseline = subprocess.run(args, capture_output=True, timeout=45, creationflags=subprocess.CREATE_NO_WINDOW)
    (out / 'baseline-stdout.bin').write_bytes(baseline.stdout)
    (out / 'baseline-stderr.bin').write_bytes(baseline.stderr)
    save(out / 'baseline-process.json', dict(returncode=baseline.returncode))
    if baseline.returncode:
        raise RuntimeError('Owned modifier helper failed; retained')
    hook = '\n'.join((P / name).read_text(encoding='utf-8') for name in
                     ('TraceFXOperandRules.js', 'TraceFXOperandParser.js', 'TraceFXInstructionPhases.js'))
    (out / 'combined-hook.js').write_text(hook, encoding='utf-8')
    traced_run(args[:-1] + [str(out / 'traced.jsonl')], hook, out)
    model, parsed = FXOperandRules().compare_events(out / 'events.jsonl'), compare_events(out / 'events.jsonl')
    save(out / 'model-boundary-comparison.json', model)
    save(out / 'parser-boundary-comparison.json', parsed)
    events = collections.defaultdict(list)
    for line in (out / 'events.jsonl').read_text(encoding='utf-8').splitlines():
        packet = json.loads(line)
        if packet['type'] == 'send' and 'request' in packet['payload']:
            events[packet['payload']['request']].append(packet['payload'])
    by_name = {r['name']:r for r in requests}
    collisions = []
    for left, right in [('Z0-D100', 'V0-D100'), ('group4-Z0-M16', 'group4-V0-M16'),
                        ('group4-Z0-M16', 'Z0-group4-M16'), ('Z0-prefixF8-AB0', 'prefixF8-Z0-AB0')]:
        a, b = by_name[left], by_name[right]
        ea = [e for e in events[a['id']] if e['event'] == 'operand-parse' and e['index'] == 1]
        eb = [e for e in events[b['id']] if e['event'] == 'operand-parse' and e['index'] == 1]
        collisions.append(dict(left=left, right=right, raw_different=a['raw'] != b['raw'],
            initialized_descriptor_equal=len(ea) == len(eb) == 1 and ea[0]['descriptor'][:16] == eb[0]['descriptor'][:16],
            left_descriptor=ea[0]['descriptor'][:16] if ea else None, right_descriptor=eb[0]['descriptor'][:16] if eb else None,
            left_status=ea[0]['result'] if ea else None, right_status=eb[0]['result'] if eb else None))
    save(out / 'descriptor-collisions.json', collisions)
    summary = dict(requests=len(requests), baseline_traced_exact=(out / 'baseline.jsonl').read_bytes() == (out / 'traced.jsonl').read_bytes(),
                   parser_counts=parsed['counts'], parser_failures=len(parsed['failures']), parser_unsupported=len(parsed['unsupported']),
                   type_counts=model['counts'], type_matched=model['matched'], type_failures=len(model['failures']),
                   type_unsupported=len(model['unsupported']), type_unsupported_reasons=dict(collections.Counter(r['reason'] for r in model['unsupported'])),
                   descriptor_collisions=collisions)
    save(out / 'comparison.json', summary)
    print(json.dumps(summary, ensure_ascii=True), flush=True)
    if model['failures'] or parsed['failures'] or not summary['baseline_traced_exact']:
        raise ValueError('Modifier-boundary mismatch retained')


if __name__ == '__main__':
    main()
