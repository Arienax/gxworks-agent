"""Public text-encoding holdouts for the FX native operand type model."""
from pathlib import Path
import base64
import collections
import json
import os
import subprocess

from probe_fx_operand_rules import DLL, P, save, traced_run
from source_fx_operand_rules import FXOperandRules, Unsupported


def main():
    out = P / 'fx-operand-rule-catalog-holdouts-20261001-v1'
    out.mkdir()
    model = FXOperandRules()
    catalog = json.loads((P / 'fx-native-instruction-catalog-20261001-v1/before-native.json').read_text(encoding='utf-8'))
    candidates = [('D100', 0xa8, {}), ('K1', 0xe8, {}), ('K65536', 0xe9, {}),
                  ('H1', 0xea, {}), ('H10000', 0xeb, {}), ('E1.5', 0xec, {}),
                  ('K4M16', 0x90, {'group':4}), ('K8M16', 0x90, {'group':8}),
                  ('M16', 0x90, {}), ('T0', 0xc2, {}), ('C0', 0xc5, {}),
                  ('X0', 0x9c, {}), ('Y0', 0x9d, {}), ('S0', 0x98, {}),
                  ('R100', 0xaf, {}), ('Z0', 0xcc, {}), ('V0', 0xcd, {}),
                  ('P0', 0xd0, {}), ('I0', 0xd1, {})]
    mutations = [('word-literal', 'K1', 0xe8, {}), ('double-word-literal', 'K65536', 0xe9, {}),
                 ('real-literal', 'E1.5', 0xec, {}), ('indexed-data', 'D100Z0', 0xa8, {'index':0}),
                 ('group4-bits', 'K4M16', 0x90, {'group':4}), ('group8-bits', 'K8M16', 0x90, {'group':8}),
                 ('bit-selector', 'D100.0', 0xa8, {'bit':0})]
    requests, generation_gaps = [], []
    seen = set()
    def predict(family, variant, operands):
        descriptors = b''
        result = []
        for index, (text, code, modifiers) in enumerate(operands, 1):
            before = model.plain(code, **modifiers)
            cap, after = model.capability(before)
            descriptors += after
            rule, provenance = model.rule(family, variant, index, descriptors)
            result.append(dict(index=index, text=text, descriptor_before=before.hex(), descriptor_after=after.hex(),
                               capability_status=cap, rule_status=rule, rule_provenance=provenance))
        return result
    for descriptor in catalog['rows'][:-1]:
        arity, family, variant = descriptor['uninterpreted_fields'][:3]
        name = descriptor['name']
        baseline, descriptors = [], b''
        for index in range(1, arity + 1):
            selected = None
            for candidate in candidates:
                text, code, modifiers = candidate
                cap, after = model.capability(model.plain(code, **modifiers))
                status, _ = model.rule(family, variant, index, descriptors + after)
                if cap == status == 0:
                    selected = candidate
                    break
            if selected is None:
                selected = candidates[0]
                generation_gaps.append(dict(descriptor_index=descriptor['index'], name=name,
                                            family=family, variant=variant, index=index,
                                            reason='No type-layer accepted operand among bounded candidate spellings'))
            baseline.append(selected)
            descriptors += model.capability(model.plain(selected[1], **selected[2]))[1]
        profiles = [('table-selected', baseline)]
        # Vary the first and last role, keeping other operands at their baseline.
        # This reaches late roles without a preceding deliberately invalid value.
        for index in sorted({0, arity - 1} - {-1}) if arity else []:
            for profile, text, code, modifiers in mutations:
                operands = list(baseline)
                operands[index] = (text, code, modifiers)
                profiles.append((f'{profile}@{index + 1}', operands))
        for profile, operands in profiles:
            instruction = ' '.join([name] + [c[0] for c in operands])
            if (descriptor['index'], instruction) in seen:
                continue
            seen.add((descriptor['index'], instruction))
            lines = ['LD M8000', instruction, 'FEND', 'END']
            raw = ('\0'.join(lines) + '\0\0').encode('ascii')
            prediction = predict(family, variant, operands)
            requests.append(dict(id=len(requests), descriptor_index=descriptor['index'], name=name,
                                 family=family, variant=variant, arity=arity, profile=profile, lines=lines,
                                 input_base64=base64.b64encode(raw).decode(), option=0, type_prediction=prediction,
                                 all_type_roles_accepted=all(r['capability_status'] == r['rule_status'] == 0 for r in prediction)))
    save(out / 'before-native.json', dict(cpu=521, mode=0, versions=[], file_version='15.31', requests=requests,
                                        generation_gaps=generation_gaps,
                                        scope='Synthetic text spellings, predicted from native tables; native function boundaries and the public encoder are independent observations. Type acceptance does not imply whole-instruction acceptance.'))
    for name in ('source_fx_operand_rules.py', 'TraceFXOperandRules.js', 'NumericOperandOracle.cs'):
        (out / name).write_bytes((P / name).read_bytes())
    (out / 'static-tables-before-native.json').write_bytes((P / 'fx-operand-rule-encode-trace-20261001-v1/static-tables-before-native.json').read_bytes())
    (out / 'requests.tsv').write_text('\n'.join(f'{r["id"]}\t0\t{r["input_base64"]}' for r in requests) + '\n', encoding='ascii')
    source, exe = out / 'NumericOperandOracle.cs', out / 'NumericOperandOracle.exe'
    build = subprocess.run([str(Path(os.environ['WINDIR']) / 'Microsoft.NET/Framework/v4.0.30319/csc.exe'),
                            '/nologo', '/platform:x86', '/out:' + str(exe), str(source)],
                           capture_output=True, timeout=30, creationflags=subprocess.CREATE_NO_WINDOW)
    (out / 'build.txt').write_bytes(build.stdout + build.stderr)
    if build.returncode:
        raise RuntimeError('Public encoder build failed')
    print(json.dumps(dict(stage='prepared-before-native', requests=len(requests), descriptors=435,
                          generation_gaps=len(generation_gaps))), flush=True)
    args = [str(exe), str(DLL), '521', str(out / 'requests.tsv'), str(out / 'baseline.jsonl')]
    run = subprocess.run(args, capture_output=True, timeout=45, creationflags=subprocess.CREATE_NO_WINDOW)
    (out / 'baseline-stdout.bin').write_bytes(run.stdout)
    (out / 'baseline-stderr.bin').write_bytes(run.stderr)
    save(out / 'baseline-process.json', dict(returncode=run.returncode))
    if run.returncode:
        raise RuntimeError('Public encoder failed; evidence retained')
    traced_run(args[:-1] + [str(out / 'traced.jsonl')], (P / 'TraceFXOperandRules.js').read_text(encoding='utf-8'), out)
    boundary = model.compare_events(out / 'events.jsonl')
    save(out / 'model-boundary-comparison.json', boundary)
    answers = [json.loads(l) for l in (out / 'baseline.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    if len(answers) != len(requests) or any(a['id'] != r['id'] for r, a in zip(requests, answers, strict=True)):
        raise ValueError('Public response framing differs')
    outcome_counts = collections.Counter()
    outcomes = []
    for request, answer in zip(requests, answers, strict=True):
        accepted = answer['code'] == 0
        outcome_counts[f'type-{request["all_type_roles_accepted"]}/encoder-{accepted}'] += 1
        outcomes.append(dict(id=request['id'], descriptor_index=request['descriptor_index'], name=request['name'],
                             profile=request['profile'], type_accepted=request['all_type_roles_accepted'],
                             native_accepted=accepted, code=answer['code'], error_offset=answer['error_offset'],
                             output_bytes=answer['capacity'] if accepted else 0))
    save(out / 'outcomes.json', outcomes)
    summary = dict(requests=len(requests), descriptor_inputs=435, generation_gaps=len(generation_gaps),
                   baseline_traced_exact=(out / 'baseline.jsonl').read_bytes() == (out / 'traced.jsonl').read_bytes(),
                   outcomes=dict(outcome_counts), counts=boundary['counts'], matched=boundary['matched'],
                   native_statuses=boundary['native_statuses'], reached_instruction_keys=len(boundary['instruction_keys']),
                   reached_roles=len(boundary['reached_roles']), failures=len(boundary['failures']), unsupported=len(boundary['unsupported']))
    save(out / 'comparison.json', summary)
    print(json.dumps(summary, ensure_ascii=True), flush=True)
    if boundary['failures'] or not summary['baseline_traced_exact']:
        raise ValueError('Static type predicates differ from native behavior; counterexamples retained')


if __name__ == '__main__':
    main()
