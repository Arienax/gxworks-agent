"""Observe raw-token parsing separately from the FX type/role predicates."""
from pathlib import Path
import json
import struct
import subprocess

from probe_fx_operand_rules import DLL, P, save, traced_run
from source_fx_operand_rules import FXOperandRules
from source_fx_operand_parser import compare_events
import pefile


def main():
    out = P / 'fx-operand-parser-full-corpus-20261001-v1'
    out.mkdir()
    prior = P / 'fx-operand-rule-full-corpus-20261001-v1'
    for name in ('before-native.json', 'requests.tsv', 'FXOperandCheckOracle.cs', 'FXOperandCheckOracle.exe',
                 'source_fx_operand_rules.py', 'static-tables-before-native.json'):
        (out / name).write_bytes((prior / name).read_bytes())
    for name in ('source_fx_operand_parser.py', 'TraceFXOperandRules.js', 'TraceFXOperandParser.js'):
        (out / name).write_bytes((P / name).read_bytes())
    image = pefile.PE(str(DLL)).get_memory_mapped_image()
    save(out / 'parser-static-before-native.json', dict(dll=str(DLL), file_version='15.31', cpu=521,
        parser_rva=0x25011, initialized_descriptor_bytes=8, descriptor_slot_bytes=9,
        prefix=image[0x25011:0x25011 + 13].hex(), selector_rva=0x2519b, selector_raw=image[0x2519b:0x251ab].hex(),
        jump_table_rva=0x25183, jump_table_raw=image[0x25183:0x2519b].hex(),
        jump_targets=[n - 0x10000000 for n in struct.unpack_from('<6I', image, 0x25183)]))
    args = [str(out / 'FXOperandCheckOracle.exe'), str(DLL), str(out / 'requests.tsv'), str(out / 'baseline.jsonl')]
    baseline = subprocess.run(args, capture_output=True, timeout=45, creationflags=subprocess.CREATE_NO_WINDOW)
    (out / 'baseline-stdout.bin').write_bytes(baseline.stdout)
    (out / 'baseline-stderr.bin').write_bytes(baseline.stderr)
    save(out / 'baseline-process.json', dict(returncode=baseline.returncode))
    if baseline.returncode:
        raise RuntimeError('Owned parser observation helper failed')
    hook = '\n'.join((P / name).read_text(encoding='utf-8') for name in ('TraceFXOperandRules.js', 'TraceFXOperandParser.js'))
    (out / 'combined-hook.js').write_text(hook, encoding='utf-8')
    traced_run(args[:-1] + [str(out / 'traced.jsonl')], hook, out)
    parsed = compare_events(out / 'events.jsonl')
    boundary = FXOperandRules().compare_events(out / 'events.jsonl')
    save(out / 'parser-boundary-comparison.json', parsed)
    save(out / 'model-boundary-comparison.json', boundary)
    summary = dict(baseline_prior_exact=(out / 'baseline.jsonl').read_bytes() == (prior / 'baseline.jsonl').read_bytes(),
                   baseline_traced_exact=(out / 'baseline.jsonl').read_bytes() == (out / 'traced.jsonl').read_bytes(),
                   parser_counts=parsed['counts'], parser_failures=len(parsed['failures']), parser_unsupported=len(parsed['unsupported']),
                   type_counts=boundary['counts'], type_matched=boundary['matched'],
                   type_failures=len(boundary['failures']), type_unsupported=len(boundary['unsupported']))
    save(out / 'comparison.json', summary)
    print(json.dumps(summary, ensure_ascii=True), flush=True)
    if parsed['failures'] or boundary['failures'] or not summary['baseline_traced_exact'] or not summary['baseline_prior_exact']:
        raise ValueError('Raw parser/model mismatch; preserved')


if __name__ == '__main__':
    main()
