"""Bypass mnemonic parsing to test FX type tables on bounded raw records."""
from pathlib import Path
import base64
import collections
import json
import struct
import subprocess

from probe_fx_operand_rules import DLL, P, save, traced_run
from source_fx_operand_rules import FXOperandRules
from source_fx_operand_parser import compare_events


def token(code, value):
    if not 0x90 <= code <= 0xff or not 0 <= value < 2**32:
        raise ValueError('Outside raw operand envelope')
    width = max(1, (value.bit_length() + 7) // 8)
    length = width + 3
    return bytes([length, code]) + value.to_bytes(width, 'little') + bytes([length])


def main():
    out = P / 'fx-operand-rule-raw-holdouts-20261001-v1'
    out.mkdir()
    prior = P / 'fx-operand-rule-catalog-holdouts-20261001-v1'
    text_requests = json.loads((prior / 'before-native.json').read_text(encoding='utf-8'))['requests']
    model = FXOperandRules()
    requests = []
    for row in text_requests:
        family, variant, arity = row['family'], row['variant'], row['arity']
        # Header shapes are explicit hypotheses. The native check and later
        # decoder establish their actual CPU-dependent reachability.
        header = bytes([3, family, 3]) if family < 0x40 and arity < 2 else (
            bytes([4, family, 127, 4]) if family < 0x40 else bytes([5, family, 127, variant, 5]))
        operands = []
        for prediction in row['type_prediction']:
            d = bytes.fromhex(prediction['descriptor_before'])
            raw = b''
            if d[0] != 0xff:
                raw += token(d[0], 0)
            if d[3] != 0xff:
                raw += token(0xf1, d[3])
            if d[4] != 0xff:
                raw += token(0xf0, d[4])
            if d[5] != 0xff:
                raw += token(0xf2, d[5])
            code = d[6]
            if code == 0xec:
                raw += bytes([7, code]) + struct.pack('<f', 1.5) + bytes([7])
            else:
                text = prediction['text']
                value = (65536 if code in (0xe9, 0xeb) else 1 if code in (0xe8, 0xea)
                         else 100 if code in (0xa8, 0xaf) else 16 if code == 0x90 else 0)
                raw += token(code, value)
            operands.append(raw)
        raw = header + b''.join(operands)
        requests.append(dict(id=len(requests), text_request_id=row['id'], name=row['name'], profile=row['profile'],
                             family=family, variant=variant, arity=arity, header_hypothesis=header.hex(), raw=raw.hex(),
                             input_base64=base64.b64encode(raw).decode(), type_prediction=row['type_prediction'],
                             all_type_roles_accepted=row['all_type_roles_accepted']))
    save(out / 'before-native.json', dict(cpu=521, mode=0, versions=[], file_version='15.31', requests=requests,
        scope='Raw single-record header hypotheses and known operand token spellings; public CPU checks are observations, not a PLC execution oracle.'))
    (out / 'requests.tsv').write_text('\n'.join(f'{r["id"]}\t{r["input_base64"]}' for r in requests) + '\n', encoding='ascii')
    old_check = P / 'fx-operand-rule-full-corpus-20261001-v1'
    for name in ('FXOperandCheckOracle.cs', 'FXOperandCheckOracle.exe', 'static-tables-before-native.json'):
        (out / name).write_bytes((old_check / name).read_bytes())
    for name in ('source_fx_operand_rules.py', 'source_fx_operand_parser.py', 'TraceFXOperandRules.js', 'TraceFXOperandParser.js'):
        (out / name).write_bytes((P / name).read_bytes())
    args = [str(out / 'FXOperandCheckOracle.exe'), str(DLL), str(out / 'requests.tsv'), str(out / 'baseline.jsonl')]
    baseline = subprocess.run(args, capture_output=True, timeout=45, creationflags=subprocess.CREATE_NO_WINDOW)
    (out / 'baseline-stdout.bin').write_bytes(baseline.stdout)
    (out / 'baseline-stderr.bin').write_bytes(baseline.stderr)
    save(out / 'baseline-process.json', dict(returncode=baseline.returncode))
    if baseline.returncode:
        raise RuntimeError('Bounded raw record check failed; counterexamples retained')
    hook = '\n'.join((P / name).read_text(encoding='utf-8') for name in ('TraceFXOperandRules.js', 'TraceFXOperandParser.js'))
    (out / 'combined-hook.js').write_text(hook, encoding='utf-8')
    traced_run(args[:-1] + [str(out / 'traced.jsonl')], hook, out)
    boundary = model.compare_events(out / 'events.jsonl')
    parsed = compare_events(out / 'events.jsonl')
    save(out / 'model-boundary-comparison.json', boundary)
    save(out / 'parser-boundary-comparison.json', parsed)
    answers = [json.loads(l) for l in (out / 'baseline.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    if len(answers) != len(requests) or any(a['id'] != r['id'] for r, a in zip(requests, answers, strict=True)):
        raise ValueError('Public check framing differs')
    outcomes, summary_counts = [], collections.Counter()
    for request, answer in zip(requests, answers, strict=True):
        accepted = answer['code'] == 0 and answer['status'] in (0, 1)
        summary_counts[f'type-{request["all_type_roles_accepted"]}/raw-check-{accepted}'] += 1
        outcomes.append(dict(id=request['id'], name=request['name'], profile=request['profile'],
            type_accepted=request['all_type_roles_accepted'], check_accepted=accepted,
            public_code=answer['code'], status=answer['status'], output_hex=base64.b64decode(answer['output_base64']).hex()))
    save(out / 'outcomes.json', outcomes)
    summary = dict(requests=len(requests), baseline_traced_exact=(out / 'baseline.jsonl').read_bytes() == (out / 'traced.jsonl').read_bytes(),
                   outcomes=dict(summary_counts), public_statuses=dict(collections.Counter(a['status'] for a in answers)),
                   type_counts=boundary['counts'], type_matched=boundary['matched'], type_statuses=boundary['native_statuses'],
                   type_failures=len(boundary['failures']), type_unsupported=len(boundary['unsupported']),
                   parser_counts=parsed['counts'], parser_failures=len(parsed['failures']), parser_unsupported=len(parsed['unsupported']),
                   reached_instruction_keys=len(boundary['instruction_keys']), reached_roles=len(boundary['reached_roles']))
    save(out / 'comparison.json', summary)
    print(json.dumps(summary, ensure_ascii=True), flush=True)
    if boundary['failures'] or parsed['failures'] or not summary['baseline_traced_exact']:
        raise ValueError('Raw holdout boundary mismatch; retained')


if __name__ == '__main__':
    main()
