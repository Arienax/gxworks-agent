"""Separate catalog type acceptance from native width rewrite support."""
from pathlib import Path
import base64
import collections
import json
import subprocess

from probe_fx_operand_rules import DLL, P, save, traced_run
from probe_fx_operand_rule_raw_holdouts import token
from source_fx_operand_rules import FXOperandRules
from source_fx_operand_parser import compare_events


def main():
    out = P / 'fx-instruction-phase-boundaries-20261001-v1'
    out.mkdir()
    raw_prior = P / 'fx-operand-rule-raw-holdouts-20261001-v1'
    old_requests = json.loads((raw_prior / 'before-native.json').read_text(encoding='utf-8'))['requests']
    outcomes = json.loads((raw_prior / 'outcomes.json').read_text(encoding='utf-8'))
    selected = [r for r in outcomes if r['type_accepted'] and not r['check_accepted']]
    selected += [r for r in outcomes if r['type_accepted'] and r['check_accepted']][:18]
    requests = []
    for answer in selected:
        old = old_requests[answer['id']]
        requests.append(dict(id=len(requests), origin='raw-catalog-holdout', prior_id=answer['id'],
                             name=old['name'], profile=old['profile'], raw=old['raw'],
                             input_base64=old['input_base64'], prior_public_status=answer['status']))
    # Role 8 is N nesting-level (D2), followed by role 9's M/Y bit device.
    # Preserve invalid controls instead of interpreting this as runtime MC proof.
    for name, first, second in [('mc-n0-m16', token(0xd2, 0), token(0x90, 16)),
                                ('mc-n0-y0', token(0xd2, 0), token(0x9d, 0)),
                                ('mc-n0-x0', token(0xd2, 0), token(0x9c, 0)),
                                ('mc-k0-m16', token(0xe8, 0), token(0x90, 16))]:
        raw = bytes([4, 0x2c, 127, 4]) + first + second
        requests.append(dict(id=len(requests), origin='missing-role-control', name=name, raw=raw.hex(),
                             input_base64=base64.b64encode(raw).decode()))
    save(out / 'before-native.json', dict(cpu=521, mode=0, versions=[], file_version='15.31', requests=requests,
                                        phase_rvas=[0x243a2, 0x3e534, 0x24422],
                                        scope='Memory-only function-boundary observations through public CheckInstructionCode2; no whole project/runtime equivalence implied.'))
    (out / 'requests.tsv').write_text('\n'.join(f'{r["id"]}\t{r["input_base64"]}' for r in requests) + '\n', encoding='ascii')
    for name in ('FXOperandCheckOracle.cs', 'FXOperandCheckOracle.exe', 'static-tables-before-native.json'):
        (out / name).write_bytes((raw_prior / name).read_bytes())
    for name in ('source_fx_operand_rules.py', 'source_fx_operand_parser.py', 'TraceFXOperandRules.js',
                 'TraceFXOperandParser.js', 'TraceFXInstructionPhases.js'):
        (out / name).write_bytes((P / name).read_bytes())
    args = [str(out / 'FXOperandCheckOracle.exe'), str(DLL), str(out / 'requests.tsv'), str(out / 'baseline.jsonl')]
    baseline = subprocess.run(args, capture_output=True, timeout=45, creationflags=subprocess.CREATE_NO_WINDOW)
    (out / 'baseline-stdout.bin').write_bytes(baseline.stdout)
    (out / 'baseline-stderr.bin').write_bytes(baseline.stderr)
    save(out / 'baseline-process.json', dict(returncode=baseline.returncode))
    if baseline.returncode:
        raise RuntimeError('Owned phase helper failed; retained')
    hook = '\n'.join((P / name).read_text(encoding='utf-8') for name in
                     ('TraceFXOperandRules.js', 'TraceFXOperandParser.js', 'TraceFXInstructionPhases.js'))
    (out / 'combined-hook.js').write_text(hook, encoding='utf-8')
    traced_run(args[:-1] + [str(out / 'traced.jsonl')], hook, out)
    parsed = compare_events(out / 'events.jsonl')
    boundary = FXOperandRules().compare_events(out / 'events.jsonl')
    save(out / 'parser-boundary-comparison.json', parsed)
    save(out / 'model-boundary-comparison.json', boundary)
    events = collections.defaultdict(list)
    for line in (out / 'events.jsonl').read_text(encoding='utf-8').splitlines():
        packet = json.loads(line)
        if packet['type'] == 'send' and 'request' in packet['payload']:
            e = packet['payload']
            events[e['request']].append(e)
    answers = [json.loads(l) for l in (out / 'baseline.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    if len(answers) != len(requests) or any(a['id'] != r['id'] for r, a in zip(requests, answers, strict=True)):
        raise ValueError('Phase response framing differs')
    classified = []
    for request, answer in zip(requests, answers, strict=True):
        batch = events[request['id']]
        checks = [e for e in batch if e['event'] == 'instruction-phase']
        widths = [e for e in batch if e['event'] == 'width-phase']
        if len(checks) != 1 or len(widths) > 1:
            raise ValueError('Native phase cardinality differs')
        reason = 'instruction-check-refused' if checks[0]['result'] < 0 else (
            'width-rewrite-refused' if widths and widths[0]['result'] <= 0 else 'accepted')
        classified.append(dict(id=request['id'], name=request['name'], origin=request['origin'],
                               prior_id=request.get('prior_id'), public_status=answer['status'],
                               instruction_status=checks[0]['result'], width_status=widths[0]['result'] if widths else None,
                               reason=reason))
    save(out / 'phase-classifications.json', classified)
    summary = dict(requests=len(requests), baseline_traced_exact=(out / 'baseline.jsonl').read_bytes() == (out / 'traced.jsonl').read_bytes(),
                   classifications=dict(collections.Counter(r['reason'] for r in classified)),
                   prior_refusal_phases=dict(collections.Counter(r['reason'] for r in classified if r.get('prior_id') in {s['id'] for s in selected if s['type_accepted'] and not s['check_accepted']})),
                   missing_role_controls=[r for r in classified if r['origin'] == 'missing-role-control'],
                   type_counts=boundary['counts'], type_matched=boundary['matched'], reached_roles=len(boundary['reached_roles']),
                   type_failures=len(boundary['failures']), parser_calls=parsed['counts']['parser_calls'],
                   parser_matched=parsed['counts']['matched'], parser_failures=len(parsed['failures']),
                   counter_check_states=dict(collections.Counter((e['enabled'], e['result']) for batch in events.values() for e in batch if e['event'] == 'counter-specific-check')))
    summary['counter_check_states'] = {str(k):v for k,v in summary['counter_check_states'].items()}
    save(out / 'comparison.json', summary)
    print(json.dumps(summary, ensure_ascii=True), flush=True)
    if boundary['failures'] or parsed['failures'] or not summary['baseline_traced_exact']:
        raise ValueError('Phase/type/parse mismatch retained')


if __name__ == '__main__':
    main()
