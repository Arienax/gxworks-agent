"""Cross-check FX operand tables against every raw record in one full project."""
from pathlib import Path
import base64
import collections
import json
import os
import subprocess
import sys

from probe_fx_operand_rules import DLL, P, ROOT, save, traced_run
from source_fx_operand_rules import FXOperandRules

sys.path.insert(0, str(ROOT / 'src'))
from gxw.token_pou import parse_token_region
from gxw.token_listing import decode_token_program


def main():
    out = P / 'fx-operand-rule-full-corpus-20261001-v1'
    out.mkdir()
    source_project = P / 'fx-full-sampled-comparisons-20261001-v2/partitioned-full-blocks'
    raw = (source_project / 'native-1/pcode-0-0.bin').read_bytes()
    program = parse_token_region(raw, 0, len(raw))
    listing = decode_token_program(program, profile='fx3u', text_encoding='cp936')
    independently_read = json.loads((source_project / 'independent-fx-reader/native-listing.json').read_text(encoding='utf-8'))
    if program.reconstruct() != raw or listing.gaps or len(listing.records) != len(independently_read):
        raise ValueError('Previously native-validated record framing differs')
    requests = []
    for index, (record, native) in enumerate(zip(listing.records, independently_read, strict=True)):
        fragment = b''.join(t.raw for t in record.tokens)
        if not 2 <= len(fragment) <= 512:
            raise ValueError('Record outside inspected caller envelope')
        requests.append(dict(id=index, raw=fragment.hex(), input_base64=base64.b64encode(fragment).decode(),
                             native_listing=native, offset=record.tokens[0].offset,
                             saved_width=record.step_width, saved_step=record.step))
    model = FXOperandRules()
    save(out / 'before-native.json', dict(source_project=str(source_project), raw_bytes=len(raw),
        cpu=521, mode=0, versions=[], file_version='15.31', fresh_object_per_record=True, requests=requests,
        context='Explicit null context invokes the converter default, not this project allocation table.',
        scope='Public checks of unchanged copied-project PCode records; original project compile/save/reopen acceptance is separate.'))
    (out / 'requests.tsv').write_text('\n'.join(f'{r["id"]}\t{r["input_base64"]}' for r in requests) + '\n', encoding='ascii')
    for name in ('FXOperandCheckOracle.cs', 'TraceFXOperandRules.js', 'source_fx_operand_rules.py'):
        (out / name).write_bytes((P / name).read_bytes())
    (out / 'static-tables-before-native.json').write_bytes((P / 'fx-operand-rule-encode-trace-20261001-v1/static-tables-before-native.json').read_bytes())
    source, exe = out / 'FXOperandCheckOracle.cs', out / 'FXOperandCheckOracle.exe'
    build = subprocess.run([str(Path(os.environ['WINDIR']) / 'Microsoft.NET/Framework/v4.0.30319/csc.exe'),
                            '/nologo', '/platform:x86', '/out:' + str(exe), str(source)],
                           capture_output=True, timeout=30, creationflags=subprocess.CREATE_NO_WINDOW)
    (out / 'build.txt').write_bytes(build.stdout + build.stderr)
    if build.returncode:
        raise RuntimeError('Public instruction check helper build failed')
    args = [str(exe), str(DLL), str(out / 'requests.tsv'), str(out / 'baseline.jsonl')]
    baseline = subprocess.run(args, capture_output=True, timeout=45, creationflags=subprocess.CREATE_NO_WINDOW)
    (out / 'baseline-stdout.bin').write_bytes(baseline.stdout)
    (out / 'baseline-stderr.bin').write_bytes(baseline.stderr)
    save(out / 'baseline-process.json', dict(returncode=baseline.returncode))
    if baseline.returncode:
        raise RuntimeError('Bounded instruction check failed; original buffers retained')
    traced_run(args[:-1] + [str(out / 'traced.jsonl')], (P / 'TraceFXOperandRules.js').read_text(encoding='utf-8'), out)
    boundary = model.compare_events(out / 'events.jsonl')
    save(out / 'model-boundary-comparison.json', boundary)
    answers = [json.loads(l) for l in (out / 'baseline.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    if len(answers) != len(requests) or any(a['id'] != r['id'] for r, a in zip(requests, answers, strict=True)):
        raise ValueError('Public response framing differs')
    exact, changed, refused = [], [], []
    for request, answer in zip(requests, answers, strict=True):
        same = bytes.fromhex(request['raw']) == base64.b64decode(answer['output_base64'])
        row = dict(id=request['id'], offset=request['offset'], saved_step=request['saved_step'],
                   native_listing=request['native_listing'], public_code=answer['code'], status=answer['status'], byte_exact=same)
        if answer['code'] != 0 or answer['status'] not in (0, 1):
            refused.append(row)
        elif same:
            exact.append(row)
        else:
            changed.append(row)
    save(out / 'changed-records.json', changed)
    save(out / 'refused-records.json', refused)
    summary = dict(records=len(requests), raw_bytes=len(raw), byte_exact_accepted=len(exact), changed_accepted=len(changed),
                   refused_default_context=len(refused), public_statuses=dict(collections.Counter(a['status'] for a in answers)),
                   all_guards_intact=all(a['guards_intact'] for a in answers),
                   baseline_traced_exact=(out / 'baseline.jsonl').read_bytes() == (out / 'traced.jsonl').read_bytes(),
                   counts=boundary['counts'], matched=boundary['matched'], native_statuses=boundary['native_statuses'],
                   reached_instruction_keys=len(boundary['instruction_keys']), reached_roles=len(boundary['reached_roles']),
                   failures=len(boundary['failures']), unsupported=len(boundary['unsupported']))
    save(out / 'comparison.json', summary)
    print(json.dumps(summary, ensure_ascii=True), flush=True)
    if boundary['failures'] or not summary['baseline_traced_exact']:
        raise ValueError('Whole-corpus type boundary mismatch; retained')


if __name__ == '__main__':
    main()
