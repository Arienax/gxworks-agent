"""Join fresh saved FX debug coordinates to independently counted live points.

Retains all stored expansion names and endpoints. An outlined FX body can have
an instance name in saved metadata while its live DBG_INFO identity names the
shared definition. That difference is retained, not interpreted as ownership.
"""
from pathlib import Path
import collections
import json
import sys

P=Path(__file__).resolve().parent;ROOT=P.parents[3]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research'),str(P)]
from gxw.compiler_debug import parse_compiler_debug,compiler_st_source_points
from probe_minimal_conditional_port_writes import streams


def save(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=True)+'\n',encoding='utf-8')


def main():
    out=P/'fx-full-sampled-comparisons-20261001-v2/partitioned-full-blocks'
    correspondence=json.loads((out/'source-reference-correspondence-v2.json').read_text(encoding='utf-8'))
    prefixes=json.loads((out/'independent-source-prefixes/comparisons.json').read_text(encoding='utf-8'))
    if not correspondence['summary']['native_check_accepted'] or not all(r['equal'] for r in prefixes):
        raise ValueError('accepted independent source prefix evidence required')
    counted={i:r for r in prefixes for i in r['point_indices']}
    live=correspondence['finalized_source_points']
    raw=streams((out/'native-1/native-saved.gxw').read_bytes())['DebugInformation2.dat']
    reopened_raw=streams((out/'reopen/native-1/native-saved.gxw').read_bytes())['DebugInformation2.dat']
    parsed=parse_compiler_debug(raw);points=compiler_st_source_points(parsed)
    after=parse_compiler_debug(reopened_raw);reopened=compiler_st_source_points(after)
    if parsed.reconstruct()!=raw or after.reconstruct()!=reopened_raw:raise ValueError('saved debug reconstruction differs')
    def native_key(r):return (r['identity']['definition'],r['location']['line'],r['linked_step'])
    def stored_key(r):return (r.definition_name_bytes.decode('cp936'),r.source_line,r.compiled_step_start)
    native_index=collections.defaultdict(list)
    for i,r in enumerate(live):native_index[native_key(r)].append(i)
    if collections.Counter(stored_key(r) for r in points)!=collections.Counter(native_key(r) for r in live):
        raise ValueError('live and saved source coordinates differ; retained')
    if any(len(v)!=1 for v in native_index.values()):raise ValueError('ambiguous source-coordinate join; retain without choosing')
    rows=[]
    for r in points:
        i=native_index[stored_key(r)][0];m=live[i];n=counted[i]
        if n['native_steps']!=r.compiled_step_start:raise ValueError('saved coordinate lacks independent prefix agreement')
        rows.append(dict(element_index=parsed.elements.index(r.element),row_index=r.row_index,
            context_names=[v.decode('cp936') for v in r.context_names],resource_hex=r.element.resource_bytes.hex(),
            source_line=r.source_line,compiled_step_start=r.compiled_step_start,stored_step_end=r.compiled_step_end,
            live_identity=m['identity'],compile_id=m['compile_id'],native_location=m['location'],
            native_prefix_byte_offset=m['prefix_byte_offset'],independent_prefix_steps=n['native_steps'],
            raw_offset_row=list(r.row),native_data_hex=m['data_hex'],native_user_info_hex=m['user_info_hex']))
    def complete_key(r):return (r.context_names,r.element.resource_bytes,r.source_line,r.compiled_step_start,r.compiled_step_end)
    same=collections.Counter(complete_key(r) for r in points)==collections.Counter(complete_key(r) for r in reopened)
    summary=dict(debug_bytes=len(raw),debug_elements=len(parsed.elements),debug_offset_tables=len(parsed.offset_tables),
        saved_st_points=len(points),live_st_points=len(live),saved_live_unique_matches=len(rows),
        independent_start_coordinates=len(rows),saved_debug_reconstruction_exact=True,
        reopen_debug_bytes_exact=raw==reopened_raw,reopen_complete_point_multiset_exact=same)
    output=out/'saved-source-point-correspondence.json'
    if output.exists():raise FileExistsError(output)
    save(output,dict(summary=summary,rows=rows,limitations=[
        'The saved five-name context is retained separately from the live outlined-body identity.',
        'A stored instance name on a shared outlined body is not a unique runtime callsite or exclusive statement instruction range.',
        'Stored endpoints are retained without an inclusive, exclusive or semantic-ownership interpretation.',
        'No PLC or simulator execution semantics are inferred from these source coordinates.']))
    print(json.dumps(summary),flush=True)


if __name__=='__main__':main()
