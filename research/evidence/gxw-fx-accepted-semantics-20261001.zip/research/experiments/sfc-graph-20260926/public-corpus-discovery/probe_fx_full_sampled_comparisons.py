"""Prospective full-source edits after the indexed BOOL alias counterexample.

Each indexed operand is captured independently before its comparison. A
separate control additionally partitions observed oversized straight-line
blocks while retaining all fields, calls, and source operations in that input.
"""
from dataclasses import replace
from pathlib import Path
import collections
import json
import re
import sys

P=Path(__file__).resolve().parent;ROOT=P.parents[3]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research'),str(P)]
from gxw.declarations import parse_declarations,parse_structure_declarations,serialize_declarations
from gxw.text_pou import parse_st_pou
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_st_sources import replace_observed_st
from probe_gxw_program_check_resources import SCRIPT
from trace_pcode_ladder_corpus import SCRIPT as LADDER
from probe_minimal_conditional_port_writes import streams,observe
from inspect_fx_full_st import verify,inventory
from inspect_fx_conversion_coverage import coverage
from inspect_native_st_references import read_events
from probe_fx_full_source_edits import PROCESS,LABELS


def save(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=True)+'\n',encoding='utf-8')


def sampled(before):
    text=parse_st_pou(before[PROCESS]).text
    first='xResearchCoilsDiffer := M0Z5 <> M0Z6;'
    left='xResearchCoilLeft';right='xResearchCoilRight'
    if text.count(first)==1:
        text=text.replace(first,left+' := M0Z5;\r\n\t\t\t\t\t'+right+' := M0Z6;\r\n\t\t\t\t\txResearchCoilsDiffer := '+left+' <> '+right+';')
    else:
        marker='\t\t\t\t\t(* If device was changed *)'
        predicate='M0Z5 <> M0Z6'
        if text.count(marker)!=1 or text.count(predicate)!=1:raise ValueError('first comparison source differs')
        text=text.replace(marker,'\t\t\t\t\t'+left+' := M0Z5;\r\n\t\t\t\t\t'+right+' := M0Z6;\r\n'+marker).replace(predicate,left+' <> '+right)
    marker='\t\t\t\t\tSET(CHANNEL.iWR <> MB_READ \r\n\t\t\t\t\t\tAND M0Z3 <> M0Z4 '
    predicate='M0Z3 <> M0Z4'
    if text.count(marker)!=1 or text.count(predicate)!=1:raise ValueError('second comparison source differs')
    text=text.replace(marker,'\t\t\t\t\t'+left+' := M0Z3;\r\n\t\t\t\t\t'+right+' := M0Z4;\r\n'+marker).replace(predicate,left+' <> '+right)
    if 'M0Z5 <> M0Z6' in text or 'M0Z3 <> M0Z4' in text:raise ValueError('indexed pair comparison survives')
    document=parse_declarations(before[LABELS],logical_name=LABELS);exemplar=next(r for r in document.rows if r.name=='xBit')
    base=max(r.record_id for r in document.rows)
    rows=tuple(replace(exemplar,name=name,record_id=base+i+1,comment='Offline control: retain each sampled coil operand') for i,name in enumerate((left,right)))
    if {r.name for r in rows}&{r.name for r in document.rows}:raise ValueError('duplicate local control name')
    labels=serialize_declarations(replace(document,rows=document.rows+rows))
    return {PROCESS:text,LABELS:labels}


def guarded_assignments(assignments,indent,predicate,*,chunk=2):
    lines=[]
    for i in range(0,len(assignments),chunk):
        lines.append(indent+'IF '+predicate+' OR NOT '+predicate+' THEN')
        lines.extend(indent+'    '+a for a in assignments[i:i+chunk])
        lines.append(indent+'END_IF;')
    return '\r\n'.join(lines)


def partitioned(before,changes):
    changes=dict(changes)
    channel_name=next(n for n in before if n.startswith('ST_MB_REG_50\\') and n.endswith('.lns'))
    channel=parse_structure_declarations(before[channel_name],logical_name=channel_name)
    if len(channel.members)!=19:raise ValueError('channel member count changed')
    def channel_write(m):return guarded_assignments(['MB_CHANNELS[iChannelID].'+r.name+' := CHANNEL.'+r.name+';' for r in channel.members],m[1],'mb_xEnable')
    text,count=re.subn(r'^([ \t]*)MB_CHANNELS\[iChannelID\] := CHANNEL;',channel_write,changes[PROCESS],flags=re.M)
    if count!=1:raise ValueError('expected one whole channel writeback')
    changes[PROCESS]=text
    alarm_name=next(n for n in before if n.startswith('ST_AM_ALARM\\') and n.endswith('.lns'))
    alarm=parse_structure_declarations(before[alarm_name],logical_name=alarm_name)
    if len(alarm.members)!=11 or any(r.data_type not in ('BOOL','INT','DWORD') for r in alarm.members):raise ValueError('outside observed flat alarm type')
    for definition,index,predicate in [('FB_AM_SET','iAN','xState'),('FB_AM_RESET','iCount','IN')]:
        logical=next(n for n in before if n.startswith(definition+'.Program\\') and n.endswith('.lnb'))
        text=parse_st_pou(before[logical]).text
        def alarm_read(m):return guarded_assignments(['ALARM.'+r.name+' := AM_ALARMS['+index+'].'+r.name+';' for r in alarm.members],m[1],predicate)
        text,count=re.subn(r'^([ \t]*)ALARM := AM_ALARMS\['+index+r'\];',alarm_read,text,flags=re.M)
        if count!=(1 if definition=='FB_AM_SET' else 2):raise ValueError('alarm read count changed')
        if definition=='FB_AM_SET':
            def alarm_write(m):return guarded_assignments(['AM_ALARMS['+index+'].'+r.name+' := ALARM.'+r.name+';' for r in alarm.members],m[1],predicate)
            text,count=re.subn(r'^([ \t]*)AM_ALARMS\['+index+r'\] := ALARM;',alarm_write,text,flags=re.M)
            if count!=1:raise ValueError('alarm write count changed')
        changes[logical]=text
    logical=next(n for n in before if n.startswith('FB_AM_INIT.Program\\') and n.endswith('.lnb'))
    text=parse_st_pou(before[logical]).text
    lines=text.splitlines();assignments=lines[2:]
    if len(assignments)!=8 or not all(re.fullmatch(r'AM_ALARMS\[iAN\]\.[A-Za-z]+\s*:=.+;',s) for s in assignments):raise ValueError('alarm initialization source differs')
    changes[logical]='\r\n'.join(lines[:2])+'\r\n'+guarded_assignments(assignments,'','xBuzzer')+'\r\n'
    logical=next(n for n in before if n.startswith('PRG_TEST_TCO_50.Program\\') and n.endswith('.lnb'))
    text=parse_st_pou(before[logical]).text
    def ticker(m):return guarded_assignments([m[0]],'','xCapture',chunk=1)
    text,count=re.subn(r'^(?:ii[1234]|di1|tTicker|dui[12]|tSec|tMin)\s*:=\s*F_[^\r\n]+;',ticker,text,flags=re.M)
    if count!=10:raise ValueError('ticker and duration conversion count changed')
    changes[logical]=text
    return changes


def main():
    out=P/(sys.argv[1] if len(sys.argv)>1 else 'fx-full-sampled-comparisons-20261001-v2')
    original=(P/'fx-original-full-st-20261001/native-1/input.gxw').read_bytes()
    combined=(P/'fx-full-source-edits-20261001-v3/combined/input.gxw').read_bytes()
    base=streams(combined);fixed=sampled(base)
    cases=[('original-two-snapshots',original,sampled(streams(original)),
        'Both comparison sites should use two retained distinct operands. Native diagnostics beyond the old failure are measured separately.'),
        ('combined-two-snapshots',combined,fixed,
        'Independent operand captures should remove the remaining compound-comparison conversion refusal. Existing oversized blocks may remain.'),
        ('partitioned-full-blocks',combined,partitioned(base,fixed),
        'Partition all currently observed oversized copies, alarm initialization and adjacent ticker calls; predict complete native acceptance without removing an operation from this combined input.')]
    out.mkdir()
    trace=out/'trace.js';trace.write_text('(function(){\n'+(P/'native-allocation-bitmap-v2/observer.js').read_text(encoding='utf-8')+'\n'+
        (P/'trace_native_source_points.js').read_text(encoding='utf-8')+'\n})();\n(function(){\n'+SCRIPT+'\n})();\n(function(){\n'+LADDER+'\n})();',encoding='utf-8')
    ready=[]
    for name,source,changes,hypothesis in cases:
        directory=out/name;directory.mkdir();before=streams(source);updates={}
        for logical,value in changes.items():
            value=replace_observed_st(before[logical],value)[0] if isinstance(value,str) else value
            updates[logical]=value;source,_=patch_raw(source,logical,before[logical],value)
        if streams(source)!=dict(before,**updates):raise ValueError('unrelated logical payload changed')
        (directory/'input.gxw').write_bytes(source)
        save(directory/'before-native.json',dict(hypothesis=hypothesis,changed_streams=list(updates),
            unrelated_payloads_byte_exact=True,texts={k:v for k,v in changes.items() if isinstance(v,str)},
            inherited_scope='Combined seed selects only master port 2; original control retains all six protocol calls.',
            scope='Copied local projects, full fresh native compile/check/export/save/reopen; no execution'))
        ready.append((name,directory));print(json.dumps(dict(case=name,prepared=True)),flush=True)
    results=[]
    for name,directory in ready:
        native,result,process=observe(directory/'input.gxw',directory,trace)
        save(directory/'native-correspondence.json',dict(diagnostics=result['diagnostics']))
        listing,verified=verify(native);correspondence=inventory(native);save(directory/'source-reference-correspondence.json',correspondence)
        calls=[r for r in read_events(native) if r.get('event')=='conversion'];save(directory/'calls.json',calls)
        located=coverage((native/'pcode-0-0.bin').read_bytes(),calls);save(directory/'conversion-coverage.json',located)
        errors=collections.Counter(d['code'] for d in result['diagnostics'] if d['kind']==2)
        row=dict(case=name,native=str(native),check=result['check'],backend_rejected=result['backend_check_rejected'],
            errors={hex(k):v for k,v in errors.items()},diagnostics=result['diagnostics'],process=process,
            native_reading=verified,conversion_summary=located['summary'])
        if result['check'] is not None and not result['check']['rejected']:
            reopen=directory/'reopen';reopen.mkdir();again,checked,proc=observe(native/'native-saved.gxw',reopen,trace)
            row['reopen']=dict(check=checked['check'],backend_rejected=checked['backend_check_rejected'],channels=[
                dict(channel=i,byte_identical=(native/f'pcode-0-{i}.bin').read_bytes()==(again/f'pcode-0-{i}.bin').read_bytes()) for i in range(3)])
        results.append(row);save(out/'comparison.json',results)
        print(json.dumps(dict(case=name,check=row['check'],errors=row['errors'],conversion=row['conversion_summary'],reopen=row.get('reopen'))),flush=True)


if __name__=='__main__':main()
