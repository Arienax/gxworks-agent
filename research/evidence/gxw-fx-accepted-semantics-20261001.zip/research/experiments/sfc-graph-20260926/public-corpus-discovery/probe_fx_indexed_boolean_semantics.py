"""Independent truth-table witnesses for source BOOL comparison lowering.

All source controls precede native compilation. A bounded, fail-closed
instruction evaluator executes only copied in-memory values and measured
ordinary bit/word operations, never a PLC or simulator. Native acceptance is
recorded separately from truth-table equality and full native token decoding.
"""
from dataclasses import replace
from pathlib import Path
import collections
import itertools
import json
import re
import sys

P=Path(__file__).resolve().parent;ROOT=P.parents[3]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research'),str(P)]
from gxw.declarations import parse_declarations,serialize_declarations
from gxw.project_metadata import mark_observed_source_compile_pending
from gxw.text_pou import parse_st_pou
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_st_sources import replace_observed_st
from probe_gxw_program_check_resources import SCRIPT
from probe_minimal_conditional_port_writes import streams,observe
from inspect_fx_full_st import verify,inventory


def save(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=True)+'\n',encoding='utf-8')


def evaluate(rows,left,right,*,max_instructions=2000):
    """Bit packing and ordinary Boolean block semantics; refuse unknown ops."""
    bits={128:bool(left),256:bool(right)};words={};stack=[];acc=False;finished=True;history=[]
    labels={r['text']:i for i,r in enumerate(rows) if r['kind']=='label'}
    def address(text):
        m=re.fullmatch(r'(K4)?(M|D|Z)([0-9]+)(?:Z([0-9]+))?',text)
        if not m:raise ValueError('outside evaluated address: '+text)
        group,family,n,index=m.groups();n=int(n)+(words.get(('Z',int(index)),0) if index is not None else 0)
        if group and family!='M':raise ValueError('outside evaluated packed address')
        return group,family,n
    def read(text):
        if re.fullmatch(r'K-?[0-9]+',text):return int(text[1:])
        if re.fullmatch(r'H[0-9A-F]+',text):return int(text[1:],16)
        group,family,n=address(text)
        if family=='M':
            if group:return sum(int(bits.get(n+i,False))<<i for i in range(16))
            if n==8000:return True
            if n==8001:return False
            return bits.get(n,False)
        return words.get((family,n),0)
    def write(text,value):
        group,family,n=address(text)
        if family=='M':
            if group:
                for i in range(16):bits[n+i]=bool(int(value)&(1<<i))
            else:bits[n]=bool(value)
        else:words[family,n]=int(value)&0xffff
    pc=0;count=0
    while pc<len(rows):
        count+=1
        if count>max_instructions:raise ValueError('evaluation budget exceeded')
        r=rows[pc];pc+=1
        if r['kind']=='label':
            if stack:raise ValueError('unclosed Boolean stack at label')
            finished=True;continue
        op=r['op'];args=r['args']
        if op in ('LD','LDI','LD=','LD<>'):
            if not finished:stack.append(acc)
            acc=(bool(read(args[0])) if op=='LD' else not bool(read(args[0])) if op=='LDI'
                else read(args[0])==read(args[1]) if op=='LD=' else read(args[0])!=read(args[1]))
            finished=False
        elif op in ('AND','ANI','OR','ORI'):
            value=bool(read(args[0]));value=not value if op in ('ANI','ORI') else value
            acc=acc and value if op in ('AND','ANI') else acc or value
        elif op in ('ANB','ORB'):
            if not stack:raise ValueError('Boolean block underflow')
            value=stack.pop();acc=value and acc if op=='ANB' else value or acc
        elif op=='INV':acc=not acc
        elif op in ('OUT','SET','RST'):
            if len(args)!=1:raise ValueError('outside measured scalar output')
            if op=='OUT':write(args[0],acc)
            elif acc:write(args[0],op=='SET')
            finished=True
        elif op in ('MOV','WAND','WOR'):
            if acc:
                value=read(args[0]) if op=='MOV' else int(read(args[0]))&int(read(args[1])) if op=='WAND' else int(read(args[0]))|int(read(args[1]))
                write(args[-1],value)
            finished=True
        elif op=='CJ':
            if stack:raise ValueError('unclosed Boolean stack at jump')
            if acc:pc=labels[args[0]]
            finished=True
        elif op in ('NOP','FEND','END'):
            if stack:raise ValueError('unclosed Boolean stack at program end')
            finished=True
        else:raise ValueError('unsupported instruction in semantic witness: '+op)
        history.append(dict(pc=pc-1,op=op,acc=acc,stack=list(stack)))
    if stack:raise ValueError('unclosed final Boolean stack')
    return dict(M100=bool(read('M100')),M101=bool(read('M101')),D100=read('D100'),D101=read('D101'))


def main():
    out=P/(sys.argv[1] if len(sys.argv)>1 else 'fx-indexed-boolean-semantics-20261001-v1');out.mkdir()
    original=(P/'fx3g-library-source-roundtrip-v6/true-source-only/compile-1/native-saved.gxw').read_bytes()
    before=streams(original);labels='MAIN.Labels.lh';body='MAIN.Program.pou'
    document=parse_declarations(before[labels],logical_name=labels)
    if document.rows:raise ValueError('minimal seed locals are not empty')
    full=streams((P/'fx-original-full-st-20261001/native-1/input.gxw').read_bytes())
    exemplar=next(r for r in parse_declarations(full[labels],logical_name=labels).rows if r.name=='xSaveIp')
    rows=tuple(replace(exemplar,name=name,record_id=i+1,comment='Offline semantic witness') for i,name in enumerate(('xLeft','xRight')))
    decl=mark_observed_source_compile_pending(serialize_declarations(replace(document,rows=rows)),logical_name=labels)
    expressions=[('scalar-pair','M128','M256'),('indexed-pair','M0Z5','M0Z6'),
        ('indexed-left','M0Z5','M256'),('indexed-right','M128','M0Z6'),('snapshot-pair','xLeft','xRight')]
    cases=[(name,'Z5 := 128;\r\nZ6 := 256;\r\n'+('xLeft := M0Z5;\r\nxRight := M0Z6;\r\n' if name=='snapshot-pair' else '')+
        'M100 := '+left+' <> '+right+';\r\nM101 := '+left+' = '+right+';\r\n',False) for name,left,right in expressions]
    cases.append(('indexed-condition','Z5 := 128;\r\nZ6 := 256;\r\nD100 := 0;\r\nIF M0Z5 <> M0Z6 THEN D100 := 1; END_IF;\r\nD101 := 0;\r\nIF M0Z5 = M0Z6 THEN D101 := 1; END_IF;\r\n',True))
    trace=out/'trace.js';trace.write_text('(function(){\n'+(P/'native-allocation-bitmap-v2/observer.js').read_text(encoding='utf-8')+'\n'+
        (P/'trace_native_source_points.js').read_text(encoding='utf-8')+'\n})();\n(function(){\n'+SCRIPT+'\n})();',encoding='utf-8')
    ready=[]
    for name,text,condition in cases:
        directory=out/name;directory.mkdir();source=original;updates={labels:decl,
            body:mark_observed_source_compile_pending(replace_observed_st(before[body],text)[0],logical_name=body)}
        for logical,raw in updates.items():source,_=patch_raw(source,logical,before[logical],raw)
        if streams(source)!=dict(before,**updates):raise ValueError('unrelated payload changed')
        (directory/'input.gxw').write_bytes(source)
        save(directory/'before-native.json',dict(source=text,changed_streams=list(updates),unrelated_payloads_byte_exact=True,
            expected_truth_table=[dict(left=left,right=right,not_equal=left!=right,equal=left==right) for left,right in itertools.product((False,True),repeat=2)],
            hypothesis='The source EQ/NE comparison should preserve both distinct sampled BOOL operands.',native_acceptance='measured separately',scope='offline compile and abstract instruction evaluation only'))
        ready.append((name,directory,condition))
    results=[]
    for name,directory,condition in ready:
        native,result,process=observe(directory/'input.gxw',directory,trace)
        save(directory/'native-correspondence.json',dict(diagnostics=result['diagnostics']))
        listing,verified=verify(native);correspondence=inventory(native);save(directory/'source-reference-correspondence.json',correspondence)
        cid=next(g['compile_id'] for g in correspondence['linked_groups'] if g['names'][0]=='MAIN')
        rows=[r['compiled'] for r in correspondence['joined_instructions'] if r['compile_id']==cid]
        save(directory/'evaluated-main-records.json',rows)
        witnesses=[]
        for left,right in itertools.product((False,True),repeat=2):
            try:
                state=evaluate(rows,left,right);actual=dict(not_equal=bool(state['D100' if condition else 'M100']),equal=bool(state['D101' if condition else 'M101']))
                expected=dict(not_equal=left!=right,equal=left==right)
                witnesses.append(dict(left=left,right=right,actual=actual,expected=expected,equal=actual==expected,handling='evaluated'))
            except (ValueError,KeyError) as e:witnesses.append(dict(left=left,right=right,handling='unsupported',reason=str(e)))
        row=dict(case=name,native=str(native),check=result['check'],backend_rejected=result['backend_check_rejected'],diagnostics=result['diagnostics'],
            native_reading=verified,witnesses=witnesses,truth_table_exact=all(w.get('equal',False) for w in witnesses),process=process)
        if result['check'] is not None and not result['check']['rejected']:
            reopen=directory/'reopen';reopen.mkdir();again,checked,proc=observe(native/'native-saved.gxw',reopen,trace)
            row['reopen']=dict(check=checked['check'],backend_rejected=checked['backend_check_rejected'],channels=[
                dict(channel=i,byte_identical=(native/f'pcode-0-{i}.bin').read_bytes()==(again/f'pcode-0-{i}.bin').read_bytes()) for i in range(3)])
        results.append(row);save(out/'comparison.json',results)
        print(json.dumps(dict(case=name,check=row['check'],truth_table_exact=row['truth_table_exact'],witnesses=witnesses,reopen=row.get('reopen'))),flush=True)


if __name__=='__main__':main()
