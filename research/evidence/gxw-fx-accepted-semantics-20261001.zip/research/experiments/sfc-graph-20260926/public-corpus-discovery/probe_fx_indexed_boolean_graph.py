"""Cross-check comparison fragments through the public native ladder grid.

Uses the exact compiled bit instruction bytes and an independently evaluated
contact graph. Sampled-value bindings are explicit measured data-flow facts,
not inferred from the contact graph or the expected EQ/NE truth tables.
"""
from pathlib import Path
import base64
import itertools
import json
import os
import subprocess
import sys

P=Path(__file__).resolve().parent;ROOT=P.parents[3]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research'),str(P)]
from gxw.token_pou import parse_token_region
from gxw.token_listing import decode_token_program
from check_native_ladder_boolean_graph import graph,evaluate


def save(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=True)+'\n',encoding='utf-8')


def main():
    source=P/'fx-indexed-boolean-semantics-20261001-v1'
    out=P/'fx-indexed-boolean-native-grid-20261001-v1';out.mkdir()
    bindings={
        'scalar-pair':{'M128':'left','M256':'right'},
        'indexed-pair':{'M7444':'left','M7445':'right'},
        'indexed-left':{'M7445':'left','M256':'right'},
        'indexed-right':{'M128':'left','M7444':'left','M7445':'right'},
        'snapshot-pair':{'M7447':'left','M7446':'right'},
    }
    requests=[];prepared=[]
    for name,mapping in bindings.items():
        info=json.loads((source/name/'source-reference-correspondence.json').read_text(encoding='utf-8'))
        accepted=next(r for r in json.loads((source/'comparison.json').read_text(encoding='utf-8')) if r['case']==name)
        if accepted['check']['rejected'] or not accepted['native_reading']['whole_listing_exact']:
            raise ValueError('accepted independent native listing required')
        native=Path(accepted['native']);raw=(native/'pcode-0-0.bin').read_bytes()
        listing=decode_token_program(parse_token_region(raw,0,len(raw)),profile='fx3u',text_encoding='cp936')
        rows=info['joined_instructions']
        for target,comparison in [('M100','not_equal'),('M101','equal')]:
            ends=[i for i,r in enumerate(rows) if r['compiled']==dict(kind='instruction',op='OUT',args=[target])]
            if len(ends)!=1:raise ValueError('ambiguous witness coil')
            end=ends[0];start=end-5;fragment=rows[start:end+1]
            if [r['compiled']['op'] for r in fragment] not in (['LD','ANI','LDI','AND','ORB','OUT'],['LD','AND','LDI','ANI','ORB','OUT']):
                raise ValueError('outside comparison fragment grammar')
            token_bytes=b''.join(t.raw for r in listing.records[start:end+1] for t in r.tokens)
            begin=fragment[0]['byte_offset'];finish=rows[end+1]['byte_offset']
            if raw[begin:finish]!=token_bytes:raise ValueError('fragment bytes differ from whole native code')
            contacts={r['compiled']['args'][0] for r in fragment[:-2]}
            if not contacts<=mapping.keys():raise ValueError('unbound sampled contact')
            index=len(requests);request=dict(id=index,cpu=521,input_base64=base64.b64encode(token_bytes+b'\0').decode('ascii'))
            requests.append(request)
            prepared.append(dict(id=index,case=name,comparison=comparison,target=target,byte_start=begin,byte_end=finish,
                exact_native_fragment=True,records=[r['compiled'] for r in fragment],sampled_value_bindings=mapping,
                binding_basis='Explicit checked prefix reads and stores: K4M indexed low bit, retained left snapshot, and two distinct local stores.',
                expected=[dict(left=left,right=right,value=(left!=right if comparison=='not_equal' else left==right))
                    for left,right in itertools.product((False,True),repeat=2)]))
    save(out/'before-native.json',dict(configuration=dict(cpu=521,mode=0,version='15.31'),requests=requests,fragments=prepared,
        scope='Offline P-to-LD conversion and static contact graph; no controller or simulator execution'))
    cs=out/'LadderByteOracle.cs';cs.write_bytes((ROOT/'research/native/LadderByteOracle.cs').read_bytes());exe=out/'LadderByteOracle.exe'
    build=subprocess.run([str(Path(os.environ['WINDIR'])/'Microsoft.NET/Framework/v4.0.30319/csc.exe'),'/nologo','/platform:x86',
        '/r:System.Web.Extensions.dll','/out:'+str(exe),str(cs)],capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW,timeout=30)
    (out/'build.txt').write_bytes(build.stdout+build.stderr)
    if build.returncode:raise RuntimeError('isolated helper build failed')
    version=subprocess.run(['powershell','-NoProfile','-Command',
        "(Get-Item -LiteralPath 'D:\\GXWORKS2\\Easysocket\\CodeGenerator\\ECCodeGeneratorFX2.dll').VersionInfo.FileVersion"],
        capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW,timeout=30)
    if version.returncode or version.stdout.strip()!=b'15.31':raise ValueError('unobserved native converter version')
    run=subprocess.run([str(exe),'D:/GXWORKS2/Easysocket/CodeGenerator/ECCodeGeneratorFX2.dll',str(out)],
        input=('\n'.join(json.dumps(r) for r in requests)+'\n').encode('ascii'),capture_output=True,
        creationflags=subprocess.CREATE_NO_WINDOW,timeout=45)
    (out/'stdout.jsonl').write_bytes(run.stdout);(out/'stderr.bin').write_bytes(run.stderr)
    save(out/'process.json',dict(returncode=run.returncode))
    answers=[json.loads(line) for line in run.stdout.splitlines()]
    if run.returncode or len(answers)!=len(requests):raise RuntimeError('incomplete native grid results; retained')
    results=[]
    for p,a in zip(prepared,answers,strict=True):
        if a['id']!=p['id'] or a['return_code']!='0x00000000' or not a['guards_intact'] or not a['pointers_unchanged']:
            raise ValueError('native grid refused or buffer limits changed; retained')
        stem=f'{p["id"]:04}';g=graph((out/(stem+'.cells.bin')).read_bytes(),(out/(stem+'.tokens.bin')).read_bytes(),a['metadata'])
        witnesses=[]
        for e in p['expected']:
            values={device:e[role] for device,role in p['sampled_value_bindings'].items()}
            actual=evaluate(g,values)
            if set(actual)!={p['target']}:raise ValueError('unexpected native coil set')
            witnesses.append(dict(left=e['left'],right=e['right'],expected=e['value'],native_grid=actual[p['target']],equal=actual[p['target']]==e['value']))
        row=dict(case=p['case'],comparison=p['comparison'],native=a,witnesses=witnesses,truth_table_exact=all(w['equal'] for w in witnesses),
            meaningful_cells=[n for n in g['nodes'].values() if n['kind'] not in (0,0x80)])
        results.append(row);print(json.dumps({k:v for k,v in row.items() if k!='meaningful_cells'}),flush=True)
    save(out/'comparison.json',results)


if __name__=='__main__':main()
