"""Recheck the saved original-cache point queries without native execution."""
from collections import Counter
from pathlib import Path
import json, sys

P = Path(__file__).resolve().parent
ROOT = P.parents[3]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'research'), str(P)]
from probe_minimal_conditional_port_writes import streams
from gxw.compiler_tables import parse_compiler_tables
from gxw.compiler_symbols import compiler_array_reference
from gxw.models import GXWFormatError


def main():
    previous = json.loads((P / 'real-array-reference-read-coverage-20261001.json').read_text(encoding='utf-8'))
    inventory = json.loads((P / 'current-real-source-gaps-20260930.json').read_text(encoding='utf-8'))
    tables = {}
    errors = []
    for name in sorted({r['file'] for r in inventory['programs']}):
        try:
            raw = streams((ROOT / name).read_bytes()).get('CGTable.dat')
            if raw is None:
                continue
            parsed = parse_compiler_tables(raw)
            assert parsed.reconstruct() == raw
            tables[name] = parsed
        except Exception as exc:
            errors.append(dict(file=name, error=str(exc)))
    rows = []
    for row in previous['rows']:
        current = {k: v for k, v in row.items() if k not in ('handling', 'reason', 'operand', 'iec_address')}
        try:
            ref = compiler_array_reference(tables[row['file']], row['component_offset'], tuple(row['indices']),
                member_offset=row['member_offset'], member_indices=tuple(row['member_indices']))
            current.update(handling='resolved', operand=ref.operand, iec_address=ref.iec_address)
            if row['handling'] == 'resolved':
                assert (row['operand'], row['iec_address']) == (ref.operand, ref.iec_address)
        except GXWFormatError as exc:
            current.update(handling='unsupported', reason=str(exc))
        except Exception as exc:
            current.update(handling='error', reason=str(exc))
            errors.append(dict(file=row['file'], component_offset=row['component_offset'], error=str(exc)))
        rows.append(current)
    result = dict(scope=__doc__, original_cache_projects=len(tables), raw_reconstructions=len(tables),
        counts=dict(Counter(r['handling'] for r in rows)), errors=errors, rows=rows)
    target = P / 'real-array-reference-read-string-after-20261001.json'
    assert not target.exists(), 'preserve the existing observation'
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: v for k, v in result.items() if k != 'rows'}))


if __name__ == '__main__':
    main()
