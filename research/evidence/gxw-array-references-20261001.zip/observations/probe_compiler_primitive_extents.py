"""Independent native type-extent queries; parameter guards, no hashes."""
from pathlib import Path
import json,os,subprocess
P=Path(__file__).resolve().parent

def main():
    out=P/'compiler-primitive-extents-20261001';out.mkdir(exist_ok=False)
    source=out/'CompilerPrimitiveExtentOracle.cs';source.write_bytes((P/source.name).read_bytes())
    exe=out/'CompilerPrimitiveExtentOracle.exe'
    prediction=[dict(type=t,parameter=n,expected_extent=n+1 if t==15 else {0:1,2:2,3:4,9:4,11:4,17:2,18:4,65:1,66:1,67:1,68:1}[t])
        for t in (0,2,3,9,11,15,17,18,65,66,67,68)
        for n in ((0,1,2,3,4,7,8,15,16,20,255,256,32767) if t==15 else (0,))]
    (out/'prediction-before-native.json').write_text(json.dumps(prediction,indent=2)+'\n',encoding='utf-8')
    build=subprocess.run([str(Path(os.environ['WINDIR'])/'Microsoft.NET/Framework/v4.0.30319/csc.exe'),'/nologo','/platform:x86','/out:'+str(exe),str(source)],capture_output=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
    (out/'build.txt').write_bytes(build.stdout+build.stderr);assert build.returncode==0
    r=subprocess.run([str(exe),'D:/GXWORKS2/Easysocket/Compiler/ECCompiler_IEC.dll',str(out/'outputs.jsonl')],capture_output=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
    (out/'stdout.bin').write_bytes(r.stdout);(out/'stderr.bin').write_bytes(r.stderr)
    (out/'process.json').write_text(json.dumps(dict(returncode=r.returncode),indent=2)+'\n',encoding='utf-8');assert r.returncode==0
    rows=[json.loads(s) for s in (out/'outputs.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    assert len(rows)==len(prediction)
    comparisons=[dict(p,actual=r['native_extent'],equal=(r['type'],r['parameter'],r['native_extent'])==(p['type'],p['parameter'],p['expected_extent'])) for p,r in zip(prediction,rows,strict=True)]
    (out/'comparison.json').write_text(json.dumps(comparisons,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(queries=len(rows),matches=sum(r['equal'] for r in comparisons),outputs=rows)),flush=True)

if __name__=='__main__':main()
