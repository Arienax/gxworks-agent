"""Read-only observations of the unmodified debug-range API on owned copies."""
import json
from pathlib import Path
import sys

sys.stdout.reconfigure(encoding='utf-8')
TRIAL = Path(__file__).resolve().parent
P = TRIAL.parent
sys.path.insert(0, str(P))
import probe_application_check_resources as trace

OUT = P / 'ghidra-debug-20261002-v1'
A = P / 'application-fbd-v2-20261002-v1'
EXTRA = r'''
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='dzdataabs_compiler_iec.dll')return;
 Interceptor.attach(m.base.add(0x652a),{
  onEnter(a){
   this.row={event:'native-debug-range-entry',module:m.name,rva:'0x652a',
    initialized:!a[0].add(12).readPointer().isNull(),
    location_present:!a[1].isNull(),resource:a[2].isNull()?null:a[2].readCString(256)};
   this.count=a[3];this.ranges=a[4];this.code=a[5];
  },
  onLeave(r){
   send({...this.row,hresult:r.toInt32(),code:this.code.isNull()?null:this.code.readU32(),
    count:this.count.isNull()?null:this.count.readS32(),
    ranges_present:this.ranges.isNull()?null:!this.ranges.readPointer().isNull()});
  }
 });
}});
'''


def main():
    OUT.mkdir(exist_ok=False)
    all_results = []
    for index, scope in enumerate(('full-FX3U-FX3UC', 'full-Q03UDV', 'full-L02')):
        frozen = A / scope / 'native-compile'
        raw = (frozen / 'input.gxw').read_bytes()
        for attempt in range(1,17):
            directory = OUT / f'c{index}-a{attempt}'
            observer = trace.prepare(directory, frozen) + EXTRA
            (directory / 'input.gxw').write_bytes(raw)
            (directory / 'observer.js').write_text(observer, encoding='utf-8')
            plan = json.loads((directory / 'plan.json').read_text(encoding='utf-8'))
            plan['pcode_range_queries'] = [dict(mode='debug', library='', pou=pou,
                resource=resource, program_kind=kind, network=network,
                start_step=line, step_count=1, element_id=-1)
                for pou,kind,network in [('MODULE_FB',193,-1),('FBD_MATRIX',208,1)]
                for resource in ('MAIN','') for line in (0,1,3)]
            trace.save(directory / 'plan.json', plan)
            returncode, messages = trace.run(directory, observer)
            result = trace.summarize(directory, returncode, messages)
            result.update(scope=scope,debug_observations=[r.get('payload',{}) for r in messages
                if r.get('payload',{}).get('event')=='native-debug-range-entry'])
            trace.save(directory / 'result.json',result)
            all_results.append(result)
            trace.save(OUT / 'results.json', all_results)
            print(json.dumps({'scope':scope,'attempt':attempt,'returncode':returncode,
                'debug_calls':len(result['debug_observations']),
                'codes':sorted(set(r['code'] for r in result['debug_observations']))}), flush=True)
            if returncode != 5:
                break


if __name__=='__main__':
    main()
