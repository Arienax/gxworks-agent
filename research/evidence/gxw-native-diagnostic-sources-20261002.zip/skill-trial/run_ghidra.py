from pathlib import Path
import json
import os
import subprocess
import sys

sys.stdout.reconfigure(encoding='utf-8')
TRIAL = Path(__file__).resolve().parent
DIRECTORY = TRIAL / 'ghidra-cli'
runtime = json.loads((DIRECTORY / 'runtime.json').read_text(encoding='utf-8'))
projects = Path('D:/gxworks-agent/research/experiments/re-tools/gtrial/projects')
projects.mkdir(parents=True, exist_ok=True)
config = DIRECTORY / 'config.yaml'
if not config.exists():
    config.write_text('\n'.join([
        'ghidra_install_dir: ' + json.dumps(runtime['ghidra']),
        'ghidra_project_dir: ' + json.dumps(str(projects)),
        'launch_timeout_secs: 180',
        'default_output_format: json-compact',
        'default_limit: 50',
        'aliases: {}',
    ]) + '\n', encoding='utf-8')
elif 'aliases:' not in config.read_text(encoding='utf-8'):
    with config.open('a', encoding='utf-8') as output:
        output.write('aliases: {}\n')
environment = dict(os.environ,
    GHIDRA_CLI_CONFIG=str(config),
    GHIDRA_INSTALL_DIR=runtime['ghidra'],
    GHIDRA_CLI_JAVA_HOME=runtime['java'],
    GHIDRA_PROJECT_DIR=str(projects),
    GHIDRA_CLI_DECOMPILE_TIMEOUT='120',
    GHIDRA_CLI_OP_TIMEOUT='600',
    GHIDRA_CLI_LAUNCH_TIMEOUT='180',
    GHIDRA_CLI_CONNECT_DEADLINE='120')
arguments = sys.argv[1:]
label = arguments.pop(0)
command = [str(DIRECTORY / 'bin/ghidra.exe'), '--projects-dir', str(projects), '--json', *arguments]
stdout_path = DIRECTORY / (label + '.stdout.bin')
stderr_path = DIRECTORY / (label + '.stderr.bin')
with stdout_path.open('wb') as stdout, stderr_path.open('wb') as stderr:
    result = subprocess.run(command, env=environment, stdout=stdout, stderr=stderr,
        creationflags=subprocess.CREATE_NO_WINDOW)
(DIRECTORY / (label + '.command.json')).write_text(json.dumps({'arguments': command, 'returncode': result.returncode}, indent=2), encoding='utf-8')
print(json.dumps({'label': label, 'returncode': result.returncode}), flush=True)
print(stdout_path.read_bytes().decode('utf-8', errors='replace')[:16000])
stderr = stderr_path.read_bytes()
if stderr:
    print(stderr.decode('utf-8', errors='replace')[-7000:])
sys.exit(result.returncode)
