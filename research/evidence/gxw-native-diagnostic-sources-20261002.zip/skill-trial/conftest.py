import json
import os
from pathlib import Path
import sys


def pytest_sessionfinish(session, exitstatus):
    module = sys.modules.get('test_fbd_properties')
    counts = getattr(module, 'COUNTS', {})
    directory = Path(__file__).resolve().parent
    label = os.environ.get('GXW_PBT_TRIAL_LABEL', 'unlabelled')
    (directory / (label + '-counts.json')).write_text(json.dumps({
        'status': int(exitstatus), 'hypothesis': __import__('hypothesis').__version__,
        'evaluations': counts}, indent=2), encoding='utf-8')
