"""Isolated skill trial: current project bytes are the source of every edit."""
from copy import deepcopy
from dataclasses import replace
import json
from pathlib import Path
import struct
import sys

TRIAL = Path(__file__).resolve().parent
ROOT = Path('D:/gxworks-agent')
sys.path[:0] = [str(TRIAL / 'python-deps'), str(ROOT / 'src')]
from hypothesis import example, given, settings, strategies as st
from gxw.container_writer import validate_cfb_streams
from gxw.editor import edit_draft
from gxw.models import UnknownRecord
from gxw.object_model import generate_object_project, read_project_context
from gxw.project_metadata import logical_mapping
from gxw.project_writer import build_gxw_project

BASELINE = (TRIAL.parent / 'application-fbd-v2-20261002-v1/full-FX3U-FX3UC/native-compile/input.gxw').read_bytes()
PROGRAM = 'FBD_MATRIX.Program.pou'
CALLER_LABELS = 'FBD_MATRIX.Labels.lh'
DEFINITION_LABELS = 'MODULE_FB.Labels.lh'
SETTINGS = settings(max_examples=100, deadline=None, database=None, derandomize=True)
COUNTS = {}
IDENTIFIER = st.text(alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ_0123456789', min_size=1, max_size=40).map(lambda suffix: 'P_' + suffix)


def payloads(raw):
    outer = validate_cfb_streams(raw)
    nested = validate_cfb_streams(outer['_hdb'])
    mapping = logical_mapping(outer['projectdatalist.xml'])
    return outer, {name: nested[key] for name, key in mapping.items() if key in nested}


def assert_unrelated_equal(before, after, allowed):
    old_outer, old_inner = payloads(before)
    new_outer, new_inner = payloads(after)
    assert old_inner.keys() == new_inner.keys()
    assert {k: v for k, v in old_inner.items() if k not in allowed} == {k: v for k, v in new_inner.items() if k not in allowed}
    assert {k: v for k, v in old_outer.items() if k not in {'_hdb', 'history.xml'}} == {k: v for k, v in new_outer.items() if k not in {'_hdb', 'history.xml'}}


def block(model):
    return next(node for node in model['nodes'] if node['template'] == 'function_block:MODULE_FB')


def edit(context, model, command):
    return edit_draft(model, command, context=context,
        templates=context.catalog(declaration_edits=model.get('declaration_edits')))['model']


def saved(context, model):
    output = generate_object_project(model, baseline=context.raw).data
    fresh = read_project_context(output, PROGRAM)
    assert fresh.object_model()['schema_version'] == 2
    assert generate_object_project(fresh.object_model(), baseline=output).data == output
    return fresh


def count(name):
    COUNTS[name] = COUNTS.get(name, 0) + 1


def save_failure(name, data):
    with (TRIAL / 'pbt-counterexamples.jsonl').open('a', encoding='utf-8') as output:
        output.write(json.dumps({'property': name, **data}) + '\n')


@SETTINGS
@given(names=st.lists(IDENTIFIER, min_size=1, max_size=4))
@example(names=['P_A', 'P_B', 'P_A'])
def test_rename_sequence_rebases_and_has_source_inverse(names):
    count('rename_sequence')
    initial = read_project_context(BASELINE, PROGRAM)
    original_symbol = block(initial.object_model())['symbol']
    context = initial
    for name in [*names, original_symbol]:
        model = context.object_model()
        target = block(model)
        before = deepcopy(model)
        draft = edit(context, model, {'action': 'update_node', 'id': target['id'], 'field': 'symbol', 'value': name})
        assert model == before
        context = saved(context, draft)
        assert block(context.object_model())['symbol'] == name
        instance = [r for r in context.declarations[CALLER_LABELS].rows if r.name == name]
        assert len(instance) == 1 and instance[0].type_reference == 'MODULE_FB'
        assert_unrelated_equal(initial.raw, context.raw, {PROGRAM, CALLER_LABELS})
    before_payloads = payloads(initial.raw)[1]
    after_payloads = payloads(context.raw)[1]
    assert before_payloads[PROGRAM] == after_payloads[PROGRAM]
    assert before_payloads[CALLER_LABELS] == after_payloads[CALLER_LABELS]


@SETTINGS
@given(name=IDENTIFIER, side=st.sampled_from(['in', 'out']), negated=st.booleans())
@example(name='P_A', side='in', negated=True)
def test_formal_rename_commutes_with_editing_its_negation(name, side, negated):
    count('formal_rename_negation')
    context = read_project_context(BASELINE, PROGRAM)
    original = context.object_model()
    target = block(original)
    rename = {'action': 'update_label', 'table': DEFINITION_LABELS, 'name': 'STATE', 'field': 'name', 'value': name}
    port_edit = {'action': 'update_port', 'id': target['id'], 'port': side + '.STATE', 'negated': negated}
    first = edit(context, original, port_edit)
    first = edit(context, first, rename)
    second = edit(context, original, rename)
    second = edit(context, second, {**port_edit, 'port': side + '.' + name})
    try:
        a, b = saved(context, first), saved(context, second)
    except Exception as error:
        save_failure('formal_rename_negation', {'name': name, 'side': side, 'negated': negated, 'error': str(error)})
        raise
    assert payloads(a.raw)[1] == payloads(b.raw)[1]
    after_ports = block(a.object_model())['ports']
    before_ports = target['ports']
    for before, after in zip(before_ports, after_ports):
        assert after['side'] == before['side']
        if before['formal_name'] == 'STATE':
            assert after['name'] == before['side'] + '.' + name
            assert after['formal_name'] == name and after['class_code'] == 5
        assert after['negated'] == (negated if before['name'] == side + '.STATE' else before['negated'])
    assert_unrelated_equal(context.raw, a.raw, {PROGRAM, DEFINITION_LABELS})


@SETTINGS
@given(payload=st.binary(min_size=0, max_size=80), record_class=st.integers(min_value=99, max_value=0xffff), x=st.integers(min_value=3, max_value=100))
@example(payload=b'', record_class=99, x=3)
@example(payload=b'\x00\xff\x00\x80', record_class=0xffff, x=100)
def test_opaque_source_bytes_survive_known_node_edits(payload, record_class, x):
    count('opaque_bytes')
    initial = read_project_context(BASELINE, PROGRAM)
    framed = struct.pack('<II', 8 + len(payload), record_class) + payload
    offset = max(r.offset for r in initial.program.iter_records()) + 1
    opaque = UnknownRecord(offset, len(framed), record_class, framed)
    injected = replace(initial.program, unknown_records=(*initial.program.unknown_records, opaque), record_count=initial.program.record_count + 1)
    source = build_gxw_project(initial.raw, injected).data
    context = read_project_context(source, PROGRAM)
    model = context.object_model()
    target = block(model)
    draft = edit(context, model, {'action': 'update_node', 'id': target['id'], 'field': 'x', 'value': x})
    fresh = saved(context, draft)
    actual_source = payloads(fresh.raw)[1][PROGRAM]
    assert framed in actual_source
    assert [r.raw for r in fresh.program.unknown_records] == [r.raw for r in context.program.unknown_records]
    assert block(fresh.object_model())['x'] == x
    assert_unrelated_equal(context.raw, fresh.raw, {PROGRAM})


def pytest_sessionfinish(session, exitstatus):
    (TRIAL / 'pbt-counts.json').write_text(json.dumps({'status': exitstatus, 'hypothesis': __import__('hypothesis').__version__, 'evaluations': COUNTS}, indent=2), encoding='utf-8')
