import json
import os
from pathlib import Path
import subprocess
import sys

sys.stdout.reconfigure(encoding='utf-8')
directory = Path(__file__).resolve().parent
label, *options = sys.argv[1:]
environment = dict(os.environ, PYTHONPATH=str(directory / 'python-deps') + ';D:/gxworks-agent/src', GXW_PBT_TRIAL_LABEL=label)
command = [sys.executable, '-m', 'pytest', str(directory / 'test_fbd_properties.py'),
    '--override-ini=addopts=', '-q', '--tb=short', '--hypothesis-show-statistics', *options]
stdout_path = directory / (label + '.stdout.txt')
stderr_path = directory / (label + '.stderr.txt')
with stdout_path.open('wb') as stdout, stderr_path.open('wb') as stderr:
    result = subprocess.run(command, env=environment, stdout=stdout, stderr=stderr,
        creationflags=subprocess.CREATE_NO_WINDOW)
(directory / (label + '.command.json')).write_text(json.dumps({'command': command, 'returncode': result.returncode}, indent=2), encoding='utf-8')
print(stdout_path.read_text(encoding='utf-8', errors='replace')[-15000:])
print(stderr_path.read_text(encoding='utf-8', errors='replace')[-3000:])
sys.exit(result.returncode)
