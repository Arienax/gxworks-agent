import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.listing.Function;

public class DisassembleOwnedDebug extends GhidraScript {
    @Override
    public void run() throws Exception {
        Address entry = toAddr("666f652a");
        // Entry comes from two native interface tables, not a guessed byte offset.
        boolean decoded = disassemble(entry);
        Function function = getFunctionAt(entry);
        if (function == null) function = createFunction(entry, "IEC_GetPCodeRangeForDebug");
        if (function == null) throw new IllegalStateException("No decoded method body");
        println("entry=" + entry + " decoded=" + decoded + " function=" + function.getName());
    }
}
