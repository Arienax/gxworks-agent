import ghidra.app.script.GhidraScript;
import ghidra.program.model.listing.Function;

public class AnnotateOwnedEH extends GhidraScript {
    @Override
    public void run() throws Exception {
        // The observed helper instructions match x86win.cspec EH_prolog.
        // This changes analysis metadata in the owned project, never DLL bytes.
        Function helper = getFunctionAt(toAddr("60ce77f0"));
        helper.setCallFixup("EH_prolog");
        println("helper=" + helper.getEntryPoint() + " callfixup=" + helper.getCallFixup());
    }
}
