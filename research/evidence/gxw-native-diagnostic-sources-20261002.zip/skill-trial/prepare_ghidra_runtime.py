from __future__ import annotations

import concurrent.futures
import json
from pathlib import Path
import sys
import urllib.request
import zipfile

sys.stdout.reconfigure(encoding='utf-8')
TRIAL = Path(__file__).resolve().parent
RUNTIME = Path('D:/gxworks-agent/research/experiments/re-tools/gtrial').resolve()
RUNTIME.mkdir(parents=True, exist_ok=True)


def fetch_json(url: str):
    req = urllib.request.Request(url, headers={'User-Agent': 'gxw-owned-skill-trial', 'Accept': 'application/json'})
    with urllib.request.urlopen(req, timeout=60) as response:
        return json.load(response)


def download(name: str, url: str, expected_size: int):
    target = RUNTIME / name
    if target.is_file() and target.stat().st_size == expected_size:
        print(json.dumps({'asset': name, 'status': 'existing', 'bytes': expected_size}), flush=True)
        return target
    partial = target.with_suffix(target.suffix + '.partial')
    print(json.dumps({'asset': name, 'status': 'downloading', 'bytes': expected_size}), flush=True)
    req = urllib.request.Request(url, headers={'User-Agent': 'gxw-owned-skill-trial'})
    with urllib.request.urlopen(req, timeout=60) as response, partial.open('wb') as output:
        while chunk := response.read(1024 * 1024):
            output.write(chunk)
    actual_size = partial.stat().st_size
    if actual_size != expected_size:
        raise ValueError(f'{name}: incomplete transfer {actual_size}/{expected_size}')
    partial.replace(target)
    print(json.dumps({'asset': name, 'status': 'downloaded', 'bytes': actual_size}), flush=True)
    return target


def extract(archive: Path, subdir: str):
    destination = (RUNTIME / subdir).resolve()
    destination.mkdir(exist_ok=True)
    with zipfile.ZipFile(archive) as source:
        for info in source.infolist():
            member = (destination / info.filename).resolve()
            if not member.is_relative_to(destination):
                raise ValueError(f'Archive path leaves owned runtime: {info.filename}')
        source.extractall(destination)
    roots = [p for p in destination.iterdir() if p.is_dir()]
    if len(roots) != 1:
        raise ValueError(f'Unexpected archive root layout: {destination}')
    print(json.dumps({'asset': archive.name, 'status': 'extracted', 'root': str(roots[0])}), flush=True)
    return roots[0]


ghidra = json.loads((TRIAL / 'ghidra-cli/ghidra-release.json').read_text(encoding='utf-8'))
ghidra_asset = next(a for a in ghidra['assets'] if a['name'].endswith('.zip') and '_PUBLIC_' in a['name'])
jdk = fetch_json('https://api.adoptium.net/v3/assets/latest/21/hotspot?architecture=x64&image_type=jdk&os=windows&vendor=eclipse')[0]
(TRIAL / 'ghidra-cli/jdk-release.json').write_text(json.dumps(jdk, indent=2), encoding='utf-8')
jdk_asset = jdk['binary']['package']
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    ghidra_future = pool.submit(download, ghidra_asset['name'], ghidra_asset['browser_download_url'], ghidra_asset['size'])
    jdk_future = pool.submit(download, jdk_asset['name'], jdk_asset['link'], jdk_asset['size'])
    ghidra_archive = ghidra_future.result()
    jdk_archive = jdk_future.result()
runtime = {'ghidra': str(extract(ghidra_archive, 'ghidra')), 'java': str(extract(jdk_archive, 'jdk'))}
(TRIAL / 'ghidra-cli/runtime.json').write_text(json.dumps(runtime, indent=2), encoding='utf-8')
print(json.dumps(runtime), flush=True)
