"""Cold replay; no native DLL, hooks or network."""
from pathlib import Path
import base64,collections,json,os,sys
p=Path(__file__).resolve().parent
os.environ['GXW2_INSTRUCTION_CATALOG']=str(p/'product/resources/instructions/mitsubishi')
sys.path.insert(0,str(p/'models'))
sys.path.insert(0,str(p/'product/src'))
from source_fx_modern_decoder import FXModernDecoder
from source_fx_machine import FXMachine
from source_fx3u_machine import FX3UMachine,FX3UCells
from source_fx_lossless_reader import FXLosslessReader
from source_fx_operand_rules import Unsupported
from gxw.token_pou import frame_token_pou,parse_token_pou
from gxw.models import GXWFormatError
def load(name):return json.loads((p/name).read_text(encoding='utf-8'))
decoders={cpu:FXModernDecoder(load('models/fx-modern-decoder-tables-20261001-v1.json'),cpu=cpu) for cpu in (520,521)}
emitters={521:FXMachine(),520:FX3UMachine(load('models/fx3u-machine-tables-before-native.json'),FX3UCells(load('models/fx3u-cell-tables-before-native.json')))}
counts=collections.Counter();gap_ids=set()
for r in load('decoder-witnesses.json'):
    raw=bytes.fromhex(r['machine']);at=0;records=[];gap=None
    while at<len(raw):
        try:record=decoders[r['cpu']].record(raw[at:])
        except Unsupported as exc:gap=str(exc);break
        n=record['words'] if record['words']>0 else 1
        record.update(offset=at,consumed_machine=raw[at:at+2*n].hex());records.append(record);at+=2*n
    prediction=dict(records=records,consumed=at,gap=gap)
    if prediction!=r['prediction']:raise ValueError('Prospective independent decoder snapshot differs')
    counts['decoder_groups']+=1
    if gap:counts['opaque_source_gaps']+=1;gap_ids.add(r['id'])
    elif len(records)!=len(r['native']) or r['public']['consumed']!=at:raise ValueError('Native decoder extent/count differs')
    else:counts['complete_decoder_groups']+=1
    if len(r['native'])<len(records):raise ValueError('Predicted native decoder call absent')
    for expected,native in zip(records,r['native']):
        if (expected['words'],expected['cells'],expected['auxiliary'])!=(native['words'],native['cells'],native['auxiliary']):raise ValueError('Native decoder fields differ')
        if (native['cpu'],native['mode'],native['before'],native['auxiliary_before'])!=(r['cpu'],8 if r['cpu']==520 else 9,'ff'*88,'00'*68):raise ValueError('Native decoder context differs')
        if expected['words']>0 and expected['consumed_machine']!=native['machine']:raise ValueError('Native machine span differs')
        counts['native_decoder_records_exact']+=1
    if not r['public']['guards_intact'] or not r['public']['input_unchanged']:raise ValueError('Owned native arena changed')
    counts['native_reverse_refusals']+=r['public']['code']!=0
changed=load('opaque-public-output-changes.json')
if {r['id'] for r in changed}!=gap_ids:raise ValueError('Opaque output changes were lost or normalized')
counts['opaque_public_output_changes']=len(changed)
reader=FXLosslessReader()
for r in load('reemission-witnesses.json'):
    raw=bytes.fromhex(r['raw']);ir=reader.read(raw,cpu=r['cpu'])
    if reader.reconstruct(ir)!=raw:raise ValueError('Canonical raw partition differs')
    records=[];machines=[]
    for record in ir['records']:
        if record['critical_gap']:raise ValueError('Canonical lexical gap')
        prediction=emitters[r['cpu']].record(bytes.fromhex(record['raw']))
        if prediction['emission']['words']<=0 or prediction['emission']['machine_output'] is None:raise ValueError('Canonical emission gap')
        records.append(dict(offset=record['offset'],prediction=prediction));machines.append(prediction['emission']['machine_output'])
    expected=dict(records=records,gaps=[],expected_machine=''.join(machines))
    if expected!=r['prediction']:raise ValueError('Prospective reemission snapshot differs')
    answer=r['public'];output=base64.b64decode(answer['output_base64']).hex()
    if answer['code']!=0 or output!=expected['expected_machine'] or answer['consumed']!=len(raw) or answer['remaining']!=0:raise ValueError('Public canonical reemission differs')
    if not answer['guards_intact'] or not answer['input_unchanged']:raise ValueError('Reemission native arena changed')
    if len(r['native'])!=len(records):raise ValueError('Reemission call count differs')
    for record,native in zip(records,r['native'],strict=True):
        prediction=record['prediction'];emission=prediction['emission']
        if (prediction['native_cells'],prediction['auxiliary'],emission['words'],emission['cells_after'],emission['machine_output'])!=(native['before'],native['auxiliary'],native['words'],native['after'],native['output']):raise ValueError('Native reemission fields differ')
        if (native['cpu'],native['mode'])!=(r['cpu'],8 if r['cpu']==520 else 9):raise ValueError('Reemission context differs')
        counts['native_reemission_records_exact']+=1
    counts['canonical_reemission_groups']+=1
    counts['canonical_machine_roundtrip_exact']+=output==r['original_machine']
    counts['canonical_native_machine_changes']+=output!=r['original_machine']
for r in load('opaque-trailer-witnesses.json'):
    raw=bytes.fromhex(r['synthetic_source']);frame=frame_token_pou(raw)
    if frame.body.hex()!=r['body'] or raw[frame.body_end:].hex()!=r['trailer'] or frame.reconstruct()!=raw:raise ValueError('Opaque source trailer differs')
    if len(bytes.fromhex(r['trailer']))==24 and parse_token_pou(raw).reconstruct()!=raw:raise ValueError('24-byte FX trailer differs')
    for extent in (19,21,23,25):
        try:frame_token_pou(raw[:frame.body_end]+bytes(extent))
        except GXWFormatError:pass
        else:raise ValueError('Unobserved trailer extent accepted')
    counts['opaque_trailer_witnesses']+=1
print(json.dumps(dict(counts),ensure_ascii=True))
