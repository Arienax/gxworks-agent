"""Source predictions and separate public P-to-M reemission of M-to-P outputs."""
import argparse
import base64
import collections
import json
import os
import subprocess
from probe_fx_operand_rules import DLL,P,save,traced_run
from probe_fx_modern_machine_decoder import load
from probe_fx1s_public_reemission import adapted_helper
from source_fx_machine import FXMachine
from source_fx3u_machine import FX3UMachine,FX3UCells
from source_fx_lossless_reader import FXLosslessReader
from source_fx_operand_rules import Unsupported


def source_rows():
    rows=[];omitted=[]
    for dataset in ('fx-modern-independent-machine-decoder-20261001-v2','fx-modern-independent-machine-holdouts-20261001-v2'):
        path=P/dataset;originals=load(path/'before-native.json')['requests'];predictions=load(path/'predictions-before-native.json')
        for result in load(path/'observations.json'):
            row=originals[result['id']]
            if predictions[str(row['id'])]['gap'] or result['public']['code']!=0:
                omitted.append(dict(dataset=dataset,origin_id=row['id'],cpu=row['cpu'],
                                    source_gap=predictions[str(row['id'])]['gap'],native_reverse_code=result['public']['code']))
                continue
            raw=base64.b64decode(result['public']['output_base64']).hex()
            rows.append(dict(id=len(rows),origin_id=row['id'],dataset=dataset,cpu=row['cpu'],case=row['case'],
                             raw=raw,original_machine=row['machine'],original_pcode=row['original_pcode'],
                             original_case='machine_group' not in row))
    return rows,omitted


def models():
    original=P/'fx3u-original-machine-corpus-20261001-v1'
    return {521:FXMachine(),520:FX3UMachine(load(original/'fx3u-machine-tables-before-native.json'),
                                         FX3UCells(load(original/'fx3u-cell-tables-before-native.json')))}


def source_prediction(reader,model,raw,cpu):
    ir=reader.read(raw,cpu=cpu)
    if reader.reconstruct(ir)!=raw:raise ValueError('Canonical PCode raw partition differs')
    records=[];gaps=[];output=[]
    for record in ir['records']:
        try:
            if record['critical_gap']:raise Unsupported('Canonical lexical gap: '+record['handling'])
            p=model.record(bytes.fromhex(record['raw']))
            records.append(dict(offset=record['offset'],prediction=p))
            if p['emission']['words']<=0 or p['emission']['machine_output'] is None:
                raise Unsupported('Canonical native emission not available: '+p['emission']['handling'])
            output.append(p['emission']['machine_output'])
        except Unsupported as exc:gaps.append(dict(offset=record['offset'],reason=str(exc)))
    return dict(records=records,gaps=gaps,expected_machine=None if gaps else ''.join(output))


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--attempt',type=int,required=True);args=parser.parse_args()
    out=P/f'fx-modern-public-machine-roundtrips-20261001-v{args.attempt}';out.mkdir()
    rows,omitted=source_rows();emitters=models();reader=FXLosslessReader()
    predictions={str(r['id']):source_prediction(reader,emitters[r['cpu']],bytes.fromhex(r['raw']),r['cpu']) for r in rows}
    save(out/'before-native.json',dict(converter='15.31',requests=rows,
        scope='Canonical PCode from independent public modern M-to-P calls. Reverse refusals and opaque/uninitialized reader branches omitted and retained separately.'))
    save(out/'predictions-before-native.json',predictions);save(out/'omitted-reverse-refusals-and-opaque.json',omitted)
    for name in ('probe_fx_modern_machine_roundtrips.py','source_fx_machine.py','source_fx3u_machine.py','source_fx_instruction_cells.py',
                 'source_fx_operand_rules.py','source_fx_lossless_reader.py'):
        (out/name).write_bytes((P/name).read_bytes())
    source=adapted_helper()
    changes=[('FX1SToMachineOracle','FXModernToMachineOracle'),('fields.Length!=2','fields.Length!=3'),
             ('Convert.FromBase64String(fields[1])','Convert.FromBase64String(fields[2])'),('open(h,518,0)','open(h,int.Parse(fields[1]),0)')]
    for old,new in changes:
        if source.count(old)!=1:raise ValueError('Owned reemission helper adaptation differs')
        source=source.replace(old,new)
    source=source.replace('int id=int.Parse(fields[0]);','if(fields[1]!="520"&&fields[1]!="521")throw new Exception("Unmeasured CPU");int id=int.Parse(fields[0]);')
    source=source.replace('fresh CPU518 context','fresh explicit CPU520/521 context')
    (out/'FXModernToMachineOracle.cs').write_text(source,encoding='utf-8')
    exe=out/'FXModernToMachineOracle.exe'
    build=subprocess.run([os.path.join(os.environ['WINDIR'],'Microsoft.NET/Framework/v4.0.30319/csc.exe'),'/nologo','/platform:x86',
        '/out:'+str(exe),str(out/'FXModernToMachineOracle.cs')],capture_output=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
    (out/'build.txt').write_bytes(build.stdout+build.stderr)
    if build.returncode:raise RuntimeError('Owned modern reemission build failed')
    for r in rows:
        if not 2<=len(bytes.fromhex(r['raw']))<=512:raise ValueError('Canonical PCode outside bounded public fragment envelope')
    (out/'requests.tsv').write_text('\n'.join(f'{r["id"]}\t{r["cpu"]}\t'+base64.b64encode(bytes.fromhex(r['raw'])).decode() for r in rows)+'\n',encoding='ascii')
    command=[str(exe),str(DLL),str(out/'requests.tsv'),str(out/'baseline.jsonl')]
    baseline=subprocess.run(command,capture_output=True,timeout=55,creationflags=subprocess.CREATE_NO_WINDOW)
    (out/'baseline-stdout.bin').write_bytes(baseline.stdout);(out/'baseline-stderr.bin').write_bytes(baseline.stderr)
    save(out/'baseline-process.json',dict(returncode=baseline.returncode))
    if baseline.returncode:raise RuntimeError('Owned modern public reemission failed; partial outputs retained')
    observer=(P/'fx1s-public-machine-reemission-20261001-v2/TraceFXPublicReemission.js').read_text(encoding='utf-8')
    (out/'TraceFXPublicReemission.js').write_text(observer,encoding='utf-8')
    traced_run(command[:-1]+[str(out/'traced.jsonl')],observer,out)
    events=collections.defaultdict(list);errors=[]
    for line in (out/'events.jsonl').read_text(encoding='utf-8').splitlines():
        packet=json.loads(line)
        if packet['type']!='send':errors.append(packet)
        else:
            e=packet['payload'];events[e['request']].append(e)
    answers=[json.loads(s) for s in (out/'baseline.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    traced_answers=[json.loads(s) for s in (out/'traced.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    counts=collections.Counter();differences=[];roundtrip_changes=[];original_differences=[];observations=[];public_changes=[]
    for row,answer,traced in zip(rows,answers,traced_answers,strict=True):
        if row['id']!=answer['id'] or row['id']!=traced['id']:raise ValueError('Public modern reemission identity differs')
        prefix='original' if row['original_case'] else 'synthetic'
        prediction=predictions[str(row['id'])];output=base64.b64decode(answer['output_base64']).hex()
        counts[prefix+'_requests']+=1;counts[prefix+'_public_accepted']+=answer['code']==0
        same={}
        if prediction['expected_machine'] is not None:
            same['machine_bytes']=answer['code']==0 and output==prediction['expected_machine']
            same['public_consumed']=answer['consumed']==len(bytes.fromhex(row['raw'])) and answer['remaining']==0
            counts[prefix+'_source_predictions']+=1
            counts[prefix+'_source_machine_exact']+=same['machine_bytes']
            calls=[e for e in events[row['id']] if e['event']=='machine-emission']
            same['call_count']=len(calls)==len(prediction['records'])
            for p,e in zip(prediction['records'],calls):
                p=p['prediction'];m=p['emission']
                fields=dict(cells=p['native_cells']==e['before'],auxiliary=p['auxiliary']==e['auxiliary'],
                            words=m['words']==e['words'],cells_after=m['cells_after']==e['after'],machine=m['machine_output']==e['output'],
                            context=e['cpu']==row['cpu'] and e['mode']==(8 if row['cpu']==520 else 9))
                counts[prefix+'_native_emission_records']+=1
                for key,value in fields.items():counts[prefix+'_'+key+'_exact']+=value
                if not all(fields.values()):same['native_fields']=False
        else:
            counts[prefix+'_source_gaps']+=1
        roundtrip=answer['code']==0 and output==row['original_machine']
        counts[prefix+'_native_machine_roundtrip_exact']+=roundtrip
        result=dict(source=row,prediction=prediction,public=answer,matches=same,native_machine_roundtrip_exact=roundtrip)
        observations.append(result)
        if not all(same.values()):differences.append(result)
        if not roundtrip:roundtrip_changes.append(result)
        if row['original_case'] and (not roundtrip or not all(same.values())):original_differences.append(result)
        if answer!=traced:public_changes.append(dict(source=row,baseline=answer,traced=traced))
    save(out/'observations.json',observations);save(out/'source-native-differences.json',differences)
    save(out/'native-roundtrip-differences.json',roundtrip_changes);save(out/'original-differences.json',original_differences)
    save(out/'baseline-traced-differences.json',public_changes)
    summary=dict(requests=len(rows),omitted_reverse_refusals_or_opaque=len(omitted),counts=dict(counts),
        source_native_differences=len(differences),native_roundtrip_differences=len(roundtrip_changes),original_differences=len(original_differences),
        public_codes=dict(collections.Counter(a['code'] for a in answers)),guards_intact=all(a['guards_intact'] for a in answers),
        input_unchanged=all(a['input_unchanged'] for a in answers),baseline_traced_exact=not public_changes,hook_errors=errors,
        scope='Independent reverse conversion followed by separate public forward conversion; byte identity, source prediction, native refusal and opaque exclusions are distinct. Not address/project validity or controller execution.')
    save(out/'comparison.json',summary);print(json.dumps(summary,ensure_ascii=True),flush=True)
    if original_differences or errors or public_changes:raise ValueError('Original/native observer differences retained')


if __name__=='__main__':main()
