"""Recompile native-saved source with a nonzero, explicitly opaque footer."""
import argparse
import json
import struct
from probe_fx_operand_rules import P,save
from probe_fx1s_lossless_project_patch import native_run
from gxw.container import CompoundFile
from gxw.container_writer import replace_stream_within_allocation
from gxw.project_resolver import GXWProjectResolver
from gxw.token_pou import parse_token_fragment


def source_parts(path):
    resolver=GXWProjectResolver(CompoundFile(path.read_bytes()))
    raw=resolver.read_logical_file('MAIN.Program.pou')
    if raw[54]!=1 or raw[63:79]!=bytes.fromhex('010000000c00000000000000ffffffff'):
        raise ValueError('Saved source prefix outside inspected context')
    a,b=struct.unpack_from('<II',raw,55)
    if a!=b or a<20:raise ValueError('Saved source sizes disagree')
    body_length=a-20;end=79+body_length
    if end>len(raw):raise ValueError('Saved source body exceeds stream')
    framed=parse_token_fragment(raw,79,body_length)
    if framed.reconstruct()!=raw:raise ValueError('Opaque tail reconstruction differs')
    return dict(raw=raw.hex(),source_bytes=len(raw),body=framed.body.hex(),body_bytes=body_length,
                footer=raw[end:].hex(),footer_bytes=len(raw)-end,footer_nonzero=any(raw[end:]),
                handling='framed-body/opaque-native-source-footer',
                scope='Length-bound raw tokens only. Footer content is preserved without assigning pointer, padding or runtime semantics.')


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--footer-bytes',type=int,choices=(20,24),default=24);args=parser.parse_args()
    name='fx3u-native-source-footer' if args.footer_bytes==24 else 'fx3u-short-source-footer'
    out=P/(name+'-20261001-v1');out.mkdir()
    (out/'probe_fx3u_saved_source_footer.py').write_bytes((P/'probe_fx3u_saved_source_footer.py').read_bytes())
    initial=P/'fx3u-gxw-native-patches-20261001-v1/case-04/candidate/native-saved.gxw'
    if args.footer_bytes==20:
        original=initial.read_bytes();resolver=GXWProjectResolver(CompoundFile(original))
        binding=[f.stream_name for f in resolver.logical_files() if f.logical_name=='MAIN.Program.pou']
        if len(binding)!=1:raise ValueError('Original saved source binding differs')
        stream=binding[0];source=resolver.hdb.read_stream(stream)
        if source[-4:]!=bytes(4):raise ValueError('Only the observed final four zero bytes may be omitted')
        inner=replace_stream_within_allocation(resolver.outer.read_stream('_hdb'),stream,source[:-4],allow_shrink=True)
        proposed=replace_stream_within_allocation(original,'_hdb',inner)
        after=GXWProjectResolver(CompoundFile(proposed))
        untouched_inner=[f.name for f in resolver.hdb.iter_streams() if f.name!=stream]
        untouched_outer=[f.name for f in resolver.outer.iter_streams() if f.name!='_hdb']
        if any(resolver.hdb.read_stream(n)!=after.hdb.read_stream(n) for n in untouched_inner):raise ValueError('Unrelated inner stream changed')
        if any(resolver.outer.read_stream(n)!=after.outer.read_stream(n) for n in untouched_outer):raise ValueError('Unrelated outer stream changed')
        initial=out/'input.gxw';initial.write_bytes(proposed)
        save(out/'footer-length-proposal-before-native.json',dict(stream=stream,original_source_bytes=len(source),
            new_source_bytes=len(source)-4,physical_changed_offsets=[i for i,(a,b) in enumerate(zip(original,proposed,strict=True)) if a!=b],
            untouched_inner_streams=len(untouched_inner),untouched_outer_streams=len(untouched_outer),
            untouched_stream_payloads_exact=True,scope='Observed legacy 20-byte footer form, all nonzero native footer bytes retained; original final four zero bytes removed from logical stream extent only.'))
    expected=(P/'fx3u-gxw-patch-20261001-v3/case-04/expected-pcode.bin').read_bytes()
    before=source_parts(initial)
    if bytes.fromhex(before['body'])!=expected or not before['footer_nonzero']:
        raise ValueError('Retained counterexample differs from declared source body/footer')
    save(out/'before-native.json',dict(input_file=str(initial),source=before,expected_pcode=expected.hex(),
        scope='Fresh compile, all-options current-code check, save and separate fresh reopen; source not modified. No digest verification.'))
    plan=json.loads((P/'additional-native-baselines/case-04/native-1/plan.json').read_text(encoding='utf-8'))
    compile_dir=out/'compile';compiled=native_run(initial,compile_dir,plan,compile=True,export=True,alias='FX3UTAIL')
    pcode=compile_dir/'pcode-0-0.bin'
    result=dict(compile=compiled,pcode_exact=pcode.exists() and pcode.read_bytes()==expected)
    saved=compile_dir/'native-saved.gxw'
    if saved.exists():
        after=source_parts(saved)
        result['resaved_source']=after
        result['resaved_body_exact']=bytes.fromhex(after['body'])==expected
        result['footer_byte_identical']=before['footer']==after['footer']
        result['reopen']=native_run(saved,out/'reopen',plan,compile=False,export=False,check=False,alias='FX3UTAIL')
    save(out/'comparison.json',result)
    print(json.dumps({k:v for k,v in result.items() if k!='resaved_source'} | dict(resaved_source={k:v for k,v in result.get('resaved_source',{}).items() if k not in ('raw','body','footer')}),ensure_ascii=True),flush=True)
    if not result['pcode_exact'] or compiled['compiler_rejected'] or not compiled['exported']:
        raise ValueError('Saved source compile differs; retained')


if __name__=='__main__':main()
