"""Re-read retained native saves after correcting opaque footer recognition.

The earlier measurements, including the reader's false negative, are unchanged.
This audit makes no native calls and uses direct byte comparisons.
"""
from pathlib import Path
import json
import sys

P = Path(__file__).resolve().parent
ROOT = P.parents[3]
sys.path.insert(0, str(ROOT / 'src'))
from gxw.container import CompoundFile
from gxw.project_resolver import GXWProjectResolver
from gxw.token_pou import frame_token_pou, parse_token_pou
from gxw.lossless import inspect_program


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=True, indent=2) + '\n', encoding='utf-8')


def main():
    prior = P / 'fx3u-gxw-native-patches-20261001-v1'
    proposals = P / 'fx3u-gxw-patch-20261001-v3'
    out = P / 'fx3u-saved-source-reaudit-20261001-v1'
    out.mkdir()
    (out / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    (out / 'token_pou.py').write_bytes((ROOT / 'src/gxw/token_pou.py').read_bytes())
    rows = []
    for measured in read(prior / 'comparison.json'):
        case = measured['case']
        stage = 'candidate' if (prior / case / 'candidate/native-saved.gxw').exists() else 'save'
        path = prior / case / stage / 'native-saved.gxw'
        expected = (proposals / case / 'expected-pcode.bin').read_bytes()
        resolver = GXWProjectResolver(CompoundFile(path.read_bytes()))
        matches = []
        for file in resolver.logical_files():
            if not file.logical_name.lower().endswith('.pou'):
                continue
            raw = resolver.hdb.read_stream(file.stream_name)
            frame = frame_token_pou(raw)
            if frame.body != expected:
                continue
            image = inspect_program(raw, token_profile=None)
            if frame.reconstruct() != raw or image.reconstruct() != raw:
                raise ValueError('Saved source reconstruction differs')
            if parse_token_pou(raw).body != expected:
                raise ValueError('24-byte FX source body differs')
            if image.regions[-1].raw != raw[frame.body_end:] or image.regions[-1].handling != 'opaque-preserved':
                raise ValueError('Native footer lost opaque preservation')
            matches.append(dict(logical=file.logical_name, stream=file.stream_name,
                source_bytes=len(raw), body_bytes=len(frame.body), footer_bytes=len(raw)-frame.body_end,
                footer_hex=raw[frame.body_end:].hex(), footer_nonzero=any(raw[frame.body_end:]),
                body_exact=True, reconstruct_exact=True, footer_handling='opaque-preserved'))
        if len(matches) != 1:
            raise ValueError('Saved source does not bind uniquely: ' + case)
        for kind, original_name in (('original', 'original.gxw'), ('candidate', 'candidate.gxw')):
            observation = measured[kind]
            if not observation['pcode_exact'] or not observation['cpu_context_exact'] or not observation['native_process_completed']:
                raise ValueError('Earlier native measurement failed: ' + case + '/' + kind)
            if (prior / case / ('control' if kind == 'original' else 'candidate') / 'input.gxw').read_bytes() != (proposals / case / original_name).read_bytes():
                raise ValueError('Retained native input differs from original proposal')
        reopen = measured['reopen']['outcome']
        if reopen['attempts'][-1]['returncode'] != 0 or reopen['failures'] or not reopen['input_copy_unchanged']:
            raise ValueError('Earlier fresh reopen failed: ' + case)
        if not measured['program_check_diagnostics_unchanged']:
            raise ValueError('Original and candidate diagnostics differ')
        rows.append(dict(case=case, saved_stage=stage, source=matches[0],
            earlier_reader_body_exact=measured['saved_source']['exact'],
            original_full_check_accepted=not measured['original']['outcome']['program_check'][0]['rejected'],
            candidate_full_check_accepted=not measured['candidate']['outcome']['program_check'][0]['rejected'],
            error_diagnostics_unchanged=True, fresh_reopen_completed=True,
            saved_file=str(path), expected_body_file=str(proposals / case / 'expected-pcode.bin')))
    result = dict(projects=len(rows), saved_source_body_exact=len(rows),
        full_check_accepted=sum(r['candidate_full_check_accepted'] for r in rows),
        original_check_failures_retained=sum(not r['candidate_full_check_accepted'] for r in rows),
        corrected_reader_false_negatives=sum(not r['earlier_reader_body_exact'] for r in rows),
        nonzero_footers=sum(r['source']['footer_nonzero'] for r in rows), cases=rows,
        scope='Re-reading the retained saves with corrected framing; no additional native run, no PLC execution, no digest validation. Earlier native logs and false-negative reader result remain unchanged.')
    save(out / 'comparison.json', result)
    print(json.dumps({k: v for k, v in result.items() if k != 'cases'}, ensure_ascii=True))


if __name__ == '__main__':
    main()
