let request=-1;
function hex(p,n){return Array.from(new Uint8Array(p.readByteArray(n))).map(x=>x.toString(16).padStart(2,'0')).join('');}
Process.attachModuleObserver({onAdded(module){
    if(module.name.toLowerCase()!=='eccodegeneratorfx2.dll')return;
    const base=module.base;
    Interceptor.attach(module.findExportByName('ChangeMToPcode'),{
        onEnter(args){request++;send({event:'public-enter',request});},
        onLeave(ret){send({event:'public-leave',request,code:ret.toInt32()});}
    });
    Interceptor.attach(base.add(0x2ff7c),{
        onEnter(args){
            this.cells=args[0];this.aux=args[1];this.input=args[2];
            this.row={event:'modern-machine-decoder',request,cpu:base.add(0x928a8).readU16(),mode:args[3].toInt32(),before:hex(this.cells,88),auxiliary_before:hex(this.aux,68),first_word:this.input.readU16()};
        },
        onLeave(ret){
            this.row.words=(ret.toInt32()<<16)>>16;
            if(this.row.words>256)throw new Error('Decoder extent exceeds owned temporary witness envelope');
            this.row.machine=this.row.words>0?hex(this.input,this.row.words*2):'';
            this.row.cells=hex(this.cells,88);this.row.auxiliary=hex(this.aux,68);send(this.row);
        }
    });
}});
