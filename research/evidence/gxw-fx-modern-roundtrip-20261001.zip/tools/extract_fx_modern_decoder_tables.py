"""Independently extract modern decoder header/arity tables from static bytes."""
from pathlib import Path
import json
import struct
import sys

ROOT = Path(__file__).resolve().parents[4]
P = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'research/experiments/re-tools'))
import capstone
import pefile


def main():
    pe = pefile.PE('D:/GXWORKS2/Easysocket/CodeGenerator/ECCodeGeneratorFX2.dll')
    versions = [t.entries.get(b'FileVersion') for f in pe.FileInfo for block in f
                if block.Key == b'StringFileInfo' for t in block.StringTable]
    if b'15.31' not in versions or pe.OPTIONAL_HEADER.ImageBase != 0x10000000:
        raise ValueError('Uninspected modern decoder binary context')
    headers = []
    for i in range(200):
        raw = pe.get_data(0x7d710 + 10 * i, 10)
        flags, kind, words, reserved, operands, opcode = struct.unpack('<BB4H', raw)
        if kind == 255:
            sentinel = dict(index=i, raw=raw.hex())
            break
        headers.append(dict(index=i, flags=flags, kind=kind, words=words,
                            reserved=reserved, operands=operands, opcode=opcode, raw=raw.hex()))
    else:
        raise ValueError('Decoder header sentinel absent in inspected extent')
    dis = capstone.Cs(capstone.CS_ARCH_X86, capstone.CS_MODE_32)
    dis.detail = True
    addresses = []
    for ins in dis.disasm(pe.get_data(0x365f0, 0x3665a - 0x365f0), 0x365f0):
        if ins.mnemonic == 'mov' and len(ins.operands) == 2:
            a, b = ins.operands
            if a.type == capstone.CS_OP_MEM and a.size == 2 and b.type == capstone.CS_OP_IMM:
                if ins.reg_name(a.mem.base) != 'ebp':
                    raise ValueError('Index literal storage context differs')
                addresses.append(b.imm)
    if len(addresses) != 16:
        raise ValueError('Independent reverse-index literal extent differs')
    result = dict(file_version='15.31', measured_contexts=[dict(cpu=520, mode=8), dict(cpu=521, mode=9)],
                  origin='360c7 header; 36edb basic references; 366c8/36ad7 word/double; 370e2 independent reader; no emitter or PCode lowering imports',
                  header_rva=0x7d710, headers=headers, header_sentinel=sentinel,
                  application_arity_rva=0x7da19,
                  application_arities=[pe.get_data(0x7da19 + 2 * i, 1)[0] for i in range(310)],
                  index_addresses=dict(V=addresses[:8], Z=addresses[8:]))
    target = P / 'fx-modern-decoder-tables-20261001-v1.json'
    content = json.dumps(result, ensure_ascii=True, indent=2) + '\n'
    if target.exists():
        raise FileExistsError('Static table extraction already retained')
    target.write_text(content, encoding='utf-8')
    print(json.dumps(dict(headers=len(headers), sentinel=sentinel, applications=len(result['application_arities']),
                          header_shapes=[{k:r[k] for k in ('flags','kind','words','operands','opcode')} for r in headers[:18]],
                          index_addresses=result['index_addresses']), ensure_ascii=True))


if __name__ == '__main__':
    main()
