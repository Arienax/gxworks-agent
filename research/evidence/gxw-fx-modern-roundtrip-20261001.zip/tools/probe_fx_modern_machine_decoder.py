"""Prospective independent modern-machine observations on retained projects."""
import argparse
import base64
import collections
import json
import os
from pathlib import Path
import subprocess
import traceback
from probe_fx_operand_rules import DLL, P, save, traced_run
from source_fx_modern_decoder import FXModernDecoder
from source_fx_operand_rules import Unsupported


def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def project_rows():
    rows=[]
    full=P/'fx-machine-step-emission-full-corpus-20261001-v1'
    for r in load(full/'machine-width-comparison.json'):
        rows.append(dict(id=len(rows),source=full.name,original_id=r['id'],case='accepted-fx3g-full',cpu=521,mode=9,
                         machine=r['machine_output'],original_pcode=r['raw']))
    prior=P/'fx3u-original-machine-corpus-20261001-v1'
    originals=load(prior/'before-native.json')['requests']
    observations=load(prior/'observations.json')
    for source,actual in zip(originals,observations,strict=True):
        if source['id']!=actual['id']:raise ValueError('Original machine witness identity differs')
        rows.append(dict(id=len(rows),source=prior.name,original_id=source['id'],case=source['case'],offset=source['offset'],cpu=520,mode=8,
                         machine=actual['native']['output'],original_pcode=source['raw']))
    return rows


def synthetic_rows():
    groups=collections.defaultdict(list)
    for witness in load(P/'fx-machine-grammar-frozen-20261001/native-witnesses.json'):
        if len(witness['native_emissions'])!=1:continue
        native=witness['native_emissions'][0]
        if native['words']<=0:continue
        cells=bytes.fromhex(native['before'])
        # The preceding checkpoint retains this undefined-output label witness;
        # its uninitialized emission is not used as a grammar input.
        if cells[2]==0 and cells[3]==255:continue
        raw=native['output']
        if len(bytes.fromhex(raw))!=2*native['words']:raise ValueError('Retained synthetic emission extent differs')
        groups[raw].append(dict(dataset=witness['dataset'],id=witness['request'],raw=witness['raw'],
                               category=witness['category'],public_output=witness['public']['output']))
    rows=[]
    for group,(machine,origins) in enumerate(groups.items()):
        for cpu,mode in ((521,9),(520,8)):
            rows.append(dict(id=len(rows),machine_group=group,source='frozen-own-mode9-synthetic-emissions',
                             case=f'synthetic-{group}',cpu=cpu,mode=mode,machine=machine,
                             original_pcode=origins[0]['public_output'],origins=origins,
                             scope='Mode-9 emitter provenance; separately measured mode-8/9 decoder context, no mode-8 emitter assertion'))
    return rows


def predict_stream(model, raw):
    at=0;records=[];gap=None
    while at<len(raw):
        try:r=model.record(raw[at:])
        except Unsupported as exc:gap=str(exc);break
        n=r['words'] if r['words']>0 else 1
        r['offset']=at;r['consumed_machine']=raw[at:at+2*n].hex()
        records.append(r);at+=2*n
    return dict(records=records,consumed=at,gap=gap)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--attempt',type=int,required=True)
    parser.add_argument('--corpus',choices=('original','synthetic'),default='original')
    args=parser.parse_args()
    stem='fx-modern-independent-machine-decoder' if args.corpus=='original' else 'fx-modern-independent-machine-holdouts'
    out=P/f'{stem}-20261001-v{args.attempt}'
    out.mkdir(exist_ok=True)
    if any(out.iterdir()):raise FileExistsError('Earlier decoder experiment must be retained')
    tables=load(P/'fx-modern-decoder-tables-20261001-v1.json')
    models={cpu:FXModernDecoder(tables,cpu=cpu) for cpu in (520,521)}
    rows=project_rows() if args.corpus=='original' else synthetic_rows()
    predictions={};gaps=[]
    for row in rows:
        raw=bytes.fromhex(row['machine'])
        if not 0<len(raw)<=512 or len(raw)%2:raise ValueError('Original emission outside bounded fragment envelope')
        try:
            predictions[str(row['id'])]=predict_stream(models[row['cpu']],raw)
        except Exception as exc:
            save(out/'harness-failure.json',dict(stage='source prediction before any native call',source=row,
                exception=type(exc).__name__,reason=str(exc),traceback=traceback.format_exc()))
            (out/'source_fx_modern_decoder.py').write_bytes((P/'source_fx_modern_decoder.py').read_bytes())
            (out/'probe_fx_modern_machine_decoder.py').write_bytes(Path(__file__).read_bytes())
            raise
        if predictions[str(row['id'])]['gap']:
            gaps.append(dict(id=row['id'],case=row['case'],cpu=row['cpu'],reason=predictions[str(row['id'])]['gap']))
    save(out/'before-native.json',dict(converter='15.31',corpus=args.corpus,requests=rows,
        scope='Separately inspected modern machine reader; retained project or own synthetic emissions as explicitly attributed per request, predictions saved before fresh M-to-P calls'))
    save(out/'predictions-before-native.json',predictions);save(out/'source-gaps.json',gaps)
    for name in ('source_fx_modern_decoder.py','extract_fx_modern_decoder_tables.py','fx-modern-decoder-tables-20261001-v1.json','probe_fx_modern_machine_decoder.py'):
        (out/name).write_bytes((P/name).read_bytes())
    cs=(P/'FX1SFromMachineOracle.cs').read_text(encoding='utf-8')
    replacements=[('FX1SFromMachineOracle','FXModernFromMachineOracle'),('fields.Length!=2','fields.Length!=3'),
                  ('Convert.FromBase64String(fields[1])','Convert.FromBase64String(fields[2])'),
                  ('open(h,518,0)','open(h,int.Parse(fields[1]),0)')]
    for old,new in replacements:
        if cs.count(old)!=1:raise ValueError('Owned public helper adaptation site differs')
        cs=cs.replace(old,new)
    cs=cs.replace('int id=int.Parse(fields[0]);',
                  'if(fields[1]!="520" && fields[1]!="521")throw new Exception("Unmeasured CPU");int id=int.Parse(fields[0]);')
    cs=cs.replace('FX dispatcher328FD routes518 to mode5','FX dispatcher328FD routes520/521 to modes8/9')
    (out/'FXModernFromMachineOracle.cs').write_text(cs,encoding='utf-8')
    trace=(P/'TraceFXOldDecoder.js').read_text(encoding='utf-8')
    trace=trace.replace("module.getExportByName('ChangeMToPcode')","module.findExportByName('ChangeMToPcode')")
    trace=trace.replace("event:'old-machine-decoder'","event:'modern-machine-decoder'")
    (out/'TraceFXModernDecoder.js').write_text(trace,encoding='utf-8')
    exe=out/'FXModernFromMachineOracle.exe'
    build=subprocess.run([os.path.join(os.environ['WINDIR'],'Microsoft.NET/Framework/v4.0.30319/csc.exe'),'/nologo','/platform:x86',
        '/out:'+str(exe),str(out/'FXModernFromMachineOracle.cs')],capture_output=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
    (out/'build.txt').write_bytes(build.stdout+build.stderr)
    if build.returncode:raise RuntimeError('Owned modern reader build failed')
    (out/'requests.tsv').write_text('\n'.join(f'{r["id"]}\t{r["cpu"]}\t'+base64.b64encode(bytes.fromhex(r['machine'])).decode() for r in rows)+'\n',encoding='ascii')
    command=[str(exe),str(DLL),str(out/'requests.tsv'),str(out/'baseline.jsonl')]
    baseline=subprocess.run(command,capture_output=True,timeout=55,creationflags=subprocess.CREATE_NO_WINDOW)
    (out/'baseline-stdout.bin').write_bytes(baseline.stdout);(out/'baseline-stderr.bin').write_bytes(baseline.stderr)
    save(out/'baseline-process.json',dict(returncode=baseline.returncode))
    if baseline.returncode:raise RuntimeError('Owned modern public reader failed; outputs retained')
    traced_run(command[:-1]+[str(out/'traced.jsonl')],trace,out)
    events,errors=collections.defaultdict(list),[]
    for line in (out/'events.jsonl').read_text(encoding='utf-8').splitlines():
        packet=json.loads(line)
        if packet['type']!='send':errors.append(packet)
        else:
            row=packet['payload'];events[row['request']].append(row)
    answers=[json.loads(line) for line in (out/'baseline.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    traced_answers=[json.loads(line) for line in (out/'traced.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    public_changes=[dict(id=r['id'],cpu=r['cpu'],source_gap=predictions[str(r['id'])]['gap'],baseline=a,traced=b)
                    for r,a,b in zip(rows,answers,traced_answers,strict=True) if a!=b]
    save(out/'baseline-traced-differences.json',public_changes)
    counts=collections.Counter();by_cpu=collections.defaultdict(collections.Counter);differences=[];observations=[]
    for source,answer in zip(rows,answers,strict=True):
        if source['id']!=answer['id']:raise ValueError('Modern reader request identity differs')
        calls=[e for e in events[source['id']] if e['event']=='modern-machine-decoder']
        prediction=predictions[str(source['id'])]
        matches=dict(call_count=bool(prediction['gap']) or len(calls)==len(prediction['records']),
                     public_extent=bool(prediction['gap']) or answer['consumed']==prediction['consumed'])
        pair_matches=[]
        for expected,native in zip(prediction['records'],calls):
            fields=dict(words=expected['words']==native['words'],cells=expected['cells']==native['cells'],
                        auxiliary=expected['auxiliary']==native['auxiliary'],context=native['cpu']==source['cpu'] and native['mode']==source['mode'],
                        before=native['before']=='ff'*88 and native['auxiliary_before']=='00'*68)
            if expected['words']>0:fields['machine_extent']=expected['consumed_machine']==native['machine']
            counts['predicted_records']+=1;by_cpu[source['cpu']]['predicted_records']+=1
            for key,value in fields.items():
                counts[key]+=value;by_cpu[source['cpu']][key]+=value
            pair_matches.append(fields)
        matches['predicted_native_fields']=all(all(r.values()) for r in pair_matches)
        counts['complete_source_groups']+=prediction['gap'] is None
        counts['public_accepted']+=answer['code']==0
        public_output=base64.b64decode(answer['output_base64']).hex()
        counts['original_pcode_byte_exact']+=public_output==source['original_pcode'] and answer['code']==0
        result=dict(id=source['id'],case=source['case'],cpu=source['cpu'],native=calls,public=answer,matches=matches,record_matches=pair_matches)
        observations.append(result)
        if not all(matches.values()):differences.append(dict(source=source,prediction=prediction,observation=result))
    save(out/'observations.json',observations);save(out/'differences.json',differences)
    summary=dict(corpus=args.corpus,requests=len(rows),source_gaps=len(gaps),gap_reasons=dict(collections.Counter(r['reason'] for r in gaps)),
        counts=dict(counts),by_cpu={str(k):dict(v) for k,v in by_cpu.items()},
        differences=len(differences),public_codes=dict(collections.Counter(a['code'] for a in answers)),
        guards_intact=all(a['guards_intact'] for a in answers),input_unchanged=all(a['input_unchanged'] for a in answers),
        baseline_traced_exact=(out/'baseline.jsonl').read_bytes()==(out/'traced.jsonl').read_bytes(),hook_errors=errors,
        baseline_traced_different_public_rows=len(public_changes),
        baseline_traced_complete_source_exact=all(r['source_gap'] is not None for r in public_changes),
        opaque_public_output_changes=sum(r['source_gap'] is not None for r in public_changes),
        returned_cursor_beyond_logical_input=sum(a['consumed']>len(bytes.fromhex(r['machine'])) for r,a in zip(rows,answers,strict=True)),
        scope='Independent static reader vs native original functions. Canonical PCode identity, decoder field agreement and native acceptance are measured separately; retained native input padding is not source knowledge.')
    save(out/'comparison.json',summary);print(json.dumps(summary,ensure_ascii=True),flush=True)
    if differences or errors or not summary['baseline_traced_complete_source_exact']:raise ValueError('Modern machine decoder differences retained')


if __name__=='__main__':main()
