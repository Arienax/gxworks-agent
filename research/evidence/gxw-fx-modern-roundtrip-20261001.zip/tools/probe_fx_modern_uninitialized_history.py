"""Controlled prior-address experiment for retained opaque reader branches."""
import base64
import collections
import json
import os
import struct
import subprocess
from probe_fx_operand_rules import DLL,P,save,traced_run
from probe_fx_modern_machine_decoder import load
from source_fx_modern_decoder import FXModernDecoder
from source_fx_lossless_reader import FXLosslessReader


def main():
    out=P/'fx-modern-uninitialized-history-20261001-v1';out.mkdir()
    prior=P/'fx-modern-independent-machine-holdouts-20261001-v2'
    originals=load(prior/'before-native.json')['requests'];gaps=load(prior/'source-gaps.json')
    tables=load(P/'fx-modern-decoder-tables-20261001-v1.json')
    models={cpu:FXModernDecoder(tables,cpu=cpu) for cpu in (520,521)}
    rows=[];predictions={}
    for gap in gaps:
        source=originals[gap['id']];raw=bytes.fromhex(source['machine'])
        if len(raw)!=4:raise ValueError('Uninitialized witness is not the inspected two-word form')
        seeds=[raw[:2]+struct.pack('<H',0xa800|(address-1536)) for address in (1900,2500)]
        row=dict(id=len(rows),origin_id=source['id'],cpu=source['cpu'],target=raw.hex(),
                 seeds=[dict(address=address,machine=seed.hex()) for address,seed in zip((1900,2500),seeds,strict=True)])
        rows.append(row)
        predictions[str(row['id'])]=[models[source['cpu']].record(seed) for seed in seeds]
    save(out/'before-native.json',dict(requests=rows,scope='Fresh object per row; seed1900, same opaque target, seed2500, same target on that object. No native memory writes or code changes; all arrays owned.'))
    save(out/'predictions-before-native.json',predictions)
    for name in ('FXModernHistoryOracle.cs','probe_fx_modern_uninitialized_history.py','source_fx_modern_decoder.py','fx-modern-decoder-tables-20261001-v1.json'):
        (out/name).write_bytes((P/name).read_bytes())
    trace=(prior/'TraceFXModernDecoder.js').read_text(encoding='utf-8')
    (out/'TraceFXModernDecoder.js').write_text(trace,encoding='utf-8')
    exe=out/'FXModernHistoryOracle.exe'
    build=subprocess.run([os.path.join(os.environ['WINDIR'],'Microsoft.NET/Framework/v4.0.30319/csc.exe'),'/nologo','/platform:x86',
        '/out:'+str(exe),str(out/'FXModernHistoryOracle.cs')],capture_output=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
    (out/'build.txt').write_bytes(build.stdout+build.stderr)
    if build.returncode:raise RuntimeError('Owned history helper failed to build')
    (out/'requests.tsv').write_text('\n'.join('\t'.join([str(r['id']),str(r['cpu']),
        *[base64.b64encode(bytes.fromhex(s['machine'])).decode() for s in r['seeds']],base64.b64encode(bytes.fromhex(r['target'])).decode()]) for r in rows)+'\n',encoding='ascii')
    command=[str(exe),str(DLL),str(out/'requests.tsv'),str(out/'baseline.jsonl')]
    baseline=subprocess.run(command,capture_output=True,timeout=45,creationflags=subprocess.CREATE_NO_WINDOW)
    (out/'baseline-stdout.bin').write_bytes(baseline.stdout);(out/'baseline-stderr.bin').write_bytes(baseline.stderr)
    save(out/'baseline-process.json',dict(returncode=baseline.returncode))
    if baseline.returncode:raise RuntimeError('Owned history conversion failed')
    traced_run(command[:-1]+[str(out/'traced.jsonl')],trace,out)
    events=collections.defaultdict(list);errors=[]
    for line in (out/'events.jsonl').read_text(encoding='utf-8').splitlines():
        packet=json.loads(line)
        if packet['type']!='send':errors.append(packet)
        elif packet['payload']['event']=='modern-machine-decoder':
            event=packet['payload'];events[event['request']].append(event)
    answers=[json.loads(line) for line in (out/'baseline.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    counts=collections.Counter();results=[];differences=[];reader=FXLosslessReader()
    for r in rows:
        responses=answers[4*r['id']:4*r['id']+4]
        if [(a['id'],a['phase']) for a in responses]!=[(r['id'],i) for i in range(4)]:raise ValueError('History phase identity differs')
        targets=[]
        for phase in (0,2):
            calls=events[4*r['id']+phase];expected=predictions[str(r['id'])][phase//2]
            matches=len(calls)==1 and expected['words']==calls[0]['words'] and expected['cells']==calls[0]['cells'] and expected['auxiliary']==calls[0]['auxiliary']
            counts['valid_seed_decoder_exact']+=matches
            if not matches:differences.append(dict(source=r,phase=phase,prediction=expected,native=calls))
            answer=responses[phase];output=base64.b64decode(answer['output_base64'])
            ir=reader.read(output,cpu=r['cpu'])
            texts=[op['text'] for record in ir['records'] for op in record['lexical_projection'].get('operands',[])]
            counts['valid_seed_canonical_address_exact']+=texts==['M'+str(r['seeds'][phase//2]['address'])] and ir['coverage']['critical_gaps']==0
            target=responses[phase+1];raw_output=base64.b64decode(target['output_base64']);ir=reader.read(raw_output,cpu=r['cpu'])
            texts=[op['text'] for record in ir['records'] for op in record['lexical_projection'].get('operands',[])]
            targets.append(dict(phase=phase+1,public=target,raw=raw_output.hex(),address_texts=texts,
                                lexical_gaps=ir['coverage']['critical_gaps'],native=events[4*r['id']+phase+1]))
        counts['opaque_target_pairs']+=1
        counts['opaque_target_output_changes']+=targets[0]['raw']!=targets[1]['raw']
        counts['opaque_target_pairs_returned_success']+=all(t['public']['code']==0 for t in targets)
        counts['opaque_target_copied_seed_addresses']+=sum(t['address_texts']==['M'+str(s['address'])] for t,s in zip(targets,r['seeds'],strict=True))
        results.append(dict(source=r,targets=targets))
    save(out/'observations.json',results);save(out/'differences.json',differences)
    summary=dict(requests=len(rows),native_calls=len(answers),counts=dict(counts),differences=len(differences),
        public_codes=dict(collections.Counter(a['code'] for a in answers)),guards_intact=all(a['guards_intact'] for a in answers),
        input_unchanged=all(a['input_unchanged'] for a in answers),hook_errors=errors,
        baseline_traced_exact=(out/'baseline.jsonl').read_bytes()==(out/'traced.jsonl').read_bytes(),
        scope='Prior valid address as controlled state, repeated byte-identical invalid target. Native success, reproducibility and prior-address propagation measured separately. Opaque targets remain unsupported; no hardware or project-validity assertion.')
    save(out/'comparison.json',summary);print(json.dumps(summary,ensure_ascii=True),flush=True)
    if differences or errors:raise ValueError('Valid history controls differ; retained')


if __name__=='__main__':main()
