"""Fresh original/modified full-check controls and separate saved-source proof."""
import argparse
import json
from probe_fx_operand_rules import P,save
from probe_fx1s_lossless_project_patch import native_run
from probe_fx1s_project_patch_controls import reports
from gxw.container import CompoundFile
from gxw.project_resolver import GXWProjectResolver
from gxw.token_pou import frame_token_pou


def load(path):return json.loads(path.read_text(encoding='utf-8-sig'))


def observed(directory,input_file,outcome,expected):
    events=[json.loads(s) for s in (directory/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    contexts=[e['cpu'] for e in events if e.get('operation')=='NativeProjectAttributes']
    pcode=directory/'pcode-0-0.bin'
    return dict(outcome=outcome,pcode_exact=pcode.exists() and pcode.read_bytes()==expected,
                native_cpu_names=contexts,cpu_context_exact=bool(contexts) and all(c=='FX3U/FX3UC' for c in contexts),
                diagnostic_rows=reports(directory),
                native_process_completed=outcome['attempts'][-1]['returncode']==0,
                input_copy_unchanged=(directory/'input.gxw').read_bytes()==input_file.read_bytes())


def saved_source(path,logical,expected):
    resolver=GXWProjectResolver(CompoundFile(path.read_bytes()))
    matches=[];gaps=[]
    for file in resolver.logical_files():
        if not file.logical_name.lower().endswith('.pou'):continue
        source=resolver.hdb.read_stream(file.stream_name)
        try:frame=frame_token_pou(source)
        except Exception as exc:
            gaps.append(dict(logical=file.logical_name,stream=file.stream_name,reason=str(exc)));continue
        if file.logical_name==logical or frame.body==expected:
            matches.append(dict(logical=file.logical_name,stream=file.stream_name,body_exact=frame.body==expected,
                                source_bytes=len(source),body_bytes=len(frame.body),footer_bytes=len(source)-frame.body_end))
    exact=[r for r in matches if r['body_exact']]
    return dict(exact=len(exact)==1,matched_source=matches,other_source_frame_gaps=gaps,
                logical_name_preserved=len(exact)==1 and exact[0]['logical']==logical)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--attempt',type=int,required=True);args=parser.parse_args()
    prior=P/'fx3u-gxw-patch-20261001-v3';out=P/f'fx3u-gxw-native-patches-20261001-v{args.attempt}';out.mkdir()
    for name in ('run_fx3u_lossless_project_patches.py','probe_fx3u_lossless_source_patches.py','probe_fx1s_lossless_project_patch.py'):
        (out/name).write_bytes((P/name).read_bytes())
    proposals=load(prior/'proposals-before-native.json')
    save(out/'before-native.json',dict(source_proposals=str(prior),cases=[r['case'] for r in proposals],
        scope='Untouched and candidate copies each compiled with fresh full ProgramCheck. Save/reopen separately if diagnostics reject. No direct edits to compiler caches or unrelated streams.'))
    results=[]
    for proposal in proposals:
        case=proposal['case'];d=out/case;d.mkdir();source=prior/case
        original=source/'original.gxw';candidate=source/'candidate.gxw'
        if not candidate.exists():
            row=dict(case=case,handling='no-proposal',proposal=proposal)
            results.append(row);save(out/'comparison.json',results);continue
        original_body=frame_token_pou(GXWProjectResolver(CompoundFile(original.read_bytes())).read_logical_file(proposal['logical'])).body
        expected=(source/'expected-pcode.bin').read_bytes()
        plan=load(P/'additional-native-baselines'/case/'native-1/plan.json')
        untouched=d/'control';control_outcome=native_run(original,untouched,plan,compile=True,export=True,alias='FX3UPATCH')
        control=observed(untouched,original,control_outcome,original_body)
        changed=d/'candidate';candidate_outcome=native_run(candidate,changed,plan,compile=True,export=True,alias='FX3UPATCH')
        actual=observed(changed,candidate,candidate_outcome,expected)
        row=dict(case=case,mutation=proposal['mutation'],source_proposal=str(source),
                 changed_input_bytes=len(proposal['physical_changed_offsets']),original=control,candidate=actual,
                 program_check_diagnostics_unchanged=control['diagnostic_rows']==actual['diagnostic_rows'])
        saved=changed/'native-saved.gxw'
        if not saved.exists() and actual['native_process_completed'] and actual['pcode_exact'] and not candidate_outcome['compiler_rejected']:
            separate=d/'save';save_outcome=native_run(candidate,separate,plan,compile=True,export=True,check=False,alias='FX3UPATCH')
            row['separate_save']=observed(separate,candidate,save_outcome,expected)
            saved=separate/'native-saved.gxw'
        if saved.exists():
            row['saved_source']=saved_source(saved,proposal['logical'],expected)
            reopen=d/'reopen';reopen_outcome=native_run(saved,reopen,plan,compile=False,export=False,check=False,alias='FX3UPATCH')
            row['reopen']=observed(reopen,saved,reopen_outcome,expected)
        save(d/'comparison.json',row);results.append(row);save(out/'comparison.json',results)
        print(json.dumps(dict(case=case,mutation=row['mutation']['kind'],changed_input_bytes=row['changed_input_bytes'],
            original_pcode_exact=control['pcode_exact'],candidate_pcode_exact=actual['pcode_exact'],
            cpu_context_exact=control['cpu_context_exact'] and actual['cpu_context_exact'],
            original_check=control_outcome['program_check'],candidate_check=candidate_outcome['program_check'],
            diagnostics_unchanged=row['program_check_diagnostics_unchanged'],
            saved_source=row.get('saved_source'),reopened=row.get('reopen',{}).get('native_process_completed')),ensure_ascii=True),flush=True)


if __name__=='__main__':main()
