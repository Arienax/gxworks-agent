"""Classify retained modern native roundtrip changes without another DLL call."""
import collections
import json
from probe_fx_operand_rules import P,save
from probe_fx_modern_machine_decoder import load,predict_stream
from source_fx_lossless_reader import FXLosslessReader
from source_fx_modern_decoder import FXModernDecoder


def lexical(reader,raw,cpu):
    try:
        ir=reader.read(bytes.fromhex(raw),cpu=cpu)
        return [dict(name=(r['lexical_projection'] or {}).get('name'),
                     args=[o.get('text') for o in (r['lexical_projection'] or {}).get('operands',[])],
                     handling=r['handling']) for r in ir['records']]
    except Exception as exc:return dict(exception=type(exc).__name__,reason=str(exc))


def main():
    out=P/'fx-modern-public-machine-roundtrips-20261001-v1'
    if any((out/name).exists() for name in ('native-roundtrip-change-classification-v2.json','change-analysis-v2.json')):
        raise FileExistsError('Earlier analysis and its failure predecessor must be retained')
    origin=P/'fx-modern-independent-machine-holdouts-20261001-v2'
    sources=load(origin/'before-native.json')['requests']
    changes=load(out/'native-roundtrip-differences.json')
    reader=FXLosslessReader();groups=collections.defaultdict(list);all_rows=[]
    for change in changes:
        row=change['source'];source=sources[row['origin_id']]
        emitted=change['prediction']['expected_machine']
        result=dict(cpu=row['cpu'],group=source['machine_group'],input_machine=row['original_machine'],output_machine=emitted,
                    canonical=lexical(reader,row['raw'],row['cpu']),
                    original_aliases=[dict(raw=r['raw'],lexical=lexical(reader,r['raw'],521)) for r in source['origins']],
                    classification='native-accepted/but-machine-bytes-differ')
        groups[(source['machine_group'],emitted)].append(result);all_rows.append(result)
    save(out/'native-roundtrip-change-classification-v2.json',all_rows)
    table=load(P/'fx-modern-decoder-tables-20261001-v1.json')
    original=P/'fx-modern-independent-machine-decoder-20261001-v2'
    rows=load(original/'before-native.json')['requests'];observations=load(original/'observations.json')
    models={cpu:FXModernDecoder(table,cpu=cpu) for cpu in (520,521)}
    exact=0
    for source,observed in zip(rows,observations,strict=True):
        prediction=predict_stream(models[source['cpu']],bytes.fromhex(source['machine']))
        if prediction['gap'] or len(prediction['records'])!=len(observed['native']):raise ValueError('Updated source introduced an original decoder gap')
        for expected,native in zip(prediction['records'],observed['native'],strict=True):
            if any(expected[k]!=native[k] for k in ('words','cells','auxiliary')):raise ValueError('Updated decoder differs from retained original native fields')
            exact+=1
    summary=dict(native_changed_rows=len(changes),distinct_changed_machine_groups=len(groups),
                 canonical_names=dict(collections.Counter(r['canonical'][0]['name'] for r in all_rows)),
                 updated_source_original_decoder_records_exact=exact)
    save(out/'change-analysis-v2.json',summary)
    examples=[dict(group=key[0],input_machine=value[0]['input_machine'],output_machine=key[1],canonical=value[0]['canonical'],
                   original_aliases=[r['lexical'] for r in value[0]['original_aliases'][:4]]) for key,value in groups.items()]
    print(json.dumps(dict(summary=summary,groups=examples),ensure_ascii=True),flush=True)


if __name__=='__main__':main()
