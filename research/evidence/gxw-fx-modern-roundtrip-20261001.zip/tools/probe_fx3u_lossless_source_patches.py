"""Original FX3U source binding and copied-project local-byte proposals."""
import argparse
import collections
import json
import struct
import sys
from probe_fx_operand_rules import P,ROOT,save
sys.path.insert(0,str(ROOT/'src'))
from gxw.container import CompoundFile
from gxw.container_writer import replace_stream_within_allocation,inspect_stream_allocation
from gxw.project_resolver import GXWProjectResolver
from gxw.token_pou import frame_token_pou
from source_fx_lossless_reader import FXLosslessReader
from source_fx3u_machine import FX3UMachine,FX3UCells
from source_fx_operand_rules import Unsupported


def load(path):return json.loads(path.read_text(encoding='utf-8-sig'))


def emitter():
    prior=P/'fx3u-original-machine-corpus-20261001-v1'
    return FX3UMachine(load(prior/'fx3u-machine-tables-before-native.json'),FX3UCells(load(prior/'fx3u-cell-tables-before-native.json')))


def known_choices(reader,model,ir):
    devices={0x90:'M',0x98:'S',0x9c:'X',0x9d:'Y',0xc2:'T',0xc5:'C'}
    contacts=('LD','LDI','AND','ANI','OR','ORI','LDP','LDF','ANDP','ANDF','ORP','ORF')
    choices=[]
    for record in ir['records']:
        projection=record['lexical_projection']
        if not projection or projection.get('name') not in contacts or projection.get('arity')!=1:continue
        if len(projection['operands'])!=1 or len(projection['operands'][0]['tokens'])!=1:continue
        index=record['token_indexes'][1]
        token=ir['physical_tokens'][index];raw=bytes.fromhex(token['raw'])
        if raw[1] not in devices or not 1<=len(raw[2:-1])<=2:continue
        address=int.from_bytes(raw[2:-1],'little')
        if address>=65535 or address&255==255:continue
        replacement=raw[:2]+(address+1).to_bytes(len(raw[2:-1]),'little')+raw[-1:]
        changed_record=bytes.fromhex(record['raw']);at=token['offset']-record['offset']
        changed_record=changed_record[:at]+replacement+changed_record[at+len(raw):]
        try:
            before=model.record(bytes.fromhex(record['raw']))['emission'];after=model.record(changed_record)['emission']
        except Unsupported:continue
        if before['words']<=0 or after['words']!=before['words'] or after['machine_output'] is None:continue
        choices.append(dict(token_index=index,raw=raw.hex(),replacement=replacement.hex(),body_offset=token['offset'],
                            name=projection['name'],family=devices[raw[1]],before_address=address,after_address=address+1,
                            record_offset=record['offset'],record_raw_before=record['raw'],record_raw_after=changed_record.hex(),
                            original_machine=before['machine_output'],expected_machine=after['machine_output']))
    return sorted(choices,key=lambda r:('M','X','Y','S','T','C').index(r['family']))


def empty_program_insertion(reader,frame):
    if frame.body!=bytes.fromhex('033403'):
        raise Unsupported('No local contact proposal and original is not the observed empty END program')
    requests=load(P/'fx3u-original-machine-corpus-20261001-v1/before-native.json')['requests']
    templates={}
    for row in requests:
        projection=reader.records.read(bytes.fromhex(row['raw']),cpu=520)
        key=(projection.get('name'),tuple(o.get('text') for o in projection['operands']))
        if key in (('LD',('M0',)),('OUT',('M1',))) and key not in templates:
            templates[key]=dict(case=row['case'],id=row['id'],raw=row['raw'])
    if len(templates)!=2:raise Unsupported('Required independently observed source templates absent')
    instructions=[templates[('LD',('M0',))],templates[('OUT',('M1',))]]
    body=b''.join(bytes.fromhex(r['raw']) for r in instructions)+frame.body
    return body,dict(kind='bounded-body-growth',instructions=instructions,terminal_end_preserved=True,
                     old_body_bytes=len(frame.body),new_body_bytes=len(body),
                     scope='Insert original CPU520 native-observed LD M0 and OUT M1 records before unchanged END')


def prepare(out):
    reader=FXLosslessReader();model=emitter();cases=load(P/'fx3u-original-machine-corpus-20261001-v1/before-native.json')['projects']
    results=[]
    for case_info in cases:
        case=case_info['case'];d=out/case;d.mkdir()
        original=(P/'additional-real-projects'/case/'input.gxw').read_bytes()
        (d/'original.gxw').write_bytes(original)
        resolver=GXWProjectResolver(CompoundFile(original));baseline=(P/'additional-native-baselines'/case/'native-1/pcode-0-0.bin').read_bytes()
        bindings=[];unsupported=[]
        for file in resolver.logical_files():
            if not file.logical_name.lower().endswith('.pou'):continue
            source=resolver.hdb.read_stream(file.stream_name)
            try:frame=frame_token_pou(source)
            except Exception as exc:
                unsupported.append(dict(logical=file.logical_name,stream=file.stream_name,reason=str(exc)));continue
            bindings.append(dict(logical=file.logical_name,stream=file.stream_name,source=source,frame=frame,
                                 source_matches_compiled_body=frame.body==baseline))
        matched=[b for b in bindings if b['source_matches_compiled_body']]
        if len(matched)!=1:
            save(d/'source-binding-gap.json',dict(case=case,bindings=[{k:v for k,v in b.items() if k not in ('source','frame')} for b in bindings],unsupported=unsupported))
            raise ValueError('Original source does not bind exactly one native body: '+case)
        bound=matched[0];source=bound['source'];frame=bound['frame'];stream=bound['stream']
        ir=reader.read(frame.body,cpu=520)
        choices=known_choices(reader,model,ir)
        info=dict(case=case,cpu=520,logical=bound['logical'],stream=stream,source_bytes=len(source),body_bytes=len(frame.body),
                  source_body_offset=frame.body_offset,source_body_byte_exact_with_original_native=True,coverage=ir['coverage'],
                  eligible_same_width_contacts=len(choices),allocation=vars(inspect_stream_allocation(resolver.outer.read_stream('_hdb'),stream)),
                  original_distribution='Original source and derivative GXW remain local-only')
        if choices:
            chosen=choices[0]
            proposed=reader.replace_same_extent_token(ir,token_index=chosen['token_index'],expected_raw=chosen['raw'],replacement_raw=chosen['replacement'])
            body=bytes.fromhex(proposed['candidate']);new_source=source[:frame.body_offset]+body+source[frame.body_end:]
            mutation=dict(kind='same-extent-contact-address',chosen=chosen)
        else:
            try:body,mutation=empty_program_insertion(reader,frame)
            except Unsupported as exc:
                info.update(handling='no-proposal',reason=str(exc))
                save(d/'proposal-before-native.json',info);results.append(info);continue
            prefix=bytearray(source[:frame.body_offset]);struct.pack_into('<II',prefix,55,len(body)+20,len(body)+20)
            new_source=bytes(prefix)+body+source[frame.body_end:]
            if frame_token_pou(new_source).body!=body:raise ValueError('Extended source wrapper disagrees with proposed body')
            mutation.update(source_size_fields=[55,59],old_source_bytes=len(source),new_source_bytes=len(new_source))
        inner=resolver.outer.read_stream('_hdb');new_inner=replace_stream_within_allocation(inner,stream,new_source)
        candidate=replace_stream_within_allocation(original,'_hdb',new_inner)
        changed=[i for i,(a,b) in enumerate(zip(original,candidate,strict=True)) if a!=b]
        if choices and len(changed)!=1:raise ValueError('Contact proposal changed more than one address byte')
        after=GXWProjectResolver(CompoundFile(candidate))
        unmodified_inner=[e.name for e in resolver.hdb.iter_streams() if e.name!=stream]
        unmodified_outer=[e.name for e in resolver.outer.iter_streams() if e.name!='_hdb']
        if any(resolver.hdb.read_stream(n)!=after.hdb.read_stream(n) for n in unmodified_inner):raise ValueError('Unrelated inner stream changed')
        if any(resolver.outer.read_stream(n)!=after.outer.read_stream(n) for n in unmodified_outer):raise ValueError('Unrelated outer stream changed')
        # Unknown metadata is retained in the raw body and never sent to an
        # instruction emitter. Full-body compiler comparison includes it.
        machine=[];gaps=[]
        for record in reader.read(body,cpu=520)['records']:
            if record['handling']=='opaque-preserved metadata':continue
            try:
                result=model.record(bytes.fromhex(record['raw']))['emission']
                if result['words']<=0 or result['machine_output'] is None:raise Unsupported('No complete emission')
                machine.append(dict(offset=record['offset'],machine=result['machine_output']))
            except Unsupported as exc:gaps.append(dict(offset=record['offset'],raw=record['raw'],reason=str(exc)))
        (d/'candidate.gxw').write_bytes(candidate);(d/'expected-pcode.bin').write_bytes(body)
        info.update(handling='raw-local-proposal/requires-native-project-validation',mutation=mutation,physical_changed_offsets=changed,
                    input_file_bytes=len(original),input_file_length_unchanged=True,untouched_inner_streams=len(unmodified_inner),
                    untouched_outer_streams=len(unmodified_outer),untouched_stream_payloads_byte_exact=True,
                    expected_instruction_machines=machine,source_emission_gaps=gaps)
        save(d/'proposal-before-native.json',info);results.append(info)
    save(out/'proposals-before-native.json',results)
    print(json.dumps([dict(case=r['case'],logical=r['logical'],body_bytes=r['body_bytes'],coverage=r['coverage'],
          choices=r['eligible_same_width_contacts'],mutation=r.get('mutation',{}).get('kind'),
          change={k:r['mutation']['chosen'][k] for k in ('name','family','before_address','after_address')} if r.get('mutation',{}).get('kind')=='same-extent-contact-address' else None) for r in results],ensure_ascii=True),flush=True)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--attempt',type=int,required=True);args=parser.parse_args()
    out=P/f'fx3u-gxw-patch-20261001-v{args.attempt}';out.mkdir()
    (out/'probe_fx3u_lossless_source_patches.py').write_bytes((P/'probe_fx3u_lossless_source_patches.py').read_bytes())
    prepare(out)


if __name__=='__main__':main()
