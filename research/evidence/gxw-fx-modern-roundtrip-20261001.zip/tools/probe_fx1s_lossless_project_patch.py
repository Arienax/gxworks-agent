"""One-byte source proposals in copied originals, followed by native project work.

Raw CFB stream payloads are compared directly. The existing Python replay wrapper
is deliberately not called because it adds digest verification and manifests.
"""
import collections
import json
import os
from pathlib import Path
import subprocess
import sys
from probe_fx_operand_rules import P,save,ROOT

sys.path.insert(0,str(ROOT/'src'))
from gxw.container import CompoundFile
from gxw.container_writer import replace_stream_within_allocation
from gxw.project_resolver import GXWProjectResolver
from gxw.token_pou import frame_token_pou
from source_fx1s_reader import FX1SLosslessReader
from source_fx_old_machine import FXOldMachine,FX1SCells


def candidate(case,directory):
    raw=(P/'additional-real-projects'/case/'input.gxw').read_bytes()
    resolver=GXWProjectResolver(CompoundFile(raw));logical='MAIN.Program.pou'
    matches=[r.stream_name for r in resolver.logical_files() if r.logical_name==logical]
    if len(matches)!=1:raise ValueError('Original MAIN source binding is ambiguous')
    stream=matches[0];source=resolver.hdb.read_stream(stream);frame=frame_token_pou(source)
    baseline=(P/'additional-native-baselines'/case/'native-1/pcode-0-0.bin').read_bytes()
    if frame.body!=baseline:raise ValueError('Original source is not independently bound to compiled PCode')
    reader=FX1SLosslessReader();ir=reader.read(frame.body,cpu=518)
    if ir['coverage']['critical_gaps']:raise ValueError('Original source retains unresolved lexical gaps')
    chosen=None
    for record in ir['records']:
        projection=record['lexical_projection']
        if not projection or projection.get('name') not in ('LD','LDI','AND','ANI','OR','ORI'):continue
        for token_index in record['token_indexes'][1:]:
            token=ir['physical_tokens'][token_index];body=bytes.fromhex(token['raw'])
            if body[1]!=0x90 or not 1<=len(body[2:-1])<=2:continue
            address=int.from_bytes(body[2:-1],'little')
            if address>=254:continue
            if len(projection['operands'])!=1 or len(projection['operands'][0]['tokens'])!=1:continue
            replacement=body[:2]+(address+1).to_bytes(len(body[2:-1]),'little')+body[-1:]
            chosen=dict(token_index=token_index,raw=token['raw'],replacement=replacement.hex(),
                body_offset=token['offset'],name=projection['name'],before_address=address,after_address=address+1)
            break
        if chosen:break
    if chosen is None:raise ValueError('No plain, same-width contact M operand in this original')
    proposal=reader.replace_same_extent_token(ir,token_index=chosen['token_index'],expected_raw=chosen['raw'],replacement_raw=chosen['replacement'])
    body=bytes.fromhex(proposal['candidate']);new_source=source[:frame.body_offset]+body+source[frame.body_end:]
    inner=resolver.outer.read_stream('_hdb');new_inner=replace_stream_within_allocation(inner,stream,new_source)
    patched=replace_stream_within_allocation(raw,'_hdb',new_inner)
    changed=[i for i,(a,b) in enumerate(zip(raw,patched,strict=True)) if a!=b]
    if len(changed)!=1:raise ValueError('Targeted proposal changed bytes outside one address payload')
    after=GXWProjectResolver(CompoundFile(patched))
    unmodified_inner=[e.name for e in resolver.hdb.iter_streams() if e.name!=stream]
    if any(resolver.hdb.read_stream(n)!=after.hdb.read_stream(n) for n in unmodified_inner):raise ValueError('Unrelated original inner stream changed')
    unmodified_outer=[e.name for e in resolver.outer.iter_streams() if e.name!='_hdb']
    if any(resolver.outer.read_stream(n)!=after.outer.read_stream(n) for n in unmodified_outer):raise ValueError('Unrelated original outer stream changed')
    model=FXOldMachine(json.loads((P/'fx-old-machine-tables-20261001-v1.json').read_text(encoding='utf-8')),
        FX1SCells(json.loads((P/'fx1s-cell-tables-20261001-v1.json').read_text(encoding='utf-8'))))
    machine=[]
    for record in reader.read(body,cpu=518)['records']:
        p=model.record(bytes.fromhex(record['raw']))['emission']
        if p['words']<=0 or p['machine_output'] is None:raise ValueError('Proposed full body has a source emission gap')
        machine.append(p['machine_output'])
    (directory/'candidate.gxw').write_bytes(patched);(directory/'expected-pcode.bin').write_bytes(body)
    (directory/'original.gxw').write_bytes(raw)
    proof=dict(case=case,cpu=518,logical=logical,stream=stream,source_bytes=len(source),body_bytes=len(body),
        source_body_offset=frame.body_offset,chosen=chosen,physical_changed_offsets=changed,
        input_file_bytes=len(raw),input_file_length_unchanged=True,
        untouched_inner_streams=len(unmodified_inner),untouched_outer_streams=len(unmodified_outer),
        untouched_stream_payloads_byte_exact=True,expected_machine=''.join(machine),
        original_distribution='Original third-party GXW and derived source remain local-only',
        scope='One original contact operand; source wrapper, token sizes, all other raw tokens, CFB allocation and unrelated stream payloads retained')
    save(directory/'proposal-before-native.json',proof)
    return proof


def native_run(input_file,directory,base_plan,*,compile,export,check=True,alias='FX1SPATCH'):
    directory.mkdir();(directory/'home').mkdir();(directory/'compiler').mkdir()
    (directory/'input.gxw').write_bytes(input_file.read_bytes())
    for name in ('WorkspaceReplayOracle.cs','NativeFrontendSnapshot.cs','NativeSfcGraphOracle.cs','NativeWorkspaceCopyOracle.cs'):
        source=(ROOT/'research/native'/name).read_text(encoding='utf-8')
        if name=='WorkspaceReplayOracle.cs':
            hash_check_line='                    Check("Project.CheckProjectHash",Slot<PtrCodeFn>(operations,456)(operations,savedPath,out code),code);'
            if source.count(hash_check_line)!=1:raise ValueError('Owned native snapshot verification site differs')
            source=source.replace(hash_check_line,'                    // No additional digest verification; native SaveProject/CreateProjectHash produce the vendor save state.')
        (directory/name).write_text(source,encoding='utf-8')
    plan=dict(base_plan)
    plan.update(workspace_home=str(directory/'home')+'\\',compiler_work=str(directory/'compiler'),input_copy=str(directory/'input.gxw'),
        project_name=alias,project_alias=alias,compile=compile,export_project=export,snapshot_frontend=True)
    if compile and check:plan.update(program_check_kind=0x7fffffff,program_check_collection=7,refresh_program_check=True)
    else:
        for key in ('program_check_kind','program_check_collection','refresh_program_check'):plan.pop(key,None)
    save(directory/'plan.json',plan)
    exe=directory/'WorkspaceReplayOracle.exe'
    command=[os.path.join(os.environ['WINDIR'],'Microsoft.NET/Framework/v4.0.30319/csc.exe'),'/nologo','/platform:x86',
        '/r:System.Web.Extensions.dll','/r:System.Windows.Forms.dll','/out:'+str(exe)]
    command.extend(str(directory/name) for name in ('WorkspaceReplayOracle.cs','NativeFrontendSnapshot.cs','NativeSfcGraphOracle.cs','NativeWorkspaceCopyOracle.cs'))
    build=subprocess.run(command,capture_output=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
    (directory/'build.stdout.bin').write_bytes(build.stdout);(directory/'build.stderr.bin').write_bytes(build.stderr)
    if build.returncode:raise RuntimeError('Owned project helper build failed')
    attempts=[]
    for attempt in range(4):
        try:
            process=subprocess.run([str(exe),str(directory/'plan.json')],capture_output=True,timeout=50,creationflags=subprocess.CREATE_NO_WINDOW)
            (directory/('stdout-'+str(attempt)+'.bin')).write_bytes(process.stdout);(directory/('stderr-'+str(attempt)+'.bin')).write_bytes(process.stderr)
            returncode=process.returncode;timed_out=False
        except subprocess.TimeoutExpired as exc:
            (directory/('stdout-'+str(attempt)+'.bin')).write_bytes(exc.stdout or b'');(directory/('stderr-'+str(attempt)+'.bin')).write_bytes(exc.stderr or b'')
            returncode=None;timed_out=True
        events=[json.loads(l) for l in (directory/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
        attempts.append(dict(attempt=attempt,returncode=returncode,timed_out=timed_out))
        save(directory/('events-attempt-'+str(attempt)+'.json'),events)
        if returncode!=5:break
    failures=[e for e in events if (e.get('hresult',0)<0 or e.get('code',0)!=0) and e.get('operation') not in ('BuildResult',)]
    summary=dict(attempts=attempts,input_copy_unchanged=(directory/'input.gxw').read_bytes()==input_file.read_bytes(),
        compile_completed=compile and any(e.get('operation')=='Progress' and e.get('percent')==100 for e in events),
        compiler_rejected=any(r.get('kind') in (2,3) for e in events if e.get('operation')=='Progress' for r in e.get('reports',[])),
        program_check=[e for e in events if e.get('operation')=='ProgramCheckCompleted'],
        exported=(directory/'native-saved.gxw').exists(),failures=failures,last_event=events[-1] if events else None)
    save(directory/'outcome.json',summary);return summary


def main():
    out=P/'fx1s-lossless-project-patch-20261001-v1';out.mkdir()
    (out/'probe_fx1s_lossless_project_patch.py').write_bytes((P/'probe_fx1s_lossless_project_patch.py').read_bytes())
    prepared=[]
    for case in ('case-08','case-09'):
        directory=out/case;directory.mkdir();proof=candidate(case,directory)
        plan=json.loads((P/'additional-native-baselines'/case/'native-1/plan.json').read_text(encoding='utf-8'))
        prepared.append((directory,proof,plan))
    results=[]
    for directory,proof,plan in prepared:
        native=directory/'native-build';outcome=native_run(directory/'candidate.gxw',native,plan,compile=True,export=True)
        pcode=native/'pcode-0-0.bin';expected=(directory/'expected-pcode.bin').read_bytes()
        row=dict(case=proof['case'],proposal=proof,build=outcome,compiled_pcode_exact=pcode.exists() and pcode.read_bytes()==expected)
        saved=native/'native-saved.gxw'
        if saved.exists():
            resolver=GXWProjectResolver(CompoundFile(saved.read_bytes()));source=resolver.read_logical_file(proof['logical']);frame=frame_token_pou(source)
            row['saved_source_body_exact']=frame.body==expected
            reopened=native_run(saved,directory/'native-reopen',plan,compile=False,export=False)
            row['reopen']=reopened
        save(directory/'comparison.json',row);results.append(row);save(out/'comparison.json',results)
        print(json.dumps({k:v for k,v in row.items() if k!='proposal'},ensure_ascii=True),flush=True)


if __name__=='__main__':main()
