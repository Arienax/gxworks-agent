"""Raw-source models for multiple FX3U SFC registrations.

The declaration ordering and reference expansion reuse already observed shapes.
The hypothesis policies retain rejected alternatives for replay. Native controls
reject concatenation and position sorting. measured_project_projection selects
the first stored registration within the observed nonempty/count/value bounds.
Numeric field semantics, opaque graph/cache bytes and program acceptance remain
separate from this byte-ownership model.
"""
import struct

from gxw.container import CompoundFile
from gxw.project_resolver import GXWProjectResolver
from gxw.project_metadata import read_project_text_context
from gxw.sfc_pou import parse_sfc_pou
from probe_gxw_task_graph import inspect_task_graph, _text


def expand_block(raw, *, registration_policy='ordered', allow_experimental_numbers=False):
    source = parse_sfc_pou(raw)
    gaps = [g for g in source.diagnostics if not (allow_experimental_numbers and g.startswith('uninterpreted SFC action qualifier '))]
    if gaps or source.graph_tokens is None:
        raise ValueError('Source retains a graph/reference gap: ' + repr(source.diagnostics))
    zooms = {c['name']: bytes.fromhex(c['token_hex']) for c in source.layout['children'] if c['kind'] == 'zoom'}
    transitions = {c['number']: bytes.fromhex(c['token_hex']) for c in source.layout['children'] if c['kind'] == 'transition'}
    actions, registration_bodies = {}, []
    for action in source.layout['actions']:
        registrations = action['registrations']
        if len(registrations) > 32 or (not allow_experimental_numbers and any(r['qualifier'] != 0 for r in registrations)):
            raise ValueError('Registration qualifier/count outside the explicit hypothesis')
        if registration_policy.startswith('position_'):
            registrations = sorted(registrations, key=lambda r:r['qualifier'])
        names = [r['zoom'] for r in registrations]
        if registration_policy in ('first','position_first'):
            names = names[:1]
        elif registration_policy == 'last':
            names = names[-1:]
        elif registration_policy == 'unique':
            names = list(dict.fromkeys(names))
        elif registration_policy not in ('ordered','position_ordered'):
            raise ValueError('Unobserved registration policy')
        code = b''.join(zooms[name] for name in names)
        actions[action['number']] = code
        registration_bodies.append(dict(number=action['number'], names=names, body_bytes=len(code)))
    expanded, bindings = [], []
    for record in source.graph_records:
        expanded.append(bytes.fromhex(record['raw_hex']))
        if record['kind'] == 'step-action-reference':
            kind, key = 'action', record['references'][-1]
            body = actions[key]
        elif record['kind'] == 'transition-reference':
            kind, key = 'transition', record['references'][0]
            body = transitions[key]
        elif record['kind'] in ('step-reference', 'block-call-reference', 'end'):
            continue
        else:
            raise ValueError('Unsupported SFC graph record')
        bindings.append(dict(kind=kind, reference=key, body_bytes=len(body)))
        expanded.append(body)
    return b''.join(expanded), dict(registration_bodies=registration_bodies, bindings=bindings)


def project_projection(data, *, registration_policy='ordered', allow_experimental_numbers=False):
    resolver = GXWProjectResolver(CompoundFile(data))
    physical_names = {e.name for e in resolver.hdb.iter_streams()}
    streams = {f.logical_name: resolver.hdb.read_stream(f.stream_name) for f in resolver.logical_files()
               if f.stream_name in physical_names}
    metadata, = [raw for name, raw in streams.items() if name.lower().endswith('.prj')]
    if read_project_text_context(metadata)['cpu'] != 'FX3U/FX3UC':
        raise ValueError('This prospective experiment is bound to FX3U/FX3UC')
    graph = inspect_task_graph(data)
    if graph['gaps'] or len(graph['resources']) != 1:
        raise ValueError('Incomplete or unsupported compile-root graph')
    task = graph['tasks'][graph['resources'][0]['task']]
    if not task['entries']:
        raise ValueError('Empty task can expose stale compiler resource output')
    ordered = []
    for entry in task['entries']:
        declaration = streams[entry['declarations']]
        _, end = _text(declaration, 54)
        if declaration[end:end + 20] != bytes.fromhex('0000000100000000010000000000010000000000'):
            raise ValueError('Unobserved SFC declaration header')
        number = struct.unpack_from('<I', declaration, end + 20)[0]
        if number > 255 or any(n == number for n, _ in ordered):
            raise ValueError('Unobserved/duplicate SFC block number')
        ordered.append((number, entry))
    output, blocks = [bytes.fromhex('056c010005')], []
    for number, entry in sorted(ordered, key=lambda row: row[0]):
        body, evidence = expand_block(streams[entry['source_program']], registration_policy=registration_policy,
                                      allow_experimental_numbers=allow_experimental_numbers)
        output.extend([bytes.fromhex('056c01020504dc') + bytes([number, 4]), body, bytes.fromhex('056c010305')])
        blocks.append(dict(program=entry['source_program'], block=number, **evidence))
    output.append(bytes.fromhex('056c010105033403'))
    return b''.join(output), dict(blocks=blocks, policy=registration_policy,
        scope='Prospective source assembly; original opaque graph/cache and child bytes retained; execution semantics not inferred')


def measured_project_projection(data):
    """First stored registration; fail explicitly for unmeasured source shapes."""
    resolver = GXWProjectResolver(CompoundFile(data))
    for file in resolver.logical_files():
        if not file.logical_name.lower().endswith('.pou'):
            continue
        raw = resolver.hdb.read_stream(file.stream_name)
        if raw[54:58] != bytes.fromhex('f0000000'):
            continue
        source = parse_sfc_pou(raw)
        actions = {a['number']:a for a in source.layout['actions']}
        for record in source.graph_records:
            if record['kind'] != 'step-action-reference':
                continue
            registrations = actions[record['references'][-1]]['registrations']
            if not 1 <= len(registrations) <= 3:
                raise ValueError('Referenced SFC action registration count is empty or unmeasured')
            if any(r['qualifier'] not in (0,1,3,7) for r in registrations):
                raise ValueError('Unmeasured SFC registration numeric value; field remains raw')
    body, evidence = project_projection(data, registration_policy='first', allow_experimental_numbers=True)
    evidence.update(handling='native-validated-source-byte-ownership',
        registration_numeric_role='uninterpreted; preserved without qualifier/execution meaning',
        scope='Converted simple FX3U, 1..3 registrations and numeric values 0/1/3/7 observed in native controls. First stored registration supplies the inline body. This does not establish complete project acceptance or execution semantics.')
    return body, evidence
