"""Physical token partition with bounded native lexical annotations.

Unknown records and a broken framing remainder stay opaque. A decoded name or
display never supplies bytes for reconstruction.
"""
from source_fx_record_reader import FXRecordReader
from source_fx_operand_rules import Unsupported


class FXLosslessReader:
    SUPPORTED_CPUS = (520,521)

    def __init__(self, header_tables=None, operand_tables=None):
        self.records = FXRecordReader(header_tables, operand_tables)

    def read(self, body, *, cpu):
        if cpu not in self.SUPPORTED_CPUS:
            raise Unsupported('Unmeasured whole-body lexical CPU')
        physical, cursor = [], 0
        while cursor < len(body):
            n = body[cursor]
            if n < 2 or cursor + n > len(body) or body[cursor + n - 1] != n:
                physical.append(dict(index=len(physical), offset=cursor, raw=body[cursor:].hex(),
                                     handling='opaque-unframed-remainder', code=None))
                break
            token = body[cursor:cursor + n]
            physical.append(dict(index=len(physical), offset=cursor, raw=token.hex(),
                                 handling='framed-raw-token', code=token[1]))
            cursor += n
        records, start = [], 0
        while start < len(physical):
            token = physical[start]
            code = token['code']
            if code is None:
                end, handling, projection, critical = start + 1, 'opaque-unframed-remainder', None, True
            elif 0x80 <= code < 0x90:
                end, handling, projection, critical = start + 1, 'opaque-preserved metadata', None, False
            else:
                end = start + 1
                while end < len(physical) and physical[end]['code'] is not None and physical[end]['code'] >= 0x90:
                    end += 1
                projection = None
                handling, critical = 'opaque-preserved instruction region', True
                if code < 0x80:
                    raw = b''.join(bytes.fromhex(t['raw']) for t in physical[start:end])
                    try:
                        projection = self.records.read(raw, cpu=cpu)
                        handling = projection['handling']
                        critical = handling != 'decoded-native-record'
                    except Unsupported as exc:
                        projection = dict(handling='unsupported', reason=str(exc), raw_record=raw.hex())
                else:
                    handling = 'opaque-preserved orphan operand region'
            records.append(dict(index=len(records), offset=token['offset'], token_indexes=list(range(start, end)),
                                raw=b''.join(bytes.fromhex(t['raw']) for t in physical[start:end]).hex(),
                                handling=handling, critical_gap=critical, lexical_projection=projection))
            for t in physical[start:end]:
                t['owner_record'] = records[-1]['index']
            start = end
        result = dict(cpu=cpu, descriptor_class=32, converter_version='15.31', raw_body=body.hex(),
                      physical_tokens=physical, records=records,
                      coverage=dict(raw_bytes=len(body), raw_regions=len(physical), records=len(records),
                          decoded_instructions=sum(r['handling'] == 'decoded-native-record' for r in records),
                          opaque_metadata=sum(r['handling'] == 'opaque-preserved metadata' for r in records),
                          critical_gaps=sum(r['critical_gap'] for r in records)),
                      scope='Lexical annotation and raw reconstruction only; range, operand roles, machine widths, project acceptance and execution require separate evidence.')
        if self.reconstruct(result) != body:
            raise ValueError('Lossless physical token partition differs')
        return result

    @staticmethod
    def reconstruct(result):
        rebuilt, offset = bytearray(), 0
        for token in result['physical_tokens']:
            raw = bytes.fromhex(token['raw'])
            if token['offset'] != offset:
                raise ValueError('Physical token offsets do not form the original partition')
            rebuilt.extend(raw)
            offset += len(raw)
        if rebuilt.hex() != result['raw_body']:
            raise ValueError('Physical partition does not reproduce its bound source')
        return bytes(rebuilt)

    @staticmethod
    def replace_same_extent_token(result, *, token_index, expected_raw, replacement_raw):
        """Local byte proposal, without interpreting or normalizing other data."""
        original = FXLosslessReader.reconstruct(result)
        token = result['physical_tokens'][token_index]
        before, after = bytes.fromhex(expected_raw), bytes.fromhex(replacement_raw)
        if token['raw'] != expected_raw or token['handling'] != 'framed-raw-token':
            raise Unsupported('Replacement does not bind an original framed token')
        if len(after) != len(before) or len(after) < 3 or after[0] != len(after) or after[-1] != len(after) or after[1] != before[1]:
            raise Unsupported('Replacement exceeds the unchanged token extent/family')
        offset = token['offset']
        candidate = original[:offset] + after + original[offset + len(before):]
        if candidate[:offset] != original[:offset] or candidate[offset + len(after):] != original[offset + len(before):]:
            raise ValueError('Untouched source bytes changed')
        return dict(candidate=candidate.hex(), offset=offset, token_index=token_index,
                    before=before.hex(), after=after.hex(), untouched_bytes_preserved=True,
                    handling='raw-byte-proposal/requires-independent-validation')
