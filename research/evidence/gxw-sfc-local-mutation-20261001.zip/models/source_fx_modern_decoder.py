"""Independent static mode-8/9 machine decoder, retaining canonical projections.

No PCode lowering or emitter is imported. The machine input is never replaced by
its address projection; incomplete and uninitialized native branches stay gaps.
"""
import struct
from source_fx_operand_rules import Unsupported


class OperandRefused(Exception):
    pass


class FXModernDecoder:
    def __init__(self, tables, *, cpu):
        modes = {520:8, 521:9}
        if tables['file_version'] != '15.31' or cpu not in modes:
            raise Unsupported('Uninspected modern machine reader context')
        self.tables, self.cpu, self.mode = tables, cpu, modes[cpu]

    def header(self, first):
        headers = self.tables['headers']
        for value in (first, first & 0xf000):
            match = next((r for r in headers if r['opcode'] == value), None)
            if match is not None:
                return dict(match)
        if first & 0xf000 == 0:
            match = next((r for r in headers if r['opcode'] == first & 0xff00), None)
            if match is not None:
                result = dict(match)
                if first & 0xff00 == 0xe00 and first & 255 >= 200:
                    result.update(flags=10, words=5)
                return result
        if first & 0xf000 > 0x2000:
            raise OperandRefused('Modern instruction class absent')
        number = ((first >> 1) & 0x7ff) - 8
        if not 0 <= number < 310:
            raise OperandRefused('Modern application number absent')
        count = self.tables['application_arities'][number]
        kind = 49 if first & 1 else 48
        flags = ((count << 5) + 0x11) & 255 if kind == 49 else ((count + 1) << 4) & 255
        if 224 <= number <= 246:
            flags = (flags + 8) & 255
        if kind == 49 and number == 152:
            flags, count = 0x51, 2
        if kind == 48 and number in (298, 299):
            return dict(flags=25 if number == 298 else 26, kind=38 if number == 298 else 39,
                        words=1, operands=0)
        return dict(flags=flags, kind=kind, words=1, operands=count,
                    function=number, pulse=first & 0xf000 != 0)

    @staticmethod
    def descriptor(family=None, value=None):
        return dict(family=family, value=value, index_family=None, index=0,
                    group=255, bit=255, unit=255)

    @staticmethod
    def need(words, at, size):
        if at + size > len(words):
            raise Unsupported('Truncated modern machine operand')

    def compact(self, word):
        area, lo = word & 0xf00, word & 255
        if area == 0xf00: family, value = 'M', 8000 + lo
        elif area == 0xe00: family, value = 'C', lo
        elif 0x800 <= area <= 0xd00: family, value = 'M', word & 0x7ff
        elif area in (0x600, 0x700): family, value = 'T', word & 0x1ff
        elif area == 0x500: family, value = 'Y', lo
        elif area == 0x400: family, value = 'X', lo
        else: family, value = 'S', word & 0x3ff
        return self.descriptor(family, value)

    def extended(self, word):
        prefix, area, lo = word & 0xf000, word & 0xf00, word & 255
        if prefix == 0x8000:
            return self.compact(word)
        if prefix == 0x9000:
            return self.descriptor('S', word & 0xfff) if area else self.descriptor('M', 8256 + lo)
        if prefix == 0xa000:
            if area in (0x400, 0x500):
                return self.descriptor('X' if area == 0x400 else 'Y', 256 + lo)
            return self.descriptor('M', 1536 + (word & 0x7ff))
        raise Unsupported('Native extended operand leaves address fields uninitialized')

    def reverse_index(self, address):
        for family in ('Z','V'):
            if address in self.tables['index_addresses'][family]:
                return family, self.tables['index_addresses'][family].index(address)
        return 'D', address

    def word(self, words, at, *, double=False, ascii_literal=False):
        self.need(words, at, 4 if double else 2)
        first, second = words[at:at + 2]
        if first & 0x8000 == 0:
            raise OperandRefused('Modern operand prefix lacks presence bit')
        result = self.descriptor()
        result['index_family'] = 'Z' if first & 0x2000 else 'V' if first & 0x1000 else None
        cls, area = (first >> 9) & 7, (second >> 9) & 15
        value = (first & 255) | ((second & 255) << 8)
        if cls in (0,1):
            if area == 8 and not double:
                raise OperandRefused('Floating literal requires the double reader')
            result.update(family=('E' if cls == 0 else 'F') if area == 8 else ('K' if cls == 0 else 'H'),
                          value=value | (((words[at+2]&255) | ((words[at+3]&255)<<8))<<16) if double else value,
                          index=(second>>8)&7)
        elif cls == 2:
            value = (first & 255) | ((second & 63) << 8)
            section, nibble = (value >> 12) & 3, second & 15
            if section == 0:
                result = self.compact(nibble << 8 | first & 255)
                if 8 <= nibble <= 13:
                    result['value'] = value & 0x7ff
                elif nibble <= 3:
                    result['value'] = value & 0x3ff
                elif nibble in (6,7):
                    result['value'] = value & 0x1ff
            elif section == 1:
                if nibble == 0: result.update(family='M', value=8256 + (first & 255))
                elif 4 <= nibble <= 15: result.update(family='S', value=value & 0xfff)
                else: raise Unsupported('Native indexed bit branch leaves family uninitialized')
            elif section == 2:
                if nibble in (4,5): result.update(family='X' if nibble == 4 else 'Y', value=256+(first&255))
                elif 8 <= nibble <= 15: result.update(family='M', value=1536+(value&0x7ff))
                else: raise Unsupported('Native extended bit branch leaves family uninitialized')
            else: result.update(family='M', value=3584+(value&0xfff))
            result['index_family'] = 'Z' if first & 0x2000 else 'V' if first & 0x1000 else None
            result.update(group=area if area else 255, index=(second>>6)&7)
        elif cls == 3:
            if area == 0:
                result.update(family='D', value=8000+((value>>1)&0x1fff))
                if result['index_family'] is None:
                    result['family'], result['value'] = self.reverse_index(result['value'])
            elif area == 1: result.update(family='T', value=(value>>1)&0x1fff)
            elif area == 2:
                address = value & 0x3fff
                result.update(family='C', value=address//2 if address<512 else (address-512)//4+200)
            elif area in (3,4): result.update(family='D', value=((value>>1)&0x1fff)+(1000 if area==4 else 0))
            elif area in (8,9,10,11):
                result.update(family='D', value=((value>>1)&0x1fff)+(8000 if area in (8,9) else 0), bit=(second>>6)&15)
            else: result.update(family='R', value=value>>1)
            result['index'] = (second>>8)&7 if result['family']=='R' else (second>>6)&7
        elif cls == 4:
            result.update(family='I' if second&0x200 else 'P', value=((first&255)|((second&63)<<8))>>1,
                          index=(second>>6)&7)
        elif cls == 5:
            if ascii_literal and not double:
                result.update(family='A', value=value)
                return result, 1
            pairs = area + 1
            self.need(words, at, 2*pairs)
            text = bytes(word & 255 for word in words[at:at+2*pairs]) + b'\0'
            result.update(family='"', value=0, string=text)
            return result, pairs
        elif cls == 6:
            result.update(family='G', value=(first&255)|((second&127)<<8), unit=(second>>10)&7,
                          index=(second>>7)&7)
        else:
            raise OperandRefused('Modern operand class absent')
        return result, 2 if double else 1

    @staticmethod
    def map_word(state, at, descriptor, *, double=False):
        family, value = descriptor['family'], descriptor['value']
        if family is None or value is None:
            raise Unsupported('Uninitialized native descriptor is not reconstructed')
        if double:
            state[at],state[at+1],state[at+9] = 1,0xf0,0xf0
        elif state[at+2] == 255:
            state[at],state[at+1] = 0,0xf0
        if family == '"':
            for dest in (at,at+8) if double else (at,):
                state[dest+3:dest+8] = bytes((255,0,0,255,255))
            return
        marker = descriptor['bit'] if family in ('D','R') else descriptor['unit'] if family=='G' else descriptor['group']
        index = (descriptor['index'] | (0x40 if descriptor['index_family']=='Z' else 0x20)) if descriptor['index_family'] else 255
        state[at+3],state[at+6],state[at+7] = ord(family),marker,index
        struct.pack_into('<H',state,at+4,value&65535)
        if double:
            state[at+11],state[at+14],state[at+15] = ord(family),marker,index
            struct.pack_into('<H',state,at+12,(value>>16)&65535 if family in 'KHEF' else value&65535)

    def basic(self, header, words):
        count, extent, kind, first = header['operands'],header['words'],header['kind'],words[0]
        if count == 0:
            return []
        if kind == 0:
            area = first & 0xf00
            if area & 0x800: value,family=first&0x3ff,'I'
            elif area & 0x400: value,family=9000+(first&255),'P'
            elif area == 0: value,family=first&255,'P'
            else:
                self.need(words,0,2)
                value,family=(first&255)|((words[1]&15)<<8),'P'
            return [self.descriptor(family,value)]
        if kind in (23,24):
            self.need(words,0,2)
            nesting=self.descriptor('N',words[1]&15)
            if kind==24:return [nesting]
            if extent==3:
                self.need(words,0,3)
                return [nesting,self.extended(words[2])]
            if extent==4:
                return [nesting,self.word(words,2)[0]]
            raise Unsupported('Uninspected MC descriptor form')
        if extent==1 and count==1:return [self.compact(first)]
        if extent==2 and count==1:
            self.need(words,0,2)
            return [self.extended(words[1])]
        if extent==3 and count==1:
            try:return [self.word(words,1)[0]]
            except OperandRefused:raise Unsupported('Basic word reader maps an uninitialized refused descriptor')
        if kind==9 and count==2:
            if extent==3:
                return [self.compact(first),self.word(words,1)[0]]
            if extent==4:
                self.need(words,0,4)
                area=first&0xf00
                timer=self.descriptor('T' if area in (0x400,0x500) else 'C',first&(0x1ff if area in (0x400,0x500) else 255))
                timer.update(index_family='V' if words[1]&1 else 'Z',index=(words[1]>>1)&7)
                return [timer,self.word(words,2)[0]]
            if extent==5:
                return [self.compact(first),self.word(words,1,double=True)[0]]
        raise Unsupported('Native basic descriptor combination uninspected')

    def record(self, raw):
        if not raw or len(raw)%2 or len(raw)>512:
            raise Unsupported('Machine fragment must have bounded WORD framing')
        words=list(struct.unpack('<'+'H'*(len(raw)//2),raw))
        state,aux=bytearray(b'\xff'*88),bytearray(68)
        try:
            header=self.header(words[0])
            state[1],state[2]=header['flags'],header['kind']
            count=header['words']
            if words[0]==0xb40f:
                state[1],state[2],count=0,10,1
            elif header['kind'] in (48,49):
                state[3]=255;struct.pack_into('<H',state,4,header['function'])
                if header['pulse']:state[7]=16
                at,position,string_offset=1,8,0
                for i in range(header['operands']):
                    descriptor,units=self.word(words,at,double=header['kind']==49,ascii_literal=header['function']==76)
                    if descriptor['family']=='"' and header['kind']==48:
                        if string_offset>68-34:raise OperandRefused('Modern auxiliary string capacity exceeded')
                        text=descriptor['string'].split(b'\0',1)[0]+b'\0'
                        aux[string_offset:string_offset+len(text)]=text
                        state[position:position+8]=bytes((0,0xf0,255,34,string_offset//34,0,255,255))
                        string_offset+=34;position+=8
                    else:
                        needed=16 if header['kind']==49 else 8
                        if position+needed>88:raise Unsupported('Modern operand cell extent exceeds inspected state')
                        self.map_word(state,position,descriptor,double=header['kind']==49)
                        position+=8*units
                    at+=2*units
                count=17 if header['kind']==49 and header['function']==152 else at
            else:
                descriptors=self.basic(header,words)
                kind=header['kind']
                if descriptors:
                    if kind in tuple(range(7))+(25,40,41,42,43,44,45):
                        self.map_word(state,0,descriptors[0])
                        if kind==0 and descriptors[0]['family']=='P' and descriptors[0]['value']>=256:
                            count=1 if descriptors[0]['value']>=9000 else 2
                    elif kind in (17,18,21,22,24):self.map_word(state,8,descriptors[0])
                    elif kind==23:
                        self.map_word(state,8,descriptors[0]);self.map_word(state,16,descriptors[1])
                    elif kind==9:
                        self.map_word(state,0,descriptors[0])
                        if header['operands']==2:
                            self.map_word(state,8,descriptors[1],double=descriptors[0]['family']=='C' and descriptors[0]['value']>=200)
            if 2*count>len(raw):raise Unsupported('Native word count exceeds bounded machine fragment')
            return dict(raw_machine=raw.hex(),words=count,cells=state.hex(),auxiliary=aux.hex(),
                        handling='decoded-native-machine/projection-not-original-raw',remaining_bytes=len(raw)-2*count)
        except OperandRefused as exc:
            return dict(raw_machine=raw.hex(),words=0,cells=state.hex(),auxiliary=aux.hex(),
                        handling='native-decoder-refused',reason=str(exc))
