"""Inspected SFC token extraction/classification, distinct from ladder names."""
from source_fx_operand_rules import Unsupported


def instruction_class(family, variant):
    if family not in (0x42,0x62,0x6c):
        return 20
    key = family * 256 + variant
    specials = {0x4201:6, 0x6c0a:5, 0x6200:4, 0x4200:3}
    if key in specials:
        return specials[key]
    if 0x6c0f <= key <= 0x6c1c:
        return 1
    if 0x6c04 <= key <= 0x6c22:
        return 2
    return 0 if key == 0x6c03 else 7


def parse(raw, offset, initial):
    """RVA 5f3cf/5fbbc; initial output fields are caller input state.

    The native reader always peeks four bytes, including across a short token
    boundary. The two WORD value bytes have meaning as a reference only for
    the separately classified SFC reference token. EOF preserves other slots.
    """
    if offset < 0 or offset >= len(raw):
        raise Unsupported('SFC cursor outside owned source extent')
    framed = raw[offset]
    state = dict(initial)
    state['length'] = framed
    if framed == 0:
        return dict(result=0, primitive_result=0, offset_after=offset, fields=state)
    if offset + framed > len(raw) or offset + 4 > len(raw):
        raise Unsupported('SFC fixed peek or framed token exceeds owned input')
    if raw[offset + framed - 1] != framed:
        return dict(result=-1, primitive_result=-1, offset_after=offset, fields=state)
    family, variant = raw[offset + 1], raw[offset + 3]
    word = raw[offset + 2] if framed == 4 else int.from_bytes(raw[offset + 2:offset + 4],'little')
    state.update(family=family,variant=variant,value=word)
    primitive = 1 if family < 0x90 else 2
    result = instruction_class(family,variant) if primitive == 1 else {0x98:10,0x99:11,0xdc:12}.get(family,13)
    return dict(result=result,primitive_result=primitive,offset_after=offset + framed,fields=state)
