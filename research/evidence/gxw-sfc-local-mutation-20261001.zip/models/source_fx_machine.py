"""Bounded FX mode-9 machine emission from raw-preserved instruction cells.

These native routines encode addresses; they do not validate PLC ranges or
execute a program. Undefined output cells are explicit None words, not zeros.
"""
import json
import struct

from source_fx_instruction_cells import FXInstructionCells, P
from source_fx_operand_rules import Unsupported


class EmissionRefused(Exception):
    """The inspected native dispatcher returns -1 for this representation."""


class FXMachine:
    def __init__(self, tables=None, cells=None):
        self.tables = tables if tables is not None else json.loads((P / 'fx-machine-tables-20261001-v1.json').read_text(encoding='utf-8'))
        if (self.tables['file_version'], self.tables['cpu'], self.tables['emission_mode']) != ('15.31', 521, 9):
            raise Unsupported('Unmeasured machine emission context')
        self.cells = cells if cells is not None else FXInstructionCells()
        self.applications = self.tables['applications']
        self.classes = self.tables['classes']

    def device_class(self, family):
        return self.classes.get(family, {}).get('class_id', 0)

    @staticmethod
    def fields(cell):
        return chr(cell[3]), int.from_bytes(cell[4:6], 'little'), cell[6], cell[7]

    @staticmethod
    def index(flags):
        mode, value = (flags >> 5) & 3, flags & 15
        return (0x8000 | (mode << 12), value) if mode in (1, 2) else (0x8000, 0)

    def gate(self, cell, basic=False):
        family, value, selector, flags = self.fields(cell)
        if cell[3] == 255:
            return
        kind = self.device_class(family)
        if not kind or family in ('"', 'G') or (kind == 2 and selector != 255):
            raise EmissionRefused('Mode-9 operand class or selector refused')
        indexed = flags != 255 and (flags & 0x60) != 0
        if basic and indexed:
            raise EmissionRefused('Mode-9 basic operand index refused')

    def compact(self, cell):
        family, value, selector, flags = self.fields(cell)
        if family in ('X', 'Y'):
            base = 0x400 if family == 'X' else 0x500
            return (1, value | base) if value <= 255 else (2, (value - 256) | (base + 0x2000))
        if family == 'S':
            return (1, value) if value <= 1023 else (2, value | 0x1000)
        if family == 'T':
            return 1, value | 0x600
        if family == 'C':
            return 1, value | 0xe00
        if family == 'M':
            if value <= 1535:
                return 1, value | 0x800
            if 8000 <= value <= 8255:
                return 1, (value - 8000) | 0xf00
            if 1536 <= value <= 3583:
                return 2, (value - 1536) | 0x2800
            if 8256 <= value <= 8511:
                return 2, (value - 8256) | 0x1000
            return 3, ((value - 3584) | 0x3000) & 0xffff
        if family == '?':
            return 1, 0xffff
        raise EmissionRefused('No compact native bit encoding')

    @staticmethod
    def index_address(family, value):
        z = (0x1f5c, 0x1ff6, 0x1ff8, 0x1ffa, 0x1ffc, 0x1ffe, 0x2000, 0x2002)
        v = (0x1f5d, 0x1ff7, 0x1ff9, 0x1ffb, 0x1ffd, 0x1fff, 0x2001, 0x2003)
        signed = value if value < 32768 else value - 65536
        return (v if family == 'V' else z)[signed] if 0 <= signed <= 7 else 0x203f

    def word_operand(self, cell):
        self.gate(cell)
        family, value, selector, flags = self.fields(cell)
        index, number = self.index(flags)
        if family in ('K', 'H'):
            return [(value & 255) | index | (0x200 if family == 'H' else 0), (value >> 8) | 0x8000 | (number << 8)]
        if family in ('P', 'I'):
            encoded = (value << 1) & 0xffff
            return [0x8800 | (encoded & 255), 0x8200 | (encoded >> 8)] if family == 'I' else [index | 0x800 | (encoded & 255), 0x8000 | (encoded >> 8) | (number << 6)]
        if family == 'R':
            if selector != 255:
                raise EmissionRefused('R selector refused')
            encoded = (value << 1) & 0xffff
            return [index | 0x600 | (encoded & 255), 0x9800 | (encoded >> 8) | (number << 8)]
        if family in ('D', 'T', 'C', 'Z', 'V'):
            if family in ('Z', 'V'):
                family, value = 'D', self.index_address(family, value)
            if family == 'T':
                area = 0x8200
            elif family == 'C':
                area = 0x8400
                if value >= 200:
                    value = (2 * value - 0x90) & 0xffff
            elif value < 1000:
                area = 0x8600
            elif value < 8000:
                area = 0x8800
                if selector == 255:
                    value = (value - 1000) & 0xffff
            else:
                area, value = 0x8000, (value - 8000) & 0xffff
            if family == 'D' and selector != 255:
                area = (0x9000 if area == 0x8000 else 0x9400) | ((selector & 15) << 6)
            encoded = (value << 1) & 0xffff
            return [(encoded & 255) | index | 0x8600, (encoded >> 8) | area | (number << 6)]
        if family in ('M', 'S', 'X', 'Y'):
            _, encoded = self.compact(cell)
            return [(encoded & 255) | index | 0x8400, (encoded >> 8) | 0x8000 | (number << 6) | (0 if selector == 255 else (selector & 15) << 9)]
        if family == 'A':
            return [0x8a00 | (value & 255), 0x8000 | (value >> 8)]
        if cell[3] == 255 or family == '?':
            return [None, None]
        raise EmissionRefused('Native word operand emitter has no branch')

    def double_operand(self, cell, high):
        self.gate(cell)
        family, value, selector, flags = self.fields(cell)
        hi = int.from_bytes(high[4:6], 'little')
        if family in ('K', 'H'):
            return self.word_operand(cell) + [0x8000 | (hi & 255), 0x8000 | (hi >> 8)]
        if family in ('E', 'F'):
            return [0x8000 | (value & 255) | (0x200 if family == 'F' else 0), 0x9000 | (value >> 8),
                    0x8000 | (hi & 255), 0x8000 | (hi >> 8)]
        if cell[3] == 255 or family == '?':
            return [None] * 4
        return self.word_operand(cell) + [0x8000, 0x8000]

    def basic(self, cell):
        self.gate(cell, basic=True)
        family, value, selector, flags = self.fields(cell)
        kind = self.device_class(family)
        if family in ('M', 'S', 'X', 'Y') and selector != 255:
            raise EmissionRefused('Basic grouping refused')
        if kind == 7:
            n, value = self.compact(cell)
            return n, [value]
        if kind not in (1, 3) or selector != 255:
            raise EmissionRefused('No native basic address encoding')
        n, value = self.compact(cell)
        if n == 2:
            value |= 0x8000
        return n, self.word_operand(cell) if n == 3 else [value]

    def operation(self, kind, selector1, selector2=0):
        row = next((r for r in self.tables['operations'] if (r['kind'], r['selector1'], r['selector2']) == (kind, selector1, selector2)), None)
        return row['value'] if row else 0

    def emit(self, raw_cells, auxiliary=None):
        state = bytearray(raw_cells)
        if len(state) != 88 or auxiliary is not None and len(auxiliary) != 68:
            raise Unsupported('Native emitter allocation extent differs')
        kind = state[2]
        def cell(i):
            if not 0 <= i <= 10:
                raise Unsupported('Native operand access exceeds the eleven cells')
            return state[8 * i:8 * (i + 1)]
        try:
            if kind in (48, 49):
                function = int.from_bytes(state[4:6], 'little')
                if function >= 310:
                    raise EmissionRefused('Application function outside table')
                entry = self.applications[function]
                if not entry['flags'] & (2 if kind == 49 else 1) or kind == 49 and entry['arity'] == 0:
                    raise EmissionRefused('Application mode is not enabled')
                if kind == 49 and function == 152:
                    state[1] = 0x91
                    for i in range(5, 9):
                        state[i * 8 + 1:i * 8 + 6] = bytes.fromhex('f0ff4b0000')
                opcode = (16 + 2 * function + (kind == 49)) | (0x1000 if state[7] == 16 else 0)
                words = [opcode]
                for i in range(entry['arity']):
                    at = 1 + i * (2 if kind == 49 else 1)
                    words += self.double_operand(cell(at), cell(at + 1)) if kind == 49 else self.word_operand(cell(at))
            elif kind in (1, 2, 3, 4, 5, 6, 40, 41, 42, 43, 44, 45):
                n, operand = self.basic(cell(0))
                if n == 1 and kind in range(40, 46):
                    n = 2
                words = [self.operation(kind, n)]
                if n == 1:
                    words[0] |= operand[0]
                elif n == 2:
                    words += [operand[0] | 0x8000]
                elif n == 3:
                    words += operand[:2]
            elif kind == 0:
                family, value, _, _ = self.fields(cell(0))
                if family == 'P':
                    words = [0xb000 | value] if value <= 255 else [0xb100 | (value & 255), 0xb200 | (value >> 8)]
                elif family == 'I':
                    words = [0xb800 | value]
                elif family == '?':
                    words = [0xb000]
                else:
                    raise EmissionRefused('Label family refused')
            elif kind == 9:
                family, value, _, flags = self.fields(cell(0))
                n, operand = self.basic(cell(0))
                if family == 'S' or family == 'M' and value >= 8000:
                    n = 2
                words = [operand[0] | 0xc000] if n == 1 else ([5 if family == 'S' else 2, operand[0] | 0x8000] if n == 2 else [0x202] + [w | 0x8000 for w in operand[:2]])
                if family in ('T', 'C'):
                    preset = cell(1)
                    if chr(preset[3]) not in ('?', 'D', 'K', 'R'):
                        raise EmissionRefused('Preset family refused')
                    words = [value | (0x600 if family == 'T' else 0xe00)]
                    words += self.double_operand(preset, cell(2)) if family == 'C' and value >= 200 else self.word_operand(preset)
            elif kind in (17, 18):
                operand_cell = cell(1)
                family, value, _, _ = self.fields(operand_cell)
                if kind == 18 and family in ('D', 'R', 'V', 'Z'):
                    words = [0xd] + [w | 0x8000 for w in self.word_operand(operand_cell)]
                else:
                    n, operand = self.basic(operand_cell)
                    if n == 3:
                        words = [(0x203 if kind == 17 else 0x20c if family in ('T', 'C') else 0x204)] + [w | 0x8000 for w in operand[:2]]
                    elif family in ('Y', 'M', 'S'):
                        if family == 'S' or family == 'M' and value >= 8000:
                            n = 2
                        words = [(0xd000 if kind == 17 else 0xe000) | operand[0]] if n == 1 else [6 if family == 'S' and kind == 17 else 7 if family == 'S' else 3 if kind == 17 else 4, operand[0] | 0x8000]
                    elif kind == 18 and family in ('T', 'C'):
                        words = [0xc, operand[0] | 0x8000]
                    else:
                        raise EmissionRefused('Set/reset family refused')
            elif kind in (21, 22, 23):
                offset = 2 if kind == 23 else 1
                family, value, _, _ = self.fields(cell(offset))
                if family == 'M' and value >= 8000:
                    raise EmissionRefused('Pulse/MC special M address refused')
                n, operand = self.basic(cell(offset))
                prefix = 0xa if kind == 23 else 9 if kind == 21 else 8
                words = [prefix | (0x200 if n == 3 else 0)]
                if kind == 23:
                    if chr(cell(1)[3]) not in ('N', '?'):
                        raise EmissionRefused('MC control family refused')
                    words += [0x8000 | cell(1)[4]]
                words += [w | 0x8000 for w in (operand[:2] if n == 3 else operand[:1])]
            elif kind == 24:
                if chr(cell(1)[3]) not in ('N', '?'):
                    raise EmissionRefused('MCR control family refused')
                words = [0xb, 0x8000 | (cell(1)[4] if cell(1)[3] == ord('N') else 0)]
            elif kind == 25:
                value = int.from_bytes(cell(0)[4:6], 'little')
                if value <= 1021:
                    words = [0xf000 | value]
                elif value <= 4095:
                    words = [0xe, 0x8000 | value | (0x1000 if value >= 1024 else 0)]
                else:
                    raise EmissionRefused('Step family refused')
            else:
                fixed = {7:0xfff8, 8:0xfff9, 10:0xffff, 11:0xb800, 13:0xfffa, 14:0xfffb,
                         15:0xfffc, 16:0xf, 26:0xf7ff, 38:0x264, 39:0x266, 46:0xfffd}
                if kind not in fixed:
                    raise Unsupported('Unmeasured native emission kind')
                words = [fixed[kind]]
            words = [w & 0xffff if w is not None else None for w in words]
            exact = all(w is not None for w in words)
            return dict(words=len(words), machine_words=words, machine_output=struct.pack('<' + 'H' * len(words), *words).hex() if exact else None,
                        cells_after=state.hex(), handling='decoded-native-emission' if exact else 'partially-decoded/undefined-output-words')
        except EmissionRefused as exc:
            return dict(words=-1, machine_words=[], machine_output='', cells_after=state.hex(),
                        handling='native-emitter-refused', reason=str(exc))

    def record(self, raw):
        projection = self.cells.record(raw)
        emission = self.emit(bytes.fromhex(projection['native_cells']), bytes.fromhex(projection['auxiliary']))
        return dict(**projection, emission=emission)

    def width_rewrite(self, raw):
        """Predict the 3e534 rewrite only when its earlier checks reach emission.

        This operation preserves all operand bytes. A short header with one
        machine word is deliberately preserved, including its uninterpreted
        last byte; the native routine does not canonicalize that byte.
        """
        record = self.record(raw)
        words = record['emission']['words']
        if words <= 0:
            return dict(candidate=None, handling='native-emitter-refused', emission=record['emission'])
        if words > 255:
            raise Unsupported('Unmeasured header width field overflow')
        header = raw[:raw[0]]
        rewritten = header
        if len(header) == 3 and words > 1:
            rewritten = bytes([4, header[1], words, 4])
        elif len(header) == 4 and words == 1:
            rewritten = bytes([3, header[1], 3])
        elif len(header) >= 4:
            rewritten = header[:2] + bytes([words]) + header[3:]
        operands = raw[len(header):]
        candidate = rewritten + operands
        return dict(candidate=candidate.hex(), raw_header=header.hex(), candidate_header=rewritten.hex(),
                    operand_bytes=operands.hex(), operand_bytes_preserved=candidate[len(rewritten):] == operands,
                    machine_words=words, handling='bounded-width-rewrite/earlier-public-checks-not-predicted')
