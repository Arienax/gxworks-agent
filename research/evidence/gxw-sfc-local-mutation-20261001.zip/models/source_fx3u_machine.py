"""Separate prospective FX3U CPU-520/mode-8 profile of inspected routines.

The instruction mapping routines do not branch on CPU. Mode-specific gates
and basic index paths are kept separate from the frozen mode-9 model.
"""
import json

from source_fx_machine import FXMachine, EmissionRefused
from source_fx_instruction_cells import FXInstructionCells, P
from source_fx_operand_rules import Unsupported


class FX3UCells(FXInstructionCells):
    def __init__(self, tables):
        if (tables['file_version'], tables['cpu']) != ('15.31', 520):
            raise Unsupported('Unmeasured FX3U instruction context')
        self.tables, self.opcodes, self.devices = tables, tables['opcodes'], tables['devices']


class FX3UMachine(FXMachine):
    def __init__(self, tables, cells):
        if (tables['file_version'], tables['cpu'], tables['emission_mode']) != ('15.31', 520, 8):
            raise Unsupported('Unmeasured FX3U machine context')
        self.tables, self.cells = tables, cells
        self.applications, self.classes = tables['applications'], tables['classes']

    def gate(self, cell, basic=False):
        # Native 3360c and 33690 apply their extra gates only in modes 9/10.
        return

    def basic(self, cell):
        family, value, selector, flags = self.fields(cell)
        kind = self.device_class(family)
        if family in ('M', 'S', 'X', 'Y') and selector != 255:
            raise EmissionRefused('Basic grouping refused')
        if kind == 7:
            n, value = self.compact(cell)
            return n, [value]
        indexed = flags != 255 and flags & 0x60 != 0
        if not indexed and selector == 255:
            if kind not in (1, 3):
                raise EmissionRefused('No native basic address encoding')
            n, value = self.compact(cell)
            if n == 2:
                value |= 0x8000
            return n, self.word_operand(cell) if n == 3 else [value]
        if indexed and family not in ('C', 'T') and kind != 1:
            raise EmissionRefused('Indexed basic family refused')
        return 3, self.word_operand(cell)

    def emit(self, raw_cells, auxiliary=None):
        state = bytes(raw_cells)
        if len(state) == 88 and state[2] == 9:
            family, value, _, flags = self.fields(state[:8])
            indexed = flags != 255 and flags & 0x60 != 0
            if indexed and (family == 'T' or family == 'C' and value < 200):
                try:
                    self.basic(state[:8])
                    preset = state[8:16]
                    if chr(preset[3]) not in ('?', 'D', 'K', 'R'):
                        raise EmissionRefused('Preset family refused')
                    index_name = 'V' if flags & 0x20 else 'Z' if flags & 0x40 else ''
                    control = (((flags & 15) | 0xc000) << 1 | (index_name == 'V')) & 0xffff
                    words = [value | (0x400 if family == 'T' else 0xc00), control] + self.word_operand(preset)
                    import struct
                    return dict(words=len(words), machine_words=words, machine_output=struct.pack('<4H', *words).hex(),
                                cells_after=state.hex(), handling='decoded-native-emission')
                except EmissionRefused as exc:
                    return dict(words=-1, machine_words=[], machine_output='', cells_after=state.hex(),
                                handling='native-emitter-refused', reason=str(exc))
        return super().emit(raw_cells, auxiliary)
