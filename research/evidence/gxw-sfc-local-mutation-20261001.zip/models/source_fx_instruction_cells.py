"""Bounded native FX instruction state: eleven raw eight-byte cells.

This is an observed lowering representation, not a lossless substitute for
PCode tokens or a PLC execution model. Every source token remains in the result.
"""
from pathlib import Path
import json
import struct

from source_fx_operand_rules import Unsupported

P = Path(__file__).resolve().parent
TABLE_PATH = P / 'fx-instruction-cell-tables-20261001-v1.json'


class FXInstructionCells:
    def __init__(self, tables=None):
        self.tables = tables if tables is not None else json.loads(TABLE_PATH.read_text(encoding='utf-8'))
        if (self.tables['file_version'], self.tables['cpu']) != ('15.31', 521):
            raise Unsupported('Unmeasured instruction-cell context')
        self.opcodes = self.tables['opcodes']
        self.devices = self.tables['devices']

    def instruction(self, raw_header, initial=None):
        if len(raw_header) < 2 or raw_header[0] != len(raw_header):
            raise Unsupported('Unframed opcode header')
        state = bytearray(initial if initial is not None else b'\xff' * 88)
        if len(state) != 88:
            raise Unsupported('Instruction state extent differs')
        kind, flags, function, extra = 0xff, 0xff, 0xffff, 0
        family = raw_header[1]
        if len(raw_header) == 2:
            kind, flags = 10, 0
        elif len(raw_header) in (3, 4) and family == 0x3c:
            kind, flags = 0, 0
        else:
            variant = 0 if len(raw_header) in (3, 4) else raw_header[3]
            if len(raw_header) == 6 and raw_header[4] == 2:
                extra = 1
            found = next((r for r in self.opcodes if (r['family'], r['variant']) == (family, variant)), None)
            if found is None:
                raise Unsupported('No native opcode mapping')
            kind, flags, function = found['kind'], found['flags'], found['function']
            if family == 0x40 and len(raw_header) == 6:
                function = (function + 8 * raw_header[4] - 128) & 0xffff
        state[2], state[1] = kind, flags
        count = 0
        if kind in (0x30, 0x31):
            struct.pack_into('<H', state, 4, function)
            if extra:
                state[7] = 0x10
            count = 1
        elif kind in (0x11, 0x12, 0x15, 0x16, 0x17, 0x18):
            count = 1
        return bytes(state), count

    def token(self, raw, initial, count, auxiliary=None):
        if len(initial) != 88 or not 0 <= count <= 10:
            raise Unsupported('Cell counter/extent outside caller allocation')
        if len(raw) < 4 or raw[0] != len(raw) or raw[-1] != len(raw) or not 0x90 <= raw[1] <= 0xff:
            raise Unsupported('Unframed operand token')
        state = bytearray(initial)
        aux = bytes(68) if auxiliary is None else bytes(auxiliary)
        if len(aux) != 68:
            raise Unsupported('Auxiliary extent differs')
        info = self.devices[str(raw[1])]
        if not info['recognized']:
            raise Unsupported('Native mapping silently skips an unknown token; raw must remain opaque')
        category = info['category']
        name = info['name']
        if category not in (0, 4, 5, 6, 8, 9, 10, 12):
            raise Unsupported(f'Unmeasured cell mapping category {category}')
        if not name:
            raise Unsupported('Device name is not mapped')
        at = count * 8
        def require_two():
            if at + 16 > 88:
                raise Unsupported('Two-cell operand exceeds caller allocation')
        def word(offset, value):
            struct.pack_into('<H', state, offset, value & 0xffff)
        def getword(offset):
            return struct.unpack_from('<H', state, offset)[0]
        def signedword(offset):
            return struct.unpack_from('<h', state, offset)[0]
        if category in (0, 4, 5):
            if getword(at + 4) != 0xffff:
                raise Unsupported('A numeric cell is already populated')
            if len(raw) not in (4, 5, 6, 7):
                raise Unsupported('Numeric token outside observed payload sizes')
            value = int.from_bytes(raw[2:-1], 'little')
            lo, hi = value & 0xffff, (value >> 16) & 0xffff
            pair = state[2] == 0x31 or (state[2] == 9 and state[3] == ord('C')
                    and signedword(4) >= 200 and category != 0)
            if not pair:
                if count:
                    state[at] = 0
                state[at + 3] = ord(name[0])
                word(at + 4, lo)
                if state[2] == 9 and state[3] in (ord('C'), ord('T')):
                    state[1] = 9
                count += 1
            else:
                require_two()
                if count:
                    state[at] = 1
                state[at + 3] = state[at + 11] = ord(name[0])
                word(at + 4, lo)
                word(at + 12, lo if category == 0 else hi)
                if state[2] == 9:
                    if state[3] == ord('C') and signedword(4) >= 200 and raw[1] == 0xe8 and lo & 0x8000:
                        word(at + 12, 0xffff)
                    state[1] = 10
                count += 2
        elif category == 6:
            if len(raw) != 7:
                raise Unsupported('Float cell requires the observed four payload bytes')
            require_two()
            state[at], state[at + 8] = 1, 0
            state[at + 3] = state[at + 11] = ord(name[0])
            word(at + 4, int.from_bytes(raw[2:4], 'little'))
            word(at + 12, int.from_bytes(raw[4:6], 'little'))
            count += 2
        elif category == 8:
            if state[at + 7] != 0xff:
                raise Unsupported('Index modifiers cannot overwrite a populated native cell')
            index_flags = raw[2] | (0x20 if name == 'V' else 0x40)
            state[at + 7] = index_flags
            if state[2] == 0x31:
                require_two()
                state[at + 15] = index_flags
        elif category in (9, 10):
            if state[at + 6] != 0xff:
                raise Unsupported('Grouping/bit modifiers cannot overwrite a populated native cell')
            state[at + 6] = raw[2]
            if state[2] == 0x31:
                require_two()
                state[at + 14] = raw[2]
        elif category == 12:
            if state[at] != 0xff or state[at + 3] != 0xff or getword(at + 4) != 0xffff or state[at + 6] != 0xff:
                raise Unsupported('Prefix cell has populated fields')
            if len(raw) not in (4, 5):
                raise Unsupported('Unmeasured prefix payload width')
            value = int.from_bytes(raw[2:-1], 'little')
            state[at] = int(state[2] == 0x31)
            state[at + 3] = ord(name[0])
            word(at + 4, value)
            if state[2] == 0x31:
                require_two()
                state[at + 8] = 0
                state[at + 11] = ord(name[0])
                word(at + 12, value)
                count += 2
            else:
                count += 1
        return bytes(state), count, aux

    def record(self, raw):
        if not raw or raw[0] > len(raw):
            raise Unsupported('Unframed instruction record')
        header = raw[:raw[0]]
        state, count = self.instruction(header)
        at, tokens, aux = len(header), [], bytes(68)
        while at < len(raw):
            length = raw[at]
            if length < 4 or at + length > len(raw):
                raise Unsupported('Operand token extends beyond the raw record')
            token = raw[at:at + length]
            state, count, aux = self.token(token, state, count, aux)
            tokens.append(dict(offset=at, raw=token.hex()))
            at += length
        return dict(raw=raw.hex(), raw_header=header.hex(), raw_tokens=tokens, native_cells=state.hex(),
                    used_cells=count, auxiliary=aux.hex(), handling='raw-preserved with bounded native lowering projection')
