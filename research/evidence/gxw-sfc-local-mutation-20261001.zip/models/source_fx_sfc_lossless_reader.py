"""SFC context annotations over the frozen physical FX byte partition.

Control ownership and lexical instructions are independent annotations. The
partition, including unknown records/remainders, is the reconstruction source.
"""
from source_fx_lossless_reader import FXLosslessReader
from source_fx_operand_rules import Unsupported
from source_fx_sfc_controls import control,step_type
from source_fx_sfc_tokens import parse


class FXSfcLosslessReader:
    def __init__(self):
        self.lexical = FXLosslessReader()

    def read(self, body, *, cpu=520):
        if cpu != 520:
            raise Unsupported('Unmeasured SFC control context CPU')
        image = self.lexical.read(body,cpu=cpu)
        initial_coverage = dict(image['coverage'])
        nodes = []
        padded = body + b'\0' * 8
        initial = dict(key=0,number=0,substep=0,program_length=0,program_offset=0)
        for record in image['records']:
            offset = record['offset']
            indexes = record['token_indexes']
            header = bytes.fromhex(image['physical_tokens'][indexes[0]]['raw'])
            if len(header) != 5 or header[1] >= 0x90:
                continue
            token = parse(padded,offset,dict(family=0,variant=0,value=0,length=0))
            key = token['fields']['family'] * 256 + token['fields']['variant']
            kind = {1:'step',2:'transition',3:'selective_target',4:'target',6:'parallel_target'}.get(token['result'])
            annotation = None
            if kind:
                try:
                    decoded = control(padded,offset,kind,initial)
                    if decoded['result'] != 0:
                        raise Unsupported('Native control reference class refused')
                    fields = decoded['fields']
                    after = fields['program_offset'] if kind in ('step','transition') else decoded['offset_after']
                    if after != offset + len(bytes.fromhex(record['raw'])):
                        raise Unsupported('Control references do not own exactly their physical record')
                    annotation = dict(kind=kind,key=key,number=fields['number'],offset=offset,record_index=record['index'])
                    if kind in ('step','transition'):
                        annotation.update(program_offset=after,program_length=fields['program_length'],
                            program_raw=body[after:after + fields['program_length']].hex())
                    if kind == 'step':
                        annotation.update(substep=fields['substep'],native_graph_type=step_type(key))
                except Unsupported as exc:
                    record['sfc_gap'] = str(exc)
                    continue
            elif key in (0x6c00,0x6c01,0x6c02,0x6c03,0x6c0a):
                kind = {0x6c00:'program-start',0x6c01:'program-end',0x6c02:'block-start',0x6c03:'block-end',0x6c0a:'segment-end'}[key]
                expected = 2 if key == 0x6c02 else 1
                if len(indexes) != expected:
                    record['sfc_gap'] = 'Wrapper/end record has unowned extra tokens'
                    continue
                annotation = dict(kind=kind,key=key,offset=offset,record_index=record['index'])
                if key == 0x6c02:
                    reference = parse(padded,offset + 5,dict(family=0,variant=0,value=0,length=0))
                    if reference['result'] != 12:
                        record['sfc_gap'] = 'Block wrapper has no BL reference'
                        continue
                    annotation['number'] = reference['fields']['value']
            if annotation is not None:
                nodes.append(annotation)
                record.update(handling='decoded-sfc-control-ownership',critical_gap=False,sfc_projection=annotation)
        for node in nodes:
            if node['kind'] not in ('step','transition'):
                continue
            start,end = node['program_offset'],node['program_offset'] + node['program_length']
            owned = []
            for record in image['records']:
                ro, re = record['offset'],record['offset'] + len(bytes.fromhex(record['raw']))
                if start <= ro < end:
                    if re > end or 'inline_owner' in record:
                        raise Unsupported('SFC inline program overlaps a physical record/owner')
                    record['inline_owner'] = dict(kind=node['kind'],control_offset=node['offset'],reference=node['number'])
                    owned.append(record['index'])
            node['inline_records'] = owned
        image.update(read_context='sfc-control-and-inline-code',sfc_nodes=nodes,ordinary_reader_coverage=initial_coverage,
            coverage=dict(raw_bytes=len(body),physical_tokens=len(image['physical_tokens']),records=len(image['records']),
                decoded_instructions=sum(r['handling']=='decoded-native-record' for r in image['records']),
                decoded_control_ownership=len(nodes),inline_programs=sum(n['kind'] in ('step','transition') for n in nodes),
                inline_bytes=sum(n.get('program_length',0) for n in nodes),critical_gaps=sum(r['critical_gap'] for r in image['records'])),
            scope='Native control references, inline byte ownership and ordinary lexical names; SFC execution, full graph layout, project/range acceptance and unknown source caches remain separate.')
        if self.lexical.reconstruct(image) != body:
            raise ValueError('SFC annotations changed reconstruction')
        return image

    reconstruct = staticmethod(FXLosslessReader.reconstruct)

