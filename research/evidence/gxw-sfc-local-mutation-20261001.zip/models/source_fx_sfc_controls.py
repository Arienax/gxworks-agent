"""Source model of native SFC control readers, not a PLC execution model.

RVA 5f435/5f6aa/5f5b8/5f631/5f784: control references and inline
ordinary program ownership. Unknown and incomplete inputs remain unsupported.
"""
from source_fx_operand_rules import Unsupported
from source_fx_sfc_tokens import parse

STEP_TYPES = dict(zip(range(0x6c0f, 0x6c1d), (0,5,1,2,3,4,12,13,6,11,7,8,9,10)))


def control(raw, offset, kind, initial):
    """Predict caller output writes, including preserved slots on refusal."""
    cursor = offset
    fields = dict(initial)

    def take(classified=True):
        nonlocal cursor
        row = parse(raw,cursor,dict(family=0,variant=0,value=0,length=0))
        cursor = row['offset_after']
        if row['primitive_result'] < 1:
            raise Unsupported('SFC control scans require a framed bounded delimiter')
        return row['result'] if classified else row['primitive_result'], row['fields']

    expected = dict(step=1,transition=2,selective_target=3,parallel_target=6,target=4)[kind]
    result, token = take()
    if result != expected:
        return dict(result=1,offset_after=cursor,fields=fields)
    key = token['family'] * 256 + token['variant']
    fields['key'] = key
    result, token = take()
    if result != (11 if kind == 'transition' else 10):
        return dict(result=1,offset_after=cursor,fields=fields)
    fields['number'] = token['value']
    if kind not in ('step','transition'):
        return dict(result=0,offset_after=cursor,fields=fields)
    if kind == 'step':
        fields['substep'] = 0
        extra = 10 if key in (0x6c14,0x6c1c) else 12 if key in (0x6c15,0x6c16) else None
        if extra is not None:
            result, token = take()
            if result != extra:
                return dict(result=1,offset_after=cursor,fields=fields)
            fields['substep'] = token['value']
    fields['program_offset'] = cursor
    length = 0
    while True:
        before = cursor
        result, token = take(False)
        boundary = result == 1 and token['family'] in (0x42,0x62,0x6c)
        if kind == 'step' and token['family'] == 0x6c and token['variant'] in (0x23,0x24):
            boundary = False
        if boundary:
            cursor = before
            fields['program_length'] = length
            return dict(result=0,offset_after=cursor,fields=fields)
        length = (length + token['length']) & 0xffff


def step_type(key):
    """Native graph type; the high bit here records an initial step."""
    if key not in STEP_TYPES:
        raise Unsupported('SFC step outside inspected native graph type mapping')
    return STEP_TYPES[key] | (16 if key >= 0x6c17 else 0)
