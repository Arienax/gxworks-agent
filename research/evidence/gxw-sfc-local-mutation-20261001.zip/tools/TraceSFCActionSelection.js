(()=>{
'use strict';
const attached=new Set();
function guard(f){try{return f();}catch(e){return {error:String(e)};}}
function hex(p,n){return Array.from(new Uint8Array(p.readByteArray(n)),v=>v.toString(16).padStart(2,'0')).join('');}
function location(p){const m=Process.findModuleByAddress(p);return m?{module:m.name,rva:p.sub(m.base).toString()}:null;}
function attachCodeGetter(target){
 if(attached.has(target.toString()))return;
 attached.add(target.toString());send({event:'workspace-program-reader-target',target:location(target)});
 Interceptor.attach(target,{
  onEnter(a){this.count=a[13];this.buffer=a[14];this.code=a[15];this.id=guard(()=>hex(this.context.esp.add(8),48));},
  onLeave(r){send({event:'workspace-program-read-return',target:location(target),object_id:this.id,hresult:r.toInt32(),
   code:guard(()=>this.code.readU32()),bytes:guard(()=>this.count.readU32()),
   body:guard(()=>this.buffer.isNull()?null:hex(this.buffer,Math.min(this.count.readU32(),2048)))});}
 });
}
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='dzdataabs_converter.dll')return;
 Interceptor.attach(m.base.add(0x101ea2),{
  onEnter(a){this.output=a[0];},
  onLeave(){guard(()=>{const workspace=this.output.readPointer();if(!workspace.isNull())attachCodeGetter(workspace.readPointer().add(0x69c).readPointer());});}
 });
 Interceptor.attach(m.base.add(0x107a32),{
  onEnter(a){this.object=this.context.ecx;this.code=a[1];this.number=guard(()=>this.object.add(0x58).readU32());},
  onLeave(r){send({event:'converter-selected-action-body',number:this.number,result:r.toInt32(),code:guard(()=>this.code.readU32()),
   compiled_source:guard(()=>{const length=this.object.add(0x4c).readU32();const data=this.object.add(0x48).readPointer();
     return {bytes:length,raw:length>0&&length<=2048?hex(data,length):null};})});}
 });
}});
})();
