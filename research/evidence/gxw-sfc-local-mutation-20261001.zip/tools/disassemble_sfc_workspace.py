"""Bounded static inspection of a runtime-resolved SFC workspace reader."""
from pathlib import Path
import json
import sys
ROOT=Path(__file__).resolve().parents[4]
sys.path.insert(0,str(ROOT/'research/experiments/re-tools'))
import capstone
import pefile


def main():
    start,stop=(int(value,16) for value in sys.argv[1:3])
    if not 0<=start<stop<=0x260000 or stop-start>0x3000:
        raise ValueError('Workspace code extent outside inspected image')
    path=Path('D:/GXWORKS2/DNaviZero/DataAbsorber/DZDataABS_Workspace.dll')
    pe=pefile.PE(str(path));versions=[t.entries.get(b'FileVersion') for f in pe.FileInfo for b in f if b.Key==b'StringFileInfo' for t in b.StringTable]
    if b'1.635.0.1' not in versions or path.stat().st_size!=2617344:
        raise ValueError('Uninspected workspace version/file extent')
    base=pe.OPTIONAL_HEADER.ImageBase;cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32)
    text='\n'.join(f'{i.address-base:06x} {i.mnemonic:8s} {i.op_str}' for i in cs.disasm(pe.get_data(start,stop-start),base+start))+'\n'
    target=Path(__file__).with_name(f'dz-sfc-workspace-{start:06x}-{stop:06x}-20261001.txt')
    if target.exists() and target.read_text(encoding='utf-8')!=text:raise FileExistsError('Earlier workspace disassembly differs')
    if not target.exists():target.write_text(text,encoding='utf-8')
    print(json.dumps(dict(dll=str(path),version='1.635.0.1',image_base=hex(base)),ensure_ascii=True));print(text,end='')


if __name__=='__main__':main()
