"""Bounded static inspection of the pinned source SFC converter."""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[4]
sys.path.insert(0,str(ROOT/'research/experiments/re-tools'))
import capstone
import pefile


def main():
    start,stop=(int(value,16) for value in sys.argv[1:3])
    if not 0<=start<stop<=0x120000 or stop-start>0x5000:
        raise ValueError('Disassembly extent outside inspected converter code')
    pe=pefile.PE('D:/GXWORKS2/DNaviZero/DataAbsorber/DZDataABS_Converter.dll')
    versions=[t.entries.get(b'FileVersion') for f in pe.FileInfo for b in f if b.Key==b'StringFileInfo' for t in b.StringTable]
    if b'1.635.0.1' not in versions or pe.OPTIONAL_HEADER.ImageBase!=0x60d00000:
        raise ValueError('Uninspected source converter version/base')
    cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32)
    base=pe.OPTIONAL_HEADER.ImageBase
    text='\n'.join(f'{i.address-base:05x} {i.mnemonic:8s} {i.op_str}' for i in cs.disasm(pe.get_data(start,stop-start),base+start))+'\n'
    path=Path(__file__).with_name(f'dz-sfc-assembly-{start:05x}-{stop:05x}-20261001.txt')
    if path.exists() and path.read_text(encoding='utf-8')!=text:
        raise FileExistsError('Earlier disassembly differs')
    if not path.exists():path.write_text(text,encoding='utf-8')
    print(text,end='')


if __name__=='__main__':main()
