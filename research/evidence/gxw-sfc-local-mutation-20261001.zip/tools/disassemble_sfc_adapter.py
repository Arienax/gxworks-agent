"""Bounded inspection of the installed SFC compiler adapter, without digests."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(ROOT / 'research/experiments/re-tools'))
import capstone
import pefile


def main():
    start, stop = (int(value, 16) for value in sys.argv[1:3])
    if not 0 <= start < stop <= 0x24000 or stop - start > 0x1800:
        raise ValueError('Disassembly extent outside bounded adapter code')
    path = Path('D:/GXWORKS2/DNaviZero/DataAbsorber/DZDataABS_CompilerAdapter.dll')
    pe = pefile.PE(str(path))
    versions = [t.entries.get(b'FileVersion') for f in pe.FileInfo for b in f
                if b.Key == b'StringFileInfo' for t in b.StringTable]
    if b'1.635.0.1' not in versions or pe.OPTIONAL_HEADER.ImageBase != 0x60cd0000 or path.stat().st_size != 167936:
        raise ValueError('Uninspected adapter version/base/extent')
    base = pe.OPTIONAL_HEADER.ImageBase
    cs = capstone.Cs(capstone.CS_ARCH_X86, capstone.CS_MODE_32)
    source = '\n'.join(f'{i.address-base:05x} {i.mnemonic:8s} {i.op_str}'
                       for i in cs.disasm(pe.get_data(start, stop-start), base+start)) + '\n'
    destination = Path(__file__).with_name(f'dz-sfc-adapter-{start:05x}-{stop:05x}-20261001.txt')
    if destination.exists() and destination.read_text(encoding='utf-8') != source:
        raise FileExistsError('Earlier disassembly differs')
    if not destination.exists():
        destination.write_text(source, encoding='utf-8')
    print(source, end='')


if __name__ == '__main__':
    main()
