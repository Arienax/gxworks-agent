(() => {
'use strict';
function guard(f) { try { return f(); } catch(e) { return {error:String(e)}; } }
function hex(p,n) { return Array.from(new Uint8Array(p.readByteArray(n)),v=>v.toString(16).padStart(2,'0')).join(''); }
Process.attachModuleObserver({onAdded(m) {
 const name = m.name.toLowerCase();
 if(name === 'dzdataabs_compileradapter.dll') {
  send({event:'module',name:m.name,path:m.path,base:m.base.toString(),size:m.size});
  Interceptor.attach(m.base.add(0x14c34), {
   onEnter(a) { this.code=a[1]; send({event:'adapter-sfc-entry',rva:0x14c34}); },
   onLeave(r) { send({event:'adapter-sfc-return',hresult:r.toInt32(),code:guard(()=>this.code.readU32())}); }
  });
  Interceptor.attach(m.base.add(0x6423), {
   onEnter(a) { send({event:'adapter-worker-entry',rva:0x6423}); },
   onLeave(r) { send({event:'adapter-worker-return',result:r.toInt32()}); }
  });
 }
 if(name !== 'dzdataabs_converter.dll') return;
 send({event:'module',name:m.name,path:m.path,base:m.base.toString(),size:m.size});
 Interceptor.attach(m.base.add(0x3d8a0), {
  onEnter(a) { this.count=a[1];this.output=a[2];this.code=a[3];send({event:'converter-sfc-entry',rva:0x3d8a0}); },
  onLeave(r) { send({event:'converter-sfc-return',hresult:r.toInt32(),code:guard(()=>this.code.readU32()),
   reports:guard(()=>{const count=this.count.readU32(),raw=this.output.readPointer();
    return {count,raw:count>0&&count<=16&&!raw.isNull()?hex(raw,count*68):null};})}); }
 });
 for(const [role,rva] of [['load-source-programs',0x10a7dd],['assemble-source-programs',0x10a4cf],['publish-resource-code',0x108fff]]) {
  Interceptor.attach(m.base.add(rva), {
   onEnter(a) { this.code=a[0];send({event:'sfc-stage-entry',role,rva}); },
   onLeave(r) { send({event:'sfc-stage-return',role,rva,result:r.toInt32(),code:guard(()=>this.code.readU32())}); }
  });
 }
 Interceptor.attach(m.base.add(0x112eae), {
  onEnter(a) { this.code=a[2];send({event:'sfc-internal-report-entry',type:a[0].toUInt32(),code:guard(()=>this.code.readU32()),extra:a[3].toUInt32()}); }
 });
}});
})();
