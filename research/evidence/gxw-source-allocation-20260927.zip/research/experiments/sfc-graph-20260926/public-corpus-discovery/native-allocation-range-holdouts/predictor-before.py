"""Experimental source-only allocation for observed Q direct declarations/SCPI calls.

No native output table, trace state or stored UserInfo is used to choose addresses.
This does not implement general nested types, latch classes or temporary lifetimes.
"""
import struct
from gxw.compiler_tables import parse_compiler_tables
from gxw.token_pou import parse_token_fragment
from probe_gxw_simple_fb import frame_source,observe_calls
from probe_gxw_parameters import project_allocation_ranges

def groups(raw):
 result=[]
 for token in parse_token_fragment(raw,0,len(raw)).tokens:
  if token.raw[1]<0x90:result.append([])
  if not result:raise ValueError('operand without source instruction')
  result[-1].append(token.raw)
 return result

def direct_call(frame,call):
 result={};materialized=[]
 for direction in ['input','output']:
  s=call[direction+'_fragment'];g=groups(frame.raw[s['offset']:s['offset']+s['length']])
  if len(g)!=4 or [r[0][1] for r in g]!=[0,0x20,0,0x4c]:raise ValueError('outside direct call templates')
  if g[2][1:]!=[bytes.fromhex('08df5f5452554508')] or len(g[3][0])!=5 or g[3][0][3]!=0:raise ValueError('outside word MOV template')
  pairs=[(g[0][1:],g[1][1:]),(g[3][1:-1],[g[3][-1]])] if direction=='input' else [(g[1][1:],g[0][1:]),(g[3][2:],[g[3][1]])]
  for operands,labels in pairs:
   if len(labels)!=1 or labels[0][1:3]!=b'\xdf_' or not operands or any(t[1]==0xdf for t in operands):raise ValueError('unresolved call operands')
   pin=labels[0][3:-1].decode('ascii');port=next(p for p in call['ports'] if p['name']==pin and p['direction']==direction)
   if pin.lower() in result:raise ValueError('duplicate connection')
   immediate=0xe3<=operands[0][1]<=0xee
   if immediate:
    if direction!='input' or port['type_marker']!='W':raise ValueError('unobserved constant connection')
    materialized.append(dict(port=pin,groups=g[2:4]))
   else:result[pin.lower()]=b''.join(operands)
 return result,materialized

def predict(streams,root=b'MAIN',scpi_calls=False):
 source=streams['CGTable.dat'];tables=parse_compiler_tables(source)
 metadata=next(v for k,v in streams.items() if k.endswith('.prj'))
 ranges={r['name']:r for r in project_allocation_ranges(metadata)['ranges']}
 # Observed native pool descriptors: selector 24 D, 31 M, 7 T, 10 C.
 forms={0:('M',0x21,0),2:('D',0x24,5),3:('D',0x24,5),9:('D',0x24,5),11:('D',0x24,5),15:('D',0x24,5),17:('D',0x24,5),18:('D',0x24,5),65:('T',5,11),67:('C',10,14)}
 maps={};assigned={};allocations=[];declared=[]
 def layout(c):
  t=tables.component_type(c);parameter=None;count=1
  if t==51:
   a=tables.array_at(tables.component_array_offset(c));assert a.count_matches_dimensions
   t=a.element_type;parameter=a.element_parameter;count=a.total_count
  elif t==15:
   if c.global_offset is not None:_,f=tables.tables[3].record_at(c.global_offset).named_fields();parameter=struct.unpack_from('<I',f,8)[0]
   else:parameter=struct.unpack_from('<I',c.fields_raw,12)[0]
  if t not in forms:raise ValueError(f'unrecovered allocation type {t}')
  size=1 if t in [0,65,67] else 2 if t in [2,17] else 4 if t in [3,9,11,18] else parameter+1
  return t,(size if t==0 else (size+1)//2)*count
 def has_address(c):
  off=tables.component_address_offset(c)
  return off>=0 and tables.address_at(off).iec_address_bytes is not None
 # Declared addresses within these allocation pools would require reservation
 # modeling. Reject them, rather than silently starting from an empty map.
 from probe_gxw_operand_bindings import observed_q_address
 for r in tables.tables[2].records:
  c=tables.component_at(r.table_offset)
  if not has_address(c):continue
  a=observed_q_address(tables.address_at(tables.component_address_offset(c)).iec_address_bytes)
  if a['handling']=='opaque':raise ValueError('unrecovered explicit address spelling')
  if a['family'] in ranges:
   p=ranges[a['family']]
   if p['handling']=='range' and p['lower']<=a['number']<=p['upper']:raise ValueError('explicit address overlaps system pool')
  declared.append(c.record.table_offset)
 def allocate(c,phase):
  if c.record.table_offset in assigned or has_address(c):return
  t,count=layout(c);family,tag,code=forms[t];r=ranges[family]
  if r['handling']!='range' or count<=0:raise ValueError('unavailable allocation pool')
  limit=r['upper']-r['lower']+1;used=maps.setdefault(family,bytearray(limit));start=None;run=0
  for i,value in enumerate(used):
   run=0 if value else run+1
   if run==count:start=i-count+1;break
  if start is None:raise ValueError('system pool exhausted')
  used[start:start+count]=b'\1'*count;number=r['upper']-start-count+1
  raw=bytearray(26);raw[0]=tag;raw[1]=code;raw[2:5]=number.to_bytes(3,'little',signed=True);struct.pack_into('<I',raw,6,count)
  assigned[c.record.table_offset]=bytes(raw)
  allocations.append(dict(component_offset=c.record.table_offset,name_hex=c.name_bytes.hex(),scope=c.scope_code,type=tables.component_type(c),element_type=t,family=family,number=number,count=count,phase=phase,raw=raw.hex()))
 globals_=[tables.pou_at(r.table_offset) for r in tables.tables[1].records if tables.pou_at(r.table_offset).name_bytes==b'@GLOBALS'];assert len(globals_)==1
 for c in tables.components(globals_[0]):
  if c.scope_code not in [9]:raise ValueError('unrecovered global scope')
  if tables.component_type(c)==53:raise ValueError('global instance not modeled')
  allocate(c,'globals')
 rootp=[tables.pou_at(r.table_offset) for r in tables.tables[1].records if tables.pou_at(r.table_offset).name_bytes==root];assert len(rootp)==1
 active=set()
 def locals_(pou):
  if pou.record.table_offset in active:raise ValueError('recursive instance')
  active.add(pou.record.table_offset)
  for c in tables.components(pou):
   if c.scope_code!=1:continue
   if tables.component_type(c)==53:locals_(tables.pou_at(tables.component_instance_pou_offset(c)))
   else:allocate(c,'locals')
  active.remove(pou.record.table_offset)
 locals_(rootp[0]);calls=[]
 frame=frame_source(streams[root.decode('ascii')+'.Program.pou'])
 observed=observe_calls(frame)
 if observed['gaps']:raise ValueError('unresolved FB markers')
 if observed['calls'] and not scpi_calls:raise ValueError('call allocation model not enabled')
 for call in observed['calls']:
  if call['definition']!='SCPI' or call['gaps']:raise ValueError('only recovered SCPI direct-call profile')
  inst=next(c for c in tables.components(rootp[0]) if c.name_bytes==call['instance'].encode('ascii'));pou=tables.pou_at(tables.component_instance_pou_offset(inst));aliases,materialized=direct_call(frame,call)
  for c in tables.components(pou):
   key=c.name_bytes.decode('ascii').lower()
   if c.scope_code not in [2,4]:continue
   if key in aliases:continue
   if c.scope_code==2 and tables.component_type(c)==0:aliases[key]=bytes.fromhex('0591900105')
   else:allocate(c,'call-'+str(len(calls)))
  calls.append(dict(call=call,instance_offset=inst.record.table_offset,aliases=aliases,materialized=materialized))
 changed=bytearray(source)
 for r in tables.tables[2].records:
  changed[r.offset+len(r.raw)-26:r.offset+len(r.raw)]=assigned.get(r.table_offset,bytes(26))
 return dict(tables=parse_compiler_tables(bytes(changed)),raw=bytes(changed),allocations=allocations,calls=calls,declared=declared)
