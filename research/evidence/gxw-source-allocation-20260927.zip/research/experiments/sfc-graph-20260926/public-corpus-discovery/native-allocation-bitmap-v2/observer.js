// Owned helper only, read-only ECCompiler_IEC 15.50 instruction sink.
'use strict';
const contexts = new Map();
let sequence = 0, nextCompile = 0;
function hex(p, n) { return Array.from(new Uint8Array(p.readByteArray(n)), b => b.toString(16).padStart(2, '0')).join(''); }
function string(p, bound) {
  const bytes=[];
  for(let i=0;i<bound;i++) {const b=p.add(i).readU8();if(!b)return {hex:bytes.map(x=>x.toString(16).padStart(2,'0')).join(''),latin1:String.fromCharCode(...bytes),terminated:true};bytes.push(b);}
  return {hex:bytes.map(x=>x.toString(16).padStart(2,'0')).join(''),terminated:false};
}
function loc(p){const m=Process.findModuleByAddress(p);return m?{module:m.name,rva:p.sub(m.base).toString()}:null;}
function emit(e){if(sequence<100000)send({...e,sequence:++sequence});else if(sequence===100000){sequence++;send({event:'sink-limit-error'});}}
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='eccompiler_iec.dll')return;
 try {
  if(Process.arch!=='ia32')throw new Error('x86 required');
  const b='6aff6806040f1064a100000000506489'.match(/../g).map(x=>parseInt(x,16)),v=m.base.add(0xf0406).toUInt32();
  for(let i=0;i<4;i++)b[3+i]=(v>>>(8*i))&255;
  if(hex(m.base.add(0xaed60),16)!==b.map(x=>x.toString(16).padStart(2,'0')).join(''))throw new Error('record-sink guard');
  emit({event:'sink-module',path:m.path,base:m.base.toString()});
  Interceptor.attach(m.findExportByName('Compile'),{
   onEnter(a){
    this.prior=contexts.get(this.threadId);this.id=++nextCompile;
    const count=a[1].toInt32(),names=[],sources=[];
    try {
     if(count<0||count>4096)throw new Error('compile count bound');
     for(let i=0;i<count;i++){
      const d=a[2].add(i*28),n=d.readS32(),name=string(d.add(8).readPointer(),1024);names.push(name);
      if(n<0||n>0x200000)throw new Error('source length bound');
      sources.push({index:i,name,raw:hex(d.add(4).readPointer(),n)});
     }
     contexts.set(this.threadId,{compile_id:this.id,names});
     const symbolsSize=a[3].toInt32();
     if(symbolsSize<0||symbolsSize>0x1000000)throw new Error('symbol length bound');
     emit({event:'sink-compile',compile_id:this.id,names,sources,symbolic_data:hex(a[4],symbolsSize)});
    }catch(e){contexts.set(this.threadId,null);emit({event:'sink-compile-error',compile_id:this.id,error:String(e)});}
   },onLeave(r){emit({event:'sink-compile-result',compile_id:this.id,result:r.toInt32()});contexts.set(this.threadId,this.prior);}
  });
  Interceptor.attach(m.base.add(0xaed60),{onEnter(a){
   const context=contexts.get(this.threadId);if(!context)return;
   try {
    const r=a[0],count=r.add(12).readU8();if(count>9)throw new Error('operand count bound');
    const operands=[];
    for(let i=0;i<count;i++){
     const p=r.add(13+i*25),operand={raw:hex(p,25)};
     if((p.add(24).readU8()&1)&&!p.readPointer().isNull())operand.string=string(p.readPointer(),4096);
     operands.push(operand);
    }
    emit({event:'sink-record',compile_id:context.compile_id,name:string(r.readPointer(),128),opcode:r.add(4).readS32(),source:r.add(8).readS32(),count,mode:a[1].toInt32(),operands,raw:hex(r,238),caller:loc(this.returnAddress)});
   }catch(e){emit({event:'sink-record-error',compile_id:context.compile_id,error:String(e)});}
  }});
 }catch(e){emit({event:'sink-guard-error',error:String(e)});}
}});

// Appended to the lean Compile observer. Function boundaries only.
const allocationContexts=new Map(),poolContexts=new Map();let nextAllocation=0,nextPool=0;
function bitmap(p){if(p.isNull())return null;const n=p.readU32();if(n>0x200000||n%8)throw new Error('bitmap capacity bound');return {address:p.toString(),capacity:n,raw:hex(p.add(4),n/8)};}
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='eccompiler_iec.dll')return;
 try{
  if(hex(m.base.add(0x52e70),3)!=='568bf1'||hex(m.base.add(0x324d0),4)!=='8b442410')throw new Error('allocation function guards');
  Interceptor.attach(m.base.add(0x52e70),{onEnter(a){const c=contexts.get(this.threadId);if(!c)return;
   this.prior=allocationContexts.get(this.threadId);this.row={event:'typed-allocation',compile_id:c.compile_id,allocation_id:++nextAllocation,type:a[0].toInt32(),arg2:a[2].toInt32(),category:a[3].toInt32(),caller:loc(this.returnAddress),sizes:[],pools:[]};allocationContexts.set(this.threadId,this.row);
   try{this.out=a[4];this.row.before=hex(this.out,26);this.row.type_parameter=a[1].isNull()?null:hex(a[1],12);
    if(this.row.type===0x33&&!a[1].isNull()){const p=a[1].readPointer();this.row.array_header=p.isNull()?null:hex(p,12);}
   }catch(e){this.row.observation_error=String(e);}
  },onLeave(r){if(!this.row)return;this.row.result=r.toInt32();try{this.row.after=hex(this.out,26);}catch(e){this.row.observation_error=String(e);}emit(this.row);allocationContexts.set(this.threadId,this.prior);}});
  Interceptor.attach(m.base.add(0x519f0),{onEnter(a){const d=allocationContexts.get(this.threadId);if(!d)return;this.parent=d;this.row={type:a[0].toInt32(),parameter:a[1].toInt32()};},onLeave(r){if(this.row){this.row.bytes=r.toInt32();this.parent.sizes.push(this.row);}}});
  for(const [rva,kind] of [[0x47180,'word'],[0x474a0,'bit'],[0x477b0,'special-65'],[0x47960,'special-66'],[0x47ac0,'special-67']])Interceptor.attach(m.base.add(rva),{onEnter(a){const c=contexts.get(this.threadId);if(!c)return;
   this.prior=poolContexts.get(this.threadId);const d=allocationContexts.get(this.threadId);this.row={event:'pool-allocation',object_address:this.context.ecx.toString(),pool_id:++nextPool,allocation_id:d?d.allocation_id:null,compile_id:c.compile_id,kind,count:a[0].toInt32(),selector:a[2].toInt32(),caller:loc(this.returnAddress),searches:[],marks:[],descriptors:[]};poolContexts.set(this.threadId,this.row);if(d)d.pools.push(this.row.pool_id);
   try{this.out=a[1];this.row.before=hex(this.out,26);const base=this.context.ecx;for(let i=0;i<=34;i++){const p=base.add(0xe+i*22);this.row.descriptors.push({index:i,raw:hex(p,22),code:p.readU8(),end:p.add(4).readS32(),limit:p.add(8).readU32(),bitmap:p.add(16).readPointer().toString()});}}
   catch(e){this.row.observation_error=String(e);}
  },onLeave(r){if(!this.row)return;this.row.result=r.toInt32();try{this.row.after=hex(this.out,26);}catch(e){this.row.observation_error=String(e);}emit(this.row);poolContexts.set(this.threadId,this.prior);}});
  Interceptor.attach(m.base.add(0x324d0),{onEnter(a){const p=poolContexts.get(this.threadId);if(!p)return;this.parent=p;this.row={count:a[1].toUInt32(),limit:a[2].toUInt32(),start:a[3].toUInt32()};try{this.ptr=a[0];this.row.before=bitmap(this.ptr);}catch(e){this.row.observation_error=String(e);}},onLeave(r){if(!this.row)return;this.row.result=r.toInt32();try{this.row.after=bitmap(this.ptr);}catch(e){this.row.observation_error=String(e);}this.parent.searches.push(this.row);}});
  Interceptor.attach(m.base.add(0x32420),{onEnter(a){const p=poolContexts.get(this.threadId);if(!p)return;this.parent=p;this.row={start:a[1].toUInt32(),count:a[2].toUInt32()};try{this.ptr=a[0];this.row.before=bitmap(this.ptr);}catch(e){this.row.observation_error=String(e);}},onLeave(r){if(!this.row)return;try{this.row.after=bitmap(this.ptr);}catch(e){this.row.observation_error=String(e);}this.parent.marks.push(this.row);}});
 }catch(e){emit({event:'allocation-guard-error',error:String(e)});}
}});

Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='eccompiler_iec.dll')return;
 for(const [rva,action] of [[0x32420,'mark'],[0x32470,'clear']])Interceptor.attach(m.base.add(rva),{onEnter(a){
  const c=contexts.get(this.threadId);if(!c||poolContexts.get(this.threadId))return;
  this.row={event:'external-bitmap-change',compile_id:c.compile_id,action,start:a[1].toUInt32(),count:a[2].toUInt32(),caller:loc(this.returnAddress)};
  try{this.p=a[0];this.row.before=bitmap(this.p);}catch(e){this.row.observation_error=String(e);}
 },onLeave(){if(!this.row)return;try{this.row.after=bitmap(this.p);}catch(e){this.row.observation_error=String(e);}emit(this.row);}});
 Interceptor.attach(m.base.add(0x147e0),{onEnter(a){const c=contexts.get(this.threadId);if(!c||a[0].toInt32()!==2)return;
  this.row={event:'component-userinfo-write',compile_id:c.compile_id,table_address:this.context.ecx.toString(),caller:loc(this.returnAddress)};
  try{if(this.context.ecx.add(0x4c).readS32()!==26)throw new Error('component size');this.pos=a[1];this.row.component_offset=this.pos.readS32();this.row.raw=hex(a[2],26);}catch(e){this.row.observation_error=String(e);}
 },onLeave(r){if(!this.row)return;this.row.result=r.toInt32();emit(this.row);}});
}});
