"""Project only measured FOR links; retain every observed node byte/unknown field.

Reads saved true-entry compiler observations, not CGTable.dat. Does not rebuild
GXW, invoke a compiler or promote native graph observations to a product ABI.
"""
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[4]
P=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from probe_minimal_conditional_port_writes import streams
from gxw.project_metadata import read_project_text_context
from source_q_direct_declarations import DirectDeclarations


def project_for(snapshot,addresses):
    nodes={n['id']:n for n in snapshot['graph']}
    def expression(index):
        if index==0:return dict(kind='implicit-positive-step',value=1,handling='source-correlated default')
        node=nodes[index];kind=node['type']
        if kind==0x112:return dict(kind='literal',value_words=[node['field56'],node['field60']],node=index,handling='partially-decoded')
        if kind==0x10f:
            return dict(kind='variable',operand_number=node['field56'],source_candidates=addresses.get(node['field56'],[]),node=index,handling='partially-decoded')
        if kind==0x169:
            return dict(kind='plus',left=expression(node['link12']),right=expression(node['link16']),node=index,handling='decoded measured INT expression')
        return dict(kind='unknown',node=index,handling='opaque-preserved')
    loops=[]
    for root in nodes.values():
        if root['type']!=0x17d:continue
        init=nodes[root['link12']];bounds=nodes[root['link16']];step_body=nodes[bounds['link16']]
        assert (init['type'],bounds['type'],step_body['type'])==(0x155,0x15e,0x172)
        counter=expression(init['link16'])
        assert counter['kind']=='variable' and any(n.endswith(('key_iterator','for_iterator')) for n in counter['source_candidates'])
        loops.append(dict(node=root['id'],handling='partially-decoded',counter=counter,
            start=expression(init['link12']),stop=expression(bounds['link12']),step=expression(step_body['link12']),
            body=dict(node=step_body['link16'],handling='opaque-preserved')))
    assert loops
    for node in nodes.values():assert len(bytes.fromhex(node['raw']))==73
    return dict(loops=loops,raw_nodes=snapshot['graph'],graph_truncated=snapshot['graph_truncated'],
        raw_preservation_scope='Exact observed 73-byte node cells, including unknown fields and unmodeled bodies; no whole-GXW roundtrip claim.')


def main():
    cases=[]
    for group in ('q-st-for-control-forward-20260930','fx-st-nested-for-forward-20260930'):
        directory=P/group
        for row in json.loads((directory/'comparison.json').read_text()):
            path=directory/row['case'];content={k:v for k,v in streams((path/'input.gxw').read_bytes()).items() if k!='CGTable.dat'}
            context=read_project_text_context(next(v for k,v in content.items() if k.endswith('.prj')))
            fx=context['cpu']=='FX3U/FX3UC';decl=DirectDeclarations(content,context['text_encoding'],local_fb_definitions=('Keypad',) if fx else ('SCPI',),allow_string_arrays=True)
            decl.add_owner('POU_01' if fx else 'MAIN');addresses={}
            for item in decl.allocations:addresses.setdefault(item['number'],[]).append(item['owner']+'.'+item['name'])
            events=[json.loads(line).get('payload',{}) for line in (Path(row['native_directory'])/'events.jsonl').read_text().splitlines()]
            assert not any(e.get('event') in ('block-walk-guard-error','block-walk-observation-error') for e in events)
            snapshot=next(e for e in events if e.get('event')=='block-walk' and e.get('name')=='wrapper' and e.get('phase')=='enter' and e['node'].get('type')==0x17d)
            projected=project_for(snapshot,addresses);projected.update(group=group,case=row['case'],native_directory=row['native_directory'],evidence='Saved runtime node graph plus observed getter/visitor implementation and controlled source correlation.')
            (path/'for-node-ir.json').write_text(json.dumps(projected,indent=2))
            cases.append(dict(group=group,case=row['case'],loops=len(projected['loops']),raw_nodes=len(projected['raw_nodes']),handling=projected['handling'] if 'handling' in projected else 'partially-decoded'))
            print(json.dumps(cases[-1]),flush=True)
    (P/'q-st-for-control-forward-20260930/for-node-ir-index.json').write_text(json.dumps(dict(scope='Observed Q03UDV/FX3U FOR graph subset. Raw cells retained, unmodeled bodies opaque. No product ABI or safe writer promotion.',cases=cases),indent=2))


if __name__=='__main__':main()
