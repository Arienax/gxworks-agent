"""Saved CASE evidence: independent decode and finite initialized witnesses.

Prospective bytes and later model fits are distinguished. Raw native node cells
remain opaque except for the observed selector/selection-list entry association.
No native compiler rerun, PLC execution or general runtime-equivalence claim.
"""
from pathlib import Path
import base64,json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.project_metadata import read_project_text_context
from probe_minimal_conditional_port_writes import streams,save
from source_q_direct_declarations import DirectDeclarations
from source_q_st_calls import predict,source_statements
from source_st_branch_trees import parse_case,parse_if
from native_gxw_tokens import native_batch,native_il_records
from inspect_st_branch_ir import decode
from witness_st_conditional_transfers import evaluate
P=Path(__file__).resolve().parent
EXPECTED={'Three':'FX','Expr':'FX','Reuse':'TXY','Range':'TX','Duplicate':'TX','Range-first':'TX','Two-ranges':'TX','No-else':'','Three-words':'TY','Four-words':'TY','False':'FX','If':'TX','For':'FX','Case':'IX','If-4':'TY','Nested':'IY'}


def project_selection(entry):
    nodes={n['id']:n for n in entry['graph']};active=set()
    def terms(index):
        if index in active:raise ValueError('native selection graph cycle')
        active.add(index);node=nodes[index]
        try:
            if node['type']==0x112 and node['field24']==2 and node['field60']==0 and 0<=node['field56']<=32767:
                return [dict(kind='value',value=node['field56'])]
            if node['type']==0x2c:return terms(node['link12'])+terms(node['link16'])
            if node['type']==0x189:
                low=terms(node['link12']);high=terms(node['link16'])
                if len(low)==len(high)==1 and low[0]['kind']==high[0]['kind']=='value':return [dict(kind='range',lower=low[0]['value'],upper=high[0]['value'])]
            return [dict(kind='opaque',node=node)]
        finally:active.remove(index)
    root=entry['node']
    if root.get('type')==0x2c and nodes[root['link12']]['type']==0x3a:root=nodes[root['link12']]
    if root.get('type')==0x3a:return dict(kind='arm',terms=terms(root['link12']))
    if root.get('type')==0x175 and root['link12']==0:return dict(kind='default',terms=[])
    return dict(kind='opaque',node=root)


def main():
    for group in sys.argv[1:]:
        out=P/group;fx=group.startswith('fx-');rows=json.loads((out/'comparison.json').read_text());plan=json.loads((out/'experiment-plan.json').read_text())
        if not (out/'native-listings.json').exists():
            assert fx
            accepted=[r for r in rows if (Path(r['native_directory'])/'pcode-0-0.bin').stat().st_size]
            requests=[dict(mode='decode',input_base64=base64.b64encode((Path(r['native_directory'])/'pcode-0-0.bin').read_bytes()+b'\0').decode()) for r in accepted]
            answers=native_batch(requests,out/'independent-native-decode',cpu_code=520);native={}
            for row,request,answer in zip(accepted,requests,answers,strict=True):
                assert answer['return_code']=='0x00000000' and answer['consumed_bytes']==len(base64.b64decode(request['input_base64']))-1
                native[row['case']]=native_il_records(base64.b64decode(answer['output_base64']),encoding='cp932')
            save(out/'native-listings.json',[dict(case=k,records=v) for k,v in native.items()])
        else:native={r['case']:r['records'] for r in json.loads((out/'native-listings.json').read_text())}
        findings=[]
        for row in rows:
            name=row['case'];n=Path(row['native_directory']);raw=(n/'pcode-0-0.bin').read_bytes();source=(n/'input.gxw').read_bytes()
            before=json.loads((out/name/'before-native.json').read_text());predicted=out/name/'predicted-0.bin'
            result=dict(case=name,generated_bytes=len(raw),before_native_status='byte-prediction' if predicted.exists() else before['prediction'].get('unsupported','discovery'),fresh_check=row['check'])
            if predicted.exists():
                assert raw==predicted.read_bytes();result['before_native_byte_match']=True
            options=plan['prediction_options']
            if not fx:options=options|dict(allow_inputs=True,allow_omitted=True,allow_members=True)
            try:current=predict(source,('Keypad',) if fx else ('SCPI',),owner='POU_01' if fx else 'MAIN',**options)['output']
            except ValueError as exc:result['current_model_status']=dict(unsupported=str(exc))
            else:
                assert current==raw,(group,name,'current model mismatch');result['current_model_status']='byte-match'
            if not raw:
                assert name in ('Few','If-3') and row['check'] is None
                result['handling']='frontend-rejected-temporary-capacity'
                findings.append(result);print(json.dumps(dict(group=group,**result)));continue
            assert row['check'] and not row['check']['rejected'] and not row['reopen']['check']['rejected'] and row['reopen'].get('bytes_identical',row['reopen'].get('identical'))
            records=decode(raw,'fx3u' if fx else 'q03udv')
            assert [{k:v for k,v in r.items() if k not in ('offset','raw')} for r in records]==native[name]
            content={k:v for k,v in streams(source).items() if k!='CGTable.dat'}
            context=read_project_text_context(next(v for k,v in content.items() if k.endswith('.prj')))
            owner='POU_01' if fx else 'MAIN';child='POU_01.keypad_a' if fx else 'MAIN.First'
            declarations=DirectDeclarations(content,context['text_encoding'],local_fb_definitions=('Keypad',) if fx else ('SCPI',),allow_string_arrays=True);declarations.add_owner(owner)
            selected={'result':(owner,'number_buffer' if fx else 'prober1'),'key_iterator':(child,'key_iterator')}
            if not fx:selected['copied']=(owner,'prober2')
            if name in ('Expr','Reuse'):selected['for_iterator']=(child,'for_iterator')
            bindings={}
            for key,(scope,var) in selected.items():
                item=declarations.bound[scope][var];bindings[key]=dict(address=item['family']+str(item['number']),type=item['row'].data_type)
            witness=evaluate(records,bindings,allow_boolean=True,profile='fx3u' if fx else 'q03udv');expected=dict(result=EXPECTED[name],key_iterator=2 if name=='For' else 0)
            if not fx:expected['copied']=EXPECTED[name]
            if name in ('Expr','Reuse'):expected['for_iterator']=88 if name=='Expr' else 66
            assert witness['observations']==expected,(group,name,witness['observations'],expected)
            save(out/name/'finite-case-witness.json',dict(bindings=bindings,expected=expected,**witness))
            events=[json.loads(line).get('payload',{}) for line in (n/'events.jsonl').read_text().splitlines()]
            errors=[e for e in events if 'error' in e.get('event','')];assert not errors,(group,name,errors)
            entries=[e for e in events if e.get('event')=='block-walk' and e.get('phase')=='enter' and e['name'] in ('wrapper','control-selection-list')]
            assert entries and not any(e.get('graph_truncated') for e in entries)
            for entry in entries:
                for node in entry.get('graph',[]):assert len(bytes.fromhex(node['raw']))==73
            emits=[e for e in events if e.get('event')=='abstract-control-emit']
            save(out/name/'case-native-ir.json',dict(scope='Exact observed raw node cells and selection-list true-entry arguments. Uninterpreted links/fields are opaque; no product ABI promotion.',entries=entries,emits=emits))
            selections=[e for e in entries if e['name']=='control-selection-list']
            if selections:
                if fx:
                    source_plan=plan['cases'][name]
                    text=source_plan if isinstance(source_plan,str) else source_plan['source']
                else:text=next(p['body'] for p in plan['cases'] if p['case']==name)
                statements=source_statements(text);expected_lists=[];position=0
                def collect(tree):
                    if tree['kind']=='case':
                        for arm in tree['arms']:
                            expected_lists.append(dict(kind='arm',terms=arm['selections']))
                            for child in arm['body']:
                                if child['kind']!='statement':collect(child)
                        if tree['otherwise'] is not None:
                            expected_lists.append(dict(kind='default',terms=[]))
                            for child in tree['otherwise']:
                                if child['kind']!='statement':collect(child)
                    else:
                        for child in tree['then']+(tree['otherwise'] or []):
                            if child['kind']!='statement':collect(child)
                while position<len(statements):
                    if statements[position].strip().upper().startswith('CASE '):
                        tree,position=parse_case(statements,position,allow_nested=True);collect(tree)
                    elif statements[position].strip().upper().startswith('IF '):
                        tree,position=parse_if(statements,position,allow_cases=True);collect(tree)
                    else:position+=1
                projected=[project_selection(e) for e in selections]
                save(out/name/'case-selection-projection.json',dict(scope='Context-bound selection-list projection: 3a arm -> choices/body, 175 default -> body; 112 positive INT literal, 189 range, 2c ordered choice list. Every original raw node remains preserved in case-native-ir.',expected=expected_lists,observed=projected))
                assert projected==expected_lists,(group,name,'native/source selection mismatch')
            case_entries=[e for e in events if e.get('event')=='block-walk' and e.get('phase')=='enter' and e['name']=='control-173']
            if case_entries:
                save(out/name/'embedded-case-entry-ir.json',dict(scope='Source-correlated 173 CASE tree entry. Selector link12 and arm-list link16 preserved; arm body semantics and other fields remain opaque.',entries=case_entries))
                result['embedded_case_nodes']=[e['node'] for e in case_entries]
            fitted=out/name/'context-case-source-fit.bin'
            if fitted.exists():assert fitted.read_bytes()==raw;result['post_observation_context_fit']=True
            result.update(handling='native-check-and-reopen-accepted',independent_lexical_match=True,witness=witness['observations'],labels=[r['text'] for r in records if r['kind']=='label'],selection_entry_types=[hex(e['node']['type']) if 'type' in e['node'] else e['node']['handling'] for e in entries if e['name']=='control-selection-list'])
            findings.append(result);print(json.dumps(dict(group=group,**result)),flush=True)
        save(out/'case-findings.json',dict(scope='Bounded flat INT CASE with ASCII string/INT assignments; source-only before predictions, raw-preserved native observations and finite offline witnesses remain distinct.',cases=findings))
        for name in (Path(__file__).name,'inspect_st_branch_ir.py','witness_st_conditional_transfers.py'):(out/name).write_bytes((P/name).read_bytes())


if __name__=='__main__':main()
