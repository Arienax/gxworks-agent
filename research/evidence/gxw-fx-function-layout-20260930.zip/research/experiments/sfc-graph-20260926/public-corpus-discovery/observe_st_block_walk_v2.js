// Read-only true function-entry observations, ECCompiler_IEC 15.50 x86.
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='eccompiler_iec.dll')return;
 const active=new Map();let serial=0;
 function bytes(p,n){return Array.from(new Uint8Array(p.readByteArray(n)),b=>b.toString(16).padStart(2,'0')).join('');}
 function loc(p){const o=Process.findModuleByAddress(p);return o?{module:o.name,rva:p.sub(o.base).toString()}:{address:p.toString()};}
 function slots(manager){const owner=manager.readPointer(),table=owner.add(0x28).readPointer().add(8).readPointer(),out=[];
  if(table.isNull())return out;
  for(let n=0;n<16;n++){const p=table.add(n*33),state=p.add(24).readU8();if(state)out.push({index:n,type:p.add(8).readU32(),address:p.add(12).readU32(),width:p.add(20).readU32(),state});}return out;
 }
 function node(manager,id){const count=manager.add(0x34).readU32();if(id<1||id>=count||count>100000)return {id,handling:'out-of-bounds',count};
  const p=manager.add(0x40).readPointer().add(id*73);return {id,type:p.add(4).readU32(),link12:p.add(12).readU32(),link16:p.add(16).readU32(),field20:p.add(20).readU32(),field24:p.add(24).readU32(),field28:p.add(28).readU32(),field32:p.add(32).readU32(),field56:p.add(56).readU32(),field60:p.add(60).readU32(),raw:bytes(p,73)};
 }
 for(const [rva,name,guard] of [[0xd7480,'wrapper','538bd98b430c'],[0x8b240,'walker','558bec83e4f8'],[0x78850,'post-walk','578bf98b4c24'],[0xd93b0,'for-generator','83ec7c538b9c'],[0xd8100,'loop-prepare','56578b7c240c']]){
  if(bytes(m.base.add(rva),guard.length/2)!==guard){send({event:'block-walk-guard-error',name,rva});continue;}
  Interceptor.attach(m.base.add(rva),{
   onEnter(a){try{this.id=++serial;this.previous=active.get(this.threadId)||[];active.set(this.threadId,this.previous.concat(this.id));
    this.manager=['wrapper','for-generator','loop-prepare'].includes(name)?this.context.ecx.add(0xc).readPointer().add(0x30).readPointer():this.context.ecx;
    this.reference=name==='loop-prepare'?a[0]:null;const nodeId=this.reference?this.reference.readS32():a[0].toInt32();
    this.row={event:'block-walk',phase:'enter',id:this.id,parent:this.previous.at(-1)||null,name,rva,caller:loc(this.returnAddress),node:node(this.manager,nodeId),arg1:a[1].toUInt32(),slots:slots(this.manager)};
    if(name==='wrapper'){const count=this.manager.add(0x34).readU32();this.row.graph=[];for(let i=1;i<Math.min(count,129);i++)this.row.graph.push(node(this.manager,i));this.row.graph_truncated=count>129;}
    send(this.row);
   }catch(e){send({event:'block-walk-observation-error',name,phase:'enter',error:String(e)});}},
   onLeave(r){try{if(!this.row)return;send({event:'block-walk',phase:'leave',id:this.id,name,result:r.toInt32(),node:node(this.manager,this.reference?this.reference.readS32():this.row.node.id),slots:slots(this.manager)});
   }catch(e){send({event:'block-walk-observation-error',name,phase:'leave',error:String(e)});}finally{if(this.id)active.set(this.threadId,this.previous);}}
  });
 }
}});
