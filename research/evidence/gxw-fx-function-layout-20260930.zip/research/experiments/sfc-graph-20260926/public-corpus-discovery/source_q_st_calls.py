"""Source-only prediction of bounded local ST FB transfers and conditional writes.

Research compiler-output model, not a semantics-preserving generator. In the
measured profile an indexed IN_OUT is copied in and copied back with a freshly
computed index. The first indexed OUTPUT aliases Z16; a second keeps a
temporary offset restored at each operand occurrence, before arithmetic
optimization. Either form can alter another alias by overwriting Z16.
These are deliberately reported as distinct transfer phases.
The default profile covers Q03UDV local INT/STRING, zero-based arrays, INT +/-,
IF scalar > constant without ELSE, assignments and selected local FB definitions.
No compiler cache. String literals are restricted to printable ASCII.
An explicit FX3U string-slice option uses the independently observed CPU
delegate, Z0 indexing, three-operand CONCAT/ADD and RST for an empty STRING.
IF blocks and constant loops reserve indexed CONCAT captures before their
condition and hold them until the closing label. An enclosing loop also owns
inner IF/FOR captures. Two FOR levels are separately opt-in. Q-only control
expressions recompute TO/BY arithmetic at the head and pin results across the
body; a scalar BY remains a live alias. Branch trees are separately opt-in:
two scalar INT/WORD IF levels, ELSE-first emission and tail continuation labels.
Calls/loops inside branch trees and general FX ports remain unsupported.
REPEAT and nearest-loop EXIT are separately opt-in. A measured Q FOR body
ending directly in EXIT is refused: native emits an unreachable increment
without a new rung and fresh ProgramCheck rejects it (0x050c9322).
Opt-in flat INT CASE supports positive scalar/range selection lists and optional
ELSE. The selector is prepared once; each arm prepares and retains its captures.
Arithmetic index scratch can be released and reused by a later arm's capture.
The whole-case preparation option is retained only as a comparison hypothesis.
Opt-in INPUT handling distinguishes direct aliases, inline literals and fresh
buffers at each static call site. Those buffers bypass the reusable slot table;
they are compiler-assigned addresses, not runtime heap allocations.
Alternate W/R/ZR storage is opt-in. Observed ZR arrays use double indexing;
32768-word arrays additionally rebase dynamic addresses by one signed offset.
Optional CONCAT is restricted to typed assignment contexts. Its indexed STRING
captures request D slots even in another temporary bank; physical stored types
can then prevent reuse. Generated string operations carry no capacity guard.
Opt-in string intrinsics cover INT_TO_STR, WORD_TO_STR and four-argument RIGHT
with a constant enable. WORD handling is limited to the conversion/IN_OUT slice.
The measured direct two-dynamic-index RIGHT form is explicitly unsupported:
native lowering emits code that fresh ProgramCheck rejects. A FB OUTPUT alias
can instead compile while an internal source index clobbers its shared Z16.
The enabled-instruction option adds LEFT/MOV and bounded scalar BOOL conditions.
Complex enables needing later argument preparation use reusable bit slots; BOOL
INPUT expressions use fresh bit buffers. Configured B overrides M storage, but
indexed BOOL and scalar NOT captures retain their operand's M/B request type.
Measured two-leaf OR/AND result captures retain the original left operand type.
Two dynamic BOOL leaves reserve a default-bank left capture before reserving
the final enable or fresh INPUT buffer; index preparation is emitted later.
An indexed BOOL OUTPUT bound to a scalar formal is still a direct Z16 alias.
Preparing the right leaf can therefore displace a subsequent read of that formal.
Opt-in dynamic BOOL stores materialize indexed/binary sources in the configured
bit bank before preparing the destination. Scalar NOT and the measured scalar
comparison remain direct LDI/LD> conditions after destination preparation.
The result operand is released and reacquired by configured bit type and its
existing address, independently of fresh slot selection. That configured type
equals physical storage in the measured fixed M/B temporary bank.
Double NOT simplifies to an alias.
Recursive Boolean lowering is separately opt-in: measured nested OR/AND,
scalar NOT leaves, indexed INT>literal comparisons and leaf/comparison XOR.
XOR emits opposite-condition branches joined by ORB. Its indexed right operand
is captured; an indexed left operand can remain direct when the right is stable.
Indexed composite right subtrees are lowered first after saving an unstable
left result; a stable left leaf is appended after the right condition. Child
captures are reserved before the parent capture. Compound XOR operands remain
unsupported.
This is still a bounded compiler-output model, not complete declaration checking.
"""
import re
from gxw.lossless import sha256
from gxw.project_metadata import read_project_text_context
from probe_gxw_st_sources import replace_observed_st
from probe_gxw_operand_bindings import split_operands
from probe_minimal_conditional_port_writes import streams
from source_q_direct_declarations import DirectDeclarations
from source_q_st_expressions import expression
from source_q_label_binding import scalar,integer16
from source_q_width import rewrite


def source_statements(text):
    """Parse-only comment removal; preserve delimiters inside ST strings."""
    parts=[]; current=[]; offset=0; depth=0; quoted=False
    while offset<len(text):
        pair=text[offset:offset+2]; char=text[offset]
        if depth:
            if pair=='(*':depth+=1;offset+=2;continue
            if pair=='*)':depth-=1;offset+=2;continue
            if char in '\r\n':current.append(char)
            offset+=1;continue
        if quoted:
            current.append(char)
            if char=="'":
                if pair=="''":current.append("'");offset+=2;continue
                quoted=False
            offset+=1;continue
        if pair=='(*':current.append(' ');depth=1;offset+=2;continue
        if char=="'":quoted=True;current.append(char)
        elif char==';':parts.append(''.join(current));current=[]
        else:current.append(char)
        offset+=1
    if depth or quoted:raise ValueError('unterminated ST comment or string')
    parts.append(''.join(current))
    return parts


def predict(source,definitions=('Wrapper',),*,max_call_depth=1,allow_inputs=False,allow_omitted=False,allow_members=False,owner='POU_01',allocation_context=None,temporary_context=None,pointer_start=None,allocate_owner=True,allow_alternate_banks=False,input_buffer_pool='temporary',allow_concat=False,allow_dynamic_stores=False,allow_string_intrinsics=False,allow_enabled_instructions=False,allow_recursive_booleans=False,allow_general_conditions=False,allow_fx_string_slice=False,allow_loops=False,allow_loop_controls=False,max_loop_depth=1,allow_branch_trees=False,max_if_depth=1,allow_loop_exits=False,allow_repeat_loops=False,allow_case_trees=False,case_capture_preparation='per-arm',allow_nested_cases=False,allow_elsif_chains=False):
    content={k:v for k,v in streams(source).items() if k!='CGTable.dat'}
    context=read_project_text_context(next(v for k,v in content.items() if k.endswith('.prj')))
    fx=context['cpu']=='FX3U/FX3UC' and allow_fx_string_slice
    if context['cpu']!='Q03UDV' and not fx:raise ValueError('unmeasured ST call CPU')
    if max_loop_depth not in (1,2) or (allow_loop_controls or max_loop_depth>1) and not allow_loops:raise ValueError('loop extension requires loop opt-in and depth 1 or 2')
    if fx and allow_loop_controls:raise ValueError('dynamic FOR controls only measured on Q03UDV')
    if (allow_loop_exits or allow_repeat_loops) and not allow_loops:raise ValueError('EXIT/REPEAT require loop opt-in')
    if max_if_depth not in (1,2) or max_if_depth>1 and not allow_branch_trees:raise ValueError('IF extension requires branch-tree opt-in and depth 1 or 2')
    if allow_branch_trees and not allow_general_conditions:raise ValueError('IF trees require typed general conditions')
    if allow_case_trees and not allow_general_conditions:raise ValueError('CASE requires typed general conditions')
    if case_capture_preparation not in ('per-arm','whole-case'):raise ValueError('unknown CASE capture hypothesis')
    if allow_nested_cases and not (allow_case_trees and allow_branch_trees):raise ValueError('nested CASE requires CASE/branch-tree opt-in')
    if allow_elsif_chains and not allow_branch_trees:raise ValueError('ELSIF requires branch-tree opt-in')
    if fx:
        from source_fx_string_slice import rewrite as profile_rewrite
    else:profile_rewrite=rewrite
    def special_bit(number):return scalar('M',number+7600) if fx else scalar('SM',number)
    always_rung=profile_rewrite(bytes.fromhex('0300030591900105'))
    if allow_general_conditions and not (allow_recursive_booleans and allow_enabled_instructions):raise ValueError('general conditions require recursive Boolean and enabled-instruction options')
    if owner+'.Program.pou' not in content or owner+'.Labels.lh' not in content:raise ValueError('source program or declarations missing')
    decl=allocation_context if allocation_context is not None else DirectDeclarations(content,context['text_encoding'],local_fb_definitions=definitions,allow_string_arrays=True,max_local_fb_depth=max_call_depth)
    if allocate_owner:decl.add_owner(owner)
    elif owner not in decl.bound:raise ValueError('preallocated owner missing')
    if not allow_alternate_banks and any(decl.ranges[f]['handling']!='unset' for f in ('W','R','ZR')):raise ValueError('ST call profile requires default D temporaries')
    temporary_family='D'
    for family in ('D','W','R','ZR'):
        if decl.ranges[family]['handling']=='range':temporary_family=family
    temporary_bit_family='B' if decl.ranges['B']['handling']=='range' else 'M'
    if input_buffer_pool not in ('temporary','ordinary'):raise ValueError('unknown INPUT bank hypothesis')
    pointer_pool=decl.ranges['P']
    slots=temporary_context if temporary_context is not None else []
    records=[];events=[];transfers=[];input_buffers=[];omitted_ports=[];member_bindings={};member_reads=[];next_label=pointer_pool['lower'] if pointer_start is None else pointer_start;initial_rung=True
    def supported_type(data_type):return data_type=='INT' or allow_string_intrinsics and data_type=='WORD' or allow_enabled_instructions and data_type=='BOOL' or re.fullmatch(r'STRING\[[1-9][0-9]*\]',data_type)
    for declared in decl.bound.values():
        for it in declared.values():
            if fx and it['row'].data_type.split(' OF ')[-1]=='BOOL':raise ValueError('FX Boolean declarations outside measured string slice')
            if it.get('dimensions') and supported_type(it['row'].data_type.split(' OF ')[-1]) and it['count']>32768:
                raise ValueError('INT/STRING array exceeds observed 32768-word declaration bound')
    def parse_expression(text):
        if re.fullmatch(r"'[ -&(-~]*'",text):return ('string',text[1:-1])
        cast=re.fullmatch(r'WORD_TO_INT\s*\((.*)\)',text,re.S|re.I) if fx else None
        if cast:return ('word_to_int',parse_expression(cast[1].strip()))
        if allow_recursive_booleans and allow_enabled_instructions:
            text=text.strip()
            def top_level_positions(raw):
                depth=0;positions=[]
                for i,char in enumerate(raw):
                    if char in '([':depth+=1
                    elif char in ')]':depth-=1
                    elif depth==0:positions.append(i)
                if depth:raise ValueError('unbalanced recursive Boolean expression')
                return positions
            while text.startswith('(') and text.endswith(')') and not top_level_positions(text):
                text=text[1:-1].strip()
            top=set(top_level_positions(text))
            for op in ('OR','XOR','AND'):
                matches=[m for m in re.finditer(r'\b'+op+r'\b',text,re.I) if m.start() in top]
                if matches:
                    m=matches[-1]
                    return (op.lower(),parse_expression(text[:m.start()]),parse_expression(text[m.end():]))
            if allow_general_conditions:
                relation=re.fullmatch(r'(.+?)\s*(<>|<=|>=|=|<|>)\s*(-?[0-9]+)',text,re.S)
                if relation:return ('relation',relation[2],parse_expression(relation[1].strip()),int(relation[3]))
            comparison=re.fullmatch(r'(.+?)\s*>\s*(-?[0-9]+)',text)
            if comparison:return ('compare',parse_expression(comparison[1]),int(comparison[2]))
        if allow_enabled_instructions:
            if text.upper() in ('TRUE','FALSE'):return ('bool',text.upper()=='TRUE')
            negate=re.fullmatch(r'NOT\s+(.+)',text,re.I|re.S)
            if negate:
                inner=negate[1].strip()
                if inner.startswith('(') and inner.endswith(')'):inner=inner[1:-1].strip()
                arg=parse_expression(inner)
                return arg[1] if isinstance(arg,tuple) and arg[0]=='not' else ('not',arg)
            comparison=re.fullmatch(r'([A-Za-z_][A-Za-z_0-9]*)\s*>\s*(-?[0-9]+)',text)
            if comparison:return ('compare',comparison[1],int(comparison[2]))
            atom=r'[A-Za-z_][A-Za-z_0-9]*(?:\.[A-Za-z_][A-Za-z_0-9]*)?(?:\[[^\[\]]+\])?'
            boolean=re.fullmatch(r'('+atom+r')\s+(OR|AND)\s+('+atom+r')',text,re.I)
            if boolean:return (boolean[2].lower(),parse_expression(boolean[1]),parse_expression(boolean[3]))
        conversion=re.fullmatch(r'(WORD_TO_STR|INT_TO_STR)\s*\((.*)\)',text,re.S|re.I)
        if conversion and allow_string_intrinsics:
            return ('conversion',conversion[1].upper(),parse_expression(conversion[2].strip()))
        call=re.fullmatch(r'CONCAT\s*\((.*)\)',text,re.S|re.I)
        if call and allow_concat:
            args=split_operands(call[1])
            if len(args)!=2:raise ValueError('bounded CONCAT requires two arguments')
            return ('concat',*(parse_expression(a.strip()) for a in args))
        return expression(text,allow_qualified=allow_members)
    def value(raw,slot=None,**metadata):return dict(raw=raw,slot=slot,**metadata)
    def raw_emit(family,variant,*operands):records.append(profile_rewrite(bytes([5,family,3,variant,5])+b''.join(o['raw'] for o in operands)))
    def consume(*operands):
        # Deferred OUTPUT indices are restored when the operand is consumed.
        # Direct aliases do not restore their earlier Z16 value, so restoring a
        # later alias can change both operands of one native instruction.
        for operand in operands:
            temporary=operand.get('deferred_index')
            if temporary is not None:
                raw_emit(0x4c,1,temporary,value(bytes([4,0xcc,16,4])))
    def emit(family,variant,*operands):
        consume(*operands)
        raw_emit(family,variant,*operands)
    def acquire(width=1,kind='word',request_family=None):
        def native_type(family):return {'M':77,'B':66,'D':68,'W':87,'R':82,'ZR':82}[family]+(32 if kind=='double' else 0)
        requested_type=native_type(request_family or (temporary_bit_family if kind=='bit' else temporary_family))
        for i,s in enumerate(slots):
            if s['state']==2 and s['width']>=width and s['kind']==kind and s.get('native_type',native_type(s['family']))==requested_type:
                s['state']=1;events.append(dict(action='reuse',slot=i,number=s['number'],width=width,capacity=s['width']));return value(s['raw'],i)
        family,number,_=decl.allocate('M',width,fixed_pool=temporary_bit_family) if kind=='bit' else decl.allocate('D',width,fixed_pool=temporary_family)
        i=len(slots);slots.append(dict(state=1,width=width,kind=kind,family=family,number=number,raw=scalar(family,number),native_type=native_type(family),creation_request_type=requested_type))
        events.append(dict(action='create',slot=i,number=number,width=width,request_type=requested_type));return value(slots[i]['raw'],i)
    def release(v):
        if v['slot'] is not None:
            i=v['slot'];assert slots[i]['state']==1;slots[i]['state']=2;events.append(dict(action='release',slot=i))
    def reacquire_operand(v):
        i=v['slot'];assert i is not None and slots[i]['state']==2 and slots[i]['kind']=='bit' and slots[i]['width']==1
        requested_type=66 if temporary_bit_family=='B' else 77
        assert slots[i]['native_type']==requested_type
        slots[i]['state']=1
        events.append(dict(action='reacquire-operand',slot=i,type=requested_type,number=slots[i]['number'],width=1))
    def member(scope,name):
        if not allow_members or name.count('.')!=1:raise ValueError('outside enabled qualified member reads')
        prefix,key=name.casefold().split('.')
        instance=decl.bound[scope].get(prefix,{})
        child=instance.get('instance');port=decl.bound.get(child,{}).get(key,{})
        if not port.get('port'):raise ValueError('qualified name is not a selected scalar FB port')
        return child,key,port
    def item(scope,name):
        if '.' in name:return member(scope,name)[2]
        result=decl.bound[scope].get(name.casefold())
        if result is None:raise ValueError('unresolved local name '+name)
        return result
    def variable(scope,name,aliases):
        if '.' in name:
            child,key,_=member(scope,name)
            if key not in member_bindings.get(child,{}):raise ValueError('member read before a measured call binding')
            alias=member_bindings[child][key]
            member_reads.append(dict(scope=scope,name=name,instance=child,port=key,raw=alias['raw'].hex(),
                caveat='Last static call binding; may refer to a skipped input capture or a released IN_OUT slot.'))
            return value(alias['raw'],**{k:alias[k] for k in ('deferred_index','immutable_literal') if k in alias})
        if name.casefold() in aliases:
            alias=aliases[name.casefold()]
            return value(alias['raw'],**{k:alias[k] for k in ('deferred_index','immutable_literal') if k in alias})
        it=item(scope,name)
        if not supported_type(it['row'].data_type) or it.get('port') or it.get('dimensions'):raise ValueError('outside local scalar INT/STRING')
        return value(decl.bind(scope,name.encode(context['text_encoding'])))
    def indexed(node):return isinstance(node,tuple) and node[0]=='index'
    def contains_index(node):return indexed(node) or isinstance(node,tuple) and any(contains_index(x) for x in node[1:])
    def require_int(scope,node):
        if isinstance(node,int):return
        if fx and isinstance(node,tuple) and node[0]=='word_to_int':
            if isinstance(node[1],str) and item(scope,node[1])['row'].data_type=='WORD':return
            raise ValueError('FX WORD_TO_INT requires measured scalar WORD')
        if isinstance(node,str) or indexed(node):
            it=item(scope,node if isinstance(node,str) else node[1])
            if it['row'].data_type.split(' OF ')[-1]=='INT':return
        elif isinstance(node,tuple) and node[0] in ('+','-'):
            require_int(scope,node[1]);require_int(scope,node[2]);return
        raise ValueError('outside measured INT expression')
    def address(scope,node,aliases,register=16,defer_output=False):
        _,name,index=node;it=item(scope,name)
        if it.get('port') or not supported_type(it['row'].data_type.split(' OF ')[-1]) or len(it.get('dimensions',()))!=1 or it['dimensions'][0]['lower']!=0 or it['family'] not in (('D','W','R','ZR','M','B') if allow_alternate_banks else ('D','M','B')):
            raise ValueError('outside local zero-based INT/STRING array addressing')
        if isinstance(index,int):return value(decl.bind(scope,f'{name}[{index}]'.encode(context['text_encoding'])))
        rebased=it['count']==32768
        if rebased and it['family']!='ZR':raise ValueError('maximum array rebasing only measured for ZR')
        base_number=it['number']+(32768 if rebased else 0)
        def adjust_index(target):
            if rebased:emit(0x49,4,value(b'\x07\xe9'+(-32768).to_bytes(4,'little',signed=True)+b'\x07'),target)
        if contains_index(index):raise ValueError('nested array indices have known native register-clobber counterexamples')
        require_int(scope,index)
        iv=lower(scope,index,aliases)
        if defer_output:
            temporary=acquire(2,kind='double');emit(0x49,8,iv,value(integer16(1)),temporary);release(iv)
            if it['stride']!=1:
                if it['stride']>255:raise ValueError('unmeasured array stride')
                emit(0x49,8,temporary,value(bytes([4,0xea,it['stride'],4])),temporary)
            adjust_index(temporary)
            return value(bytes([4,0xf6 if it['family']=='ZR' else 0xf0,16,4])+scalar(it['family'],base_number),deferred_index=temporary)
        z=value(bytes([4,0xcc,register,4]))
        if register==16:
            emit(0x49,8,iv,value(integer16(1)),z);release(iv)
        elif register==18:
            temporary=acquire(2,kind='double');emit(0x49,8,iv,value(integer16(1)),temporary);release(iv)
            if it['stride']!=1:
                if it['stride']>255:raise ValueError('unmeasured array stride')
                emit(0x49,8,temporary,value(bytes([4,0xea,it['stride'],4])),temporary)
            adjust_index(temporary)
            emit(0x4c,1,temporary,z);release(temporary)
            return value(bytes([4,0xf6 if it['family']=='ZR' else 0xf0,register,4])+scalar(it['family'],base_number),indexed=True)
        else:raise ValueError('index register outside measured pair')
        if it['stride']!=1:
            if it['stride']>255:raise ValueError('unmeasured array stride')
            emit(0x49,8,z,value(bytes([4,0xea,it['stride'],4])),z)
        adjust_index(z)
        return value(bytes([4,0xf6 if it['family']=='ZR' else 0xf0,register,4])+scalar(it['family'],base_number),indexed=True)
    def lower(scope,node,aliases,destination=None,register=16):
        if isinstance(node,str):return variable(scope,node,aliases)
        if isinstance(node,int):return value(integer16(node))
        if fx and isinstance(node,tuple) and node[0]=='word_to_int':
            require_int(scope,node);return lower(scope,node[1],aliases)
        if isinstance(node,tuple) and node[0]=='bool':return value(special_bit(400 if node[1] else 401),immutable_literal=True)
        if isinstance(node,tuple) and node[0]=='string':
            raw=node[1].encode('ascii')
            if len(raw)>32 or b'"' in raw:raise ValueError('outside bounded string literal')
            if not raw:raw=b'\0'  # Native empty literal retains one NUL payload byte.
            return value(bytes([len(raw)+3,0xee])+raw+bytes([len(raw)+3]))
        if indexed(node):return address(scope,node,aliases,register)
        op,left,right=node
        if op not in ('+','-'):raise ValueError('arithmetic operator')
        require_int(scope,node)
        if (contains_index(left) and isinstance(left,tuple) and not indexed(left)) or (contains_index(right) and isinstance(right,tuple) and not indexed(right)):
            raise ValueError('indexed arithmetic subtree materialization not yet modeled')
        lhs=lower(scope,left,aliases)
        rhs=lower(scope,right,aliases,register=18 if lhs.get('indexed') else 16)
        target=destination if destination is not None else acquire()
        # The native operand conversion precedes its two-operand arithmetic
        # optimization; repeated references can emit repeated index restores.
        consume(lhs,rhs,target)
        if fx:
            if op!='+':raise ValueError('FX subtraction outside measured string slice')
            raw_emit(0x49,0x28,lhs,rhs,target)
        elif target['raw']==lhs['raw']:
            raw_emit(0x49,0 if op=='+' else 2,rhs,target)
        elif op=='+' and target['raw']==rhs['raw']:raw_emit(0x49,0,lhs,target)
        else:raw_emit(0x49,1 if op=='+' else 3,lhs,rhs,target)
        release(lhs);release(rhs);return target
    def dynamic_bit(node):return indexed(node) and not isinstance(node[2],int)
    def needs_bool_index(node):
        return dynamic_bit(node) or isinstance(node,tuple) and any(needs_bool_index(arg) for arg in node[1:])
    def direct_condition(node):
        if isinstance(node,tuple) and node[0]=='not':return direct_condition(node[1])
        if isinstance(node,tuple) and node[0] in ('or','and','xor'):return False
        return not needs_bool_index(node)
    relation_variants={'=':0,'<>':1,'>':2,'>=':3,'<':4,'<=':5}
    relation_complements={'=':'<>','<>':'=','>':'<=','>=':'<','<':'>=','<=':'>'}
    def relation_operands(scope,node,aliases):
        _,op,left,right=node
        if isinstance(left,str) or indexed(left):
            typ=item(scope,left[1] if indexed(left) else left)['row'].data_type.split(' OF ')[-1]
        else:require_int(scope,left);typ='INT'
        if typ not in ('INT','WORD'):raise ValueError('condition relation only measured for INT/WORD')
        if typ=='WORD':
            if not 0<=right<=32767:raise ValueError('WORD relation outside measured signed-compatible constant range')
            n=max(1,(right.bit_length()+7)//8)
            constant=integer16(0) if right==0 else bytes([n+3,0xea])+right.to_bytes(n,'little')+bytes([n+3])
        else:constant=integer16(right)
        return relation_variants[op],lower(scope,left,aliases),value(constant)
    def prepare_condition(scope,node,aliases):
        if allow_recursive_booleans and isinstance(node,tuple) and node[0]=='xor':
            left,right=node[1:]
            if any(isinstance(arg,tuple) and arg[0] in ('or','and','xor') for arg in (left,right)):
                raise ValueError('compound XOR operand not yet predicted')
            if direct_condition(right):return dict(xor=True,left=None,right=None)
            def is_leaf(arg):
                return isinstance(arg,str) or isinstance(arg,tuple) and (arg[0]=='bool' or indexed(arg) and isinstance(arg[2],int))
            return dict(xor=True,left=None if is_leaf(left) else acquire(kind='bit'),right=None if is_leaf(right) else acquire(kind='bit'))
        if allow_recursive_booleans and isinstance(node,tuple) and node[0] in ('or','and'):
            left,right=node[1:]
            lhs=prepare_condition(scope,left,aliases);rhs=prepare_condition(scope,right,aliases)
            capture=acquire(kind='bit') if not direct_condition(left) and needs_bool_index(right) else None
            return dict(recursive=True,left=lhs,right=rhs,capture=capture)
        # Reserving an expression's internal capture precedes the consumer's
        # result reservation and all emitted index arithmetic. A direct scalar
        # left operand remains addressable while the right index is prepared.
        if isinstance(node,tuple) and node[0] in ('or','and') and dynamic_bit(node[1]) and dynamic_bit(node[2]):
            return acquire(kind='bit')
        return None
    def bit_result_family(scope,node,aliases):
        if isinstance(node,tuple) and node[0] in ('not','or','and','xor'):
            return bit_result_family(scope,node[1],aliases)
        if indexed(node):return item(scope,node[1])['family']
        if not isinstance(node,str):return None
        if '.' in node:
            member_owner,member_key,_=member(scope,node)
            binding=member_bindings.get(member_owner,{}).get(member_key)
        else:binding=aliases.get(node.casefold())
        family={0x90:'M',0xa0:'B'}.get(binding['raw'][1]) if binding else item(scope,node)['family']
        if family not in ('M','B'):raise ValueError('BOOL capture operand bank outside measured M/B storage')
        return family
    def condition(scope,node,aliases,prepared=None):
        def replace_rung():
            nonlocal initial_rung
            if records and records[-1]==always_rung:records.pop()
            if not records:initial_rung=False
        if isinstance(node,int) and node in (0,1):node=('bool',bool(node))
        if isinstance(node,tuple) and node[0]=='bool':
            replace_rung()
            records.append(bytes.fromhex('030003')+special_bit(400 if node[1] else 401));return
        if not allow_enabled_instructions:raise ValueError('variable enables require the enabled-instruction profile')
        if allow_recursive_booleans and isinstance(node,tuple) and node[0]=='xor':
            left,right=node[1:];plan=prepared if prepared is not None else prepare_condition(scope,node,aliases)
            def operand(arg):
                negate=isinstance(arg,tuple) and arg[0]=='not';arg=arg[1] if negate else arg
                if isinstance(arg,tuple) and arg[0]=='compare':
                    if negate:raise ValueError('NOT comparison XOR operand not yet predicted')
                    require_int(scope,arg[1]);return ('compare',lower(scope,arg[1],aliases),lower(scope,arg[2],aliases))
                if isinstance(arg,tuple) and arg[0]=='bool':v=lower(scope,arg,aliases)
                else:
                    if not (isinstance(arg,str) or indexed(arg)) or item(scope,arg[1] if indexed(arg) else arg)['row'].data_type.split(' OF ')[-1]!='BOOL':
                        raise ValueError('XOR leaf requires BOOL or measured comparison')
                    v=lower(scope,arg,aliases)
                return ('bit',v,negate)
            lhs=rhs=None
            if plan['left'] is not None:
                condition(scope,left,aliases)
                records.append(profile_rewrite(bytes.fromhex('032003')+plan['left']['raw']))
                if needs_bool_index(right):records.append(always_rung)
                lhs=('bit',plan['left'],False)
            if plan['right'] is not None:
                condition(scope,right,aliases)
                records.append(profile_rewrite(bytes.fromhex('032003')+plan['right']['raw']))
                rhs=('bit',plan['right'],False)
            if lhs is None:lhs=operand(left)
            if rhs is None:rhs=operand(right)
            def load(desc,invert=False):
                replace_rung()
                if desc[0]=='compare':records.append(profile_rewrite(bytes([6,0x40,3,5 if invert else 2,0x10,6])+desc[1]['raw']+desc[2]['raw']))
                else:records.append(profile_rewrite(bytes([3,int(bool(desc[2])^invert),3])+desc[1]['raw']))
            def append(desc,invert=False):
                if desc[0]=='compare':records.append(profile_rewrite(bytes([6,0x40,3,5 if invert else 2,0x11,6])+desc[1]['raw']+desc[2]['raw']))
                else:records.append(profile_rewrite(bytes([3,0x0c+int(bool(desc[2])^invert),3])+desc[1]['raw']))
            load(lhs);append(rhs,True);load(lhs,True);append(rhs);records.append(bytes.fromhex('031803'))
            for capture in (plan['left'],plan['right']):
                if capture is not None:release(capture)
            return
        if allow_recursive_booleans and isinstance(node,tuple) and node[0] in ('or','and'):
            left,right=node[1:];plan=prepared if prepared is not None else prepare_condition(scope,node,aliases)
            capture=plan['capture']
            def leaf(node):
                negate=isinstance(node,tuple) and node[0]=='not';arg=node[1] if negate else node
                if isinstance(arg,tuple) and arg[0]=='relation':
                    if negate:raise ValueError('negated relation append not yet predicted')
                    variant,lhs,rhs=relation_operands(scope,arg,aliases)
                    return ('relation',variant,lhs,rhs)
                if isinstance(arg,tuple) and arg[0]=='compare':
                    if negate:raise ValueError('negated comparison append not yet predicted')
                    require_int(scope,arg[1])
                    return ('compare',lower(scope,arg[1],aliases),lower(scope,arg[2],aliases))
                if isinstance(arg,tuple) and arg[0] in ('or','and','xor'):
                    raise ValueError('compound NOT append not yet predicted')
                if isinstance(arg,int) and arg in (0,1):arg=('bool',bool(arg))
                if isinstance(arg,tuple) and arg[0]=='bool':operand=lower(scope,arg,aliases)
                else:
                    if not (isinstance(arg,str) or indexed(arg)) or item(scope,arg[1] if indexed(arg) else arg)['row'].data_type.split(' OF ')[-1]!='BOOL':
                        raise ValueError('recursive logical leaf requires BOOL')
                    operand=lower(scope,arg,aliases)
                return ('negated' if negate else 'bit',operand)
            if capture is not None:
                condition(scope,left,aliases,plan['left'])
                records.append(profile_rewrite(bytes.fromhex('032003')+capture['raw']))
                records.append(always_rung)
                if isinstance(right,tuple) and right[0] in ('or','and','xor'):
                    condition(scope,right,aliases,plan['right'])
                    records.append(profile_rewrite(bytes([3,6 if node[0]=='or' else 0x0c,3])+capture['raw']))
                    release(capture);return
                rhs=leaf(right)
                records.append(profile_rewrite(bytes.fromhex('030003')+capture['raw']))
            elif isinstance(right,tuple) and right[0] in ('or','and','xor'):
                if needs_bool_index(right):
                    condition(scope,right,aliases,plan['right']);rhs=leaf(left)
                    if rhs[0]=='relation':records.append(profile_rewrite(bytes([6,0x40,3,rhs[1],0x12 if node[0]=='or' else 0x11,6])+rhs[2]['raw']+rhs[3]['raw']))
                    elif rhs[0]=='compare':records.append(profile_rewrite(bytes([6,0x40,3,2,0x12 if node[0]=='or' else 0x11,6])+rhs[1]['raw']+rhs[2]['raw']))
                    else:records.append(profile_rewrite(bytes([3,(6 if node[0]=='or' else 0x0c)+(rhs[0]=='negated'),3])+rhs[1]['raw']))
                    return
                condition(scope,left,aliases,plan['left']);condition(scope,right,aliases,plan['right'])
                records.append(bytes([3,0x18 if node[0]=='or' else 0x19,3]));return
            elif needs_bool_index(right):
                rhs=leaf(right);condition(scope,left,aliases,plan['left'])
            else:
                condition(scope,left,aliases,plan['left']);rhs=leaf(right)
            if rhs[0]=='relation':
                records.append(profile_rewrite(bytes([6,0x40,3,rhs[1],0x12 if node[0]=='or' else 0x11,6])+rhs[2]['raw']+rhs[3]['raw']))
            elif rhs[0]=='compare':
                records.append(profile_rewrite(bytes([6,0x40,3,2,0x12 if node[0]=='or' else 0x11,6])+rhs[1]['raw']+rhs[2]['raw']))
            else:
                family=(6 if node[0]=='or' else 0x0c)+(rhs[0]=='negated')
                records.append(profile_rewrite(bytes([3,family,3])+rhs[1]['raw']))
            if capture is not None:release(capture)
            return
        if isinstance(node,tuple) and node[0]=='relation':
            variant,lhs,rhs=relation_operands(scope,node,aliases);replace_rung()
            records.append(profile_rewrite(bytes([6,0x40,3,variant,0x10,6])+lhs['raw']+rhs['raw']));return
        if isinstance(node,tuple) and node[0] in ('or','and'):
            left,right=node[1:]
            for arg in (left,right):
                if not (isinstance(arg,str) or indexed(arg)) or item(scope,arg[1] if indexed(arg) else arg)['row'].data_type.split(' OF ')[-1]!='BOOL':
                    raise ValueError('OR/AND currently measured for two scalar or local indexed BOOL leaves')
            capture=prepared if prepared is not None else prepare_condition(scope,node,aliases)
            if capture is not None:
                condition(scope,left,aliases)
                records.append(profile_rewrite(bytes.fromhex('032003')+capture['raw']))
                records.append(always_rung)
                rhs=lower(scope,right,aliases)
                records.append(profile_rewrite(bytes.fromhex('030003')+capture['raw']))
            elif dynamic_bit(right):
                rhs=lower(scope,right,aliases);condition(scope,left,aliases)
            else:
                condition(scope,left,aliases);rhs=lower(scope,right,aliases)
            records.append(profile_rewrite(bytes([3,6 if node[0]=='or' else 0x0c,3])+rhs['raw']))
            if capture is not None:release(capture)
            return
        if isinstance(node,tuple) and node[0]=='compare':
            require_int(scope,node[1]);lhs=lower(scope,node[1],aliases);rhs=lower(scope,node[2],aliases)
            replace_rung()
            records.append(profile_rewrite(bytes.fromhex('064003021006')+lhs['raw']+rhs['raw']));return
        negate=isinstance(node,tuple) and node[0]=='not'
        name=node[1] if negate else node
        if not (isinstance(name,str) or indexed(name)) or item(scope,name[1] if indexed(name) else name)['row'].data_type.split(' OF ')[-1]!='BOOL':raise ValueError('enabled instruction requires BOOL, a comparison, or literal 0/1')
        operand=lower(scope,name,aliases)
        replace_rung()
        records.append(profile_rewrite(bytes([3,1 if negate else 0,3])+operand['raw']))
    def copy_bit(source_value,destination):
        nonlocal initial_rung
        if any('deferred_index' in v for v in (source_value,destination)):
            raise ValueError('deferred BOOL index restoration not yet measured')
        if records and records[-1]==always_rung:records.pop()
        if not records:initial_rung=False
        records.append(profile_rewrite(bytes.fromhex('030003')+source_value['raw']))
        records.append(profile_rewrite(bytes.fromhex('032003')+destination['raw']))
        records.append(always_rung)
    def assign(scope,target,node,aliases,prepared_concat=None):
        if allow_dynamic_stores and indexed(target) and not isinstance(target[2],int):
            typ=item(scope,target[1])['row'].data_type.split(' OF ')[-1]
            if typ=='BOOL' and allow_enabled_instructions:
                prepared=prepare_condition(scope,node,aliases)
                computed=isinstance(node,tuple) and node[0] in ('or','and','xor') or dynamic_bit(node) or isinstance(node,tuple) and node[0]=='not' and dynamic_bit(node[1])
                if computed:
                    source_value=acquire(kind='bit')
                    condition(scope,node,aliases,prepared)
                    records.append(profile_rewrite(bytes.fromhex('032003')+source_value['raw']))
                    records.append(always_rung)
                    release(source_value)
                    destination=address(scope,target,aliases)
                    reacquire_operand(source_value)
                    records.append(profile_rewrite(bytes.fromhex('030003')+source_value['raw']))
                else:
                    destination=address(scope,target,aliases);condition(scope,node,aliases)
                    source_value=None
                records.append(profile_rewrite(bytes.fromhex('032003')+destination['raw']))
                records.append(always_rung)
                if source_value is not None:release(source_value)
                return
            if not typ.startswith('STRING['):raise ValueError('dynamic stores currently measured only for STRING')
            if isinstance(node,tuple) and node[0]=='concat':raise ValueError('CONCAT directly assigned to dynamic destination rejected by observed native lowering')
            if isinstance(node,tuple) and node[0]=='string':
                if len(node[1])>int(typ[7:-1]):raise ValueError('literal exceeds dynamic destination capacity')
            elif isinstance(node,str) or indexed(node):
                if item(scope,node[1] if indexed(node) else node)['row'].data_type.split(' OF ')[-1]!=typ:raise ValueError('dynamic STRING assignment type mismatch')
            else:raise ValueError('unmeasured dynamic STRING assignment expression')
            source_value=lower(scope,node,aliases)
            destination=address(scope,target,aliases,register=18 if source_value.get('indexed') else 16)
            emit(0x4c,3,source_value,destination);release(source_value)
            return
        if isinstance(target,str):
            if '.' in target:raise ValueError('qualified FB port assignment rejected in the measured native profile')
            it=item(scope,target)
            if it['row'].class_code==3:raise ValueError('assignment to VAR_INPUT rejected by measured frontend')
            destination=variable(scope,target,aliases)
        elif indexed(target) and isinstance(target[2],int):destination=address(scope,target,aliases)
        else:raise ValueError('dynamic array assignment outside ST call profile')
        target_type=item(scope,target if isinstance(target,str) else target[1])['row'].data_type.split(' OF ')[-1]
        string=target_type.startswith('STRING[')
        if target_type=='BOOL':
            condition(scope,node,aliases);records.append(profile_rewrite(bytes.fromhex('032003')+destination['raw']))
            records.append(always_rung);return
        if string and isinstance(node,tuple) and node[0]=='conversion':
            _,operation,arg=node
            if fx and operation=='WORD_TO_STR':raise ValueError('FX3U WORD_TO_STR rejects0x500c1049; no BINHA capability')
            required_type='WORD' if operation=='WORD_TO_STR' else 'INT'
            if required_type=='INT':require_int(scope,arg)
            elif not (isinstance(arg,str) or indexed(arg)) or item(scope,arg[1] if indexed(arg) else arg)['row'].data_type.split(' OF ')[-1]!='WORD':
                raise ValueError('WORD conversion requires a matching scalar/array source')
            if indexed(arg) and not isinstance(arg[2],int):
                source_value=acquire(1,request_family='D');indexed_value=address(scope,arg,aliases)
                emit(0x4c,0,indexed_value,source_value);release(indexed_value)
            else:source_value=lower(scope,arg,aliases)
            emit(0x59,2 if required_type=='WORD' else 0,source_value,destination)
            release(source_value);return
        if string and isinstance(node,tuple) and node[0]=='concat':
            operands=[];captured=[]
            for arg_index,arg in enumerate(node[1:]):
                if isinstance(arg,tuple) and arg[0]=='string':
                    operands.append(lower(scope,arg,aliases));continue
                if not isinstance(arg,str) and not indexed(arg):raise ValueError('nested CONCAT rejected by observed native lowering')
                info=item(scope,arg[1] if indexed(arg) else arg)
                if not re.fullmatch(r'STRING\[[1-9][0-9]*\]',info['row'].data_type.split(' OF ')[-1]):raise ValueError('CONCAT argument must be bounded STRING')
                if indexed(arg) and not isinstance(arg[2],int):
                    # The intrinsic prepares indexed STRING arguments in
                    # separate live slots, before moving/appending the result.
                    scratch=prepared_concat[arg_index] if prepared_concat is not None else acquire(info['stride'],request_family='D')
                    source_value=address(scope,arg,aliases)
                    emit(0x4c,3,source_value,scratch);release(source_value)
                    operands.append(scratch);captured.append(scratch)
                else:operands.append(lower(scope,arg,aliases))
            lhs,rhs=operands
            if rhs['raw']==destination['raw']:raise ValueError('CONCAT right operand aliases destination; native 0x050f0196')
            if fx:
                emit(0x49,0x23,lhs,rhs,destination)
            elif lhs['raw']!=destination['raw'] or 'deferred_index' in lhs or 'deferred_index' in destination:
                emit(0x4c,3,lhs,destination)
            if not fx:emit(0x49,0x22,rhs,destination)
            if prepared_concat is None:
                for scratch in captured:release(scratch)
            return
        if string:
            if isinstance(node,tuple) and node[0]=='string':
                if fx and node[1]=='':
                    records.append(profile_rewrite(bytes.fromhex('032403')+destination['raw']));return
                if len(node[1])>int(target_type[7:-1]):raise ValueError('string literal exceeds destination capacity')
            elif isinstance(node,str) or indexed(node):
                source_type=item(scope,node if isinstance(node,str) else node[1])['row'].data_type.split(' OF ')[-1]
                if source_type!=target_type:raise ValueError('string assignment type mismatch')
            else:raise ValueError('unmeasured STRING expression')
        elif target_type=='WORD':
            if not (isinstance(node,int) and 0<=node<=32767 or isinstance(node,str) and item(scope,node)['row'].data_type=='WORD'):
                raise ValueError('WORD assignment only measured for positive small literal or scalar')
        else:require_int(scope,node)
        if isinstance(node,tuple) and node[0] in ('+','-'):lower(scope,node,aliases,destination)
        else:
            source_value=lower(scope,node,aliases)
            if not string and source_value['raw']==destination['raw'] and 'deferred_index' not in source_value and 'deferred_index' not in destination:
                release(source_value);return
            emit(0x4c,3 if string else 0,source_value,destination);release(source_value)
    def body(scope,definition,aliases,allow_calls):
        nonlocal next_label,initial_rung
        _,text=replace_observed_st(content[definition+'.Program.pou'],'')
        branches=[];branch_captures=[];prepared_by_statement={};loops=[]
        statements=[]
        for part in source_statements(text):
            # Split chained loop headers without changing original source bytes.
            part=part.strip()
            while True:
                chained=re.fullmatch(r'((?:FOR|WHILE)\s+.+?\s+DO)\s+((?:FOR|WHILE)\b.*)',part,re.S|re.I) if allow_loops else None
                if chained is None:break
                statements.append(chained[1]);part=chained[2]
            statements.append(part)
        def execute_leaf(statement,prepared_concat=None):
            if statement.upper()=='EXIT':
                if not allow_loop_exits or not loops:raise ValueError('EXIT outside selected loop profile')
                loop=loops[-1]
                following=next((s.strip() for s in statements[ordinal+1:] if s.strip()),'')
                if not fx and loop['kind']=='FOR' and following=='END_FOR':
                    raise ValueError('Q FOR ending directly in EXIT emits a native tail rejected by fresh ProgramCheck (0x050c9322)')
                if loop['end'] is None:loop['end']=branch_label()
                # Q's native EXIT is JMP and does not consume a rung. FX's
                # equivalent needs an explicit true condition after an IF test.
                if not fx and records and records[-1]==always_rung:records.pop()
                emit(0x4d if fx else 0x68,0,value(loop['end']));return
            call=re.fullmatch(r'([A-Za-z_][A-Za-z_0-9]*)\s*\((.*)\)',statement,re.S)
            if call:
                if loops:raise ValueError('instruction/FB call inside loop outside measured profile')
                operation=call[1].upper()
                if allow_string_intrinsics and operation=='RIGHT' or allow_enabled_instructions and operation in ('LEFT','MOV'):
                    args=[parse_expression(a.strip()) for a in split_operands(call[2])]
                    if len(args)!=(3 if operation=='MOV' else 4):raise ValueError('enabled instruction argument count')
                    enabled,source_arg,target_arg=args[0],args[1],args[-1]
                    count_arg=args[2] if operation!='MOV' else None
                    for arg in (source_arg,target_arg):
                        if operation=='MOV':require_int(scope,arg)
                        elif not (isinstance(arg,str) or indexed(arg)) or not item(scope,arg[1] if indexed(arg) else arg)['row'].data_type.split(' OF ')[-1].startswith('STRING['):
                            raise ValueError('RIGHT/LEFT require STRING source/destination')
                    if not (isinstance(target_arg,str) or indexed(target_arg)):raise ValueError('enabled instruction output requires a writable target')
                    if indexed(target_arg) and not isinstance(target_arg[2],int) and indexed(source_arg) and not isinstance(source_arg[2],int):
                        raise ValueError('enabled instruction with two dynamic array indices rejected by fresh ProgramCheck (0x050c9322)')
                    if isinstance(target_arg,str) and '.' in target_arg:raise ValueError('enabled instruction qualified destination not measured')
                    if contains_index(count_arg):raise ValueError('indexed count not yet measured')
                    if item(scope,target_arg[1] if indexed(target_arg) else target_arg)['row'].class_code==3:raise ValueError('enabled instruction cannot write a VAR_INPUT directly')
                    if count_arg is not None:require_int(scope,count_arg)
                    enable_capture=None
                    complex_enable=isinstance(enabled,tuple) and enabled[0] in ('not','compare','or','and','xor') or indexed(enabled) and not isinstance(enabled[2],int)
                    def needs_preparation(arg):
                        return indexed(arg) and not isinstance(arg[2],int) or isinstance(arg,tuple) and arg[0] in ('+','-')
                    prepared=prepare_condition(scope,enabled,aliases)
                    if complex_enable and any(needs_preparation(arg) for arg in (source_arg,target_arg,count_arg)):
                        enable_capture=acquire(kind='bit',request_family=bit_result_family(scope,enabled,aliases));condition(scope,enabled,aliases,prepared)
                        records.append(profile_rewrite(bytes.fromhex('032003')+enable_capture['raw']))
                        records.append(always_rung)
                    source_value=lower(scope,source_arg,aliases)
                    count_value=lower(scope,count_arg,aliases) if count_arg is not None else None
                    destination=lower(scope,target_arg,aliases)
                    if any('deferred_index' in v for v in (source_value,destination) if v):raise ValueError('enabled instruction deferred FB output restoration not yet measured')
                    if enable_capture is None:condition(scope,enabled,aliases,prepared)
                    else:records.append(profile_rewrite(bytes.fromhex('030003')+enable_capture['raw']))
                    if operation=='MOV':emit(0x4c,0,source_value,destination)
                    else:emit(0x59,0x16 if operation=='RIGHT' else 0x17,source_value,destination,count_value)
                    release(source_value)
                    if count_value is not None:release(count_value)
                    if enable_capture is not None:release(enable_capture)
                    records.append(always_rung);return
                if not allow_calls:raise ValueError('nested FB calls outside measured profile')
                actuals={}
                for arg in (split_operands(call[2]) if call[2].strip() else []):
                    name,actual=arg.split(':=',1);name=name.strip().casefold()
                    if name in actuals:raise ValueError('duplicate named actual')
                    actuals[name]=parse_expression(actual.strip())
                invoke(scope,call[1],actuals,aliases);return
            if ':=' not in statement:raise ValueError('outside straight-line ST statements')
            target,rhs=statement.split(':=',1)
            assign(scope,expression(target.strip(),allow_qualified=allow_members),parse_expression(rhs.strip()),aliases,prepared_concat)
        def loop_relation(predicate,lhs,rhs,append=False,logic=None):
            nonlocal initial_rung
            logic_code=0x12 if logic=='OR' else 0x11 if append else 0x10
            if logic_code==0x10:
                if records and records[-1]==always_rung:records.pop()
                if not records:initial_rung=False
            records.append(profile_rewrite(bytes([6,0x40,3,relation_variants[predicate],logic_code,6])+lhs['raw']+rhs['raw']))
        def reserve_concat_candidates(candidates):
            reserved=[]
            for pos,block_statement in candidates:
                # An enclosing loop prepares captures in nested IF statements
                # too. Strip their header solely for this typed prepass.
                block_statement=re.sub(r'^(?:IF\s+.+?\s+THEN|(?:FOR|WHILE)\s+.+?\s+DO|REPEAT\b)\s*', '', block_statement, flags=re.S|re.I)
                if not re.search(r':=\s*CONCAT\s*\(',block_statement,re.I):continue
                concat=parse_expression(block_statement.split(':=',1)[1].strip())
                if not isinstance(concat,tuple) or concat[0]!='concat':raise ValueError('unmeasured block CONCAT form')
                captures={}
                for arg_index,arg in enumerate(concat[1:]):
                    if indexed(arg) and not isinstance(arg[2],int):
                        info=item(scope,arg[1])
                        if not re.fullmatch(r'STRING\[[1-9][0-9]*\]',info['row'].data_type.split(' OF ')[-1]):raise ValueError('block CONCAT requires STRING array')
                        scratch=acquire(info['stride'],request_family='D');captures[arg_index]=scratch;reserved.append(scratch)
                if captures:prepared_by_statement[pos]=captures
            return reserved
        def branch_label():
            nonlocal next_label
            if pointer_pool['handling']!='range' or next_label>pointer_pool['upper']:raise ValueError('branch P pointer pool unavailable or exhausted')
            result=bytes([5,0xd0])+next_label.to_bytes(2,'little')+b'\x05';next_label+=1
            return result
        def label_here(label):
            if records and records[-1]==always_rung:records.pop()
            records.append((bytes.fromhex('043c0204') if fx else bytes.fromhex('033c03'))+label)
            records.append(always_rung)
        def branch_condition(text,complement=False):
            node=parse_expression(text.strip())
            if not (isinstance(node,tuple) and node[0]=='relation' and isinstance(node[2],str) and isinstance(node[3],int)):
                raise ValueError('branch-tree condition requires measured scalar INT/WORD relation')
            if complement:node=('relation',relation_complements[node[1]],node[2],node[3])
            condition(scope,node,aliases)
        def render_branch_sequence(nodes,continuation):
            for index,child in enumerate(nodes):
                if child['kind']=='if':render_branch(child,continuation if index==len(nodes)-1 else None)
                elif child['kind']=='case':render_case(child,embedded=True,prepared_by_parent=True)
                else:
                    if re.match(r'\w+\s*\(',child['text']):raise ValueError('calls inside IF tree outside measured assignment profile')
                    execute_leaf(child['text'],prepared_by_statement.get(child['ordinal']))
        def render_branch(node,inherited=None):
            if node['otherwise'] is None:
                end=inherited if inherited is not None else branch_label()
                branch_condition(node['condition'],True);emit(0x4d,0,value(end));records.append(always_rung)
                render_branch_sequence(node['then'],end)
            else:
                take=branch_label();end=inherited if inherited is not None else branch_label()
                branch_condition(node['condition']);emit(0x4d,0,value(take));records.append(always_rung)
                render_branch_sequence(node['otherwise'],end)
                # Q has unconditional JMP. Measured FX uses the still-enabled
                # CJ after its ELSE data instructions under M8000.
                if not fx and len(records)>=2 and records[-1]==always_rung and records[-2].startswith(bytes.fromhex('033c03')):
                    # A nested CASE owns its end label; no condition rung is
                    # emitted between that label and the enclosing Q JMP.
                    records.pop()
                emit(0x4d if fx else 0x68,0,value(end));label_here(take)
                render_branch_sequence(node['then'],end)
            if inherited is None:label_here(end)
        def render_case(node,embedded=False,prepared_by_parent=False):
            if (loops or branches or embedded) and not allow_nested_cases:raise ValueError('CASE inside another control block outside selected profile')
            prepared_by_parent=prepared_by_parent or bool(loops)
            selector=parse_expression(node['selector'].strip());require_int(scope,selector)
            if not (isinstance(selector,str) or isinstance(selector,tuple) and selector[0] in ('+','-') and all(isinstance(arg,(str,int)) for arg in selector[1:])):
                raise ValueError('CASE selector requires scalar INT or one arithmetic level')
            selected_value=lower(scope,selector,aliases)
            # The selector is prepared before branch captures. Each arm then
            # prepares its own captures, retaining those of earlier arms.
            # An arithmetic selector remains live through the entire CASE.
            from source_st_branch_trees import source_leaves
            captures=reserve_concat_candidates([(leaf['ordinal'],leaf['text']) for leaf in source_leaves(node)]) if case_capture_preparation=='whole-case' and not prepared_by_parent else []
            skip=branch_label();end=None
            for index,arm in enumerate(node['arms']):
                if index:skip=branch_label()
                if case_capture_preparation=='per-arm' and not prepared_by_parent:
                    captures.extend(reserve_concat_candidates([(leaf['ordinal'],leaf['text']) for child in arm['body'] for leaf in (source_leaves(child) if child['kind']!='statement' else [child])]))
                # Each term is a nonmembership test. Singletons append AND<>,
                # while a range forms (< low OR > high), joined with ANB.
                for term_index,term in enumerate(arm['selections']):
                    if term['kind']=='value':loop_relation('<>',selected_value,value(integer16(term['value'])),append=term_index>0)
                    else:
                        loop_relation('<',selected_value,value(integer16(term['lower'])))
                        loop_relation('>',selected_value,value(integer16(term['upper'])),logic='OR')
                        if term_index:records.append(bytes.fromhex('031903'))
                emit(0x4d,0,value(skip));records.append(always_rung)
                render_branch_sequence(arm['body'],None)
                if node['otherwise'] is not None or index<len(node['arms'])-1:
                    if end is None:end=branch_label()
                    if not fx and records and records[-1]==always_rung:records.pop()
                    emit(0x4d if fx else 0x68,0,value(end))
                label_here(skip)
            if case_capture_preparation=='per-arm' and not prepared_by_parent:
                captures.extend(reserve_concat_candidates([(leaf['ordinal'],leaf['text']) for child in node['otherwise'] or [] for leaf in (source_leaves(child) if child['kind']!='statement' else [child])]))
            render_branch_sequence(node['otherwise'] or [],None)
            if end is None:end=branch_label()
            label_here(end)
            for capture in captures:release(capture)
            release(selected_value)
        skipped_until=-1
        for ordinal,statement in enumerate(statements):
            if ordinal<skipped_until:continue
            statement=statement.strip()
            if not statement:continue
            repeat_close=re.fullmatch(r'UNTIL\s+(.+?)\s+END_REPEAT',statement,re.S|re.I) if allow_repeat_loops else None
            if repeat_close:
                if not loops or loops[-1]['kind']!='REPEAT':raise ValueError('unmatched REPEAT terminator')
                loop=loops.pop();branch_condition(repeat_close[1],True);emit(0x4d,0,value(loop['head']))
                if loop['end'] is not None:label_here(loop['end'])
                else:records.append(always_rung)
                for scratch in loop['captures']:release(scratch)
                continue
            if statement in ('END_FOR','END_WHILE') and allow_loops:
                expected='FOR' if statement=='END_FOR' else 'WHILE'
                if not loops or loops[-1]['kind']!=expected:raise ValueError('unmatched loop terminator')
                loop=loops.pop()
                if len(branches)!=loop['branch_depth']:raise ValueError('loop terminator crosses an open IF')
                if expected=='FOR':
                    counter=variable(scope,loop['counter'],aliases);step=loop['step_value']
                    if fx:emit(0x49,0x28,step,counter,counter)
                    else:emit(0x49,0,step,counter)
                records.append(always_rung);emit(0x4d,0,value(loop['head']))
                records.append((bytes.fromhex('043c0204') if fx else bytes.fromhex('033c03'))+loop['end'])
                for scratch in loop['captures']:release(scratch)
                for scratch in loop.get('control_values',[]):release(scratch)
                records.append(always_rung);continue
            loop_for=re.fullmatch(r'FOR\s+([A-Za-z_][A-Za-z_0-9]*)\s*:=\s*(.+?)\s+TO\s+(.+?)(?:\s+BY\s+(.+?))?\s+DO(?:\s+(.*))?',statement,re.S|re.I) if allow_loops else None
            loop_while=re.fullmatch(r'WHILE\s+(.+?)\s+DO(?:\s+(.*))?',statement,re.S|re.I) if allow_loops else None
            loop_repeat=re.fullmatch(r'REPEAT(?:\s+(.*))?',statement,re.S|re.I) if allow_repeat_loops else None
            if loop_for or loop_while or loop_repeat:
                if len(loops)>=max_loop_depth or branches:raise ValueError('nested loop/control-flow outside selected profile')
                if loops and (not loop_for or loops[-1]['kind']!='FOR'):raise ValueError('only two nested FOR loops measured')
                if not allow_general_conditions:raise ValueError('loop profile requires typed conditions')
                if pointer_pool['handling']!='range' or next_label+(0 if loop_repeat else 1)>pointer_pool['upper']:raise ValueError('loop P pointers unavailable or exhausted')
                head=bytes([5,0xd0])+next_label.to_bytes(2,'little')+b'\x05'
                end=None if loop_repeat else bytes([5,0xd0])+(next_label+1).to_bytes(2,'little')+b'\x05';next_label+=1 if loop_repeat else 2
                following=(loop_for[5] if loop_for else loop_while[2] if loop_while else loop_repeat[1]) or ''
                candidates=[(ordinal,following)];closing='END_FOR' if loop_for else 'END_WHILE' if loop_while else 'END_REPEAT';depth=0
                for pos in range(ordinal+1,len(statements)):
                    block_statement=statements[pos].strip()
                    if re.match(r'(FOR|WHILE|REPEAT)\b',block_statement,re.I):depth+=1
                    repeat_end=re.fullmatch(r'UNTIL\s+.+?\s+END_REPEAT',block_statement,re.S|re.I)
                    if block_statement in ('END_FOR','END_WHILE') or repeat_end:
                        if depth==0:
                            if ('END_REPEAT' if repeat_end else block_statement)!=closing:raise ValueError('mismatched loop prepass terminator')
                            break
                        depth-=1
                    candidates.append((pos,block_statement))
                else:raise ValueError('unterminated loop prepass')
                captures=[] if loops else reserve_concat_candidates(candidates)
                if loop_for:
                    counter=loop_for[1];start=parse_expression(loop_for[2]);stop=parse_expression(loop_for[3]);step=parse_expression(loop_for[4] or '1')
                    if not allow_loop_controls and not (isinstance(start,int) and isinstance(stop,int) and isinstance(step,int) and 0<=start<=32767 and 0<=stop<=32767 and 1<=step<=32767):raise ValueError('FOR profile requires nonnegative bounds and positive step')
                    if isinstance(step,int) and not 1<=step<=32767:raise ValueError('nonpositive constant FOR step unmeasured')
                    for control in (start,stop,step):
                        require_int(scope,control)
                        if contains_index(control):raise ValueError('indexed FOR control expressions unmeasured')
                    info=item(scope,counter)
                    if info['row'].data_type!='INT' or info['row'].class_code!=1 or info.get('dimensions'):raise ValueError('FOR requires scalar local INT')
                    assign(scope,counter,start,aliases)
                    if records and records[-1]==always_rung:records.pop()
                    records.append((bytes.fromhex('043c0204') if fx else bytes.fromhex('033c03'))+head)
                    if any(isinstance(x,tuple) and x[0] in ('+','-') for x in (stop,step)):records.append(always_rung)
                    bound_value=lower(scope,stop,aliases);step_value=lower(scope,step,aliases);counter_value=variable(scope,counter,aliases)
                    if isinstance(step,int):loop_relation('>',counter_value,bound_value);emit(0x4d,0,value(end))
                    else:
                        loop_relation('>',step_value,value(integer16(0)));loop_relation('>',counter_value,bound_value,True);emit(0x4d,0,value(end))
                        loop_relation('<=',step_value,value(integer16(0)));loop_relation('<',counter_value,bound_value,True);emit(0x4d,0,value(end))
                    loops.append(dict(kind='FOR',counter=counter,step_value=step_value,head=head,end=end,captures=captures,control_values=[bound_value,step_value],branch_depth=len(branches)))
                elif loop_while:
                    test=parse_expression(loop_while[1].strip())
                    if not (isinstance(test,tuple) and test[0]=='relation' and test[1]=='<' and isinstance(test[2],str) and item(scope,test[2])['row'].data_type=='INT' and isinstance(test[3],int) and 0<=test[3]<=32767):raise ValueError('WHILE profile requires scalar INT < nonnegative literal')
                    node=('relation','>=',test[2],test[3]);loops.append(dict(kind='WHILE',head=head,end=end,captures=captures,branch_depth=len(branches)))
                    if records and records[-1]==always_rung:records.pop()
                    records.append((bytes.fromhex('043c0204') if fx else bytes.fromhex('033c03'))+head)
                    condition(scope,node,aliases);emit(0x4d,0,value(end))
                else:
                    loops.append(dict(kind='REPEAT',head=head,end=None,captures=captures,branch_depth=len(branches)))
                    if records and records[-1]==always_rung:records.pop()
                    records.append((bytes.fromhex('043c0204') if fx else bytes.fromhex('033c03'))+head)
                records.append(always_rung);statement=following.strip()
                if not statement:continue
            if allow_branch_trees and re.match(r'IF\b',statement,re.I):
                from source_st_branch_trees import parse_if,source_leaves
                tree,skipped_until=parse_if(statements,ordinal,first=statement,max_depth=max_if_depth,allow_cases=allow_nested_cases,allow_elsif=allow_elsif_chains)
                captures=[] if loops else reserve_concat_candidates([(leaf['ordinal'],leaf['text']) for leaf in source_leaves(tree)])
                render_branch(tree)
                for capture in captures:release(capture)
                continue
            if allow_case_trees and re.match(r'CASE\b',statement,re.I):
                from source_st_branch_trees import parse_case
                tree,skipped_until=parse_case(statements,ordinal,first=statement,max_depth=max_if_depth,allow_nested=allow_nested_cases,allow_elsif=allow_elsif_chains)
                render_case(tree);continue
            if statement=='END_IF':
                if not branches:raise ValueError('END_IF without IF')
                if loops and len(branches)<=loops[-1]['branch_depth']:raise ValueError('END_IF crosses an open loop')
                if records and records[-1]==always_rung:records.pop()
                records.append((bytes.fromhex('043c0204') if fx else bytes.fromhex('033c03'))+branches.pop())
                for scratch in branch_captures.pop():release(scratch)
                records.append(always_rung);continue
            conditional=re.fullmatch(r'IF\s+(.+?)\s+THEN\s+(.*)',statement,re.S|re.I) if allow_general_conditions else re.fullmatch(r'IF\s+([A-Za-z_][A-Za-z_0-9]*)\s*>\s*(-?[0-9]+)\s+THEN\s+(.*)',statement,re.S)
            if allow_general_conditions and conditional is None:
                # Real Keypad source joins a numeric comparison and THEN.
                conditional=re.fullmatch(r'IF\s+(.+?(?:<>|<=|>=|=|<|>)\s*-?[0-9]+)THEN\s+(.*)',statement,re.S|re.I)
            if conditional:
                if branches:raise ValueError('nested IF outside measured profile')
                if pointer_pool['handling']!='range' or next_label>pointer_pool['upper']:raise ValueError('automatic P pointer pool unavailable or exhausted')
                # Native preprocesses indexed CONCAT operands throughout this
                # IF before emitting its condition. All captures stay live
                # until the block's closing label, even across assignments.
                reserved=[]
                following=conditional[2 if allow_general_conditions else 3]
                candidates=[(ordinal,following)]
                for pos in range(ordinal+1,len(statements)):
                    block_statement=statements[pos].strip()
                    if block_statement=='END_IF':break
                    if re.match(r'IF\b',block_statement,re.I):raise ValueError('nested IF preprocessing outside measured profile')
                    candidates.append((pos,block_statement))
                if not loops:reserved=reserve_concat_candidates(candidates)
                branch_captures.append(reserved)
                if allow_general_conditions:
                    node=parse_expression(conditional[1].strip())
                    if fx:
                        def word_guard(n):
                            if isinstance(n,tuple) and n[0]=='and':return word_guard(n[1]) and word_guard(n[2])
                            return isinstance(n,tuple) and n[0]=='relation' and n[1] in ('=','<>') and isinstance(n[2],str) and item(scope,n[2])['row'].data_type=='WORD'
                        loop_int_guard=bool(loops) and isinstance(node,tuple) and node[0]=='relation' and node[1]=='>' and isinstance(node[2],str) and item(scope,node[2])['row'].data_type=='INT' and node[3]==0
                        if not word_guard(node) and not loop_int_guard:raise ValueError('FX condition outside measured scalar WORD guard or loop INT > 0')
                    if isinstance(node,str) or indexed(node):condition(scope,('not',node),aliases)
                    elif isinstance(node,tuple) and node[0]=='not':condition(scope,node[1],aliases)
                    elif isinstance(node,tuple) and node[0]=='relation':
                        condition(scope,('relation',relation_complements[node[1]],node[2],node[3]),aliases)
                    elif isinstance(node,tuple) and node[0]=='bool':condition(scope,('bool',not node[1]),aliases)
                    else:
                        prepared=prepare_condition(scope,node,aliases);condition(scope,node,aliases,prepared)
                        if fx:
                            capture=acquire(kind='bit')
                            records.append(profile_rewrite(bytes.fromhex('032003')+capture['raw']))
                            records.append(profile_rewrite(bytes.fromhex('030103')+capture['raw']));release(capture)
                        else:records.append(bytes.fromhex('031403'))
                    following=conditional[2]
                else:
                    if item(scope,conditional[1])['row'].data_type!='INT':raise ValueError('only scalar INT conditions')
                    lhs=variable(scope,conditional[1],aliases);rhs=value(integer16(int(conditional[2])))
                    before_condition=len(records)
                    consume(lhs,rhs)
                    # Keep the rung when deferred-index consumption emitted
                    # preparation that needs it; otherwise the condition owns it.
                    if len(records)==before_condition and records and records[-1]==always_rung:records.pop()
                    records.append(profile_rewrite(bytes.fromhex('064003051006')+lhs['raw']+rhs['raw']))
                    following=conditional[3]
                label=bytes([5,0xd0])+next_label.to_bytes(2,'little')+b'\x05';next_label+=1
                emit(0x4d,0,value(label));branches.append(label)
                records.append(always_rung);statement=following
            execute_leaf(statement,prepared_by_statement.get(ordinal))
        if branches:raise ValueError('unterminated IF')
        if loops:raise ValueError('unterminated loop')
    def invoke(scope,name,actuals,parent_aliases):
        if fx and any(not isinstance(arg,str) for arg in actuals.values()):raise ValueError('FX port profile requires direct scalar named actuals')
        instance=item(scope,name)
        if 'instance' not in instance:raise ValueError('not a selected local FB')
        child=instance['instance'];definition=instance['row'].data_type
        ports={k:v for k,v in decl.bound[child].items() if v.get('port')}
        if not set(actuals)<=set(ports) or (not allow_omitted and set(actuals)!=set(ports)):raise ValueError('all measured ports must have named actuals')
        aliases={};copybacks=[];deferred_outputs=[];output_indices=0
        row=dict(instance=child,definition=definition,bindings=[]);transfers.append(row)
        # Measured order: INPUT capture, IN_OUT copy-in, OUTPUT preparation.
        # Per-class record IDs, not named-argument source order, select ports.
        for key,port in sorted(ports.items(),key=lambda kv:({3:0,5:1,4:2}.get(kv[1]['row'].class_code,99),kv[1]['row'].record_id)):
            formal=port['row']
            if not supported_type(formal.data_type) or formal.class_code not in ((3,4,5) if allow_inputs else (4,5)):raise ValueError('outside enabled INT/STRING port directions')
            if key not in actuals:
                if formal.data_type=='BOOL':raise ValueError('omitted BOOL ports not yet measured in this call profile')
                if 'number' not in port:
                    decl.allocate_item(child,port)
                    omitted_ports.append(dict(instance=child,port=key,class_code=formal.class_code,family=port['family'],number=port['number'],width=port['count']))
                aliases[key]=value(scalar(port['family'],port['number']))
                row['bindings'].append(dict(port=key,mode='persistent-omitted-port'))
                continue
            actual=actuals[key]
            if formal.data_type=='BOOL':
                if formal.class_code in (4,5):
                    if not (isinstance(actual,str) or indexed(actual)) or item(scope,actual[1] if indexed(actual) else actual)['row'].data_type.split(' OF ')[-1]!='BOOL':
                        raise ValueError('BOOL writable port requires a matching variable')
                    if indexed(actual) and not isinstance(actual[2],int):
                        if formal.class_code==4 and output_indices:raise ValueError('second indexed BOOL OUTPUT not yet measured')
                        binding=address(scope,actual,parent_aliases)
                        if formal.class_code==5:
                            temporary=acquire(kind='bit');copy_bit(binding,temporary)
                            aliases[key]=temporary;copybacks.append((actual,temporary,'bit'))
                            row['bindings'].append(dict(port=key,mode='copy-in-and-recompute-index-for-copy-back'))
                        else:
                            output_indices+=1;aliases[key]=binding
                            row['bindings'].append(dict(port=key,mode='indexed-alias-before-body',register=16,caveat='body index generation can overwrite this register'))
                    else:
                        binding=lower(scope,actual,parent_aliases)
                        if binding.get('immutable_literal'):raise ValueError('literal BOOL INPUT cannot be forwarded to a writable port')
                        aliases[key]=binding;row['bindings'].append(dict(port=key,mode='direct-alias'))
                    continue
                literal=isinstance(actual,tuple) and actual[0]=='bool'
                capture=isinstance(actual,tuple) and actual[0] in ('not','compare','or','and','xor') or indexed(actual) and not isinstance(actual[2],int)
                if capture:
                    prepared=prepare_condition(scope,actual,parent_aliases)
                    family,number,_=decl.allocate('M',1,fixed_pool=temporary_bit_family)
                    target=value(scalar(family,number));condition(scope,actual,parent_aliases,prepared)
                    records.append(profile_rewrite(bytes.fromhex('032003')+target['raw']));records.append(always_rung)
                    input_buffers.append(dict(instance=child,port=key,family=family,number=number,width=1,actual=actual))
                    aliases[key]=target;row['bindings'].append(dict(port=key,mode='fresh-input-buffer-no-copy-back'));continue
                if not literal and not (isinstance(actual,str) and item(scope,actual)['row'].data_type=='BOOL'):
                    raise ValueError('BOOL INPUT expression capture not yet measured')
                aliases[key]=lower(scope,actual,parent_aliases)
                row['bindings'].append(dict(port=key,mode='inline-literal' if literal else 'direct-input-alias'));continue
            if formal.class_code==3:
                string=formal.data_type.startswith('STRING[')
                literal=isinstance(actual,int) and actual>=0 or isinstance(actual,tuple) and actual[0]=='string'
                if string:
                    if isinstance(actual,tuple) and actual[0]=='string':
                        if len(actual[1])>int(formal.data_type[7:-1]):raise ValueError('INPUT literal exceeds STRING capacity')
                    elif isinstance(actual,str) or indexed(actual):
                        if item(scope,actual[1] if indexed(actual) else actual)['row'].data_type.split(' OF ')[-1]!=formal.data_type:raise ValueError('INPUT STRING type mismatch')
                    else:raise ValueError('outside measured STRING INPUT actuals')
                else:require_int(scope,actual)
                capture=(isinstance(actual,int) and actual<0 or indexed(actual) and not isinstance(actual[2],int) or
                    isinstance(actual,tuple) and actual[0] in ('+','-'))
                if capture:
                    # Native call preparation calls the physical allocator
                    # directly at 0xca1ca. It does not select/release a slot.
                    family,number,_=decl.allocate('D',port['stride'],fixed_pool=temporary_family if input_buffer_pool=='temporary' else None)
                    target=value(scalar(family,number))
                    input_buffers.append(dict(instance=child,port=key,family=family,number=number,width=port['stride'],actual=actual))
                    if indexed(actual) or isinstance(actual,int):
                        source_value=address(scope,actual,parent_aliases) if indexed(actual) else lower(scope,actual,parent_aliases)
                        emit(0x4c,3 if string else 0,source_value,target);release(source_value)
                    else:lower(scope,actual,parent_aliases,destination=target)
                    aliases[key]=target;mode='fresh-input-buffer-no-copy-back'
                else:
                    aliases[key]=lower(scope,actual,parent_aliases)
                    if literal:aliases[key]['immutable_literal']=True
                    mode='inline-literal' if literal else 'direct-input-alias'
                row['bindings'].append(dict(port=key,mode=mode));continue
            actual_type=item(scope,actual[1] if indexed(actual) else actual)['row'].data_type.split(' OF ')[-1]
            if actual_type!=formal.data_type:raise ValueError('port and actual types differ')
            move_variant=3 if formal.data_type.startswith('STRING[') else 0
            if indexed(actual) and not isinstance(actual[2],int):
                if formal.class_code==4 and output_indices>=2:raise ValueError('more than two dynamic OUTPUT indices not measured')
                binding=address(scope,actual,parent_aliases,defer_output=formal.class_code==4 and output_indices>0)
                if formal.class_code==5:
                    temporary=acquire(port['stride']);emit(0x4c,move_variant,binding,temporary)
                    aliases[key]=temporary;copybacks.append((actual,temporary,move_variant))
                    row['bindings'].append(dict(port=key,mode='copy-in-and-recompute-index-for-copy-back'))
                else:
                    output_indices+=1
                    if 'deferred_index' in binding:deferred_outputs.append(binding['deferred_index'])
                    aliases[key]=binding;row['bindings'].append(dict(port=key,mode='deferred-index-alias' if 'deferred_index' in binding else 'indexed-alias-before-body',register=16,
                        caveat='body index generation can overwrite this register'))
            else:
                aliases[key]=address(scope,actual,parent_aliases) if indexed(actual) else variable(scope,actual,parent_aliases)
                if aliases[key].get('immutable_literal'):raise ValueError('literal INPUT forwarded to writable port has no writable destination')
                row['bindings'].append(dict(port=key,mode='direct-alias'))
        member_bindings[child]=aliases
        body(child,definition,aliases,max_call_depth>1)
        for temporary in deferred_outputs:release(temporary)
        for actual,temporary,move_variant in copybacks:
            binding=address(scope,actual,parent_aliases)
            if move_variant=='bit':copy_bit(temporary,binding)
            else:emit(0x4c,move_variant,temporary,binding)
            release(temporary)
    body(owner,owner,{},True)
    # END_IF restores the always-on rung only when subsequent code needs it.
    # At the end of MAIN, native output goes directly from the label to FEND.
    if records and records[-1]==always_rung:records.pop()
    code=(always_rung if initial_rung else b'')+b''.join(records)+(bytes.fromhex('0333030202033403') if fx else bytes.fromhex('033303020204340204'))
    return dict(output=code,sha256=sha256(code),declarations=list(decl.allocations),next_pointer=next_label,
        slots=[{k:v for k,v in s.items() if k!='raw'} for s in slots],temporary_family=temporary_family,temporary_bit_family=temporary_bit_family,input_buffer_pool=input_buffer_pool,temporary_events=events,transfers=transfers,input_buffers=input_buffers,omitted_ports=omitted_ports,member_reads=member_reads,
        temporary_reservation_order_handling='measured IF and loop source-order CONCAT captures; enclosing loop owns inner IF/FOR captures; two FOR levels require max_loop_depth=2; two IF levels require branch-tree opt-in',
        loop_control_handling='Q03UDV scalar/INT arithmetic FOR controls: TO/BY arithmetic evaluated at head and pinned across body; scalar BY remains a live alias' if allow_loop_controls else 'positive constant FOR and scalar INT < literal WHILE only',
        loop_exit_handling='EXIT selects nearest active loop end; Q JMP versus FX true-condition CJ' if allow_loop_exits else 'EXIT unsupported',
        repeat_handling='REPEAT scalar relation tested at bottom; one head label, exit label allocated lazily' if allow_repeat_loops else 'REPEAT unsupported',
        branch_tree_handling='Scalar INT/WORD assignment branches: ELSE first, source-order captures, tail continuation joins shared; at most two IF levels' if allow_branch_trees else 'Legacy flat IF without ELSE only',
        case_tree_handling='INT CASE: positive scalar/range selections, optional ELSE; standalone selector first, captures prepared per arm and retained to the end' if allow_case_trees else 'CASE unsupported',
        case_capture_hypothesis=case_capture_preparation if allow_case_trees else None,
        elsif_chain_handling='At most two ELSIF links lowered to ELSE-child IF trees with shared end; conditions remain bounded scalar relations' if allow_elsif_chains else 'ELSIF unsupported',
        nested_case_handling='CASE nested under IF/FOR/CASE: enclosing block owns captures, CASE end label allocated at first emitted exit' if allow_nested_cases else 'Nested CASE unsupported',
        scope='Bounded FX3U string-slice and loop byte/address prediction with measured CONCAT capture lifetimes; no generic FX ports, Boolean compiler or runtime equivalence claim.' if fx else 'Compiler behavior reproduction only; INPUT can alias indirectly writable storage and indexed OUTPUT can be clobbered. No semantic-safety guarantee.')
