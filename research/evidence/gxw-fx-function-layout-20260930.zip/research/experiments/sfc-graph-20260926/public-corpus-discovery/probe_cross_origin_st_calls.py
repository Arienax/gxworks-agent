"""Source-only FB predictions on an independent SCPI-derived project.

The original ladder bodies are deliberately replaced; this is cross-container
and project-metadata validation, not an independent real ST source lineage.
All four selected logical payloads and predictions are saved before native use.
"""
from pathlib import Path
from dataclasses import replace
import base64,json,struct,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from gxw.declarations import parse_declarations,edit_declarations,serialize_declarations
from gxw.project_metadata import mark_observed_source_compile_pending
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_program_check_resources import SCRIPT
from probe_minimal_conditional_port_writes import streams,save,observe
from probe_cross_source_st_lifetimes import st_source
from source_q_st_calls import predict
from native_gxw_tokens import native_batch,native_il_records,Q_DLL
from verify_temporary_check_correspondence import verify
from probe_gxw_parameters import project_allocation_ranges
P=Path(__file__).resolve().parent


def main():
    config=json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
    out=P/config['directory'];out.mkdir(exist_ok=False);save(out/'experiment-plan.json',config)
    for name in (Path(__file__).name,'source_q_st_calls.py','source_st_branch_trees.py','source_q_direct_declarations.py','source_q_st_expressions.py','source_q_label_binding.py','source_q_width.py'):
        (out/name).write_bytes((P/name).read_bytes())
    extra=''
    if config.get('extra_observer'):
        extra_path=P/config['extra_observer'];extra=extra_path.read_text(encoding='utf-8')
        (out/extra_path.name).write_bytes(extra_path.read_bytes())
    trace=out/'trace.js';trace.write_text('(()=>{'+(P/'native-allocation-bitmap-v2/observer.js').read_text()+'\n'+(P/'observe_expression_temporaries.js').read_text()+'\n'+(P/'observe_index_register_lifetime.js').read_text()+'\n})();\n(()=>{'+SCRIPT+'\n})();\n(()=>{'+extra+'\n})();',encoding='utf-8')
    original=(P/'native-allocation-inventory/case-03/input.gxw').read_bytes();before=streams(original);ready=[]
    for plan in config['cases']:
        d=out/plan['case'];d.mkdir();changes={};typ=plan.get('type','INT')
        logical='MAIN.Labels.lh';doc=parse_declarations(before[logical],logical_name=logical)
        assert not doc.rows
        rows=[dict(name=n,data_type='SCPI',kind='function_block') for n in config.get('instances',('First','Second'))]
        rows += [dict(name='probeArray',data_type=f'ARRAY[0..{plan.get("array_upper",3)}] OF '+typ),dict(name='probeIndex',data_type='INT')]
        rows += [dict(name=n,data_type=typ) for n in ('probeR0','probeR1','probeR2')]
        for row in rows:
            if row['name'] in plan.get('root_types',{}):row['data_type']=plan['root_types'][row['name']]
        doc=edit_declarations(doc,upserts=rows);changes[logical]=serialize_declarations(doc)
        logical='SCPI.Labels.lh';doc=parse_declarations(before[logical],logical_name=logical)
        keep={'iUnitNo':'value','iComCh':'idx','oRecvCmdNum':'result'}
        doc=edit_declarations(doc,remove=[r.name for r in doc.rows if r.name not in keep],renames=keep,
            upserts=[dict(name='value',data_type=typ),dict(name='idx',data_type='INT'),
                     dict(name='result',data_type=typ),dict(name='saved',data_type=typ)])
        additions=plan.get('additional_body_declarations',[])
        if additions:
            existing={r.name.casefold() for r in doc.rows}
            names=[r['name'].casefold() for r in additions]
            assert len(names)==len(set(names)) and not existing.intersection(names)
            doc=edit_declarations(doc,upserts=additions)
        classes={'value':{'VAR_INPUT':3,'VAR_OUTPUT':4,'VAR_IN_OUT':5}[plan.get('value_class','VAR_INPUT')],'idx':5,'result':4}
        if plan.get('body_types'):
            assert set(plan['body_types']) <= {r.name for r in doc.rows}
            doc=edit_declarations(doc,upserts=[dict(name=name,data_type=data_type) for name,data_type in plan['body_types'].items()])
        doc=replace(doc,rows=tuple(replace(r,class_code=classes.get(r.name,r.class_code)) for r in doc.rows))
        changes[logical]=serialize_declarations(doc)
        changes['MAIN.Program.pou']=st_source(before['MAIN.Program.pou'],plan['root'])
        changes['SCPI.Program.pou']=st_source(before['SCPI.Program.pou'],plan['body'])
        pools=dict(plan.get('pools',{}))
        if 'pointer_range' in plan:pools['P']=plan['pointer_range']
        if pools:
            name=next(k for k in before if k.endswith('.prj'))
            ranges={r['name']:r for r in project_allocation_ranges(before[name])['ranges']}
            raw=bytearray(before[name])
            for family,pair in pools.items():struct.pack_into('<II',raw,ranges[family]['offset'],*pair)
            changes[name]=bytes(raw)
        source=original;receipts=[]
        for name,raw in list(changes.items()):
            if not name.endswith('.prj'):raw=mark_observed_source_compile_pending(raw,logical_name=name)
            changes[name]=raw
            source,receipt=patch_raw(source,name,before[name],raw);receipts.append(receipt)
        assert streams(source)==dict(before,**changes)
        path=d/'input.gxw';path.write_bytes(source)
        options=config.get('prediction_options',{})|plan.get('prediction_options',{})
        try:prediction=predict(source,('SCPI',),allow_inputs=True,allow_omitted=True,allow_members=True,owner='MAIN',**options)
        except ValueError as exc:
            if not plan.get('allow_unsupported'):raise
            prediction=dict(output=None,unsupported=str(exc))
        if prediction['output'] is not None:(d/'predicted-0.bin').write_bytes(prediction['output'])
        alternatives=[]
        for key,extra in config.get('alternative_predictions',{}).items():
            try:
                other=predict(source,('SCPI',),allow_inputs=True,allow_omitted=True,allow_members=True,owner='MAIN',**(options|extra))
                (d/f'predicted-{key}.bin').write_bytes(other['output']);alternatives.append(dict(key=key,**{k:v for k,v in other.items() if k!='output'}))
            except ValueError as exc:alternatives.append(dict(key=key,unsupported=str(exc)))
        save(d/'before-native.json',dict(case=plan['case'],original_sha256=sha256(original),input_sha256=sha256(source),receipts=receipts,
            changed_streams=list(changes),unchanged_streams={k:sha256(v)for k,v in before.items() if k not in changes},
            prediction={k:v for k,v in prediction.items() if k!='output'},alternatives=alternatives,hypothesis=plan['hypothesis'],
            provenance='SCPI public-corpus project, controlled replacement of original ladder bodies and local labels; not real ST lineage.'))
        ready.append((plan,d,path,prediction))
    rows=[];requests=[];keys=[]
    for plan,d,path,prediction in ready:
        native,result,process=observe(path,d,trace)
        code_path=native/'pcode-0-0.bin'
        if not code_path.exists():
            failure=dict(case=plan['case'],native_directory=str(native),handling='observation-incomplete',
                check=result['check'],backend_rejected=result['backend_check_rejected'],process=process,
                diagnostic_codes=sorted({hex(e['code']) for e in result['diagnostics']}),
                reason='No generated PCode observation. This is not evidence of frontend rejection or successful empty output.')
            rows.append(failure);save(out/'comparison.json',rows);save(d/'observation-failure.json',failure)
            raise RuntimeError(f"{plan['case']}: native observation incomplete; saved failure before stopping batch")
        code=code_path.read_bytes()
        row=dict(case=plan['case'],native_directory=str(native),check=result['check'],backend_rejected=result['backend_check_rejected'],
            diagnostics=result['diagnostics'],backend_diagnostics=result['backend_check_diagnostics'],process=process,predicted_equal=None if prediction['output'] is None else code==prediction['output'])
        if code:requests.append(dict(mode='decode',input_base64=base64.b64encode(code+b'\0').decode()));keys.append(plan['case'])
        if result['exported_sha256']:
            rd=d/'reopen';rd.mkdir();rn,rr,rp=observe(native/'native-saved.gxw',rd,trace)
            row['reopen']=dict(native_directory=str(rn),check=rr['check'],diagnostics=rr['diagnostics'],identical=code==(rn/'pcode-0-0.bin').read_bytes())
        rows.append(row);save(out/'comparison.json',rows)
        print(json.dumps(dict(case=row['case'],check=row['check'],equal=row['predicted_equal'],diagnostics=sorted(set(hex(e['code']) for e in row['diagnostics'] if e['kind']==2)),reopen=row.get('reopen',{}).get('identical'))),flush=True)
    answers=native_batch(requests,out/'native-decode',dll=Q_DLL,cpu_code=209,native_versions=(25,))
    listings=[]
    for case,req,answer in zip(keys,requests,answers,strict=True):
        assert answer['return_code']=='0x00000000' and answer['consumed_bytes']==len(base64.b64decode(req['input_base64']))-1
        listings.append(dict(case=case,records=native_il_records(base64.b64decode(answer['output_base64']),encoding='cp932')))
    save(out/'native-listings.json',listings);save(out/'current-check-export-correspondence.json',verify([out.name]))


if __name__=='__main__':main()
