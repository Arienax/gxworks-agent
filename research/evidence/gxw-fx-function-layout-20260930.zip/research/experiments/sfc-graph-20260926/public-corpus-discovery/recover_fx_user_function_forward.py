"""Finish saved group after its mismatch renderer failed on predicted OR.

No original input compilation is repeated. Only the as-yet-unperformed reopen
of the fourth saved project is run; then all saved native outputs are decoded.
Original before-native bytes remain untouched.
"""
from pathlib import Path
import base64,json,sys
ROOT=Path(__file__).resolve().parents[4];P=Path(__file__).resolve().parent
sys.path[:0]=[str(P),str(ROOT/'src'),str(ROOT/'research')]
from probe_minimal_conditional_port_writes import save,observe
from probe_gxw_program_check_resources import inspect_run
from native_gxw_tokens import native_batch,native_il_records
from inspect_st_branch_ir import decode
from inspect_st_library_call_abi import canonical


def main():
    out=P/'fx3g-user-functions-forward-v2-20260930';rows=json.loads((out/'comparison.json').read_text())
    assert len(rows)==3
    directory=out/'Mixed-return-or';native=directory/'native-1';result=inspect_run(native)
    actual=(native/'pcode-0-0.bin').read_bytes();expected=(directory/'prediction-before-native.bin').read_bytes()
    save(directory/'runner-failure.json',dict(phase='rendering-prospective-mismatch',native_compile_and_check_finished=True,
         message='Predicted OR header is outside the independent decoder; the runner exited before persisting case 4 comparison and reopen.',
         recovery='Read original native observation, preserve failed full prediction, run its saved-project reopen once. Original input is not recompiled. Original process return dictionary was lost and is not reconstructed.'))
    save(directory/'prospective-mismatch.json',dict(predicted_hex=expected.hex(),actual=decode(actual,'fx3g'),
         predicted_bytes=len(expected),actual_bytes=len(actual),expected_decoder_gap='unknown token 04040304 at 119',
         status='prospective-failure; any later correction is post-observation'))
    reopened=directory/'reopen';reopened.mkdir(exist_ok=False)
    rn,rr,rp=observe(native/'native-saved.gxw',reopened,out/'trace.js')
    row=dict(case='Mixed-return-or',native_directory=str(native),check=result['check'],process=None,
             process_limitation='Original process return dictionary was lost when mismatch rendering failed; saved events and observer errors inspected.',
             generated_bytes=len(actual),prospective_equal=False,
             diagnostics=[{k:v for k,v in r.items() if k!='raw_base64'} for r in result['diagnostics'] if r['kind']==2],
             reopen=dict(native_directory=str(rn),check=rr['check'],bytes_identical=actual==(rn/'pcode-0-0.bin').read_bytes(),process=rp))
    rows.append(row);save(out/'comparison.json',rows)
    requests=[dict(mode='decode',input_base64=base64.b64encode((Path(r['native_directory'])/'pcode-0-0.bin').read_bytes()+b'\0').decode()) for r in rows]
    answers=native_batch(requests,out/'native-decode',cpu_code=521)
    for row,answer in zip(rows,answers,strict=True):
        raw=(Path(row['native_directory'])/'pcode-0-0.bin').read_bytes()
        assert answer['return_code']=='0x00000000' and answer['consumed_bytes']==len(raw)
        observed=native_il_records(base64.b64decode(answer['output_base64']),encoding='cp1252');independent=decode(raw,'fx3g')
        assert canonical(observed)==canonical(independent)
        row['independent_address_projection_match']=True
        save(out/row['case']/'independent-listing.json',independent)
    save(out/'comparison.json',rows);(out/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    print(json.dumps(dict(cases=len(rows),prospective_matches=sum(r['prospective_equal'] for r in rows),
                         accepted=sum(bool(r['check']) and not r['check']['rejected'] for r in rows))),flush=True)


if __name__=='__main__':main()
