"""Inspect saved IF-tree observations; finite witnesses, no compiler rerun.

Raw 73-byte node cells and opaque fields remain in the original event files.
This identifies only the measured IF/ELSE and branch-pair child relationships.
"""
from pathlib import Path
import base64,json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.token_pou import LadderToken,TokenProgram
from gxw.token_listing import decode_token_program,TokenInstruction,TokenLabel
from gxw.project_metadata import read_project_text_context
from probe_minimal_conditional_port_writes import streams,save
from source_q_direct_declarations import DirectDeclarations
from source_q_st_calls import predict
from native_gxw_tokens import native_batch,native_il_records
from witness_st_conditional_transfers import evaluate
P=Path(__file__).resolve().parent


def decode(raw,profile):
    tokens=[];at=0
    while at<len(raw):
        size=raw[at];part=raw[at:at+size]
        if size<2 or len(part)!=size or part[-1]!=size:raise ValueError('framing')
        tokens.append(LadderToken(at,part));at+=size
    listing=decode_token_program(TokenProgram(raw,tuple(tokens),0,len(raw)),profile=profile,text_encoding='cp932')
    rows=[]
    for r in listing.records:
        row=dict(offset=r.tokens[0].offset,raw=''.join(t.raw.hex() for t in r.tokens))
        if isinstance(r,TokenInstruction):row.update(kind='instruction',op=r.mnemonic,args=list(r.args))
        elif isinstance(r,TokenLabel):row.update(kind='label',text=r.text)
        else:raise ValueError('independent decoder gap '+str(r))
        rows.append(row)
    return rows


def main():
    q_expected={'Else-nested':'FX','Non-tail':'FXY','Tail-no-else':'T','Loop':'TX'}
    fx_expected={'Else-nested':'TX','Non-tail':'TXY','Tail-no-else':'TX','Loop':'TX'}
    groups=sys.argv[1:] or ['q-st-branch-tree-forward-20260930','fx-st-branch-tree-forward-20260930']
    for group in groups:
        fx=group.startswith('fx-')
        out=P/group;comparison=json.loads((out/'comparison.json').read_text());plan=json.loads((out/'experiment-plan.json').read_text())
        expected=plan.get('expected_results',fx_expected if fx else q_expected)
        if fx and not (out/'native-listings.json').exists():
            accepted=[r for r in comparison if (Path(r['native_directory'])/'pcode-0-0.bin').stat().st_size]
            requests=[dict(mode='decode',input_base64=base64.b64encode((Path(r['native_directory'])/'pcode-0-0.bin').read_bytes()+b'\0').decode()) for r in accepted]
            answers=native_batch(requests,out/'independent-native-decode',cpu_code=520)
            native={}
            for row,request,answer in zip(accepted,requests,answers,strict=True):
                assert answer['return_code']=='0x00000000' and answer['consumed_bytes']==len(base64.b64decode(request['input_base64']))-1
                native[row['case']]=native_il_records(base64.b64decode(answer['output_base64']),encoding='cp932')
            save(out/'native-listings.json',[dict(case=k,records=v) for k,v in native.items()])
        else:native={r['case']:r['records'] for r in json.loads((out/'native-listings.json').read_text())}
        findings=[]
        for row in comparison:
            name=row['case'];n=Path(row['native_directory']);raw=(n/'pcode-0-0.bin').read_bytes();source=(n/'input.gxw').read_bytes()
            if not raw:
                before=json.loads((out/name/'before-native.json').read_text())
                assert name in plan.get('expected_rejections',[]) and row['check'] is None
                assert before['prediction']['unsupported']=='fixed temporary pool exhausted'
                assert not (out/name/'predicted-0.bin').exists()
                codes=set(row.get('diagnostic_codes',[]))|{hex(d['code']) for d in row.get('diagnostics',[]) if d['kind']==2}
                assert '0x50f1218' in codes
                result=dict(case=name,handling='frontend-rejected-temporary-capacity',before_native_status=before['prediction']['unsupported'],diagnostic_codes=sorted(codes))
                findings.append(result);print(json.dumps(dict(group=group,**result)),flush=True);continue
            records=decode(raw,'fx3u' if fx else 'q03udv')
            lexical=[{k:v for k,v in r.items() if k not in ('offset','raw')} for r in records]
            assert lexical==native[name],(name,'independent/native lexical mismatch')
            opts=plan['prediction_options'];defs=('Keypad',) if fx else ('SCPI',);owner='POU_01' if fx else 'MAIN'
            if fx:prediction=predict(source,defs,owner=owner,**opts)
            else:prediction=predict(source,defs,owner=owner,allow_inputs=True,allow_omitted=True,allow_members=True,**opts)
            before_raw=(out/name/'predicted-0.bin').read_bytes()
            before_match=before_raw==raw;current_match=prediction['output']==raw
            if not before_match:
                save(out/name/'model-byte-mismatch.json',dict(
                    handling='native-accepted-prospective-prediction-differs',
                    before_native_bytes=len(before_raw),native_bytes=len(raw),
                    first_byte_difference=next((i for i,(a,b) in enumerate(zip(before_raw,raw)) if a!=b),min(len(before_raw),len(raw))),
                    before_native_listing=decode(before_raw,'fx3u' if fx else 'q03udv'),native_listing=records,
                    preservation='Original predicted-0.bin and runner source snapshot are retained unchanged.'))
            content={k:v for k,v in streams(source).items() if k!='CGTable.dat'}
            context=read_project_text_context(next(v for k,v in content.items() if k.endswith('.prj')))
            declarations=DirectDeclarations(content,context['text_encoding'],local_fb_definitions=defs,allow_string_arrays=True);declarations.add_owner(owner)
            selections={'result':(owner,'number_buffer' if fx else 'prober1'),'key_iterator':('POU_01.keypad_a' if fx else 'MAIN.First','key_iterator')}
            if not fx:selections['copied']=(owner,'prober2')
            bindings={}
            for key,(scope,var) in selections.items():
                item=declarations.bound[scope][var];bindings[key]=dict(address=item['family']+str(item['number']),type=item['row'].data_type)
            witness=evaluate(records,bindings,allow_boolean=True,profile='fx3u' if fx else 'q03udv')
            observed=dict(result=expected[name],key_iterator=2 if name=='Loop' else 0)
            if not fx:observed['copied']=expected[name]
            assert witness['observations']==observed,(group,name,witness['observations'],observed)
            events=[json.loads(line).get('payload',{}) for line in (n/'events.jsonl').read_text().splitlines()]
            errors=[r for r in events if r.get('event') in ('block-walk-guard-error','block-walk-observation-error')]
            assert not errors,(name,errors)
            graphs=[r for r in events if r.get('event')=='block-walk' and r.get('phase')=='enter' and r.get('name')=='wrapper' and any(x['type']==0x17e for x in r.get('graph',[]))]
            assert graphs
            graph=graphs[-1]['graph'];by_id={r['id']:r for r in graph};branches=[]
            for node in graph:
                if node['type']!=0x17e:continue
                pair=by_id[node['link16']];assert pair['type']==0x185
                branches.append(dict(node=node,pair=pair,condition=by_id[node['link12']],else_child=by_id[pair['link12']] if pair['link12'] else None,then_child=by_id[pair['link16']] if pair['link16'] else None))
            if plan['prediction_options'].get('allow_elsif_chains'):
                from source_q_st_calls import source_statements
                from source_st_branch_trees import parse_if
                text=plan['cases'][name] if fx else next(c['body'] for c in plan['cases'] if c['case']==name)
                statements=source_statements(text);position=next(i for i,s in enumerate(statements) if s.strip().upper().startswith('IF '))
                tree,_=parse_if(statements,position,allow_cases=True,allow_elsif=True)
                def count_if(node):
                    if node['kind']=='statement':return 0
                    children=node['then']+(node['otherwise'] or []) if node['kind']=='if' else [c for a in node['arms'] for c in a['body']]+(node['otherwise'] or [])
                    return (node['kind']=='if')+sum(count_if(c) for c in children)
                assert count_if(tree)==len(branches),(name,'normalized source/native IF count mismatch')
                save(out/name/'source-control-tree.json',tree)
            save(out/name/'finite-branch-witness.json',dict(bindings=bindings,expected=observed,**witness))
            save(out/name/'branch-node-ir.json',dict(scope='Measured 17e -> condition/185 pair; 185 -> ELSE/THEN. Other fields retained opaque, not interpreted.',graphs=graphs,branches=branches))
            assert not row['check']['rejected'] and not row['reopen']['check']['rejected'] and row['reopen'].get('bytes_identical',row['reopen'].get('identical'))
            result=dict(case=name,before_native_byte_match=before_match,current_model_byte_match=current_match,independent_lexical_match=True,compile_check_reopen=True,labels=[r['text'] for r in records if r['kind']=='label'],witness=witness['observations'],if_else_nodes=len(branches),graph_cell_inventory_truncated=any(g['graph_truncated'] for g in graphs),observer_errors=errors)
            findings.append(result);print(json.dumps(dict(group=group,**result)),flush=True)
        save(out/'branch-tree-findings.json',dict(scope='Prospective bounded scalar INT/WORD IF/ELSIF trees, finite initialized ASCII/word witnesses; rejected capacities retained. No PLC execution or general ST semantics claim.',cases=findings))
        (out/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
        (out/'witness_st_conditional_transfers.py').write_bytes((P/'witness_st_conditional_transfers.py').read_bytes())


if __name__=='__main__':main()
