"""Saved REPEAT/EXIT/RETURN node observations and bounded offline witnesses.

Generation, fresh check rejection and accepted reopen are separate outcomes.
Native decoding is compared with the repository decoder; no native build rerun.
Unknown node fields remain raw, with no writer or general ST runtime claim.
"""
from pathlib import Path
import base64,json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.project_metadata import read_project_text_context
from probe_minimal_conditional_port_writes import streams,save
from source_q_direct_declarations import DirectDeclarations
from native_gxw_tokens import native_batch,native_il_records
from inspect_st_branch_ir import decode
from witness_st_conditional_transfers import evaluate
P=Path(__file__).resolve().parent
EXPECTED={'Repeat':('XX',2),'While-exit':('X',1),'Nested-exit':('XXXX',2),'Return':('TX',0),'Last':('TX',0),'Guard':('TX',0),'Main':('Z',0),'Repeat-once':('X',3),'Repeat-exit':('X',1),'For-direct':('X',0),'Nested':('XXXXXX',3)}


def main():
    for group in sys.argv[1:]:
        out=P/group;fx=group.startswith('fx-');rows=json.loads((out/'comparison.json').read_text())
        if not (out/'native-listings.json').exists():
            assert fx
            requests=[dict(mode='decode',input_base64=base64.b64encode((Path(r['native_directory'])/'pcode-0-0.bin').read_bytes()+b'\0').decode()) for r in rows]
            answers=native_batch(requests,out/'independent-native-decode',cpu_code=520)
            native={}
            for row,request,answer in zip(rows,requests,answers,strict=True):
                assert answer['return_code']=='0x00000000' and answer['consumed_bytes']==len(base64.b64decode(request['input_base64']))-1
                native[row['case']]=native_il_records(base64.b64decode(answer['output_base64']),encoding='cp932')
            save(out/'native-listings.json',[dict(case=k,records=v) for k,v in native.items()])
        else:native={r['case']:r['records'] for r in json.loads((out/'native-listings.json').read_text())}
        findings=[]
        for row in rows:
            name=row['case'];n=Path(row['native_directory']);raw=(n/'pcode-0-0.bin').read_bytes();source=(n/'input.gxw').read_bytes()
            records=decode(raw,'fx3u' if fx else 'q03udv')
            assert [{k:v for k,v in r.items() if k not in ('offset','raw')} for r in records]==native[name]
            events=[json.loads(line).get('payload',{}) for line in (n/'events.jsonl').read_text().splitlines()]
            errors=[e for e in events if e.get('event') in ('block-walk-guard-error','block-walk-observation-error')];assert not errors
            graphs=[e for e in events if e.get('event')=='block-walk' and e.get('phase')=='enter' and e['name']=='wrapper' and any(x['type'] in (0x183,0x188,0x17c,0x14a) for x in e.get('graph',[]))]
            assert graphs and not any(g['graph_truncated'] for g in graphs)
            for g in graphs:
                for node in g['graph']:assert len(bytes.fromhex(node['raw']))==73
            nodes={};controls=[]
            for g in graphs:
                for node in g['graph']:
                    if node['type'] in (0x183,0x188,0x17c,0x14a):nodes[(node['id'],node['type'])]=node
            for e in events:
                if e.get('event')=='block-walk' and e.get('phase')=='enter' and (e['name'].startswith('control-') or e['name']=='walker' and e['node'].get('type') in (0x17c,0x14a)):
                    controls.append(e)
            graph_result=dict(scope='Measured native graph tags: 183 REPEAT, 188 WHILE, 17c EXIT, 14a RETURN; link/field meanings outside measured child relationships remain opaque.',graphs=graphs,control_nodes=list(nodes.values()),entry_observations=controls)
            save(out/name/'loop-exit-node-ir.json',graph_result)
            rejected=row['check']['rejected'];result=dict(case=name,generated_bytes=len(raw),fresh_check_rejected=rejected,independent_lexical_match=True,labels=[r['text'] for r in records if r['kind']=='label'],node_tags=sorted({hex(node['type']) for node in nodes.values()}))
            predicted=out/name/'predicted-0.bin'
            if predicted.exists():
                assert predicted.read_bytes()==raw,(group,name,'before prediction mismatch');result['before_native_byte_match']=True
            fitted=out/name/'loop-exit-source-fit.bin'
            if fitted.exists():
                assert fitted.read_bytes()==raw;result['post_observation_fit_byte_match']=True
            if rejected:
                result.update(handling='native-generated-but-fresh-check-rejected',reopen_validated=False,witness='Not interpreted as accepted native code.')
            else:
                assert not row['reopen']['check']['rejected'] and row['reopen'].get('bytes_identical',row['reopen'].get('identical'))
                content={k:v for k,v in streams(source).items() if k!='CGTable.dat'}
                context=read_project_text_context(next(v for k,v in content.items() if k.endswith('.prj')))
                owner='POU_01' if fx else 'MAIN';child='POU_01.keypad_a' if fx else 'MAIN.First'
                declarations=DirectDeclarations(content,context['text_encoding'],local_fb_definitions=('Keypad',) if fx else ('SCPI',),allow_string_arrays=True);declarations.add_owner(owner)
                selected={'result':(owner,'number_buffer' if fx else 'prober1'),'key_iterator':(child,'key_iterator')}
                if not fx and name not in ('Last','Main'):selected['copied']=(owner,'prober2')
                if name in ('Nested-exit','Nested'):selected['for_iterator']=(child,'for_iterator')
                bindings={}
                for key,(scope,var) in selected.items():
                    item=declarations.bound[scope][var];bindings[key]=dict(address=item['family']+str(item['number']),type=item['row'].data_type)
                witness=evaluate(records,bindings,allow_boolean=True,profile='fx3u' if fx else 'q03udv')
                string,counter=EXPECTED[name];expected=dict(result=string,key_iterator=counter)
                if 'copied' in bindings:expected['copied']=string
                if 'for_iterator' in bindings:expected['for_iterator']=1
                assert witness['observations']==expected,(group,name,witness['observations'],expected)
                save(out/name/'finite-loop-exit-witness.json',dict(bindings=bindings,expected=expected,**witness))
                result.update(handling='native-check-and-reopen-accepted',reopen_validated=True,witness=witness['observations'])
            findings.append(result);print(json.dumps(dict(group=group,**result)),flush=True)
        save(out/'loop-exit-findings.json',dict(scope='Source correlation and saved native outputs, independent lexical cross-check, finite initialized ASCII/INT witnesses. Not PLC execution or complete declaration/runtime safety.',cases=findings))
        (out/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
        (out/'inspect_st_branch_ir.py').write_bytes((P/'inspect_st_branch_ir.py').read_bytes())
        (out/'witness_st_conditional_transfers.py').write_bytes((P/'witness_st_conditional_transfers.py').read_bytes())


if __name__=='__main__':main()
