"""Finite initialized INT/ASCII-string witnesses; no PLC or generic ST simulator.

Core lexical decoding is cross-checked with saved native decoding. Source-only
declarations locate the two final observations. Word memory, NUL termination,
branch decisions and effective indexed targets are explicit; unknown operations
and uninitialized reads fail closed. D/W/R/ZR are separate word-memory families;
W text uses hexadecimal addresses. No bank switching or device bounds modeled.
This does not certify runtime semantics.
"""
from pathlib import Path
import json,re,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from gxw.token_pou import LadderToken
from gxw.token_q import q_instruction_header,q_operand_groups,q_operand_text
from gxw.project_metadata import read_project_text_context
from probe_minimal_conditional_port_writes import streams,save
from source_q_direct_declarations import DirectDeclarations
from source_q_st_calls import predict
from verify_temporary_check_correspondence import verify
P=Path(__file__).resolve().parent
GROUPS=['st-fb-conditional-int-20260930','st-fb-conditional-string-20260930','st-fb-conditional-holdouts-20260930']


def decode(raw):
    groups=[];at=0
    while at<len(raw):
        n=raw[at];part=raw[at:at+n]
        if n<2 or len(part)!=n or part[-1]!=n:raise ValueError('framing')
        if part[1]<0x80:groups.append([])
        if not groups:raise ValueError('operand before instruction')
        groups[-1].append(LadderToken(at,part));at+=n
    records=[]
    for ts in groups:
        row=dict(offset=ts[0].offset,raw=''.join(t.raw.hex() for t in ts))
        if ts[0].raw[1]==0x3c:
            if len(ts)!=2 or ts[1].raw[1]!=0xd0:raise ValueError('only P labels')
            row.update(kind='label',text=q_operand_text(ts[1].raw,text_encoding='cp932'))
        else:
            op,arity=q_instruction_header(ts[0].raw)
            args=q_operand_groups(tuple(ts[1:]),text_encoding='cp932')
            if len(args)!=arity:raise ValueError('arity')
            row.update(kind='instruction',op=op,args=[text for _,text in args])
        records.append(row)
    return records


def evaluate(records,observations,*,allow_boolean=False,profile='q03udv'):
    if profile not in ('q03udv','fx3u'):raise ValueError('unmeasured finite witness CPU profile')
    fx=profile=='fx3u'
    memory={};bit_memory={};steps=[];branches=[];labels={r['text']:i for i,r in enumerate(records) if r['kind']=='label'}
    pc=0;condition=None;budget=1000;logic_stack=[]
    def load_condition(value):
        nonlocal condition
        if condition is not None:
            logic_stack.append(condition)
            del logic_stack[:-8]
        condition=value
    def signed(n,bits):
        n&=(1<<bits)-1
        return n-(1<<bits) if n&(1<<(bits-1)) else n
    def address(text):
        m=re.fullmatch(r'(ZR|D|Z|W|R|M|B)([0-9A-F]+)(?:(ZZ|Z)([0-9]+))?',text)
        if not m:raise ValueError('unsupported address '+text)
        family,number,index_kind,index=m.groups();number=int(number,16 if family in ('W','B') else 10)
        if index is not None:
            key=('Z',int(index))
            if key not in memory:raise ValueError('uninitialized index')
            if index_kind=='ZZ':
                high=('Z',int(index)+1)
                if high not in memory:raise ValueError('uninitialized double index')
                number+=signed(memory[key]|(memory[high]<<16),32)
            else:number+=signed(memory[key],16)
        if number<0:raise ValueError('negative address')
        return family,number
    def read(text,bits=16):
        if re.fullmatch(r'K-?[0-9]+',text):return int(text[1:])
        if re.fullmatch(r'H[0-9A-F]+',text):return int(text[1:],16)
        family,number=address(text);value=0
        for i in range(bits//16):
            if (family,number+i) not in memory:raise ValueError('uninitialized word '+text)
            value|=memory[(family,number+i)]<<(16*i)
        return signed(value,bits)
    def write(text,value,bits=16):
        family,number=address(text)
        for i in range(bits//16):memory[(family,number+i)]=(value>>(16*i))&0xffff
        return family+(format(number,'X') if family=='W' else str(number))
    def read_string(text):
        if re.fullmatch(r'"[ -!#-~]*"',text):return text[1:-1]
        family,number=address(text);raw=bytearray()
        for i in range(32):
            if (family,number+i) not in memory:raise ValueError('uninitialized string word '+text)
            for b in memory[(family,number+i)].to_bytes(2,'little'):
                if b==0:return raw.decode('ascii')
                raw.append(b)
        raise ValueError('string exceeds finite witness bound')
    def read_bit(text):
        if not fx and text in ('SM400','SM401'):return text=='SM400'
        if fx and text in ('M8000','M8001'):return text=='M8000'
        key=address(text)
        if key[0] not in ('M','B'):raise ValueError('outside M/B bit witness '+text)
        if key not in bit_memory:raise ValueError('uninitialized bit '+text)
        return bit_memory[key]
    while pc<len(records):
        budget-=1
        if budget<=0:raise ValueError('witness instruction limit')
        r=records[pc];pc+=1
        if r['kind']=='label':continue
        op,args=r['op'],r['args']
        if op in ('FEND','END') and not args:break
        if op=='NOP' and not args:continue
        if op=='LD' and args==(['M8000'] if fx else ['SM400']):
            if allow_boolean:load_condition(True)
            else:condition=True
            continue
        if allow_boolean:
            if op in ('LD','LDI') and len(args)==1:
                load_condition(read_bit(args[0]) if op=='LD' else not read_bit(args[0]));continue
            if op in ('OR','AND','ORI','ANI') and len(args)==1:
                if condition is None:raise ValueError('undefined Boolean condition')
                rhs=read_bit(args[0])
                if op in ('ORI','ANI'):rhs=not rhs
                condition=condition or rhs if op in ('OR','ORI') else condition and rhs;continue
            relation=re.fullmatch(r'(LD|AND|OR)(<>|<=|>=|=|<|>)',op)
            if relation and len(args)==2:
                left,right=read(args[0]),read(args[1]);predicate=relation[2]
                rhs={'=':left==right,'<>':left!=right,'>':left>right,'>=':left>=right,'<':left<right,'<=':left<=right}[predicate]
                if relation[1]=='LD':load_condition(rhs)
                elif condition is None:raise ValueError('undefined Boolean condition')
                else:condition=condition or rhs if relation[1]=='OR' else condition and rhs
                continue
            if op=='INV' and not args:
                if condition is None:raise ValueError('undefined inverted Boolean condition')
                condition=not condition;continue
            if op in ('ORB','ANB') and not args:
                if condition is None or not logic_stack:raise ValueError('undefined Boolean block')
                lhs=logic_stack.pop();condition=lhs or condition if op=='ORB' else lhs and condition;continue
            if op=='OUT' and len(args)==1:
                key=address(args[0])
                if condition is None or key[0] not in ('M','B'):raise ValueError('outside M/B BOOL OUT witness')
                effective=key[0]+(format(key[1],'X') if key[0]=='B' else str(key[1]))
                bit_memory[key]=condition;steps.append(dict(offset=r['offset'],op=op,args=args,effective_destination=effective,value=condition));continue
            if condition is False and op in ('MOV','DMOV'):
                steps.append(dict(offset=r['offset'],op=op,args=args,skipped=True));continue
        if op=='LD<=' and len(args)==2:
            value=read(args[0])<=read(args[1])
            if allow_boolean:load_condition(value)
            else:condition=value
            continue
        if not fx and op=='JMP' and len(args)==1:
            branches.append(dict(offset=r['offset'],target=args[0],taken=True,unconditional=True))
            pc=labels[args[0]];continue
        if op=='CJ' and len(args)==1:
            if condition is None:raise ValueError('undefined branch condition')
            branches.append(dict(offset=r['offset'],target=args[0],taken=condition))
            if condition:pc=labels[args[0]]
            continue
        if condition is not True:raise ValueError('unobserved conditional data instruction')
        if fx and op=='RST' and len(args)==1:
            if address(args[0])[0]!='D':raise ValueError('FX RST witness restricted to observed word STRING clear')
            effective=write(args[0],0)
            steps.append(dict(offset=r['offset'],op=op,args=args,effective_destination=effective,value=0));continue
        bits=32 if op.startswith('D') else 16
        if op=='$MOV' and len(args)==2 or op=='$+' and len(args)==(3 if fx else 2):
            # Bounded offline string-operation model. PCode has no declaration
            # capacity operand; preserve every modeled write, including writes
            # outside an independently supplied source declaration allocation.
            val=read_string(args[0]) if op=='$MOV' else read_string(args[0])+read_string(args[1]) if fx else read_string(args[1])+read_string(args[0])
            raw=val.encode('ascii')+b'\0'
            if len(raw)%2:raw+=b'\0'
            family,number=address(args[-1]);effective=family+(format(number,'X') if family=='W' else str(number))
            for i in range(0,len(raw),2):memory[(family,number+i//2)]=int.from_bytes(raw[i:i+2],'little')
        else:
            if op in ('MOV','DMOV') and len(args)==2:val=read(args[0],bits)
            elif (op in ('+','-','D+','D-') and len(args) in (2,3)) or (fx and op=='ADD' and len(args)==3):
                lhs,rhs=(read(args[0],bits),read(args[1],bits)) if len(args)==3 else (read(args[1],bits),read(args[0],bits))
                val=lhs+rhs if op in ('+','D+','ADD') else lhs-rhs
                if not -(1<<(bits-1))<=val<(1<<(bits-1)):raise ValueError('outside no-overflow witness')
            elif op=='*' and len(args)==3:val=read(args[0])*read(args[1]);bits=32
            else:raise ValueError('unsupported operation '+str(r))
            effective=write(args[-1],val,bits)
        steps.append(dict(offset=r['offset'],op=op,args=args,effective_destination=effective,value=val))
    result={key:(read_string(v['address']) if v['type'].startswith('STRING') else read_bit(v['address']) if allow_boolean and v['type']=='BOOL' else read(v['address'])) for key,v in observations.items()}
    result=dict(observations=result,branches=branches,steps=steps)
    if fx:result['execution_context']='Finite RUN-enabled FX witness: M8000=true, M8001=false; not PLC execution.'
    if allow_boolean:result['final_condition']=condition
    return result


def main():
    rows=[]
    for group in GROUPS:
        plan=json.loads((P/group/'experiment-plan.json').read_text())
        listings={r['case']:r for r in json.loads((P/group/'native-listings.json').read_text())}
        for case in json.loads((P/group/'comparison.json').read_text()):
            n=Path(case['native_directory']);source=(n/'input.gxw').read_bytes();raw=(n/'pcode-0-0.bin').read_bytes()
            records=decode(raw)
            lexical=[{k:v for k,v in r.items() if k not in ('offset','raw')} for r in records]
            assert listings[case['case']]['return_code']=='0x00000000' and lexical==listings[case['case']]['records']
            assert predict(source)['output']==raw
            content={k:v for k,v in streams(source).items() if k!='CGTable.dat'}
            context=read_project_text_context(next(v for k,v in content.items() if k.endswith('.prj')))
            d=DirectDeclarations(content,context['text_encoding'],local_fb_definitions=('Wrapper',),allow_string_arrays=True);d.add_owner('POU_01')
            observations={}
            for key,var in [('first','prober1'),('second','prober2')]:
                item=d.bound['POU_01'][var]
                observations[key]=dict(address=item['family']+str(item['number']),type=item['row'].data_type)
            result=evaluate(records,observations);expected=dict(plan['expected_alias_results'])
            if case['case']=='output-body-index':expected['second']=expected['output-body-index-second']
            expected={k:expected[k] for k in observations}
            assert result['observations']==expected,(case['case'],result['observations'],expected)
            rows.append(dict(group=group,case=case['case'],input_sha256=sha256(source),pcode_sha256=sha256(raw),
                native_core_decode_equal=True,source_model_bytes_equal=True,bindings=observations,expected=expected,**result))
            print(json.dumps(dict(group=group,case=case['case'],result=result['observations'])))
    out=P/GROUPS[-1]
    save(out/'offline-conditional-witnesses.json',dict(scope='Finite initialized ASCII strings and INTs; explicit little-endian word memory and branches. Offline witness, not PLC execution or general source-semantics equivalence.',cases=rows))
    save(out/'current-check-export-correspondence.json',verify(GROUPS))
    (out/Path(__file__).name).write_bytes(Path(__file__).read_bytes())


if __name__=='__main__':main()
