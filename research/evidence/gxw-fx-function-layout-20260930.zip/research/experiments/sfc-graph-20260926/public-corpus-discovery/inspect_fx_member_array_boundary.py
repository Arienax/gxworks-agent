"""Keep native member-array acceptance separate from bad CALL-pool controls.

Original failures and before-native model refusals stay unchanged. Read saved
events only: no compiler reruns, source-model promotion or hash verification.
"""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[4];P=Path(__file__).resolve().parent
sys.path[:0]=[str(P),str(ROOT/'src'),str(ROOT/'research')]
from probe_minimal_conditional_port_writes import save

GROUPS=['fx3g-structure-member-arrays-discovery-20260930',
        'fx3g-structure-member-array-declaration-20260930',
        'fx3g-structure-member-array-default-controls-20260930',
        'fx3g-structure-member-array-pointer-controls-20260930',
        'fx3g-function-pointer-boundary-20260930']


def main():
    rows=[]
    for group in GROUPS:
        out=P/group
        for row in json.loads((out/'comparison.json').read_text()):
            name=row['case'];native=Path(row['native_directory']);payloads=[];errors=[]
            for line in (native/'events.jsonl').read_text().splitlines():
                event=json.loads(line);payload=event.get('payload',{});payloads.append(payload)
                if event.get('type')=='error' or payload.get('observation_error') or 'error' in payload.get('event',''):errors.append(event)
            assert not errors
            pools=[e for e in payloads if e.get('event')=='pool-allocation' and e.get('caller',{}).get('rva') in ('0x544c0','0x54535')]
            save(out/name/'member-array-boundary-native-ir.json',dict(structure_pools=pools,
                 typed_allocations=[e for e in payloads if e.get('event')=='typed-allocation'],
                 compiler_returns=[e for e in payloads if e.get('event')=='sink-compile-result'],
                 raw_wrappers=[e for e in payloads if e.get('event')=='block-walk' and e.get('name')=='wrapper' and e.get('phase')=='enter'],
                 sink_records=[e for e in payloads if e.get('event')=='sink-record'],
                 handling='Raw-preserved layout discovery and pointer controls. Native acceptance is separate from source model support.'))
            accepted=bool(row['check']) and not row['check']['rejected']
            if accepted:
                assert not row['reopen']['check']['rejected'] and row['reopen']['bytes_identical'] and row['independent_address_projection_match']
                status='native-check-and-reopen-accepted'
            else:
                assert any(d['code']==0x500c9004 for d in row['diagnostics'])
                status='native-call-target-refusal'
            rows.append(dict(group=group,case=name,status=status,generated_bytes=row['generated_bytes'],
                 original_prospective_equal=row['prospective_equal'],original_source_model_refusal=row.get('expected_error'),
                 diagnostics=row['diagnostics'],observed_structure_pool_counts=[dict(kind=e['kind'],count=e['count'],raw_after=e['after']) for e in pools]))
    boundary={r['case']:r for r in rows if r['group']=='fx3g-function-pointer-boundary-20260930'}
    assert boundary['P2047']['status']=='native-check-and-reopen-accepted' and boundary['P2048']['status']=='native-call-target-refusal'
    flat=next(r for r in rows if r['case']=='Flat-function-P2100');assert flat['status']=='native-call-target-refusal'
    corrected=[r for r in rows if r['group']=='fx3g-structure-member-array-pointer-controls-20260930' and r['case']!='Flat-function-P2100']
    assert len(corrected)==3 and all(r['status']=='native-check-and-reopen-accepted' for r in corrected)
    summary=dict(scope='FX3G 15.50 outlined CALL pointer boundary and primitive member-array discovery.',
         observations=len(rows),accepted=sum(r['status']=='native-check-and-reopen-accepted' for r in rows),
         call_target_refusals=sum(r['status']=='native-call-target-refusal' for r in rows),
         findings=['CALL P2047 compiles/checks/reopens; adjacent P2048 and independent flat-function P2100 refuse with 0x500c9004.',
                   'Prior seven member-array failures used P2100. The same WORD/BOOL array declarations and literal member references accept after changing only the P range to P1800..1815.',
                   'Native structure word counts grow 36 to 42 for a three-WORD member replacing one WORD; bit counts grow 24 to 30 for a three-BOOL member replacing one BOOL.',
                   'The source model continues to refuse primitive array members explicitly. No full byte prediction is claimed for the three corrected array controls.'],
         boundary='One FX3G lineage, offline compiler evidence only; no general branch-label P range or PLC execution claim.',cases=rows)
    save(P/'fx3g-member-array-call-boundary-summary-20260930.json',summary)
    print(json.dumps({k:v for k,v in summary.items() if k!='cases'}),flush=True)


if __name__=='__main__':main()
