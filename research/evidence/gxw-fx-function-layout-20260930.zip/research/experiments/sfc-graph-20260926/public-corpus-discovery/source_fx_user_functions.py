"""Bounded source-only FX3G outlined primitive user-function research model.

Inputs are source .lnl/.lnb declarations/bodies and .prj allocation ranges.
No CGTable, generated code, native encoder or observed addresses are inputs.
Unknown syntax/types fail closed; original source payloads stay in the project.
The profile is deliberately limited to primitive functions, MOV comparisons,
BON/DBON, assignments, nested calls and one two-call Boolean expression.
This models compiled layout, not PLC execution semantics.
"""
import re
from gxw.text_pou import parse_st_pou
from probe_fx3g_library_declarations import source_rows
from probe_gxw_parameters import project_allocation_ranges
from probe_gxw_native_listing import project_text_context
from source_q_label_binding import scalar, integer16

H = {k: bytes.fromhex(v) for k,v in {
    'always':'0300030590401f05', 'LD':'04000304', 'OUT':'04200304',
    'OUTY':'032003', 'MOV':'054c050005', 'DMOV':'054c090105',
    'CALL':'0554030105', 'label':'043c0204', 'FEND':'033303',
    'SRET':'056a010705', 'NOP':'0202', 'END':'033403',
    'BON':'0553071c05', 'DBON':'05530d1d05', 'AND':'040c0304',
    'OR':'04060304', 'LD>':'064005021006', 'LD<':'064005041006',
}.items()}
TYPES={'BOOL':('M',1),'INT':('D',1),'WORD':('D',1),'DWORD':('D',2)}


def statements(text):
    if text is None: raise ValueError('opaque source text')
    text=re.sub(r'\(\*.*?\*\)', '', text, flags=re.S)
    if '(*' in text or '*)' in text: raise ValueError('nested/unterminated source comments')
    if any(c in text for c in "'\"/"): raise ValueError('syntax outside function profile')
    return [v.strip() for v in text.split(';') if v.strip()]


def expression(text):
    text=text.strip()
    depth=0
    for i,c in enumerate(text):
        depth += (c=='(')-(c==')')
        if depth<0: raise ValueError('unbalanced call expression')
        if depth==0:
            m=re.match(r'\s+(AND|OR)\s+',text[i:],re.I)
            if m: return ('bool',m[1].upper(),expression(text[:i]),expression(text[i+m.end():]))
    if depth: raise ValueError('unbalanced call expression')
    m=re.fullmatch(r'([A-Za-z_][\w]*)\((.*)\)',text,re.S)
    if m:
        args=[];start=depth=0
        for i,c in enumerate(m[2]):
            depth += (c in '([')-(c in ')]')
            if c==',' and depth==0:args.append(expression(m[2][start:i]));start=i+1
        args.append(expression(m[2][start:]))
        return ('call',m[1].casefold(),args)
    if re.fullmatch(r'(?:[A-Za-z_]\w*(?:\[[+-]?\d+(?:\s*,\s*[+-]?\d+)*\]\.[A-Za-z_]\w*)?|[+-]?\d+|16#[0-9A-Fa-f]+)',text):return ('atom',text)
    raise ValueError('unmeasured expression: '+text)


def p_operand(number):
    if not 0<=number<=65535:raise ValueError('pointer outside observed width')
    return b'\x05\xd0'+number.to_bytes(2,'little')+b'\x05'


class Model:
    def __init__(self, streams, *, allow_structure_globals=False,allow_multiple_global_documents=False):
        self.streams=streams; self.definitions={};self.frames={};self.queue=[]
        self.allocations=[];self.temp_allocations=[];self.edges={}
        metadata=[n for n in streams if n.endswith('.prj')]
        if len(metadata)!=1:raise ValueError('ambiguous project allocation metadata')
        if project_text_context(streams[metadata[0]])['cpu']!='FX3G':
            raise ValueError('CPU outside measured FX3G function profile')
        ranges={r['name']:r for r in project_allocation_ranges(streams[metadata[0]])['ranges']}
        self.pools={n:[ranges[n]['lower'],ranges[n]['upper']] for n in ('D','M','P')}
        if any(lo>hi for lo,hi in self.pools.values()):raise ValueError('invalid measured pool interval')
        if not (0<=self.pools['D'][0]<=self.pools['D'][1]<8000 and
                3840<=self.pools['M'][0]<=self.pools['M'][1]<8000 and
                1024<=self.pools['P'][0]<=self.pools['P'][1]<=2047):
            raise ValueError('pool addresses outside measured function token profile')
        self.cursor={n:self.pools[n][1] for n in ('D','M')};self.next_p=self.pools['P'][0]
        self.globals=None
        if allow_structure_globals:
            from source_fx_structure_layout import Globals
            self.globals=Globals(streams,self.pools,self.cursor,allow_multiple_documents=allow_multiple_global_documents)
        for name,raw in streams.items():
            if not allow_structure_globals and name.endswith(('.gh','.lng')):
                rows=source_rows(raw,False)['rows']
                if any(r['class_code'] not in (2,9) for r in rows):
                    raise ValueError('unmodeled global storage: '+name)
            if not name.endswith('.lnl'):continue
            doc=source_rows(raw,True)
            if not doc['return_type']:continue  # Unreferenced FBs remain raw.
            owner=doc['owner'];body=owner+'.Program'+name[name.index('\\'):][:-4]+'.lnb'
            key=owner.casefold()
            if key in self.definitions:raise ValueError('ambiguous function source owner')
            self.definitions[key]=dict(doc=doc,body_stream=body,declaration_stream=name)
        if source_rows(streams['MAIN.Labels.lh'],True)['rows']:
            raise ValueError('MAIN locals outside profile')

    def allocate(self,typ,owner,name,category):
        if typ not in TYPES:raise ValueError('unmeasured function primitive type: '+typ)
        family,count=TYPES[typ];number=self.cursor[family]-count+1
        if number<self.pools[family][0]:raise ValueError('allocation capacity exhausted: '+family)
        self.cursor[family]=number-1
        row=dict(owner=owner,name=name,type=typ,category=category,family=family,number=number,count=count)
        self.allocations.append(row)
        return dict(type=typ,operand=scalar(family,number),name=name)

    def register(self,expr):
        if expr[0]=='call':
            for arg in expr[2]:self.register(arg)
            key=expr[1]
            if key in self.frames:return
            if key not in self.definitions:raise ValueError('unresolved source user function: '+key)
            definition=self.definitions[key];doc=definition['doc']
            if doc['return_type'] not in ('BOOL','INT'):
                raise ValueError('unmeasured function return type')
            if len({r['record_id'] for r in doc['rows']})!=len(doc['rows']):
                raise ValueError('duplicate function source record ID')
            if len({r['name'].casefold() for r in doc['rows']}|{key})!=len(doc['rows'])+1:
                raise ValueError('duplicate function source symbol')
            inputs=[];locals_=[]
            for r in sorted(doc['rows'],key=lambda r:r['record_id']):
                if r['mode'] or r['device'] or r['iec_address'] or r['array_marker']:
                    raise ValueError('nonprimitive or explicitly located function label')
                if r['initial_value'] not in ('','0','FALSE'):
                    raise ValueError('nondefault function label initializer outside profile')
                if r['class_code']==3:inputs.append(r)
                elif r['class_code']==1:locals_.append(r)
                else:raise ValueError('unmeasured function declaration class')
            if len(inputs)!=len(expr[2]):raise ValueError('source call arity')
            if self.next_p>self.pools['P'][1]:raise ValueError('pointer capacity exhausted')
            frame=dict(definition=definition,p=self.next_p,inputs=[],symbols={})
            self.next_p+=1
            for r in inputs:
                value=self.allocate(r['data_type'],doc['owner'],r['name'],2)
                frame['inputs'].append(value);frame['symbols'][r['name'].casefold()]=value
            value=self.allocate(doc['return_type'],doc['owner'],doc['owner'],4)
            frame['return']=value;frame['symbols'][key]=value
            for r in locals_:
                frame['symbols'][r['name'].casefold()]=self.allocate(r['data_type'],doc['owner'],r['name'],1)
            self.frames[key]=frame;self.queue.append(key);self.edges[key]=set()
        elif expr[0]=='bool':
            self.register(expr[2]);self.register(expr[3])

    def atom(self,expr,expected,symbols):
        if expr[0]!='atom':raise ValueError('scalar source expected')
        text=expr[1];key=text.casefold()
        if key in symbols:
            value=symbols[key]
            if value['type']!=expected:raise ValueError('implicit type conversion outside profile')
            return value['operand']
        if self.globals is not None:
            value=self.globals.resolve(text)
            if value is not None:
                if value['type']!=expected:raise ValueError('global member implicit conversion outside profile')
                return value['operand']
        if expected=='INT' and re.fullmatch(r'K?[+-]?\d+',text,re.I):
            return integer16(int(re.sub('^K','',text,flags=re.I)))
        if expected in ('WORD','DWORD') and text.upper().startswith('16#'):
            value=int(text[3:],16);limit=16 if expected=='WORD' else 32
            if value>=1<<limit:raise ValueError('hex literal exceeds source formal type')
            width=1 if value<256 else 2 if value<65536 else 4
            return bytes([width+3,0xea if expected=='WORD' else 0xeb])+value.to_bytes(width,'little')+bytes([width+3])
        raise ValueError('unmeasured typed atom: '+text+' as '+expected)

    def call(self,expr,symbols):
        if expr[0]!='call':raise ValueError('function call expected')
        self.register(expr);frame=self.frames[expr[1]]
        if len(frame['inputs'])!=len(expr[2]):raise ValueError('call arity mismatch')
        code=b''
        for arg,formal in zip(expr[2],frame['inputs'],strict=True):
            if arg[0]=='call':
                prefix,value=self.call(arg,symbols);code+=prefix
                if value['type']!=formal['type']:raise ValueError('nested return type mismatch')
                operand=value['operand']
            else:operand=self.atom(arg,formal['type'],symbols)
            if formal['type']=='BOOL':raise ValueError('BOOL input copy unmeasured')
            code+=H['DMOV' if formal['type']=='DWORD' else 'MOV']+operand+formal['operand']
        return code+H['CALL']+p_operand(frame['p']),frame['return']

    def bool_value(self,expr,symbols):
        if expr[0]=='atom' and self.globals is not None:
            return H['LD']+self.atom(expr,'BOOL',symbols)
        if expr[0]=='call':
            code,value=self.call(expr,symbols)
            if value['type']!='BOOL':raise ValueError('BOOL return expected')
            return H['always']+code+H['LD']+value['operand']
        if expr[0]=='bool':
            if expr[2][0]!='call' or expr[3][0]!='call':raise ValueError('bounded two-call Boolean profile')
            left,lv=self.call(expr[2],symbols)
            if lv['type']!='BOOL':raise ValueError('left BOOL call expected')
            n=self.cursor['M']
            count=2 if expr[1]=='OR' else 1
            if n-count+1<self.pools['M'][0]:raise ValueError('temporary capacity exhausted: M')
            temp=scalar('M',n);self.temp_allocations.append(dict(family='M',number=n,count=1))
            right,rv=self.call(expr[3],symbols)
            if rv['type']!='BOOL':raise ValueError('right BOOL call expected')
            if expr[1]=='OR':
                temp2=scalar('M',n-1);self.temp_allocations.append(dict(family='M',number=n-1,count=1))
                return H['always']+left+H['LD']+lv['operand']+H['OUT']+temp+H['always']+right+H['LD']+rv['operand']+H['OUT']+temp2+H['LD']+temp2+H['OR']+temp
            return H['always']+left+H['LD']+lv['operand']+H['OUT']+temp+H['always']+right+H['LD']+temp+H[expr[1]]+rv['operand']
        raise ValueError('unmeasured BOOL source expression')

    def routine(self,key):
        frame=self.frames[key];definition=frame['definition'];symbols=frame['symbols']
        source=parse_st_pou(self.streams[definition['body_stream']]).text
        code=H['label']+p_operand(frame['p'])
        for i,text in enumerate(statements(source)):
            assign=re.fullmatch(r'([A-Za-z_]\w*)\s*:=\s*(.*)',text,re.S)
            if assign:
                if assign[1].casefold() not in symbols:raise ValueError('unresolved function assignment destination')
                dst=symbols[assign[1].casefold()];expr=expression(assign[2]);self.register(expr)
                if expr[0]=='call':
                    def links(node):
                        if node[0]=='call':
                            self.edges[key].add(node[1])
                            for child in node[2]:links(child)
                    links(expr)
                    prefix,value=self.call(expr,symbols)
                    if value['type']!=dst['type']:raise ValueError('return assignment type mismatch')
                    code+=H['always']+prefix+H['MOV']+value['operand']+dst['operand']
                elif dst['type']=='BOOL':
                    code+=H['LD']+self.atom(expr,'BOOL',symbols)+H['OUT']+dst['operand']
                else:
                    if dst['type']!='INT':raise ValueError('unmeasured local scalar assignment width')
                    if i==0:code+=H['always']
                    code+=H['MOV']+self.atom(expr,dst['type'],symbols)+dst['operand']
                continue
            mov=re.fullmatch(r'MOV\(\s*([A-Za-z_]\w*)\s*([<>])\s*([A-Za-z_]\w*)\s*,\s*([A-Za-z_]\w*)\s*,\s*([A-Za-z_]\w*)\s*\)',text,re.I)
            if mov:
                code+=H['LD'+mov[2]]+self.atom(('atom',mov[1]),'INT',symbols)+self.atom(('atom',mov[3]),'INT',symbols)
                code+=H['MOV']+self.atom(('atom',mov[4]),'INT',symbols)+self.atom(('atom',mov[5]),'INT',symbols)
                continue
            expr=expression(text)
            if expr[0]!='call':raise ValueError('unmeasured function statement')
            op=expr[1].upper()
            if op in ('BON','DBON'):
                args=expr[2]
                if len(args)!=4 or args[0]!=('atom','TRUE'):raise ValueError('bit instruction guard outside profile')
                code+=H['always']+H[op]+self.atom(args[1],'WORD' if op=='BON' else 'DWORD',symbols)+self.atom(args[3],'BOOL',symbols)+self.atom(args[2],'INT',symbols)
            else:raise ValueError('unmeasured primitive statement: '+text)
        return code+H['SRET']

    def run(self):
        code=b''
        for text in statements(parse_st_pou(self.streams['MAIN.Program.pou']).text):
            m=re.fullmatch(r'(Y[0-7])\s*:=\s*(.*)',text,re.I|re.S)
            if not m:raise ValueError('MAIN outside direct BOOL output assignments')
            expr=expression(m[2]);self.register(expr)
            code+=self.bool_value(expr,{})+H['OUTY']+scalar('Y',int(m[1][1:],8))
        code+=H['FEND'];i=0
        while i<len(self.queue):
            code+=self.routine(self.queue[i]);i+=1
        active=set();done=set()
        def visit(key):
            if key in active:raise ValueError('recursive user functions outside measured profile')
            if key in done:return
            active.add(key)
            for child in self.edges[key]:visit(child)
            active.remove(key);done.add(key)
        for key in self.queue:visit(key)
        code+=H['NOP']+H['END']
        return dict(output=code,allocations=self.allocations,temporaries=self.temp_allocations,
                    global_blocks=self.globals.blocks if self.globals is not None else [],
                    routine_order=[dict(owner=self.frames[k]['definition']['doc']['owner'],pointer=self.frames[k]['p']) for k in self.queue],
                    scope='FX3G primitive source-only outlined functions; optional measured split structure globals, empty MAIN locals; no PLC execution proof.')


def predict(streams, **options):
    source={n:raw for n,raw in streams.items()
            if n in ('MAIN.Program.pou','MAIN.Labels.lh') or n.endswith(('.prj','.gh','.lng','.lns','.lnl','.lnb','.lif'))}
    result=Model(source,**options).run()
    result['input_contract']='Source .prj/.gh/.lng/.lns/.lnl/.lnb, ordered .lif library inventory and MAIN source/labels only. CGTable and generated library companions are excluded.'
    return result
