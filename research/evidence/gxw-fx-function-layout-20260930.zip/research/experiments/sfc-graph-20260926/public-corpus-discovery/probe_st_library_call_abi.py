"""Isolated real FX3G user-library call ABI observations, preserving library bytes.

The original project is already reduced to one task and one known-valid call.
These controls vary MAIN source only. No device execution or hash verification.
"""
from pathlib import Path
import base64,json,sys

ROOT=Path(__file__).resolve().parents[4]
P=Path(__file__).resolve().parent
sys.path[:0]=[str(P),str(ROOT/'src'),str(ROOT/'research')]
from probe_minimal_conditional_port_writes import streams,save,observe
from probe_gxw_st_sources import replace_observed_st
from probe_gxw_sfc_graph import patch_raw
from gxw.project_metadata import mark_observed_source_compile_pending
from probe_gxw_program_check_resources import SCRIPT
from native_gxw_tokens import native_batch,native_il_records
from inspect_st_branch_ir import decode
from inspect_st_library_call_abi import canonical

CASES={
    'Repeat':"Y0 := F_DISBON(16#00000004,2); Y1 := F_DISBON(16#00000008,3);",
    'Two-definitions':"Y0 := F_ISBON(16#0004,2); Y1 := F_DISBON(16#00000004,2);",
    'Nested-argument':"Y0 := F_DISBON(16#00000004,F_LIMIT(31,2,0));",
    'Boolean-pair':"Y0 := F_DISBON(16#80000000,2) AND F_DISBON(16#00000004,2);",
}


def main():
    out=P/'fx3g-st-library-call-abi-disc-20260930';out.mkdir(exist_ok=False)
    for name in (Path(__file__).name,'observe_st_block_walk_v7.js','observe_expression_temporaries.js'):
        (out/name).write_bytes((P/name).read_bytes())
    trace=out/'trace.js';trace.write_text('(()=>{'+SCRIPT+'\n})();\n(()=>{'+(P/'observe_st_block_walk_v7.js').read_text()+'\n})();\n(()=>{'+(P/'native-allocation-bitmap-v2/observer.js').read_text()+'\n'+(P/'observe_expression_temporaries.js').read_text()+'\n})();',encoding='utf-8')
    baseline=P/'fx3g-library-source-roundtrip-v6/original-library/candidate.gxw'
    source=baseline.read_bytes();before=streams(source);logical='MAIN.Program.pou';ready=[]
    save(out/'experiment-plan.json',dict(source=str(baseline),cases=CASES,
        hypothesis='Distinguish per-definition and per-call outlined routines, parameter/result frame reuse, first-use emission order and capture of a shared return in a Boolean pair. Library bodies and declarations stay raw-preserved.',
        evidence='Original FX3G UtilsV5 engineering-library lineage; controlled MAIN source replacement. Not an independent project lineage.'))
    for name,text in CASES.items():
        directory=out/name;directory.mkdir()
        replacement,_=replace_observed_st(before[logical],text)
        replacement=mark_observed_source_compile_pending(replacement,logical_name=logical)
        candidate,_=patch_raw(source,logical,before[logical],replacement)
        assert streams(candidate)==dict(before,**{logical:replacement})
        path=directory/'input.gxw';path.write_bytes(candidate)
        save(directory/'before-native.json',dict(source=text,changed_streams=[logical],
            untouched_payloads_byte_identical=True,untouched_payload_count=len(before)-1,
            predicted_structure='One outlined routine/frame per referenced definition; repeated calls share parameter and result storage. Boolean pair may require an explicit first-result capture. No full byte prediction for these discovery controls.'))
        ready.append((name,directory,path))
    rows=[];requests=[];keys=[]
    for name,directory,path in ready:
        native,result,process=observe(path,directory,trace)
        code_path=native/'pcode-0-0.bin';raw=code_path.read_bytes() if code_path.exists() else None
        row=dict(case=name,native_directory=str(native),check=result['check'],process=process,
                 generated_bytes=len(raw) if raw is not None else None,
                 diagnostics=[{k:v for k,v in r.items() if k!='raw_base64'} for r in result['diagnostics'] if r['kind']==2])
        if raw:
            requests.append(dict(mode='decode',input_base64=base64.b64encode(raw+b'\0').decode()));keys.append(name)
        if (native/'native-saved.gxw').exists():
            reopened=directory/'reopen';reopened.mkdir();rn,rr,rp=observe(native/'native-saved.gxw',reopened,trace)
            row['reopen']=dict(native_directory=str(rn),check=rr['check'],bytes_identical=raw==(rn/'pcode-0-0.bin').read_bytes(),process=rp)
        rows.append(row);save(out/'comparison.json',rows)
        print(json.dumps(row,ensure_ascii=True),flush=True)
    answers=native_batch(requests,out/'native-decode',cpu_code=521);listings=[]
    for name,request,answer in zip(keys,requests,answers,strict=True):
        expected_length=len(base64.b64decode(request['input_base64']))-1
        assert answer['return_code']=='0x00000000' and answer['consumed_bytes']==expected_length
        records=native_il_records(base64.b64decode(answer['output_base64']),encoding='cp1252')
        row=next(r for r in rows if r['case']==name);raw=(Path(row['native_directory'])/'pcode-0-0.bin').read_bytes()
        independent=decode(raw,'fx3g')
        assert canonical(records)==canonical(independent)
        listings.append(dict(case=name,records=records,independent_address_projection_match=True,
                             exact_spelling_match=records==[{k:v for k,v in r.items() if k not in ('offset','raw')} for r in independent]))
        save(out/name/'independent-listing.json',independent)
        print(json.dumps(dict(case=name,records=records),ensure_ascii=True),flush=True)
    save(out/'native-listings.json',listings)


if __name__=='__main__':main()
