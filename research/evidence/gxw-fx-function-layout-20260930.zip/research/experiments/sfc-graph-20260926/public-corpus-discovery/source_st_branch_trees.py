"""Bounded control trees from parse-only ST text; leaves stay opaque.

Used by a research output model. Original GXW source payloads are never changed
by parsing. Loops inside branches are not interpreted. The measured
profile permits two combined IF/CASE levels through explicit opt-ins. CASE
choices are bounded positive INT values/ranges. Unknown leaves remain available
to a typed consumer.
"""
import re


def parse_if(statements, start, *, first=None, max_depth=2, allow_cases=False, depth=1, allow_elsif=False):
    def statement(position, text, depth):
        if re.match(r'IF\b', text, re.I):
            return conditional(position, text, depth)
        if allow_cases and re.match(r'CASE\b',text,re.I):
            return parse_case(statements,position,first=text,max_depth=max_depth,allow_nested=True,depth=depth,allow_elsif=allow_elsif)
        if re.match(r'(ELSE|ELSIF|ELSEIF|END_IF|FOR|WHILE|REPEAT|CASE)\b', text, re.I):
            raise ValueError('unmeasured branch control statement')
        return dict(kind='statement', ordinal=position, text=text), position+1

    def conditional(position, text, depth, elsif_count=0):
        if depth>max_depth:
            raise ValueError('IF depth exceeds selected profile')
        match=re.fullmatch(r'IF\s+(.+?)\s+THEN(?:\s+(.*))?', text, re.S|re.I)
        if match is None:
            match=re.fullmatch(r'IF\s+(.+?(?:<>|<=|>=|=|<|>)\s*-?[0-9]+)THEN(?:\s+(.*))?', text, re.S|re.I)
        if match is None:
            raise ValueError('unrecognized IF tree header')
        node=dict(kind='if', ordinal=position, condition=match[1], then=[], otherwise=None)
        destination=node['then']
        rest=(match[2] or '').strip()
        if rest:
            child,position=statement(position,rest,depth+1)
            destination.append(child)
        else:
            position+=1
        while position<len(statements):
            text=statements[position].strip()
            if not text:
                position+=1
                continue
            if text.upper()=='END_IF':
                node['end_ordinal']=position
                return node,position+1
            elsif=re.fullmatch(r'ELSIF\s+(.+)',text,re.S|re.I)
            if elsif:
                if not allow_elsif or node['otherwise'] is not None or elsif_count>=2:
                    raise ValueError('ELSIF outside selected chain profile')
                # Native observed ELSIF is a 17e IF under the preceding ELSE.
                # It shares one END_IF and adds no lexical nesting level.
                child,position=conditional(position,'IF '+elsif[1],depth,elsif_count+1)
                child['source_header']='ELSIF'
                node['otherwise']=[child];node['end_ordinal']=child['end_ordinal']
                return node,position
            otherwise=re.fullmatch(r'ELSE(?:\s+(.*))?',text,re.S|re.I)
            if otherwise:
                if node['otherwise'] is not None:
                    raise ValueError('duplicate ELSE')
                node['otherwise']=[]
                destination=node['otherwise']
                rest=(otherwise[1] or '').strip()
                if rest:
                    child,position=statement(position,rest,depth+1)
                    destination.append(child)
                else:
                    position+=1
                continue
            child,position=statement(position,text,depth+1)
            destination.append(child)
        raise ValueError('unterminated IF tree')

    return conditional(start,first if first is not None else statements[start].strip(),depth)


def source_leaves(node):
    """Source order, independent of the ELSE-first emitted instruction order."""
    if node['kind']=='case':
        for arm in node['arms']:
            for child in arm['body']:
                if child['kind']=='statement':yield child
                else:yield from source_leaves(child)
        children=node['otherwise'] or []
    else:children=node['then']+(node['otherwise'] or [])
    for child in children:
        if child['kind']!='statement':
            yield from source_leaves(child)
        else:
            yield child


def parse_case(statements,start,*,first=None,max_depth=2,allow_nested=False,depth=1,allow_elsif=False):
    if depth>max_depth:raise ValueError('CASE/control depth exceeds selected profile')
    text=first if first is not None else statements[start].strip()
    header=re.fullmatch(r'CASE\s+(.+?)\s+OF(?:\s+(.*))?',text,re.S|re.I)
    if header is None:raise ValueError('unrecognized CASE header')
    node=dict(kind='case',ordinal=start,selector=header[1],arms=[],otherwise=None)
    position=start;rest=(header[2] or '').strip();destination=None
    while position<len(statements):
        if position!=start:rest=statements[position].strip()
        if not rest:position+=1;continue
        if rest.upper()=='END_CASE':
            if not node['arms']:raise ValueError('CASE requires measured arms')
            node['end_ordinal']=position
            return node,position+1
        arm=re.fullmatch(r'([0-9][0-9\s,.]*)\s*:\s*(.*)',rest,re.S)
        default=re.fullmatch(r'ELSE(?:\s+(.*))?',rest,re.S|re.I)
        if arm:
            if node['otherwise'] is not None:raise ValueError('CASE selection after ELSE')
            terms=[]
            for text in arm[1].split(','):
                term=re.fullmatch(r'\s*([0-9]+)(?:\s*\.\.\s*([0-9]+))?\s*',text)
                if term is None:raise ValueError('malformed CASE selection')
                low=int(term[1]);high=int(term[2]) if term[2] else None
                if low>32767 or high is not None and not low<high<=32767:raise ValueError('CASE selection outside positive INT range profile')
                terms.append(dict(kind='range',lower=low,upper=high) if high is not None else dict(kind='value',value=low))
            if len(node['arms'])>=4 or len(terms)>4:raise ValueError('CASE selection count outside bounded profile')
            selected=dict(selections=terms,ordinal=position,body=[])
            node['arms'].append(selected);destination=selected['body'];rest=arm[2].strip()
        elif default:
            if node['otherwise'] is not None:raise ValueError('duplicate CASE ELSE')
            node['otherwise']=[];destination=node['otherwise'];rest=(default[1] or '').strip()
        elif re.match(r'[-+0-9]',rest):raise ValueError('negative/typed CASE selections unmeasured')
        if rest:
            nested=re.match(r'(IF|CASE)\b',rest,re.I)
            if nested and allow_nested:
                if destination is None:raise ValueError('nested CASE control before any arm')
                if nested[1].upper()=='IF':child,position=parse_if(statements,position,first=rest,max_depth=max_depth,allow_cases=True,depth=depth+1,allow_elsif=allow_elsif)
                else:child,position=parse_case(statements,position,first=rest,max_depth=max_depth,allow_nested=True,depth=depth+1,allow_elsif=allow_elsif)
                destination.append(child);continue
            if destination is None or re.match(r'(IF|CASE|FOR|WHILE|REPEAT|EXIT|RETURN|END_)\b',rest,re.I):
                raise ValueError('control statement in CASE outside selected flat profile')
            destination.append(dict(kind='statement',ordinal=position,text=rest))
        position+=1
    raise ValueError('unterminated CASE')
