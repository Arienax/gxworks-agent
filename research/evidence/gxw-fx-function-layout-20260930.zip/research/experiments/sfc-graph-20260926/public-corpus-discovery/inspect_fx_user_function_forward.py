"""Cross-check saved source-only function ABI controls, without native reruns.

Keep original prospective failures distinct from post-observation fits; retain
raw cells, allocator records, instruction sink events and refusal diagnostics.
No formal report, broad regression suite or hash verification is produced.
"""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[4];P=Path(__file__).resolve().parent
sys.path[:0]=[str(P),str(ROOT/'src'),str(ROOT/'research')]
from probe_minimal_conditional_port_writes import save,streams
from inspect_st_branch_ir import decode
from source_fx_user_functions import predict

GROUPS=['fx3g-user-functions-forward-v2-20260930',
        'fx3g-user-functions-boolean-forward-20260930',
        'fx3g-user-functions-declaration-order-20260930']
TYPE_CODES={'BOOL':0,'INT':2,'WORD':17,'DWORD':18}


def main():
    all_rows=[]
    for group in GROUPS:
        out=P/group;findings=[]
        for row in json.loads((out/'comparison.json').read_text()):
            name=row['case'];directory=out/name;native=Path(row['native_directory'])
            events=[json.loads(l) for l in (native/'events.jsonl').read_text().splitlines()]
            payloads=[r.get('payload',{}) for r in events]
            errors=[r for r in events if r.get('type')=='error' or r.get('payload',{}).get('observation_error') or 'error' in r.get('payload',{}).get('event','')]
            assert not errors,(group,name,errors)
            wrappers=[r for r in payloads if r.get('event')=='block-walk' and r.get('name')=='wrapper' and r.get('phase')=='enter']
            assert wrappers and not any(r.get('graph_truncated') for r in wrappers)
            alloc=[r for r in payloads if r.get('event')=='typed-allocation']
            save(directory/'native-call-abi-ir.json',dict(wrapper_entries=wrappers,typed_allocations=alloc,
                 temporary_events=[r for r in payloads if r.get('event','').startswith('temporary-')],
                 sink_records=[r for r in payloads if r.get('event')=='sink-record'],
                 handling='Known entry-point events with raw cells and opaque fields retained. Not native execution semantics.'))
            finding=dict(group=group,case=name,prospective_equal=row['prospective_equal'],observer_errors=errors,
                         check=row['check'],reopen=row.get('reopen'))
            if not row['generated_bytes']:
                assert row['expected_error']=='temporary capacity exhausted: M'
                assert row['check'] is None and any(d['arguments']==['M'] for d in row['diagnostics'])
                finding.update(status='native-frontend-refusal',diagnostics=row['diagnostics'],source_model_refusal=row['expected_error'])
                try:predict(streams((directory/'input.gxw').read_bytes()))
                except ValueError as error:assert str(error)==row['expected_error']
                else:raise AssertionError('current source model silently accepted exhausted temporary pool')
            else:
                assert row['check'] and not row['check']['rejected'] and not row['reopen']['check']['rejected'] and row['reopen']['bytes_identical']
                assert row['independent_address_projection_match']
                raw=(native/'pcode-0-0.bin').read_bytes();listing=decode(raw,'fx3g')
                prediction=predict(streams((directory/'input.gxw').read_bytes()))
                assert raw==prediction['output']
                expected=[dict(type=TYPE_CODES[r['type']],category=r['category'],family=r['family'],number=r['number'],count=r['count']) for r in prediction['allocations']]
                observed=[]
                for r in alloc:
                    address=bytes.fromhex(r['after']);assert r['result']==1 and len(address)==26
                    family={0x24:'D',0x21:'M'}[address[0]]
                    observed.append(dict(type=r['type'],category=r['category'],family=family,
                                         number=int.from_bytes(address[2:5],'little'),count=int.from_bytes(address[6:10],'little')))
                assert observed==expected,(group,name,observed,expected)
                fend=next(i for i,r in enumerate(listing) if r.get('op')=='FEND')
                regions=[];current=None
                for record in listing[fend+1:]:
                    if record['kind']=='label':
                        assert current is None
                        current=dict(label=record['text'],records=[record])
                    elif current is not None:
                        current['records'].append(record)
                        if record.get('op')=='SRET':regions.append(current);current=None
                assert current is None and [r['label'] for r in regions]==['P'+str(r['pointer']) for r in prediction['routine_order']]
                save(directory/'outlined-routine-regions.json',dict(main=listing[:fend+1],routines=regions,
                     terminal=[r for r in listing if r['offset']>=regions[-1]['records'][-1]['offset']+len(bytes.fromhex(regions[-1]['records'][-1]['raw']))]))
                finding.update(status='accepted-check-and-reopen',generated_bytes=len(raw),allocation_projection_equal=True,
                               allocation_projection=observed,routine_order=prediction['routine_order'],
                               current_source_model_equal=True,
                               corrected_after_observation=row['prospective_equal'] is False)
            findings.append(finding);all_rows.append(finding)
        save(out/'call-abi-findings.json',dict(cases=findings,boundary='One FX3G lineage, primitive functions, isolated empty unused globals; no PLC runtime claim.'))
    summary=dict(scope='Source-only primitive FX3G outlined user functions, original native source bodies preserved. No product integration or original structure-global allocation claim.',
                 observations=len(all_rows),accepted=sum(r['status']=='accepted-check-and-reopen' for r in all_rows),
                 prospective_full_byte_matches=sum(r['prospective_equal'] is True for r in all_rows),
                 prospective_full_byte_failures=sum(r['prospective_equal'] is False for r in all_rows),
                 expected_capacity_refusals=sum(r['status']=='native-frontend-refusal' for r in all_rows),
                 cases=all_rows)
    save(P/'fx3g-user-function-source-model-summary-20260930.json',summary)
    print(json.dumps({k:v for k,v in summary.items() if k!='cases'}),flush=True)


if __name__=='__main__':main()
