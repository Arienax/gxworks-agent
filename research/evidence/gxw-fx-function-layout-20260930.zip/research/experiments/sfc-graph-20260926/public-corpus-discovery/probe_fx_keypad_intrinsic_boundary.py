"""Separate FX3U intrinsic support from the accepted Q03UDV transplant.

Only the Keypad source stream is changed. Retain all declarations, caller and
CPU metadata; isolated offline native build/check/export/reopen, no device API.
"""
from pathlib import Path
import json,sys,struct
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from probe_minimal_conditional_port_writes import streams,save,observe
from probe_gxw_st_sources import replace_observed_st
from probe_gxw_sfc_graph import patch_raw
from gxw.project_metadata import mark_observed_source_compile_pending
from probe_gxw_program_check_resources import SCRIPT
from source_q_st_calls import predict
from probe_gxw_parameters import project_allocation_ranges
P=Path(__file__).resolve().parent


def main():
    config=json.loads(Path(sys.argv[1]).read_text()) if len(sys.argv)>1 else {}
    out=P/config.get('directory','fx-keypad-intrinsic-boundary-20260930');out.mkdir(exist_ok=False)
    (out/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    if config.get('prediction_options'):
        for name in ('source_q_st_calls.py','source_st_branch_trees.py','source_fx_string_slice.py','source_q_direct_declarations.py','source_q_st_expressions.py','source_q_label_binding.py','source_q_width.py'):
            (out/name).write_bytes((P/name).read_bytes())
    extra=''
    if config.get('observe_allocations'):
        shared=[]
        for name in ('native-allocation-bitmap-v2/observer.js','observe_expression_temporaries.js','observe_bit_request_stacks.js'):
            raw=(P/name).read_text();shared.append(raw)
            (out/Path(name).name).write_text(raw)
        extra+='\n(()=>{'+shared[0]+'\n'+shared[1]+'\n})();\n(()=>{'+shared[2]+'\n})();\n'
    extra+='''
Process.attachModuleObserver({onAdded(m){
 if(!/^eccodegenerator(?:fx)?2\\.dll$/i.test(m.name))return;
 const open=m.findExportByName('Open');if(!open)return;
 Interceptor.attach(open,{onEnter(a){send({event:'codegen-open',module:m.name,cpu:a[1].toInt32(),mode:a[2].toInt32()});}});
}});
'''
    if config.get('extra_observer'):
        observer=P/config['extra_observer'];raw=observer.read_text();extra+='\n(()=>{'+raw+'\n})();\n'
        (out/observer.name).write_text(raw)
    trace=out/'trace.js';trace.write_text('(()=>{'+SCRIPT+'\n})();\n'+extra)
    original=(P/'boxid-keypad-call-native/input.gxw').read_bytes()
    before=streams(original);name='Keypad.Program.pou'
    _,body=replace_observed_st(before[name],'')
    cases={
        'clear-only':"in_out_character := 0; number := ''; key_iterator := 0;",
        'WORD_TO_STR-only':'tempCharacter := WORD_TO_STR(in_out_character);',
        'RIGHT-only':'tempCharacter := \'1\'; RIGHT(1,tempCharacter,1,newString);',
        'CONCAT-only':"newString := '1'; number := CONCAT(number,newString);",
        'whole-with-literal-conversion':body.replace('WORD_TO_STR(in_out_character)',"'1'"),
    }
    if config.get('cases'):
        cases={k:(body.replace('WORD_TO_STR(in_out_character)',v['conversion']) if 'conversion' in v else v['source']) for k,v in config['cases'].items()}
    save(out/'experiment-plan.json',dict(config,source_project=str(P/'boxid-keypad-call-native/input.gxw'),cases=cases))
    ready=[]
    for case,text in cases.items():
        d=out/case;d.mkdir();plan=config.get('cases',{}).get(case,{})
        raw,_=replace_observed_st(before[name],text)
        raw=mark_observed_source_compile_pending(raw,logical_name=name)
        source,_=patch_raw(original,name,before[name],raw)
        changes={name:raw}
        if plan.get('pools'):
            project=next(k for k in before if k.endswith('.prj'));metadata=bytearray(before[project])
            ranges={r['name']:r for r in project_allocation_ranges(metadata)['ranges']}
            for family,pair in plan['pools'].items():struct.pack_into('<II',metadata,ranges[family]['offset'],*pair)
            changes[project]=bytes(metadata);source,_=patch_raw(source,project,before[project],changes[project])
        assert streams(source)==dict(before,**changes)
        path=d/'input.gxw';path.write_bytes(source)
        prediction=None
        if config.get('prediction_options'):
            try:prediction=predict(source,('Keypad',),owner='POU_01',**config['prediction_options'])
            except ValueError as exc:
                if not plan.get('allow_unsupported'):raise
                prediction=dict(unsupported=str(exc))
            if prediction.get('output') is not None:(d/'predicted-0.bin').write_bytes(prediction['output'])
        save(d/'before-native.json',dict(case=case,source=text,cpu='FX3U/FX3UC',changed_streams=list(changes),unrelated_logical_payloads='byte-identical',unrelated_payload_count=len(before)-len(changes),prediction={k:v for k,v in prediction.items() if k not in ('output','sha256')} if prediction else 'Discovery: CPU capability versus shared offline adapter not yet distinguished.'))
        ready.append((case,d,path))
    rows=[]
    for case,d,path in ready:
        n,result,process=observe(path,d,trace)
        generated={f.name:f.read_bytes() for f in sorted(n.glob('pcode-*.bin'))}
        row=dict(case=case,native_directory=str(n),check=result['check'],backend_rejected=result['backend_check_rejected'],diagnostic_codes=sorted({hex(e['code']) for e in result['diagnostics'] if e['kind']==2}),diagnostic_arguments=[e['arguments'] for e in result['diagnostics'] if e['kind']==2],pcode_sizes={k:len(v) for k,v in generated.items()},process=process)
        if (d/'predicted-0.bin').exists():row['before_native_prediction_equal']=(d/'predicted-0.bin').read_bytes()==generated.get('pcode-0-0.bin')
        if (n/'native-saved.gxw').exists():
            rd=d/'reopen';rd.mkdir();rn,rr,rp=observe(n/'native-saved.gxw',rd,trace)
            other={f.name:f.read_bytes() for f in rn.glob('pcode-*.bin')}
            row['reopen']=dict(native_directory=str(rn),check=rr['check'],backend_rejected=rr['backend_check_rejected'],bytes_identical=generated==other)
        rows.append(row);save(out/'comparison.json',rows)
        print(json.dumps(row),flush=True)


if __name__=='__main__':main()
