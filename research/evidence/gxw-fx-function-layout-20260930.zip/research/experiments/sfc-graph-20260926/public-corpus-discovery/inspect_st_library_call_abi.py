"""Inspect saved FX3G call-ABI observations without native reruns.

Exact lexical spellings and known octal X/Y address equivalence are separate.
Uninterpreted native cells, routine bodies and allocator fields stay raw.
"""
from pathlib import Path
import base64,json,re,sys

ROOT=Path(__file__).resolve().parents[4]
P=Path(__file__).resolve().parent
sys.path[:0]=[str(P),str(ROOT/'src'),str(ROOT/'research')]
from native_gxw_tokens import native_il_records
from inspect_st_branch_ir import decode
from probe_minimal_conditional_port_writes import save


def canonical(records):
    result=[]
    for record in records:
        row={k:v for k,v in record.items() if k not in ('offset','raw')}
        if row['kind']=='instruction':
            row['args']=[re.sub(r'^([XY])([0-7]+)$',lambda m:m[1]+format(int(m[2],8),'o'),arg) for arg in row['args']]
        result.append(row)
    return result


def main():
    group=sys.argv[1] if len(sys.argv)>1 else 'fx3g-st-library-call-abi-disc-20260930'
    out=P/group;rows=json.loads((out/'comparison.json').read_text())
    answers=[json.loads(line) for line in (out/'native-decode/native-stdout.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    assert len(answers)==len(rows)
    listings=[];findings=[]
    for row,answer in zip(rows,answers,strict=True):
        name=row['case'];native=Path(row['native_directory']);raw=(native/'pcode-0-0.bin').read_bytes()
        assert answer['return_code']=='0x00000000' and answer['consumed_bytes']==len(raw)
        observed=native_il_records(base64.b64decode(answer['output_base64']),encoding='cp1252')
        independent=decode(raw,'fx3g');exact=observed==[{k:v for k,v in r.items() if k not in ('offset','raw')} for r in independent]
        assert canonical(observed)==canonical(independent),(name,'independent lexical mismatch beyond octal X/Y padding')
        assert row['check'] and not row['check']['rejected'] and not row['reopen']['check']['rejected'] and row['reopen']['bytes_identical']
        save(out/name/'independent-listing.json',independent)
        if not exact:
            save(out/name/'lexical-spelling-difference.json',dict(handling='known-FX-octal-address-padding',native=observed,independent=independent,
                 equivalence='Only standalone X/Y octal operands normalize leading zeros. All opcode, operand order and other spellings compare exactly. No hash verification.'))
        fend=next(i for i,r in enumerate(independent) if r.get('op')=='FEND')
        main_records=independent[:fend+1];bodies={};current=None
        for record in independent[fend+1:]:
            if record['kind']=='label':current=record['text'];bodies[current]=[record]
            elif current is not None:bodies[current].append(record)
        calls=[dict(offset=r['offset'],target=r['args'][0]) for r in main_records if r.get('op')=='CALL']
        events=[json.loads(line).get('payload',{}) for line in (native/'events.jsonl').read_text().splitlines()]
        errors=[e for e in events if 'error' in e.get('event','')];assert not errors,(name,errors)
        allocations=[e for e in events if e.get('event')=='typed-allocation']
        wrappers=[e for e in events if e.get('event')=='block-walk' and e.get('name')=='wrapper' and e.get('phase')=='enter']
        assert wrappers and not any(w.get('graph_truncated') for w in wrappers)
        save(out/name/'call-abi-native-ir.json',dict(scope='Raw-preserved observed wrapper cells, allocator requests and instruction-sink records. Callee IDs, source symbol fields and unrelated node types are not inferred.',
             wrapper_entries=wrappers,allocations=allocations,temporary_events=[e for e in events if e.get('event','').startswith('temporary-')],
             sink_records=[e for e in events if e.get('event')=='sink-record']))
        save(out/name/'outlined-routine-regions.json',dict(scope='Observed label-to-SRET bodies retained as byte/listing regions; roles come from native call targets, not library-name assumptions.',
             main=main_records,routines=bodies))
        finding=dict(case=name,generated_bytes=len(raw),native_check_reopen_accepted=True,exact_lexical_spelling_match=exact,
                     independent_address_projection_match=True,main_calls=calls,outlined_labels=list(bodies),observer_errors=errors)
        listings.append(dict(case=name,records=observed));findings.append(finding)
        print(json.dumps(finding,ensure_ascii=True),flush=True)
    save(out/'native-listings.json',listings);save(out/'call-abi-findings.json',dict(scope='Native-observed user-library call boundaries; no prospective full-byte claim or PLC execution.',cases=findings))
    (out/Path(__file__).name).write_bytes(Path(__file__).read_bytes())


if __name__=='__main__':main()
