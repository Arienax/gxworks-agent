"""Prospective ELSIF chain/context/capacity plans for two offline CPU dialects."""
from pathlib import Path
from copy import deepcopy
import json

P=Path(__file__).resolve().parent


def main():
    initialization="result := ''; key_iterator := 0; for_iterator := 0; newString := 'X'; tempString[key_iterator] := newString; newString := 'Y'; tempString[1] := newString; newString := 'X'; "
    first="result := 'T'; result := CONCAT(result,tempString[key_iterator + 1]); "
    second="result := 'F'; result := CONCAT(result,tempString[key_iterator]); "
    last="result := 'L'; result := CONCAT(result,tempString[key_iterator]); "
    default="result := 'D'; result := CONCAT(result,tempString[key_iterator]); "
    chain=f'IF selector = 49 THEN {first}ELSIF selector = 67 THEN {second}ELSE {default}END_IF;'
    two=f'IF selector = 49 THEN {first}ELSIF selector = 67 THEN {second}ELSIF selector = 88 THEN {last}ELSE {default}END_IF;'
    no_else=f'IF selector = 49 THEN {first}ELSIF selector = 67 THEN {second}ELSIF selector = 88 THEN {last}END_IF;'
    inner="CASE key_iterator OF 0: result := 'C'; result := CONCAT(result,tempString[key_iterator]); 1: result := 'B'; result := CONCAT(result,tempString[key_iterator]); ELSE result := 'E'; result := CONCAT(result,tempString[key_iterator]); END_CASE; "
    case_else=f'IF selector = 49 THEN {first}ELSIF selector = 67 THEN {inner}ELSE {default}END_IF;'
    experiments=[('Tail',67,chain,4,'FX'),('Last',88,two,5,'LX'),('No-else',99,no_else,4,''),('Capacity-3',49,chain,3,None),('Capacity-4',49,chain,4,'TY'),('Case-else',67,case_else,6,'CX')]
    q_base=json.loads((P/'q-st-case-context-forward-plan.json').read_text())
    q=deepcopy(q_base);q['directory']='q-st-elsif-forward-20260930';q['cases']=[]
    fx_base=json.loads((P/'fx-st-case-context-forward-plan.json').read_text())
    fx=deepcopy(fx_base);fx['directory']='fx-st-elsif-forward-20260930';fx['cases']={}
    for config in (q,fx):
        config['prediction_options']['allow_elsif_chains']=True
        config['expected_results']={name:value for name,_,_,_,value in experiments if value is not None}
        config['expected_rejections']=['Capacity-3']
    template=q_base['cases'][1]
    for name,value,control,words,expected in experiments:
        plan=deepcopy(template);plan['case']=name
        plan['root']=plan['root'].replace('probeR0 := 49',f'probeR0 := {value}')
        plan['body']=initialization+control.replace('selector','value')
        plan['pools']={'D':[13210-words,13311]};plan['pointer_range']=[2400,2415]
        plan['hypothesis']='Before-native hypothesis: ELSIF lowers to a tail ELSE-child IF sharing the outer end; source-order subtree captures precede first condition, including CASE in the ELSIF branch. Three captures plus first-arm arithmetic index require four words.'
        if expected is None:plan['allow_unsupported']=True
        q['cases'].append(plan)
        fplan=deepcopy(next(iter(fx_base['cases'].values())))
        fplan['source']=(initialization+control.replace('selector','for_iterator')).replace('for_iterator := 0;',f'for_iterator := {value};').replace('result','number')
        fplan['pools']={'D':[951-words,999],'P':[2048,2063]}
        if expected is None:fplan['allow_unsupported']=True
        else:fplan.pop('allow_unsupported',None)
        fx['cases'][name]=fplan
    for cpu,config in (('q',q),('fx',fx)):
        target=P/f'{cpu}-st-elsif-forward-plan.json'
        if target.exists():raise FileExistsError(target)
        target.write_text(json.dumps(config,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        print(target)


if __name__=='__main__':main()
