"""Prospective source-only outlined function ABI under relocated FX3G pools.

Only copied offline projects compile/check/save/reopen. Plans explicitly choose
empty unused globals or preserve the original structure globals. Source row
reordering is a separate control. Every prediction precedes all native runs.
"""
from pathlib import Path
from dataclasses import replace
import base64,json,struct,sys

ROOT=Path(__file__).resolve().parents[4];P=Path(__file__).resolve().parent
sys.path[:0]=[str(P),str(ROOT/'src'),str(ROOT/'research')]
from probe_minimal_conditional_port_writes import streams,save,observe
from probe_fx3g_library_declarations import source_rows
from gxw.source_header import source_payload_offset
from gxw.declarations import parse_structure_declarations,parse_declarations,serialize_declarations,edit_declarations,_type_parts,_string
from gxw.project_metadata import mark_observed_source_compile_pending
from probe_gxw_st_sources import replace_observed_st
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_parameters import project_allocation_ranges
from probe_retain_class10_holdouts import patch_pool_metadata
from probe_gxw_program_check_resources import SCRIPT
from source_fx_user_functions import predict
from native_gxw_tokens import native_batch,native_il_records
from inspect_st_branch_ir import decode
from inspect_st_library_call_abi import canonical

CASES={
    'Reverse-roots':dict(source='Y2 := F_DISBON(16#00000100,8); Y3 := F_ISBON(16#0080,7);'),
    'Nested-and-repeat':dict(source='Y4 := F_DISBON(16#80000000,F_LIMIT(31,4,0)); Y5 := F_DISBON(16#00000010,4);'),
    'Shared-return-and':dict(source='Y6 := F_DISBON(16#00000020,5) AND F_DISBON(16#00000040,6);'),
    'Mixed-return-or':dict(source='Y7 := F_ISBON(16#0001,0) OR F_DISBON(16#00000002,1);'),
}


def main():
    out=P/(sys.argv[1] if len(sys.argv)>1 else 'fx3g-user-functions-forward-v2-20260930');out.mkdir(exist_ok=False)
    config=json.loads(Path(sys.argv[2]).read_text()) if len(sys.argv)>2 else {}
    cases=config.get('cases',config or CASES)
    preserve_globals=config.get('preserve_globals',False);options=config.get('prediction_options',{})
    for name in (Path(__file__).name,'source_fx_user_functions.py','source_fx_structure_layout.py','probe_fx3g_library_declarations.py','source_q_label_binding.py','observe_st_block_walk_v7.js','observe_expression_temporaries.js','inspect_st_library_call_abi.py'):
        (out/name).write_bytes((P/name).read_bytes())
    trace=out/'trace.js';trace.write_text('(()=>{'+SCRIPT+'\n})();\n(()=>{'+(P/'observe_st_block_walk_v7.js').read_text()+'\n})();\n(()=>{'+(P/'native-allocation-bitmap-v2/observer.js').read_text()+'\n'+(P/'observe_expression_temporaries.js').read_text()+'\n})();',encoding='utf-8')
    baseline=P/'fx3g-library-source-roundtrip-v6/original-library/candidate.gxw'
    original=baseline.read_bytes();before=streams(original);controlled=original;modifications={}
    for name in (() if preserve_globals else ('Global1.gh','GVL_TCO\\TimeControl.lng')):
        raw=before[name];doc=source_rows(raw,False)
        replacement=raw[:source_payload_offset(raw)]+struct.pack('<I',0)+bytes.fromhex(doc['trailer_hex'])
        assert not source_rows(replacement,False)['rows']
        controlled,_=patch_raw(controlled,name,raw,replacement);modifications[name]=replacement
    metadata=next(n for n in before if n.endswith('.prj'));new=bytearray(before[metadata])
    ranges={r['name']:r for r in project_allocation_ranges(new)['ranges']}
    pools=config.get('pools',{'D':[5000,5015],'M':[5000,5015],'P':[1700,1715]})
    for name,pair in pools.items():struct.pack_into('<II',new,ranges[name]['offset'],*pair)
    controlled,_=patch_pool_metadata(controlled,metadata,before[metadata],bytes(new),pools);modifications[metadata]=bytes(new)
    assert streams(controlled)==dict(before,**modifications)
    (out/'controlled-baseline.gxw').write_bytes(controlled)
    save(out/'experiment-plan.json',dict(source=str(baseline),cases=cases,pools=pools,
         changed_global_tables=[] if preserve_globals else ['Global1.gh','GVL_TCO\\TimeControl.lng'],
         simplification='Preserve original global declarations and structure types.' if preserve_globals else 'Remove unused structure/DWORD global storage only in isolated copied controls. No claim of source-only allocation for the original structure globals.',
         prediction_options=options,
         hypotheses=config.get('hypotheses',['Nested argument calls register postorder; root calls register before dependencies discovered in outlined bodies.',
                     'One frame/routine per definition, inputs then implicit return then locals, queue in first registration order.',
                     'Repeated BOOL calls capture the first shared return; test OR and different definitions as new controls.']),
         boundary='One FX3G project lineage, primitive library functions and optional flat structure globals; no PLC/device execution.'))
    ready=[]
    for name,case in cases.items():
        directory=out/name;directory.mkdir();logical='MAIN.Program.pou'
        case_source=controlled;case_modifications=dict(modifications)
        if 'pools' in case:
            latest=bytearray(modifications[metadata])
            for bank,pair in case['pools'].items():struct.pack_into('<II',latest,ranges[bank]['offset'],*pair)
            case_source,_=patch_pool_metadata(controlled,metadata,modifications[metadata],bytes(latest),case['pools'])
            case_modifications[metadata]=bytes(latest)
        for label,ids in case.get('declaration_row_order',{}).items():
            old=streams(case_source)[label];doc=source_rows(old,True)
            by_id={r['record_id']:old[r['offset']:r['offset']+r['size']] for r in doc['rows']}
            assert len(by_id)==len(doc['rows']) and set(ids)==set(by_id) and len(ids)==len(by_id)
            reordered=old[:doc['rows'][0]['offset']]+b''.join(by_id[i] for i in ids)+bytes.fromhex(doc['trailer_hex'])
            assert sorted((r['record_id'],r['name']) for r in source_rows(reordered,True)['rows'])==sorted((r['record_id'],r['name']) for r in doc['rows'])
            case_source,_=patch_raw(case_source,label,old,reordered);case_modifications[label]=reordered
        for label,ids in case.get('structure_member_order',{}).items():
            old=streams(case_source)[label];doc=parse_structure_declarations(old,logical_name=label)
            by_id={m.record_id:m.raw for m in doc.members}
            assert len(by_id)==len(doc.members) and set(ids)==set(by_id) and len(ids)==len(by_id)
            reordered=doc.header+b''.join(by_id[i] for i in ids)+doc.trailer
            assert sorted((m.record_id,m.name) for m in parse_structure_declarations(reordered,logical_name=label).members)==sorted((m.record_id,m.name) for m in doc.members)
            case_source,_=patch_raw(case_source,label,old,reordered);case_modifications[label]=reordered
        for label,changes in case.get('structure_member_types',{}).items():
            old=streams(case_source)[label];doc=parse_structure_declarations(old,logical_name=label)
            assert set(changes)<=set(m.name for m in doc.members)
            parts=[]
            for member in doc.members:
                if member.name not in changes:parts.append(member.raw);continue
                change=changes[member.name];base,bounds=_type_parts(change['data_type'])
                assert base==member.data_type and bounds and set(change)=={'data_type','initial_value'}
                changed_member=replace(member,data_type=change['data_type'],initial_value=change['initial_value'],array_marker=1)
                parts.append(b''.join((_string(changed_member.name),_string(changed_member.data_type),_string(changed_member.initial_value),
                    _string(changed_member.unknown_text),struct.pack('<I',changed_member.record_id),_string(changed_member.comment),
                    struct.pack('<II',changed_member.array_marker,changed_member.type_code),_string(changed_member.type_reference))))
            changed=doc.header+b''.join(parts)+doc.trailer;parse_structure_declarations(changed,logical_name=label)
            case_source,_=patch_raw(case_source,label,old,changed);case_modifications[label]=changed
        for label,types in case.get('global_structure_bounds',{}).items():
            old=streams(case_source)[label];doc=parse_declarations(old,logical_name=label)
            selected={r.name:r for r in doc.rows if r.name in types};assert len(selected)==len(types)
            for key,new_type in types.items():
                base,bounds=_type_parts(new_type);row=selected[key]
                assert row.type_code==9 and row.unknown_u32==2 and bounds and base==row.type_reference
            rows=tuple(replace(r,data_type=types[r.name]) if r.name in types else r for r in doc.rows)
            changed=serialize_declarations(replace(doc,rows=rows))
            parsed=parse_declarations(changed,logical_name=label)
            for a,b in zip(doc.rows,parsed.rows,strict=True):assert replace(b,data_type=a.data_type,offset=a.offset,raw=a.raw)==a
            case_source,_=patch_raw(case_source,label,old,changed);case_modifications[label]=changed
        for label,additions in case.get('clone_structure_globals',{}).items():
            old=streams(case_source)[label];doc=parse_declarations(old,logical_name=label);rows=list(doc.rows)
            for addition in additions:
                prototype_doc=parse_declarations(streams(case_source)[addition['prototype_document']],logical_name=addition['prototype_document']) if 'prototype_document' in addition else doc
                prototype=next(r for r in prototype_doc.rows if r.name==addition['prototype'])
                base,bounds=_type_parts(addition['data_type'])
                assert base==prototype.type_reference and bounds and prototype.type_code==9 and prototype.unknown_u32==2
                assert addition['name'] not in {r.name for r in rows} and addition['record_id'] not in {r.record_id for r in rows}
                rows.append(replace(prototype,name=addition['name'],data_type=addition['data_type'],record_id=addition['record_id']))
            changed=serialize_declarations(replace(doc,rows=tuple(rows)));parse_declarations(changed,logical_name=label)
            case_source,_=patch_raw(case_source,label,old,changed);case_modifications[label]=changed
        for label,additions in case.get('new_primitive_globals',{}).items():
            old=streams(case_source)[label];doc=parse_declarations(old,logical_name=label)
            assert all(a['name'] not in {r.name for r in doc.rows} and a['data_type'] in ('BOOL','INT','WORD','DWORD') for a in additions)
            edited=edit_declarations(doc,upserts=[dict(name=a['name'],data_type=a['data_type'],class_name='VAR_GLOBAL') for a in additions])
            ids={a['name']:a['record_id'] for a in additions}
            rows=tuple(replace(r,record_id=ids[r.name]) if r.name in ids else r for r in edited.rows)
            assert len({r.record_id for r in rows})==len(rows)
            changed=serialize_declarations(replace(edited,rows=rows));parse_declarations(changed,logical_name=label)
            case_source,_=patch_raw(case_source,label,old,changed);case_modifications[label]=changed
        replacement,_=replace_observed_st(before[logical],case['source'])
        replacement=mark_observed_source_compile_pending(replacement,logical_name=logical)
        candidate,_=patch_raw(case_source,logical,before[logical],replacement)
        assert streams(candidate)==dict(before,**case_modifications,**{logical:replacement})
        path=directory/'input.gxw';path.write_bytes(candidate)
        try:prediction=predict(streams(candidate),**options)
        except ValueError as error:
            if case.get('expected_error')!=str(error):raise
            prediction=dict(output=None,expected_error=str(error))
        if prediction['output'] is not None:(directory/'prediction-before-native.bin').write_bytes(prediction['output'])
        save(directory/'prediction-before-native.json',dict(source=case['source'],changed_streams=list(case_modifications)+[logical],
             untouched_payloads_byte_identical=True,untouched_payload_count=len(before)-len(case_modifications)-1,
             prediction={k:v for k,v in prediction.items() if k!='output'},predicted_bytes=len(prediction['output']) if prediction['output'] else None))
        ready.append((name,directory,path,prediction))
    rows=[];requests=[]
    for name,directory,path,prediction in ready:
        native,result,process=observe(path,directory,trace);code_path=native/'pcode-0-0.bin'
        raw=code_path.read_bytes() if code_path.exists() else None
        row=dict(case=name,native_directory=str(native),check=result['check'],process=process,
                 generated_bytes=len(raw) if raw else None,prospective_equal=raw==prediction['output'] if prediction['output'] is not None else None,
                 expected_error=prediction.get('expected_error'),
                 diagnostics=[{k:v for k,v in r.items() if k!='raw_base64'} for r in result['diagnostics'] if r['kind']==2])
        if raw:
            requests.append(dict(mode='decode',input_base64=base64.b64encode(raw+b'\0').decode()))
            if prediction['output'] is not None and raw!=prediction['output']:
                got=decode(raw,'fx3g')
                try:want=decode(prediction['output'],'fx3g');gap=None
                except ValueError as error:want=None;gap=str(error)
                save(directory/'prospective-mismatch.json',dict(expected=want,expected_hex=prediction['output'].hex(),expected_decoder_gap=gap,actual=got))
        if raw is not None and (native/'native-saved.gxw').exists():
            reopened=directory/'reopen';reopened.mkdir();rn,rr,rp=observe(native/'native-saved.gxw',reopened,trace)
            row['reopen']=dict(native_directory=str(rn),check=rr['check'],bytes_identical=raw==(rn/'pcode-0-0.bin').read_bytes(),process=rp)
        rows.append(row);save(out/'comparison.json',rows);print(json.dumps(row,ensure_ascii=True),flush=True)
    answers=native_batch(requests,out/'native-decode',cpu_code=521)
    for row,answer in zip([r for r in rows if r['generated_bytes']],answers,strict=True):
        raw=(Path(row['native_directory'])/'pcode-0-0.bin').read_bytes()
        assert answer['return_code']=='0x00000000' and answer['consumed_bytes']==len(raw)
        observed=native_il_records(base64.b64decode(answer['output_base64']),encoding='cp1252');independent=decode(raw,'fx3g')
        assert canonical(observed)==canonical(independent)
        row['independent_address_projection_match']=True
        save(out/row['case']/'independent-listing.json',independent)
    save(out/'comparison.json',rows)
    print(json.dumps(dict(cases=len(rows),prospective_matches=sum(r['prospective_equal'] is True for r in rows),
                         accepted=sum(bool(r['check']) and not r['check']['rejected'] for r in rows))),flush=True)


if __name__=='__main__':main()
