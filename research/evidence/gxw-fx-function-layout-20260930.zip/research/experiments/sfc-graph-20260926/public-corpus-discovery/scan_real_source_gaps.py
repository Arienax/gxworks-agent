"""Inspect current real-source capabilities, independent of stale inventories.

Original engineering projects stay local. Exact byte equality deduplicates
inputs and checks reconstruction; no hashes or native compilation are used.
"""
from pathlib import Path
from collections import Counter
import json,re,sys

ROOT=Path(__file__).resolve().parents[4]
P=Path(__file__).resolve().parent
sys.path[:0]=[str(P),str(ROOT/'src'),str(ROOT/'research')]
from probe_minimal_conditional_port_writes import streams
from gxw.source_header import source_payload_offset
from gxw.lossless import inspect_program
from gxw.project_metadata import read_project_text_context


def main():
    files=[P/r['local_file'] for r in json.loads((P/'download-inventory.json').read_text())]
    for folder in ('native-allocation-inventory','additional-real-projects','new-source-holdouts','cross-family-source-holdouts'):
        files.extend(sorted((P/folder).glob('case-*/input.gxw')))
    seen=[];unique=[]
    for path in files:
        if path.exists():
            raw=path.read_bytes()
            if raw not in seen:seen.append(raw);unique.append(path)
    counts=Counter();rows=[];errors=[]
    for path in unique:
        try:
            content=streams(path.read_bytes())
            context=read_project_text_context(next(v for k,v in content.items() if k.endswith('.prj')))
        except Exception as exc:
            errors.append(dict(file=str(path.relative_to(ROOT)),error=str(exc)));continue
        cpu=context['cpu']
        profile={'Q03UDV':'q03udv','Q02CPU':'q02','Q02HCPU':'q02','Q02/Q02H':'q02','FX3U/FX3UC':'fx3u','FX1S':'fx1s','FX3G':'fx3g'}.get(cpu)
        for name,raw in content.items():
            if not name.endswith('.pou'):continue
            try:offset=source_payload_offset(raw)
            except Exception:offset=None
            image=inspect_program(raw,logical_name=name,token_profile=profile,text_encoding=context['text_encoding'])
            assert image.reconstruct()==raw,(path,name)
            counts[(cpu,image.layout)]+=1
            row=dict(file=str(path.relative_to(ROOT)),cpu=cpu,name=name,payload_offset=offset,
                     bytes=len(raw),layout=image.layout,diagnostics=image.diagnostics,
                     region_handling=dict(Counter(r.handling for r in image.regions)),byte_reconstruction=True)
            if image.layout=='structured-text':
                row['source']=image.projection.text
                row['call_like_tokens']=sorted(set(re.findall(r'\b([A-Za-z_]\w*)\s*\(',image.projection.text or '')))
                row['call_like_token_handling']='Lexical candidates only, including comments; not a semantic function inventory.'
            rows.append(row)
    result=dict(scope='Current code against original local real projects. Source framing and raw preservation only; no source freshness or runtime claim.',
                projects=len(unique),counts=[dict(cpu=k[0],layout=k[1],count=v) for k,v in counts.items()],
                shifted_prefixes=[r for r in rows if r['payload_offset'] not in (None,54)],
                structured_text=[r for r in rows if r['layout']=='structured-text'],
                unsupported=[r for r in rows if r['layout']=='unsupported'],errors=errors,programs=rows)
    (P/'current-real-source-gaps-20260930.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='programs'},ensure_ascii=True))


if __name__=='__main__':main()
