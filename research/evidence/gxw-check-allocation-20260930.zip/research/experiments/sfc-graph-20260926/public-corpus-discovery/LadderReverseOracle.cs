// Offline, owned buffers only. Research ABI from FX2 15.31 exports 0x3752,
// 0x1f4f and method 0x76ee. No project, device or simulator interfaces.
using System;
using System.IO;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Web.Script.Serialization;
public static class LadderReverseOracle {
    [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
    static extern IntPtr LoadLibraryEx(string path, IntPtr file, uint flags);
    [DllImport("kernel32.dll", CharSet=CharSet.Ansi, ExactSpelling=true)]
    static extern IntPtr GetProcAddress(IntPtr module, string name);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate IntPtr CreateFn();
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int OpenFn(IntPtr h,int cpu,int mode);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int CloseFn(IntPtr h);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate void DeleteFn(IntPtr h);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int OffsetFn(IntPtr h,ref int value);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int ReverseFn(IntPtr h,
        int count,IntPtr descriptor,ref int size,IntPtr output,IntPtr errorCell,int mode);
    static T Export<T>(IntPtr m,string name) where T:class {
        IntPtr p=GetProcAddress(m,name);if(p==IntPtr.Zero)throw new Exception(name);
        return Marshal.GetDelegateForFunctionPointer(p,typeof(T)) as T;
    }
    sealed class Buffer:IDisposable {
        public IntPtr raw,pointer; public int size;
        public Buffer(int n) {
            size=n;raw=Marshal.AllocHGlobal(n+64);pointer=IntPtr.Add(raw,32);
            byte[] bytes=new byte[n+64];
            for(int i=0;i<32;i++){bytes[i]=0xa5;bytes[n+32+i]=0xa5;}
            Marshal.Copy(bytes,0,raw,bytes.Length);
        }
        public byte[] Bytes(){byte[] b=new byte[size];Marshal.Copy(pointer,b,0,size);return b;}
        public bool Intact(){for(int i=0;i<32;i++)if(Marshal.ReadByte(raw,i)!=0xa5||Marshal.ReadByte(raw,size+32+i)!=0xa5)return false;return true;}
        public void Dispose(){Marshal.FreeHGlobal(raw);}
    }
    public static int Main(string[] args) {
        if(IntPtr.Size!=4||args.Length!=2)return 2;
        IntPtr m=LoadLibraryEx(args[0],IntPtr.Zero,8);if(m==IntPtr.Zero)throw new Exception("LoadLibraryEx");
        var create=Export<CreateFn>(m,"ObjectNew");var open=Export<OpenFn>(m,"Open");
        var close=Export<CloseFn>(m,"Close");var delete=Export<DeleteFn>(m,"ObjectDelete");
        var reverse=Export<ReverseFn>(m,"ChangeLDToPcode");var offset=Export<OffsetFn>(m,"GetErrorOffset");
        var json=new JavaScriptSerializer();json.MaxJsonLength=16*1024*1024;
        string line;
        while((line=Console.ReadLine())!=null) {
            var q=json.Deserialize<Dictionary<string,object>>(line);
            int id=Convert.ToInt32(q["id"]),height=Convert.ToInt32(q["height"]);
            byte[] tb=Convert.FromBase64String((string)q["tokens_base64"]),cb=Convert.FromBase64String((string)q["cells_base64"]);
            if(height<1||height>24||cb.Length!=0x2288||tb.Length<1||tb.Length>65536)throw new Exception("Envelope");
            IntPtr h=create();if(h==IntPtr.Zero)throw new Exception("ObjectNew");
            try {
                if(open(h,521,0)!=0)throw new Exception("Open");
                using(var tokens=new Buffer(tb.Length))using(var cells=new Buffer(cb.Length))
                using(var descriptor=new Buffer(11))using(var output=new Buffer(131072))using(var errorCell=new Buffer(32)) {
                    Marshal.Copy(tb,0,tokens.pointer,tb.Length);Marshal.Copy(cb,0,cells.pointer,cb.Length);
                    Marshal.WriteByte(descriptor.pointer,0,23);Marshal.WriteByte(descriptor.pointer,1,(byte)height);
                    Marshal.WriteIntPtr(descriptor.pointer,2,tokens.pointer);Marshal.WriteByte(descriptor.pointer,6,8);
                    Marshal.WriteIntPtr(descriptor.pointer,7,cells.pointer);
                    int n=output.size;int rc=reverse(h,1,descriptor.pointer,ref n,output.pointer,errorCell.pointer,0);
                    int error=-1,er=rc==0?0:offset(h,ref error);
                    bool guards=tokens.Intact()&&cells.Intact()&&descriptor.Intact()&&output.Intact()&&errorCell.Intact();
                    bool pointers=Marshal.ReadIntPtr(descriptor.pointer,2)==tokens.pointer&&Marshal.ReadIntPtr(descriptor.pointer,7)==cells.pointer;
                    string stem=Path.Combine(args[1],id.ToString("D4"));
                    File.WriteAllBytes(stem+".output-buffer.bin",output.Bytes());
                    File.WriteAllBytes(stem+".tokens-after.bin",tokens.Bytes());
                    File.WriteAllBytes(stem+".cells-after.bin",cells.Bytes());
                    Console.WriteLine(json.Serialize(new {id=id,return_code="0x"+rc.ToString("X8"),output_size=n,
                        error_offset=rc==0||er!=0?(int?)null:error,error_cell=(int)(ushort)Marshal.ReadInt16(errorCell.pointer),guards_intact=guards,pointers_unchanged=pointers,
                        metadata=new int[]{Marshal.ReadByte(descriptor.pointer,0),Marshal.ReadByte(descriptor.pointer,1),Marshal.ReadByte(descriptor.pointer,6)}}));
                    Console.Out.Flush();if(!guards||!pointers)return 3;
                }
            } finally {close(h);delete(h);}
        }
        return 0;
    }
}
