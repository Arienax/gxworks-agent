"""Independent, raw-preserving Q machine reader for an explicit read context.

Boundaries port the inspected reverse scanner at 76F52. Ordinary instruction
decoding uses reverse tables/76029, 74A5E, 76796, 874C3 and 87232. This module
does not import the PCode parser, a forward model, a native helper, or observed
instruction outputs. The explicit context table can be a retained initialization
witness or be built by source_q_read_context from a project parameter record;
neither path derives addresses from instruction output pairs. Selecting the
matching project context remains the caller's responsibility; an unbound table
does not establish actual project allocation.
"""
from dataclasses import dataclass
import json
import struct


class Unsupported(ValueError):
    pass


@dataclass(frozen=True)
class ReadProfile:
    basic: bytes
    markers: bytes
    control: bytes
    devices: bytes
    literals: bytes = b''
    word_reverse: bytes = b''
    comparisons: bytes = b''
    applications: bytes = b''

    def __post_init__(self):
        if (len(self.basic), len(self.markers), len(self.control)) != (192, 192, 128):
            raise ValueError('Q reverse table extent differs')
        if not self.devices or len(self.devices) != 1 + (self.devices[0] + 1) * 4:
            raise ValueError('Device read table extent differs')
        for table, extent in ((self.literals, 36), (self.word_reverse, 324), (self.comparisons, 30), (self.applications, 4998)):
            if table and len(table) != extent:
                raise ValueError('Application reverse table extent differs')


def load_read_tables(static_path, device_table):
    static = json.loads(static_path.read_text(encoding='utf-8'))
    if static['file_version'] != '15.41' or static['adapter_cpu'] != 209 or static['versions'] != [25]:
        raise Unsupported('Uninspected Q compiler profile')
    t = static['tables']
    return ReadProfile(bytes.fromhex(t['basic_reverse']['raw_hex']),
                       bytes.fromhex(t['basic_start_flags']['raw_hex']),
                       bytes.fromhex(t['control_reverse']['raw_hex']),
                       bytes(device_table),
                       bytes.fromhex(t.get('literal_devices', {}).get('raw_hex', '')),
                       bytes.fromhex(t.get('word_reverse', {}).get('raw_hex', '')),
                       bytes.fromhex(t.get('comparison_reverse', {}).get('raw_hex', '')),
                       bytes.fromhex(t.get('application_reverse', {}).get('raw_hex', '')))


def load_profile(static_path, context_path):
    context = json.loads(context_path.read_text(encoding='utf-8'))
    if context['errors'] or not context['traced_baseline_exact'] or len(context['tables']) != 1:
        raise Unsupported('Device read context was not consistently observed')
    return load_read_tables(static_path, bytes.fromhex(context['tables'][0]))


def word_kind(word):
    high = (word >> 24) & 0x7F
    if high < 0x40:
        return 1
    if high >= 0x70:
        return 15
    if high < 0x5D:
        return 2
    if 0x60 <= high < 0x68:
        return 7
    if 0x6C <= high < 0x6E:
        return 12
    if high == 0x5F:
        sub = (word >> 21) & 7
        if sub < 2:
            return 5
        if sub < 4:
            return 6
        raise Unsupported('Unsupported 5F word subtype')
    return {0x5D:3, 0x5E:4, 0x68:8, 0x69:9, 0x6A:10, 0x6B:11, 0x6E:13, 0x6F:14}[high]


def _kind3_start(field, mode):
    return int(8 <= field <= 11 or field == 0x10 or
               (field == 0x11 and mode <= 1) or (field == 0x12 and mode == 0) or field >= 0x30)


def _start_flag(words, at, profile):
    word = words[at]
    kind = word_kind(word)
    if kind == 1:
        return profile.markers[3 * ((word >> 24) & 0x3F) + 1]
    if kind == 2:
        return int(((word >> 24) & 0x1F) == 0x15)
    if kind == 13:
        return int(((word >> 18) & 0x1F) == 0x15)
    if kind == 3:
        return _kind3_start((word >> 18) & 0x3F, (word >> 16) & 3)
    if kind == 4:
        if ((word >> 21) & 7) == 1 and ((word >> 16) & 15) == 0:
            return 0
        mask = word & 0x7FEF0000
        if mask in (0x5E050000, 0x5E000000, 0x5E010000):
            if at + 1 == len(words):
                raise Unsupported('Control lookahead is outside input')
            nxt = words[at + 1]
            if nxt & 0x7FFF0000 == 0x5D490000:
                return 0
            if mask == 0x5E050000 and nxt & 0x7FEF0000 in (0x5E000000, 0x5E010000):
                if at + 2 == len(words):
                    raise Unsupported('Nested control lookahead is outside input')
                if words[at + 2] & 0x7FFF0000 == 0x5D490000:
                    return 0
        return (word >> 20) & 1
    if 5 <= kind <= 11:
        return (word >> 20) & 1
    if kind == 12:
        mode, field = (word >> 23) & 3, (word >> 19) & 15
        if mode == 0:
            return profile.markers[3 * ((word >> 17) & 0x3F) + 1]
        return int(mode == 1 and 8 <= field <= 15)
    if kind == 14:
        mode, field = (word >> 22) & 3, (word >> 16) & 0x3F
        if mode == 0:
            return _kind3_start(field, (word >> 14) & 3)
        return int(mode == 1 and field in (8, 9))
    raise Unsupported('A prefix has no standalone instruction flag')


def _unit(words, at, profile):
    kind = word_kind(words[at])
    if kind == 15:
        if at + 1 == len(words):
            raise Unsupported('Missing word after extended prefix')
        kind = word_kind(words[at + 1])
        if kind not in (12, 13, 14):
            raise Unsupported('Uninspected prefix pair')
        return _start_flag(words, at + 1, profile), 2
    if kind in (12, 13, 14):
        raise Unsupported('Extended word is missing its prefix')
    return _start_flag(words, at, profile), 1


def _operand(device, number):
    if not 0 <= number < 2 ** 32:
        raise Unsupported('Decoded device number extent')
    width = max(1, (number.bit_length() + 7) // 8)
    length = width + 3
    return bytes((length, device)) + number.to_bytes(width, 'little') + bytes((length,))


def _mapped_device(address, bit, profile):
    table = profile.devices
    for i in range(table[0]):
        start, kind, device = struct.unpack_from('<HBB', table, 1 + 4 * i)
        end, = struct.unpack_from('<H', table, 5 + 4 * i)
        if start <= address < end:
            if kind == 1:
                return kind, device, (address - start) * 16 + bit
            if kind == 2:
                # 874C3 selects the coil device by adding two, unlike 87355.
                return kind, device + 2, (address - start) * 8 + (bit >> 1)
            if kind == 3:
                return kind, device, address - start
            raise Unsupported('Float device range needs another reverse branch')
    raise Unsupported('Address falls outside the explicit default read context')


def _ordinary_device(word, profile):
    if ((word >> 16) & 15) != 3:
        raise Unsupported('Device modifier needs another reverse branch')
    kind, device, number = _mapped_device(word & 0xFFFF, (word >> 20) & 15, profile)
    if kind not in (1, 2):
        raise Unsupported('Bit selection on a word device needs another reverse branch')
    return _operand(device, number)


def _word_device(word, profile):
    if ((word >> 16) & 15) != 3:
        raise Unsupported('Word device modifier needs another reverse branch')
    kind, device, number = _mapped_device(word & 0xFFFF, 0, profile)
    if kind != 3:
        raise Unsupported('Bit group in a word operation needs another reverse branch')
    return _operand(device, number)


def _literal_descriptor_pcode(word, profile):
    field, mode = (word >> 18) & 0x3F, (word >> 16) & 3
    if not profile.literals or not 0x14 <= field < 0x1D:
        raise Unsupported('Uninspected normalized literal descriptor')
    device = profile.literals[(field - 0x14) * 4 + mode]
    if device not in (0xE8, 0xE9, 0xEA, 0xEB):
        raise Unsupported('Literal descriptor requires another reverse branch')
    return _operand(device, word & 0xFFFF)


def _application_header(family, variant, command, words):
    # 77353 emits header shape from the command's mode, then 59E26 fills words.
    mode = (command >> 20) & 3 if word_kind(command) == 2 else (command >> 18) & 3
    if mode == 1:
        return bytes((5, family, words, variant, 5))
    extra = {0:0, 2:2, 3:5}[mode]
    return bytes((6, family, words, variant, extra, 6))


def _collect_simple_operands(words, profile):
    """Port bounded ordinary branches of 77CBA, preserving operand descriptors."""
    operands, at = [], 0
    while at < len(words):
        word, kind = words[at], word_kind(words[at])
        if kind == 2 and ((word >> 24) & 0x1F) in (0x14, 0x15):
            operands.append(dict(type='word', word=word, pcode=_word_device(word, profile)))
        elif kind == 1 and 0x18 <= ((word >> 24) & 0x3F) <= 0x1F:
            operands.append(dict(type='bit', word=word, pcode=_ordinary_device(word, profile)))
        elif kind == 3 and ((word >> 18) & 0x3F) <= 0x0B:
            mask = word & 0x7FFC0000
            if mask in (0x5D000000, 0x5D200000):
                descriptor = 0x5D510000 | (word & 0xFFFF)
            elif mask in (0x5D040000, 0x5D240000):
                descriptor = 0x5D500000 | (word & 0xFFFF)
            else:
                raise Unsupported('Multiword literal collection needs another reverse branch')
            operands.append(dict(type='literal', word=descriptor, pcode=_literal_descriptor_pcode(descriptor, profile)))
        else:
            break
        at += 1
    return operands, at


def _stack_instruction(words, profile):
    operands, at = _collect_simple_operands(words, profile)
    if at < len(words) and word_kind(words[at]) == 1 and (words[at] >> 24) & 0x3F == 0x2F:
        # 7646F advances from the timer coil to its value word, pushes the
        # existing parameter to slot one, then checks the closing coil word.
        if len(operands) != 1 or len(words) - at != 3:
            raise Unsupported('Timer output does not fit the ordinary reverse branch')
        value, final = words[at + 1:]
        value_selector = value & 0x7FF00000
        if value_selector in (0x5A000000, 0x5A200000, 0x5A900000):
            opcode = 0x21
        elif value_selector in (0x5A100000, 0x5A300000):
            opcode = 0x22
        else:
            raise Unsupported('Extended timer output value word')
        if word_kind(value) != 2 or word_kind(final) != 1 or (final >> 24) & 0x3F != 0x2E:
            raise Unsupported('Timer output closing sequence differs')
        return bytes((4, opcode, len(words), 4)) + _word_device(value, profile) + operands[0]['pcode']
    if at != len(words) - 1:
        raise Unsupported('Application operand collection does not reach a single final command')
    command, count = words[at], len(words)
    kind = word_kind(command)
    if kind == 1:
        opcode = (command >> 24) & 0x3F
        if opcode in (*range(4, 8), *range(12, 16), *range(20, 24)) and len(operands) == 1 and operands[0]['type'] == 'bit':
            return bytes((4, profile.markers[3 * opcode], count, 4)) + operands[0]['pcode']
        raise Unsupported('Complex basic command after operand collection')
    if kind == 2:
        if not profile.word_reverse:
            raise Unsupported('Word command reverse table is absent')
        opcode, mode = (command >> 24) & 0x1F, (command >> 22) & 3
        if opcode >= 0x1B:
            raise Unsupported('Word command opcode outside reverse table')
        row = (opcode * 4 + mode) * 3
        family, variant, _groups = profile.word_reverse[row:row + 3]
        destination = dict(type='word', word=command, pcode=_word_device(command, profile))
        if family == 0x4C and variant == 0 and len(operands) == 1:
            operands.append(destination)
        elif family == 0x49 and variant == 0 and len(operands) == 2:
            # 7555B compares descriptor address/type with the destination.
            same = operands[0]['type'] == 'word' and operands[0]['word'] & 0xFFFFF == command & 0xFFFFF
            if same:
                operands = [operands[1], operands[0]]  # 779A5 mode 20 swaps them.
            else:
                operands.append(destination)
                variant += 1
        else:
            raise Unsupported('Word application header branch is not yet ported')
        return _application_header(family, variant, command, count) + b''.join(o['pcode'] for o in operands)
    if kind == 8:
        if not profile.comparisons:
            raise Unsupported('Comparison reverse table is absent')
        operation, relation, data = (command >> 21) & 7, (command >> 15) & 7, (command >> 12) & 7
        if not (3 <= operation <= 5 and relation < 6 and data < 5):
            raise Unsupported('Comparison command selectors outside ordinary branch')
        variant = profile.comparisons[relation * 5 + data]
        if variant >= 6 or len(operands) != 2 or any(0x20 <= x <= 0x33 for x in ((command >> 6) & 0x3F, command & 0x3F)):
            raise Unsupported('Comparison needs extended operand collection')
        header = bytes((6, 0x40, count, variant, operation + 0x0D, 6))
        return header + b''.join(o['pcode'] for o in operands)
    raise Unsupported('Application final command family is not yet ported')


def _descriptor_token(word, profile):
    kind = word_kind(word)
    if kind == 1:
        return _ordinary_device(word, profile)
    if kind == 2:
        return _word_device(word, profile)
    if kind == 3:
        return _literal_descriptor_pcode(word, profile)
    raise Unsupported('Application parameter needs an extended descriptor')


def _direct_application(words, at, profile):
    command = words[at]
    if word_kind(command) != 5 or not profile.applications:
        raise Unsupported('Direct application table is absent or does not match')
    identifier = command & 0x7FF
    row = next((profile.applications[i:i + 7] for i in range(0, len(profile.applications), 7)
                if int.from_bytes(profile.applications[i:i + 2], 'little') == identifier), None)
    if row is None or row[2] == 0xFF:
        raise Unsupported('Application identifier has no supported table entry')
    family, variant, parameters, extra = row[2:6]
    if 0x30 <= identifier < 0xB0 and parameters == 0:
        if identifier == 0x7A:
            if len(words) - at != 2 or words[at + 1] & 0x7FFF0000 != 0x5D490000:
                raise Unsupported('END metadata word is not the inspected shape')
            return bytes((4, family, len(words), 4))
        if len(words) - at == 1 and at == 0:
            return bytes((3, family, 3))
        raise Unsupported('Zero-parameter application extent differs')
    # Ordinary 744B3 / 74520 -> 74163 branches; special families stay opaque.
    if not 0xB0 <= identifier < 0x430 or family in (0x40, 0x69, 0x6A) or (command >> 21) & 7 == 1:
        raise Unsupported('Direct application needs another header branch')
    if len(words) - at - 1 != parameters:
        raise Unsupported('Application parameter word extent differs')
    mode = (command >> 15) & 15
    if extra == 0x0A or (extra == 0xFE and mode != 2):
        header = bytes((5, family, len(words), variant, 5))
    else:
        header = bytes((6, family, len(words), variant, 2 if extra == 0xFE else extra, 6))
    return header + b''.join(_descriptor_token(w, profile) for w in words[at + 1:])


def _timer_reset(words, profile):
    # Ordinary 72610 -> 780E3 -> 7759A -> 761AF path. The command before
    # the two matching coil words is skipped by the native operand collector.
    if len(words) not in (2, 4) or word_kind(words[0]) != 8 or ((words[0] >> 21) & 7) != 1 or ((words[0] >> 12) & 0x3F) != 4:
        raise Unsupported('Timer reset prefix differs')
    if any(0x20 <= value <= 0x33 for value in ((words[0] >> 6) & 0x3F, words[0] & 0x3F)):
        raise Unsupported('Timer reset prefix has operand references')
    if len(words) == 2:
        # 776A3 recognizes a preceding 68204000 command and dispatches to
        # 75BE8, emitting RST of the current ordinary word destination.
        command = words[1]
        if words[0] & 0x7FE3F000 != 0x68204000 or (words[0] >> 6) & 0x3F or word_kind(command) != 2 or command & 0x7FC00000 != 0x56000000:
            raise Unsupported('Word reset command sequence differs')
        return bytes((4, 0x24, len(words), 4)) + _word_device(command, profile)
    first, second, value = words[1:]
    if any(word_kind(w) != 1 or ((w >> 24) & 0x3F) != 0x25 for w in (first, second)):
        raise Unsupported('Timer reset coil pair differs')
    if first & 0xFFFFF != second & 0xFFFFF or word_kind(value) != 2 or value & 0x7FC00000 != 0x56000000:
        raise Unsupported('Timer reset value sequence differs')
    return bytes((4, 0x24, len(words), 4)) + _word_device(value, profile)


def decode_record(raw, profile):
    if len(raw) != 4:
        words = list(struct.unpack('<' + 'I' * (len(raw) // 4), raw))
        if word_kind(words[0]) == 5:
            return _direct_application(words, 0, profile)
        if word_kind(words[0]) == 1 and profile.basic[3 * ((words[0] >> 24) & 0x3F) + 2] == 5 and word_kind(words[1]) == 5:
            return _direct_application(words, 1, profile)
        if word_kind(words[0]) == 8:
            return _timer_reset(words, profile)
        return _stack_instruction(words, profile)
    word, = struct.unpack('<I', raw)
    kind = word_kind(word)
    if kind == 1:
        opcode = (word >> 24) & 0x3F
        pcode_op, _flags, mode = profile.basic[3 * opcode:3 * opcode + 3]
        if mode == 3:
            return bytes((3, pcode_op, 3))
        if mode in (1, 2):
            return bytes((3, pcode_op, 3)) + _ordinary_device(word, profile)
        raise Unsupported('Complex basic instruction reverse branch')
    if kind == 4:
        a, c = (word >> 21) & 7, (word >> 16) & 15
        if a >= 4:
            raise Unsupported('Control selector outside reverse table')
        at = 2 * (a + 4 * c)
        op, auxiliary = profile.control[at:at + 2]
        if op == 0x14 or 0x18 <= op <= 0x1C:
            return bytes((3, op, 3))
        if op == 0x6A:
            return bytes((5, op, 1, auxiliary, 5))
        raise Unsupported('Unsupported control table entry')
    raise Unsupported('Instruction family semantic branch is not yet ported')


def read_machine(raw, profile):
    """Return ordered records and an unguessed opaque suffix on boundary failure."""
    words = list(struct.unpack('<' + 'I' * (len(raw) // 4), raw[:len(raw) // 4 * 4]))
    records, at = [], 0
    while at < len(words):
        start = at
        try:
            flag, width = _unit(words, at, profile)
            if flag != 1:
                raise Unsupported('First unit lacks a supported instruction start flag')
            at += width
            while at < len(words):
                flag, width = _unit(words, at, profile)
                if flag == 1:
                    break
                if flag != 0:
                    raise Unsupported('Unsupported instruction start flag')
                at += width
                if at - start > 180:
                    raise Unsupported('Record exceeds inspected scanner word envelope')
            chunk = raw[start * 4:at * 4]
            item = dict(offset=start * 4, raw_hex=chunk.hex(), word_count=at-start,
                        kinds=[word_kind(w) for w in words[start:at]],
                        parity_even=[w.bit_count() % 2 == 0 for w in words[start:at]],
                        boundary_handling='decoded')
            try:
                item.update(handling='decoded', pcode_hex=decode_record(chunk, profile).hex())
            except Unsupported as error:
                item.update(handling='opaque-preserved', reason=str(error))
            records.append(item)
        except Unsupported as error:
            records.append(dict(offset=start*4, raw_hex=raw[start*4:].hex(),
                                handling='opaque-preserved', boundary_handling='unsupported', reason=str(error)))
            at = len(words)
            break
    if len(raw) % 4 and (not records or records[-1]['boundary_handling'] != 'unsupported'):
        offset = len(words) * 4
        records.append(dict(offset=offset, raw_hex=raw[offset:].hex(), handling='opaque-preserved',
                            boundary_handling='unsupported', reason='Partial final DWORD'))
    if b''.join(bytes.fromhex(r['raw_hex']) for r in records) != raw:
        raise AssertionError('Raw reconstruction differs')
    return records
