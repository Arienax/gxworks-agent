"""Bounded ST contact mutation in an independently read Q machine body.

The address table must come from the same project's parameter record. Exactly
one ordinary kind-1 word and its parity bit change; every other raw word remains
untouched. A matching independent PCode prediction is required. This is a
research operation on a conversion input, not a project-cache or PLC writer.
"""
import struct
from source_q_machine_reader import read_machine


def patch_st_contact(machine, profile, *, record_index, before_number, after_number,
                     allocated_count, expected_pcode):
    if not 0<=before_number<allocated_count or not 0<=after_number<allocated_count:
        raise ValueError('ST contact outside the bound source allocation')
    if before_number==after_number:
        raise ValueError('Contact mutation has no effect')
    records=read_machine(machine,profile)
    if any(r['handling']!='decoded' for r in records):
        raise ValueError('Selected body has unresolved machine semantics')
    record=records[record_index]
    if record['kinds']!=[1] or record['word_count']!=1:
        raise ValueError('Selected contact is outside the ordinary single-word branch')
    rows=[struct.unpack_from('<HBB',profile.devices,1+4*i) for i in range(profile.devices[0])]
    start,kind,device=next(row for row in rows if row[2]==0xC6)
    if kind!=2:raise ValueError('ST contact table is not the inspected kind')
    old_word,=struct.unpack('<I',bytes.fromhex(record['raw_hex']))
    if ((old_word>>24)&0x7F) not in (0,1,8,9,16,17):
        raise ValueError('Selected word is not an ordinary load/AND/OR contact')
    if (old_word>>16)&0xF!=3 or (old_word&0xFFFF)!=start+(before_number>>3):
        raise ValueError('Existing ST contact address or subtype differs')
    old_bit=(old_word>>20)&15
    if old_bit>>1!=before_number&7:
        raise ValueError('Existing ST bit does not match the bound operand')
    bit=((after_number&7)<<1)|(old_bit&1)
    word=(old_word&~(0x80F0FFFF))|(bit<<20)|(start+(after_number>>3))
    word|=(word.bit_count()&1)<<31
    after=bytearray(machine)
    struct.pack_into('<I',after,record['offset'],word)
    result=bytes(after)
    decoded=read_machine(result,profile)
    if any(r['handling']!='decoded' for r in decoded):
        raise ValueError('Proposed machine body has an unresolved record')
    if b''.join(bytes.fromhex(r['pcode_hex']) for r in decoded)!=expected_pcode:
        raise ValueError('Independent machine mutation differs from source prediction')
    if len(records)!=len(decoded) or any(a['raw_hex']!=b['raw_hex'] for i,(a,b) in enumerate(zip(records,decoded)) if i!=record_index):
        raise ValueError('Machine mutation changed an unrelated record')
    return result,dict(record_index=record_index,machine_offset=record['offset'],
        before_word=old_word,after_word=word,before_number=before_number,after_number=after_number,
        raw_words_preserved=len(records)-1)
