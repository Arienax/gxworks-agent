"""Build the inspected Q03UDV read ranges from the raw 2000 parameter record.

The model ports the CPU-word 71 branch of 4876B, 57435 and 3FA51. It does not
consume initialized native tables or instruction conversion outputs. Division
into machine address units is a native read convention, not allocation validity.
Unmeasured banks, rows or wrapping addresses remain unsupported with raw input
available to the caller. The caller must bind the record to the correct project.
"""
from dataclasses import dataclass
import struct


class Unsupported(ValueError):
    pass


@dataclass(frozen=True)
class QReadContext:
    parameter_raw: bytes
    devices: bytes
    used_rows: tuple
    opaque_rows: tuple


VARIABLES = (0x9C, 0x9D, 0x90, 0x92, 0xA0, 0x93, 0xA1, 0x94, 0x98,
             0xC2, 0xC8, 0xC5, 0xA8, 0xB4, 0xB5)
BIT_DEVICES = frozenset(VARIABLES[:9])
FIXED_RANGES = ((0, 1, 0x9E), (0x40, 1, 0x9F), (0x80, 4, 0xAA),
                (0x180, 1, 0x91), (0x200, 3, 0xA9))


def build_read_context(raw, *, adapter_cpu=209, versions=(25,)):
    if adapter_cpu!=209 or tuple(versions)!=(25,):
        raise Unsupported('Uninspected project/compiler profile')
    raw = bytes(raw)
    if len(raw)<6:
        raise Unsupported('Truncated parameter record')
    length, tag, count = struct.unpack_from('<HHH', raw)
    if length!=len(raw) or tag!=0x2000 or len(raw)!=6+4*count or count>20:
        raise Unsupported('Outside inspected parameter record framing')
    values = dict.fromkeys(VARIABLES, 0)
    # 489BA/489C0 retain the X/Y defaults even in parameter-read mode.
    values[0x9C] = values[0x9D] = 0x2000
    used, opaque, seen = [], [], set()
    for offset in range(6, len(raw), 4):
        code, value = struct.unpack_from('<HH', raw, offset)
        low, bank = code & 0xFF, code>>8
        if code==0xCC and value==0xFFFF:
            # 498F6/4997D skip this original terminal device row. Its meaning
            # is not needed for the inspected address table; preserve it raw.
            opaque.append((offset, raw[offset:offset+4]))
            continue
        if low not in values or bank!=1:
            raise Unsupported('Unmeasured parameter row or bank')
        if low in seen:
            raise Unsupported('Duplicate parameter device row')
        seen.add(low)
        values[low] = value
        used.append((offset, code, value))
    units = {code:(value>>4 if code in BIT_DEVICES else value) for code,value in values.items()}
    ranges = list(FIXED_RANGES)
    next_address = 0xA00
    for code in VARIABLES[:9]:
        amount = units[code]
        if amount:
            ranges.append((next_address, 1, code))
            next_address += amount
    for value_code, contact in ((0xC2, 0xC0), (0xC8, 0xC6), (0xC5, 0xC3)):
        amount = units[value_code]>>3
        if amount:
            ranges.append((next_address, 2, contact))
            next_address += amount
    for code in (0xC2, 0xC8, 0xC5, 0xA8, 0xB4, 0xB5):
        amount = units[code]
        if amount:
            ranges.append((next_address, 3, code))
            next_address += amount
    if next_address>=0xFFFF or any(a>=b for (a,_,_), (b,_,_) in zip(ranges, ranges[1:])):
        raise Unsupported('Wrapping or overlapping read address ranges')
    table = bytes((len(ranges),))+b''.join(struct.pack('<HBB', *row) for row in ranges)+b'\xff'*4
    return QReadContext(raw, table, tuple(used), tuple(opaque))
