"""Read original Q bodies with address ranges derived from each source project.

Raw Param.wpa/2000 records are framed from GXW before native conversion. Their
range tables come only from the independent static-derived context model. Fresh
forward conversion supplies machine inputs; fresh reverse compares predicted
PCode. This does not establish freshness of saved machine caches or acceptance
of whole-project edits.
"""
from pathlib import Path
from collections import Counter
import base64
import json
import os
import subprocess
import sys

P=Path(__file__).resolve().parent
ROOT=P.parents[3]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.container import CompoundFile
from gxw.project_resolver import GXWProjectResolver
from gxw.project_metadata import read_project_text_context
from probe_gxw_parameters import device_allocation_record
from source_q_read_context import build_read_context
from source_q_machine_reader import load_read_tables,read_machine


def save(path,value):
    path.write_text(json.dumps(value,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')


def complete(row,size):
    return row['code']==0 and row['remaining']==0 and row['consumed']==size and row['input_unchanged'] and row['guards_intact']


def main():
    output=P/'q-machine-project-bound-corpus-20261001-v1'
    output.mkdir()
    original=json.loads((P/'q-machine-original-corpus-20261001-v1/before-forward.json').read_text())
    for name in ('source_q_machine_reader.py','source_q_read_context.py','QMachineOracle.cs',Path(__file__).name):
        (output/name).write_bytes((P/name).read_bytes())
    static=output/'static-read-tables.json'
    static.write_bytes((P/'q-machine-static-read-tables-20261001-v3.json').read_bytes())
    projects={}
    for directory in sorted({Path(r['source']).parent for r in original['programs']}):
        resolver=GXWProjectResolver(CompoundFile((directory/'input.gxw').read_bytes()))
        files=resolver.logical_files()
        project,=[f for f in files if f.logical_name.lower().endswith('.prj')]
        context=read_project_text_context(resolver.hdb.read_stream(project.stream_name))
        if context['cpu']!='Q03UDV':raise ValueError('Uninspected project CPU')
        parameter,=[f for f in files if f.logical_name=='Param.wpa']
        record=device_allocation_record(resolver.hdb.read_stream(parameter.stream_name))
        built=build_read_context(record.raw)
        projects[directory.name]=dict(parameter_hex=record.raw.hex(),device_table_hex=built.devices.hex(),
            stream=parameter.stream_name,record_offset=record.offset,plc=context['cpu'],
            profile=load_read_tables(static,built.devices))
    requests,bodies,pairs=[],[],{}
    for program in original['programs']:
        if 'records' not in program:continue
        case=Path(program['source']).parent.name
        parameter=projects[case]['parameter_hex']
        ids=[]
        for ref in program['records']:
            source=original['requests'][ref['id']]
            key=(source['raw_hex'],parameter)
            if key not in pairs:
                i=len(requests);pairs[key]=i
                requests.append(dict(id=i,original_pcode_hex=key[0],parameter_hex=parameter,
                    mnemonic=source['mnemonic'],first_case=case,original_unique_id=ref['id']))
            ids.append(pairs[key])
        raw=Path(program['source']).read_bytes()
        if b''.join(bytes.fromhex(requests[i]['original_pcode_hex']) for i in ids)!=raw:
            raise ValueError('Source body framing differs')
        bodies.append(dict(id=100000+len(bodies),case=case,source=program['source'],parameter_hex=parameter,
                           instruction_ids=ids,original_pcode_hex=raw.hex()))
    save(output/'before-forward.json',dict(scope=__doc__,projects={k:{f:v for f,v in row.items() if f!='profile'} for k,row in projects.items()},
                                           requests=requests,bodies=bodies))
    executable=output/'QMachineOracle.exe'
    built=subprocess.run([str(Path(os.environ['WINDIR'])/'Microsoft.NET/Framework/v4.0.30319/csc.exe'),'/nologo','/platform:x86',
                          '/out:'+str(executable),str(output/'QMachineOracle.cs')],capture_output=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
    (output/'build.txt').write_bytes(built.stdout+built.stderr)
    if built.returncode:raise RuntimeError('Owned helper build failed; retained')
    def run(mode,rows,name):
        directory=output/name;directory.mkdir()
        request=directory/'requests.tsv'
        request.write_text('\n'.join(str(i)+'\t'+base64.b64encode(raw).decode()+'\t'+base64.b64encode(parameter).decode()
                                    for i,raw,parameter in rows)+'\n',encoding='ascii')
        process=subprocess.run([str(executable),'D:/GXWORKS2/Easysocket/CodeGenerator/ECCodeGenerator2.dll',mode,
                                str(request),str(directory/'output.jsonl')],capture_output=True,timeout=45,creationflags=subprocess.CREATE_NO_WINDOW)
        (directory/'stdout.bin').write_bytes(process.stdout);(directory/'stderr.bin').write_bytes(process.stderr)
        save(directory/'process.json',dict(returncode=process.returncode))
        if process.returncode:raise RuntimeError('Owned native conversion failed; retained')
        result={r['id']:r for r in (json.loads(line) for line in (directory/'output.jsonl').read_text(encoding='utf-8-sig').splitlines())}
        if len(result)!=len(rows):raise ValueError('Native result identifiers differ')
        print(json.dumps(dict(stage=name,requests=len(rows),accepted=sum(r['code']==0 for r in result.values()))),flush=True)
        return result
    forward=run('forward',[(r['id'],bytes.fromhex(r['original_pcode_hex']),bytes.fromhex(r['parameter_hex'])) for r in requests],'forward')
    for row in requests:
        f=forward[row['id']]
        if complete(f,len(row['original_pcode_hex'])//2):
            machine=base64.b64decode(f['output_base64'])
            row.update(machine_hex=machine.hex(),prediction=read_machine(machine,projects[row['first_case']]['profile']))
        else:row['forward_refusal']=f
    for row in bodies:
        if all('machine_hex' in requests[i] for i in row['instruction_ids']):
            machine=b''.join(bytes.fromhex(requests[i]['machine_hex']) for i in row['instruction_ids'])
            row.update(machine_hex=machine.hex(),prediction=read_machine(machine,projects[row['case']]['profile']))
    save(output/'before-reverse.json',dict(scope=__doc__,projects={k:{f:v for f,v in row.items() if f!='profile'} for k,row in projects.items()},
                                           requests=requests,bodies=bodies))
    reverse=run('reverse',[(r['id'],bytes.fromhex(r['machine_hex']),bytes.fromhex(r['parameter_hex'])) for r in requests+bodies
                           if 'machine_hex' in r],'reverse')
    comparisons,counts,weighted=[],Counter(),Counter()
    for row in requests+bodies:
        parts=row.get('prediction',[])
        decoded=bool(parts) and all(r['handling']=='decoded' for r in parts)
        raw=b''.join(bytes.fromhex(r['pcode_hex']) for r in parts) if decoded else None
        n=reverse.get(row['id'])
        full=n is not None and complete(n,len(row.get('machine_hex',''))//2)
        compare=dict(id=row['id'],decoded=decoded,native_input_complete=full,
            native_exact=decoded and full and raw==base64.b64decode(n['output_base64']),
            source_exact=decoded and raw.hex()==row['original_pcode_hex'],
            raw_preserved=b''.join(bytes.fromhex(r['raw_hex']) for r in parts).hex()==row.get('machine_hex'))
        comparisons.append(compare)
        group='isolated_' if row['id']<100000 else 'full_bodies_'
        for key in ('decoded','native_input_complete','native_exact','source_exact','raw_preserved'):
            counts[group+key]+=compare[key]
        counts[group+'inputs']+='machine_hex' in row
    by_id={r['id']:r for r in comparisons}
    for body in bodies:
        for identifier in body['instruction_ids']:
            weighted['original_instructions']+=1
            weighted['decoded_native_source_exact']+=all(by_id[identifier][key] for key in ('decoded','native_exact','source_exact'))
    failures=[dict(input=row,comparison=by_id[row['id']]) for row in requests+bodies if by_id[row['id']]['decoded'] and
              not all(by_id[row['id']][key] for key in ('native_input_complete','native_exact','source_exact','raw_preserved'))]
    save(output/'comparison.json',comparisons);save(output/'failures.json',failures)
    result=dict(scope=__doc__,projects_bound=len(projects),parameter_profiles=len({r['parameter_hex'] for r in projects.values()}),
                counts=dict(counts),weighted=dict(weighted),independent_mismatches=len(failures),
                native_inputs_unchanged=all(r['input_unchanged'] and r['guards_intact'] for group in (forward,reverse) for r in group.values()))
    save(output/'summary.json',result)
    print(json.dumps(result,ensure_ascii=True),flush=True)
    if failures:raise ValueError('Independent project-bound reader differs; retained')


if __name__=='__main__':main()
