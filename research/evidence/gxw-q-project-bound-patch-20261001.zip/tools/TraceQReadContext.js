'use strict';
function bytes(address,size) {
    return Array.from(new Uint8Array(address.readByteArray(size))).map(b=>b.toString(16).padStart(2,'0')).join('');
}
Process.attachModuleObserver({
    onAdded(module) {
        if(module.name.toLowerCase()!=='eccodegenerator2.dll')return;
        if(bytes(module.base.add(0x3fa51),5)!=='558d6c2490')throw new Error('Uninspected read-context builder');
        let active=null,serial=0;
        Interceptor.attach(module.base.add(0x5a36),{
            onEnter(args) {
                if(active!==null)throw new Error('Unexpected nested reverse call');
                const pointer=args[2];
                if(pointer.isNull())throw new Error('This probe requires an explicit project parameter record');
                const count=pointer.add(4).readU16();
                if(count>20)throw new Error('Outside inspected parameter count');
                active={serial:serial++,parameter_hex:bytes(pointer,6+4*count)};
            },
            onLeave(){active=null;}
        });
        Interceptor.attach(module.base.add(0x3fa51),{
            onEnter(args){this.table=args[1];this.sourceConfig=args[0];},
            onLeave(){
                const count=this.table.readU8();
                if(active===null||count>96)throw new Error('Unexpected context observation');
                send({event:'Q-parameter-read-context',serial:active.serial,parameter_hex:active.parameter_hex,
                    count,table_hex:bytes(this.table,1+4*(count+1)),config_hex:bytes(this.sourceConfig,0x380),
                    internal_cpu_word:module.base.add(0x16d12c).readU16()});
            }
        });
    }
});
