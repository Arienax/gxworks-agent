"""One-byte ST source edits with complete source and independent machine witnesses.

Five original Q03UDV projects retain all unrelated input streams and their stale
code caches. Predictions are saved before memory-only native controls or fresh
owned compiler/check/save/reopen work. Native failures remain separate outcomes.
Legacy source models' historical annotations are discarded; no digest check is
added. Full machine predictions reuse the retained baseline raw words and the
static-derived project read context, changing only the selected contact word.
"""
from pathlib import Path
import base64
import json
import os
import struct
import subprocess
import sys

P=Path(__file__).resolve().parent
ROOT=P.parents[3]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.container import CompoundFile
from gxw.container_writer import replace_stream_within_allocation
from gxw.project_resolver import GXWProjectResolver
from gxw.project_metadata import read_project_text_context
from gxw.token_listing import decode_token_listing
from gxw.token_pou import frame_token_pou
from probe_gxw_parameters import device_allocation_record
from source_q_direct_projection import project_projection
from source_q_allocation import groups
from source_q_read_context import build_read_context
from source_q_machine_reader import load_read_tables,read_machine
from source_q_contact_patch import patch_st_contact
from probe_fx1s_lossless_project_patch import native_run
from probe_fx1s_project_patch_controls import reports

CASES=('case-16','case-18','case-23','case-30','case-31')
OUTPUT=P/'q-lossless-project-patch-20261001-v1'


def save(path,value):
    path.write_text(json.dumps(value,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')


def prepare():
    OUTPUT.mkdir()
    for name in (Path(__file__).name,'source_q_contact_patch.py','source_q_machine_reader.py','source_q_read_context.py','QMachineOracle.cs'):
        (OUTPUT/name).write_bytes((P/name).read_bytes())
    bound=json.loads((P/'q-machine-project-bound-corpus-20261001-v1/before-reverse.json').read_text())
    controls=[]
    for case in CASES:
        directory=OUTPUT/case;directory.mkdir()
        baseline=P/'noeul-native-batch'/case
        raw=(baseline/'input.gxw').read_bytes()
        resolver=GXWProjectResolver(CompoundFile(raw))
        metadata=next(resolver.hdb.read_stream(f.stream_name) for f in resolver.logical_files() if f.logical_name.endswith('.prj'))
        context=read_project_text_context(metadata)
        parameter=device_allocation_record(resolver.read_logical_file('Param.wpa')).raw
        read_context=build_read_context(parameter)
        profile=load_read_tables(P/'q-machine-static-read-tables-20261001-v3.json',read_context.devices)
        choices=[]
        for file in resolver.logical_files():
            if not file.logical_name.endswith('.Program.pou'):continue
            source=resolver.hdb.read_stream(file.stream_name)
            listing=decode_token_listing(source,profile='q03udv',text_encoding=context['text_encoding'])
            for index,instruction in enumerate(listing.instructions):
                if instruction.mnemonic!='AND' or len(instruction.operands)!=1 or not instruction.args[0].startswith('ST'):continue
                operand=instruction.operands[0]
                if len(operand.tokens)!=1 or operand.tokens[0].raw[1]!=0xC8:continue
                choices.append((file,source,listing,index,operand.tokens[0]))
        if not choices:raise ValueError('No bound plain ST contact in this original')
        file,source,listing,source_index,token=choices[0]
        number=int.from_bytes(token.raw[2:-1],'little')
        if number>=254:raise ValueError('Source proposal exceeds the same-width control')
        new_token=token.raw[:2]+(number+1).to_bytes(len(token.raw)-3,'little')+token.raw[-1:]
        new_source=source[:token.offset]+new_token+source[token.offset+len(token.raw):]
        new_listing=decode_token_listing(new_source,profile='q03udv',text_encoding=context['text_encoding'])
        if listing.gaps or new_listing.gaps or len(listing.instructions)!=len(new_listing.instructions):
            raise ValueError('Source lexical boundary changed')
        diffs=[i for i,(a,b) in enumerate(zip(listing.instructions,new_listing.instructions,strict=True)) if a!=b]
        if diffs!=[source_index]:raise ValueError('Source mutation changed an unrelated instruction')
        inner=replace_stream_within_allocation(resolver.outer.read_stream('_hdb'),file.stream_name,new_source)
        candidate=replace_stream_within_allocation(raw,'_hdb',inner)
        after=GXWProjectResolver(CompoundFile(candidate))
        unchanged_inner=[e.name for e in resolver.hdb.iter_streams() if e.name!=file.stream_name]
        unchanged_outer=[e.name for e in resolver.outer.iter_streams() if e.name!='_hdb']
        if any(resolver.hdb.read_stream(n)!=after.hdb.read_stream(n) for n in unchanged_inner):raise ValueError('Unrelated input inner stream changed')
        if any(resolver.outer.read_stream(n)!=after.outer.read_stream(n) for n in unchanged_outer):raise ValueError('Unrelated input outer stream changed')
        physical=[i for i,(a,b) in enumerate(zip(raw,candidate,strict=True)) if a!=b]
        if len(physical)!=1:raise ValueError('Source proposal is not a one-byte physical change')
        original_projection=project_projection(raw);proposed_projection=project_projection(candidate)
        resources=[];changed_records=0
        for a,b in zip(original_projection,proposed_projection,strict=True):
            index=a['resource_index']
            if a['resource']!=b['resource'] or a['output']!=(baseline/f'pcode-{index}-0.bin').read_bytes():
                raise ValueError('Source-only baseline differs from retained native compiler output')
            original_groups=[b''.join(g) for g in groups(a['output'])]
            proposed_groups=[b''.join(g) for g in groups(b['output'])]
            if len(original_groups)!=len(proposed_groups):raise ValueError('Compiled instruction count changed')
            differences=[i for i,(x,y) in enumerate(zip(original_groups,proposed_groups,strict=True)) if x!=y]
            witnesses=[r for r in bound['bodies'] if r['parameter_hex']==parameter.hex() and r['original_pcode_hex']==a['output'].hex()]
            machines={r['machine_hex'] for r in witnesses}
            if len(machines)!=1:raise ValueError('Baseline machine body is not uniquely bound by raw PCode and parameters')
            original_machine=bytes.fromhex(machines.pop())
            read=read_machine(original_machine,profile)
            if [bytes.fromhex(r['pcode_hex']) for r in read]!=original_groups:
                raise ValueError('Independent machine boundary partition differs from full source prediction')
            proposed_machine=original_machine;machine_patch=None
            if differences:
                if len(differences)!=1:raise ValueError('Source edit affects several compiled instructions')
                allocated_count=next(struct.unpack_from('<H',parameter,offset+2)[0] for offset in range(6,len(parameter),4)
                                     if struct.unpack_from('<H',parameter,offset)[0]==0x1C8)
                proposed_machine,machine_patch=patch_st_contact(original_machine,profile,record_index=differences[0],
                    before_number=number,after_number=number+1,allocated_count=allocated_count,expected_pcode=b['output'])
                changed_records+=1
            for label,value in (('original-pcode',a['output']),('expected-pcode',b['output']),
                                ('original-machine',original_machine),('expected-machine',proposed_machine)):
                (directory/f'{label}-{index}.bin').write_bytes(value)
            resources.append(dict(index=index,name=a['resource'],program=a['program'],bytes=len(b['output']),
                original_instructions=len(original_groups),changed_records=differences,machine_patch=machine_patch))
            for stage,pcode in (('original',a['output']),('candidate',b['output'])):
                controls.append(dict(id=len(controls),case=case,stage=stage,resource_index=index,pcode_hex=pcode.hex(),parameter_hex=parameter.hex()))
        if changed_records!=1:raise ValueError('Proposal does not affect exactly one complete resource instruction')
        (directory/'original.gxw').write_bytes(raw);(directory/'candidate.gxw').write_bytes(candidate)
        (directory/'expected-source-body.bin').write_bytes(frame_token_pou(new_source).body)
        (directory/'project-parameters.bin').write_bytes(parameter)
        save(directory/'proposal-before-native.json',dict(case=case,logical=file.logical_name,stream=file.stream_name,
            chosen=dict(source_instruction=source_index,source_token_offset=token.offset,before='ST'+str(number),after='ST'+str(number+1)),
            source_token_hex=token.raw.hex(),proposed_token_hex=new_token.hex(),physical_changed_offsets=physical,
            input_length_unchanged=True,unchanged_inner_streams=len(unchanged_inner),unchanged_outer_streams=len(unchanged_outer),
            unrelated_input_payloads_exact=True,resources=resources,parameter_hex=parameter.hex(),
            scope='Complete source predictions precede fresh compiler operations. Original opaque caches and all unrelated input streams remain unchanged.'))
    save(OUTPUT/'before-native-machine.json',dict(scope=__doc__,controls=controls))
    executable=OUTPUT/'QMachineOracle.exe'
    built=subprocess.run([str(Path(os.environ['WINDIR'])/'Microsoft.NET/Framework/v4.0.30319/csc.exe'),'/nologo','/platform:x86',
                          '/out:'+str(executable),str(OUTPUT/'QMachineOracle.cs')],capture_output=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
    (OUTPUT/'build.txt').write_bytes(built.stdout+built.stderr)
    if built.returncode:raise RuntimeError('Owned memory helper build failed')
    request=OUTPUT/'requests.tsv'
    request.write_text('\n'.join(str(r['id'])+'\t'+base64.b64encode(bytes.fromhex(r['pcode_hex'])).decode()+'\t'+
        base64.b64encode(bytes.fromhex(r['parameter_hex'])).decode() for r in controls)+'\n',encoding='ascii')
    process=subprocess.run([str(executable),'D:/GXWORKS2/Easysocket/CodeGenerator/ECCodeGenerator2.dll','forward',
                            str(request),str(OUTPUT/'output.jsonl')],capture_output=True,timeout=45,creationflags=subprocess.CREATE_NO_WINDOW)
    (OUTPUT/'stdout.bin').write_bytes(process.stdout);(OUTPUT/'stderr.bin').write_bytes(process.stderr)
    if process.returncode:raise RuntimeError('Owned machine conversion failed; retained')
    native=[json.loads(line) for line in (OUTPUT/'output.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    comparisons=[]
    for row,result in zip(controls,native,strict=True):
        label='original-machine' if row['stage']=='original' else 'expected-machine'
        expected=(OUTPUT/row['case']/f'{label}-{row["resource_index"]}.bin').read_bytes()
        comparisons.append(dict(id=row['id'],case=row['case'],stage=row['stage'],resource_index=row['resource_index'],
            native_complete=result['code']==0 and result['consumed']==len(row['pcode_hex'])//2 and result['remaining']==0,
            machine_exact=base64.b64decode(result['output_base64'])==expected,
            input_unchanged=result['input_unchanged'] and result['guards_intact']))
    save(OUTPUT/'memory-comparison.json',comparisons)
    print(json.dumps(dict(prepared_cases=len(CASES),machine_controls=len(comparisons),machine_exact=sum(r['machine_exact'] for r in comparisons))),flush=True)


def native_case(case):
    if case not in CASES:raise ValueError('Unbound original case')
    directory=OUTPUT/case
    proposal=json.loads((directory/'proposal-before-native.json').read_text())
    plan=json.loads((P/'noeul-native-batch'/case/'plan.json').read_text())
    control=directory/'native-control'
    baseline=native_run(directory/'original.gxw',control,plan,compile=True,export=True,check=True,alias='QPATCH')
    native=directory/'native-patch'
    changed=native_run(directory/'candidate.gxw',native,plan,compile=True,export=True,check=True,alias='QPATCH')
    row=dict(case=case,control=baseline,patch=changed,control_reports=reports(control),patch_reports=reports(native))
    row['program_check_diagnostics_unchanged']=(row['control_reports']==row['patch_reports']
        if baseline['program_check'] and changed['program_check'] else None)
    if row['program_check_diagnostics_unchanged'] is None:
        row['diagnostics_comparison_status']='not-checkable: public checks did not both complete'
    row['resources']=[]
    for resource in proposal['resources']:
        index=resource['index']
        original=(directory/f'original-pcode-{index}.bin').read_bytes();expected=(directory/f'expected-pcode-{index}.bin').read_bytes()
        row['resources'].append(dict(index=index,name=resource['name'],
            control_pcode_exact=(control/f'pcode-{index}-0.bin').exists() and (control/f'pcode-{index}-0.bin').read_bytes()==original,
            patch_pcode_exact=(native/f'pcode-{index}-0.bin').exists() and (native/f'pcode-{index}-0.bin').read_bytes()==expected))
    saved=native/'native-saved.gxw'
    if saved.exists():
        resolver=GXWProjectResolver(CompoundFile(saved.read_bytes()))
        row['saved_source_body_exact']=frame_token_pou(resolver.read_logical_file(proposal['logical'])).body==(directory/'expected-source-body.bin').read_bytes()
        row['saved_source_predictions_exact']=all(r['output']==(directory/f'expected-pcode-{r["resource_index"]}.bin').read_bytes()
                                                 for r in project_projection(saved.read_bytes()))
        reopen=directory/'native-reopen'
        row['reopen']=native_run(saved,reopen,plan,compile=True,export=False,check=True,alias='QPATCH')
        for resource in row['resources']:
            index=resource['index'];path=reopen/f'pcode-{index}-0.bin'
            resource['reopen_pcode_exact']=path.exists() and path.read_bytes()==(directory/f'expected-pcode-{index}.bin').read_bytes()
        row['reopen_reports']=reports(reopen)
        row['reopen_diagnostics_unchanged']=row['reopen_reports']==row['patch_reports']
    save(directory/'comparison.json',row)
    compact={k:v for k,v in row.items() if k not in ('control_reports','patch_reports','reopen_reports')}
    print(json.dumps(compact,ensure_ascii=True),flush=True)


if __name__=='__main__':
    if len(sys.argv)!=2:raise ValueError('Choose prepare or a bound case')
    if sys.argv[1]=='prepare':prepare()
    else:native_case(sys.argv[1])
