"""Observe Q patch checks without conflating projection failure with acceptance.

Inputs and whole-body source/machine predictions precede native work in the
lossless-project-patch experiment. Read-only diagnostics observe only a freshly
spawned owned helper. Separate compile/save/reopen runs retain the check outcome
and establish persistence only, never program-check acceptance.
"""
from pathlib import Path
import json
import sys

P = Path(__file__).resolve().parent
ROOT = P.parents[3]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'research')]
from gxw.container import CompoundFile
from gxw.project_resolver import GXWProjectResolver
from gxw.project_metadata import read_project_text_context
from gxw.token_pou import frame_token_pou
from source_q_direct_projection import project_projection
from probe_fx_operand_rules import traced_run
from probe_fx1s_lossless_project_patch import native_run
from probe_gxw_program_check_resources import SCRIPT as IEC_SCRIPT

PRIOR = P/'q-lossless-project-patch-20261001-v1'
OUTPUT = P/'q-lossless-project-patch-check-save-20261001-v3'
CASES = ('case-16', 'case-18', 'case-23', 'case-30', 'case-31')
# Compiler 1.635.0.1 GetProgress 0x73e5 uses self/percent/count/reports/code
# at stack arguments 0..4 and advances report pointers by 0x44 at 0x75f7.
# Its relative call prefix is inspected statically and checked in the process.
OLD_TARGET = "supported=!!location.module&&location.module.toLowerCase()==='dzdataabs_compiler_iec.dll'&&location.rva==='0x700b';"
NEW_TARGET = "supported=!!location.module&&((location.module.toLowerCase()==='dzdataabs_compiler_iec.dll'&&location.rva==='0x700b')||(location.module.toLowerCase()==='dzdataabs_compiler.dll'&&location.rva==='0x73e5'&&hex(target.add(5),5)==='e8516b0000'));"
if IEC_SCRIPT.count(OLD_TARGET) != 1:
    raise ValueError('Inspected shared observer target definition differs')
SCRIPT = IEC_SCRIPT.replace(OLD_TARGET, NEW_TARGET)


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=True, indent=2)+'\n', encoding='utf-8')


def inspect_trace(directory, source, proposal, label):
    events = [json.loads(line) for line in (directory/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    packets = [json.loads(line) for line in (directory/'events.jsonl').read_text(encoding='utf-8').splitlines()]
    errors = [p for p in packets if p.get('type') == 'error' or p.get('payload', {}).get('event') == 'observation-error']
    trace = [p['payload'] for p in packets if p.get('type') == 'send']
    resolver = GXWProjectResolver(CompoundFile(source.read_bytes()))
    metadata = next(resolver.hdb.read_stream(f.stream_name) for f in resolver.logical_files() if f.logical_name.endswith('.prj'))
    encoding = read_project_text_context(metadata)['text_encoding']
    names = {tuple(e['id']): e['name'] for e in events if e.get('operation') == 'NativeObject'}
    generated = {e['name']: e['index'] for e in events if e.get('operation') == 'Resource'}
    def diagnostic(row):
        result = {k: v for k, v in row.items() if k != 'raw_hex'}
        for field in ('library', 'name', 'instance'):
            raw = row[field+'_hex']
            result[field] = None if raw is None else bytes.fromhex(raw).decode(encoding, errors='backslashreplace')
        result['arguments'] = [None if raw is None else bytes.fromhex(raw).decode(encoding, errors='backslashreplace')
                               for raw in row['arguments_hex']]
        return result
    starts = [r for r in trace if r.get('event') == 'check-start']
    progress = [r for r in trace if r.get('event') == 'backend-check-progress']
    completed = {r['check_index'] for r in progress if r['hresult'] >= 0 and r['code'] == 0 and r['percent'] == 100}
    diagnostics = {}
    for row in progress:
        for report in row['reports']:
            if report['kind'] not in (2, 3):
                continue
            item = dict(diagnostic(report), check_index=row['check_index'], target=names.get(tuple(row['target'])))
            diagnostics[json.dumps(item, sort_keys=True)] = item
    diagnostics = [diagnostics[k] for k in sorted(diagnostics)]
    reads = []
    for row in trace:
        if row.get('event') != 'workspace-pcode-read' or row['phase'] != 'check':
            continue
        name = names.get(tuple(row['target']))
        index = generated.get(name)
        logical = next((r['name'] for r in proposal['resources'] if r['index'] == index), None)
        for channel, buffer in enumerate(row['buffers']):
            if buffer['raw_hex'] is None:
                continue
            raw = bytes.fromhex(buffer['raw_hex'])
            (directory/f'checked-read-{row["serial"]}-{channel}.bin').write_bytes(raw)
            actual = None if index is None else directory/f'pcode-{index}-{channel}.bin'
            reads.append(dict(serial=row['serial'], check_index=row['check_index'], native_resource=name, resource=logical, channel=channel,
                bytes=len(raw), matches_current=actual is not None and actual.exists() and raw == actual.read_bytes()))
    resources = []
    for resource in proposal['resources']:
        index = resource['index']
        actual = directory/f'pcode-{index}-0.bin'
        expected = PRIOR/proposal['case']/f'{label}-pcode-{index}.bin'
        resources.append(dict(index=index, name=resource['name'], bytes=resource['bytes'],
            compiler_pcode_exact=actual.exists() and actual.read_bytes() == expected.read_bytes(),
            checked_current_pcode=any(r['resource'] == resource['name'] and r['channel'] == 0 and r['matches_current'] for r in reads)))
    public = next((e for e in events if e.get('operation') == 'ProgramCheckCompleted'), None)
    observers = [r for r in trace if r.get('event') == 'backend-diagnostic-observer']
    backend_complete = bool(starts) and len(starts) == len(resources) and {r['check_index'] for r in starts} <= completed
    result = dict(input_copy_unchanged=(directory/'input.gxw').read_bytes() == source.read_bytes(),
        compile_completed=any(e.get('operation') == 'Progress' and e.get('percent') == 100 for e in events),
        project_owned_compiler=any(e.get('operation') == 'Workspace.GetProjectCompiler' and e.get('code') == 0 for e in events),
        compiler_rejected=any(r.get('kind') == 2 for e in events if e.get('operation') == 'Progress' for r in e.get('reports', [])),
        public_check=public, public_check_complete=public is not None,
        public_diagnostics=sorted({json.dumps({k:v for k,v in report.items() if k != 'raw_base64'},sort_keys=True)
            for event in events if event.get('operation') == 'ProgramCheckProgress'
            for report in event.get('reports',[]) if report['kind'] in (2,3)}),
        check_starts=len(starts), expected_targets=len(resources), backend_complete=backend_complete,
        backend_completed_indices=sorted(completed), backend_rejected=True if any(d['kind'] == 2 for d in diagnostics)
            else False if backend_complete and observers and all(o['supported'] for o in observers) and not errors else None,
        backend_diagnostics=diagnostics,
        projection_failures=[dict(check_index=r['check_index'], hresult=r['hresult'], code=r['code'], report=diagnostic(r['report']))
            for r in trace if r.get('event') == 'diagnostic-projection-failure'],
        observers=observers, observation_errors=errors, resources=resources, checked_reads=reads,
        public_failures=[e for e in events if e.get('hresult', 0) < 0 or e.get('code', 0) != 0],
        last_event=events[-1] if events else None,
        handling='Observed backend rejection and public check completion are independent outcomes.')
    save(directory/'observation.json', result)
    return result


def check(case, stage):
    proposal = json.loads((PRIOR/case/'proposal-before-native.json').read_text())
    directory = OUTPUT/case
    directory.mkdir(parents=True, exist_ok=True)
    source = PRIOR/case/(stage+'.gxw')
    plan = json.loads((P/'noeul-native-batch'/case/'plan.json').read_text())
    plan['project_owned_compiler'] = True
    attempts = []
    for attempt in range(1, 5):
        native = directory/f'{stage}-check-{attempt}'
        prepared = native_run(source, native, plan, compile=True, export=False, check=True,
                              alias='QPATCH', prepare_only=True)
        (native/'check-observer.js').write_text(SCRIPT, encoding='utf-8')
        traced_run([prepared['executable'], prepared['plan_file']], SCRIPT, native, timeout=50)
        events = [json.loads(line) for line in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
        collision = any(e.get('operation') == 'NativeTemporaryDirectoryCollision' for e in events)
        attempts.append(dict(attempt=attempt, directory=str(native), temporary_collision=collision))
        if not collision:
            break
    label = 'original' if stage == 'original' else 'expected'
    result = inspect_trace(native, source, proposal, label)
    save(directory/(stage+'-check.json'), dict(attempts=attempts, result=result))
    compact = {k: v for k, v in result.items() if k not in ('checked_reads', 'last_event', 'public_failures', 'backend_diagnostics', 'projection_failures')}
    compact['backend_diagnostic_count'] = len(result['backend_diagnostics'])
    compact['projection_failure_count'] = len(result['projection_failures'])
    print(json.dumps(dict(case=case, stage=stage, **compact)), flush=True)


def persistence(case):
    directory = OUTPUT/case
    proposal = json.loads((PRIOR/case/'proposal-before-native.json').read_text())
    checks = {stage: json.loads((directory/(stage+'-check.json')).read_text())['result'] for stage in ('original', 'candidate')}
    comparison = dict(case=case, checks=checks,
        public_diagnostics_unchanged=None if not all(r['public_check_complete'] for r in checks.values()) else
            checks['original']['public_diagnostics'] == checks['candidate']['public_diagnostics'],
        observed_backend_diagnostics_unchanged=(checks['original']['backend_diagnostics'] == checks['candidate']['backend_diagnostics']
            if all(r['backend_complete'] and all(s['checked_current_pcode'] for s in r['resources']) for r in checks.values()) else None),
        all_backend_targets_observed=all(r['backend_complete'] for r in checks.values()),
        scope='Persistence measured independently of full program checks. Retained rejection/failure is not acceptance.')
    plan = json.loads((P/'noeul-native-batch'/case/'plan.json').read_text())
    candidate = PRIOR/case/'candidate.gxw'
    native = directory/'candidate-save-separate'
    if case == 'case-16':
        # The preceding persistence control passed using the project-owned
        # compiler selected by export=True. Reuse it; only stale checks rerun.
        prior_persistence = P/'q-lossless-project-patch-check-save-20261001-v2'/case
        native = prior_persistence/'candidate-save-separate'
        comparison['save'] = json.loads((native/'outcome.json').read_text())
        comparison['persistence_reused_from'] = str(prior_persistence)
    else:
        comparison['save'] = native_run(candidate, native, plan, compile=True, export=True, check=False, alias='QPATCH')
    saved = native/'native-saved.gxw'
    resources = []
    for resource in proposal['resources']:
        index = resource['index']
        actual = native/f'pcode-{index}-0.bin'
        resources.append(dict(index=index, name=resource['name'],
            save_pcode_exact=actual.exists() and actual.read_bytes() == (PRIOR/case/f'expected-pcode-{index}.bin').read_bytes()))
    if saved.exists():
        raw = saved.read_bytes()
        resolver = GXWProjectResolver(CompoundFile(raw))
        comparison['saved_source_body_exact'] = frame_token_pou(resolver.read_logical_file(proposal['logical'])).body == (PRIOR/case/'expected-source-body.bin').read_bytes()
        comparison['saved_source_prediction_exact'] = all(r['output'] == (PRIOR/case/f'expected-pcode-{r["resource_index"]}.bin').read_bytes()
                                                         for r in project_projection(raw))
        if case == 'case-16':
            reopened = prior_persistence/'candidate-reopen-compile-separate'
            comparison['reopen'] = json.loads((reopened/'outcome.json').read_text())
        else:
            reopened = directory/'candidate-reopen-compile-separate'
            comparison['reopen'] = native_run(saved, reopened, plan, compile=True, export=False, check=False, alias='QPATCH')
        for resource in resources:
            index = resource['index']
            actual = reopened/f'pcode-{index}-0.bin'
            resource['reopen_pcode_exact'] = actual.exists() and actual.read_bytes() == (PRIOR/case/f'expected-pcode-{index}.bin').read_bytes()
    comparison['resources'] = resources
    save(directory/'comparison.json', comparison)
    print(json.dumps({k: v for k, v in comparison.items() if k != 'checks'}), flush=True)


if __name__ == '__main__':
    case, mode = sys.argv[1:]
    if case not in CASES or mode not in ('original', 'candidate', 'persistence'):
        raise ValueError('Choose a bound case and explicit check/persistence mode')
    OUTPUT.mkdir(exist_ok=True)
    (OUTPUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    save(OUTPUT/'retained-predecessor.json', dict(paths=['q-lossless-project-patch-check-save-20261001-v1','q-lossless-project-patch-check-save-20261001-v2'],
        reason='v1 retained the unsupported non-IEC backend and a native/logical-name comparison error. v2 resolved observation but its export=False check selected a separate compiler: both current compiled bodies were exact while MAIN1 workspace reads retained original ST1 rather than proposed ST2 at offset 296. v3 explicitly selects the project-owned compiler before checking. v2 separate save/reopen already passed and its saved resource copies contain the changed bytes. All predecessor inputs and observations remain retained.'))
    if mode == 'persistence':
        persistence(case)
    else:
        check(case, mode)
