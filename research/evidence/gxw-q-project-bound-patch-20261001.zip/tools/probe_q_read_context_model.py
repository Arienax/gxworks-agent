"""Predict address tables from project parameters before fresh native observation.

Use original record framing and synthetic capacity variations. Native operations
only convert END in fresh owned objects; no engineering-project or device write.
The read-only observer records the initialized table and unchanged parameter
input. Matching a read convention does not establish valid project allocation.
"""
from pathlib import Path
from dataclasses import replace
from collections import Counter
import base64
import json
import os
import struct
import subprocess
import sys

P=Path(__file__).resolve().parent
ROOT=P.parents[3]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.container import CompoundFile
from gxw.project_resolver import GXWProjectResolver
from probe_gxw_parameters import device_allocation_record
from probe_fx_operand_rules import traced_run
from source_q_read_context import build_read_context, VARIABLES, BIT_DEVICES, Unsupported
from source_q_machine_reader import load_profile, read_machine


def save(path,value):
    path.write_text(json.dumps(value,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')


def parity(word):
    return word|((word.bit_count()&1)<<31)


def main():
    revision=sys.argv[1] if len(sys.argv)>1 else 'v2'
    if not revision.startswith('v') or not revision[1:].isdigit():raise ValueError('Revision name')
    output=P/f'q-read-context-model-20261001-{revision}'
    output.mkdir()
    for name in ('source_q_read_context.py','source_q_machine_reader.py','QMachineOracle.cs','TraceQReadContext.js',Path(__file__).name):
        (output/name).write_bytes((P/name).read_bytes())
    corpus=json.loads((P/'q-machine-original-corpus-20261001-v1/before-forward.json').read_text())
    directories=sorted({Path(row['source']).parent for row in corpus['programs']})
    originals=[]
    for directory in directories:
        resolver=GXWProjectResolver(CompoundFile((directory/'input.gxw').read_bytes()))
        parameter,=[f for f in resolver.logical_files() if f.logical_name=='Param.wpa']
        stored=resolver.hdb.read_stream(parameter.stream_name)
        record=device_allocation_record(stored)
        originals.append(dict(case=directory.name,parameter_record_offset=record.offset,
                              parameter_hex=record.raw.hex(),stream_name=parameter.stream_name))
    profile=load_profile(P/'q-machine-static-read-tables-20261001-v3.json',P/'q-machine-default-device-table-20261001-v2/comparison.json')
    # The already inspected zero-operand END form, including its metadata.
    machine=struct.pack('<II',parity(0x5F17807A),parity(0x5D490012))
    controls=[]
    def add(raw,description):
        context=build_read_context(raw)
        prediction=read_machine(machine,replace(profile,devices=context.devices))
        if not prediction or any(r['handling']!='decoded' for r in prediction):
            raise ValueError('END prediction unexpectedly opaque')
        controls.append(dict(id=len(controls),description=description,parameter_hex=raw.hex(),
            table_hex=context.devices.hex(),ranges=context.devices[0],opaque_rows=[dict(offset=at,raw_hex=part.hex()) for at,part in context.opaque_rows],
            machine_hex=machine.hex(),expected_pcode_hex=b''.join(bytes.fromhex(r['pcode_hex']) for r in prediction).hex()))
    profiles=list(dict.fromkeys(row['parameter_hex'] for row in originals))
    for parameter in profiles:
        add(bytes.fromhex(parameter),'Original profile')
    base=(P/'q-machine-observed-project-profile-20261001-v1/project-parameters.bin').read_bytes()
    for code in VARIABLES:
        points=(0,1,15,16,17,0x200) if code in BIT_DEVICES else (0,1,7,8,9,0x80)
        at,=[offset for offset in range(6,len(base),4) if struct.unpack_from('<H',base,offset)[0]==0x100|code]
        for count in points:
            raw=bytearray(base)
            struct.pack_into('<H',raw,at+2,count)
            add(bytes(raw),dict(device_code=code,value=count))
    add(struct.pack('<HHH',6,0x2000,0),'Empty row table; inspected fixed X/Y defaults')
    only_st=struct.pack('<HHHHH',10,0x2000,1,0x1C8,16)
    add(only_st,'ST-only table with other configurable devices absent')
    small=bytearray(base)
    for at in range(6,len(small),4):
        code=struct.unpack_from('<H',small,at)[0]&0xFF
        if code in VARIABLES:struct.pack_into('<H',small,at+2,32 if code in BIT_DEVICES else 16)
    add(bytes(small),'All configurable devices small')
    refused=[]
    bad_bank=bytearray(base);struct.pack_into('<H',bad_bank,6,0x290)
    duplicate=bytearray(base);duplicate[10:14]=duplicate[6:10]
    wrong_tag=bytearray(base);struct.pack_into('<H',wrong_tag,2,0x1000)
    for description,raw in [('unmeasured-bank',bytes(bad_bank)),('duplicate-device-row',bytes(duplicate)),
                            ('unmeasured-tag',bytes(wrong_tag)),('truncated-record',base[:-1])]:
        try:build_read_context(raw)
        except Unsupported as exc:refused.append(dict(description=description,raw_hex=raw.hex(),reason=str(exc),native_called=False))
        else:raise ValueError('Malformed control unexpectedly accepted')
    save(output/'before-native.json',dict(scope=__doc__,originals=originals,controls=controls,unsupported=refused))
    executable=output/'QMachineOracle.exe'
    build=subprocess.run([str(Path(os.environ['WINDIR'])/'Microsoft.NET/Framework/v4.0.30319/csc.exe'),'/nologo','/platform:x86',
                          '/out:'+str(executable),str(output/'QMachineOracle.cs')],capture_output=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
    (output/'build.txt').write_bytes(build.stdout+build.stderr)
    if build.returncode:raise RuntimeError('Owned helper build failed; retained')
    request=output/'requests.tsv'
    request.write_text('\n'.join(str(r['id'])+'\t'+base64.b64encode(machine).decode()+'\t'+base64.b64encode(bytes.fromhex(r['parameter_hex'])).decode()
                                 for r in controls)+'\n',encoding='ascii')
    args=[str(executable),'D:/GXWORKS2/Easysocket/CodeGenerator/ECCodeGenerator2.dll','reverse',str(request),str(output/'baseline.jsonl')]
    baseline=subprocess.run(args,capture_output=True,timeout=45,creationflags=subprocess.CREATE_NO_WINDOW)
    (output/'baseline-stdout.bin').write_bytes(baseline.stdout);(output/'baseline-stderr.bin').write_bytes(baseline.stderr)
    if baseline.returncode:raise ValueError('Owned baseline failed; retained')
    args[4]=str(output/'output.jsonl')
    traced_run(args,(output/'TraceQReadContext.js').read_text(),output)
    packets=[json.loads(line) for line in (output/'events.jsonl').read_text().splitlines()]
    events=[r['payload'] for r in packets if r['type']=='send']
    errors=[r for r in packets if r['type']!='send']
    before=[json.loads(line) for line in (output/'baseline.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    after=[json.loads(line) for line in (output/'output.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    comparisons=[]
    for control,event,native in zip(controls,events,after,strict=True):
        comparisons.append(dict(id=control['id'],serial_exact=event['serial']==control['id'],
            parameter_input_exact=event['parameter_hex']==control['parameter_hex'],
            table_exact=event['table_hex']==control['table_hex'],
            expected_pcode_exact=base64.b64decode(native['output_base64']).hex()==control['expected_pcode_hex'],
            native_input_complete=native['code']==0 and native['remaining']==0 and native['consumed']==len(machine),
            input_unchanged=native['input_unchanged'] and native['guards_intact'],
            actual_ranges=event['count'],expected_ranges=control['ranges'],actual_table_hex=event['table_hex']))
    save(output/'comparison.json',dict(errors=errors,traced_baseline_exact=before==after,comparisons=comparisons))
    failures=[dict(control=controls[r['id']],comparison=r) for r in comparisons if not all(r[k] for k in
               ('serial_exact','parameter_input_exact','table_exact','expected_pcode_exact','native_input_complete','input_unchanged'))]
    save(output/'failures.json',failures)
    result=dict(scope=__doc__,original_projects=len(originals),original_profiles=len(profiles),prospective_tables=len(controls),
                exact=sum(r['table_exact'] for r in comparisons),unsupported_raw_preserved=len(refused),
                mismatches=len(failures),hook_errors=len(errors),traced_baseline_exact=before==after)
    save(output/'summary.json',result)
    print(json.dumps(result,ensure_ascii=True),flush=True)
    if failures or errors or before!=after:raise ValueError('Independent context prediction differs; retained')


if __name__=='__main__':main()
