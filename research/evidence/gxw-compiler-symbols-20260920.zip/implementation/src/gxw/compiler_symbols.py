"""Compiler symbol paths and exact lexical operand occurrences.

These cross-references describe stored artifacts. They preserve multiple
aliases and timer roles, and do not infer liveness or current-source validity.
"""
from __future__ import annotations

from dataclasses import dataclass

from .compiler_assignment import CompilerAssignment, parse_compiler_assignment
from .compiler_tables import CompilerComponent, CompilerTables
from .models import GXWFormatError
from .token_listing import TokenInstruction, TokenListing


@dataclass(frozen=True)
class CompilerSymbol:
    pou_offset: int
    component: CompilerComponent
    assignment: CompilerAssignment
    declared_address_offset: int


@dataclass(frozen=True)
class CompilerSymbolPath:
    root_pou_offset: int
    names: tuple[bytes, ...]
    component_offsets: tuple[int, ...]
    symbol: CompilerSymbol


def compiler_symbols(tables: CompilerTables) -> tuple[CompilerSymbol, ...]:
    result = []
    for record in tables.tables[1].records:
        pou = tables.pou_at(record.table_offset)
        for component in tables.components(pou):
            result.append(CompilerSymbol(record.table_offset, component,
                parse_compiler_assignment(component.user_info), tables.component_address_offset(component)))
    return tuple(result)


def compiler_symbol_paths(tables: CompilerTables, root_pou_offset: int, *, limit: int = 10000) -> tuple[CompilerSymbolPath, ...]:
    """Follow explicit FB references; fail visibly on cycles or expansion limit.

    A root is supplied by the caller; unowned library POUs are not guessed to
    be program roots. Arrays/structures are retained as leaf declarations.
    """
    root = tables.pou_at(root_pou_offset)
    pending = [(root, (root.name_bytes,), (), frozenset())]
    result = []
    while pending:
        pou, names, offsets, ancestors = pending.pop()
        if pou.record.table_offset in ancestors:
            raise GXWFormatError("cycle in compiler instance references")
        ancestors = ancestors | {pou.record.table_offset}
        children = []
        for component in tables.components(pou):
            if len(result) >= limit:
                raise GXWFormatError("compiler symbol path expansion exceeds limit")
            symbol = CompilerSymbol(pou.record.table_offset, component,
                parse_compiler_assignment(component.user_info), tables.component_address_offset(component))
            path = CompilerSymbolPath(root_pou_offset, names + (component.name_bytes,),
                                      offsets + (component.record.table_offset,), symbol)
            result.append(path)
            reference = component.instance_pou_offset
            if reference is not None:
                children.append((tables.pou_at(reference), path.names, path.component_offsets, ancestors))
        pending.extend(reversed(children))
    return tuple(result)


@dataclass(frozen=True)
class CompilerOperandOccurrence:
    instruction_offset: int
    step: int | None
    mnemonic: str
    operand_index: int
    operand_offset: int
    text: str
    component_offsets: tuple[int, ...]


def compiler_operand_occurrences(symbols: tuple[CompilerSymbol, ...], listing: TokenListing) -> tuple[CompilerOperandOccurrence, ...]:
    """Match complete FX operand spellings, retaining every possible alias.

    Does not expand indexed operands, word extents, implicit outputs or digit
    groups. An unmatched argument remains an occurrence with no candidate.
    Timer status/coil/value aliases remain distinct symbols at the same Tn.
    """
    by_operand: dict[str, list[int]] = {}
    for symbol in symbols:
        operand = symbol.assignment.fx_operand
        if operand is not None:
            by_operand.setdefault(operand, []).append(symbol.component.record.table_offset)
    result = []
    for record in listing.records:
        if not isinstance(record, TokenInstruction):
            continue
        for index, operand in enumerate(record.operands):
            result.append(CompilerOperandOccurrence(record.tokens[0].offset, record.step, record.mnemonic,
                index, operand.tokens[0].offset, operand.text, tuple(by_operand.get(operand.text, ()))))
    return tuple(result)
