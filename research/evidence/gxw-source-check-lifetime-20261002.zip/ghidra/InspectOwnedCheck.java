import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.listing.Function;

public class InspectOwnedCheck extends GhidraScript {
    @Override
    public void run() throws Exception {
        Address helperEntry = toAddr("60ce77f0");
        disassemble(helperEntry);
        Function helper = getFunctionAt(helperEntry);
        if (helper == null) helper = createFunction(helperEntry, "Owned_EH_prolog");
        if (helper == null) throw new IllegalStateException("No verified EH helper");
        helper.setCallFixup("EH_prolog");
        for (String value : getScriptArgs()) {
            Address entry = toAddr(value);
            boolean decoded = disassemble(entry);
            Function function = getFunctionAt(entry);
            if (function == null) function = createFunction(entry, "OwnedCheck_" + value);
            if (function == null) throw new IllegalStateException("No method at " + value);
            println("entry=" + entry + " decoded=" + decoded + " function=" + function.getName());
        }
    }
}
