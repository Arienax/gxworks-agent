import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.listing.Function;

public class InspectNativeEntries extends GhidraScript {
    @Override
    public void run() throws Exception {
        for (String value : getScriptArgs()) {
            Address entry = toAddr(value);
            boolean decoded = disassemble(entry);
            Function function = getFunctionAt(entry);
            if (function == null) function = createFunction(entry, "OwnedNative_" + value);
            if (function == null) throw new IllegalStateException("No native method at " + value);
            println("entry=" + entry + " decoded=" + decoded + " function=" + function.getName());
        }
    }
}
