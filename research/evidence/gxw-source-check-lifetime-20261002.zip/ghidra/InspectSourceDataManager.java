import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.listing.Function;

public class InspectSourceDataManager extends GhidraScript {
    @Override
    public void run() throws Exception {
        if (!currentProgram.getImageBase().equals(toAddr("66720000"))) {
            throw new IllegalStateException("Source DataManager image base differs");
        }
        // Remove only the two owned entries created with an incorrect image base.
        for (String value : new String[] {"66730dc7", "667331d5"}) {
            Address entry = toAddr(value);
            Function function = getFunctionAt(entry);
            if (function != null && function.getName().equals("OwnedNative_" + value)) {
                currentProgram.getFunctionManager().removeFunction(entry);
                println("removed_owned_incorrect_entry=" + entry);
            }
        }
        for (String value : new String[] {"66750dc7", "667531d5", "667220f0"}) {
            Address entry = toAddr(value);
            disassemble(entry);
            Function function = getFunctionAt(entry);
            if (function == null) function = createFunction(entry, "OwnedSource_" + value);
            if (function == null) throw new IllegalStateException("No method at " + value);
            println("entry=" + entry + " function=" + function.getName());
        }
    }
}
