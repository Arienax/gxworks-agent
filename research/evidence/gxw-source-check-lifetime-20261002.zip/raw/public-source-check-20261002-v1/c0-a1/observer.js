
let serial=0,phase='startup',checkIndex=-1,checkTarget=null;
function id(a){return Array.from({length:12},(_,i)=>a[i+1].toUInt32());}
function loc(p){const m=Process.findModuleByAddress(p);return m?{module:m.name,rva:p.sub(m.base).toString()}:{address:p.toString()};}
function hex(p,n){if(n<0||n>16777216)throw new Error('buffer bound');return Array.from(new Uint8Array(p.readByteArray(n)),b=>b.toString(16).padStart(2,'0')).join('');}
// The public adapter can fail while projecting a completed backend error.
// Preserve that original diagnostic independently; never replace a return value.
const backendProgressTargets=new Set();
function sizedText(p,n){
  if(n<0||n>65536)throw new Error('diagnostic text bound');
  if(p.isNull()){if(n!==0)throw new Error('null diagnostic text');return null;}
  if(n===0)return '';
  const raw=hex(p,n);if(!raw.endsWith('00'))throw new Error('diagnostic text terminator');return raw.slice(0,-2);
}
function backendReport(p){
  const args=[],list=p.add(64).readPointer();
  if(!list.isNull()){
    const count=list.add(4).readS32();if(count<0||count>128)throw new Error('diagnostic argument bound');
    const base=list.readPointer();if(count&&base.isNull())throw new Error('null diagnostic arguments');
    for(let i=0;i<count;i++){const a=base.add(i*8);args.push(sizedText(a.readPointer(),a.add(4).readS32()));}
  }
  return {raw_hex:hex(p,68),kind:p.readS32(),code:p.add(4).readU32(),
    library_hex:sizedText(p.add(8).readPointer(),p.add(12).readS32()),
    name_hex:sizedText(p.add(16).readPointer(),p.add(20).readS32()),
    instance_kind:p.add(24).readS32(),instance_hex:sizedText(p.add(28).readPointer(),p.add(32).readS32()),
    program_kind:p.add(36).readS32(),step:p.add(40).readS32(),network:p.add(44).readS32(),
    left:p.add(48).readS32(),top:p.add(52).readS32(),right:p.add(56).readS32(),bottom:p.add(60).readS32(),arguments_hex:args};
}
Process.attachModuleObserver({onAdded(m){
  const name=m.name.toLowerCase();
  if(name==='dzdataabs_compileradapter.dll'){
   Interceptor.attach(m.base.add(86113),{
    onEnter(a){checkIndex++;phase='check';checkTarget=id(a);send({event:'check-start',serial:serial++,check_index:checkIndex,target:checkTarget,kind:a[13].toUInt32()});}
   });
   Interceptor.attach(m.base.add(0x9674),{onEnter(){
    if(phase!=='check')return;
    try{
      const backend=this.context.ecx.add(0x14).readPointer(),target=backend.readPointer().add(44).readPointer();
      if(backendProgressTargets.has(target.toString()))return;backendProgressTargets.add(target.toString());
      const location=loc(target),supported=!!location.module&&location.module.toLowerCase()==='dzdataabs_compiler_iec.dll'&&location.rva==='0x700b';
      send({event:'backend-diagnostic-observer',serial:serial++,target:location,supported});
      if(!supported)return;
      Interceptor.attach(target,{
        onEnter(a){if(phase!=='check')return;this.contextRow={check_index:checkIndex,target:checkTarget};this.percent=a[1];this.count=a[2];this.reports=a[3];this.code=a[4];},
        onLeave(r){if(!this.contextRow)return;try{
          const count=this.count.readS32(),rows=[];if(count<0||count>10000)throw new Error('backend report count');
          const data=this.reports.readPointer();
          if(!data.isNull())for(let i=0;i<count;i++)rows.push(backendReport(data.add(i*68)));
          send({event:'backend-check-progress',serial:serial++,...this.contextRow,hresult:r.toInt32(),code:this.code.readU32(),percent:this.percent.readS32(),
            count,reports_present:!data.isNull(),reports:rows});
        }catch(e){send({event:'observation-error',error:String(e)});}}
      });
    }catch(e){send({event:'observation-error',error:String(e)});}
   }});
   Interceptor.attach(m.base.add(0x8e48),{
    onEnter(a){if(phase!=='check')return;try{this.row={check_index:checkIndex,target:checkTarget,report:backendReport(a[0])};this.code=a[2];}catch(e){send({event:'observation-error',error:String(e)});}},
    onLeave(r){if(!this.row||r.toInt32()>=0)return;try{send({event:'diagnostic-projection-failure',serial:serial++,...this.row,hresult:r.toInt32(),code:this.code.readU32()});}catch(e){send({event:'observation-error',error:String(e)});}}
   });
  }
  if(name!=='dzdataabs_workspace.dll')return;
  Interceptor.attach(m.base.add(0x8663c),{
    onEnter(a){phase=checkIndex<0?'publish-before-check':'publish-before-export';send({event:'publish',serial:serial++,phase:phase,target:id(a)});}
  });
  Interceptor.attach(m.base.add(0x78d08),{
    onEnter(a){
      try{
        this.row={event:'workspace-pcode-read',serial:serial++,phase:phase,check_index:checkIndex,
          check_target:checkTarget,target:id(a),caller:loc(this.returnAddress),
          stack:Thread.backtrace(this.context,Backtracer.ACCURATE).slice(0,12).map(loc)};
        this.sizes=[a[13],a[15],a[17]];this.buffers=[a[14],a[16],a[18]];this.code=a[19];
        this.row.requested_sizes=this.sizes.map(p=>p.isNull()?null:p.readS32());
      }catch(e){send({event:'observation-error',error:String(e)});}
    },
    onLeave(r){if(!this.row)return;try{
      const code=this.code.readS32();
      this.row.hresult=r.toInt32();this.row.code=code;
      this.row.buffers=this.sizes.map((p,i)=>{const n=p.isNull()?null:p.readS32();return {size:n,
        raw_hex:code===0&&r.toInt32()>=0&&!this.buffers[i].isNull()&&n!==null?hex(this.buffers[i],n):null};});
      send(this.row);
    }catch(e){send({event:'observation-error',error:String(e)});}}
  });
}});

let projectionDepth=0;
const lookupObservers=new Set();
function textBstr(p){if(p.isNull())return null;const n=p.sub(4).readU32();if(n>131072||n%2)throw new Error('BSTR bound');return p.readUtf16String(n/2);}
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='dzdataabs_compileradapter.dll')return;
 Interceptor.attach(m.base.add(0x8e48),{
  onEnter(a){projectionDepth++;try{
   const workspace=this.context.ecx.add(0x18).readPointer();
   const fn=workspace.readPointer().add(0x6f8).readPointer();
   if(!lookupObservers.has(fn.toString())){
    lookupObservers.add(fn.toString());
    send({event:'projection-lookup-observer',location:loc(fn)});
    Interceptor.attach(fn,{
     onEnter(a){if(!projectionDepth)return;try{
      this.code=a[16];this.output=a[15];
      this.row={event:'projection-object-lookup',check_index:checkIndex,caller:loc(this.returnAddress),
       parent:id(a),kind:a[13].toUInt32(),name:textBstr(a[14])};
     }catch(e){send({event:'observation-error',error:String(e)});}},
     onLeave(r){if(!this.row)return;try{send({...this.row,hresult:r.toInt32(),code:this.code.readU32(),
      output_id:r.toInt32()>=0?Array.from({length:12},(_,i)=>this.output.add(i*4).readU32()):null});
     }catch(e){send({event:'observation-error',error:String(e)});}}
    });
   }
  }catch(e){send({event:'observation-error',error:String(e)});}},
  onLeave(){projectionDepth--;}
 });
 for(const rva of [0x3def,0x1e27])Interceptor.attach(m.base.add(rva),{
  onEnter(a){if(!projectionDepth)return;this.code=a[2];this.row={event:'projection-argument-transfer',rva:'0x'+rva.toString(16),check_index:checkIndex};},
  onLeave(r){if(!this.row)return;try{send({...this.row,hresult:r.toInt32(),code:this.code.readU32()});}catch(e){send({event:'observation-error',error:String(e)});}}
 });
}});

Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='kernelbase.dll')return;
 const target=m.findExportByName('OutputDebugStringW');
 if(!target)throw new Error('Owned drain gate export unavailable');
 Interceptor.attach(target,{onEnter(a){
  if(a[0].isNull())return;
  if(a[0].readUtf16String(32)==='GXW_OWNED_DIAGNOSTIC_DRAIN_READY')
   send({event:'owned-diagnostic-drain-ready'});
 }});
}});
