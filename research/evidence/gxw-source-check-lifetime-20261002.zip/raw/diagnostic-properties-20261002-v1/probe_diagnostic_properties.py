"""Generate coherent locator variants and reject contradictory witnesses.

Only the stored native seed cases are native observations. Generated records
exercise the research correlation algorithm, not compiler or PLC execution.
"""
from pathlib import Path
from copy import deepcopy
import json
import struct
import sys

P = Path(__file__).resolve().parent
ROOT = P.parents[3]
sys.path[:0] = [str(P / 'skill-trial-20261002-v1/python-deps'), str(P),
               str(ROOT / 'src'), str(ROOT / 'research')]
from hypothesis import given, settings, strategies as st, example
from gxw.compiler_debug import parse_compiler_debug
from program_check_evidence import correlate_st_diagnostic
from probe_inline_fb_identity import source_inputs

OUT = P / 'diagnostic-properties-20261002-v1'


def name_bytes(value):
    return struct.pack('<i', len(value) + 1) + value + b'\0'


def debug_bytes(debug, elements, tables=None):
    tables = debug.offset_tables if tables is None else tables
    raw = struct.pack('<ii', 3, len(tables)) + b''.join(table.raw for table in tables)
    raw += struct.pack('<i', len(elements))
    for element in elements:
        raw += (name_bytes(element.resource_bytes) + struct.pack('<6i', *element.fields)
                + b''.join(name_bytes(name) for name in element.names)
                + struct.pack('<i', element.kind_code) + name_bytes(element.extra_name)
                + struct.pack('<i', element.offset_table_index))
    return raw + debug.opaque_tail


def load_seeds():
    seeds = []
    for group in ['inline-fb-debug-20261002-v1', 'inline-fb-identity-20261002-v1']:
        rows = json.loads((P / group / 'results.json').read_text(encoding='utf-8'))
        for row in rows:
            if row['returncode'] != 2:
                continue
            directory = Path(row['directory'])
            context, texts = source_inputs((directory / 'input.gxw').read_bytes())
            debug = parse_compiler_debug((directory / 'compiler_DZComp/DebugInformation2.dat').read_bytes())
            if debug.reconstruct() != debug.raw:
                raise AssertionError('Native debug seed lost bytes')
            references = [r for q in row['source_references']['queries'] for r in q['rows']]
            for query in row['diagnostic_locations']:
                expected = correlate_st_diagnostic(query, row['link_witness']['rows'], references,
                    texts, context.object_model()['nodes'], debug=debug, debug_encoding='ascii')
                if expected['status'] != 'uniquely_correlated':
                    raise AssertionError(expected)
                seeds.append(dict(query=query, links=row['link_witness']['rows'], references=references,
                    texts=texts, nodes=context.object_model()['nodes'], debug=debug,
                    expected=expected, cpu=row['cpu'], directory=str(directory)))
    return seeds


def project(seed):
    return correlate_st_diagnostic(seed['query'], seed['links'], seed['references'],
        seed['texts'], seed['nodes'], debug=seed['debug'], debug_encoding='ascii')


SEEDS = load_seeds()
INLINE = [seed for seed in SEEDS if seed['cpu'] == 'FX0N']
checks = {'native_seed_locations': len(SEEDS), 'coherent_generated': 0,
          'contradictory_generated': 0, 'ambiguous_generated': 0}


@settings(max_examples=300, deadline=None, derandomize=True, database=None)
@given(index=st.integers(min_value=0, max_value=len(SEEDS)-1),
       prefix=st.text(alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ_', min_size=1, max_size=12),
       delta=st.integers(min_value=0, max_value=256), reverse=st.booleans())
@example(index=0, prefix='_', delta=1, reverse=True)
def coherent(index, prefix, delta, reverse):
    from dataclasses import replace
    original = SEEDS[index]
    seed = deepcopy(original)
    rename = lambda name: '.'.join(prefix + part for part in name.split('.')) if name else name
    seed['query']['query']['resource'] = rename(seed['query']['query']['resource'])
    seed['query']['query']['start_step'] += delta
    seed['query']['location']['pou'] = rename(seed['query']['location']['pou'])
    seed['texts'] = {rename(name): text for name, text in seed['texts'].items()}
    pous = set(original['texts']) | {row['source'] for row in original['references']}
    for row in seed['references']:
        for key in ['name', 'source', 'instance', 'resource', 'task']:
            row[key] = rename(row[key])
        if row['type'] in pous:
            row['type'] = rename(row['type'])
    for row in seed['links']:
        row['name'] = rename(row['name'])
        row['step_start'] += delta
    for node in seed['nodes']:
        node['symbol'] = rename(node['symbol'])
        if node['template'].startswith('function_block:'):
            node['template'] = 'function_block:' + rename(node['template'].split(':', 1)[1])
    elements = []
    for element in seed['debug'].elements:
        fields = list(element.fields)
        fields[2] += delta
        fields[3] += delta
        elements.append(replace(element, resource_bytes=rename(element.resource_bytes.decode('ascii')).encode('ascii'),
            names=tuple(rename(name.decode('ascii')).encode('ascii') for name in element.names), fields=tuple(fields)))
    if reverse:
        for key in ['references', 'links', 'nodes']:
            seed[key].reverse()
        elements.reverse()
    seed['debug'] = parse_compiler_debug(debug_bytes(seed['debug'], elements))
    actual = project(seed)
    assert actual['status'] == 'uniquely_correlated', actual
    assert actual['instance'] == rename(original['expected']['instance']), actual
    assert actual['task'] == rename(original['expected']['task']), actual
    assert actual['source']['zero_based_line'] == original['expected']['source']['zero_based_line'], actual
    assert actual['diagnostic_step'] == original['expected']['diagnostic_step'] + delta, actual
    assert actual['caller']['bbox'] == original['expected']['caller']['bbox'], actual
    assert actual['public_check_promoted'] is False
    checks['coherent_generated'] += 1


@settings(max_examples=180, deadline=None, derandomize=True, database=None)
@given(index=st.integers(min_value=0, max_value=len(INLINE)-1),
       fault=st.sampled_from(['resource', 'line', 'step', 'selected-source', 'object-bbox',
          'native-failure', 'source-reference', 'debug-source', 'debug-library', 'debug-table-kind']))
def contradictory(index, fault):
    from dataclasses import replace
    seed = deepcopy(INLINE[index])
    expected = seed['expected']
    if fault == 'resource':
        seed['query']['query']['resource'] = 'OWNED_FOREIGN_RESOURCE'
    elif fault == 'line':
        seed['query']['location']['start_step'] = len(seed['texts'][expected['source']['pou']].splitlines())
    elif fault == 'step':
        seed['query']['query']['start_step'] = max(e.linked_step_end for e in seed['debug'].elements) + 1024
    elif fault == 'selected-source':
        del seed['texts'][expected['source']['pou']]
    elif fault == 'object-bbox':
        for node in seed['nodes']:
            if node['id'] == expected['caller']['object_id']:
                node['x'] += 1
    elif fault == 'native-failure':
        seed['query']['hresult'] = -2147467259
    elif fault == 'source-reference':
        seed['references'] = [row for row in seed['references'] if row != expected['native_reference']]
    elif fault in ['debug-source', 'debug-library']:
        elements = []
        for element in seed['debug'].elements:
            names = list(element.names)
            names[2 if fault == 'debug-source' else 0] = b'OWNED_FOREIGN_SOURCE'
            elements.append(replace(element, names=tuple(names)))
        seed['debug'] = parse_compiler_debug(debug_bytes(seed['debug'], elements))
    elif fault == 'debug-table-kind':
        tables = [replace(table, kind_code=208, raw=struct.pack('<i',208)+table.raw[4:])
                  if table.kind_code == 193 else table for table in seed['debug'].offset_tables]
        seed['debug'] = parse_compiler_debug(debug_bytes(seed['debug'], seed['debug'].elements, tables))
    actual = project(seed)
    assert actual['status'] == 'unresolved', (fault, actual)
    assert actual['public_check_promoted'] is False
    checks['contradictory_generated'] += 1


@settings(max_examples=150, deadline=None, derandomize=True, database=None)
@given(index=st.integers(min_value=0, max_value=len(INLINE)-1),
       duplicate=st.sampled_from(['source-reference', 'caller-reference', 'caller-object', 'debug-element']))
def ambiguous(index, duplicate):
    seed = deepcopy(INLINE[index])
    expected = seed['expected']
    if duplicate == 'source-reference':
        seed['references'].append(deepcopy(expected['native_reference']))
    elif duplicate == 'caller-reference':
        call = next(row for row in seed['references'] if row.get('program_kind') == 208
            and row.get('class_code') == 1 and row['name'] == expected['instance'].split('.')[-1])
        seed['references'].append(deepcopy(call))
    elif duplicate == 'caller-object':
        seed['nodes'].append(deepcopy(next(node for node in seed['nodes'] if node['id'] == expected['caller']['object_id'])))
    elif duplicate == 'debug-element':
        element = seed['debug'].elements[expected['debug_evidence']['element_index']]
        seed['debug'] = parse_compiler_debug(debug_bytes(seed['debug'], [*seed['debug'].elements, element]))
    actual = project(seed)
    assert actual['status'] == 'unresolved', (duplicate, actual)
    checks['ambiguous_generated'] += 1


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    OUT.mkdir(exist_ok=False)
    (OUT / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    for check in [coherent, contradictory, ambiguous]:
        print('checking ' + check.__name__, flush=True)
        try:
            check()
        except Exception:
            (OUT / 'partial-counts.json').write_text(json.dumps(checks, indent=2), encoding='utf-8')
            raise
    checks['scope'] = 'generated research locator records; not native or PLC execution'
    (OUT / 'result.json').write_text(json.dumps(checks, indent=2), encoding='utf-8')
    print(json.dumps(checks), flush=True)


if __name__ == '__main__':
    main()
