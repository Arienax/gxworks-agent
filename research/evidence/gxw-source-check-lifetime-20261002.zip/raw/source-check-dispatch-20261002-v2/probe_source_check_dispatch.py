"""Observe the original source Check dispatch; do not replace native results."""
from pathlib import Path
import json
import shutil
import sys

P = Path(__file__).resolve().parent
sys.path.insert(0, str(P))
import probe_public_source_check as source
import probe_native_check_drain as drain
import probe_application_check_resources as trace

OUT = P / 'source-check-dispatch-20261002-v2'
OBSERVER = r'''
let ownedSourceCheckDepth=0;
const sourceDispatches=new Set();
const nativeSourceDispatches=new Set();
let ownedSourceCheckEver=false;
function sourceSelections(p,count){
 if(count<0||count>32)throw new Error('source unit count bound');
 const units=[];
 for(let i=0;i<count;i++){
  const unit=p.add(i*12), n=unit.add(4).readS32(), selections=unit.add(8).readPointer();
  if(n<0||n>32)throw new Error('source selection count bound');
  const rows=[];
  for(let j=0;j<n;j++)rows.push({row:selections.add(j*8).readS32(),
    name:textBstr(selections.add(j*8+4).readPointer())});
  units.push({kind:unit.readS32(),count:n,rows});
 }
 return units;
}
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='dzdataabs_compileradapter.dll')return;
 Interceptor.attach(m.base.add(0x13d3b),{
  onEnter(a){ownedSourceCheckDepth++;ownedSourceCheckEver=true;try{send({event:'public-source-check-enter',
   report_kind:a[1].toInt32(),count:a[2].toInt32(),units:sourceSelections(a[3],a[2].toInt32())});
  }catch(e){send({event:'observation-error',phase:'source-check-enter',error:String(e)});}},
  onLeave(r){send({event:'public-source-check-return',hresult:r.toInt32()});ownedSourceCheckDepth--;}
 });
 Interceptor.attach(m.base.add(0x13a2a),{
  onEnter(){this.owned=ownedSourceCheckDepth>0;},
  onLeave(r){if(!this.owned)return;try{
   const object=r.readPointer(),table=object.readPointer(),check=table.add(12).readPointer();
   send({event:'source-check-dispatch-selected',object:object.toString(),vtable:loc(table),check:loc(check)});
   if(sourceDispatches.has(check.toString()))return;
   sourceDispatches.add(check.toString());
   Interceptor.attach(check,{
    onEnter(a){if(!ownedSourceCheckDepth)return;try{
     this.code=a[3];send({event:'source-check-implementation-enter',address:loc(check),
      self:this.context.ecx.toString(),report_kind:a[0].toInt32(),count:a[1].toInt32(),
      units:sourceSelections(a[2],a[1].toInt32())});
     const backend=this.context.ecx.add(0x14).readPointer(),vtable=backend.readPointer(),
      nativeCheck=vtable.add(36).readPointer(),progress=vtable.add(44).readPointer();
     send({event:'source-check-backend-selected',vtable:loc(vtable),check:loc(nativeCheck),progress:loc(progress)});
     if(!nativeSourceDispatches.has(nativeCheck.toString())){
      nativeSourceDispatches.add(nativeCheck.toString());
      Interceptor.attach(nativeCheck,{
       onEnter(a){if(!ownedSourceCheckDepth)return;this.code=a[4];try{
        const count=a[2].toInt32(),units=[];
        if(count<0||count>32)throw new Error('backend source count bound');
        for(let i=0;i<count;i++){
         const unit=a[3].add(i*12),n=unit.add(4).readS32(),selections=unit.add(8).readPointer(),rows=[];
         if(n<0||n>32)throw new Error('backend source selection bound');
         for(let j=0;j<n;j++)rows.push({row:selections.add(j*8).readS32(),
           name:selections.add(j*8+4).readPointer().readCString(2048)});
         units.push({kind:unit.readS32(),count:n,rows});
        }
        send({event:'source-check-backend-enter',address:loc(nativeCheck),
          report_kind:a[1].toInt32(),count,units});
       }catch(e){send({event:'observation-error',phase:'source-backend-enter',error:String(e)});}},
       onLeave(r){if(!this.code)return;send({event:'source-check-backend-return',hresult:r.toInt32(),code:this.code.readU32()});}
      });
      Interceptor.attach(progress,{
       onEnter(a){if(!ownedSourceCheckEver||phase==='check')return;
        this.percent=a[1];this.count=a[2];this.reports=a[3];this.code=a[4];},
       onLeave(r){if(!this.code)return;try{
        const count=this.count.readS32(),data=this.reports.readPointer(),rows=[];
        if(count<0||count>10000)throw new Error('source report count bound');
        if(!data.isNull())for(let i=0;i<count;i++)rows.push(backendReport(data.add(i*68)));
        send({event:'source-check-backend-progress',hresult:r.toInt32(),code:this.code.readU32(),
          percent:this.percent.readS32(),count,reports:rows});
       }catch(e){send({event:'observation-error',phase:'source-backend-progress',error:String(e)});}}
      });
     }
    }catch(e){send({event:'observation-error',phase:'source-check-implementation',error:String(e)});}},
    onLeave(r){if(!this.code)return;try{send({event:'source-check-implementation-return',
     hresult:r.toInt32(),code:this.code.readU32()});}catch(e){send({event:'observation-error',error:String(e)});}}
   });
  }catch(e){send({event:'observation-error',phase:'source-check-dispatch',error:String(e)});}}
 });
}});
'''


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    OUT.mkdir(exist_ok=False)
    shutil.copyfile(Path(__file__), OUT / Path(__file__).name)
    prior = next(row for row in json.loads((P / 'diag-cpu-20261002-v1/results.json').read_text(
        encoding='utf-8')) if row['cpu'] == 'FX3U/FX3UC' and row['returncode'] != 5)
    raw = (Path(prior['directory']) / 'input.gxw').read_bytes()
    frozen = trace.A / 'full-FX3U-FX3UC/native-compile'
    prepare, adapt = trace.prepare, drain.adapt_helper
    source.UNITS = [dict(kind=6, name='FBD_MATRIX', row=-1)]
    drain.adapt_helper = source.adapt
    trace.prepare = lambda *args, **kwargs: prepare(*args, **kwargs) + OBSERVER
    try:
        results = []
        for attempt in range(1, 17):
            directory = OUT / f'a{attempt}'
            result = drain.run(directory, frozen, raw)
            observations = [json.loads(line) for line in (directory / 'observation-events.jsonl').read_text(
                encoding='utf-8').splitlines()]
            result['source_dispatch'] = [row['payload'] for row in observations
                if row.get('type') == 'send' and 'source-check' in row['payload'].get('event', '')]
            trace.save(directory / 'result-with-dispatch.json', result)
            results.append(result)
            trace.save(OUT / 'results.json', results)
            print(json.dumps(dict(returncode=result['returncode'],dispatch=result['source_dispatch'],
                observation_errors=result['observation_errors']),ensure_ascii=False),flush=True)
            if result['returncode'] != 5:
                break
    finally:
        trace.prepare, drain.adapt_helper = prepare, adapt


if __name__ == '__main__':
    main()
