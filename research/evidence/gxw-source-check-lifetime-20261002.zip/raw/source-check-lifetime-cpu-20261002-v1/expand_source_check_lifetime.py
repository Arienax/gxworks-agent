"""Expand the source-selection lifetime module over exact recorded CPU options.

Each option retains its own native input and configuration. This matrix tests
the Check selection lifetime, not PLC execution or whole language coverage.
"""
from pathlib import Path
import json
import shutil
import sys

P=Path(__file__).resolve().parent
sys.path.insert(0,str(P))
import probe_application_check_resources as trace
import probe_native_check_drain as drain
import probe_public_source_check as source
import probe_source_check_dispatch as dispatch
import probe_source_check_units as units

OUT=P/'source-check-lifetime-cpu-20261002-v1'


def assess(result, observed, native):
    if result['returncode']==5:
        return 'retained-startup-collision'
    failures=[]
    cleaned=[row for row in observed if row.get('event')=='native-source-owner-cleanup-enter']
    workers=[row for row in observed if row.get('event')=='native-source-worker-enter']
    rejected=[row for row in observed if row.get('event')=='native-source-shape-rejection']
    if result['returncode']!=2:
        failures.append('original public source-check exit differs')
    if not result['compile_completed']:
        failures.append('compile completion absent')
    if len(cleaned)!=1 or len(workers)!=1 or len(rejected)!=1:
        failures.append('source lifetime observation is not one-to-one')
    else:
        before=cleaned[0]['units'][0];worker=workers[0]['units'][0];after=rejected[0]['unit']
        if before['pointer']!=worker['pointer'] or before['pointer']!=after['pointer']:
            failures.append('worker selection array differs from cleaned owner')
        if before['count']!=2 or [row['name'] for row in before['rows']]!=['','FBD_MATRIX']:
            failures.append('original names before cleanup differ')
        if after['count']!=2 or [row['name'] for row in after['rows']]!=[None,None]:
            failures.append('rejection does not observe the cleared two-name selection')
    source_reports=[report for row in native if row.get('operation')=='SourceCheckProgress'
        for report in row.get('reports',[]) if report['kind']==2]
    if not source_reports or any(row['code']!=0x50030018 for row in source_reports):
        failures.append('original source shape rejection differs')
    if result['public_check'] or any(row.get('operation')=='PublicSourceCheckCompleted' for row in native):
        failures.append('incomplete original check was promoted')
    if result['observation_errors']:
        failures.append('read-only observation failed')
    return failures or 'owner-cleared-selection-native-worker-rejected-original-public-incomplete'


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    OUT.mkdir(exist_ok=False)
    for path in [Path(__file__),P/'probe_source_check_units.py',P/'probe_source_check_dispatch.py',
                 P/'probe_public_source_check.py',P/'probe_native_check_drain.py']:
        shutil.copyfile(path,OUT/path.name)
    earlier=json.loads((P/'diag-cpu-20261002-v1/results.json').read_text(encoding='utf-8'))
    applications=json.loads((trace.A/'native-results.json').read_text(encoding='utf-8'))
    prepare,adapt,stage=trace.prepare,drain.adapt_helper,source.SOURCE_CHECK
    source.SOURCE_CHECK=units.SOURCE_CHECK
    source.UNITS=[dict(kind=6,selections=[dict(row=-1,name=''),dict(row=-1,name='FBD_MATRIX')])]
    drain.adapt_helper=source.adapt
    trace.prepare=lambda *args,**kwargs:prepare(*args,**kwargs)+dispatch.OBSERVER+units.OBSERVER
    results=[]
    try:
        for index,application in enumerate(applications):
            cpu=application['cpu'];prior=next(row for row in earlier if row['cpu']==cpu and row['returncode']!=5)
            original=Path(prior['directory']);raw=(original/'input.gxw').read_bytes()
            frozen=Path(application['application_case'])/'native-compile'
            for attempt in range(1,17):
                directory=OUT/f'c{index:02d}-a{attempt}'
                result=drain.run(directory,frozen,raw)
                native=[json.loads(line) for line in (directory/'native-events.jsonl').read_text(
                    encoding='utf-8-sig').splitlines()]
                messages=[json.loads(line) for line in (directory/'observation-events.jsonl').read_text(
                    encoding='utf-8').splitlines()]
                observed=[row['payload'] for row in messages if row.get('type')=='send']
                result.update(cpu=cpu,original_input=str(original/'input.gxw'),
                    source_bytes_exact=(directory/'input.gxw').read_bytes()==raw,
                    source_lifetime_events=[row for row in observed if 'source-' in row.get('event','')],
                    source_check_events=[row for row in native if row.get('operation','').startswith(
                        ('Compiler.SourceCheck','SourceCheckProgress','PublicSourceCheck'))],
                    native_initialize_cpu_keys=sorted(set(row['cpu'] for row in observed
                        if row.get('event')=='native-source-compiler-initialize')),
                    public_check_promoted=False)
                result['validation']=assess(result,observed,native)
                trace.save(directory/'result-with-source-lifetime.json',result)
                results.append(result);trace.save(OUT/'results.json',results)
                print(json.dumps(dict(index=index,cpu=cpu,attempt=attempt,returncode=result['returncode'],
                    native_initialize_cpu_keys=result['native_initialize_cpu_keys'],validation=result['validation']),
                    ensure_ascii=False),flush=True)
                if result['returncode']!=5:
                    break
    finally:
        trace.prepare,drain.adapt_helper,source.SOURCE_CHECK=prepare,adapt,stage


if __name__=='__main__':
    main()
