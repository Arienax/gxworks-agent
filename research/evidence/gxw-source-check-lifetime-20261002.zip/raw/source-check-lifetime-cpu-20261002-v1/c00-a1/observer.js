
let serial=0,phase='startup',checkIndex=-1,checkTarget=null;
function id(a){return Array.from({length:12},(_,i)=>a[i+1].toUInt32());}
function loc(p){const m=Process.findModuleByAddress(p);return m?{module:m.name,rva:p.sub(m.base).toString()}:{address:p.toString()};}
function hex(p,n){if(n<0||n>16777216)throw new Error('buffer bound');return Array.from(new Uint8Array(p.readByteArray(n)),b=>b.toString(16).padStart(2,'0')).join('');}
// The public adapter can fail while projecting a completed backend error.
// Preserve that original diagnostic independently; never replace a return value.
const backendProgressTargets=new Set();
function sizedText(p,n){
  if(n<0||n>65536)throw new Error('diagnostic text bound');
  if(p.isNull()){if(n!==0)throw new Error('null diagnostic text');return null;}
  if(n===0)return '';
  const raw=hex(p,n);if(!raw.endsWith('00'))throw new Error('diagnostic text terminator');return raw.slice(0,-2);
}
function backendReport(p){
  const args=[],list=p.add(64).readPointer();
  if(!list.isNull()){
    const count=list.add(4).readS32();if(count<0||count>128)throw new Error('diagnostic argument bound');
    const base=list.readPointer();if(count&&base.isNull())throw new Error('null diagnostic arguments');
    for(let i=0;i<count;i++){const a=base.add(i*8);args.push(sizedText(a.readPointer(),a.add(4).readS32()));}
  }
  return {raw_hex:hex(p,68),kind:p.readS32(),code:p.add(4).readU32(),
    library_hex:sizedText(p.add(8).readPointer(),p.add(12).readS32()),
    name_hex:sizedText(p.add(16).readPointer(),p.add(20).readS32()),
    instance_kind:p.add(24).readS32(),instance_hex:sizedText(p.add(28).readPointer(),p.add(32).readS32()),
    program_kind:p.add(36).readS32(),step:p.add(40).readS32(),network:p.add(44).readS32(),
    left:p.add(48).readS32(),top:p.add(52).readS32(),right:p.add(56).readS32(),bottom:p.add(60).readS32(),arguments_hex:args};
}
Process.attachModuleObserver({onAdded(m){
  const name=m.name.toLowerCase();
  if(name==='dzdataabs_compileradapter.dll'){
   Interceptor.attach(m.base.add(86113),{
    onEnter(a){checkIndex++;phase='check';checkTarget=id(a);send({event:'check-start',serial:serial++,check_index:checkIndex,target:checkTarget,kind:a[13].toUInt32()});}
   });
   Interceptor.attach(m.base.add(0x9674),{onEnter(){
    if(phase!=='check')return;
    try{
      const backend=this.context.ecx.add(0x14).readPointer(),target=backend.readPointer().add(44).readPointer();
      if(backendProgressTargets.has(target.toString()))return;backendProgressTargets.add(target.toString());
      const location=loc(target),supported=!!location.module&&location.module.toLowerCase()==='dzdataabs_compiler_iec.dll'&&location.rva==='0x700b';
      send({event:'backend-diagnostic-observer',serial:serial++,target:location,supported});
      if(!supported)return;
      Interceptor.attach(target,{
        onEnter(a){if(phase!=='check')return;this.contextRow={check_index:checkIndex,target:checkTarget};this.percent=a[1];this.count=a[2];this.reports=a[3];this.code=a[4];},
        onLeave(r){if(!this.contextRow)return;try{
          const count=this.count.readS32(),rows=[];if(count<0||count>10000)throw new Error('backend report count');
          const data=this.reports.readPointer();
          if(!data.isNull())for(let i=0;i<count;i++)rows.push(backendReport(data.add(i*68)));
          send({event:'backend-check-progress',serial:serial++,...this.contextRow,hresult:r.toInt32(),code:this.code.readU32(),percent:this.percent.readS32(),
            count,reports_present:!data.isNull(),reports:rows});
        }catch(e){send({event:'observation-error',error:String(e)});}}
      });
    }catch(e){send({event:'observation-error',error:String(e)});}
   }});
   Interceptor.attach(m.base.add(0x8e48),{
    onEnter(a){if(phase!=='check')return;try{this.row={check_index:checkIndex,target:checkTarget,report:backendReport(a[0])};this.code=a[2];}catch(e){send({event:'observation-error',error:String(e)});}},
    onLeave(r){if(!this.row||r.toInt32()>=0)return;try{send({event:'diagnostic-projection-failure',serial:serial++,...this.row,hresult:r.toInt32(),code:this.code.readU32()});}catch(e){send({event:'observation-error',error:String(e)});}}
   });
  }
  if(name!=='dzdataabs_workspace.dll')return;
  Interceptor.attach(m.base.add(0x8663c),{
    onEnter(a){phase=checkIndex<0?'publish-before-check':'publish-before-export';send({event:'publish',serial:serial++,phase:phase,target:id(a)});}
  });
  Interceptor.attach(m.base.add(0x78d08),{
    onEnter(a){
      try{
        this.row={event:'workspace-pcode-read',serial:serial++,phase:phase,check_index:checkIndex,
          check_target:checkTarget,target:id(a),caller:loc(this.returnAddress),
          stack:Thread.backtrace(this.context,Backtracer.ACCURATE).slice(0,12).map(loc)};
        this.sizes=[a[13],a[15],a[17]];this.buffers=[a[14],a[16],a[18]];this.code=a[19];
        this.row.requested_sizes=this.sizes.map(p=>p.isNull()?null:p.readS32());
      }catch(e){send({event:'observation-error',error:String(e)});}
    },
    onLeave(r){if(!this.row)return;try{
      const code=this.code.readS32();
      this.row.hresult=r.toInt32();this.row.code=code;
      this.row.buffers=this.sizes.map((p,i)=>{const n=p.isNull()?null:p.readS32();return {size:n,
        raw_hex:code===0&&r.toInt32()>=0&&!this.buffers[i].isNull()&&n!==null?hex(this.buffers[i],n):null};});
      send(this.row);
    }catch(e){send({event:'observation-error',error:String(e)});}}
  });
}});

let projectionDepth=0;
const lookupObservers=new Set();
function textBstr(p){if(p.isNull())return null;const n=p.sub(4).readU32();if(n>131072||n%2)throw new Error('BSTR bound');return p.readUtf16String(n/2);}
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='dzdataabs_compileradapter.dll')return;
 Interceptor.attach(m.base.add(0x8e48),{
  onEnter(a){projectionDepth++;try{
   const workspace=this.context.ecx.add(0x18).readPointer();
   const fn=workspace.readPointer().add(0x6f8).readPointer();
   if(!lookupObservers.has(fn.toString())){
    lookupObservers.add(fn.toString());
    send({event:'projection-lookup-observer',location:loc(fn)});
    Interceptor.attach(fn,{
     onEnter(a){if(!projectionDepth)return;try{
      this.code=a[16];this.output=a[15];
      this.row={event:'projection-object-lookup',check_index:checkIndex,caller:loc(this.returnAddress),
       parent:id(a),kind:a[13].toUInt32(),name:textBstr(a[14])};
     }catch(e){send({event:'observation-error',error:String(e)});}},
     onLeave(r){if(!this.row)return;try{send({...this.row,hresult:r.toInt32(),code:this.code.readU32(),
      output_id:r.toInt32()>=0?Array.from({length:12},(_,i)=>this.output.add(i*4).readU32()):null});
     }catch(e){send({event:'observation-error',error:String(e)});}}
    });
   }
  }catch(e){send({event:'observation-error',error:String(e)});}},
  onLeave(){projectionDepth--;}
 });
 for(const rva of [0x3def,0x1e27])Interceptor.attach(m.base.add(rva),{
  onEnter(a){if(!projectionDepth)return;this.code=a[2];this.row={event:'projection-argument-transfer',rva:'0x'+rva.toString(16),check_index:checkIndex};},
  onLeave(r){if(!this.row)return;try{send({...this.row,hresult:r.toInt32(),code:this.code.readU32()});}catch(e){send({event:'observation-error',error:String(e)});}}
 });
}});

let ownedSourceCheckDepth=0;
const sourceDispatches=new Set();
const nativeSourceDispatches=new Set();
let ownedSourceCheckEver=false;
let ownedExpectedSelectionNames=[];
function sourceSelections(p,count){
 if(count<0||count>32)throw new Error('source unit count bound');
 const units=[];
 for(let i=0;i<count;i++){
  const unit=p.add(i*12), n=unit.add(4).readS32(), selections=unit.add(8).readPointer();
  if(n<0||n>32)throw new Error('source selection count bound');
  const rows=[];
  for(let j=0;j<n;j++)rows.push({row:selections.add(j*8).readS32(),
    name:textBstr(selections.add(j*8+4).readPointer())});
  units.push({kind:unit.readS32(),count:n,rows});
 }
 return units;
}
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='dzdataabs_compileradapter.dll')return;
 Interceptor.attach(m.base.add(0x13d3b),{
  onEnter(a){ownedSourceCheckDepth++;ownedSourceCheckEver=true;try{
   const units=sourceSelections(a[3],a[2].toInt32());
   ownedExpectedSelectionNames=units.flatMap(unit=>unit.rows.map(row=>row.name));
   send({event:'public-source-check-enter',report_kind:a[1].toInt32(),count:a[2].toInt32(),units});
  }catch(e){send({event:'observation-error',phase:'source-check-enter',error:String(e)});}},
  onLeave(r){send({event:'public-source-check-return',hresult:r.toInt32()});ownedSourceCheckDepth--;}
 });
 Interceptor.attach(m.base.add(0x13a2a),{
  onEnter(){this.owned=ownedSourceCheckDepth>0;},
  onLeave(r){if(!this.owned)return;try{
   const object=r.readPointer(),table=object.readPointer(),check=table.add(12).readPointer();
   send({event:'source-check-dispatch-selected',object:object.toString(),vtable:loc(table),check:loc(check)});
   if(sourceDispatches.has(check.toString()))return;
   sourceDispatches.add(check.toString());
   Interceptor.attach(check,{
    onEnter(a){if(!ownedSourceCheckDepth)return;try{
     this.code=a[3];send({event:'source-check-implementation-enter',address:loc(check),
      self:this.context.ecx.toString(),report_kind:a[0].toInt32(),count:a[1].toInt32(),
      units:sourceSelections(a[2],a[1].toInt32())});
     const backend=this.context.ecx.add(0x14).readPointer(),vtable=backend.readPointer(),
      nativeCheck=vtable.add(36).readPointer(),progress=vtable.add(44).readPointer();
     send({event:'source-check-backend-selected',vtable:loc(vtable),check:loc(nativeCheck),progress:loc(progress)});
     if(!nativeSourceDispatches.has(nativeCheck.toString())){
      nativeSourceDispatches.add(nativeCheck.toString());
      Interceptor.attach(nativeCheck,{
       onEnter(a){if(!ownedSourceCheckDepth)return;this.code=a[4];try{
        const count=a[2].toInt32(),units=[];
        if(count<0||count>32)throw new Error('backend source count bound');
        let expectedIndex=0;
        for(let i=0;i<count;i++){
         const unit=a[3].add(i*12),n=unit.add(4).readS32(),selections=unit.add(8).readPointer(),rows=[];
         if(n<0||n>32)throw new Error('backend source selection bound');
         for(let j=0;j<n;j++){
          const expected=ownedExpectedSelectionNames[expectedIndex++];
          if(typeof expected!=='string'||expected.length>128||/[^\x00-\x7f]/.test(expected))
           throw new Error('owned ASCII prefix bound');
          const name=selections.add(j*8+4).readPointer();
          rows.push({row:selections.add(j*8).readS32(),name_prefix_hex:hex(name,expected.length),
           prefix_expected:expected,terminator_hex:hex(name.add(expected.length),1)});
         }
         units.push({kind:unit.readS32(),count:n,rows});
        }
        send({event:'source-check-backend-enter',address:loc(nativeCheck),
          report_kind:a[1].toInt32(),count,units});
       }catch(e){send({event:'observation-error',phase:'source-backend-enter',error:String(e)});}},
       onLeave(r){if(!this.code)return;send({event:'source-check-backend-return',hresult:r.toInt32(),code:this.code.readU32()});}
      });
      Interceptor.attach(progress,{
       onEnter(a){if(!ownedSourceCheckEver||phase==='check')return;
        this.percent=a[1];this.count=a[2];this.reports=a[3];this.code=a[4];},
       onLeave(r){if(!this.code)return;try{
        const count=this.count.readS32(),data=this.reports.readPointer(),rows=[];
        if(count<0||count>10000)throw new Error('source report count bound');
        if(!data.isNull())for(let i=0;i<count;i++)rows.push(backendReport(data.add(i*68)));
        send({event:'source-check-backend-progress',hresult:r.toInt32(),code:this.code.readU32(),
          percent:this.percent.readS32(),count,reports:rows});
       }catch(e){send({event:'observation-error',phase:'source-backend-progress',error:String(e)});}}
      });
     }
    }catch(e){send({event:'observation-error',phase:'source-check-implementation',error:String(e)});}},
    onLeave(r){if(!this.code)return;try{send({event:'source-check-implementation-return',
     hresult:r.toInt32(),code:this.code.readU32()});}catch(e){send({event:'observation-error',error:String(e)});}}
   });
  }catch(e){send({event:'observation-error',phase:'source-check-dispatch',error:String(e)});}}
 });
}});

function ownedSourceName(p){
 if(p.isNull())return null;
 const bytes=[];
 for(let i=0;i<256;i++){
  const b=p.add(i).readU8();
  if(b===0)return String.fromCharCode(...bytes);
  bytes.push(b);
 }
 throw new Error('source name exceeds bounded terminated string');
}
function ownedNarrowUnit(p){
 const kind=p.readS32(),count=p.add(4).readS32(),data=p.add(8).readPointer(),rows=[];
 if(count<0||count>32)throw new Error('owned narrow unit count bound');
 if(!data.isNull())for(let i=0;i<count;i++)rows.push({
  row:data.add(i*8).readS32(),name:ownedSourceName(data.add(i*8+4).readPointer())});
 return {kind,count,rows,pointer:p.toString()};
}
const ownedSourceSites=new Set();
function ownedAttachSourceModule(m){
 if(m.name.toLowerCase()==='dzdataabs_compileradapter.dll')Interceptor.attach(m.base.add(0x2cac),{
  onEnter(){if(!ownedSourceCheckDepth)return;this.owned=true;try{
   this.owner=this.context.ecx;
   const count=this.owner.add(8).readS32(),data=this.owner.add(4).readPointer(),units=[];
   if(count<0||count>32)throw new Error('source cleanup unit count bound');
   if(!data.isNull())for(let i=0;i<count;i++)units.push(ownedNarrowUnit(data.add(i*12)));
   send({event:'native-source-owner-cleanup-enter',count,units});
  }catch(e){send({event:'observation-error',phase:'source-owner-cleanup-enter',error:String(e)});}},
  onLeave(){if(this.owned)send({event:'native-source-owner-cleanup-return',
   units_pointer_after:this.owner.add(4).readPointer().toString()});}
 });
 if(m.name.toLowerCase()==='dzdataabs_compiler_iec.dll')Interceptor.attach(m.base.add(0x6852),{
  onEnter(a){this.code=a[3];send({event:'native-source-compiler-initialize',cpu:a[2].toInt32(),
   temporary_path:ownedSourceName(a[1])});},
  onLeave(r){send({event:'native-source-compiler-initialize-return',hresult:r.toInt32(),
   code:this.code.readU32()});}
 });
 if(m.name.toLowerCase()==='dzdataabs_compiler_iec.dll')Interceptor.attach(m.base.add(0x6f2c),{
  onEnter(){try{
   const target=m.base.add(0x10120).readPointer();
   send({event:'native-source-iat-target',target:loc(target),address:target.toString(),
    prefix_hex:hex(target,20)});
   const converter=Process.findModuleByAddress(target);
   if(!converter||converter.name.toLowerCase()!=='dzdataabs_sicconverter_iec.dll')
    throw new Error('resolved source Check converter differs');
   ownedAttachSourceModule(converter);
   Interceptor.attach(target,{
    onEnter(a){try{send({event:'native-source-iat-check-enter',address:target.toString(),
     count:a[0].toInt32(),units_pointer:a[1].toString()});
    }catch(e){send({event:'observation-error',phase:'source-iat-check-enter',error:String(e)});}},
    onLeave(r){send({event:'native-source-iat-check-return',code:r.toUInt32()});}
   });
   send({event:'native-source-active-modules',modules:Process.enumerateModules()
    .filter(row=>/dataabs|compiler|converter/i.test(row.name))
    .map(row=>({name:row.name,path:row.path,base:row.base.toString()}))});
   send({event:'native-source-resolved-imports',imports:m.enumerateImports()
    .filter(row=>row.name&&row.name.startsWith('?Check@CDZDataABS_ProcessManager@'))
    .map(row=>({name:row.name,module:row.module,address:row.address?loc(row.address):null}))});
  }catch(e){send({event:'observation-error',phase:'native-source-module-inventory',error:String(e)});}}
 });
 if(m.name.toLowerCase().includes('sicconverter')||m.name.toLowerCase().includes('datamanager'))
  send({event:'native-source-module',name:m.name,path:m.path,base:m.base.toString()});
 if(m.name.toLowerCase()!=='dzdataabs_sicconverter_iec.dll')return;
 if(ownedSourceSites.has(m.base.toString()))return;
 ownedSourceSites.add(m.base.toString());
 send({event:'native-source-sites',worker:loc(m.base.add(0x2e8f6)),
  worker_prefix_hex:hex(m.base.add(0x2e8f6),16),reject_prefix_hex:hex(m.base.add(0x2f131),8)});
 const check=m.enumerateExports().find(row=>row.name.startsWith('?Check@CDZDataABS_ProcessManager@'));
 if(check)Interceptor.attach(check.address,{
  onEnter(a){this.owned=ownedSourceCheckEver;try{
   send({event:'native-source-process-check-enter',owned:this.owned,address:loc(check.address),
    count:a[0].toInt32(),units_pointer:a[1].toString()});
  }catch(e){send({event:'observation-error',phase:'process-check-enter',error:String(e)});}},
  onLeave(r){if(this.owned)send({event:'native-source-process-check-return',code:r.toUInt32()});}
 });
 Interceptor.attach(m.base.add(0x2e8f6),{
  onEnter(a){if(!ownedSourceCheckEver)return;this.owned=true;try{
   const count=a[0].toInt32(),units=[];
   if(count<0||count>32)throw new Error('worker unit count bound');
   for(let i=0;i<count;i++)units.push(ownedNarrowUnit(a[1].add(i*12)));
   send({event:'native-source-worker-enter',count,units});
  }catch(e){send({event:'observation-error',phase:'source-worker-enter',error:String(e)});}},
  onLeave(r){if(this.owned)send({event:'native-source-worker-return',code:r.toUInt32()});}
 });
 Interceptor.attach(m.base.add(0x2f131),{onEnter(){if(!ownedSourceCheckEver)return;try{
  const frame=this.context.ebp,array=frame.sub(0x28),size=array.add(8).readS32(),
   data=array.add(4).readPointer(),index=this.context.ebx.toInt32();
  if(size<0||size>32||index<0||index>=size)throw new Error('source rejection array bounds');
  const unit=data.add(index*4).readPointer();
  send({event:'native-source-shape-rejection',index,size,unit:ownedNarrowUnit(unit)});
 }catch(e){send({event:'observation-error',phase:'source-shape-rejection',error:String(e)});}}});
 Interceptor.attach(m.base.add(0x251cf),{
  onEnter(a){if(!ownedSourceCheckEver)return;this.owned=true;try{
   const slots={};
   for(const offset of [0x14,0x18]){
    const manager=this.context.ecx.add(offset).readPointer(),vtable=manager.readPointer(),methods={};
    for(const method of [0x80,0x110,0x114,0x118,0x128])methods['0x'+method.toString(16)]=loc(vtable.add(method).readPointer());
    slots['0x'+offset.toString(16)]={vtable:loc(vtable),methods};
   }
   send({event:'native-source-unit-enter',unit:ownedNarrowUnit(this.context.esp.add(4)),managers:slots});
  }catch(e){send({event:'observation-error',phase:'source-unit-enter',error:String(e)});}},
  onLeave(r){if(this.owned)send({event:'native-source-unit-return',code:r.toUInt32()});}
 });
}
const ownedSourceModuleObserver=Process.attachModuleObserver({onAdded:ownedAttachSourceModule});

Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='kernelbase.dll')return;
 const target=m.findExportByName('OutputDebugStringW');
 if(!target)throw new Error('Owned drain gate export unavailable');
 Interceptor.attach(target,{onEnter(a){
  if(a[0].isNull())return;
  if(a[0].readUtf16String(32)==='GXW_OWNED_DIAGNOSTIC_DRAIN_READY')
   send({event:'owned-diagnostic-drain-ready'});
 }});
}});
