"""Properties of evidence classification; records here are synthetic witnesses."""
from pathlib import Path
from copy import deepcopy
import argparse
import json
import sys
import traceback

P = Path(__file__).resolve().parent
ROOT = P.parents[3]
sys.path[:0] = [str(P / 'skill-trial-20261002-v1/python-deps'), str(ROOT / 'research')]
from hypothesis import given, settings, strategies as st
from program_check_evidence import analyze_check


def identity(index):
    return [1, 0, 1 + index, *([0] * 9)]


def case(count):
    collection = identity(4096)
    targets = [identity(index) for index in range(count)]
    generated = {tuple(target): (bytes([index + 1]), b'linked', b'map')
                 for index, target in enumerate(targets)}
    events = [dict(operation='Compiler.Build', hresult=0, code=0),
        dict(operation='Progress', percent=100, count=0, reports=[]),
        dict(operation='Workspace.UpdatePCodeBeforeProgramCheck', hresult=0, code=0),
        dict(operation='Workspace.GetProgramCheckCollection', hresult=0, code=0),
        dict(operation='InventoryCount', id=collection, count=count)]
    events += [dict(operation='NativeObject', id=target, parent=collection) for target in targets]
    observations = []
    for index, target in enumerate(targets):
        events += [dict(operation='ProgramCheckTarget', id=target),
            dict(operation='ProgramCheckProgress', percent=100, count=0, reports=[])]
        observations += [dict(event='workspace-pcode-read', phase='check', serial=index,
            check_target=target, target=target, hresult=0, code=0, requested_sizes=[1,6,3],
            buffers=[dict(size=len(raw), raw_hex=raw.hex()) for raw in generated[tuple(target)]]),
            dict(event='backend-check-progress', target=target, hresult=0, code=0, percent=100, reports=[])]
    events += [dict(operation='ProgramCheckCompleted', targets=count, rejected=False)]
    selection = dict(status='verified', source_bytes_current=True, configuration_bytes_current=True,
                     selected_sources=['POU_' + str(i) for i in range(count)], empty_task=False)
    return events, observations, generated, selection


COUNTS = {'positive': 0, 'foreign_target': 0, 'compile_rejection': 0,
          'source_only_completion': 0}


@settings(max_examples=30, deadline=None, derandomize=True, database=None)
@given(count=st.integers(min_value=1,max_value=6))
def positive(count):
    events, observations, generated, selection = case(count)
    actual = analyze_check(events, observations, generated, selection=selection)
    assert actual['current_source_check'] == 'established', actual['public_check']
    assert actual['public_check']['status'] == 'passed'
    COUNTS['positive'] += 1


@settings(max_examples=80, deadline=None, derandomize=True, database=None)
@given(count=st.integers(min_value=1,max_value=6), foreign=st.integers(min_value=100,max_value=1000))
def foreign_target(count, foreign):
    events, observations, generated, selection = case(count)
    old, new = identity(0), identity(foreign)
    generated[tuple(new)] = generated[tuple(old)]
    for event in events:
        if event.get('operation') == 'ProgramCheckTarget' and event['id'] == old:
            event['id'] = new
    for observation in observations:
        if observation.get('target') == old:
            observation['target'] = new
        if observation.get('check_target') == old:
            observation['check_target'] = new
    actual = analyze_check(events, observations, generated, selection=selection)
    assert actual['public_check']['completed'] is False, {
        'public_check': actual['public_check'], 'targets': actual['targets'],
        'correspondence': actual['checker_resources']['correspondence']}
    assert actual['current_source_check'] == 'not_established'
    COUNTS['foreign_target'] += 1


@settings(max_examples=60, deadline=None, derandomize=True, database=None)
@given(count=st.integers(min_value=1,max_value=6), error_at_end=st.booleans())
def compile_rejection(count, error_at_end):
    events, observations, generated, selection = case(count)
    report = dict(kind=2, code=0x500c5057, name='POU_0', instance='POU_0')
    if error_at_end:
        events[1]['reports'] = [report]
        events[1]['count'] = 1
    else:
        events.insert(1, dict(operation='Progress', percent=0, count=1, reports=[report]))
    actual = analyze_check(events, observations, generated, selection=selection)
    assert actual['current_source_check'] == 'not_established', {
        'compilation': actual['compilation'], 'public_check': actual['public_check'],
        'current_source_check': actual['current_source_check']}
    COUNTS['compile_rejection'] += 1


@settings(max_examples=60, deadline=None, derandomize=True, database=None)
@given(count=st.integers(min_value=1,max_value=6), warning=st.booleans(),
       finished_operation=st.sampled_from(['PublicSourceCheckCompleted',
           'SourceCheck.NativeExecutionFinished']))
def source_only_completion(count, warning, finished_operation):
    events, observations, generated, selection = case(count)
    events = [row for row in events if not row.get('operation','').startswith('ProgramCheck')]
    events += [dict(operation='Compiler.SourceCheck',hresult=0,code=0),
        dict(operation='SourceCheckProgress',percent=100,count=int(warning),
            reports=[dict(kind=3,code=0x500c2034,name='POU_0')] if warning else []),
        dict(operation=finished_operation,progress=100,rejected=False,public_check_promoted=False)]
    for row in observations:
        if row['event']=='workspace-pcode-read':
            row['phase']='source-check'
        if row['event']=='backend-check-progress':
            row['event']='original-source-check-reports'
    actual = analyze_check(events, observations, generated, selection=selection)
    assert actual['public_check']['completed'] is False, actual['public_check']
    assert actual['current_source_check']=='not_established', actual
    COUNTS['source_only_completion'] += 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', type=Path)
    args = parser.parse_args()
    sys.stdout.reconfigure(encoding='utf-8')
    args.directory.mkdir(exist_ok=False)
    (args.directory / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    failures = []
    for check in [positive, foreign_target, compile_rejection, source_only_completion]:
        try:
            check()
        except Exception:
            message = traceback.format_exc()
            (args.directory / (check.__name__ + '-failure.txt')).write_text(message, encoding='utf-8')
            failures.append(check.__name__)
            print(message, flush=True)
    result = dict(counts=COUNTS, failures=failures,
                  scope='generated evidence-classifier records; not native execution')
    (args.directory / 'result.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps(result), flush=True)
    return 2 if failures else 0


if __name__ == '__main__':
    raise SystemExit(main())
