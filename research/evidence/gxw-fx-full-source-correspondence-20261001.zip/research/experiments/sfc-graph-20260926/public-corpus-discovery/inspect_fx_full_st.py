"""Independent FX3G listing/width and full compiler-source reference inventory."""
from pathlib import Path
import base64
import collections
import json
import os
import struct
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[4];P=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research'),str(P)]
from gxw.token_pou import parse_token_region
from gxw.token_listing import decode_token_program
from gxw.compiler_tables import parse_compiler_tables
from native_gxw_tokens import native_il_records,listing_records,canonical_record
from inspect_native_st_references import read_events,REF,resolve,b64,source_identity
from gxw.lossless import inspect_project
from gxw.text_pou import parse_st_pou


def save(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=True)+'\n',encoding='utf-8')


def verify(native):
    directory=native.parent/'independent-fx-reader';directory.mkdir(exist_ok=True)
    if any(directory.iterdir()):raise FileExistsError('existing reader evidence must not be overwritten')
    raw=(native/'pcode-0-0.bin').read_bytes();program=parse_token_region(raw,0,len(raw))
    listing=decode_token_program(program,profile='fx3u',text_encoding='cp936')
    if listing.gaps or program.reconstruct()!=raw:raise ValueError('lexical reading gap')
    records=list(listing.records)
    requests=[dict(id=0,mode='decode',input_base64=b64(raw+b'\0'))]
    requests+=[dict(id=i+1,mode='steps',input_base64=b64(b''.join(t.raw for t in row.tokens)),
        expected=row.step_width,byte_offset=row.tokens[0].offset) for i,row in enumerate(records)]
    native_result=json.loads((native.parent/'native-correspondence.json').read_text(encoding='utf-8'))
    errors=[d for d in native_result['diagnostics'] if d['kind']==2]
    errors_at={d['step'] for d in errors}
    requests+=[dict(id=len(requests)+i,mode='steps',input_base64=b64(raw[:row.tokens[0].offset]),
        expected=row.step,byte_offset=row.tokens[0].offset,prefix=True)
        for i,row in enumerate(row for row in records if row.step in errors_at)]
    save(directory/'before-native.json',dict(configuration_source=str(P/'fx3g-native-configuration/comparison.json'),
        cpu=521,mode=0,versions=[],converter_version='15.31',requests=requests))
    (directory/'requests.tsv').write_text('\n'.join(f'{r["id"]}\t{r["mode"]}\t{r["input_base64"]}' for r in requests)+'\n',encoding='ascii')
    source=directory/'FXSourceStepOracle.cs';source.write_bytes((P/source.name).read_bytes());exe=directory/'FXSourceStepOracle.exe'
    build=subprocess.run([str(Path(os.environ['WINDIR'])/'Microsoft.NET/Framework/v4.0.30319/csc.exe'),'/nologo','/platform:x86','/out:'+str(exe),str(source)],capture_output=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
    (directory/'build.txt').write_bytes(build.stdout+build.stderr)
    if build.returncode!=0:raise RuntimeError('helper build failed')
    run=subprocess.run([str(exe),'D:/GXWORKS2/Easysocket/CodeGenerator/ECCodeGeneratorFX2.dll',str(directory/'requests.tsv'),str(directory/'outputs.jsonl')],capture_output=True,timeout=45,creationflags=subprocess.CREATE_NO_WINDOW)
    (directory/'stdout.bin').write_bytes(run.stdout);(directory/'stderr.bin').write_bytes(run.stderr);save(directory/'process.json',dict(returncode=run.returncode))
    if run.returncode!=0:raise RuntimeError('native reader failed; evidence retained')
    answers=[json.loads(x) for x in (directory/'outputs.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    if len(answers)!=len(requests) or any(r['id']!=a['id'] or a['code']!=0 for r,a in zip(requests,answers,strict=True)):raise ValueError('native response incomplete')
    il=base64.b64decode(answers[0]['output_base64']);(directory/'native-il.bin').write_bytes(il)
    actual=native_il_records(il,encoding='cp936');expected=listing_records(listing)
    left,right=[canonical_record(r) for r in expected],[canonical_record(r) for r in actual]
    comparisons=[dict(id=r['id'],offset=r['byte_offset'],expected=r['expected'],native=a['native_steps'],equal=r['expected']==a['native_steps'],prefix=r.get('prefix',False)) for r,a in zip(requests[1:],answers[1:],strict=True)]
    save(directory/'native-listing.json',actual);save(directory/'step-comparison.json',comparisons)
    differences=[dict(index=i,ours=left[i] if i<len(left) else None,native=right[i] if i<len(right) else None) for i in range(max(len(left),len(right))) if i>=len(left) or i>=len(right) or left[i]!=right[i]]
    save(directory/'listing-differences.json',differences)
    observations=dict(raw_bytes=len(raw),lexical_records=len(records),native_records=len(actual),
        native_decode_consumed=answers[0]['size'],whole_listing_exact=not differences,
        individual_step_queries=len(records),individual_step_matches=sum(c['equal'] for c in comparisons if not c['prefix']),
        error_prefix_queries=sum(c['prefix'] for c in comparisons),error_prefix_matches=sum(c['equal'] and c['prefix'] for c in comparisons))
    save(directory/'summary.json',observations)
    if differences or not all(c['equal'] for c in comparisons):raise ValueError('independent native reading differs; retained')
    return listing,observations


def fx_sink_operand(operand):
    """Measured formatting only; retain the native bytes and modifier flags."""
    raw=bytes.fromhex(operand['raw'])
    if len(raw)!=25 or raw[16:20]!=bytes(4) or raw[24] not in (0,16):
        raise ValueError('outside observed FX operand framing')
    kind=struct.unpack_from('<I',raw,20)[0]
    families={0x2754:'T',0x21d4:'T',0x24d:'K4M',
        **{ord(s):s for s in 'PMKDZHRVEI'}}
    if kind not in families:raise ValueError('outside observed FX operand family')
    number=struct.unpack_from('<q',raw,8)[0]
    family=families[kind]
    if family=='E':text=family+format(struct.unpack_from('<d',raw,8)[0],'.15g')
    elif family=='H':
        # The two negative native H operands in this capture are DWORD -2.
        # This formatter does not infer the size of an arbitrary H constant.
        if number<0:
            if number!=-2:raise ValueError('unmeasured negative FX hex constant')
            number+=2**32
        text=family+format(number,'X')
    else:text=family+str(number)
    index=None
    if raw[:8]!=bytes(8):
        index_kind,index=struct.unpack_from('<II',raw)
        valid_z=index_kind==ord('Z') and 0<=index<=16 and family in ('D','R','K4M')
        valid_v=index_kind==ord('V') and index==0 and family=='K4M'
        if not (valid_z or valid_v):
            raise ValueError('outside measured FX indexed operand')
        text+=chr(index_kind)+str(index)
    return dict(text=text,kind_code=kind,number=number,index=index,
        flags=raw[24],raw_base64=b64(raw),handling='observed-FX-formatting')


def inventory(native):
    """Match whole emitted groups, then rebase native physical source points.

    The compiler emits outlined bodies before the final linker arranges tasks
    and functions. Equal record counts do not make an event-order zip valid.
    Each complete group must have one exact, disjoint final-code occurrence.
    """
    trace=read_events(native)
    if any('error' in r.get('event','') for r in trace):
        raise ValueError('trace observation errors must remain failures')
    oracle=json.loads((native.parent/'independent-fx-reader/summary.json').read_text(encoding='utf-8'))
    if not oracle['whole_listing_exact'] or oracle['individual_step_matches']!=oracle['lexical_records']:
        raise ValueError('whole FX native listing/step validation unavailable')
    raw=(native/'pcode-0-0.bin').read_bytes()
    listing=decode_token_program(parse_token_region(raw,0,len(raw)),profile='fx3u',text_encoding='cp936')
    final=[canonical_record(row) for row in listing_records(listing)]
    tables={};compilations={};sources=[];incoming=collections.defaultdict(list)
    for r in trace:
        if r.get('event')!='sink-compile':continue
        cid=r['compile_id'];t=parse_compiler_tables(bytes.fromhex(r['symbolic_data']))
        if t.reconstruct()!=t.raw:raise ValueError('symbol-table roundtrip differs')
        tables[cid]=t;compilations[cid]=dict(names=[n['latin1'] for n in r['names']])
        for s in r['sources']:
            source=bytes.fromhex(s['raw'])
            # Outlined ST starts with FOREIGN_NET label lines in this project.
            if b'ST_BODY\r\n' not in source:continue
            refs=[];segments=[];cursor=0
            for match in REF.finditer(source):
                tag=match[1].decode('ascii');offset=int(match[2])
                segments.extend((source[cursor:match.start()],match[0]));cursor=match.end()
                ref=dict(spelling=match[0].decode('ascii'),start=match.start(),end=match.end())
                if tag=='D' and offset==999999:
                    ref.update(handling='generated-source-point-sentinel')
                else:
                    try:
                        ref.update(binding=resolve(t,tag,offset),handling='resolved')
                        if tag=='D':
                            b=ref['binding'];key=(cid,b['network'],b['line'],b['parent_pou_offset'],b['expansion_offset'])
                            incoming[key].append(ref)
                    except (ValueError,KeyError,IndexError) as e:
                        ref.update(handling='opaque-preserved',gap=str(e))
                refs.append(ref)
            segments.append(source[cursor:])
            if b''.join(segments)!=source:raise ValueError('normalized source reconstruction differs')
            sources.append(dict(compile_id=cid,name=s['name']['latin1'],raw_base64=b64(source),
                segments_base64=[b64(v) for v in segments],references=refs))
    originals={};original_gaps=[]
    for s in inspect_project((native/'input.gxw').read_bytes()).streams:
        name=s.logical_name or ''
        if name.endswith(('.Program.pou','.lnb')):
            try:originals[name]=parse_st_pou(s.raw).text.splitlines()
            except ValueError as e:original_gaps.append(dict(name=name,gap=str(e),handling='opaque-preserved'))

    def physical(r):
        data=bytes.fromhex(r['data']);ui=bytes.fromhex(r['user_info'])
        if len(data)!=12 or len(ui)!=8:raise ValueError('source position widths changed')
        network,line,pou=struct.unpack('<iii',data);expansion=struct.unpack_from('<i',ui,4)[0]
        loc=dict(network=network,line=line,parent_pou_offset=pou,expansion_offset=expansion)
        identity=source_identity(tables[r['compile_id']],loc)
        candidates=[dict(stream=name,line=line,text=lines[line]) for name,lines in originals.items()
            if name.startswith(identity['definition']+'.Program') and 0<=line<len(lines)]
        key=(r['compile_id'],network,line,pou,expansion)
        return dict(sequence=r['sequence'],compile_id=r['compile_id'],native_offset=r['requested_offset'],
            caller=r['caller'],data_hex=r['data'],user_info_hex=r['user_info'],location=loc,
            identity=identity,source_candidates=candidates,
            incoming_refs=[ref['spelling'] for ref in incoming.get(key,[])])

    groups=collections.defaultdict(list);latest={};markers=[];finalizers=[]
    for r in trace:
        event=r.get('event')
        if event=='source-point-read' and r['result']==1 and r['user_info'] is not None:
            if r['caller']['rva']=='0x701ec':
                m=physical(r);markers.append(m);latest[r['compile_id']]=m
            elif r['caller']['rva']=='0x24d83':
                m=physical(r);m['relative_native_step']=struct.unpack('<i',bytes.fromhex(r['user_info'])[:4])[0]
                finalizers.append(m)
        if event=='sink-record':
            views=[fx_sink_operand(o) for o in r['operands']];args=[o['text'] for o in views]
            name=r['name']['latin1']
            row=canonical_record(dict(kind='label',text=args[0]) if name in ('P','I')
                else dict(kind='instruction',op=name,args=args))
            groups[r['compile_id']].append(dict(sequence=r['sequence'],row=row,operand_views=views,
                preceding_source_point=latest.get(r['compile_id']),caller=r['caller'],field8=r['source']))
    where=collections.defaultdict(list)
    for i,row in enumerate(final):where[json.dumps(row,sort_keys=True)].append(i)
    joined=[None]*len(final);linked_groups=[];starts={}
    for cid,rows in groups.items():
        seq=[r['row'] for r in rows]
        matches=[i for i in where[json.dumps(seq[0],sort_keys=True)] if final[i:i+len(seq)]==seq]
        if len(matches)!=1:raise ValueError('whole compiler group has no unique final occurrence: '+str((cid,matches)))
        start=matches[0];starts[cid]=listing.records[start].step
        linked_groups.append(dict(compile_id=cid,first_record_index=start,record_count=len(rows),
            final_step_start=starts[cid],names=compilations[cid]['names'],unique_whole_group_match=True))
        for i,row in enumerate(rows,start):
            if joined[i] is not None:raise ValueError('overlapping compiler groups')
            token=listing.records[i]
            joined[i]=dict(record_index=i,step=token.step,byte_offset=token.tokens[0].offset,
                compiled=final[i],compile_id=cid,observed=row)
    if any(row is None for row in joined):raise ValueError('unmatched final code')
    boundaries={r['step']:r['byte_offset'] for r in joined}
    boundaries[sum(r.step_width for r in listing.records)]=len(raw)
    for m in finalizers:
        step=starts[m['compile_id']]+m['relative_native_step'];m['linked_step']=step
        m['prefix_byte_offset']=boundaries.get(step)
        if m['prefix_byte_offset'] is None:raise ValueError('native source point is not at a token boundary')
    diagnostics=[];by_step={row['step']:row for row in joined}
    for r in trace:
        if r.get('event')!='backend-check-progress':continue
        for d in r['reports']:
            if d['kind'] not in (2,3):continue
            instruction=by_step.get(d['step'])
            diagnostics.append(dict(diagnostic=d,matching_instruction=instruction))
    refs=[r for s in sources for r in s['references']]
    return dict(scope='Fresh original FX3G compile input, native instruction sink and source reads, independently decoded final PCode; offline only',
        summary=dict(compile_snapshots=len(tables),normalized_st_sources=len(sources),
            normalized_source_roundtrip_exact=True,reference_occurrences=len(refs),
            resolved_references=sum(r['handling']=='resolved' for r in refs),
            opaque_references=sum(r['handling']=='opaque-preserved' for r in refs),
            synthetic_sentinels=sum(r['handling']=='generated-source-point-sentinel' for r in refs),
            whole_compiler_groups=len(linked_groups),all_groups_unique=True,
            native_sink_instructions=len(joined),all_instructions_matched=True,
            native_operand_matches=sum(len(r['observed']['operand_views']) for r in joined),
            preceding_source_reads=len(markers),finalized_source_points=len(finalizers),
            native_check_accepted=False,errors=sum(d['diagnostic']['kind']==2 for d in diagnostics)),
        normalized_sources=sources,linked_groups=linked_groups,markers=markers,finalized_source_points=finalizers,
        joined_instructions=joined,backend_diagnostics=diagnostics,original_text_gaps=original_gaps,
        limitations=['A preceding source read is an observed physical point, not exclusive ownership of subsequent instructions.',
            'No library or root source is merged solely because it has the same definition name; multiple source candidates are retained.',
            'Formatting of native operands is bounded to this measured FX capture; opaque original fields are retained.',
            'Instruction emission and exact native decoding do not make a rejected project acceptable.',
            'Fresh DebugInformation2 is empty after this refusal; stored source ranges are not used as fresh evidence.'])


def verify_source_steps(native):
    result=json.loads((native.parent/'source-reference-correspondence.json').read_text(encoding='utf-8'))
    directory=native.parent/'independent-source-prefixes';directory.mkdir()
    raw=(native/'pcode-0-0.bin').read_bytes();positions=collections.defaultdict(list)
    for i,m in enumerate(result['finalized_source_points']):positions[m['prefix_byte_offset']].append(i)
    requests=[]
    for i,(offset,points) in enumerate(positions.items()):
        steps={result['finalized_source_points'][j]['linked_step'] for j in points}
        if len(steps)!=1:raise ValueError('one prefix has conflicting native source step values')
        requests.append(dict(id=i,offset=offset,expected=steps.pop(),point_indices=points))
    save(directory/'before-native.json',dict(cpu=521,mode=0,versions=[],converter_version='15.31',
        requests=requests,scope='Independent prefix widths at all finalized source points; no project/device interfaces'))
    (directory/'requests.tsv').write_text('\n'.join(f'{r["id"]}\tsteps\t{b64(raw[:r["offset"]])}' for r in requests)+'\n',encoding='ascii')
    source=directory/'FXSourceStepOracle.cs';source.write_bytes((P/source.name).read_bytes());exe=directory/'FXSourceStepOracle.exe'
    build=subprocess.run([str(Path(os.environ['WINDIR'])/'Microsoft.NET/Framework/v4.0.30319/csc.exe'),'/nologo','/platform:x86','/out:'+str(exe),str(source)],capture_output=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
    (directory/'build.txt').write_bytes(build.stdout+build.stderr)
    if build.returncode!=0:raise RuntimeError('source step helper build failed')
    run=subprocess.run([str(exe),'D:/GXWORKS2/Easysocket/CodeGenerator/ECCodeGeneratorFX2.dll',str(directory/'requests.tsv'),str(directory/'outputs.jsonl')],capture_output=True,timeout=60,creationflags=subprocess.CREATE_NO_WINDOW)
    (directory/'stdout.bin').write_bytes(run.stdout);(directory/'stderr.bin').write_bytes(run.stderr);save(directory/'process.json',dict(returncode=run.returncode))
    if run.returncode!=0:raise RuntimeError('source prefix oracle failed; evidence retained')
    answers=[json.loads(line) for line in (directory/'outputs.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    if len(answers)!=len(requests):raise ValueError('prefix response count differs')
    comparisons=[dict(**r,native_steps=a['native_steps'],code=a['code'],
        equal=r['id']==a['id'] and a['code']==0 and r['expected']==a['native_steps'])
        for r,a in zip(requests,answers,strict=True)]
    save(directory/'comparisons.json',comparisons)
    summary=dict(finalized_source_points=len(result['finalized_source_points']),
        distinct_prefix_queries=len(requests),exact_prefix_matches=sum(c['equal'] for c in comparisons),
        source_points_verified=sum(len(c['point_indices']) for c in comparisons if c['equal']))
    save(directory/'summary.json',summary)
    if not all(c['equal'] for c in comparisons):raise ValueError('source/native prefix correspondence differs; retained')
    return summary


if __name__=='__main__':
    native=P/'fx-original-full-st-20261001/native-1'
    if '--inventory' in sys.argv:
        result=inventory(native);output=native.parent/'source-reference-correspondence.json'
        if output.exists():raise FileExistsError(output)
        save(output,result);print(json.dumps(result['summary']),flush=True)
    elif '--source-steps' in sys.argv:
        print(json.dumps(verify_source_steps(native)),flush=True)
    else:
        listing,observations=verify(native)
        print(json.dumps(observations),flush=True)
