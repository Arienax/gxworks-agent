// Read-only FX3G token decoder and step counter. No project/device interfaces.
using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;

public static class FXSourceStepOracle {
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode)] static extern IntPtr LoadLibraryEx(string path,IntPtr file,uint flags);
    [DllImport("kernel32.dll",CharSet=CharSet.Ansi,ExactSpelling=true)] static extern IntPtr GetProcAddress(IntPtr module,string name);
    [DllImport("kernel32.dll")] static extern uint SetErrorMode(uint mode);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate IntPtr Create();
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Open(IntPtr h,int cpu,int mode);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Version(IntPtr h,int count,[In] uint[] versions);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Close(IntPtr h);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate void Destroy(IntPtr h);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Steps(IntPtr h,int size,[In] byte[] input,ref int steps);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Decode(IntPtr h,[In] byte[] input,ref int size,[Out] byte[] output,ref int capacity);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int ErrorOffset(IntPtr h,ref int offset);
    static T Export<T>(IntPtr m,string n) where T:class {
        IntPtr p=GetProcAddress(m,n);if(p==IntPtr.Zero)throw new Exception("Missing export: "+n);
        return Marshal.GetDelegateForFunctionPointer(p,typeof(T)) as T;
    }
    public static int Main(string[] args) {
        if(IntPtr.Size!=4||args.Length!=3)return 2;SetErrorMode(3);
        if(FileVersionInfo.GetVersionInfo(args[0]).FileVersion!="15.31")throw new Exception("Uninspected FX converter version");
        IntPtr m=LoadLibraryEx(args[0],IntPtr.Zero,8);if(m==IntPtr.Zero)throw new Exception("Load failed");
        Create create=Export<Create>(m,"ObjectNew");Open open=Export<Open>(m,"Open");
        Version version=Export<Version>(m,"SetVersion");Close close=Export<Close>(m,"Close");Destroy destroy=Export<Destroy>(m,"ObjectDelete");
        Steps steps=Export<Steps>(m,"GetStepSize");Decode decode=Export<Decode>(m,"ChangePToILcode");ErrorOffset error=Export<ErrorOffset>(m,"GetErrorOffset");
        IntPtr h=create();if(h==IntPtr.Zero)throw new Exception("Create failed");
        try {
            int code=open(h,521,0);if(code!=0)throw new Exception("Open: "+code);
            code=version(h,0,new uint[0]);if(code!=0)throw new Exception("Version: "+code);
            using(StreamWriter output=new StreamWriter(args[2])) {
                foreach(string line in File.ReadLines(args[1])) {
                    string[] parts=line.Split('\t');if(parts.Length!=3)throw new Exception("Request framing");
                    int id=int.Parse(parts[0]),value=0,offset=-1;byte[] raw=Convert.FromBase64String(parts[2]);
                    if(raw.Length>65536)throw new Exception("Input bound");
                    int size=raw.Length,capacity=0;byte[] buffer=new byte[0];
                    if(parts[1]=="steps")code=steps(h,size,raw.Length==0?new byte[1]:raw,ref value);
                    else if(parts[1]=="decode") {
                        if(size==0)throw new Exception("Empty decode");
                        capacity=1048576;buffer=new byte[capacity];code=decode(h,raw,ref size,buffer,ref capacity);
                    }else throw new Exception("Read-only mode only");
                    if(capacity<0||capacity>buffer.Length)throw new Exception("Output bound");
                    if(code!=0)error(h,ref offset);
                    output.WriteLine("{\"id\":"+id+",\"code\":"+code+",\"size\":"+size+",\"native_steps\":"+value+",\"error_offset\":"+offset+",\"output_base64\":\""+Convert.ToBase64String(buffer,0,code==0?capacity:0)+"\"}");output.Flush();
                }
            }
        }finally {close(h);destroy(h);}return 0;
    }
}
