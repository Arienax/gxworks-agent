"""Capture the complete original FX3G ST library program on an offline copy."""
from pathlib import Path
import json
import sys

ROOT=Path(__file__).resolve().parents[4];P=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research'),str(P)]
from probe_minimal_conditional_port_writes import streams,observe
from probe_gxw_program_check_resources import SCRIPT
from inspect_native_st_references import read_events


def save(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=True)+'\n',encoding='utf-8')


if __name__=='__main__':
    out=P/'fx-original-full-st-20261001';out.mkdir(exist_ok=False)
    original=P/'cross-family-source-holdouts/case-00/input.gxw'
    source=original.read_bytes();target=out/'input.gxw';target.write_bytes(source)
    if streams(target.read_bytes())!=streams(source):raise ValueError('copied source differs')
    save(out/'before-native.json',dict(scope='Unmodified copied FX3G project; compile/check/save only; no PLC or simulator execution',
        source=str(original),input=str(target),all_logical_payloads_byte_exact=True,
        previous_q_model_handling='unsupported CPU and general library/aggregate types; no extrapolation of Q scalar rules',
        observations_to_measure=['Complete emitted library/function/FB program rather than another isolated function variant.',
            'Native frontend/backend acceptance or original refusal diagnostics.',
            'Full normalized source, symbol snapshots and instruction sink for independent future reconstruction.']))
    trace=out/'trace.js'
    trace.write_text('(function(){\n'+(P/'native-allocation-bitmap-v2/observer.js').read_text(encoding='utf-8')+
        '\n'+(P/'trace_native_source_points.js').read_text(encoding='utf-8')+'\n})();\n(function(){\n'+SCRIPT+'\n})();\n',encoding='utf-8')
    native,result,process=observe(target,out,trace)
    events=read_events(native)
    row=dict(native=str(native),process=process,check=result['check'],backend_rejected=result['backend_check_rejected'],diagnostics=result['diagnostics'],
        sink_instructions=sum(e.get('event')=='sink-record' for e in events),
        compile_snapshots=sum(e.get('event')=='sink-compile' for e in events),
        source_point_reads=sum(e.get('event')=='source-point-read' for e in events),
        generated_buffers=[dict(file=f'pcode-{g["index"]}-{c}.bin',bytes=(native/f'pcode-{g["index"]}-{c}.bin').stat().st_size) for g in result['generated'] for c in range(3)])
    if result['check'] is not None and not result['check']['rejected']:
        reopen=out/'reopen';reopen.mkdir()
        again,checked,traced=observe(native/'native-saved.gxw',reopen,trace)
        row['reopen']=dict(native=str(again),check=checked['check'],backend_rejected=checked['backend_check_rejected'],process=traced,
            channels=[dict(**g,byte_identical=(native/g['file']).read_bytes()==(again/g['file']).read_bytes()) for g in row['generated_buffers']])
    save(out/'native-correspondence.json',row)
    print(json.dumps({k:v for k,v in row.items() if k!='diagnostics'}|dict(diagnostic_count=len(row['diagnostics'])),ensure_ascii=True),flush=True)
