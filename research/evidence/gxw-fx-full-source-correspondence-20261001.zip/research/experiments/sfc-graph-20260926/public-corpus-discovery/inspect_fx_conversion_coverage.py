"""Locate captured native conversion packets without merging ambiguous copies.

Candidate coordinates must be instruction boundaries in final PCode. Ordered
resolution is only admitted when all unique anchors have nondecreasing starts.
This measures one captured conversion path, never source semantics or the
entire ProgramCheck. Input coverage and consumed coverage remain separate.
"""
from pathlib import Path
import collections
import json
import sys

P=Path(__file__).resolve().parent;ROOT=P.parents[3]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research'),str(P)]
from gxw.token_pou import parse_token_region
from gxw.token_listing import decode_token_program


def coverage(code,calls):
    listing=decode_token_program(parse_token_region(code,0,len(code)),profile='fx3u',text_encoding='cp936')
    if listing.gaps:raise ValueError('token boundary gaps')
    boundaries={r.tokens[0].offset for r in listing.records}|{len(code)}
    rows=[]
    for c in calls:
        raw=bytes.fromhex(c['input_hex']);packet=raw[:-1] if raw[-1:]==b'\0' else raw
        candidates=[];cursor=0
        while (position:=code.find(packet,cursor))!=-1:
            if position in boundaries and position+len(packet) in boundaries:candidates.append(position)
            cursor=position+1
        rows.append(dict(id=c['id'],bytes=len(packet),return_code=c['return_code'],
            consumed=c['consumed_bytes'],all_candidates=candidates))
    anchors=[(i,r['all_candidates'][0]) for i,r in enumerate(rows) if len(r['all_candidates'])==1]
    monotone=all(left[1]<=right[1] for left,right in zip(anchors,anchors[1:]))
    for i,r in enumerate(rows):
        candidates=r['all_candidates']
        if monotone:
            lo=max((position for index,position in anchors if index<i),default=0)
            hi=min((position for index,position in anchors if index>i),default=len(code))
            candidates=[position for position in candidates if lo<=position<=hi]
        r['ordered_candidates']=candidates
        r['handling']='resolved-unique-in-ordered-trace' if len(candidates)==1 else 'ambiguous' if candidates else 'unmatched'
    intervals=[(r['ordered_candidates'][0],r['ordered_candidates'][0]+r['bytes']) for r in rows if len(r['ordered_candidates'])==1]
    union=[]
    for start,end in sorted(intervals):
        if union and start<=union[-1][1]:union[-1][1]=max(union[-1][1],end)
        else:union.append([start,end])
    records_with_packet=[i for i,r in enumerate(listing.records) if any(start<=r.tokens[0].offset and
        r.tokens[-1].offset+len(r.tokens[-1].raw)<=end for start,end in union)]
    return dict(summary=dict(program_bytes=len(code),instructions=len(listing.records),calls=len(rows),
        unique_unordered_anchors=len(anchors),anchors_nondecreasing=monotone,
        handling_counts=dict(collections.Counter(r['handling'] for r in rows)),
        resolved_packet_union_bytes=sum(end-start for start,end in union),
        instructions_in_resolved_packets=len(records_with_packet),resolved_packet_intervals=union,
        rejected_packets=sum(bool(r['return_code']) for r in rows)),packets=rows,
        limitations=['Ordered candidate resolution assumes the monotone traversal observed at the unique anchors; copied packets do not retain their original memory address.',
            'A supplied packet can overlap its neighbours and a successful call can consume only a prefix.',
            'Presence in the supplied packet is not proof of acceptance or full consumption.',
            'Absence here describes this captured conversion path, not every validation performed by GX Works2.'])


def main():
    profiles=[('original',P/'fx-original-full-st-20261001/native-1/pcode-0-0.bin',P/'fx3g-ladder-call-corpus/calls.json'),
        ('unused-bool-local',P/'fx-full-check-cascade-20261001/unused-bool-local/native-1/pcode-0-0.bin',P/'fx-full-check-cascade-20261001/unused-bool-local/calls.json'),
        ('combined',P/'fx-full-check-cascade-20261001/captured-condition/native-1/pcode-0-0.bin',P/'fx-full-check-cascade-20261001/captured-condition/calls.json')]
    output=P/'fx-full-check-cascade-20261001/conversion-coverage.json'
    if output.exists():raise FileExistsError(output)
    results=[]
    for name,code,calls in profiles:
        result=coverage(code.read_bytes(),json.loads(calls.read_text(encoding='utf-8')))
        results.append(dict(case=name,**result));print(json.dumps(dict(case=name,**result['summary'])),flush=True)
    output.write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')


if __name__=='__main__':main()
