"""Prospective isolated edits to the original full FX3G library source.

All cases are prepared before the first native run. The original refusal and
counterexamples remain separate; no unmodified source/cache payload is removed.
This experiment never executes a PLC program or opens a controller session.
"""
from dataclasses import replace
from pathlib import Path
import collections
import json
import re
import sys

ROOT=Path(__file__).resolve().parents[4];P=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research'),str(P)]
from gxw.declarations import parse_declarations,parse_structure_declarations,serialize_declarations
from gxw.text_pou import parse_st_pou
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_st_sources import replace_observed_st
from probe_gxw_program_check_resources import SCRIPT
from probe_minimal_conditional_port_writes import streams,observe

PROGRAM='PRG_MB_TEST.Program\\Modbus.lnb'
PROCESS='MB_PROCESS_50.Program\\Modbus.lnb'
LABELS='MB_PROCESS_50.Labels\\Modbus.lnl'


def save(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=True)+'\n',encoding='utf-8')


def variants(before,*,refined=False):
    program=parse_st_pou(before[PROGRAM]).text
    process=parse_st_pou(before[PROCESS]).text
    declarations=parse_declarations(before[LABELS],logical_name=LABELS)
    structure_names=[name for name in before if name.split('\\')[0]=='ST_MB_REG_50' and name.endswith('.lns')]
    if len(structure_names)!=1:raise ValueError('ambiguous channel structure')
    structure=parse_structure_declarations(before[structure_names[0]],logical_name=structure_names[0])
    if len(structure.members)!=19 or any(m.data_type not in ('BOOL','INT','WORD','DWORD') for m in structure.members):
        raise ValueError('outside observed flat channel structure')
    calls=re.findall(r'^M0 := .+;\r?$',program,re.M)
    if len(calls)!=6 or not calls[0].startswith('M0 := MB_MASTER_INIT_PORT2('):raise ValueError('protocol control source differs')
    one_protocol=program
    for line in calls[1:]:one_protocol=one_protocol.replace(line,'(* Isolated compile control: '+line.rstrip('\r')+' *)'+ ('\r' if line.endswith('\r') else ''))
    def expand_copy(match):
        indent=match[1]
        lines=[]
        for index in range(0,len(structure.members),2 if refined else len(structure.members)):
            if refined:lines.append(indent+'IF mb_xEnable OR NOT mb_xEnable THEN')
            lines.extend(indent+('    ' if refined else '')+'CHANNEL.'+m.name+' := MB_CHANNELS[iChannelID].'+m.name+';' for m in structure.members[index:index+(2 if refined else len(structure.members))])
            if refined:lines.append(indent+'END_IF;')
        return '\r\n'.join(lines)
    scalar_copy,count=re.subn(r'^([ \t]*)CHANNEL := MB_CHANNELS\[iChannelID\];',expand_copy,process,flags=re.M)
    if count!=2:raise ValueError('expected two whole-channel copies')
    predicate='CHANNEL.isRegister = FALSE AND M0Z5 <> M0Z6'
    marker='\t\t\t\t\t(* If device was changed *)'
    capture='\t\t\t\t\t_researchCoilsDiffer := M0Z5 <> M0Z6;\r\n'
    if process.count(predicate)!=1 or process.count(marker)!=1:raise ValueError('condition control source differs')
    captured=process.replace(marker,capture+marker).replace(predicate,'CHANNEL.isRegister = FALSE AND _researchCoilsDiffer')
    exemplar=next(r for r in declarations.rows if r.name=='xBit')
    row=replace(exemplar,name='_researchCoilsDiffer',record_id=max(r.record_id for r in declarations.rows)+1,
        comment='Offline experiment: capture the indexed coil comparison before the compound branch')
    labels=serialize_declarations(replace(declarations,rows=declarations.rows+(row,)))
    if [r.name for r in parse_declarations(labels,logical_name=LABELS).rows]!=[r.name for r in declarations.rows]+[row.name]:
        raise ValueError('declaration append did not roundtrip')
    combined=scalar_copy.replace(marker,capture+marker).replace(predicate,'CHANNEL.isRegister = FALSE AND _researchCoilsDiffer')
    if refined:
        captured=captured.replace('_researchCoilsDiffer','xResearchCoilsDiffer')
        combined=combined.replace('_researchCoilsDiffer','xResearchCoilsDiffer')
        labels=serialize_declarations(replace(declarations,rows=declarations.rows+(replace(row,name='xResearchCoilsDiffer'),)))
        return [
            ('guarded-channel-copy',{PROCESS:scalar_copy},{0x050c9322:4,0x050c9300:16},
                'Use two member assignments per tautological IF branch. Keep all nineteen fields and both original copy positions. Predict both ladder-size errors disappear.'),
            ('captured-indexed-condition',{PROCESS:captured,LABELS:labels},{0x050c9521:2,0x050c9300:16},
                'Use an ordinary x-prefixed local name for the indexed comparison capture. Predict all four conversion errors disappear.'),
            ('combined',{PROGRAM:one_protocol,PROCESS:combined,LABELS:labels},{},
                'Combine the previously verified single-protocol edit with guarded member copying and a separately captured BOOL comparison. Predict fresh native acceptance and saved reopen.'),
        ]
    return [
        ('single-protocol',{PROGRAM:one_protocol},{0x050c9521:2,0x050c9322:4},
            'Retain only master port 2 initialization; the sixteen duplicate-output errors should disappear.'),
        ('scalar-channel-copy',{PROCESS:scalar_copy},{0x050c9521:0,0x050c9322:4,0x050c9300:16},
            'Replace two flat whole-structure reads with explicit member assignments; the two ladder-size errors should disappear.'),
        ('captured-indexed-condition',{PROCESS:captured,LABELS:labels},{0x050c9521:2,0x050c9322:0,0x050c9300:16},
            'Capture the indexed BOOL comparison in a new local before the mixed OR condition; four ladder-conversion errors should disappear.'),
        ('combined',{PROGRAM:one_protocol,PROCESS:combined,LABELS:labels},{},
            'Combine the three isolated source edits; expect a fresh accepted compile, then save/reopen and complete channel equality.'),
    ]


def main():
    out=P/(sys.argv[1] if len(sys.argv)>1 else 'fx-full-source-edits-20261001-v1');out.mkdir()
    original=(P/'fx-original-full-st-20261001/native-1/input.gxw').read_bytes();before=streams(original)
    trace=out/'trace.js'
    trace.write_text('(function(){\n'+(P/'native-allocation-bitmap-v2/observer.js').read_text(encoding='utf-8')+
        '\n'+(P/'trace_native_source_points.js').read_text(encoding='utf-8')+'\n})();\n(function(){\n'+SCRIPT+'\n})();\n',encoding='utf-8')
    ready=[]
    for name,changes,expected,hypothesis in variants(before,refined='--refined' in sys.argv):
        directory=out/name;directory.mkdir();payloads={};source=original
        for logical,content in changes.items():
            payload=replace_observed_st(before[logical],content)[0] if isinstance(content,str) else content
            payloads[logical]=payload;source,_=patch_raw(source,logical,before[logical],payload)
            if isinstance(content,str) and parse_st_pou(payload).text!=content:raise ValueError('source text rewrite differs')
        if streams(source)!=dict(before,**payloads):raise ValueError('unrelated logical payload changed')
        (directory/'input.gxw').write_bytes(source)
        save(directory/'before-native.json',dict(scope='Original full FX3G copied project; source .lnb/.lnl edits only; offline compile, check, save and reopen',
            hypothesis=hypothesis,expected_error_counts={hex(k):v for k,v in expected.items() if v},
            changed_streams=list(payloads),unrelated_payloads_byte_exact=True,
            source_compile_status='Library status headers are preserved; the observer requests a full fresh compile.',
            texts={k:v for k,v in changes.items() if isinstance(v,str)}))
        ready.append((name,directory,expected));print(json.dumps(dict(case=name,prepared=True,expected_error_counts={hex(k):v for k,v in expected.items() if v})),flush=True)
    results=[]
    for name,directory,expected in ready:
        native,result,process=observe(directory/'input.gxw',directory,trace)
        errors=collections.Counter(d['code'] for d in result['diagnostics'] if d['kind']==2)
        check=result['check']
        row=dict(case=name,native=str(native),process=process,check=check,
            backend_rejected=result['backend_check_rejected'],diagnostics=result['diagnostics'],
            observed_error_counts={hex(k):v for k,v in errors.items()},
            expected_errors_exact=errors==collections.Counter({k:v for k,v in expected.items() if v}))
        if check is not None and not check['rejected']:
            saved=native/'native-saved.gxw'
            if not saved.exists():raise ValueError('accepted check has no saved project')
            reopen=directory/'reopen';reopen.mkdir();again,checked,traced=observe(saved,reopen,trace)
            channels=[]
            for g in result['generated']:
                for channel in range(3):
                    filename=f'pcode-{g["index"]}-{channel}.bin'
                    channels.append(dict(file=filename,bytes=(native/filename).stat().st_size,
                        byte_identical=(native/filename).read_bytes()==(again/filename).read_bytes()))
            row['reopen']=dict(native=str(again),check=checked['check'],backend_rejected=checked['backend_check_rejected'],channels=channels,process=traced)
        results.append(row);save(out/'comparison.json',results)
        print(json.dumps(dict(case=name,check=check,observed_error_counts=row['observed_error_counts'],
            expected_errors_exact=row['expected_errors_exact'],reopen=row.get('reopen'))),flush=True)


if __name__=='__main__':main()
