"""Cold replay of frozen native witnesses; no native DLL, hooks or network."""
from pathlib import Path
import collections,json,sys
p=Path(__file__).resolve().parent
sys.path.insert(0,str(p/'models'))
from source_fx_old_machine import FXOldMachine,FX1SCells
from source_fx_old_decoder import FXOldDecoder
from source_fx1s_reader import FX1SLosslessReader
from source_fx_operand_rules import Unsupported
def load(name):return json.loads((p/name).read_text(encoding='utf-8'))
emitter=FXOldMachine(load('models/fx-old-machine-tables-20261001-v1.json'),FX1SCells(load('models/fx1s-cell-tables-20261001-v1.json')))
decoder=FXOldDecoder(load('models/fx-old-decoder-tables-20261001-v1.json'))
counts=collections.Counter()
for r in load('emission-witnesses.json'):
    try:prediction=emitter.record(bytes.fromhex(r['raw']))
    except Unsupported as exc:
        if str(exc)!=r.get('gap'):raise
        counts['emission_source_gaps']+=1;continue
    if prediction!=r['prediction']:raise ValueError('Prospective emission snapshot differs')
    counts['emission_source_predictions']+=1
    if r['native'] is None:counts['pre_emission_refusals']+=1;continue
    e=r['native'];actual=prediction['emission']
    if prediction['native_cells']!=e['before'] or prediction['auxiliary']!=e['auxiliary'] or actual['words']!=e['words'] or actual['cells_after']!=e['after'] or actual['machine_output']!=e['output']:
        raise ValueError('Original emission witness differs')
    counts['native_emission_exact']+=1
    if e['words']>0:
        if emitter.width_rewrite(bytes.fromhex(r['raw']))['candidate']!=r['public_output']:raise ValueError('Raw width rewrite differs')
        counts['raw_width_rewrites_exact']+=1
for r in load('decoder-witnesses.json'):
    raw=bytes.fromhex(r['machine']);at=0;records=[];gap=None
    while at<len(raw):
        try:expected=decoder.record(raw[at:])
        except Unsupported as exc:gap=str(exc);break
        n=expected['words'] if expected['words']>0 else 1
        expected['offset']=at;expected['consumed_machine']=raw[at:at+2*n].hex();records.append(expected);at+=2*n
    predicted=r['prediction']
    if records!=predicted['records'] or at!=predicted['consumed'] or gap!=predicted.get('gap'):raise ValueError('Prospective decoder snapshot differs')
    counts['decoder_groups']+=1
    if gap:counts['decoder_source_gaps']+=1
    elif len(records)!=len(r['native']):raise ValueError('Native decoder call count differs')
    else:counts['decoder_complete_groups']+=1
    for expected,e in zip(records,r['native']):
        if expected['words']!=e['words'] or expected['cells']!=e['cells'] or expected['auxiliary']!=e['auxiliary']:
            raise ValueError('Independent machine reader differs')
        if expected['words']>0 and expected['consumed_machine']!=e['machine']:raise ValueError('Machine extent differs')
        counts['native_decoder_records_exact']+=1
    counts['native_reverse_refusals']+=r['public_code']!=0
reader=FX1SLosslessReader()
for r in load('reemission-witnesses.json'):
    raw=bytes.fromhex(r['raw']);ir=reader.read(raw,cpu=518)
    if reader.reconstruct(ir)!=raw:raise ValueError('Canonical raw partition differs')
    projected=[];gap=False
    for record in ir['records']:
        if record['critical_gap']:gap=True;break
        try:emission=emitter.record(bytes.fromhex(record['raw']))['emission']
        except Unsupported:gap=True;break
        if emission['words']<=0 or emission['machine_output'] is None:gap=True;break
        projected.append(emission['machine_output'])
    output=None if gap else ''.join(projected)
    if output!=r['expected_machine']:raise ValueError('Source canonical reemission differs')
    if output is not None and output!=r['native_machine']:raise ValueError('Public P-to-M output differs')
    counts['canonical_reemission_groups']+=1
    counts['canonical_reemission_source_gaps']+=gap
    counts['canonical_machine_roundtrip_exact']+=r['native_code']==0 and r['native_machine']==r['original_machine']
    counts['canonical_native_machine_changes']+=r['native_code']==0 and r['native_machine']!=r['original_machine']
    counts['canonical_native_reemission_refusals']+=r['native_code']!=0
print(json.dumps(dict(counts),ensure_ascii=True))
