"""Independent mode-5 machine reader from the inspected legacy decoder.

This does not import the PCode lowering or emitter. Machine bytes are retained;
canonical addresses recovered here must never replace original PCode addresses.
"""
import struct
from source_fx_operand_rules import Unsupported


class DecodeRefused(Exception):
    pass


class FXOldDecoder:
    def __init__(self,tables):
        if (tables['file_version'],tables['cpu'],tables['mode'])!=('15.31',518,5):
            raise Unsupported('Unmeasured legacy decoder context')
        self.tables=tables

    def index(self,address):
        for family in ('Z','V'):
            if address in self.tables['index_addresses'][family]:
                return family,self.tables['index_addresses'][family].index(address)
        return 'D',address

    def device(self,nibble):
        family,high=self.tables['compact_devices'][nibble]
        return chr(family),high

    @staticmethod
    def put(state,at,family,value):
        state[at+3]=ord(family)
        struct.pack_into('<H',state,at+4,value&65535)

    def word(self,state,at,first,second,double=False,tail=None):
        prefix=(first>>12)&15
        if prefix not in (8,9,10):raise DecodeRefused('Legacy operand prefix refused')
        state[at]=int(double)
        flags=255 if prefix==8 else 0x20 if prefix==9 else 0x40
        if double:
            state[at+6]=state[at+14]=255
            state[at+7]=state[at+15]=flags
        else:state[at+7]=flags
        if flags!=255:
            if (first>>8)&15 in (0,2):
                index=(second>>8)&7;second&=0xf8ff
            else:
                index=(second>>6)&7;second&=0xfe3f
            flags|=index;state[at+7]=flags
            if double:state[at+15]=flags
        lo=first&255;middle=second&255;area=second>>8
        value=lo|(middle<<8)
        if first&0x400:
            if first&0x200:
                value>>=1
                if area==0x80:
                    value=(value+8000)&65535
                    family,value=self.index(value) if flags==255 else ('D',value)
                elif area==0x82:family='T'
                elif area==0x84:
                    family='C'
                    if value&0x100:
                        value=(((value&255)>>1)+200)&255
                    else:value&=255
                elif area==0x86:family='D'
                elif area==0x88:family,value='D',(value+1000)&65535
                else:raise DecodeRefused('Legacy word area refused')
            else:
                if area>0x81:
                    group=(area>>1)&63
                    if not 1<=group<9:raise DecodeRefused('Legacy grouping selector refused')
                    state[at+6]=group
                    if double:state[at+14]=group
                if middle&0x20:family,value='M',((middle&7)<<8|lo)+1536
                else:
                    if middle>=16:raise Unsupported('Native compact table access extends beyond inspected rows')
                    family,high=self.device(middle)
                    value=8000+lo if high==31 else (high<<8)|lo
        else:
            if double:
                if first&0x800:
                    if first&0x200:raise DecodeRefused('Legacy double label/literal class refused')
                    if area not in (0x80,0x82):raise DecodeRefused('Legacy double label area refused')
                    family,value=('P' if area==0x80 else 'I'),value>>1
                else:
                    if tail is None:raise Unsupported('Missing double literal tail')
                    family='H' if first&0x200 else 'K'
                    high=(tail[0]&255)|((tail[1]&255)<<8)
                    self.put(state,at,family,value);self.put(state,at+8,family,high)
                    return
            else:
                if area==0x80:
                    family='A' if first&0x800 and first&0x200 else 'P' if first&0x800 else 'H' if first&0x200 else 'K'
                    if family=='P':value>>=1
                elif area==0x82 and (first>>8)&15==8:family,value='I',value>>1
                else:raise DecodeRefused('Legacy literal/label area refused')
        self.put(state,at,family,value)
        if double:self.put(state,at+8,family,value)

    def timer(self,state,words):
        first=words[0];high=first>>8;value=first&255
        state[2]=9;self.put(state,0,'C' if high==14 else 'T',value|(256 if high==7 else 0))
        wide=high==14 and value>=200
        state[1]=10 if wide else 9;state[8]=int(wide)
        if len(words)<(5 if wide else 3):raise Unsupported('Truncated native timer preset')
        a,b=words[1:3]
        if wide:
            c,d=words[3:5]
            if ((a>>8)&0xf0)|((b>>8)&0xf0)|(c>>8)|(d>>8)!=0x80:
                raise DecodeRefused('Legacy wide timer preset envelope refused')
            if (a>>8)&6==0:family,hi='K',(c&255)|((d&255)<<8)
            elif (a>>8)&6==6:
                family='D';hi=((a&255)|((b&255)<<8))>>1
                if b>>8==0x80:hi=(hi+8000)&65535
                elif b>>8==0x88:hi=(hi+1000)&65535
                elif b>>8!=0x86:raise DecodeRefused('Legacy wide timer D area refused')
            else:raise Unsupported('Native invalid timer branch uses unrecovered register fields')
            self.put(state,16,family,hi)
        if a>>8==0x80:
            if b>>8!=0x80:raise DecodeRefused('Legacy K timer preset refused')
            family,value='K',(a&255)|((b&255)<<8)
        elif a>>8==0x86:
            family,value='D',((a&255)|((b&255)<<8))>>1
            if b>>8==0x80:value=(value+8000)&65535
            elif b>>8==0x88:value=(value+1000)&65535
        else:raise DecodeRefused('Legacy timer preset class refused')
        self.put(state,8,family,value)
        return 5 if wide else 3

    def control(self,state,words):
        first=words[0]
        if first>=16:
            high=first>>8
            if high in (6,7,14):return self.timer(state,words)
            if high not in (0,1,2,16,17,18):raise DecodeRefused('Legacy first-word class refused')
            if high&16:state[7]=16
            value=first&0xfff;kind=48|(value&1);fn=(value>>1)-8
            state[2]=kind
            if not 0<=fn<300:raise DecodeRefused('Legacy application number refused')
            struct.pack_into('<H',state,4,fn)
            flags=self.tables['applications'][fn][kind-48];state[1]=flags
            if flags==255:raise DecodeRefused('Legacy application column absent')
            if flags==16:return 1
            cells=(flags>>4)-1
            if 1+2*cells>len(words):raise Unsupported('Truncated table-driven application operands')
            double=kind==49
            for i in range(cells//2 if double else cells):
                pos=1+i*(4 if double else 2);at=8+i*(16 if double else 8)
                if at+(16 if double else 8)>72:raise Unsupported('Decoder writes beyond its inspected nine-cell reset')
                self.word(state,at,*words[pos:pos+2],double=double,tail=words[pos+2:pos+4] if double else None)
            return 1+2*cells
        flags,kind=self.tables['controls'][first]
        if kind==255:raise DecodeRefused('Legacy control number absent')
        state[1],state[2]=flags,kind
        if flags==16:return 1
        if flags==48:
            if len(words)<3:raise Unsupported('Truncated MC two-operand reader')
            a,b=words[1:3];state[8]=state[16]=0;state[11]=ord('N')
            if a>>8!=0x80:raise DecodeRefused('Legacy MC nesting prefix refused')
            struct.pack_into('<H',state,12,a&255)
            if b>>12==8:
                family,high=self.device((b>>8)&15);value=(high<<8)|(b&255)
            elif b>>12==10:family,value='M',(((b>>8)&7)+6)*256+(b&255)
            else:raise DecodeRefused('Legacy MC destination prefix refused')
            self.put(state,16,family,value);return 3
        if len(words)<2:raise Unsupported('Truncated control address')
        a=words[1];prefix=(a>>12)&15
        if flags==32:
            state[8]=0
            if first==13:
                if len(words)<3:raise Unsupported('Truncated RST word address')
                b=words[2]
                if a>>8!=0x86:raise DecodeRefused('Legacy RST word prefix refused')
                value=((a&255)|((b&255)<<8))>>1
                if b>>8==0x86:family='D'
                elif b>>8==0x88:family,value='D',(value+1000)&65535
                elif b>>8==0x80:family,value=self.index((value+8000)&65535)
                else:raise DecodeRefused('Legacy RST word area refused')
                self.put(state,8,family,value);return 3
            if prefix==8:
                if first==11:family,value='N',a&255
                else:
                    family,high=self.device((a>>8)&15)
                    value=8000+(a&255) if high==31 else (high<<8)|(a&255)
            elif prefix==10:family,value='M',(((a>>8)&7)+6)*256+(a&255)
            else:raise DecodeRefused('Legacy control operand class refused')
            self.put(state,8,family,value);return 2
        if prefix==8:
            family,high=self.device((a>>8)&15)
            state[3]=ord(family)
            value=(high<<8)|(a&255)
            if high==31:value=(value+64)&65535
            elif family!='S':raise DecodeRefused('Legacy compact OUT area refused')
        elif prefix==10:family,value='M',(((a>>8)&7)+6)*256+(a&255)
        else:raise DecodeRefused('Legacy extended OUT area refused')
        self.put(state,0,family,value);return 2

    def record(self,raw):
        if not raw or len(raw)%2 or len(raw)>512:raise Unsupported('Machine fragment must have bounded WORD framing')
        words=list(struct.unpack('<'+'H'*(len(raw)//2),raw));first=words[0]
        state=bytearray(b'\xff'*88)
        try:
            if first in (0x264,0x266,0xb40f,0x860f):
                state[1],state[2]={0x264:(25,38),0x266:(26,39),0xb40f:(0,10),0x860f:(0,10)}[first];n=1
            elif first>>8==255:
                if first&0xf8!=0xf8:raise DecodeRefused('Legacy fixed word class refused')
                state[1],state[2]=self.tables['fixed'][first&7]
                if state[2]==255:raise DecodeRefused('Legacy fixed word absent')
                n=1
            elif first&0xfff0==0x1c0:
                if len(words)<2:raise Unsupported('Truncated extended bit instruction')
                a=words[1]
                if first&255<0xca:
                    idx=(((first&15)-2)&65535)*16+8
                    if not 0<=idx<224:raise Unsupported('Extended bit table address exceeds inspected rows')
                    flags,kind,family,high=self.tables['ordinary'][idx]
                    state[1],state[2]=flags,kind;self.put(state,0,chr(family),(((a>>8)&7)+6)*256+(a&255))
                else:
                    prefix=(a>>12)&15;col=(a>>8)&15 if prefix==8 else 8
                    idx=((((first&7)-2)&65535)*16)+col
                    if not 0<=idx<224:raise Unsupported('Extended contact table address exceeds inspected rows')
                    flags,kind,family,high=self.tables['extended'][idx];state[1],state[2]=flags,kind
                    value=(high<<8)|(a&255) if prefix==8 else (((a>>8)&7)+6)*256+(a&255)
                    if prefix==8 and high==31:value=8000+(a&255)
                    self.put(state,0,chr(family),value)
                n=2
            elif first>>8<32:n=self.control(state,words)
            else:
                flags,kind,family,high=self.tables['ordinary'][(first>>8)-32]
                state[1],state[2]=flags,kind
                if flags==32:
                    state[8]=0;self.put(state,8,chr(family),(high<<8)|(first&255));n=1
                else:
                    if kind==26 and first&255!=255:raise DecodeRefused('Legacy RET low byte refused')
                    state[3]=family
                    if high==31:value=8000+(first&255)
                    elif flags==255:raise DecodeRefused('Legacy ordinary word absent')
                    else:value=(high<<8)|(first&255)
                    struct.pack_into('<H',state,4,value);n=1
            return dict(raw_machine=raw.hex(),words=n,cells=state.hex(),auxiliary=bytes(68).hex(),
                handling='decoded-native-machine/projection-not-original-raw',remaining_bytes=len(raw)-2*n)
        except DecodeRefused as exc:
            return dict(raw_machine=raw.hex(),words=-1,cells=state.hex(),auxiliary=bytes(68).hex(),
                handling='native-decoder-refused',reason=str(exc))
