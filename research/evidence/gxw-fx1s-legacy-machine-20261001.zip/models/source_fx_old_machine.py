"""Inspected legacy mode-5 emission, retaining raw input and undefined words.

This path is separate from mode8/9. It does not validate controller ranges or
execute a program. Byte truncation and address aliases must not drive a writer.
"""
import struct
from source_fx_instruction_cells import FXInstructionCells
from source_fx_machine import FXMachine,EmissionRefused
from source_fx_operand_rules import Unsupported


class FX1SCells(FXInstructionCells):
    def __init__(self,tables):
        if (tables['file_version'],tables['cpu'])!=('15.31',518):raise Unsupported('Unmeasured FX1S cell context')
        self.tables,self.opcodes,self.devices=tables,tables['opcodes'],tables['devices']


class FXOldMachine(FXMachine):
    def __init__(self,tables,cells):
        if (tables['file_version'],tables['cpu'],tables['emission_mode'])!=('15.31',518,5):
            raise Unsupported('Unmeasured legacy emission context')
        self.tables,self.cells=tables,cells
        self.applications=tables['applications']

    @staticmethod
    def no_index(cell):
        if cell[7]>>4 in (2,4):raise EmissionRefused('Legacy basic index refused')

    @staticmethod
    def compact_old(cell,opcode=0):
        family,value,_,_=FXMachine.fields(cell)
        if family=='?':return opcode|(value&255)
        if family not in ('C','M','S','T','X','Y'):raise EmissionRefused('Legacy compact family refused')
        if family=='M':
            if value>=8000:return opcode|0xf00|((value-8000)&255)
            return opcode|0x800|value
        if family in ('C','X','Y'):
            return opcode|(value&255)|{'C':0xe00,'X':0x400,'Y':0x500}[family]
        return opcode|value|{'S':0,'T':0x600}[family]

    @staticmethod
    def extended_m(value):
        return (((value-1536)|0xa800)&65535) if value<8000 else (0x8f00|((value-8000)&255))

    def index_old(self,family,value):
        if 0<=value<=7:return self.tables['index_addresses'][family][value]
        return 65535

    def word_old(self,cell):
        family,value,selector,flags=self.fields(cell)
        mode=flags>>4
        prefix=0x9000 if mode==2 else 0xa000 if mode==4 else 0x8000
        index=flags&15 if mode in (2,4) else 0
        if family in ('K','H'):
            return [prefix|(0x200 if family=='H' else 0)|(value&255),0x8000|(index<<8)|(value>>8)]
        if family in ('?','\xff'):return [0x8000,0x8000]
        if family=='A':return [0x8a00|(value&255),0x8000|(value>>8)]
        if family in ('P','I'):
            encoded=(value<<1)&65535
            return [prefix|0x800|(encoded&255),(0x8200 if family=='I' else 0x8000)|(index<<6)|(encoded>>8)]
        if family in ('S','M','X','Y'):
            if family=='M':
                encoded=(value|0x800) if value<=1535 else ((value-1536)|0x2800) if value<8000 else (0xf00|((value-8000)&255))
            else:encoded=value if family=='S' else (value&255)|{'X':0x400,'Y':0x500}[family]
            group=0x8000 if selector==255 else (((selector|0xc0)<<1)&255)<<8
            return [prefix|0x400|(encoded&255),group|(index<<6)|((encoded>>8)&255)]
        if family in ('T','C','D','Z','V'):
            if selector!=255:raise EmissionRefused('Legacy word selector refused')
            if family=='T':area=0x8200
            elif family=='C':
                area=0x8400
                # Native tests the low BYTE, then changes the full WORD.
                if value&255>=200:value=(((2*value-400)&65535)|0x100)
            elif family=='D':
                if value<1000:area=0x8600
                elif value<8000:area,value=0x8800,(value-1000)&65535
                else:area,value=0x8000,(value-8000)&65535
            else:area,value=0x8000,(self.index_old(family,value)-8000)&65535
            encoded=(value<<1)&65535
            return [prefix|0x600|(encoded&255),area|(index<<6)|(encoded>>8)]
        raise EmissionRefused('Legacy word family has no branch')

    def double_old(self,cell,high):
        if chr(cell[3]) in ('K','H'):
            value=int.from_bytes(high[4:6],'little')
            return self.word_old(cell)+[0x8000|(value&255),0x8000|(value>>8)]
        return self.word_old(cell)+[0x8000,0x8000]

    def emit(self,raw_cells,auxiliary=None):
        state=bytes(raw_cells)
        if len(state)!=88:raise Unsupported('Legacy lowering allocation extent differs')
        kind=state[2]
        def cell(i):
            if not 0<=i<=10:raise Unsupported('Legacy cell access exceeds owned allocation')
            return state[8*i:8*i+8]
        def plain(i):
            c=cell(i);self.no_index(c);return self.fields(c)
        try:
            fixed={7:0xfff8,8:0xfff9,10:0xffff,13:0xfffa,14:0xfffb,15:0xfffc,16:15,26:0xf7ff,38:0x264,39:0x266,46:0xfffd}
            if kind in fixed:words=[fixed[kind]]
            elif kind in (1,2,3,4,5,6,25):
                family,value,_,_=plain(0)
                opcode={1:0x4000,2:0x5000,3:0x6000,4:0x7000,5:0x2000,6:0x3000,25:0xf000}[kind]
                words=[0x1c0|(opcode>>12),self.extended_m(value)] if family=='M' and 1535<value<8000 else [self.compact_old(cell(0),opcode)]
            elif kind in (40,41,42,43,44,45):
                family,value,_,_=plain(0)
                address=self.extended_m(value) if family=='M' and 1535<value<8000 else self.compact_old(cell(0),0x8000)
                words=[{40:0x1cc,41:0x1cd,42:0x1ce,43:0x1cf,44:0x1ca,45:0x1cb}[kind],address]
            elif kind==0:
                family,value,_,_=self.fields(cell(0))
                if family not in ('P','I','?'):raise EmissionRefused('Legacy label family refused')
                words=[None if family=='?' else value| (0xb000 if family=='P' else 0xb800)]
            elif kind==9:
                family,value,_,_=plain(0)
                if family=='?':words=[None]*(3 if state[1]==9 else 5 if state[1]==10 else 1)
                elif family=='Y' or family=='M' and value<=1535:words=[self.compact_old(cell(0),0xc000)]
                elif family=='M':words=[2,self.extended_m(value)]
                elif family=='S':words=[5,value|0x8000]
                elif family in ('T','C'):
                    preset_family,preset_value,_,_=plain(1)
                    address=(value&255)|0xe00 if family=='C' and value>=200 else self.compact_old(cell(0))
                    words=[address]
                    if preset_family=='?':words += [None]*(4 if family=='C' and value>=200 else 2)
                    elif preset_family not in ('K','D'):raise EmissionRefused('Legacy preset family refused')
                    else:words += self.double_old(cell(1),cell(2)) if family=='C' and value>=200 else self.word_old(cell(1))
                else:raise EmissionRefused('Legacy OUT family refused')
            elif kind in (17,18):
                family,value,_,_=plain(1)
                if family=='?':words=[None,None]
                elif family=='Y' or family=='M' and value<=1535:words=[self.compact_old(cell(1),0xd000 if kind==17 else 0xe000)]
                elif family=='M':words=[3 if kind==17 else 4,self.extended_m(value)]
                elif kind==17:words=[6,value|0x8000]
                elif family=='S':words=[7,value|0x8000]
                elif family in ('T','C'):words=[12,self.compact_old(cell(1),0x8000)]
                elif family in ('D','Z','V'):words=[13]+self.word_old(cell(1))
                else:raise EmissionRefused('Legacy RST family refused')
            elif kind in (21,22,24):
                family,value,_,_=plain(1)
                if family=='M' and value>=8000:raise EmissionRefused('Legacy pulse/control M range refused')
                address=None if family=='?' else self.extended_m(value) if family=='M' and value>1535 else self.compact_old(cell(1),0x8000) if family in ('M','Y') else value|0x8000
                words=[{21:9,22:8,24:11}[kind],address]
            elif kind==23:
                destination,value,_,_=plain(2)
                first_family,first_value,_,_=self.fields(cell(1))
                if first_family=='?' or destination=='?':words=[None,None,None]
                else:
                    if destination=='Y':address=value|0x8500
                    elif value<=1535:address=value|0x8800
                    elif value<8000:address=self.extended_m(value)
                    else:raise EmissionRefused('Legacy MC destination range refused')
                    words=[10,first_value|0x8000,address]
            elif kind in (48,49):
                function=int.from_bytes(state[4:6],'little')
                if function>=300 or self.applications[function]['word' if kind==48 else 'double']==255:
                    raise EmissionRefused('Legacy application mode absent')
                flags=state[1]
                if flags in (0,255) or kind==49 and flags==16:raise EmissionRefused('Legacy application flags refused')
                n=(flags>>4)-1
                if kind==49:
                    if n<2:raise EmissionRefused('Legacy double application arity refused')
                    n>>=1
                opcode=16+2*function+(kind==49)
                if state[7]==16:opcode|=0x1000
                words=[opcode]
                for i in range(n):
                    at=1+i*(2 if kind==49 else 1)
                    words+=self.double_old(cell(at),cell(at+1)) if kind==49 else self.word_old(cell(at))
            elif kind in (11,12,19,20,27,28,29,30,31):
                raise EmissionRefused('Legacy dispatcher entry is the refusal stub343c5')
            else:raise Unsupported('Legacy native kind outside inspected emission branches')
            words=[w&65535 if w is not None else None for w in words]
            defined=all(w is not None for w in words)
            return dict(words=len(words),machine_words=words,machine_output=struct.pack('<'+'H'*len(words),*words).hex() if defined else None,
                cells_after=state.hex(),handling='decoded-native-emission' if defined else 'partially-decoded/undefined-output-words')
        except EmissionRefused as exc:
            return dict(words=-1,machine_words=[],machine_output='',cells_after=state.hex(),handling='native-emitter-refused',reason=str(exc))
