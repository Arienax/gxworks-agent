"""CPU518 lexical profile; machine emission/ranges remain separate.

RVA3d7b9 exempts CPU0x206 (518), alongside CPU520/521, from the older
index-zero display branch. The initial contrary hypothesis is retained as a
failed native boundary comparison; all physical source tokens stay preserved.
"""
from source_fx_lossless_reader import FXLosslessReader
from source_fx_operand_reader import FXOperandReader
from source_fx_operand_rules import Unsupported
from source_fx_record_reader import FXRecordReader


class FX1SOperandReader(FXOperandReader):
    def read(self,raw,*,cpu=518):
        if cpu != 518:
            raise Unsupported('FX1S lexical model requires its own CPU context')
        return super().read(raw,cpu=520)


class FX1SRecordReader(FXRecordReader):
    def __init__(self):
        super().__init__()
        self.operands = FX1SOperandReader()

    def read(self,raw,*,cpu=518):
        if cpu != 518:
            raise Unsupported('FX1S record model requires its own CPU context')
        return super().read(raw,cpu=cpu)


class FX1SLosslessReader(FXLosslessReader):
    SUPPORTED_CPUS = (518,)

    def __init__(self):
        super().__init__()
        self.records = FX1SRecordReader()
