"""Legacy CPU518 predictions for two retained broad synthetic token matrices."""
import base64
import collections
import json
import subprocess
import sys
from probe_fx_operand_rules import DLL,P,save,traced_run
from source_fx_old_machine import FXOldMachine,FX1SCells
from source_fx_operand_rules import Unsupported


def main():
    name=sys.argv[1] if len(sys.argv)==2 else 'fx1s-old-machine-holdouts-20261001-v1'
    if name not in ('fx1s-old-machine-holdouts-20261001-v1','fx1s-old-machine-holdouts-20261001-v2'):
        raise ValueError('Explicit local run identity required')
    out=P/name;out.mkdir()
    model=FXOldMachine(json.loads((P/'fx-old-machine-tables-20261001-v1.json').read_text(encoding='utf-8')),
        FX1SCells(json.loads((P/'fx1s-cell-tables-20261001-v1.json').read_text(encoding='utf-8'))))
    rows,seen=[],set()
    for origin in ('fx-instruction-cell-holdouts-20261001-v1','fx-machine-prospective-holdouts-20261001-v1'):
        for r in json.loads((P/origin/'before-native.json').read_text(encoding='utf-8'))['requests']:
            if r['raw'] in seen:continue
            seen.add(r['raw']);rows.append(dict(id=len(rows),raw=r['raw'],origin=origin,origin_id=r['id'],
                category=r.get('category',r.get('profile','')),name=r.get('name'),description=r.get('description')))
    predictions,gaps={},[]
    for row in rows:
        try:predictions[str(row['id'])]=model.record(bytes.fromhex(row['raw']))
        except Unsupported as exc:gaps.append(dict(id=row['id'],reason=str(exc)))
    save(out/'before-native.json',dict(cpu=518,converter='15.31',emission_mode=5,requests=rows,
        scope='Synthetic raw token matrices originally observed in a different CPU; independently remeasured for518, with no assumptions about availability/ranges'))
    if name.endswith('-v2'):
        save(out/'retained-predecessor.json',dict(path='fx1s-old-machine-holdouts-20261001-v1',
            differences=52,reason='Compact X/Y/C and word X/Y use fixed address high bytes, not OR with raw high bytes; original predictions and native traces remain immutable'))
    save(out/'predictions-before-native.json',predictions);save(out/'source-gaps.json',gaps)
    for name in ('source_fx_old_machine.py','source_fx_instruction_cells.py','source_fx_machine.py','TraceFXInstructionCells.js',
        'fx-old-machine-tables-20261001-v1.json','fx1s-cell-tables-20261001-v1.json','probe_fx1s_old_machine_holdouts.py'):
        (out/name).write_bytes((P/name).read_bytes())
    helper=P/'fx1s-old-machine-corpus-20261001-v1'
    for name in ('FX1SOldMachineOracle.cs','FX1SOldMachineOracle.exe'):(out/name).write_bytes((helper/name).read_bytes())
    (out/'requests.tsv').write_text('\n'.join(str(r['id'])+'\t'+base64.b64encode(bytes.fromhex(r['raw'])).decode() for r in rows)+'\n',encoding='ascii')
    args=[str(out/'FX1SOldMachineOracle.exe'),str(DLL),str(out/'requests.tsv'),str(out/'baseline.jsonl')]
    process=subprocess.run(args,capture_output=True,timeout=45,creationflags=subprocess.CREATE_NO_WINDOW)
    (out/'baseline-stdout.bin').write_bytes(process.stdout);(out/'baseline-stderr.bin').write_bytes(process.stderr);save(out/'baseline-process.json',dict(returncode=process.returncode))
    if process.returncode:raise RuntimeError('Owned legacy holdout helper failed; outputs retained')
    traced_run(args[:-1]+[str(out/'traced.jsonl')],(out/'TraceFXInstructionCells.js').read_text(encoding='utf-8'),out)
    events,errors=collections.defaultdict(list),[]
    for line in (out/'events.jsonl').read_text(encoding='utf-8').splitlines():
        packet=json.loads(line)
        if packet['type']!='send':errors.append(packet);continue
        e=packet['payload'];events[e['request']].append(e)
    answers=[json.loads(l) for l in (out/'baseline.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    counts,differences,unavailable,observations=collections.Counter(),[],[],[]
    for row,answer in zip(rows,answers,strict=True):
        assert row['id']==answer['id']
        calls=[e for e in events[row['id']] if e['event']=='machine-emission'];p=predictions.get(str(row['id']))
        if len(calls)!=1 or p is None:
            unavailable.append(dict(id=row['id'],calls=calls,source_gap=p is None,public=answer));continue
        e=calls[0];emission=p['emission']
        same=dict(cells_before=p['native_cells']==e['before'],auxiliary=p['auxiliary']==e['auxiliary'],words=emission['words']==e['words'],
            cells_after=emission['cells_after']==e['after'],context=e['cpu']==518 and e['mode']==5)
        if emission['machine_output'] is not None:same['machine_bytes']=emission['machine_output']==e['output']
        else:counts['undefined_output']+=1
        if emission['words']>0:
            try:same['public_rewrite']=model.width_rewrite(bytes.fromhex(row['raw']))['candidate']==base64.b64decode(answer['output_base64']).hex()
            except Unsupported:counts['source_width_rewrite_unsupported']+=1
        counts['observed']+=1
        for k,ok in same.items():counts[k]+=ok
        obs=dict(id=row['id'],native=e,matches=same,public=answer);observations.append(obs)
        if not all(same.values()):differences.append(dict(source=row,predicted=p,observation=obs))
    save(out/'observations.json',observations);save(out/'differences.json',differences);save(out/'unavailable.json',unavailable)
    summary=dict(requests=len(rows),predictions=len(predictions),source_gaps=len(gaps),counts=dict(counts),differences=len(differences),unavailable=len(unavailable),
        public_codes=dict(collections.Counter(a['code'] for a in answers)),public_statuses=dict(collections.Counter(a['status'] for a in answers)),
        guards_intact=all(a['guards_intact'] for a in answers),baseline_traced_exact=(out/'baseline.jsonl').read_bytes()==(out/'traced.jsonl').read_bytes(),hook_errors=errors,
        scope='New CPU518 public check measurements for retained synthetic boundaries; raw lowering, count, machine bytes and width rewrite only; pre-emitter refusals and undefined bytes stay separate')
    save(out/'comparison.json',summary);print(json.dumps(summary,ensure_ascii=True),flush=True)
    if differences or errors or not summary['baseline_traced_exact']:raise ValueError('Legacy holdout differences retained')


if __name__=='__main__':main()
