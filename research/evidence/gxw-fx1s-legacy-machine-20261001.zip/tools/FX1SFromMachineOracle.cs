// Owned, guarded buffers; public memory-only FX 15.31 machine-to-PCode ABI.
using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;

public static class FX1SFromMachineOracle {
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode)] static extern IntPtr LoadLibraryEx(string path,IntPtr file,uint flags);
    [DllImport("kernel32.dll",CharSet=CharSet.Ansi,ExactSpelling=true)] static extern IntPtr GetProcAddress(IntPtr module,string name);
    [DllImport("kernel32.dll")] static extern uint SetErrorMode(uint mode);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate IntPtr Create();
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Open(IntPtr h,int cpu,int mode);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Version(IntPtr h,int count,[In] uint[] versions);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Close(IntPtr h);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate void Destroy(IntPtr h);
    [StructLayout(LayoutKind.Sequential,Pack=1)] struct CodeBuffers {
        public IntPtr machine;
        public int remaining;
        public IntPtr pcode;
        public IntPtr deviceOffsets;
        public int reserved16,reserved20;
    }
    [StructLayout(LayoutKind.Sequential,Pack=1)] struct PackedNativeValue { public uint low; public ushort high; }
    // 369B copies two six-byte values to padded stack slots. The inspected
    // FX dispatcher328FD routes518 to mode5; output +8 is a temporary pointer.
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int FromMachine(IntPtr h,ref CodeBuffers buffers,
        IntPtr context,ref int bytes,int option1,int option2,PackedNativeValue value1,PackedNativeValue value2);
    static T Export<T>(IntPtr module,string name) where T:class {
        IntPtr p=GetProcAddress(module,name);if(p==IntPtr.Zero)throw new Exception(name);
        return Marshal.GetDelegateForFunctionPointer(p,typeof(T)) as T;
    }
    sealed class Arena:IDisposable {
        public const int Guard=32;
        public byte[] data;public int capacity;GCHandle pin;
        public Arena(int size){capacity=size;data=new byte[size+2*Guard];for(int i=0;i<Guard;i++){data[i]=0xA5;data[Guard+size+i]=0xA5;}pin=GCHandle.Alloc(data,GCHandleType.Pinned);}
        public IntPtr Pointer{get{return IntPtr.Add(pin.AddrOfPinnedObject(),Guard);}}
        public void Verify(){for(int i=0;i<Guard;i++)if(data[i]!=0xA5||data[Guard+capacity+i]!=0xA5)throw new Exception("Owned buffer guard changed");}
        public void Dispose(){pin.Free();}
    }
    public static int Main(string[] args){
        if(IntPtr.Size!=4||args.Length!=3)return 2;SetErrorMode(3);
        if(FileVersionInfo.GetVersionInfo(args[0]).FileVersion!="15.31")throw new Exception("Uninspected converter version");
        IntPtr m=LoadLibraryEx(args[0],IntPtr.Zero,8);if(m==IntPtr.Zero)throw new Exception("Load failed");
        Create create=Export<Create>(m,"ObjectNew");Open open=Export<Open>(m,"Open");Version version=Export<Version>(m,"SetVersion");
        Close close=Export<Close>(m,"Close");Destroy destroy=Export<Destroy>(m,"ObjectDelete");FromMachine convert=Export<FromMachine>(m,"ChangeMToPcode");
        using(StreamWriter output=new StreamWriter(args[2]))foreach(string line in File.ReadLines(args[1])){
            string[] fields=line.Split('\t');if(fields.Length!=2)throw new Exception("Request framing");int id=int.Parse(fields[0]);byte[] raw=Convert.FromBase64String(fields[1]);
            if(raw.Length<2||raw.Length>512||(raw.Length&1)!=0)throw new Exception("Outside bounded WORD fragment envelope");
            using(Arena input=new Arena(4096))using(Arena result=new Arena(1048576))using(Arena offsets=new Arena(128)){
                Array.Copy(raw,0,input.data,Arena.Guard,raw.Length);IntPtr h=create();if(h==IntPtr.Zero)throw new Exception("Create failed");
                try{
                    int code=open(h,518,0);if(code!=0)throw new Exception("Open: "+code);code=version(h,0,new uint[0]);if(code!=0)throw new Exception("Version: "+code);
                    CodeBuffers b=new CodeBuffers();b.machine=input.Pointer;b.remaining=raw.Length;b.pcode=result.Pointer;b.deviceOffsets=offsets.Pointer;
                    int bytes=result.capacity;code=convert(h,ref b,IntPtr.Zero,ref bytes,0,0,new PackedNativeValue(),new PackedNativeValue());
                    int consumed=b.machine.ToInt32()-input.Pointer.ToInt32();if(consumed<0||consumed>input.capacity)throw new Exception("Returned input cursor exceeds owned buffer");
                    if(bytes<0||bytes>result.capacity)throw new Exception("Returned output extent exceeds owned buffer");input.Verify();result.Verify();offsets.Verify();
                    bool unchanged=true;for(int i=0;i<raw.Length;i++)if(input.data[Arena.Guard+i]!=raw[i])unchanged=false;
                    output.WriteLine("{\"id\":"+id+",\"code\":"+code+",\"consumed\":"+consumed+",\"remaining\":"+b.remaining+",\"bytes\":"+bytes+",\"input_unchanged\":"+(unchanged?"true":"false")+",\"guards_intact\":true,\"output_base64\":\""+(code==0?Convert.ToBase64String(result.data,Arena.Guard,bytes):"")+"\"}");output.Flush();
                }finally{close(h);destroy(h);}
            }
        }
        return 0;
    }
}
