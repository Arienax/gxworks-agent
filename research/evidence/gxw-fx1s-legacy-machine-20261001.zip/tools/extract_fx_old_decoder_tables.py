"""Extract the distinct machine-reader tables, without loading the converter."""
import json
import pefile
from probe_fx_operand_rules import DLL,P,save


def main():
    pe=pefile.PE(str(DLL))
    versions=[t.entries.get(b'FileVersion') for f in pe.FileInfo for block in f
        if block.Key==b'StringFileInfo' for t in block.StringTable]
    if b'15.31' not in versions or pe.OPTIONAL_HEADER.ImageBase!=0x10000000:
        raise ValueError('Uninspected legacy decoder binary context')
    def rows(rva,count,width):
        raw=pe.get_data(rva,count*width)
        if len(raw)!=count*width:raise ValueError('Static decoder table extent differs')
        return [list(raw[i*width:(i+1)*width]) for i in range(count)]
    import struct
    result=dict(file_version='15.31',cpu=518,mode=5,
        origin='Inspected35e8a/35daa/35aac/3542e/35629; decoder tables independently extracted, no emitter or PCode lowering imports',
        ordinary=rows(0x7cd40,224,4),extended=rows(0x7d0c0,224,4),fixed=rows(0x7d440,8,2),
        controls=rows(0x7d450,16,2),compact_devices=rows(0x7d470,16,2),applications=rows(0x7d490,300,2),
        index_addresses={f:list(struct.unpack('<8H',pe.get_data(rva,16))) for f,rva in [('V',0x7d6e8),('Z',0x7d6f8)]})
    save(P/'fx-old-decoder-tables-20261001-v1.json',result)
    print(json.dumps(dict(ordinary=len(result['ordinary']),extended=len(result['extended']),applications=len(result['applications']),version='15.31',cpu=518,mode=5),ensure_ascii=True))


if __name__=='__main__':main()
