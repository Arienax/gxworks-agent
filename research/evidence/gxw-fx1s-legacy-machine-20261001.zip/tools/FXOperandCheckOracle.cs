// Owned memory buffers, inspected public FX 15.31 instruction-check interface.
using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;

public static class FXOperandCheckOracle {
    [DllImport("kernel32.dll", CharSet=CharSet.Unicode)] static extern IntPtr LoadLibraryEx(string path, IntPtr file, uint flags);
    [DllImport("kernel32.dll", CharSet=CharSet.Ansi, ExactSpelling=true)] static extern IntPtr GetProcAddress(IntPtr module, string name);
    [DllImport("kernel32.dll")] static extern uint SetErrorMode(uint mode);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate IntPtr Create();
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Open(IntPtr h, int cpu, int mode);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Version(IntPtr h, int count, [In] uint[] versions);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Close(IntPtr h);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate void Destroy(IntPtr h);
    [StructLayout(LayoutKind.Sequential, Pack=1)] struct CodeBuffers {
        public IntPtr output;
        public int remaining;
        public IntPtr input;
        public IntPtr deviceOffsets;
        public int reserved16, reserved20;
    }
    // Export 3cb2 -> 26e6 -> 59a9 copies six 32-bit fields, then returns
    // the type status separately from the public transport status.
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Check(IntPtr h,
        ref CodeBuffers buffers, int mode, IntPtr context, out short status);
    static T Export<T>(IntPtr m, string name) where T:class {
        IntPtr p=GetProcAddress(m, name); if(p==IntPtr.Zero) throw new Exception(name);
        return Marshal.GetDelegateForFunctionPointer(p, typeof(T)) as T;
    }
    public static int Main(string[] args) {
        if(IntPtr.Size!=4 || args.Length!=3) return 2;
        SetErrorMode(3);
        if(FileVersionInfo.GetVersionInfo(args[0]).FileVersion!="15.31") throw new Exception("Uninspected converter version");
        IntPtr m=LoadLibraryEx(args[0], IntPtr.Zero, 8); if(m==IntPtr.Zero) throw new Exception("Load failed");
        Create create=Export<Create>(m,"ObjectNew"); Open open=Export<Open>(m,"Open");
        Version version=Export<Version>(m,"SetVersion"); Close close=Export<Close>(m,"Close");
        Destroy destroy=Export<Destroy>(m,"ObjectDelete"); Check check=Export<Check>(m,"CheckInstructionCode2");
        using(StreamWriter output=new StreamWriter(args[2])) {
            foreach(string line in File.ReadLines(args[1])) {
                string[] fields=line.Split('\t'); if(fields.Length!=2) throw new Exception("Request framing");
                int id=int.Parse(fields[0]); byte[] raw=Convert.FromBase64String(fields[1]);
                if(raw.Length<2 || raw.Length>512) throw new Exception("Outside caller-bounded single-record envelope");
                const int guard=32, capacity=4096;
                byte[] area=new byte[capacity+2*guard];
                for(int i=0;i<guard;i++){area[i]=0xA5;area[guard+capacity+i]=0xA5;}
                Array.Copy(raw,0,area,guard,raw.Length);
                GCHandle pin=GCHandle.Alloc(area,GCHandleType.Pinned);
                IntPtr h=create(); if(h==IntPtr.Zero) throw new Exception("Create failed");
                try {
                    int code=open(h,521,0); if(code!=0) throw new Exception("Open: "+code);
                    code=version(h,0,new uint[0]); if(code!=0) throw new Exception("Version: "+code);
                    CodeBuffers b=new CodeBuffers(); IntPtr start=IntPtr.Add(pin.AddrOfPinnedObject(),guard);
                    b.input=start;b.remaining=raw.Length;
                    short status; code=check(h,ref b,0,IntPtr.Zero,out status);
                    if(b.input!=start || b.output!=IntPtr.Zero || b.deviceOffsets!=IntPtr.Zero || b.reserved16!=0 || b.reserved20!=0)
                        throw new Exception("Unexpected public buffer descriptor mutation");
                    if(b.remaining<0 || b.remaining>capacity) throw new Exception("Returned extent outside owned buffer");
                    for(int i=0;i<guard;i++) if(area[i]!=0xA5 || area[guard+capacity+i]!=0xA5) throw new Exception("Owned buffer guard changed");
                    output.WriteLine("{\"id\":"+id+",\"code\":"+code+",\"status\":"+status+",\"size\":"+b.remaining+
                        ",\"guards_intact\":true,\"output_base64\":\""+Convert.ToBase64String(area,guard,b.remaining)+"\"}");
                    output.Flush();
                } finally {close(h);destroy(h);pin.Free();}
            }
        }
        return 0;
    }
}
