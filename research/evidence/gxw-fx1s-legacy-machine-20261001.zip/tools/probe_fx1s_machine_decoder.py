"""Prospective independent decoder comparison for retained original emissions."""
import base64
import collections
import json
import os
import subprocess
from probe_fx_operand_rules import DLL,P,save,traced_run
from source_fx_old_decoder import FXOldDecoder
from source_fx_operand_rules import Unsupported


def main():
    out=P/'fx1s-independent-machine-decoder-20261001-v1';out.mkdir()
    tables=json.loads((P/'fx-old-decoder-tables-20261001-v1.json').read_text(encoding='utf-8'));model=FXOldDecoder(tables)
    prior=P/'fx1s-old-machine-corpus-20261001-v1'
    original=json.loads((prior/'before-native.json').read_text(encoding='utf-8'))['requests']
    observed=json.loads((prior/'observations.json').read_text(encoding='utf-8'))
    rows,predictions,gaps=[],{},[]
    for source,native in zip(original,observed,strict=True):
        assert source['id']==native['id']
        raw=bytes.fromhex(native['native']['output'])
        rows.append(dict(id=source['id'],case=source['case'],offset=source['offset'],machine=raw.hex(),original_pcode=source['raw']))
        try:predictions[str(source['id'])]=model.record(raw)
        except Unsupported as exc:gaps.append(dict(id=source['id'],reason=str(exc)))
    save(out/'before-native.json',dict(cpu=518,mode=5,converter='15.31',requests=rows,scope='Unchanged original public-emitter bytes; source decoder predictions retained before separate public machine-to-PCode runs'))
    save(out/'predictions-before-native.json',predictions);save(out/'source-gaps.json',gaps)
    for name in ('source_fx_old_decoder.py','fx-old-decoder-tables-20261001-v1.json','extract_fx_old_decoder_tables.py','TraceFXOldDecoder.js','FX1SFromMachineOracle.cs','probe_fx1s_machine_decoder.py'):
        (out/name).write_bytes((P/name).read_bytes())
    exe=out/'FX1SFromMachineOracle.exe'
    build=subprocess.run([os.path.join(os.environ['WINDIR'],'Microsoft.NET/Framework/v4.0.30319/csc.exe'),'/nologo','/platform:x86','/out:'+str(exe),str(out/'FX1SFromMachineOracle.cs')],capture_output=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
    (out/'build.txt').write_bytes(build.stdout+build.stderr)
    if build.returncode:raise RuntimeError('Owned machine-reader helper build failed')
    (out/'requests.tsv').write_text('\n'.join(str(r['id'])+'\t'+base64.b64encode(bytes.fromhex(r['machine'])).decode() for r in rows)+'\n',encoding='ascii')
    args=[str(exe),str(DLL),str(out/'requests.tsv'),str(out/'baseline.jsonl')]
    process=subprocess.run(args,capture_output=True,timeout=45,creationflags=subprocess.CREATE_NO_WINDOW)
    (out/'baseline-stdout.bin').write_bytes(process.stdout);(out/'baseline-stderr.bin').write_bytes(process.stderr);save(out/'baseline-process.json',dict(returncode=process.returncode))
    if process.returncode:raise RuntimeError('Owned public decoder failed; partial outputs retained')
    traced_run(args[:-1]+[str(out/'traced.jsonl')],(out/'TraceFXOldDecoder.js').read_text(encoding='utf-8'),out)
    events,errors=collections.defaultdict(list),[]
    for line in (out/'events.jsonl').read_text(encoding='utf-8').splitlines():
        packet=json.loads(line)
        if packet['type']!='send':errors.append(packet);continue
        event=packet['payload'];events[event['request']].append(event)
    answers=[json.loads(l) for l in (out/'baseline.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    counts,differences,unavailable,results=collections.Counter(),[],[],[]
    for row,answer in zip(rows,answers,strict=True):
        assert row['id']==answer['id']
        calls=[e for e in events[row['id']] if e['event']=='old-machine-decoder'];p=predictions.get(str(row['id']))
        if len(calls)!=1 or p is None:
            unavailable.append(dict(id=row['id'],calls=calls,prediction=p,public=answer));continue
        native=calls[0]
        same=dict(words=p['words']==native['words'],cells=p['cells']==native['cells'],auxiliary=p['auxiliary']==native['auxiliary'],
            context=native['cpu']==518 and native['mode']==5,machine=row['machine']==native['machine'],
            before=native['before']=='ff'*88 and native['auxiliary_before']=='00'*68,
            public_consumed=answer['consumed']==len(bytes.fromhex(row['machine'])) and answer['remaining']==0)
        counts['observed']+=1
        for k,ok in same.items():counts[k]+=ok
        result=dict(id=row['id'],case=row['case'],native=native,matches=same,public=answer);results.append(result)
        if not all(same.values()):differences.append(dict(source=row,predicted=p,observation=result))
    save(out/'observations.json',results);save(out/'differences.json',differences);save(out/'unavailable.json',unavailable)
    summary=dict(original_records=len(rows),predicted=len(predictions),source_gaps=gaps,counts=dict(counts),differences=len(differences),unavailable=len(unavailable),
        public_codes=dict(collections.Counter(a['code'] for a in answers)),guards_intact=all(a['guards_intact'] for a in answers),input_unchanged=all(a['input_unchanged'] for a in answers),
        baseline_traced_exact=(out/'baseline.jsonl').read_bytes()==(out/'traced.jsonl').read_bytes(),hook_errors=errors,
        scope='Separate static machine grammar, native public M-to-P conversion and original retained emitter witnesses; no full GXW load/compile/reopen or execution assertion')
    save(out/'comparison.json',summary);print(json.dumps(summary,ensure_ascii=True),flush=True)
    if differences or errors or not summary['baseline_traced_exact']:raise ValueError('Independent decoder differences retained')


if __name__=='__main__':main()
