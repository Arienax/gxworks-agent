"""Extract the separate legacy mode-5 machine dispatcher and availability."""
import json
import struct
import pefile
from probe_fx_operand_rules import DLL,P,save


def main():
    out=P/'fx-old-machine-tables-20261001-v1.json'
    if out.exists():raise FileExistsError('Retained static tables must not be replaced')
    pe=pefile.PE(str(DLL));image=pe.get_memory_mapped_image();base=pe.OPTIONAL_HEADER.ImageBase
    dispatch=[dict(kind=i,function_rva=struct.unpack_from('<I',image,0x7ccc0+4*i)[0]-base,
                   raw=image[0x7ccc0+4*i:0x7ccc4+4*i].hex()) for i in range(32)]
    functions=[dict(function=i,word=image[0x7d490+2*i],double=image[0x7d491+2*i],
        raw=image[0x7d490+2*i:0x7d492+2*i].hex()) for i in range(300)]
    indexes={name:[struct.unpack_from('<H',image,at+2*i)[0] for i in range(8)] for name,at in [('V',0x7d6e8),('Z',0x7d6f8)]}
    # The lowering tables are shared code/data, tagged separately for CPU518.
    cells=json.loads((P/'fx-instruction-cell-tables-20261001-v1.json').read_text(encoding='utf-8'))
    for row in cells['opcodes']:
        at=cells['opcode_rva']+6*row['index']
        if image[at:at+6].hex()!=row['raw']:raise ValueError('Inspected opcode table bytes changed')
    cells['cpu']=518
    save(P/'fx1s-cell-tables-20261001-v1.json',cells)
    save(out,dict(file_version='15.31',cpu=518,emission_mode=5,dispatch_rva=0x7ccc0,application_rva=0x7d490,
        dispatch=dispatch,applications=functions,index_addresses=indexes,
        scope='Separate legacy encoding path at35d50; availability and encoding do not establish operand/project validity'))
    print(json.dumps(dict(dispatch=len(dispatch),word_functions=sum(r['word']!=255 for r in functions),
        double_functions=sum(r['double']!=255 for r in functions),index_addresses=indexes)))


if __name__=='__main__':main()
