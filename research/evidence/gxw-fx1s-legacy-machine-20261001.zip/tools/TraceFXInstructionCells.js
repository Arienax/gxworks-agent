'use strict';
let cellRequest = -1;
function cellHex(p, n) {
    return Array.from(new Uint8Array(p.readByteArray(n)), b => b.toString(16).padStart(2, '0')).join('');
}
function cellShort(r) { return (r.toInt32() << 16) >> 16; }
function cellRaw(buffer) {
    const input = buffer.add(8).readPointer(), n = input.readU8();
    if (n < 2 || n > 127) throw new Error('Unbounded input token');
    return cellHex(input, n);
}
Process.attachModuleObserver({ onAdded(m) {
    if (m.name.toLowerCase() !== 'eccodegeneratorfx2.dll') return;
    const base = m.base;
    Interceptor.attach(m.findExportByName('CheckInstructionCode2'), {
        onEnter(a) { cellRequest++; this.status = a[4]; this.row = { event: 'check', request: cellRequest }; },
        onLeave(r) { this.row.code = r.toInt32(); this.row.status = this.status.readS16(); send(this.row); }
    });
    Interceptor.attach(base.add(0x3e339), {
        onEnter(a) {
            this.state = a[1]; this.count = a[2];
            this.row = { event: 'instruction-cells', request: cellRequest, raw: cellRaw(a[0]),
                before: cellHex(this.state, 88), count_before: this.count.readS32() };
        },
        onLeave(r) {
            this.row.result = cellShort(r); this.row.after = cellHex(this.state, 88);
            this.row.count_after = this.count.readS32(); send(this.row);
        }
    });
    Interceptor.attach(base.add(0x3dc7a), {
        onEnter(a) {
            this.state = a[1]; this.count = a[2]; this.aux = a[3];
            this.row = { event: 'operand-cells', request: cellRequest, raw: cellRaw(a[0]),
                before: cellHex(this.state, 88), count_before: this.count.readS32(), auxiliary_before: cellHex(this.aux, 68) };
        },
        onLeave(r) {
            this.row.result = cellShort(r); this.row.after = cellHex(this.state, 88);
            this.row.count_after = this.count.readS32(); this.row.auxiliary_after = cellHex(this.aux, 68); send(this.row);
        }
    });
    Interceptor.attach(base.add(0x2ff3f), {
        onEnter(a) {
            this.state = a[0]; this.output = a[2];
            this.row = { event: 'machine-emission', request: cellRequest, mode: a[3].toInt32(),
                cpu: base.add(0x928a8).readU16(), before: cellHex(this.state, 88), auxiliary: cellHex(a[1], 68) };
        },
        onLeave(r) {
            this.row.words = cellShort(r); this.row.after = cellHex(this.state, 88);
            if (this.row.words > 256) throw new Error('Native emission exceeded the owned temporary buffer');
            this.row.output = this.row.words > 0 ? cellHex(this.output, this.row.words * 2) : ''; send(this.row);
        }
    });
} });
