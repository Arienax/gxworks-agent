"""Public P-to-M conversion of separately returned machine-to-PCode witnesses."""
import base64
import collections
import json
import os
import subprocess
import sys
from probe_fx_operand_rules import DLL,P,save,traced_run


def adapted_helper():
    source=(P/'FX1SFromMachineOracle.cs').read_text(encoding='utf-8')
    source=source.replace('FX1SFromMachineOracle','FX1SToMachineOracle')
    changes=[
        ('// 369B copies two six-byte values to padded stack slots. The inspected\n    // FX dispatcher328FD routes518 to mode5; output +8 is a temporary pointer.',
         '// 3674 passes the six-field buffer descriptor to the public P-to-M\n    // adapter. Pointer deltas delimit the machine bytes; fresh CPU518 context.'),
        ('delegate int FromMachine(IntPtr h,ref CodeBuffers buffers,\n        IntPtr context,ref int bytes,int option1,int option2,PackedNativeValue value1,PackedNativeValue value2);',
         'delegate int ToMachine(IntPtr h,ref CodeBuffers buffers,IntPtr context,ref int words,int option1,int option2);'),
        ('FromMachine convert=Export<FromMachine>(m,"ChangeMToPcode");','ToMachine convert=Export<ToMachine>(m,"ChangePToMcode");'),
        ('raw.Length>512||(raw.Length&1)!=0','raw.Length>512'),
        ('Outside bounded WORD fragment envelope','Outside bounded PCode fragment envelope'),
        ('b.machine=input.Pointer;b.remaining=raw.Length;b.pcode=result.Pointer;',
         'b.machine=result.Pointer;b.remaining=raw.Length;b.pcode=input.Pointer;'),
        ('int bytes=result.capacity;code=convert(h,ref b,IntPtr.Zero,ref bytes,0,0,new PackedNativeValue(),new PackedNativeValue());',
         'int words=result.capacity/4;code=convert(h,ref b,IntPtr.Zero,ref words,0,0);int bytes=b.machine.ToInt32()-result.Pointer.ToInt32();'),
        ('int consumed=b.machine.ToInt32()-input.Pointer.ToInt32();','int consumed=b.pcode.ToInt32()-input.Pointer.ToInt32();'),
        ('\\\"bytes\\\":"+bytes+', '\\\"bytes\\\":"+bytes+",\\\"words\\\":"+words+'),
    ]
    for old,new in changes:
        if source.count(old)!=1:raise ValueError('Owned helper adaptation site differs: '+old)
        source=source.replace(old,new)
    return source


def main():
    name=sys.argv[1] if len(sys.argv)==2 else 'fx1s-public-machine-reemission-20261001-v1'
    if name not in ('fx1s-public-machine-reemission-20261001-v1','fx1s-public-machine-reemission-20261001-v2'):
        raise ValueError('Explicit local run identity required')
    out=P/name;out.mkdir()
    origin=P/'fx1s-machine-roundtrip-analysis-20261001-v1'
    rows=json.loads((origin/'prospective-public-reemission.json').read_text(encoding='utf-8'))
    save(out/'before-native.json',dict(cpu=518,converter='15.31',versions=[],requests=rows,
        scope='Canonical PCode returned by separate public M-to-P conversion; source reemission predictions already retained; public full-fragment P-to-M interface, not a private width call'))
    if name.endswith('-v2'):
        save(out/'retained-predecessor.json',dict(path='fx1s-public-machine-reemission-20261001-v1',
            reason='Baseline completed; observer adaptation expected a different export-lookup spelling. No native prediction was changed. Retained full baseline and owned helper source.'))
    source=adapted_helper();(out/'FX1SToMachineOracle.cs').write_text(source,encoding='utf-8')
    exe=out/'FX1SToMachineOracle.exe'
    build=subprocess.run([os.path.join(os.environ['WINDIR'],'Microsoft.NET/Framework/v4.0.30319/csc.exe'),'/nologo','/platform:x86','/out:'+str(exe),str(out/'FX1SToMachineOracle.cs')],capture_output=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
    (out/'build.txt').write_bytes(build.stdout+build.stderr)
    if build.returncode:raise RuntimeError('Owned public reemission helper build failed')
    (out/'probe_fx1s_public_reemission.py').write_bytes((P/'probe_fx1s_public_reemission.py').read_bytes())
    (out/'requests.tsv').write_text('\n'.join(str(r['id'])+'\t'+base64.b64encode(bytes.fromhex(r['raw'])).decode() for r in rows)+'\n',encoding='ascii')
    args=[str(exe),str(DLL),str(out/'requests.tsv'),str(out/'baseline.jsonl')]
    process=subprocess.run(args,capture_output=True,timeout=45,creationflags=subprocess.CREATE_NO_WINDOW)
    (out/'baseline-stdout.bin').write_bytes(process.stdout);(out/'baseline-stderr.bin').write_bytes(process.stderr);save(out/'baseline-process.json',dict(returncode=process.returncode))
    if process.returncode:raise RuntimeError('Owned public reemission failed; partial outputs retained')
    observer=(P/'TraceFXInstructionCells.js').read_text(encoding='utf-8')
    hook_changes=[("m.findExportByName('CheckInstructionCode2')","m.findExportByName('ChangePToMcode')"),
        ("cellRequest++; this.status = a[4]; this.row = { event: 'check', request: cellRequest };",
         "cellRequest++; this.row = { event: 'public-P-to-M', request: cellRequest };"),
        ("this.row.code = r.toInt32(); this.row.status = this.status.readS16(); send(this.row);",
         "this.row.code = r.toInt32(); send(this.row);")]
    for old,new in hook_changes:
        if observer.count(old)!=1:raise ValueError('Owned public observer adaptation differs')
        observer=observer.replace(old,new)
    (out/'TraceFXPublicReemission.js').write_text(observer,encoding='utf-8')
    traced_run(args[:-1]+[str(out/'traced.jsonl')],observer,out)
    events,errors=collections.defaultdict(list),[]
    for line in (out/'events.jsonl').read_text(encoding='utf-8').splitlines():
        packet=json.loads(line)
        if packet['type']!='send':errors.append(packet);continue
        e=packet['payload'];events[e['request']].append(e)
    answers=[json.loads(l) for l in (out/'baseline.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    counts,differences,original_differences,roundtrip_changes,results=collections.Counter(),[],[],[],[]
    for r,a in zip(rows,answers,strict=True):
        assert r['id']==a['id']
        raw=base64.b64decode(a['output_base64']).hex();prefix='original' if 'original_case' in r else 'synthetic'
        counts[prefix+'_requests']+=1
        counts[prefix+'_public_accepted']+=a['code']==0
        same=dict(public_accepted=a['code']==0,full_consumption=a['consumed']==len(bytes.fromhex(r['raw'])) and a['remaining']==0)
        if r['expected_machine'] is not None:
            same['source_machine']=raw==r['expected_machine'];counts[prefix+'_source_predictions']+=1
            counts[prefix+'_source_machine_exact']+=same['source_machine']
        else:counts[prefix+'_source_gaps']+=1
        roundtrip=raw==r['original_machine'] and a['code']==0
        counts[prefix+'_native_machine_roundtrip_exact']+=roundtrip
        calls=[e for e in events[r['id']] if e['event']=='machine-emission']
        result=dict(id=r['id'],source=r,public=a,native_calls=calls,matches=same,native_machine_roundtrip_exact=roundtrip)
        results.append(result)
        if not all(same.values()):differences.append(result)
        if not roundtrip:roundtrip_changes.append(result)
        if prefix=='original' and (not all(same.values()) or not roundtrip):original_differences.append(result)
    save(out/'observations.json',results);save(out/'source-native-differences.json',differences);save(out/'native-roundtrip-differences.json',roundtrip_changes)
    save(out/'original-differences.json',original_differences)
    summary=dict(requests=len(rows),counts=dict(counts),source_native_differences=len(differences),native_roundtrip_differences=len(roundtrip_changes),original_differences=len(original_differences),
        public_codes=dict(collections.Counter(a['code'] for a in answers)),guards_intact=all(a['guards_intact'] for a in answers),input_unchanged=all(a['input_unchanged'] for a in answers),
        baseline_traced_exact=(out/'baseline.jsonl').read_bytes()==(out/'traced.jsonl').read_bytes(),hook_errors=errors,
        scope='Fresh public P-to-M interface; retained native M-to-P outputs, source predictions and original machine bytes compared independently. Native roundtrip differences are retained counterexamples, not necessarily source-model errors.')
    save(out/'comparison.json',summary);print(json.dumps(summary,ensure_ascii=True),flush=True)
    if errors or original_differences or not summary['baseline_traced_exact']:raise ValueError('Original reemission or hook verification differs')


if __name__=='__main__':main()
