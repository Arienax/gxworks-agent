"""Independent legacy reader on unique native-emitted synthetic machine bytes."""
import base64
import collections
import json
import subprocess
import sys
from probe_fx_operand_rules import DLL,P,save,traced_run
from source_fx_old_decoder import FXOldDecoder
from source_fx_operand_rules import Unsupported


def stream_prediction(model,raw):
    at,records=0,[]
    while at<len(raw):
        try:record=model.record(raw[at:])
        except Unsupported as exc:
            return dict(records=records,consumed=at,handling='partial/opaque-preserved',gap=str(exc),remaining=raw[at:].hex())
        words=record['words'] if record['words']>0 else 1
        record['offset']=at;record['consumed_machine']=raw[at:at+2*words].hex()
        records.append(record);at+=words*2
    return dict(records=records,consumed=at,handling='decoded-native-machine-stream')


def main():
    name=sys.argv[1] if len(sys.argv)==2 else 'fx1s-independent-machine-holdouts-20261001-v1'
    if name not in ('fx1s-independent-machine-holdouts-20261001-v1','fx1s-independent-machine-holdouts-20261001-v2'):
        raise ValueError('Explicit local run identity required')
    out=P/name;out.mkdir()
    prior=P/'fx1s-old-machine-holdouts-20261001-v2'
    source_rows=json.loads((prior/'before-native.json').read_text(encoding='utf-8'))['requests']
    observations=json.loads((prior/'observations.json').read_text(encoding='utf-8'))
    groups=collections.defaultdict(list)
    for obs in observations:
        if not all(obs['matches'].values()):raise ValueError('Unresolved preceding emission difference')
        if obs['native']['words']<=0:continue
        r=source_rows[obs['id']];groups[obs['native']['output']].append(dict(id=r['id'],raw=r['raw'],category=r['category']))
    rows=[dict(id=i,machine=raw,origins=origins) for i,(raw,origins) in enumerate(groups.items())]
    model=FXOldDecoder(json.loads((P/'fx-old-decoder-tables-20261001-v1.json').read_text(encoding='utf-8')))
    predictions={str(r['id']):stream_prediction(model,bytes.fromhex(r['machine'])) for r in rows}
    save(out/'before-native.json',dict(cpu=518,emission_mode=5,requests=rows,source_emissions=sum(len(r['origins']) for r in rows),
        scope='Distinct machine byte groups derived from separate native emission observations; source stream predictions stored before public M-to-P calls; original alias provenance retained'))
    save(out/'predictions-before-native.json',predictions)
    if name.endswith('-v2'):
        save(out/'retained-predecessor.json',dict(path='fx1s-independent-machine-holdouts-20261001-v1',
            differences=155,reason='Index classification inspects high-byte low nibble; rejected compact OUT also writes the family before refusal; original failure predictions and traces stay immutable'))
    for name in ('source_fx_old_decoder.py','fx-old-decoder-tables-20261001-v1.json','probe_fx1s_machine_decoder_holdouts.py','TraceFXOldDecoder.js','FX1SFromMachineOracle.cs'):
        (out/name).write_bytes((P/name).read_bytes())
    helper=P/'fx1s-independent-machine-decoder-20261001-v1'
    (out/'FX1SFromMachineOracle.exe').write_bytes((helper/'FX1SFromMachineOracle.exe').read_bytes())
    (out/'requests.tsv').write_text('\n'.join(str(r['id'])+'\t'+base64.b64encode(bytes.fromhex(r['machine'])).decode() for r in rows)+'\n',encoding='ascii')
    args=[str(out/'FX1SFromMachineOracle.exe'),str(DLL),str(out/'requests.tsv'),str(out/'baseline.jsonl')]
    process=subprocess.run(args,capture_output=True,timeout=45,creationflags=subprocess.CREATE_NO_WINDOW)
    (out/'baseline-stdout.bin').write_bytes(process.stdout);(out/'baseline-stderr.bin').write_bytes(process.stderr);save(out/'baseline-process.json',dict(returncode=process.returncode))
    if process.returncode:raise RuntimeError('Owned legacy machine reader failed; partial outputs retained')
    traced_run(args[:-1]+[str(out/'traced.jsonl')],(out/'TraceFXOldDecoder.js').read_text(encoding='utf-8'),out)
    events,errors=collections.defaultdict(list),[]
    for line in (out/'events.jsonl').read_text(encoding='utf-8').splitlines():
        packet=json.loads(line)
        if packet['type']!='send':errors.append(packet);continue
        e=packet['payload'];events[e['request']].append(e)
    answers=[json.loads(l) for l in (out/'baseline.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    counts,differences,results,gaps=collections.Counter(),[],[],[]
    for r,a in zip(rows,answers,strict=True):
        assert r['id']==a['id']
        p=predictions[str(r['id'])];calls=[e for e in events[r['id']] if e['event']=='old-machine-decoder'];matches=[]
        for expected,native in zip(p['records'],calls):
            same=dict(words=expected['words']==native['words'],cells=expected['cells']==native['cells'],auxiliary=expected['auxiliary']==native['auxiliary'],
                context=native['cpu']==518 and native['mode']==5,before=native['before']=='ff'*88 and native['auxiliary_before']=='00'*68)
            if expected['words']>0:same['machine']=expected['consumed_machine']==native['machine']
            counts['observed_records']+=1
            for k,ok in same.items():counts[k]+=ok
            matches.append(same)
            if not all(same.values()):differences.append(dict(id=r['id'],source=r,predicted=expected,native=native,matches=same))
        if p['handling']=='decoded-native-machine-stream':
            counts['complete_source_groups']+=1
            exact=len(p['records'])==len(calls)
            counts['call_count_exact']+=exact
            if not exact:differences.append(dict(id=r['id'],source=r,predicted=p,native=calls,reason='Decoder invocation count differs'))
            counts['public_consumption_exact']+=a['consumed']==p['consumed'] and a['remaining']==0
        else:gaps.append(dict(id=r['id'],source=r,predicted=p,native=calls,public=a))
        results.append(dict(id=r['id'],native=calls,matches=matches,public=a))
    save(out/'observations.json',results);save(out/'differences.json',differences);save(out/'source-gaps.json',gaps)
    summary=dict(source_emissions=sum(len(r['origins']) for r in rows),distinct_machine_groups=len(rows),counts=dict(counts),differences=len(differences),source_gaps=len(gaps),
        public_codes=dict(collections.Counter(a['code'] for a in answers)),returned_cursor_beyond_logical_input=sum(a['consumed']>len(bytes.fromhex(r['machine'])) for r,a in zip(rows,answers,strict=True)),
        guards_intact=all(a['guards_intact'] for a in answers),input_unchanged=all(a['input_unchanged'] for a in answers),
        baseline_traced_exact=(out/'baseline.jsonl').read_bytes()==(out/'traced.jsonl').read_bytes(),hook_errors=errors,
        scope='Static reader independently compared with original decoder calls from public M-to-P conversion; source gaps retained explicitly. Cursor accounting does not prove absence of reads into owned padding; not whole-project/execution validity')
    save(out/'comparison.json',summary);print(json.dumps(summary,ensure_ascii=True),flush=True)
    if differences or errors or not summary['baseline_traced_exact']:raise ValueError('Decoder holdout differences retained')


if __name__=='__main__':main()
