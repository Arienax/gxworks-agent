"""Keep canonical machine projection, lexical differences and original raw apart."""
import base64
import collections
import json
from probe_fx_operand_rules import P,save
from source_fx1s_reader import FX1SRecordReader,FX1SLosslessReader
from source_fx_old_machine import FXOldMachine,FX1SCells
from source_fx_operand_rules import Unsupported


def signature(record):
    if record['handling']!='decoded-native-record':return None
    return dict(name=record['name'],args=[o['text'] for o in record['operands']])


def main():
    out=P/'fx1s-machine-roundtrip-analysis-20261001-v1';out.mkdir()
    origin=P/'fx1s-independent-machine-holdouts-20261001-v2'
    rows=json.loads((origin/'before-native.json').read_text(encoding='utf-8'))['requests']
    observed=json.loads((origin/'observations.json').read_text(encoding='utf-8'))
    reader,body_reader=FX1SRecordReader(),FX1SLosslessReader()
    emitter=FXOldMachine(json.loads((P/'fx-old-machine-tables-20261001-v1.json').read_text(encoding='utf-8')),
        FX1SCells(json.loads((P/'fx1s-cell-tables-20261001-v1.json').read_text(encoding='utf-8'))))
    results,counts,aliases,refusals,proposals=[],collections.Counter(),[],[],[]
    for r,o in zip(rows,observed,strict=True):
        if r['id']!=o['id']:raise ValueError('Machine group identity differs')
        item=dict(id=r['id'],machine=r['machine'],public_code=o['public']['code'],origins=[],native_decoded_cells=o['native'])
        counts['groups']+=1
        for source in r['origins']:
            try:lexical=signature(reader.read(bytes.fromhex(source['raw']),cpu=518))
            except Unsupported as exc:lexical=dict(unsupported=str(exc))
            item['origins'].append(dict(**source,lexical=lexical))
        if o['public']['code']:
            counts['public_reverse_refused']+=1;refusals.append(item);results.append(item);continue
        raw=base64.b64decode(o['public']['output_base64']);ir=body_reader.read(raw,cpu=518)
        item.update(canonical_pcode=raw.hex(),canonical_ir=ir,canonical_lexical=[signature(n['lexical_projection']) if n['lexical_projection'] else None for n in ir['records']])
        counts['public_reverse_accepted']+=1
        counts['canonical_raw_reconstruction_exact']+=body_reader.reconstruct(ir)==raw
        counts['canonical_records']+=len(ir['records'])
        counts['canonical_critical_gaps']+=ir['coverage']['critical_gaps']
        unique={json.dumps(s['lexical'],sort_keys=True) for s in item['origins']}
        if len(unique)>1:aliases.append(item);counts['distinct_lexical_alias_groups']+=1
        different=sum([s['lexical']]!=item['canonical_lexical'] for s in item['origins'])
        counts['origin_lexical_differences']+=different
        item['origin_lexical_differences']=different
        projected,gap=[],None
        for n in ir['records']:
            if n['critical_gap']:gap='Canonical PCode contains an opaque/unframed lexical region';break
            try:emission=emitter.record(bytes.fromhex(n['raw']))
            except Unsupported as exc:gap=str(exc);break
            if emission['emission']['words']<=0 or emission['emission']['machine_output'] is None:
                gap='Canonical PCode source emission refused or undefined';break
            projected.append(emission)
        item['canonical_source_emissions']=projected
        item['source_emission_gap']=gap
        candidate=''.join(e['emission']['machine_output'] for e in projected) if gap is None else None
        item['canonical_predicted_machine']=candidate
        item['canonical_source_machine_exact']=candidate==r['machine'] if candidate is not None else None
        if gap is None:
            counts['canonical_source_machine_predicted']+=1
            counts['canonical_source_machine_exact']+=candidate==r['machine']
        else:counts['canonical_source_emission_gaps']+=1
        proposals.append(dict(id=len(proposals),machine_group=r['id'],raw=raw.hex(),expected_machine=candidate,original_machine=r['machine'],source_gap=gap))
        results.append(item)
    originals=P/'fx1s-independent-machine-decoder-20261001-v1'
    original_rows=json.loads((originals/'before-native.json').read_text(encoding='utf-8'))['requests']
    original_observed=json.loads((originals/'observations.json').read_text(encoding='utf-8'))
    original_counts=collections.Counter()
    for r,o in zip(original_rows,original_observed,strict=True):
        before=bytes.fromhex(r['original_pcode']);after=base64.b64decode(o['public']['output_base64'])
        original_counts['records']+=1;original_counts['pcode_byte_exact']+=before==after
        original_counts['lexical_exact']+=signature(reader.read(before,cpu=518))==signature(reader.read(after,cpu=518))
        candidate=emitter.record(after)['emission']['machine_output']
        original_counts['source_reemission_exact']+=candidate==r['machine']
        proposals.append(dict(id=len(proposals),original_case=r['case'],original_id=r['id'],raw=after.hex(),expected_machine=candidate,original_machine=r['machine'],distribution='Original third-party PCode remains local-only'))
    save(out/'groups.json',results);save(out/'lexical-alias-groups.json',aliases);save(out/'native-reverse-refusals.json',refusals)
    save(out/'prospective-public-reemission.json',proposals)
    for name in ('analyze_fx1s_machine_roundtrips.py','source_fx_old_machine.py','source_fx1s_reader.py'):(out/name).write_bytes((P/name).read_bytes())
    summary=dict(synthetic=dict(counts),original=dict(original_counts),public_reemission_proposals=len(proposals),
        scope='Post-observation analysis of independently measured machine decoder. Canonical PCode is kept beside original raw witnesses; lexical equality is not execution equivalence. Reemission predictions precede the next native run.')
    save(out/'comparison.json',summary);print(json.dumps(summary,ensure_ascii=True),flush=True)


if __name__=='__main__':main()
