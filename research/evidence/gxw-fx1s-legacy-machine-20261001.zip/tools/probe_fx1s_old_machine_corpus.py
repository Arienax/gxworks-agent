"""Prospective legacy-path emission for unchanged independent FX1S bodies."""
import base64
import collections
import json
import os
import subprocess

from probe_fx_operand_rules import DLL,P,save,traced_run
from probe_fx3u_original_machine_corpus import frame
from source_fx_old_machine import FXOldMachine,FX1SCells
from source_fx_operand_rules import Unsupported


def main():
    out=P/'fx1s-old-machine-corpus-20261001-v1';out.mkdir()
    tables=json.loads((P/'fx-old-machine-tables-20261001-v1.json').read_text(encoding='utf-8'))
    cells=json.loads((P/'fx1s-cell-tables-20261001-v1.json').read_text(encoding='utf-8'))
    model=FXOldMachine(tables,FX1SCells(cells))
    rows,predictions,gaps,projects=[],{},[],[]
    for case in ('case-08','case-09'):
        raw=(P/'additional-native-baselines'/case/'native-1/pcode-0-0.bin').read_bytes()
        records,metadata=frame(raw)
        projects.append(dict(case=case,bytes=len(raw),records=len(records),raw_metadata=len(metadata),distribution='Original third-party GXW and its PCode remain local-only'))
        (out/(case+'-input.bin')).write_bytes(raw)
        for record in records:
            body=b''.join(t['raw'] for t in record['tokens'])
            row=dict(id=len(rows),case=case,offset=record['offset'],raw=body.hex())
            rows.append(row)
            try:predictions[str(row['id'])]=model.record(body)
            except Unsupported as exc:gaps.append(dict(id=row['id'],reason=str(exc)))
    save(out/'before-native.json',dict(cpu=518,emission_mode=5,converter='15.31',projects=projects,requests=rows,
        scope='Separate legacy dispatcher inferred prospectively from3e3dd/2ff3f/35d50 and static tables; unchanged original bodies, fresh native object per public raw check'))
    save(out/'predictions-before-native.json',predictions);save(out/'source-generation-gaps.json',gaps)
    for name in ('source_fx_old_machine.py','source_fx_instruction_cells.py','source_fx_machine.py','TraceFXInstructionCells.js',
                 'fx-old-machine-tables-20261001-v1.json','fx1s-cell-tables-20261001-v1.json','probe_fx1s_old_machine_corpus.py'):
        (out/name).write_bytes((P/name).read_bytes())
    cs=(P/'FXOperandCheckOracle.cs').read_text(encoding='utf-8').replace('FXOperandCheckOracle','FX1SOldMachineOracle')
    if cs.count('open(h,521,0)')!=1:raise ValueError('Owned CPU adaptation site differs')
    cs=cs.replace('open(h,521,0)','open(h,518,0)')
    (out/'FX1SOldMachineOracle.cs').write_text(cs,encoding='utf-8')
    exe=out/'FX1SOldMachineOracle.exe'
    build=subprocess.run([str(os.path.join(os.environ['WINDIR'],'Microsoft.NET/Framework/v4.0.30319/csc.exe')),
        '/nologo','/platform:x86','/out:'+str(exe),str(out/'FX1SOldMachineOracle.cs')],capture_output=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
    (out/'build.txt').write_bytes(build.stdout+build.stderr)
    if build.returncode:raise RuntimeError('Owned legacy helper build failed')
    (out/'requests.tsv').write_text('\n'.join(str(r['id'])+'\t'+base64.b64encode(bytes.fromhex(r['raw'])).decode() for r in rows)+'\n',encoding='ascii')
    args=[str(exe),str(DLL),str(out/'requests.tsv'),str(out/'baseline.jsonl')]
    process=subprocess.run(args,capture_output=True,timeout=45,creationflags=subprocess.CREATE_NO_WINDOW)
    (out/'baseline-stdout.bin').write_bytes(process.stdout);(out/'baseline-stderr.bin').write_bytes(process.stderr)
    save(out/'baseline-process.json',dict(returncode=process.returncode))
    if process.returncode:raise RuntimeError('Owned legacy original check failed; retained')
    traced_run(args[:-1]+[str(out/'traced.jsonl')],(out/'TraceFXInstructionCells.js').read_text(encoding='utf-8'),out)
    events,errors=collections.defaultdict(list),[]
    for line in (out/'events.jsonl').read_text(encoding='utf-8').splitlines():
        packet=json.loads(line)
        if packet['type']!='send':errors.append(packet);continue
        e=packet['payload'];events[e['request']].append(e)
    answers=[json.loads(l) for l in (out/'baseline.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    counts,differences,unavailable,observations=collections.Counter(),[],[],[]
    for row,answer in zip(rows,answers,strict=True):
        assert row['id']==answer['id']
        observed=[e for e in events[row['id']] if e['event']=='machine-emission']
        prediction=predictions.get(str(row['id']))
        if len(observed)!=1 or prediction is None:
            unavailable.append(dict(id=row['id'],native_emissions=observed,predicted=prediction,public=answer));continue
        e=observed[0];emission=prediction['emission']
        same=dict(cells_before=prediction['native_cells']==e['before'],auxiliary=prediction['auxiliary']==e['auxiliary'],
            words=emission['words']==e['words'],cells_after=emission['cells_after']==e['after'],context=e['cpu']==518 and e['mode']==5)
        if emission['machine_output'] is not None:same['machine_bytes']=emission['machine_output']==e['output']
        rewrite=model.width_rewrite(bytes.fromhex(row['raw']))
        same['public_rewrite']=rewrite['candidate']==base64.b64decode(answer['output_base64']).hex()
        counts['observed']+=1
        for name,ok in same.items():counts[name]+=ok
        obs=dict(id=row['id'],case=row['case'],native=e,matches=same,public_code=answer['code'],status=answer['status'])
        observations.append(obs)
        if not all(same.values()):differences.append(dict(source=row,predicted=prediction,observation=obs))
    save(out/'observations.json',observations);save(out/'differences.json',differences);save(out/'no-emitter-observation.json',unavailable)
    exact=(out/'baseline.jsonl').read_bytes()==(out/'traced.jsonl').read_bytes()
    summary=dict(original_projects=2,cpu=518,emission_mode=5,original_records=len(rows),predictions=len(predictions),source_generation_gaps=gaps,
        counts=dict(counts),differences=len(differences),no_emitter_observation=len(unavailable),
        public_accepted=sum(a['code']==0 and a['status'] in (0,1) for a in answers),public_statuses=dict(collections.Counter(a['status'] for a in answers)),
        original_records_byte_exact=sum(base64.b64decode(a['output_base64']).hex()==r['raw'] for r,a in zip(rows,answers,strict=True)),
        guards_intact=all(a['guards_intact'] for a in answers),baseline_traced_exact=exact,hook_errors=errors,
        scope='Original raw lowering, legacy machine bytes and local public width rewrite; not a full GXW writer/address/project/execution validation')
    save(out/'comparison.json',summary);print(json.dumps(summary,ensure_ascii=True),flush=True)
    if differences or errors or not exact:raise ValueError('Legacy machine differences retained')


if __name__=='__main__':main()
