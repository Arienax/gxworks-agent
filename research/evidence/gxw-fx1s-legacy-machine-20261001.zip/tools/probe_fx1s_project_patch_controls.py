"""Attribute full-check rejection using untouched controls; measure save separately."""
import json
import sys
from probe_fx_operand_rules import P,save
from probe_fx1s_lossless_project_patch import native_run
from gxw.container import CompoundFile
from gxw.project_resolver import GXWProjectResolver
from gxw.token_pou import frame_token_pou


def reports(directory):
    events=[json.loads(l) for l in (directory/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    rows=set()
    for e in events:
        if e['operation']!='ProgramCheckProgress':continue
        for r in e.get('reports',[]):
            if r.get('kind') not in (2,3):continue
            rows.add((r['kind'],r['code'],r['name'],r['instance'],r['step'],r['network'],tuple(r['arguments'])))
    return sorted(rows)


def main():
    run_name=sys.argv[1] if len(sys.argv)==2 else 'fx1s-lossless-project-patch-controls-20261001-v1'
    if run_name not in ('fx1s-lossless-project-patch-controls-20261001-v1','fx1s-lossless-project-patch-controls-20261001-v2'):
        raise ValueError('Explicit local run identity required')
    out=P/run_name;out.mkdir()
    for script_name in ('probe_fx1s_project_patch_controls.py','probe_fx1s_lossless_project_patch.py'):(out/script_name).write_bytes((P/script_name).read_bytes())
    if run_name.endswith('-v2'):
        save(out/'retained-predecessor.json',dict(path='fx1s-lossless-project-patch-controls-20261001-v1',
            reason='Untouched all-options controls completed and are reused. The proposed separate save runs inadvertently retained ProgramCheck because a helper text variable shadowed the boolean check argument. Both failed save-stage plans and native reports remain retained; fresh corrected save/reopen only.'))
    prior=P/'fx1s-lossless-project-patch-20261001-v1';prepared=[]
    for case in ('case-08','case-09'):
        d=out/case;d.mkdir();original=prior/case/'original.gxw';candidate=prior/case/'candidate.gxw'
        original_body=frame_token_pou(GXWProjectResolver(CompoundFile(original.read_bytes())).read_logical_file('MAIN.Program.pou')).body
        expected=(prior/case/'expected-pcode.bin').read_bytes()
        plan=json.loads((P/'additional-native-baselines'/case/'native-1/plan.json').read_text(encoding='utf-8'))
        save(d/'before-native.json',dict(case=case,original_file=str(original),candidate_file=str(candidate),expected_original_pcode=original_body.hex(),expected_candidate_pcode=expected.hex(),
            plan='Untouched full-check control, then separate compile/save/reopen experiment. The latter retains full-check rejection and does not claim program-check success.'))
        prepared.append((case,d,original,candidate,original_body,expected,plan))
    results=[]
    for case,d,original,candidate,original_body,expected,plan in prepared:
        if run_name.endswith('-v2'):
            control=P/'fx1s-lossless-project-patch-controls-20261001-v1'/case/'native-untouched-control'
            control_result=json.loads((control/'outcome.json').read_text(encoding='utf-8'))
        else:
            control=d/'native-untouched-control';control_result=native_run(original,control,plan,compile=True,export=True)
        patch_reports=reports(prior/case/'native-build');control_reports=reports(control)
        saved_run=d/'native-save-separate';saved_result=native_run(candidate,saved_run,plan,compile=True,export=True,check=False)
        row=dict(case=case,untouched_control_source=str(control),untouched_control=control_result,untouched_control_pcode_exact=(control/'pcode-0-0.bin').exists() and (control/'pcode-0-0.bin').read_bytes()==original_body,
            prior_patch_reports=patch_reports,untouched_control_reports=control_reports,program_check_diagnostics_unchanged=patch_reports==control_reports,
            save_run=saved_result,save_run_pcode_exact=(saved_run/'pcode-0-0.bin').exists() and (saved_run/'pcode-0-0.bin').read_bytes()==expected)
        saved=saved_run/'native-saved.gxw'
        if saved.exists():
            frame=frame_token_pou(GXWProjectResolver(CompoundFile(saved.read_bytes())).read_logical_file('MAIN.Program.pou'))
            row['saved_source_body_exact']=frame.body==expected
            row['reopen']=native_run(saved,d/'native-reopen',plan,compile=False,export=False,check=False)
        save(d/'comparison.json',row);results.append(row);save(out/'comparison.json',results)
        print(json.dumps({k:v for k,v in row.items() if k not in ('prior_patch_reports','untouched_control_reports')},ensure_ascii=True),flush=True)


if __name__=='__main__':main()
