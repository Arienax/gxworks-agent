"""Distinguish captured references, copy-back and output address evaluation."""
from dataclasses import replace
from pathlib import Path
import base64,json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from gxw.declarations import parse_declarations,edit_declarations,serialize_declarations
from gxw.project_metadata import mark_observed_source_compile_pending
from probe_gxw_st_sources import replace_observed_st
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_program_check_resources import SCRIPT
from probe_minimal_conditional_port_writes import streams,observe,save
from native_gxw_tokens import native_batch,Q_DLL,native_il_records
P=Path(__file__).resolve().parent
OUT=P/'st-fb-index-capture-20260930'


def main():
    global OUT
    config=json.loads(Path(sys.argv[1]).read_text()) if len(sys.argv)>1 else None
    if config:OUT=P/config['directory']
    OUT.mkdir(exist_ok=False)
    if config:save(OUT/'experiment-plan.json',config)
    for name in (Path(__file__).name,'observe_expression_temporaries.js','observe_index_register_lifetime.js',
                 'source_q_st_calls.py','source_q_direct_declarations.py','source_q_st_expressions.py','source_q_label_binding.py','source_q_width.py'):
        (OUT/name).write_bytes((P/name).read_bytes())
    trace=OUT/'trace.js';trace.write_text('(()=>{'+(P/'native-allocation-bitmap-v2/observer.js').read_text()+'\n'+(P/'observe_expression_temporaries.js').read_text()+'\n'+(P/'observe_index_register_lifetime.js').read_text()+'\n})();\n(()=>{'+SCRIPT+'\n})();',encoding='utf-8')
    original=(P/'ST-nested-FB-controls/single/native/native-saved.gxw').read_bytes();before=streams(original)
    root_labels='POU_01.Labels.lh';doc=parse_declarations(before[root_labels],logical_name=root_labels)
    root=edit_declarations(doc,upserts=[dict(name='probeArray',data_type='ARRAY[0..7] OF INT')]+
        [dict(name=name,data_type='INT') for name in ('probeIndex','probeFrozen','probeOther','probeResult','probeR0','probeR1','probeR2')])
    if config:root=edit_declarations(root,upserts=config.get('root_declarations',[]))
    root_raw=mark_observed_source_compile_pending(serialize_declarations(root),logical_name=root_labels)
    fb_labels='Wrapper.Labels.lh';doc=parse_declarations(before[fb_labels],logical_name=fb_labels)
    assert [(r.name,r.class_code) for r in doc.rows]==[('number',4),('in_out_character',5),('Inner',1)]
    doc=edit_declarations(doc,remove=['Inner'],renames={'number':'result','in_out_character':'value'},
        upserts=[dict(name='result',data_type='INT'),dict(name='value',data_type='INT')])
    value=next(r for r in doc.rows if r.name=='value')
    idx=replace(value,name='idx',record_id=max(r.record_id for r in doc.rows)+1)
    doc=replace(doc,rows=doc.rows+(idx,))
    if config:doc=edit_declarations(doc,upserts=config.get('local_declarations',[]))
    init='probeIndex := 0;\nprobeFrozen := probeIndex;\nprobeOther := 11;\nprobeArray[0] := 11;\nprobeArray[1] := 22;\nprobeArray[2] := 33;\n'
    tail='probeR0 := probeArray[0];\nprobeR1 := probeArray[1];\nprobeR2 := probeArray[2];\n'
    plans=[('inout-scalar',5,'probeOther',False),('inout-dynamic',5,'probeArray[probeIndex]',False),
        ('inout-frozen-index',5,'probeArray[probeFrozen]',False),('inout-value-first',5,'probeArray[probeIndex]',True),
        ('output-dynamic',4,'probeArray[probeIndex]',False),('output-frozen-index',4,'probeArray[probeFrozen]',False)]
    if config:plans=config['plans']
    ready=[]
    for case,scope,actual,value_first in plans:
        d=OUT/case;d.mkdir()
        formal=replace(doc,rows=tuple(replace(r,class_code=scope) if r.name=='value' else r for r in doc.rows))
        changes={root_labels:root_raw,fb_labels:mark_observed_source_compile_pending(serialize_declarations(formal),logical_name=fb_labels)}
        main=init+f'Keypad_1(value := {actual}, idx := probeIndex, result := probeResult);\n'+tail
        mutation='value := value + 10;' if scope==5 else 'value := 77;'
        body=(mutation+'\nidx := idx + 1;\n' if value_first else 'idx := idx + 1;\n'+mutation+'\n')+'result := '+('value' if scope==5 else 'idx')+';\n'
        if config:
            body=config.get('bodies',{}).get(case,body)
            main=init+config['calls'][case]+tail if case in config.get('calls',{}) else main
        for name,text in [('POU_01.Program.pou',main),('Wrapper.Program.pou',body)]:
            raw,_=replace_observed_st(before[name],text.replace('\n','\r\n'))
            changes[name]=mark_observed_source_compile_pending(raw,logical_name=name)
        source=original;receipts=[]
        for name,raw in changes.items():source,receipt=patch_raw(source,name,before[name],raw);receipts.append(receipt)
        assert streams(source)==dict(before,**changes)
        path=d/'input.gxw';path.write_bytes(source)
        prediction=None;predicted=None
        if config and config.get('predict_source'):
            from source_q_st_calls import predict
            prediction=predict(source);predicted=prediction.pop('output');(d/'predicted-0.bin').write_bytes(predicted)
        save(d/'before-native.json',dict(case=case,input_sha256=sha256(source),root_source=main,fb_source=body,
            formals=[dict(name=r.name,type=r.data_type,class_code=r.class_code,record_id=r.record_id) for r in formal.rows],receipts=receipts,prediction=prediction,
            hypotheses=['Capture address at call entry: array[0] becomes 21, array[1] remains 22.',
                'Direct late binding: after idx increments, value may read/write array[1] (32).',
                'Copy-in with recalculated copy-back: array[0] remains 11, array[1] becomes 21.',
                'VAR_OUTPUT address timing may differ from VAR_IN_OUT; frozen index is the control.']))
        ready.append((case,d,path,predicted))
    rows=[];requests=[];keys=[]
    for case,d,path,predicted in ready:
        native,checked,process=observe(path,d,trace)
        messages=[json.loads(l) for l in (native/'events.jsonl').read_text().splitlines()]
        events=[m['payload'] for m in messages if m.get('type')=='send']
        errors=[m for m in messages if m.get('type')=='error' or 'error' in m.get('payload',{}).get('event','') or m.get('payload',{}).get('observation_error')]
        generated=[]
        for g in checked['generated']:
            code=(native/f'pcode-{g["index"]}-0.bin').read_bytes()
            generated.append(dict(name=g['name'],index=g['index'],bytes=len(code),sha256=sha256(code)))
            if code:requests.append(dict(mode='decode',case=case,input_base64=base64.b64encode(code+b'\0').decode()));keys.append((case,g['name'],g['index']))
        row=dict(case=case,native_directory=str(native),process=process,check=checked['check'],diagnostics=checked['diagnostics'],trace_errors=errors,generated=generated,
            prediction_identical=None if predicted is None else predicted==(native/'pcode-0-0.bin').read_bytes(),
            temporary_events=[e for e in events if e.get('event','').startswith('temporary-')],index_events=[e for e in events if e.get('event')=='index-register-lifetime'])
        if checked['exported_sha256']:
            rd=d/'reopen';rd.mkdir();rn,rc,rp=observe(native/'native-saved.gxw',rd,trace)
            row['reopen']=dict(native_directory=str(rn),check=rc['check'],diagnostics=rc['diagnostics'],identical=all(
                (native/f'pcode-{g["index"]}-0.bin').read_bytes()==(rn/f'pcode-{g["index"]}-0.bin').read_bytes() for g in checked['generated']))
        rows.append(row);save(OUT/'comparison.json',rows)
        print(json.dumps(dict(case=case,check=row['check'],generated=generated,prediction_identical=row['prediction_identical'],diagnostics=sorted(set(hex(e['code']) for e in row['diagnostics'] if e['kind']==2)),
            trace_errors=errors,reopen=row.get('reopen',{}).get('identical'))),flush=True)
        if errors:raise RuntimeError('trace incomplete')
    if requests:
        decoded=native_batch(requests,OUT/'native-decode',dll=Q_DLL,cpu_code=209,native_versions=(25,))
        save(OUT/'native-listings.json',[dict(case=k[0],resource=k[1],index=k[2],return_code=r['return_code'],records=native_il_records(base64.b64decode(r['output_base64']),encoding='cp932')) for k,r in zip(keys,decoded)])


if __name__=='__main__':main()
