"""Source-only prediction of measured straight-line local ST FB transfers.

Research compiler-output model, not a semantics-preserving generator. In the
measured profile an indexed IN_OUT is copied in and copied back with a freshly
computed index; an indexed OUTPUT is an alias to Z16 and can be clobbered by
body indexing. These are deliberately reported as distinct transfer phases.
Only Q03UDV local INTs, zero-based one-dimensional INT arrays, +/-, assignments
and explicitly selected local FB definitions are accepted. No compiler cache.
"""
import re
from gxw.lossless import sha256
from gxw.project_metadata import read_project_text_context
from probe_gxw_st_sources import replace_observed_st
from probe_gxw_operand_bindings import split_operands
from probe_minimal_conditional_port_writes import streams
from source_q_direct_declarations import DirectDeclarations
from source_q_st_expressions import expression
from source_q_label_binding import scalar,integer16
from source_q_width import rewrite


def predict(source,definitions=('Wrapper',)):
    content={k:v for k,v in streams(source).items() if k!='CGTable.dat'}
    context=read_project_text_context(next(v for k,v in content.items() if k.endswith('.prj')))
    if context['cpu']!='Q03UDV':raise ValueError('unmeasured ST call CPU')
    owner='POU_01';decl=DirectDeclarations(content,context['text_encoding'],local_fb_definitions=definitions);decl.add_owner(owner)
    if any(decl.ranges[f]['handling']!='unset' for f in ('W','R','ZR')):raise ValueError('ST call profile requires default D temporaries')
    slots=[];records=[];events=[];transfers=[]
    def value(raw,slot=None,**metadata):return dict(raw=raw,slot=slot,**metadata)
    def emit(family,variant,*operands):records.append(rewrite(bytes([5,family,3,variant,5])+b''.join(o['raw'] for o in operands)))
    def acquire(width=1):
        for i,s in enumerate(slots):
            if s['state']==2 and s['width']==width:
                s['state']=1;events.append(dict(action='reuse',slot=i,number=s['number'],width=width));return value(s['raw'],i)
        family,number,_=decl.allocate('D',width,fixed_pool='D')
        i=len(slots);slots.append(dict(state=1,width=width,family=family,number=number,raw=scalar(family,number)))
        events.append(dict(action='create',slot=i,number=number,width=width));return value(slots[i]['raw'],i)
    def release(v):
        if v['slot'] is not None:
            i=v['slot'];assert slots[i]['state']==1;slots[i]['state']=2;events.append(dict(action='release',slot=i))
    def item(scope,name):
        result=decl.bound[scope].get(name.casefold())
        if result is None:raise ValueError('unresolved local name '+name)
        return result
    def variable(scope,name,aliases):
        if name.casefold() in aliases:return value(aliases[name.casefold()]['raw'])
        it=item(scope,name)
        if it['row'].data_type!='INT' or it.get('port') or it.get('dimensions'):raise ValueError('outside local scalar INT')
        return value(decl.bind(scope,name.encode(context['text_encoding'])))
    def indexed(node):return isinstance(node,tuple) and node[0]=='index'
    def contains_index(node):return indexed(node) or isinstance(node,tuple) and any(contains_index(x) for x in node[1:])
    def address(scope,node,aliases,register=16):
        _,name,index=node;it=item(scope,name)
        if it.get('port') or it['row'].type_code!=2 or len(it.get('dimensions',()))!=1 or it['dimensions'][0]['lower']!=0 or it['family']!='D':
            raise ValueError('outside local zero-based INT array addressing')
        if isinstance(index,int):return value(decl.bind(scope,f'{name}[{index}]'.encode(context['text_encoding'])))
        if contains_index(index):raise ValueError('nested array indices have known native register-clobber counterexamples')
        iv=lower(scope,index,aliases)
        z=value(bytes([4,0xcc,register,4]))
        if register==16:
            emit(0x49,8,iv,value(integer16(1)),z);release(iv)
        elif register==18:
            temporary=acquire(2);emit(0x49,8,iv,value(integer16(1)),temporary);release(iv)
            emit(0x4c,1,temporary,z);release(temporary)
        else:raise ValueError('index register outside measured pair')
        return value(bytes([4,0xf0,register,4])+scalar(it['family'],it['number']),indexed=True)
    def lower(scope,node,aliases,destination=None,register=16):
        if isinstance(node,str):return variable(scope,node,aliases)
        if isinstance(node,int):return value(integer16(node))
        if indexed(node):return address(scope,node,aliases,register)
        op,left,right=node
        if op not in ('+','-'):raise ValueError('arithmetic operator')
        if (contains_index(left) and isinstance(left,tuple) and not indexed(left)) or (contains_index(right) and isinstance(right,tuple) and not indexed(right)):
            raise ValueError('indexed arithmetic subtree materialization not yet modeled')
        lhs=lower(scope,left,aliases)
        rhs=lower(scope,right,aliases,register=18 if lhs.get('indexed') else 16)
        target=destination if destination is not None else acquire()
        if target['raw']==lhs['raw']:
            emit(0x49,0 if op=='+' else 2,rhs,target)
        elif op=='+' and target['raw']==rhs['raw']:emit(0x49,0,lhs,target)
        else:emit(0x49,1 if op=='+' else 3,lhs,rhs,target)
        release(lhs);release(rhs);return target
    def assign(scope,target,node,aliases):
        if isinstance(target,str):
            it=item(scope,target)
            if it['row'].class_code==3:raise ValueError('assignment to VAR_INPUT rejected by measured frontend')
            destination=variable(scope,target,aliases)
        elif indexed(target) and isinstance(target[2],int):destination=address(scope,target,aliases)
        else:raise ValueError('dynamic array assignment outside ST call profile')
        if isinstance(node,tuple) and not indexed(node):lower(scope,node,aliases,destination)
        else:
            source_value=lower(scope,node,aliases);emit(0x4c,0,source_value,destination);release(source_value)
    def body(scope,definition,aliases,allow_calls):
        _,text=replace_observed_st(content[definition+'.Program.pou'],'')
        for statement in text.split(';'):
            statement=statement.strip()
            if not statement:continue
            call=re.fullmatch(r'([A-Za-z_][A-Za-z_0-9]*)\s*\((.*)\)',statement,re.S)
            if call:
                if not allow_calls:raise ValueError('nested FB calls outside measured profile')
                actuals={}
                for arg in split_operands(call[2]):
                    name,actual=arg.split(':=',1);name=name.strip().casefold()
                    if name in actuals:raise ValueError('duplicate named actual')
                    actuals[name]=expression(actual.strip())
                invoke(scope,call[1],actuals,aliases);continue
            if ':=' not in statement:raise ValueError('outside straight-line ST statements')
            target,rhs=statement.split(':=',1);assign(scope,expression(target.strip()),expression(rhs.strip()),aliases)
    def invoke(scope,name,actuals,parent_aliases):
        instance=item(scope,name)
        if 'instance' not in instance:raise ValueError('not a selected local FB')
        child=instance['instance'];definition=instance['row'].data_type
        ports={k:v for k,v in decl.bound[child].items() if v.get('port')}
        if set(actuals)!=set(ports):raise ValueError('all measured ports must have named actuals')
        aliases={};copybacks=[];row=dict(instance=child,definition=definition,bindings=[]);transfers.append(row)
        for key,port in sorted(ports.items(),key=lambda kv:(kv[1]['row'].class_code,kv[1]['row'].record_id)):
            formal=port['row'];actual=actuals[key]
            if formal.data_type!='INT' or formal.class_code not in (4,5):raise ValueError('only INT OUTPUT/IN_OUT ports modeled')
            if indexed(actual) and not isinstance(actual[2],int):
                binding=address(scope,actual,parent_aliases)
                if formal.class_code==5:
                    temporary=acquire();emit(0x4c,0,binding,temporary)
                    aliases[key]=temporary;copybacks.append((actual,temporary))
                    row['bindings'].append(dict(port=key,mode='copy-in-and-recompute-index-for-copy-back'))
                else:
                    aliases[key]=binding;row['bindings'].append(dict(port=key,mode='indexed-alias-before-body',register=16,
                        caveat='body index generation can overwrite this register'))
            else:
                aliases[key]=address(scope,actual,parent_aliases) if indexed(actual) else variable(scope,actual,parent_aliases)
                row['bindings'].append(dict(port=key,mode='direct-alias'))
        body(child,definition,aliases,False)
        for actual,temporary in copybacks:
            binding=address(scope,actual,parent_aliases);emit(0x4c,0,temporary,binding);release(temporary)
    body(owner,owner,{},True)
    code=bytes.fromhex('0300030591900105')+b''.join(records)+bytes.fromhex('033303020204340204')
    return dict(output=code,sha256=sha256(code),declarations=decl.allocations,
        slots=[{k:v for k,v in s.items() if k!='raw'} for s in slots],temporary_events=events,transfers=transfers,
        scope='Compiler behavior reproduction only; indexed OUTPUT aliasing is not a semantic-safety guarantee.')
