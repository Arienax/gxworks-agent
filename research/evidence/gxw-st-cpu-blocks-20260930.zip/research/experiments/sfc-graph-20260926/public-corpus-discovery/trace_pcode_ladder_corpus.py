"""Capture every public P -> LD check call in one isolated native project build."""
from pathlib import Path
import argparse
import hashlib
import json
import sys

ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from replay_gxw_workspace import prepare,trace_prepared

SCRIPT=r'''
function hex(p,n){
  if(n<0||n>32768)throw new Error('unobserved input bound');
  return Array.from(new Uint8Array(p.readByteArray(n)), b=>b.toString(16).padStart(2,'0')).join('');
}
let sequence=0;
Process.attachModuleObserver({onAdded(m){
  if(m.name.toLowerCase()!=='eccodegeneratorfx2.dll')return;
  const target=m.findExportByName('ChangePToLDcode');
  if(!target||target.sub(m.base).toUInt32()!==0x37a9)throw new Error('export RVA differs');
  Interceptor.attach(target,{
    onEnter(a){
      try{
        this.n=a[1];this.count=a[3];this.d=a[4];
        const n=this.n.readS32();
        this.row={event:'conversion',id:sequence++,input_hex:hex(a[2],n),input_bytes:n,
          initial_count:this.count.readS32(),capacity:a[5].toInt32(),mode:a[6].toInt32(),
          initial_metadata:[0,1,6].map(o=>this.d.add(o).readU8())};
      }catch(e){send({event:'observation-error',error:String(e)});}
    },
    onLeave(r){
      if(!this.row)return;
      try{
        const code=r.toUInt32();
        send(Object.assign(this.row,{return_code:code,consumed_bytes:this.n.readS32(),count:this.count.readS32(),
          metadata:[0,1,6].map(o=>this.d.add(o).readU8()),
          error_offset:code?m.base.add(0x921a4).readS32():null}));
      }catch(e){send({event:'observation-error',error:String(e)});}
    }
  });
}});
'''

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input',type=Path);parser.add_argument('output',type=Path)
    args=parser.parse_args();out=args.output.resolve();out.mkdir(exist_ok=False)
    dll=Path('D:/GXWORKS2/Easysocket/CodeGenerator/ECCodeGeneratorFX2.dll')
    assert hashlib.sha256(dll.read_bytes()).hexdigest()=='a700da129ede89869a00a5614d08b43dc64e94c240494fc753fe09104c5b9399'
    script=out/'trace.js';script.write_text(SCRIPT,encoding='utf-8')
    (out/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    for attempt in range(1,5):
        native=out/f'native-{attempt}'
        prepare(args.input.resolve(),native,compile=True,export_project=True,program_check=True,project_alias='LDCORPUS')
        trace=trace_prepared(native,script)
        events=[json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
        if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
    messages=[json.loads(l) for l in (native/'events.jsonl').read_text(encoding='utf-8').splitlines()]
    errors=[r for r in messages if r.get('type')=='error' or r.get('payload',{}).get('event')=='observation-error']
    calls=[r['payload'] for r in messages if r.get('payload',{}).get('event')=='conversion']
    summary=dict(trace=trace,errors=errors,calls=len(calls),failures=sum(bool(r['return_code']) for r in calls),
        check_completed=any(e.get('operation')=='ProgramCheckCompleted' for e in events),
        pcode_sha256=hashlib.sha256((native/'pcode-0-0.bin').read_bytes()).hexdigest())
    (out/'calls.json').write_text(json.dumps(calls,indent=2),encoding='utf-8')
    (out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(summary))
    assert summary['check_completed'] and not errors

if __name__=='__main__':main()
