"""Observe dynamic array lowering after isolated real ST declaration mutations."""
import base64
from dataclasses import replace
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.declarations import parse_declarations,edit_declarations,serialize_declarations
from gxw.compiler_debug import parse_compiler_debug
from gxw.token_pou import parse_token_fragment
from probe_gxw_compiled_references import stored_records
from probe_gxw_st_sources import replace_observed_st
from probe_gxw_sfc_graph import patch_raw
from native_gxw_tokens import native_batch,native_il_projection,Q_DLL
from replay_gxw_workspace import run
P=Path(__file__).resolve().parent
OUT=P/'ST-dynamic-array-controls';OUT.mkdir(exist_ok=True)
source=(P/'samples/boxid.gxw').read_bytes()
streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
labels='Keypad.Labels.lh';program='Keypad.Program.pou'
doc=parse_declarations(streams[labels],logical_name=labels)
_,text=replace_observed_st(streams[program],'')
cases=[('wider','ARRAY [0..19] OF STRING[4]','tempString[key_iterator]'),
       ('negative_lower','ARRAY [-2..17] OF STRING[4]','tempString[key_iterator]'),
       ('two_dimensional','ARRAY [-2..1,3..7] OF STRING[4]','tempString[key_iterator,key_iterator]')]
for case,datatype,reference in cases:
    directory=OUT/case;directory.mkdir(exist_ok=True)
    if (directory/'comparison.json').exists():continue
    # The general writer rejects bracketed STRING array element types before
    # native execution. Retain the observed real row's type code/array marker
    # and all other fields for this narrowly bounded research mutation.
    new_labels=serialize_declarations(replace(doc,rows=tuple(replace(r,data_type=datatype) if r.name=='tempString' else r for r in doc.rows)))
    changed,receipt=patch_raw(source,labels,streams[labels],new_labels)
    receipts=[receipt]
    changed_text=text.replace('tempString[key_iterator]',reference)
    if changed_text!=text:
        new_program,_=replace_observed_st(streams[program],changed_text)
        changed,receipt=patch_raw(changed,program,streams[program],new_program);receipts.append(receipt)
    payloads={s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}
    assert all(payloads[n]==raw for n,raw in streams.items() if n not in [labels,program])
    path=directory/'changed.gxw';path.write_bytes(changed)
    (directory/'mutation.json').write_text(json.dumps(dict(source_sha256=sha256(source),changed_sha256=sha256(changed),
        datatype=datatype,reference=reference,receipts=receipts,unrelated_logical_payloads='byte-identical'),indent=2),encoding='utf-8')
    q=[dict(name='all',keys=[],symbol='',scope='',declared=0,plural=0)]
    assignment=[dict(name='tempString',keys=[dict(category=1,value='tempString'),dict(category=4,value='POU_01.Keypad_1')])]
    native=run(path,directory/'native',compile=True,export_project=True,project_alias='DYNARRAY',analysis_queries=q,
               analysis_version=3,assignment_queries=assignment)
    result=dict(case=case,datatype=datatype,native={k:native[k] for k in ['returncode','compile_completed','compiler_rejected','diagnostics']})
    if native.get('native_export'):
        reopened=run(directory/'native/native-saved.gxw',directory/'reopen',compile=True,export_project=True,assignment_queries=assignment)
        result['reopen']={k:reopened[k] for k in ['returncode','compile_completed','compiler_rejected','diagnostics']}
        result['reopen_pcode_equal']=native['outputs']==reopened['outputs']
        result['assignments']=json.loads((directory/'native/native-device-assignments.json').read_text(encoding='utf-8-sig'))
        saved={s.logical_name:s.raw for s in inspect_project((directory/'native/native-saved.gxw').read_bytes()).streams if s.logical_name}
        debug=parse_compiler_debug(saved['DebugInformation2.dat'])
        binary=(directory/'native/pcode-0-0.bin').read_bytes()
        groups,_=stored_records(parse_token_fragment(binary,0,len(binary)),encoding='cp1252')
        refs=json.loads((directory/'native/native-program-analysis.json').read_text(encoding='utf-8-sig'))['queries'][0]['rows']
        results=[];requests=[]
        for ref in refs:
            if ref['address'] or ref['source']!='Keypad' or not ref['name'].startswith('tempString['):continue
            for index,e in enumerate(debug.elements):
                if e.names[2]!=b'Keypad':continue
                rows=[r for r in debug.offset_tables[e.offset_table_index].rows if r[0]+e.fields[0]==ref['top']]
                output=[g for r in rows for g in groups if e.linked_step_start+r[1]<=g['stored_step']<=e.linked_step_start+r[2]]
                item=dict(reference=ref,source_line=changed_text.splitlines()[ref['top']],debug_rows=rows,compiled=[])
                for g in output:
                    item['compiled'].append(dict(request=len(requests),offset=g['offset'],raw_hex=g['raw'].hex()))
                    requests.append(dict(mode='decode',input_base64=base64.b64encode(g['raw']+b'\0').decode()))
                results.append(item)
        answers=native_batch(requests,directory/'native-lowering-decode',dll=Q_DLL,cpu_code=209)
        for item in results:
            for g in item['compiled']:
                a=answers[g['request']]
                g['return_code']=a['return_code']
                if a['return_code']=='0x00000000' and a['consumed_bytes']==len(bytes.fromhex(g['raw_hex'])):
                    g['records']=native_il_projection(base64.b64decode(a['output_base64']),encoding='cp1252')['records']
        result['lowering']=results
    (directory/'comparison.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in ['assignments','lowering']}|dict(lowering=[dict(line=r['source_line'],instructions=[x for g in r['compiled'] for x in g.get('records',[])]) for r in result.get('lowering',[])])),flush=True)
