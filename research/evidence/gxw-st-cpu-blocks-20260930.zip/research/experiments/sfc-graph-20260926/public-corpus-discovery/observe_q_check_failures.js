// Read-only function-boundary observers in a newly spawned owned helper.
let checkActive=false,sequence=0;
const progressTargets=new Set();
const additionalTargets=new Set();
function emit(row){send({...row,trace_sequence:++sequence});}
function hex(p,n){if(n<0||n>65536)throw new Error('buffer bound');return Array.from(new Uint8Array(p.readByteArray(n)),b=>b.toString(16).padStart(2,'0')).join('');}
function loc(p){const m=Process.findModuleByAddress(p);return m?{module:m.name,rva:p.sub(m.base).toString()}:{address:p.toString()};}
function stack(ctx){return Thread.backtrace(ctx,Backtracer.ACCURATE).slice(0,18).map(loc);}
function cstring(p){if(p.isNull())return null;const b=[];for(let i=0;i<1024;i++){const v=p.add(i).readU8();if(!v)return b.map(v=>v.toString(16).padStart(2,'0')).join('');b.push(v);}throw new Error('string bound');}
function report68(p){const list=p.add(64).readPointer(),args=[];if(!list.isNull()){
 const n=list.add(4).readS32();if(n<0||n>128)throw new Error('argument bound');const a=list.readPointer();
 for(let i=0;i<n;i++){const s=a.add(i*8),n=s.add(4).readS32();args.push({size:n,text_hex:cstring(s.readPointer())});}
 }return {raw:hex(p,68),kind:p.readS32(),code:p.add(4).readU32(),library_hex:cstring(p.add(8).readPointer()),
 name_hex:cstring(p.add(16).readPointer()),type:p.add(24).readU32(),instance_hex:cstring(p.add(28).readPointer()),step:p.add(40).readS32(),arguments:args};}
function progress(target,label){
 if(progressTargets.has(target.toString()))return;progressTargets.add(target.toString());
 emit({event:'progress-target',label,target:loc(target)});
 Interceptor.attach(target,{onEnter(a){if(!checkActive)return;this.out=a[0];this.count=a[1];this.reports=a[2];this.code=a[3];this.callstack=stack(this.context);},onLeave(r){
  if(!this.code)return;try{emit({event:'progress-result',label,target:loc(target),hresult:r.toInt32(),code:this.code.readU32(),percent:this.out.readS32(),count:this.count.readS32(),stack:this.callstack});}
  catch(e){emit({event:'observation-error',error:String(e)});}
 }});
}
Process.attachModuleObserver({onAdded(m){
 const name=m.name.toLowerCase();
 if(name==='dzdataabs_compileradapter.dll'){
  Interceptor.attach(m.base.add(0x15061),{onEnter(){checkActive=true;emit({event:'checking-start'});}});
  Interceptor.attach(m.base.add(0x13a2a),{onEnter(){this.selected=this.returnAddress.equals(m.base.add(0x13e75));},onLeave(r){
   if(!this.selected)return;try{const object=r.readPointer();progress(object.readPointer().add(4).readPointer(),'adapter-selected');}
   catch(e){emit({event:'observation-error',error:String(e)});}
  }});
  Interceptor.attach(m.base.add(0x8e48),{onEnter(a){if(!checkActive)return;try{this.out=a[1];this.code=a[2];this.row={event:'report-conversion',source:report68(a[0])};}catch(e){emit({event:'observation-error',error:String(e)});}},onLeave(r){if(!this.row)return;try{emit({...this.row,result:r.toInt32(),code:this.code.readU32(),output:hex(this.out,100)});}catch(e){emit({event:'observation-error',error:String(e)});}}});
  Interceptor.attach(m.base.add(0x9674),{onEnter(){if(!checkActive)return;try{
   const backend=this.context.ecx.add(0x14).readPointer(),target=backend.readPointer().add(0x2c).readPointer();
   if(!additionalTargets.has(target.toString())){
    additionalTargets.add(target.toString());emit({event:'backend-progress-target',target:loc(target)});
    Interceptor.attach(target,{onEnter(a){this.percent=a[1];this.count=a[2];this.rows=a[3];this.code=a[4];},onLeave(r){try{
     const count=this.count.readS32(),rows=[];if(count<0||count>10000)throw new Error('reports bound');
     const p=this.rows.readPointer();if(!p.isNull())for(let i=0;i<count;i++)rows.push(report68(p.add(i*68)));
     emit({event:'backend-progress-result',result:r.toInt32(),percent:this.percent.readS32(),count,code:this.code.readU32(),rows});
    }catch(e){emit({event:'observation-error',error:String(e)});}}});
   }
   const ws=this.context.ecx.add(0x18).readPointer(),lookup=ws.readPointer().add(0x6f8).readPointer();
   if(!additionalTargets.has(lookup.toString())){
    additionalTargets.add(lookup.toString());emit({event:'report-lookup-target',target:loc(lookup)});
    Interceptor.attach(lookup,{onEnter(a){if(!checkActive)return;try{
     this.out=a[15];this.code=a[16];const n=a[14].isNull()?0:a[14].sub(4).readU32();if(n>4096||n%2)throw new Error('bstr bound');
     this.row={event:'report-object-lookup',parent_id:Array.from({length:12},(_,i)=>a[i+1].toUInt32()),kind:a[13].toUInt32(),name:a[14].isNull()?null:a[14].readUtf16String(n/2),stack:stack(this.context)};
    }catch(e){emit({event:'observation-error',error:String(e)});}},onLeave(r){if(this.row)emit({...this.row,result:r.toInt32(),code:this.code.readU32(),object_id:hex(this.out,48)});}});
   }
  }catch(e){emit({event:'observation-error',error:String(e)});}}});
 }
 if(name==='eccodegenerator2.dll'){
  const target=m.findExportByName('ChangePToLDcode');
  if(!target||target.sub(m.base).toUInt32()!==0x5b44){emit({event:'observation-error',error:'Q public conversion RVA guard'});return;}
  Interceptor.attach(target,{onEnter(a){try{
   this.length=a[1];this.count=a[3];this.d=a[4];
   this.row={event:'q-pcode-to-ladder',check_active:checkActive,input_hex:hex(a[2],this.length.readS32()),input_bytes:this.length.readS32(),
    count_before:this.count.readS32(),capacity:a[5].toInt32(),mode:a[6].toInt32(),metadata_before:[0,1,6].map(o=>this.d.add(o).readU8()),stack:stack(this.context)};
  }catch(e){emit({event:'observation-error',error:String(e)});}},onLeave(r){if(!this.row)return;try{
   emit({...this.row,result:r.toUInt32(),consumed_bytes:this.length.readS32(),count_after:this.count.readS32(),metadata_after:[0,1,6].map(o=>this.d.add(o).readU8())});
  }catch(e){emit({event:'observation-error',error:String(e)});}}});
  Interceptor.attach(m.findExportByName('GetErrorOffset'),{onEnter(a){this.out=a[1];},onLeave(r){try{emit({event:'q-error-offset',result:r.toUInt32(),offset:this.out.readS32()});}catch(e){emit({event:'observation-error',error:String(e)});}}});
 }
 if(name==='eccompiler_iec.dll'){
  for(const rva of [0x3b630,0x3caf0])Interceptor.attach(m.base.add(rva),{onEnter(a){try{
   this.len=a[0];this.step=a[2];this.row={event:'iec-check-block',rva,check_active:checkActive,input_hex:hex(a[1],this.len.readS32()),step:this.step.readS32(),stack:stack(this.context)};
  }catch(e){emit({event:'observation-error',error:String(e)});}},onLeave(r){if(this.row&&r.toInt32()!==0)emit({...this.row,result:r.toUInt32(),length_after:this.len.readS32(),step_after:this.step.readS32()});}});
  Interceptor.attach(m.base.add(0x3a3c0),{onEnter(a){emit({event:'iec-report-error',code:a[0].toUInt32(),step:a[2].toInt32(),stack:stack(this.context)});}});
 }
 if(name==='kernelbase.dll'){
  const target=m.findExportByName('RaiseException');if(!target)return;
  Interceptor.attach(target,{onEnter(a){if(!checkActive||a[0].toUInt32()!==0xe06d7363)return;
   emit({event:'native-cpp-exception',code:a[0].toUInt32(),parameters:Math.min(a[2].toUInt32(),15),stack:stack(this.context)});
  }});
 }
}});
