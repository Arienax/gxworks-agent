"""Read both native allocation getters for independently sourced projects."""
import base64
import hashlib
import json
from pathlib import Path
import struct
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'research')]
from gxw.lossless import inspect_project
from probe_gxw_native_listing import project_text_context
from replay_gxw_workspace import run

P = Path(__file__).resolve().parent
OUT = P / 'native-allocation-inventory'
OUT.mkdir(exist_ok=False)
files = list((P / 'samples').glob('*.gxw')) + sorted((P / 'noeul-native-batch').glob('case-*/input.gxw'))
seen = set()
for index, source in enumerate(files):
    raw = source.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    if digest in seen:
        continue
    seen.add(digest)
    row = dict(source=str(source), source_sha256=digest, case=index)
    try:
        project = next(s for s in inspect_project(raw).streams if (s.logical_name or '').endswith('.prj'))
        context = project_text_context(project.raw)
        start = context['codepage_offset'] + 4
        count = struct.unpack_from('<I', project.raw, start + 88)[0]
        predicted_offset = start + 138 + count * 4
        row.update(cpu=context['cpu'], codepage=context['codepage'], intervening_count=count,
                   extended_predicted_offset=predicted_offset)
        directory = OUT / ('case-' + str(index).zfill(2))
        outcome = run(source, directory, snapshot_frontend=True, project_alias='RANGE' + str(index))
        row['native'] = {k: outcome[k] for k in ['returncode', 'open_succeeded', 'last_event']}
        ranges = json.loads((directory / 'system-variable-ranges.json').read_text())
        legacy, extended = [base64.b64decode(ranges[key]) for key in ['legacy_base64', 'extended_base64']]
        matches = [i for i in range(len(project.raw)) if project.raw.startswith(extended, i)]
        row.update(native_legacy_equals_extended=legacy == extended[4:92],
                   native_extended_matches=matches,
                   native_extended_equals_predicted=project.raw[predicted_offset:predicted_offset + 228] == extended,
                   native_legacy_equals_stored_legacy=project.raw[start:start + 88] == legacy,
                   extended_base64=ranges['extended_base64'])
        snap_path = directory / 'frontend-snapshot.json'
        if snap_path.exists():
            snap = json.loads(snap_path.read_text())
            converter = base64.b64decode(snap['parameter']['raw'])[8:]
            row['converter_equals_native_legacy'] = converter == legacy
    except Exception as exc:
        row['error'] = str(exc)
    with (OUT / 'results.jsonl').open('a', encoding='utf-8') as output:
        output.write(json.dumps(row) + '\n')
    print(json.dumps({k: v for k, v in row.items() if k not in ['source', 'extended_base64', 'native']}), flush=True)
