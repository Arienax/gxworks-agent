"""Distinguish constant names, Z indexing, and ordinary-ladder array use."""
from pathlib import Path
import base64,json,struct,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.declarations import parse_declarations,edit_declarations,serialize_declarations
from probe_gxw_simple_fb import frame_source,observe_calls
from probe_gxw_parameters import device_allocation_record
from probe_gxw_sfc_graph import patch_raw
from native_gxw_tokens import native_batch,Q_DLL
from replay_gxw_workspace import run
P=Path(__file__).resolve().parent
out=P/'scpi-array-index-resolution';out.mkdir(exist_ok=False)
source=(P/'scpi-label-inputs/local-array-dynamic/changed.gxw').read_bytes()
streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
name='MAIN.Program.pou';frame=frame_source(streams[name]);call=observe_calls(frame)['calls'][0]
plans=[dict(case='constant-index-name',value="'InputWords[InputIndex]",index_constant=True),
       dict(case='z0-index',value="'InputWords[Z0]"),
       dict(case='ordinary-ladder-dynamic',value='K1',prefix="LD SM400\0MOV 'InputWords[InputIndex] D500")]
requests=[]
for plan in plans:
 text=f"LD X1F\0OUT '_iEn\0LD '_TRUE\0MOV {plan['value']} '_iUnitNo"
 plan['replacement_index']=len(requests);requests.append(dict(mode='encode',text=text,input_base64=base64.b64encode(text.encode()+b'\0\0').decode()))
 if plan.get('prefix'):
  text=plan['prefix'];plan['prefix_index']=len(requests);requests.append(dict(mode='encode',text=text,input_base64=base64.b64encode(text.encode()+b'\0\0').decode()))
answers=native_batch(requests,out/'native-encode',dll=Q_DLL,cpu_code=209,native_versions=(25,),device_context=device_allocation_record(streams['Param.wpa']).raw)
for plan in plans:
 directory=out/plan['case'];directory.mkdir();answer=answers[plan['replacement_index']];assert answer['return_code']=='0x00000000'
 a=call['input_fragment']['offset'];b=a+call['input_fragment']['length'];replacement=base64.b64decode(answer['output_base64'])
 program=frame.raw[:a]+replacement+frame.raw[b:]
 if 'prefix_index' in plan:
  answer=answers[plan['prefix_index']];assert answer['return_code']=='0x00000000'
  prefix=base64.b64decode(answer['output_base64']);program=program[:frame.body_offset]+prefix+program[frame.body_offset:]
 program=bytearray(program);delta=len(program)-len(frame.raw)
 for offset in [55,59]:struct.pack_into('<I',program,offset,struct.unpack_from('<I',frame.raw,offset)[0]+delta)
 changed,receipt=patch_raw(source,name,frame.raw,bytes(program));receipts=[receipt];touched=[name]
 if plan.get('index_constant'):
  labels='MAIN.Labels.lh';doc=parse_declarations(streams[labels],logical_name=labels)
  new=serialize_declarations(edit_declarations(doc,upserts=[dict(name='InputIndex',class_name='VAR_CONSTANT',initial_value='1')]))
  changed,receipt=patch_raw(changed,labels,streams[labels],new);receipts.append(receipt);touched.append(labels)
 after={s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}
 assert all(after[k]==v for k,v in streams.items() if k not in touched)
 path=directory/'changed.gxw';path.write_bytes(changed)
 (directory/'mutation.json').write_text(json.dumps(dict(plan,source_sha256=sha256(source),changed_sha256=sha256(changed),receipts=receipts,unrelated_payloads='byte-identical'),indent=2))
 for attempt in range(1,9):
  target=directory/('native' if attempt==1 else 'native-v'+str(attempt))
  result=run(path,target,compile=True,export_project=True,project_alias='SCPIINDEXRESOLVE')
  events=[json.loads(s) for s in (target/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
  if (target/'pcode-0-0.bin').exists() or not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
 row=dict(plan,native_directory=str(target.relative_to(P)),native={k:result[k] for k in ['returncode','compile_completed','compiler_rejected','diagnostics','outputs']})
 (directory/'comparison.json').write_text(json.dumps(row,indent=2));print(json.dumps(dict(case=plan['case'],native={k:row['native'][k] for k in ['returncode','compile_completed','compiler_rejected','diagnostics']})),flush=True)
