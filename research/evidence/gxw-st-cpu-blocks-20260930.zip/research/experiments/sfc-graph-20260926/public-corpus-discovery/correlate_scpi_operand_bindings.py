"""Compare preserved real SCPI source operands to exact native expansions."""
from pathlib import Path
import argparse,base64,collections,json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.compiler_tables import parse_compiler_tables
from gxw.compiler_debug import parse_compiler_debug
from gxw.token_pou import parse_token_fragment
from probe_gxw_simple_fb import frame_source
from probe_gxw_compiled_references import stored_records
from probe_gxw_operand_bindings import resolve_simple_instance_label
from native_gxw_tokens import native_batch,native_il_projection,Q_DLL
P=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
value_cases=[kind+'-'+order for kind in ['int','dint','string'] for order in ['literal-first','device-first']]
indexed_cases=['indexed-int-z0','indexed-int-z1','indexed-int-indirect','indexed-int-buffer']
label_cases=['label-'+s for s in ['local-auto','global-address','global-constant','local-array-static','global-array-static']]
parser.add_argument('cases',nargs='*',choices=['two','same','compound','first','last','guarded-int-literal','guarded-int-device']+value_cases+indexed_cases+label_cases)
parser.add_argument('--output-dir',type=Path,default=P/'scpi-exact-instance-operands')
args=parser.parse_args();OUT=args.output_dir
original={s.logical_name:s.raw for s in inspect_project((P/'samples/scpi-SCPI_FB.gxw').read_bytes()).streams if s.logical_name}
CASES={'two':'scpi-two-callers/native','same':'scpi-instance-binding-controls/same-instance/native',
       'compound':'native-fb-connection-type-controls/compound/native',
       'first':'scpi-repeated-complex-enable/first/native','last':'scpi-repeated-complex-enable/last/native'}
CASES.update({case:'scpi-repeated-value-inputs/'+case+'/native' for case in value_cases})
CASES.update({case:'scpi-guarded-inputs/'+case.removeprefix('guarded-')+'/native' for case in ['guarded-int-literal','guarded-int-device']})
CASES.update({case:'scpi-indexed-inputs/'+case.removeprefix('indexed-')+'/native' for case in indexed_cases})
CASES.update({case:'scpi-label-inputs/'+case.removeprefix('label-')+'/native' for case in label_cases})
for case in args.cases or ['two','same']:
 native=P/CASES[case];out=OUT/case;out.mkdir(parents=True,exist_ok=False)
 outcome=json.loads((native/'outcome.json').read_text(encoding='utf-8'))
 if not outcome['compile_completed'] or outcome['compiler_rejected'] or outcome.get('timed_out'):
  raise ValueError('Native compile did not accept this source; output presence is not validation')
 source=(native/'native-saved.gxw').read_bytes()
 streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
 # The historical native export normalizes byte 50 in these source envelopes.
 preservation={}
 for name in ('SCPI.Program.pou','SCPI.Labels.lh'):
  a,b=original[name],streams[name]
  differences=[i for i,(x,y) in enumerate(zip(a,b)) if x!=y]
  assert len(a)==len(b) and differences in ([],[50])
  preservation[name]=dict(original_sha256=sha256(a),export_sha256=sha256(b),changed_offsets=differences)
 raw=(native/'compiler_DZComp/CGTable.dat').read_bytes();tables=parse_compiler_tables(raw)
 debugraw=(native/'compiler_DZComp/DebugInformation2.dat').read_bytes();debug=parse_compiler_debug(debugraw)
 groups,_=stored_records(frame_source(streams['SCPI.Program.pou']),encoding='cp932')
 binaries={};compiled={}
 for line in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines():
  e=json.loads(line)
  if e.get('operation')!='Resource':continue
  f='pcode-'+str(e['index'])+'-0.bin';blob=(native/f).read_bytes()
  assert sha256(blob)==outcome['outputs'][f]['sha256']
  binaries[e['name']]=dict(file=f,sha256=sha256(blob))
  compiled[e['name']],_=stored_records(parse_token_fragment(blob,0,len(blob)),encoding='cp932')
 requests=[];dedup={}
 def capture(group):
  blob=group['raw'];key=sha256(blob)
  if key not in dedup:
   dedup[key]=len(requests);requests.append(dict(mode='decode',input_base64=base64.b64encode(blob+b'\0').decode()))
  return dict(offset=group['offset'],stored_step=group['stored_step'],stored_width=group['stored_width'],
              raw_base64=base64.b64encode(blob).decode(),sha256=key,decode_request=dedup[key])
 expansions=[]
 for index,e in enumerate(debug.elements):
  if e.names[2]!=b'SCPI':continue
  parent=[tables.pou_at(r.table_offset) for r in tables.tables[1].records if tables.pou_at(r.table_offset).name_bytes==e.names[3]]
  assert len(parent)==1
  instances=[c for c in tables.components(parent[0]) if c.name_bytes==e.names[4]];assert len(instances)==1
  instance=instances[0];assert tables.pou_at(instance.instance_pou_offset).name_bytes==e.names[2]
  table=debug.offset_tables[e.offset_table_index];resource=e.resource_bytes.decode('ascii');rows=[]
  def empty_parent(p):
   return (p.linked_step_start==p.linked_step_end==e.linked_step_start
           and debug.offset_tables[p.offset_table_index].rows==((0,0,0,-1,7,-1),))
  preceding=[(i,p) for i,p in enumerate(debug.elements) if p.names[2]==e.names[3] and p.names[4]==b''
             and p.resource_bytes==e.resource_bytes and (p.linked_step_end+1==e.linked_step_start or empty_parent(p))]
  assert len(preceding)==1
  parent_index,parent_debug=preceding[0]
  parent_code=[capture(c) for c in compiled[resource] if parent_debug.linked_step_start<=c['stored_step']<e.linked_step_start]
  for g in groups:
   mapped=[r for r in table.rows if r[0]+e.fields[0]==g['stored_step']]
   selected={c['offset']:c for r in mapped for c in compiled[resource]
             if e.linked_step_start+r[1]<=c['stored_step']<=e.linked_step_start+r[2]}
   rows.append(dict(source=capture(g),debug_rows=[list(r) for r in mapped],
                    compiled=[capture(c) for c in selected.values()]))
  expansions.append(dict(element=index,raw_debug_base64=base64.b64encode(e.raw).decode(),
                          instance=instance.name_bytes.decode('ascii'),instance_offset=instance.record.table_offset,
                          instance_pou_offset=instance.instance_pou_offset,parent=e.names[3].decode('ascii'),resource=resource,rows=rows,
                          parent_debug_index=parent_index,parent_source_step=parent_debug.fields[0],parent_compiled_groups=parent_code))
  expansions[-1]['parent_debug_boundary']='empty-marker-overlaps-FB-entry' if empty_parent(parent_debug) else 'preceding-code-interval'
 answers=native_batch(requests,out/'native-decode',dll=Q_DLL,cpu_code=209)
 decoded=[]
 for request,answer in zip(requests,answers):
  assert answer['return_code']=='0x00000000'
  assert answer['consumed_bytes']==len(base64.b64decode(request['input_base64']))-1
  decoded.append(native_il_projection(base64.b64decode(answer['output_base64']),encoding='cp932'))
 for expansion in expansions:
  expansion['parent_compiled_records']=[r for g in expansion['parent_compiled_groups'] for r in decoded[g['decode_request']]['records']]
  counts=collections.Counter()
  for row in expansion['rows']:
   source_records=decoded[row['source']['decode_request']]
   actual=[r for c in row['compiled'] for r in decoded[c['decode_request']]['records']]
   row['source_records']=source_records['records'];row['compiled_records']=actual
   expected=[];bindings=[];gaps=[]
   if source_records['text_gaps'] or any(decoded[c['decode_request']]['text_gaps'] for c in row['compiled']):gaps.append('native text decoding gaps')
   for record in source_records['records']:
    record=dict(record)
    if record['kind']=='instruction':
     args=[]
     for argument in record['args']:
      if argument.startswith("'"):
       bound=resolve_simple_instance_label(argument,expansion['instance_offset'],tables,cpu='Q03UDV',encoding='cp932');bindings.append(bound)
       if bound['operand'] is None:gaps.extend(bound['gaps'] or ['unresolved label'])
       args.append(bound['operand'])
      else:args.append(argument)
     record['args']=args
    expected.append(record)
   row.update(expected_records=expected,bindings=bindings,gaps=gaps,
              handling='opaque-preserved' if gaps else 'exact-instance-lowering' if expected==actual else 'lowering-difference')
   counts[row['handling']]+=1
  expansion['summary']=dict(counts)
 result=dict(case=case,export_sha256=sha256(source),symbols_sha256=sha256(raw),debug_sha256=sha256(debugraw),
             body_preservation=preservation,resources=binaries,expansions=expansions,
             scope='source-label allocation and per-expansion instruction comparison; indirect target values, control flow and runtime memory accesses remain unproved')
 (out/'comparison.json').write_text(json.dumps(result,ensure_ascii=True,indent=2),encoding='utf-8')
 print(json.dumps(dict(case=case,expansions=[dict(instance=e['instance'],parent=e['parent'],**e['summary']) for e in expansions])),flush=True)
