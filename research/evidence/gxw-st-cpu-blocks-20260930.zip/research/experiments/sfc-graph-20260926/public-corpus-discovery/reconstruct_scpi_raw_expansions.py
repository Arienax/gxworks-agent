"""Rebuild full inline FB bodies from preserved source, caller aliases and CGTable."""
from pathlib import Path
import base64,json,re,subprocess,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.compiler_tables import parse_compiler_tables
from gxw.token_pou import parse_token_fragment
from probe_gxw_simple_fb import frame_source
from probe_gxw_compiled_references import stored_records
from probe_gxw_operand_bindings import resolve_simple_instance_label
P=Path(__file__).resolve().parent
OUT=P/'scpi-raw-expansion-reconstruction';OUT.mkdir(exist_ok=False)
(OUT/'probe.py').write_bytes(Path(__file__).read_bytes())
helper=P/'q-public-check-replay/PublicCheckOracle.exe'
results=[]
for case in json.loads((P/'scpi-alias-device-methods/comparison.json').read_text()):
 assert not case['errors'] and all(case['exact_pcode'].values())
 source=Path(case['source']).read_bytes();assert sha256(source)==case['source_sha256']
 streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
 baseline=Path(case['baseline_directory']);saved=(baseline/'native-saved.gxw').read_bytes()
 table=next(s.raw for s in inspect_project(saved).streams if s.logical_name=='CGTable.dat');tables=parse_compiler_tables(table)
 main=[tables.pou_at(r.table_offset) for r in tables.tables[1].records if tables.pou_at(r.table_offset).name_bytes==b'MAIN'];assert len(main)==1
 instances=[c.record.table_offset for c in tables.components(main[0]) if c.name_bytes==b'SCPI_1'];assert len(instances)==1
 body=frame_source(streams['SCPI.Program.pou']);groups,_=stored_records(body,encoding='cp932')
 proof=json.loads((P/'scpi-alias-device-methods'/case['case']/'raw-forwarding.json').read_text())
 events=[e['payload'] for l in (Path(case['trace_directory'])/'events.jsonl').read_text().splitlines() if (e:=json.loads(l)).get('type')=='send']
 check=[e for e in events if e['event']=='check-instruction-code2'];assert check and len({e['device_context'] for e in check})==1
 ctx=bytes.fromhex(check[0]['device_context']);native=(baseline/'pcode-0-0.bin').read_bytes()
 for call in range(2):
  directory=OUT/(case['case']+'-'+str(call));directory.mkdir();aliases={e['port'].lower():bytes.fromhex(e['raw']) for e in proof['evidence'] if e['call']==call and e['predicted_alias']}
  rebuilt=[];requests=[];bindings=[];gaps=[]
  for ordinal,g in enumerate(groups):
   tokens=parse_token_fragment(g['raw'],0,len(g['raw'])).tokens;parts=[]
   for token in tokens:
    raw=token.raw
    if raw[1]!=0xdf:parts.append(raw);continue
    label=raw[2:-1].decode('ascii')
    if label.lower() in aliases:replacement=aliases[label.lower()];origin='source-callsite-raw';bound=None
    else:
     bound=resolve_simple_instance_label("'"+label,instances[0],tables,cpu='Q03UDV',encoding='cp932')
     m=re.fullmatch(r'(SM|M|D|T)([0-9]+)',bound.get('operand') or '')
     if bound['gaps'] or not m:gaps.append(dict(label=label,binding=bound));parts.append(raw);continue
     number=int(m[2]);n=max(1,(number.bit_length()+7)//8);assert n<=2
     replacement=bytes([n+3,{'SM':0x91,'M':0x90,'D':0xa8,'T':0xc2}[m[1]]])+number.to_bytes(n,'little')+bytes([n+3]);origin='native-postallocation-CGTable'
    parts.append(replacement);bindings.append(dict(ordinal=ordinal,input=raw.hex(),output=replacement.hex(),origin=origin,label=label,component_offset=bound.get('component_offset') if bound else None))
   value=b''.join(parts);rebuilt.append(value)
   if g['labels']:requests.append(dict(ordinal=ordinal,input_base64=base64.b64encode(value).decode()))
  if gaps:
   (directory/'failure.json').write_text(json.dumps(dict(gaps=gaps),indent=2));raise ValueError('unresolved body labels')
  (directory/'device-context.bin').write_bytes(ctx)
  (directory/'requests.json').write_text(json.dumps(dict(source_sha256=sha256(source),source_body_sha256=sha256(body.raw),compiler_table_sha256=sha256(table),aliases={k:v.hex() for k,v in aliases.items()},bindings=bindings,requests=requests),indent=2))
  protocol=''.join(f"check-instruction\t{i}\t{r['input_base64']}\n" for i,r in enumerate(requests))
  run=subprocess.run([str(helper),'D:/GXWORKS2/Easysocket/CodeGenerator/ECCodeGenerator2.dll','209','1','q','1',str(directory/'device-context.bin')],input=protocol.encode(),capture_output=True,timeout=45,creationflags=subprocess.CREATE_NO_WINDOW)
  (directory/'stdout.jsonl').write_bytes(run.stdout);(directory/'stderr.bin').write_bytes(run.stderr)
  answers=[json.loads(l) for l in run.stdout.splitlines()];assert run.returncode==0 and len(answers)==len(requests)
  for request,answer in zip(requests,answers):
   assert answer['return_code']=='0x00000000';rebuilt[request['ordinal']]=base64.b64decode(answer['output_base64'])
  predicted=b''.join(rebuilt);(directory/'predicted-body.bin').write_bytes(predicted)
  offsets=[];start=0
  while (at:=native.find(predicted,start))>=0:offsets.append(at);start=at+1
  row=dict(case=case['case'],call=call,body_groups=len(groups),bindings=len(bindings),raw_alias_bindings=sum(b['origin']=='source-callsite-raw' for b in bindings),predicted_sha256=sha256(predicted),predicted_bytes=len(predicted),exact_full_body_offsets=offsets)
  if not offsets:
   # Retain exact per-group matching for diagnosing transformations, never call it a full match.
   row['group_matches']=[dict(ordinal=i,bytes=len(b),native_offsets=[m.start() for m in re.finditer(re.escape(b),native)]) for i,b in enumerate(rebuilt)]
  (directory/'comparison.json').write_text(json.dumps(row,indent=2));results.append(row)
  print(json.dumps({k:v for k,v in row.items() if k!='group_matches'}),flush=True)
(OUT/'comparison.json').write_text(json.dumps(results,indent=2))
