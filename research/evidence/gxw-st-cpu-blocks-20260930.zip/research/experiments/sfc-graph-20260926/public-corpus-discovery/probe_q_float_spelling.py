"""Independent native Q constant spelling against an explicit FX hypothesis."""
from pathlib import Path
import base64,json,struct,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.token_listing import fx_operand_text
from gxw.token_pou import LadderToken
from native_gxw_tokens import native_batch,native_il_projection,Q_DLL
P=Path(__file__).resolve().parent
OUT=P/'q-float-spelling-holdouts'


def main():
    OUT.mkdir(exist_ok=False);(OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    bits={0,0x80000000,1,0x007fffff,0x00800000,0x7f7fffff,0x3f8ccccd,0x400ccccd,0xbf8ccccd}
    for value in [1.,-1.,1.234567,1.2345678,1.2345685,1234567.5,999999.95,9999999.5,0.00009999999,0.000009999999,1e-10,1e-11,1e11,1e12,1e20,1e-30]:
        n=struct.unpack('<I',struct.pack('<f',value))[0]
        bits.update([n-1,n,n+1])
    plans=[];requests=[]
    for code in [0xec,0xed]:
        for n in sorted(bits):
            token=bytes([7,code])+struct.pack('<I',n)+b'\x07'
            row=dict(code=code,bits=n,token=token.hex())
            try:row['predicted']=fx_operand_text(LadderToken(0,token))
            except ValueError as exc:row['gap']=str(exc)
            plans.append(row)
            body=bytes.fromhex('054c030205')+token+bytes.fromhex('04a80004033403')
            requests.append(dict(mode='decode',input_base64=base64.b64encode(body+b'\0').decode(),token=token.hex()))
    (OUT/'predictions-before-native.json').write_text(json.dumps(plans,indent=2),encoding='utf-8')
    results=[]
    for cpu in [34,209]:
        actual=native_batch(requests,OUT/f'native-{cpu}',dll=Q_DLL,cpu_code=cpu,native_versions=())
        for plan,row in zip(plans,actual):
            result=dict(plan,cpu=cpu,return_code=row['return_code'])
            if row['return_code']=='0x00000000':
                native=native_il_projection(base64.b64decode(row['output_base64']),encoding='cp949')
                result['native']=native['records'][0]['args'][0]
                result['identical']=result.get('predicted')==result['native']
            results.append(result)
    (OUT/'comparison.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
    print(json.dumps(dict(total=len(results),predicted=sum('predicted' in r for r in results),
        identical=sum(r.get('identical',False) for r in results),differences=[r for r in results if 'predicted' in r and not r.get('identical')],
        gaps=[r for r in results if 'gap' in r])),flush=True)


if __name__=='__main__':main()
