"""Compare library IL counters and intrinsic Boolean blocks in real Q ST."""
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.declarations import parse_declarations,edit_declarations,serialize_declarations
from gxw.compiler_debug import parse_compiler_debug
from probe_gxw_st_sources import replace_observed_st
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_compiled_references import inspect
from replay_gxw_workspace import run
P=Path(__file__).resolve().parent
OUT=P/'ST-standard-counter-controls';OUT.mkdir(exist_ok=True)
source=(P/'samples/boxid.gxw').read_bytes()
streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
program='POU_01.Program.pou';labels='POU_01.Labels.lh'
_,original=replace_observed_st(streams[program],'')
d=parse_declarations(streams[labels],logical_name=labels)
cases=[('CTU','CU := TRUE, RESET := FALSE, PV := 10'),('CTD','CD := TRUE, LOAD := FALSE, PV := 10'),
 ('CTUD','CU := TRUE, CD := FALSE, RESET := FALSE, LOAD := FALSE, PV := 10'),
 ('R_TRIG','_CLK := TRUE'),('SR_E','EN := TRUE, _S1 := TRUE, _R := FALSE')]
for kind,args in cases:
 out=OUT/kind;out.mkdir(exist_ok=True)
 if (out/'comparison.json').exists():continue
 call='LibraryProbe('+args+');'
 new,_=replace_observed_st(streams[program],original+'\r\n'+call+'\r\n')
 replacements={program:new,labels:serialize_declarations(edit_declarations(d,upserts=[dict(name='LibraryProbe',data_type=kind,kind='function_block')]))}
 changed=source;receipts=[]
 for name,raw in replacements.items():
  changed,receipt=patch_raw(changed,name,streams[name],raw);receipts.append(receipt)
 after={s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}
 assert all(after[n]==raw for n,raw in streams.items() if n not in replacements)
 path=out/'changed.gxw';path.write_bytes(changed)
 (out/'mutation.json').write_text(json.dumps(dict(source_sha256=sha256(source),changed_sha256=sha256(changed),receipts=receipts,call=call,unrelated_payloads='byte-identical'),indent=2))
 result=run(path,out/'native',compile=True,export_project=True,snapshot_frontend=True,project_alias='STLIBRARY',
  assignment_queries=[dict(name='LibraryProbe',keys=[dict(category=1,value='LibraryProbe'),dict(category=4,value='POU_01')])],
  analysis_queries=[dict(name='all',keys=[],symbol='',scope='',declared=0,plural=0)],analysis_version=3)
 comparison=dict(case=kind,native={k:result[k] for k in ['returncode','compile_completed','compiler_rejected','diagnostics']})
 if result.get('native_export'):
  reopened=run(out/'native/native-saved.gxw',out/'reopen',compile=True,export_project=True)
  comparison['reopen']={k:reopened[k] for k in ['returncode','compile_completed','compiler_rejected','diagnostics']}
  comparison['reopen_pcode_equal']=result['outputs']==reopened['outputs']
  read=inspect(out/'native',out/'correlation');comparison['reader']=read['summary']
  debug=parse_compiler_debug(next(s.raw for s in inspect_project((out/'native/native-saved.gxw').read_bytes()).streams if s.logical_name=='DebugInformation2.dat'))
  comparison['elements']=[dict(index=i,kind=e.kind_code,names=[v.decode('cp1252') for v in e.names],fields=e.fields,rows=debug.offset_tables[e.offset_table_index].rows) for i,e in enumerate(debug.elements)]
 (out/'comparison.json').write_text(json.dumps(comparison,indent=2))
 print(json.dumps({k:v for k,v in comparison.items() if k!='elements'}),flush=True)
