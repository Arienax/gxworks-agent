"""Predict allocator outputs from entry snapshots, independently of returned records."""
from pathlib import Path
import json,struct
P=Path(__file__).resolve().parent;OUT=P/'native-allocation-bitmap'
def bit(raw,i):return bool(raw[i//8]&(0x80>>(i%8)))
def first_fit(raw,start,limit,count):
 if count<=0 or not 0<=start<=limit<=len(raw)*8:raise ValueError('unsupported search bounds')
 run=0
 for i in range(start,limit):
  run=0 if bit(raw,i) else run+1
  if run==count:return i-count+1
 return -1
def type_size(t,p):
 if t in [0,65,66,67,68]:return 1
 if t in [2,17]:return 2
 if t in [3,9,11,18]:return 4
 if t==15:return p+1
 raise ValueError('unrecovered type-size fallback')
results=[]
for case in json.loads((OUT/'comparison.json').read_text()):
 assert all(case['exact_pcode'].values()) and not case['errors']
 rows=[];state={};external=[]
 for pool in case['pools']:
  selected=None;searches=[]
  for s in pool['searches']:
   b=s['before'];raw=bytes.fromhex(b['raw']);predicted=first_fit(raw,s['start'],s['limit'],s['count']);assert predicted==s['result'] and s['before']==s['after']
   key=(pool['compile_id'],b['address'])
   if key in state and state[key]!=raw:
    external.append(dict(pool_id=pool['pool_id'],bitmap=b['address'],prior_population=sum(v.bit_count() for v in state[key]),current_population=sum(v.bit_count() for v in raw),added=sum(bit(raw,i) and not bit(state[key],i) for i in range(len(raw)*8)),removed=sum(bit(state[key],i) and not bit(raw,i) for i in range(len(raw)*8))))
   state[key]=raw
   descriptors=[d for d in pool['descriptors'] if d['bitmap']==b['address']];assert len(descriptors)==1
   searches.append(dict(predicted=predicted,actual=s['result'],descriptor=descriptors[0]))
   if predicted>=0:assert selected is None;selected=(predicted,descriptors[0])
  if pool['result']!=0:raise ValueError('retain unhandled failed allocation')
  assert selected is not None and len(pool['marks'])==1
  index,desc=selected;mark=pool['marks'][0];assert mark['start']==index and mark['count']==pool['count'] and mark['before']==pool['searches'][-1]['after']
  predicted_map=bytearray.fromhex(mark['before']['raw'])
  for i in range(mark['start'],mark['start']+mark['count']):predicted_map[i//8]|=0x80>>(i%8)
  assert predicted_map.hex()==mark['after']['raw'];state[(pool['compile_id'],mark['after']['address'])]=bytes(predicted_map)
  number=desc['end']-index-pool['count']+1;predicted_record=bytearray.fromhex(pool['before']);predicted_record[0]=0x24 if pool['kind']=='word' else 0x21;predicted_record[1]=desc['code'];predicted_record[2:5]=number.to_bytes(3,'little',signed=True);struct.pack_into('<I',predicted_record,6,pool['count'])
  assert predicted_record.hex()==pool['after']
  rows.append(dict(pool_id=pool['pool_id'],compile_id=pool['compile_id'],kind=pool['kind'],count=pool['count'],selector=pool['selector'],selected_pool=desc['index'],predicted_number=number,searches=searches,record_byte_identical=True,bitmap_byte_identical=True))
 types=[]
 for a in case['allocations']:
  t=a['type'];params=bytes.fromhex(a['type_parameter']);n=1
  if t==51:t,_,n=struct.unpack('<3I',bytes.fromhex(a['array_header']))
  p=struct.unpack_from('<i',params,0 if a['type']==15 else 4)[0]
  size=type_size(t,p);assert len(a['sizes'])==1 and a['sizes'][0]['bytes']==size
  count=(size if t==0 else (size+1)//2)*n
  for pool_id in a['pools']:
   pool=next(p for p in case['pools'] if p['pool_id']==pool_id);assert pool['count']==count and pool['after']==a['after']
  types.append(dict(allocation_id=a['allocation_id'],type=a['type'],element_type=t,elements=n,parameter=p,predicted_bytes=size,predicted_units=count,pool_observed=bool(a['pools'])))
 row=dict(case=case['case'],pools=len(rows),type_requests=len(types),external_bitmap_changes=external,pool_replay=rows,type_replay=types,scope='First-fit search, MSB-first occupancy update and descending address assignment independently replayed from observed entry bitmaps and pool descriptors. Source allocation order and initial map construction are not yet reproduced.')
 (OUT/case['case']/'replay.json').write_text(json.dumps(row,indent=2));results.append(row);print(json.dumps(dict(case=row['case'],pools=row['pools'],types=row['type_requests'],external_bitmap_changes=external)))
(OUT/'replay.json').write_text(json.dumps(results,indent=2))
