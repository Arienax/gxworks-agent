from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from replay_gxw_workspace import prepare,trace_prepared
from native_gxw_compiler import native_table_dump
P=Path(__file__).resolve().parent/'builtin-template-call-controls/typed-real-time'
attempts=[]
for attempt in range(3,11):
 out=P/f'trace-v{attempt}'
 prepare(P/'changed.gxw',out,compile=True,export_project=True)
 trace=trace_prepared(out,ROOT/'research/native/CompilerTrace.js',timeout=45)
 native_events=[json.loads(l) for l in (out/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
 attempts.append(dict(directory=out.name,trace=trace))
 if (out/'pcode-0-0.bin').exists():break
 if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in native_events):
  raise RuntimeError('Trace failed for a different reason; evidence retained')
else:raise RuntimeError('No unused native temporary directory found in eight fresh processes')
result=dict(trace=trace,attempts=attempts,
            prior_trace_failure='trace and trace-v2 stopped for NativeTemporaryDirectoryCollision; original evidence retained')
result['trace_pcode_equal']=(out/'pcode-0-0.bin').read_bytes()==(P/'native/pcode-0-0.bin').read_bytes()
captured=[]
for line in (out/'events.jsonl').read_text().splitlines():
 e=json.loads(line).get('payload',{})
 if e.get('event')!='enter' or e.get('name')!='Compile':continue
 b={v['label']:v for v in e['buffers']}
 if any(k.startswith('name_') and v.get('bytes') and bytes.fromhex(v['bytes']).split(b'\0')[0]==b'POU_01' for k,v in b.items()):captured.append(bytes.fromhex(b['symbolic_data']['bytes']))
assert len(captured)==1
(P/'captured-symbols.bin').write_bytes(captured[0])
result['constant_reader']=native_table_dump(captured[0],P/'native-constant-reader',read_constants=True)
read=json.loads((P/'correlation/compiled-references.json').read_text())
result['assignments']=[dict(line=o['source_line'],records=[r for g in o['compiled_records'] for r in read['decoded_fragments'][g['decode_request']].get('records',[])]) for e in read['expansions'] for o in e.get('occurrences',[]) if o.get('source_line',{}).get('text','').startswith('Literal')]
(P/'comparison.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result),flush=True)
