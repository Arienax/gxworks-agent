"""Read-only public object lookup before the normal unmodified checking path."""
from pathlib import Path
import json,subprocess,sys
ROOT=Path(__file__).resolve().parents[4];sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from replay_gxw_workspace import prepare,trace_prepared
from probe_gxw_program_check_resources import SCRIPT,inspect_run
from probe_minimal_conditional_port_writes import save
P=Path(__file__).resolve().parent
out=P/(sys.argv[1] if len(sys.argv)>1 else 'q-check-object-lookup-20260930');out.mkdir(exist_ok=False)
(out/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
trace=out/'trace.js';trace.write_text('(()=>{'+(P/'observe_q_check_failures.js').read_text()+'\n})();\n(()=>{'+SCRIPT+'\n})();',encoding='utf-8')
native=out/'native-1';prepare(P/'native-allocation-inventory/case-10/input.gxw',native,compile=True,program_check=True,export_project=True,snapshot_frontend=True,project_alias='CHECKLOOKUP')
source=native/'WorkspaceReplayOracle.cs';text=source.read_text(encoding='utf-8-sig')
needle='    static JavaScriptSerializer json=new JavaScriptSerializer();'
extra='''    [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int LookupIdFn(IntPtr self,ObjectId parent,int kind,IntPtr name,out ObjectId found,out int code);
'''
assert text.count(needle)==1;text=text.replace(needle,extra+needle)
needle='            if(plan.ContainsKey("program_check_kind")'
assert text.count(needle)==1
pos=text.index(needle)
extra='''            foreach(int kind in new int[]{0x1a,0x1b,0x1c,0x20,0x44})
                foreach(string name in new string[]{"MAIN","MAIN.res","MAIN1","MAIN1.res","기본동작","응용동작1"}) {
                    ObjectId found;int lookupCode;
                    int lookupHr=Slot<LookupIdFn>(workspace,1784)(workspace,id,kind,BStr(name),out found,out lookupCode);
                    Record(new {operation="DiagnosticObjectLookup",parent=id.words,kind=kind,name=name,hresult=lookupHr,code=lookupCode,id=found.words});
                }
'''
text=text[:pos]+extra+text[pos:];source.write_text(text,encoding='utf-8-sig')
csc=Path('C:/Windows/Microsoft.NET/Framework/v4.0.30319/csc.exe')
exe=native/'WorkspaceReplayOracle.exe'
build=subprocess.run([str(csc),'/nologo','/platform:x86','/r:System.Web.Extensions.dll','/r:System.Windows.Forms.dll','/out:'+str(exe)]+[str(native/n) for n in ('WorkspaceReplayOracle.cs','NativeFrontendSnapshot.cs','NativeSfcGraphOracle.cs','NativeWorkspaceCopyOracle.cs')],capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW,timeout=30)
(out/'build.stdout').write_bytes(build.stdout);assert build.returncode==0,build.stdout
save(out/'helper-patch-provenance.json',dict(source_sha256=sha256(source.read_bytes()),exe_sha256=sha256(exe.read_bytes()),change='Thirty read-only GetObjectID calls before checking; no return-value override or project mutation. Original prepare request hashes retained.'))
process=trace_prepared(native,trace);checked=inspect_run(native)
events=[json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
lookups=[e for e in events if e.get('operation')=='DiagnosticObjectLookup']
observed=[json.loads(l).get('payload',{}) for l in (native/'events.jsonl').read_text().splitlines()]
reports=[e for e in observed if e.get('event')=='backend-progress-result' and any(r['kind']==2 for r in e['rows'])]
save(out/'summary.json',dict(process=process,check=checked['check'],lookups=lookups,reports=reports,last_event=checked['last_event']))
print(json.dumps(dict(lookups=[e for e in lookups if e['hresult']>=0 and e['code']==0],reports=reports,last_event=checked['last_event'])))
