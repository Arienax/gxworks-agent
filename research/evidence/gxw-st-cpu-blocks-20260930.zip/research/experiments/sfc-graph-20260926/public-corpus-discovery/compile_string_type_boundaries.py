"""Separate native type-text parsing from actual used ST declaration compilation."""
from dataclasses import replace
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.declarations import parse_declarations,serialize_declarations
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import run
P=Path(__file__).resolve().parent
OUT=P/'native-string-declaration-boundaries';OUT.mkdir(exist_ok=True)
source=(P/'samples/boxid.gxw').read_bytes()
streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
name='Keypad.Labels.lh';doc=parse_declarations(streams[name],logical_name=name)
for case,datatype in [('zero','STRING[0]'),('length255','STRING[255]'),('length256','STRING[256]'),
                      ('length257','STRING[257]'),('length32767','STRING[32767]'),('lowercase','string[20]'),('spaced','STRING [20]')]:
    out=OUT/case;out.mkdir(exist_ok=True)
    if (out/'comparison.json').exists():continue
    new=serialize_declarations(replace(doc,rows=tuple(replace(r,data_type=datatype) if r.name=='newString' else r for r in doc.rows)))
    changed,receipt=patch_raw(source,name,streams[name],new)
    path=out/'changed.gxw';path.write_bytes(changed)
    (out/'mutation.json').write_text(json.dumps(dict(source_sha256=sha256(source),changed_sha256=sha256(changed),
        target='newString',datatype=datatype,receipt=receipt),indent=2),encoding='utf-8')
    result=run(path,out/'native',compile=True,export_project=True,project_alias='STRINGBOUND')
    row=dict(case=case,datatype=datatype,native={k:result[k] for k in ['returncode','open_succeeded','compile_completed','compiler_rejected','diagnostics','outputs','last_event']})
    (out/'comparison.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
    print(json.dumps(dict(case=case,datatype=datatype,native={k:v for k,v in row['native'].items() if k!='outputs'})),flush=True)
