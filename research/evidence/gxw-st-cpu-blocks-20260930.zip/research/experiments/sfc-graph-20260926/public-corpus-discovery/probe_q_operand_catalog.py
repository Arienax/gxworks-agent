"""Cross-check table-driven Q operands against independent native text conversion.

Raw token controls are lexical probes, not declarations of valid device ranges,
stored instruction widths, executable PLC code, or accepted source syntax.
"""
from pathlib import Path
import base64,json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.token_pou import parse_token_fragment
from native_gxw_tokens import native_batch,native_il_projection,Q_DLL
from probe_q_token_lexical import OPERANDS,operand_groups,header_name
P=Path(__file__).resolve().parent
out=P/'q-operand-catalog-controls';out.mkdir(exist_ok=False)
def token(code,payload):return bytes([len(payload)+3,code])+payload+bytes([len(payload)+3])
plans=[]
for code,desc in OPERANDS.items():
 if code>=0xf0 or desc['format_kind'] not in (0,1,4):continue
 values=[bytes([1]),bytes([0xab]),bytes.fromhex('3412'),bytes.fromhex('ffff')]
 if code not in (0xe8,0xea):values += [bytes.fromhex('563412'),bytes.fromhex('78563412'),bytes.fromhex('ffffffff')]
 for value in values:plans.append(dict(case=hex(code)+'-'+value.hex(),operand=token(code,value)))
for code,values,base in [(0xf0,[0,1,15],0xa8),(0xf1,[1,4,8],0x90),(0xf2,[0,10,15],0xa8),
                         (0xf6,[0,1,2],0xa8),(0xf8,[0,1,10],0xab),(0xf9,[0,1,10],0xa8),(0xfc,[0,1],0x98)]:
 for value in values:plans.append(dict(case=hex(code)+'-'+str(value),operand=token(code,bytes([value]))+token(base,b'\xc8')))
plans += [dict(case='indirect',operand=token(0xf3,b'\0')+token(0xa8,b'\xc8')),
          dict(case='digit-index',operand=token(0xf1,b'\4')+token(0xf0,b'\1')+token(0x90,b'\x64')),
          dict(case='unit-index',operand=token(0xf8,b'\0')+token(0xf0,b'\1')+token(0xab,b'\xc8')),
          dict(case='index-bit',operand=token(0xf0,b'\1')+token(0xf2,b'\x0a')+token(0xa8,b'\xc8'))]
requests=[]
for plan in plans:
 body=bytes.fromhex('054c020005')+plan['operand']+bytes.fromhex('04a80004')
 frame=parse_token_fragment(body,0,len(body));groups=operand_groups(frame.tokens[1:],encoding='cp949');assert groups is not None and len(groups)==2
 plan['expected']=dict(kind='instruction',op='MOV',args=[g['text'] for g in groups])
 requests.append(dict(mode='decode',input_base64=base64.b64encode(body+b'\0').decode()))
answers=native_batch(requests,out/'native-decode',dll=Q_DLL,cpu_code=209)
rows=[]
for plan,answer in zip(plans,answers):
 actual=native_il_projection(base64.b64decode(answer['output_base64']),encoding='cp949') if answer['return_code']=='0x00000000' else None
 exact=answer['return_code']=='0x00000000' and not actual['text_gaps'] and actual['records']==[plan['expected']]
 rows.append(dict(case=plan['case'],raw_hex=plan['operand'].hex(),expected=plan['expected'],native=actual,native_result=answer['return_code'],exact=exact))
result=dict(summary=dict(cases=len(rows),exact=sum(r['exact'] for r in rows)),rows=rows,scope=__doc__)
with (out/'comparison.json').open('x') as f:json.dump(result,f,indent=2)
print(json.dumps(dict(summary=result['summary'],gaps=[r for r in rows if not r['exact']])))
