"""Contrast scalar FB, INT array, and FB array native type resolution."""
from pathlib import Path
import hashlib,json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from replay_gxw_workspace import prepare,trace_prepared
from gxw.lossless import inspect_project,sha256
from gxw.declarations import parse_declarations,edit_declarations,serialize_declarations
from probe_gxw_sfc_graph import patch_raw
P=Path(__file__).resolve().parent
out=P/'q-fb-array-type-trace-v4';out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
assert hashlib.sha256(Path('D:/GXWORKS2/DNaviZero/DataAbsorber/DZDataABS_SICConverter_IEC.dll').read_bytes()).hexdigest()=='670fd037852287e4c99de6aa58d19ea0ba9505f10bb46969d2e17d1e54b863f6'
for case,dtype in [('local-fb-array','ARRAY [0..1] OF SCPI'),('local-int-array','ARRAY [0..1] OF INT'),('local-fb-scalar','SCPI'),('global-fb-array','ARRAY [0..1] OF SCPI')]:
    d=out/case;d.mkdir()
    is_global=case.startswith('global')
    source=P/'q-fb-array-storage'/('global-empty-initial' if is_global else 'local-empty-initial')/'input.gxw'
    raw=source.read_bytes();logical='Global1.gh' if is_global else 'MAIN.Labels.lh'
    streams={s.logical_name:s.raw for s in inspect_project(raw).streams if s.logical_name}
    original=streams[logical];doc=parse_declarations(original,logical_name=logical)
    data=serialize_declarations(edit_declarations(doc,upserts=[dict(name='BlockArray',data_type=dtype,kind='function_block' if dtype.endswith('SCPI') else 'variable',initial_value='')]))
    changed,receipt=patch_raw(raw,logical,original,data)
    assert {s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}==dict(streams,**{logical:data})
    (d/'input.gxw').write_bytes(changed)
    (d/'mutation.json').write_text(json.dumps(dict(source=str(source),source_sha256=sha256(raw),changed_sha256=sha256(changed),logical=logical,data_type=dtype,receipt=receipt,unrelated_payloads='byte-identical'),indent=2))
    target=d/'native'
    prepare(d/'input.gxw',target,compile=True,snapshot_frontend=True,export_project=True,project_alias='QFBARRAYTRACE')
    result=trace_prepared(target,P/'TraceFbArrayTypeV4.js')
    events=[json.loads(s) for s in (target/'events.jsonl').read_text(encoding='utf-8').splitlines()]
    selected=[e.get('payload',e) for e in events]
    native=[json.loads(s) for s in (target/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    summary=dict(case=case,process=result,events=selected,errors=[r for e in native for r in e.get('reports',[]) if r['kind']==2],exported=(target/'native-saved.gxw').is_file())
    (d/'comparison.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(dict(case=case,process=result,events=[e for e in selected if e.get('event')!='resolved-declaration-type' or e['input'] in (dtype,'SCPI')],errors=summary['errors'],exported=summary['exported'])),flush=True)
