from pathlib import Path
import sys,json,time
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from gxw.lossless import inspect_project,sha256
from probe_gxw_library_archive import decode_library_archive,encode_library_literals
from probe_gxw_library_sources import snapshot_library_pous
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import run
P=Path(__file__).resolve().parent
case=sys.argv[1] if len(sys.argv)>1 else 'case-00'
directory=P/'native-allocation-inventory'/case
out=P/'library-repack-controls'/case
out.mkdir(parents=True,exist_ok=False)
source=(directory/'input.gxw').read_bytes();changed=source;receipts=[]
before={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
for name,raw in before.items():
 if not name.lower().endswith('.lif'):continue
 start=time.monotonic();plain=decode_library_archive(raw[20:]).decoded;archive=encode_library_literals(plain)
 assert decode_library_archive(archive).decoded==plain
 new=raw[:20]+archive;changed,receipt=patch_raw(changed,name,raw,new)
 receipts.append(dict(logical_name=name,original_size=len(raw),new_size=len(new),original_sha256=sha256(raw),new_sha256=sha256(new),plain_sha256=sha256(plain),seconds=time.monotonic()-start,patch=receipt))
 print(json.dumps({k:v for k,v in receipts[-1].items() if k!='patch'}),flush=True)
after={s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name};touched={r['logical_name'] for r in receipts}
assert all(after[n]==b for n,b in before.items() if n not in touched)
(out/'repacked.gxw').write_bytes(changed)
(out/'mutation.json').write_text(json.dumps(dict(source_sha256=sha256(source),changed_sha256=sha256(changed),receipts=receipts,unrelated_payloads='byte-identical',source_text='byte-identical',purpose='native acceptance of alternate compression tokenization; no source change'),indent=2))
result=run(out/'repacked.gxw',out/'native',compile=True,export_project=True,snapshot_frontend=True)
print(json.dumps(result),flush=True)
if result.get('native_export'):
 original=snapshot_library_pous(json.loads((directory/'frontend-snapshot.json').read_text(encoding='utf-8-sig')))
 current=snapshot_library_pous(json.loads((out/'native/frontend-snapshot.json').read_text(encoding='utf-8-sig')))
 comparison=dict(original_definitions=len(original),current_definitions=len(current),native_library_buffers_exact=original==current)
 reopened=run(out/'native/native-saved.gxw',out/'reopen',compile=True,export_project=True,snapshot_frontend=True)
 comparison['reopen']=reopened
 if reopened.get('native_export'):
  again=snapshot_library_pous(json.loads((out/'reopen/frontend-snapshot.json').read_text(encoding='utf-8-sig')))
  comparison['reopened_library_buffers_exact']=original==again
  files=[f.name for f in (out/'native').glob('PCode*') if f.is_file()]
  comparison['pcode_files']=files
  comparison['saved_reopen_pcode_exact']=bool(files) and all((out/'native'/n).read_bytes()==(out/'reopen'/n).read_bytes() for n in files)
 (out/'comparison.json').write_text(json.dumps(comparison,indent=2))
 print(json.dumps(comparison),flush=True)
