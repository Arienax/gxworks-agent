"""Cross-check raw-grid paths with independent native-generated graph controls."""
from pathlib import Path
import json
import sys
ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'research')]
from source_sfc_grid import read_grid, flow_connections

P = Path(__file__).resolve().parent
OUT = P/'sfc-grid-path-crosscheck'


def main():
    OUT.mkdir(exist_ok=False)
    for file in [Path(__file__), P/'source_sfc_grid.py']:
        (OUT/file.name).write_bytes(file.read_bytes())
    # References are from native-generated topology experiments and their
    # converted graph instructions, not inferred from this path traversal.
    controls = [
        ('parallel', P.parent/'decode-parallel-roundtrip', [('step0','transition0'),('transition0','step1'),('transition0','step2'),
            ('step1','transition1'),('step2','transition1'),('transition1','jump0')], []),
        ('selective', P.parent/'decode-selective-roundtrip', [('step0','transition0'),('step0','transition1'),
            ('transition0','step1'),('transition1','step2'),('step1','transition2'),('step2','transition3'),
            ('transition2','jump0'),('transition3','jump0')], []),
        ('linear-pending', P/'pending-sfc-source-chars-v3/three-steps-reopen/native-1', [('step0','transition0'),
            ('transition0','step1'),('step1','transition1'),('transition1','step2'),('step2','transition2'),('transition2','jump1')], []),
        ('q-end', P/'pending-q-end-kind/convert-1', [('step0','transition0'),('transition0','end999')], []),
        ('incomplete-q', P/'pending-sfc-source-chars-v3/q00j-empty/native-1', [('step0','transition0')], ['dangling geometric connection']),
    ]
    rows = []
    for tag, native, expected, expected_gaps in controls:
        image = read_grid((native/'sfc-buffer-0.bin').read_bytes()[:21512]); graph = flow_connections(image)
        name = lambda node: node['kind'] + str(node['number'])
        pairs = sorted((name(e['source']), name(e['target'])) for e in graph['edges'])
        gaps = [g['reason'] for g in graph['gaps']]
        row = dict(case=tag, native_directory=str(native), graph=graph, expected_edges=expected,
            edges_agree=pairs == sorted(expected), expected_gap_reasons=expected_gaps, gaps_agree=gaps == expected_gaps)
        rows.append(row)
    (OUT/'comparison.json').write_text(json.dumps(rows, indent=2), encoding='utf-8')
    print(json.dumps([dict(case=r['case'], edges=len(r['graph']['edges']), edges_agree=r['edges_agree'],
        gaps_agree=r['gaps_agree'], gaps=r['graph']['gaps']) for r in rows]), flush=True)


if __name__ == '__main__':
    main()
