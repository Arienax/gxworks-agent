"""Bounded FX3U output dialect, measured on the real Keypad call project.

This is research only. It neither validates runtime string capacity nor
establishes general FX Boolean, indexed-port or temporary reservation order.
"""
from source_q_width import tokens


def rewrite(raw):
    ts=tokens(raw);header=ts[0];operands=[];pending=b''
    for part in ts[1:]:
        part=bytearray(part)
        if part[1] in (0xf0,0xcc):
            if len(part)!=4 or part[2] not in (16,18):raise ValueError('unmeasured FX index register')
            part[2]-=16
        if part[1]>=0xf0:pending+=bytes(part)
        else:operands.append(pending+bytes(part));pending=b''
    if pending:raise ValueError('FX operand modifier without base')
    family=header[1]
    if family==0x49 and header[3]==8:
        if len(operands)!=3 or operands[1]!=bytes.fromhex('04e80104') or operands[2][1]!=0xcc:
            raise ValueError('FX index profile requires scalar INT and stride one')
        operands=[operands[0],operands[2]];family=0x4c;header=bytes.fromhex('054c030005')
    if family in (0,1,6,7,0xc,0xd,0x20,0x24):
        if len(operands)!=1:raise ValueError('FX basic operand count')
        part=operands[0];number=int.from_bytes(part[2:-1],'little')
        if part[1]==0x91:
            if number not in (400,401):raise ValueError('unmeasured FX special relay')
            number+=7600;operands=[bytes([5,0x90])+number.to_bytes(2,'little')+b'\x05'];width=1
        elif part[1]==0x90 and number in (8000,8001):width=1
        elif part[1]==0x90 and 3840<=number<=7679:width=3
        elif family==0x24 and part[1]==0xa8 and number<=999:width=3
        else:raise ValueError('outside measured FX basic device range')
        header=bytes([3,family,3]) if width==1 else bytes([4,family,width,4])
    elif family==0x40:
        if len(header)!=6 or len(operands)!=2:raise ValueError('unmeasured FX comparison')
        header=header[:2]+b'\x05'+header[3:]
    elif family in (0x49,0x4c,0x4d,0x59):
        variant=header[3];arity=len(operands)
        if (family,variant,arity) not in ((0x49,0x28,3),(0x49,0x23,3),(0x4c,0,2),(0x4c,3,2),(0x4d,0,1),(0x59,0,2),(0x59,0x16,3)):
            raise ValueError(f'unmeasured FX applied instruction form {family:02x}/{variant:02x}/{arity}')
        for part in operands:
            if part[1]==0xee and (len(part)!=4 or part[2]==0):raise ValueError('FX literal profile requires one nonempty ASCII character')
        header=bytes([5,family,2*arity+1,variant,5])
    else:raise ValueError('outside measured FX string-slice instruction')
    return header+b''.join(operands)
