"""Distinguish native cell topology using generated Boolean and branch controls."""
from pathlib import Path
import base64
import json
import sys
import struct

ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from native_gxw_tokens import native_batch
from native_gxw_ladder import native_ladder_batch

P=Path(__file__).resolve().parent
OUT=P/'native-ladder-topology'

def main():
    OUT.mkdir(exist_ok=False)
    (OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    cases=[
        ('contact',['LD X0','OUT Y0']),
        ('series',['LD X0','AND X1','OUT Y0']),
        ('parallel',['LD X0','OR X1','OUT Y0']),
        ('series-of-parallel',['LD X0','OR X1','LD X2','OR X3','ANB','OUT Y0']),
        ('parallel-of-series',['LD X0','AND X1','LD X2','AND X3','ORB','OUT Y0']),
        ('series-after-parallel',['LD X0','OR X1','AND X2','OUT Y0']),
        ('parallel-after-series',['LD X0','AND X1','OR X2','OUT Y0']),
        ('nested-block',['LD X0','LD X1','AND X2','LD X3','OR X4','ANB','ORB','OUT Y0']),
        ('two-coils',['LD X0','OUT Y0','OUT Y1']),
        ('branch-two',['LD X0','MPS','AND X1','OUT Y0','MPP','AND X2','OUT Y1']),
        ('branch-three',['LD X0','MPS','AND X1','OUT Y0','MRD','AND X2','OUT Y1','MPP','AND X3','OUT Y2']),
        ('nested-stack',['LD X0','MPS','AND X1','MPS','AND X2','OUT Y0','MPP','AND X3','OUT Y1','MPP','AND X4','OUT Y2']),
        ('after-coil-contact',['LD X0','OUT Y0','AND X1','OUT Y1']),
        ('two-circuits',['LD X0','OUT Y0','LD X1','OUT Y1']),
        ('dangling-contact',['LD X0']),
        ('orb-underflow',['LD X0','ORB','OUT Y0']),
        ('mpp-underflow',['LD X0','MPP','OUT Y0']),
        ('unclosed-stack',['LD X0','MPS','OUT Y0']),
    ]
    for op in ('LDI','LDP','LDF'):
        cases.append((op.lower(),[f'{op} X0','OUT Y0']))
    for op in ('ANI','ANDP','ANDF','ORI','ORP','ORF'):
        cases.append((op.lower(),['LD X0',f'{op} X1','OUT Y0']))
    for op in ('SET','RST','PLS','PLF'):
        cases.append((op.lower(),['LD X0',f'{op} Y0']))
    for op in ('INV','MEP','MEF'):
        cases.append((op.lower(),['LD X0',op,'OUT Y0']))
    (OUT/'predictions.json').write_text(json.dumps(dict(cases=cases,
        question='Determine graph connections independently of input instruction-stack evaluation; retain rejected/partial controls.'),indent=2),encoding='utf-8')
    encoded=native_batch([dict(mode='encode',input_base64=base64.b64encode(('\0'.join(lines)+'\0\0').encode('ascii')).decode())
                          for _,lines in cases],OUT/'encode',cpu_code=521)
    accepted=[(i,r) for i,r in enumerate(encoded) if r['return_code']=='0x00000000']
    requests=[dict(case=cases[i][0],input_base64=base64.b64encode(base64.b64decode(r['output_base64'])+b'\0').decode()) for i,r in accepted]
    native=native_ladder_batch(requests,OUT/'ladder')
    rows=[]
    for j,((i,encoded_row),request,result) in enumerate(zip(accepted,requests,native,strict=True)):
        cells=(OUT/'ladder'/f'{j:04}.cells.bin').read_bytes()
        tokens=(OUT/'ladder'/f'{j:04}.tokens.bin').read_bytes()
        records=[]
        for off in range(0,len(cells),8):
            cell=cells[off:off+8]
            if any(cell):
                records.append(dict(index=off//8,raw_hex=cell.hex(),words=list(struct.unpack('<4H',cell))))
        row=dict(case=cases[i][0],lines=cases[i][1],encoded=encoded_row,request=request,native=result,cells=records)
        rows.append(row)
        meaningful=[r for r in records if r['raw_hex'][2:4] not in ('80','00') or (int(r['raw_hex'][:2],16)&12)]
        print(json.dumps(dict(case=row['case'],code=result['return_code'],metadata=result['metadata'],
            consumed=result['consumed_bytes'],input_bytes=len(base64.b64decode(request['input_base64'])),
            cells=meaningful,token_prefix=tokens[:min(80,len(tokens))].hex())),flush=True)
    (OUT/'comparison.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
    rejected=[dict(case=cases[i][0],native=r) for i,r in enumerate(encoded) if r['return_code']!='0x00000000']
    (OUT/'encode-rejections.json').write_text(json.dumps(rejected,indent=2),encoding='utf-8')

if __name__=='__main__':main()
