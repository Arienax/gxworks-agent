"""Follow unmodified public Keypad array accesses through native temporaries."""
from pathlib import Path
import json,re,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.compiler_tables import parse_compiler_tables
from probe_gxw_index_arithmetic import source_array_reference,decoded_index_arithmetic,affine,add
P=Path(__file__).resolve().parent
out=P/'array-operand-controls/word-bit-transfer'
original={s.logical_name:s.raw for s in inspect_project((P/'samples/boxid.gxw').read_bytes()).streams if s.logical_name}
changed={s.logical_name:s.raw for s in inspect_project((out/'changed.gxw').read_bytes()).streams if s.logical_name}
for name in ('Keypad.Program.pou','Keypad.Labels.lh'):assert original[name]==changed[name]
events=[json.loads(l).get('payload',{}) for l in (out/'trace/events.jsonl').read_text().splitlines()]
source=None;tables=None;allocated=None
for e in events:
 if e.get('event')!='enter' or e.get('name')!='Compile':continue
 b={v['label']:v for v in e['buffers']}
 for k,v in b.items():
  if not k.startswith('name_') or not v.get('bytes'):continue
  name=bytes.fromhex(v['bytes']).split(b'\0')[0]
  if name==b'POU_01.Keypad_1':
   assert source is None
   source=bytes.fromhex(b[k.replace('name_','source_')]['bytes']).decode()
   tables=parse_compiler_tables(bytes.fromhex(b['symbolic_data']['bytes']))
  if name==b'Task_01':allocated=parse_compiler_tables(bytes.fromhex(b['symbolic_data']['bytes']))
assert source is not None and allocated is not None
read=json.loads((out/'correlation/compiled-references.json').read_text())
assert all(sha256((out/'trace'/r['file']).read_bytes())==r['sha256'] for r in read['resources'])
dump=(out/'native-table-reader/native-table-dump.txt').read_text(encoding='cp1252')
positions={int(m[1]):int(m[2]) for m in re.finditer(r'^Index +(\d+) , Line +(-?\d+) , NW +(-?\d+) , POUIdx +(\d+)',dump,re.M)}
occurrences=[o for e in read['expansions'] if e['stored_names']==['','POU_01','Keypad','POU_01','Keypad_1'] for o in e.get('occurrences',[])]
rows=[]
for line in source.splitlines():
 refs=re.findall(r'K[0-9]+\[[^\[\]]+\]',line)
 if not refs:continue
 point=re.search(r'D([0-9]+)$',line);assert point
 matches=[o for o in occurrences if o['source_line']['line_index']==positions[int(point[1])]];assert len(matches)==1
 occurrence=matches[0]
 records=[r for g in occurrence['compiled_records'] for r in read['decoded_fragments'][g['decode_request']].get('records',[])]
 for token in refs:
  expected=source_array_reference(token,tables,allocated);candidates=[]
  target_expression=add(affine(expected['base_coordinate']),expected['relative_device_units'])
  for ordinal,record in enumerate(records):
   for operand_index,operand in enumerate(record.get('args',[])):
    device=re.fullmatch(r'([DM])([0-9]+)Z([0-9]+)',operand)
    if not device:continue
    arithmetic=decoded_index_arithmetic(records[:ordinal]);relative=arithmetic['state'].get('Z'+device[3])
    complete=add(affine(int(device[2])),relative) if relative is not None else None
    candidates.append(dict(record=record,operand_index=operand_index,arithmetic=arithmetic,complete_address=complete,
                           exact=device[1]==expected['binding']['base']['family'] and complete==target_expression and not arithmetic['gaps']))
  rows.append(dict(generated=line,physical_source=occurrence['source_line'],expected=expected,native_records=records,
                   candidate_references=candidates,exact_references=sum(c['exact'] for c in candidates)))
result=dict(scope='unmodified public Keypad FB body in isolated modified parent project; no PLC execution',
            original_source_sha256=sha256((P/'samples/boxid.gxw').read_bytes()),
            unchanged_payloads={n:sha256(original[n]) for n in ('Keypad.Program.pou','Keypad.Labels.lh')},
            compile_group='POU_01.Keypad_1',symbols_sha256=sha256(tables.raw),
            allocated_symbols_sha256=sha256(allocated.raw),rows=rows,
            references=len(rows),exact=sum(r['exact_references']==1 for r in rows))
(out/'real-keypad-array-comparison.json').write_text(json.dumps(result,indent=2))
print(json.dumps(dict(references=result['references'],exact=result['exact'],unchanged_payloads=result['unchanged_payloads'])))
