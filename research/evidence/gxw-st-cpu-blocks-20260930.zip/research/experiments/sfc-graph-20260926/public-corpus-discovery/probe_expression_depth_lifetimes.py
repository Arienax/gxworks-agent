"""Use simultaneous expression values to discriminate temporary-slot reuse."""
from dataclasses import replace
from pathlib import Path
import base64,json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from gxw.structured_pou import parse_structured_pou
from gxw.structured_pou_writer import serialize_structured_pou
from gxw.project_metadata import mark_observed_source_compile_pending
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_program_check_resources import SCRIPT
from probe_minimal_conditional_port_writes import streams,observe,save
from native_gxw_tokens import native_batch,DEFAULT_DLL,native_il_projection
P=Path(__file__).resolve().parent
OUT=P/'expression-depth-lifetimes-20260930'


def main():
    OUT.mkdir(exist_ok=False);(OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    trace=OUT/'trace.js';trace.write_text('(()=>{'+(P/'native-allocation-bitmap-v2/observer.js').read_text()+'\n'+(P/'observe_expression_temporaries.js').read_text()+'\n})();\n(()=>{'+SCRIPT+'\n})();',encoding='utf-8')
    original=(P/'native-graph-inout-writeback-v2/output-bound/source.gxw').read_bytes();before=streams(original)
    name='1.Program.pou';doc=parse_structured_pou(before[name],logical_name=name)
    plans=[('add-pair',('D10 + D12','D20 + D22')),
           ('balanced-pair',('(D10 + D12) - (D14 + D16)','(D20 + D22) - (D24 + D26)')),
           ('left-nested-pair',('((D10 + D12) + D14) + D16','((D20 + D22) + D24) + D26'))]
    ready=[]
    for case,expressions in plans:
        d=OUT/case;d.mkdir();mapping=dict(zip(('D10','D20'),expressions))
        nodes=tuple(replace(n,symbol=mapping[n.symbol]) if n.symbol in mapping else n for n in doc.nodes)
        raw=mark_observed_source_compile_pending(serialize_structured_pou(replace(doc,nodes=nodes)),logical_name=name)
        source,receipt=patch_raw(original,name,before[name],raw)
        assert streams(source)==dict(before,**{name:raw})
        path=d/'input.gxw';path.write_bytes(source)
        save(d/'before-native.json',dict(case=case,input_sha256=sha256(source),receipt=receipt,expressions=expressions,
             hypotheses=['Sequential expressions can share a released slot.',
                         'Operands simultaneously live in a balanced tree require distinct slots.',
                         'Left-nested expression lowering can reuse intermediates before the next call.']))
        ready.append((case,d,path))
    result=[];requests=[];keys=[]
    for case,d,path in ready:
        native,observed,process=observe(path,d,trace);code=(native/'pcode-0-0.bin').read_bytes()
        messages=[json.loads(l) for l in (native/'events.jsonl').read_text().splitlines()]
        events=[m['payload'] for m in messages if m.get('type')=='send']
        errors=[m for m in messages if m.get('type')=='error' or 'error' in m.get('payload',{}).get('event','') or m.get('payload',{}).get('observation_error')]
        row=dict(case=case,native_directory=str(native),process=process,check=observed['check'],diagnostics=observed['diagnostics'],
             trace_errors=errors,bytes=len(code),sha256=sha256(code),temporary_events=[e for e in events if e.get('event','').startswith('temporary-')],
             pools=[e for e in events if e.get('event')=='pool-allocation'])
        result.append(row);save(OUT/'comparison.json',result)
        print(json.dumps(dict(case=case,check=row['check'],errors=sorted(set(hex(x['code']) for x in row['diagnostics'] if x['kind']==2)),
             trace_errors=errors,bytes=len(code),creations=[{k:e[k] for k in ('type','count','output','before_counters','after_counters')} for e in row['temporary_events'] if e['event']=='temporary-create'],
             request_count=sum(e.get('name')=='request' for e in row['temporary_events']))),flush=True)
        if errors:raise RuntimeError('temporary trace failed; retained')
        if code:requests.append(dict(mode='decode',case=case,input_base64=base64.b64encode(code+b'\0').decode()));keys.append(case)
    if requests:
        decoded=native_batch(requests,OUT/'native-decode',dll=DEFAULT_DLL,cpu_code=0x208)
        save(OUT/'native-listings.json',[dict(case=k,return_code=r['return_code'],listing=native_il_projection(base64.b64decode(r['output_base64']),encoding='gb18030')) for k,r in zip(keys,decoded)])


if __name__=='__main__':main()
