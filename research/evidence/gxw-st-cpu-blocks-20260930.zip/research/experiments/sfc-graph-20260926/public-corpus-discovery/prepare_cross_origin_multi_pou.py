from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[4];sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from replay_gxw_workspace import prepare,trace_prepared
from probe_gxw_program_check_resources import inspect_run
from probe_minimal_conditional_port_writes import save,observe
from probe_gxw_task_graph import inspect_task_graph
P=Path(__file__).resolve().parent
out=P/'cross-origin-multi-pou-seed-v3-20260930';out.mkdir(exist_ok=False)
source=P/'cross-origin-st-calls-v3-20260930/input-capture-and-alias/input.gxw'
trace=P/'cross-origin-st-calls-v3-20260930/trace.js'
n=out/'native-copy'
copy=dict(source='MAIN',name='ProbeNext',destination_collection=25,destination_collection_type=0x1000000,conditions=0)
prepare(source,n,compile=True,program_check=True,export_project=True,snapshot_frontend=True,project_alias='CROSSCALL',native_copy=copy)
process=trace_prepared(n,trace);r=inspect_run(n)
row=dict(case='native-copy-seed',native_directory=str(n),process=process,check=r['check'],diagnostics=r['diagnostics'],copy=copy)
if r['exported_sha256']:
 graph=inspect_task_graph((n/'native-saved.gxw').read_bytes());row['tasks']={k:v['entries'] for k,v in graph['tasks'].items()}
 d=out/'reopen';d.mkdir();rn,rr,rp=observe(n/'native-saved.gxw',d,trace)
 row['reopen']=dict(native_directory=str(rn),check=rr['check'],diagnostics=rr['diagnostics'],identical=(n/'pcode-0-0.bin').read_bytes()==(rn/'pcode-0-0.bin').read_bytes())
save(out/'comparison.json',[row]);print(json.dumps({k:v for k,v in row.items() if k!='diagnostics'}))
