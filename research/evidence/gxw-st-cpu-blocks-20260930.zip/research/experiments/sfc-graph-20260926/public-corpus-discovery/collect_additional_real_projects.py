"""Retrieve immutable public Git blobs for local-only research and framing."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import base64
import hashlib
import json
import sys
import urllib.request
ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'research')]
from gxw.lossless import inspect_project, sha256
from gxw.project_metadata import read_project_text_context
from probe_gxw_simple_fb import frame_source, observe_calls
from probe_gxw_task_graph import inspect_task_graph

P = Path(__file__).resolve().parent
OUT = P/'additional-real-projects'


def retrieve(plan):
    directory = OUT/plan['case']; directory.mkdir()
    row = dict(plan, distribution='local-only; no redistribution license inferred')
    try:
        request = urllib.request.Request(plan['url'], headers={'User-Agent': 'GXWorks-research', 'Accept': 'application/vnd.github+json'})
        with urllib.request.urlopen(request, timeout=30) as response:
            payload = response.read()
        blob = json.loads(payload)
        raw = base64.b64decode(blob['content'])
        git_sha = hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
        if git_sha != plan['blob_sha'] or blob['sha'] != git_sha:
            raise ValueError('download does not match immutable Git blob')
        (directory/'source-blob.json').write_bytes(payload)
        path = directory/'input.gxw'; path.write_bytes(raw)
        image = inspect_project(raw)
        streams = {s.logical_name: s.raw for s in image.streams if s.logical_name}
        row.update(source=str(path), sha256=sha256(raw), bytes=len(raw),
            context=read_project_text_context(next(v for k, v in streams.items() if k.endswith('.prj'))),
            diagnostics=image.diagnostics, stream_errors=[dict(name=s.logical_name, error=s.error) for s in image.streams if s.error],
            programs=[])
        graph = inspect_task_graph(raw)
        row['task_graph'] = {k: graph[k] for k in ['resources', 'gaps', 'source_pous_without_direct_task_reference']}
        for name, body in streams.items():
            if name not in {p['source_program'] for p in graph['programs'].values()}:
                continue
            program = dict(name=name, sha256=sha256(body), bytes=len(body), signature=body[54:79].hex())
            try:
                framed = frame_source(body); observed = observe_calls(framed)
                program.update(handling='token-framed', body_sha256=sha256(framed.body), tokens=len(framed.tokens),
                    label_tokens=sum(t.raw[1] == 0xdf for t in framed.tokens), calls=len(observed['calls']), gaps=observed['gaps'])
            except ValueError as exc:
                program.update(handling='opaque-preserved', error=str(exc))
            row['programs'].append(program)
    except Exception as exc:
        row['error'] = type(exc).__name__+': '+str(exc)
    (directory/'inventory.json').write_text(json.dumps(row, indent=2), encoding='utf-8')
    return row


def main():
    OUT.mkdir(exist_ok=False)
    (OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    specs = [('cmz269_-plc-gxworks2--tree.json', 'cmz269/-plc-gxworks2-', set()),
             ('factonation_modbus-rs485-fundamentals-tree.json', 'factonation/modbus-rs485-fundamentals', {'src/master.gxw'}),
             ('MineFujiko_PLC-CONTROL-STEPPER-MOTOR-tree.json', 'MineFujiko/PLC-CONTROL-STEPPER-MOTOR', {'00_LAD_GX_works2/2_1.gxw'})]
    plans = []
    for filename, repository, excluded in specs:
        tree = json.loads((P/filename).read_text(encoding='utf-8'))
        for entry in tree['tree']:
            if not entry['path'].lower().endswith('.gxw') or entry['path'] in excluded:
                continue
            plans.append(dict(case=f'case-{len(plans):02d}', repository=repository, tree_sha=tree['sha'],
                path=entry['path'], blob_sha=entry['sha'], url=entry['url']))
    (OUT/'plans.json').write_text(json.dumps(plans, indent=2), encoding='utf-8')
    with ThreadPoolExecutor(max_workers=4) as pool:
        rows = list(pool.map(retrieve, plans))
    (OUT/'inventory.json').write_text(json.dumps(rows, indent=2), encoding='utf-8')
    for row in rows:
        print(json.dumps({k: row.get(k) for k in ['case', 'repository', 'path', 'context', 'programs', 'error']}), flush=True)


if __name__ == '__main__':
    main()
