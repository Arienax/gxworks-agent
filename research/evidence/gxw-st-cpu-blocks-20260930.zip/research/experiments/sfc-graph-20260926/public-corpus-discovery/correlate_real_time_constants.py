"""Keep literal spelling, table values and compiled precision distinct."""
from pathlib import Path
import sys,json,struct,base64
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from gxw.compiler_tables import parse_compiler_tables
from gxw.lossless import sha256
from probe_gxw_compiler_constants import constant_record
P=Path(__file__).resolve().parent/'builtin-template-call-controls/typed-real-time'
raw=(P/'captured-symbols.bin').read_bytes()
views=[constant_record(r) for r in parse_compiler_tables(raw).tables[5].records]
native=json.loads((P/'native-constant-reader/comparison.json').read_text())
assert native['input_sha256']==sha256(raw) and native['constant_reads_complete'] and not native['constant_field_mismatches']
read=json.loads((P/'correlation/compiled-references.json').read_text())
occurrences=[o for e in read['expansions'] for o in e.get('occurrences',[]) if o.get('source_line',{}).get('text','').startswith('Literal')]
results=[]
for o in occurrences:
 spelling=o['source_line']['text'].split(':=')[1].strip().removesuffix(';')
 candidates=[v for v in views if v['spelling_ascii']==spelling];assert len(candidates)==1
 view=candidates[0]
 compiled=[dict(record=g,decoded=read['decoded_fragments'][g['decode_request']]) for g in o['compiled_records']]
 row=dict(source_line=o['source_line'],constant=view,compiled_records=compiled)
 if view['kind']==10:
  items=[c for c in compiled if c['decoded']['records'][0].get('op')=='EMOV'];assert len(items)==1
  token=base64.b64decode(items[0]['record']['raw_base64'])
  assert token[:7]==bytes.fromhex('054c03020507ec') and token[11]==7
  stored=token[7:11];value=view['stored_real']
  direct=struct.pack('<f',value);rounded=struct.pack('<f',float(format(value,'.6e')))
  row.update(compiled_binary32_hex=stored.hex(),compiled_binary32_value=struct.unpack('<f',stored)[0],
             direct_binary32_cast_hex=direct.hex(),seven_significant_digit_binary32_hex=rounded.hex(),
             matches_direct_cast=stored==direct,matches_seven_significant_digits=stored==rounded,
             projection_scope='two observed positive literals assigned to REAL on Q03UDV; not a universal decimal rounding rule')
 elif view['kind']==11:
  records=[r for c in compiled for r in c['decoded']['records'] if r.get('op')=='DMOV']
  assert len(records)==1 and view['duration_milliseconds'].is_integer()
  row.update(duration_matches_native_operand=records[0]['args'][0]=='K'+str(int(view['duration_milliseconds'])))
 results.append(row)
result=dict(symbols_sha256=sha256(raw),native_reader=native['dll_sha256'],results=results,
            diagnostics=json.loads((P/'native/outcome.json').read_text())['diagnostics'])
(P/'typed-value-comparison.json').write_text(json.dumps(result,indent=2))
print(json.dumps([dict(source=r['source_line']['text'],**{k:v for k,v in r.items() if k not in ['source_line','constant','compiled_records']}) for r in results]))
