"""Distinguish conditional literal materialization from dangling alias guards."""
from pathlib import Path
import base64,json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from probe_gxw_simple_fb import frame_source,observe_calls
from probe_gxw_sfc_graph import patch_raw
from source_q_allocation import groups
from source_q_direct_projection import project_projection
from native_gxw_tokens import native_batch,Q_DLL,native_il_records
from probe_gxw_program_check_resources import SCRIPT
from probe_minimal_conditional_port_writes import streams,splice,observe,save
P=Path(__file__).resolve().parent
OUT=P/'minimal-guard-boundaries-20260930'


def main():
    OUT.mkdir(exist_ok=False);(OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    trace=OUT/'trace.js';trace.write_text(SCRIPT,encoding='utf-8')
    ready=[]
    for guard in ('none','input-only'):
      for kind in ('int','string'):
       for value in ('device','literal'):
        case=f'{guard}-{kind}-{value}';d=OUT/case;d.mkdir()
        source=(P/f'minimal-port-modes-20260930/input-read-{kind}-{value}/input.gxw').read_bytes()
        before=streams(source);name='MAIN.Program.pou';frame=frame_source(before[name]);call,=observe_calls(frame)['calls']
        raw=frame.raw
        # Descending offsets keep each span tied to the original frame.
        for direction in ('output','input'):
            if direction=='input' and guard=='input-only':continue
            span=call[direction+'_fragment'];a=span['offset'];b=a+span['length'];rows=groups(raw[a:b])
            expected='049c4f04' if direction=='output' else '049c2f04'
            index=next(i for i,g in enumerate(rows) if len(g)==2 and g[1].hex()==expected)
            assert rows[index+1][0]==bytes.fromhex('030d03')
            rows[index:index+2]=[[bytes.fromhex('04000204'),bytes.fromhex('08df5f5452554508')]]
            raw=splice(raw,a,b,b''.join(t for g in rows for t in g))
        source,receipt=patch_raw(source,name,before[name],raw)
        assert streams(source)==dict(before,**{name:raw})
        path=d/'input.gxw';path.write_bytes(source)
        prediction=project_projection(source,allow_scpi=True,resource_limit=1)[0];code=prediction.pop('output')
        (d/'predicted-0.bin').write_bytes(code)
        save(d/'before-native.json',dict(case=case,input_sha256=sha256(source),receipt=receipt,prediction=prediction,
             hypothesis='Literal guards retain a MOV/$MOV destination; conditional device aliases leave an open condition which ProgramCheck rejects. Unguarded copies or aliases should pass.'))
        ready.append((case,d,path,code))
    result=[];decodes=[];keys=[]
    for case,d,path,predicted in ready:
        native,observed,process=observe(path,d,trace);code=(native/'pcode-0-0.bin').read_bytes()
        row=dict(case=case,native_directory=str(native),process=process,check=observed['check'],diagnostics=observed['diagnostics'],
                 bytes=len(code),predicted_equal=predicted==code,exported=bool(observed['exported_sha256']),reads=observed['resource_reads'])
        if row['exported']:
            rd=d/'reopen';rd.mkdir();rn,ro,rp=observe(native/'native-saved.gxw',rd,trace)
            row['reopen']=dict(native_directory=str(rn),check=ro['check'],diagnostics=ro['diagnostics'],
                               byte_identical=code==(rn/'pcode-0-0.bin').read_bytes(),reads=ro['resource_reads'])
        if code:decodes.append(dict(mode='decode',input_base64=base64.b64encode(code+b'\0').decode(),case=case));keys.append(case)
        result.append(row);save(OUT/'comparison.json',result)
        print(json.dumps(dict(case=case,bytes=len(code),predicted_equal=row['predicted_equal'],check=row['check'],exported=row['exported'],
             errors=sorted(set(hex(e['code']) for e in row['diagnostics'] if e['kind']==2)),reopen=row.get('reopen',{}).get('byte_identical'))),flush=True)
    decoded=native_batch(decodes,OUT/'native-decode',dll=Q_DLL,cpu_code=209,native_versions=(25,))
    save(OUT/'native-listings.json',[dict(case=k,return_code=r['return_code'],records=native_il_records(base64.b64decode(r['output_base64']),encoding='cp932')) for k,r in zip(keys,decoded)])


if __name__=='__main__':main()
