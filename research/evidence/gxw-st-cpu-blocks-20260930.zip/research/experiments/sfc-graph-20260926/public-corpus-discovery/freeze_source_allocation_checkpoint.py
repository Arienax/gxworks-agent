"""Freeze source-allocation experiments without redistributing unlicensed projects."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, zipfile

ROOT = Path(__file__).resolve().parents[4]
P = Path(__file__).resolve().parent
OUT = ROOT / 'research/results/gxw-source-allocation-20260927'
OUT.mkdir(exist_ok=False)
digest = lambda b: hashlib.sha256(b).hexdigest()
public, local = {}, {}

def add(target, path):
    path = path.resolve()
    if not path.is_file():
        raise FileNotFoundError(path)
    target[path.relative_to(ROOT).as_posix()] = path

def top(target, directory):
    if not directory.exists():
        return
    for path in directory.iterdir():
        if path.is_file() and path.suffix in {'.json', '.jsonl', '.bin', '.gxw', '.txt', '.py', '.js', '.cs', '.dat'}:
            if path.name != 'frontend-snapshot.json':
                add(target, path)

def case(target, directory):
    top(target, directory)
    for child in directory.iterdir():
        if not child.is_dir():
            continue
        top(target, child)
        for name in ['CGTable.dat', 'DebugInformation2.dat', 'CallTree.dat', 'ResourceCallTree.dat']:
            path = child / 'compiler_DZComp' / name
            if path.exists():
                add(target, path)

# Freeze the current readers and native helper sources as well as experiment code.
# Vendor executables/DLLs and generated helper executables are deliberately omitted.
for directory, patterns in [(ROOT/'src/gxw', ['**/*.py', '**/*.json']),
                            (ROOT/'research', ['*.py', 'native/*.cs', 'native/*.js'])]:
    for pattern in patterns:
        for path in directory.glob(pattern):
            add(public, path)
scripts = ['source_q_allocation.py', 'reconstruct_q_source_allocated.py',
           'reconstruct_q_source_allocated_ranges.py', 'reconstruct_q_source_allocated_fragmented.py',
           'probe_native_allocation_bitmap.py', 'probe_native_allocation_bitmap_v2.py',
           'probe_native_allocation_ranges.py', 'probe_native_allocation_fragmented.py',
           'replay_native_allocation_bitmap.py', 'allocation_observer_tail.js',
           'allocation_observer_v2_tail.js', 'TraceInstructionSink.js', 'TraceBinaryAliasMethods.js',
           'probe_scpi_alias_device_forms.py', 'trace_scpi_alias_device_methods.py',
           'crosscheck_scpi_raw_alias_forwarding.py', 'reconstruct_scpi_raw_expansions.py',
           'reconstruct_scpi_raw_programs.py', 'replay_public_instruction_check.py',
           'freeze_source_allocation_checkpoint.py']
for name in scripts:
    add(public, P/name)
for pattern in ['allocator-*.txt', 'binary-width-*.txt']:
    for path in P.glob(pattern):
        add(public, path)
for name in ['scpi-provenance.json', 'download-inventory.json', 'samples/scpi-SCPI_FB.gxw', 'samples/scpi-LICENSE.txt']:
    add(public, P/name)
for name in ['samples/boxid.gxw', 'samples/project2.gxw', 'noeul-native-batch/case-00/input.gxw']:
    add(local, P/name)
add(public, P/'scpi-instance-binding-controls/same-instance/native/native-saved.gxw')

for name in ['native-allocation-bitmap', 'native-allocation-bitmap-v2']:
    top(local, P/name)
    for script in ['probe.py', 'observer.js']:
        add(public, P/name/script)
    for directory in (P/name).iterdir():
        if directory.is_dir():
            case(public if directory.name == 'same' else local, directory)
for name in ['native-allocation-range-holdouts', 'native-allocation-fragmented-holdout',
             'scpi-alias-device-forms', 'scpi-alias-device-methods',
             'scpi-raw-expansion-reconstruction', 'scpi-raw-program-reconstruction',
             'q-source-allocated-reconstruction', 'q-source-allocated-range-reconstruction',
             'q-source-allocated-fragmented-reconstruction']:
    top(public, P/name)
    for directory in (P/name).iterdir():
        if directory.is_dir():
            case(local if directory.name == 'project2' else public, directory)
top(local, P/'q-public-check-replay')
add(public, P/'q-public-check-replay/PublicCheckOracle.cs')

comparisons = []
for name, native_name in [('q-source-allocated-reconstruction', None),
                          ('q-source-allocated-range-reconstruction', 'native-allocation-range-holdouts'),
                          ('q-source-allocated-fragmented-reconstruction', 'native-allocation-fragmented-holdout')]:
    for row in json.loads((P/name/'comparison.json').read_text()):
        label = row['case']
        if label == 'project2':
            baseline = json.loads((P/'native-allocation-bitmap-v2/case-02/comparison.json').read_text())['baseline_directory']
        else:
            folder = native_name or 'scpi-alias-device-methods'
            baseline = json.loads((P/folder/label/'comparison.json').read_text())['baseline_directory']
        candidate = P/name/label/'predicted-pcode.bin'
        native = Path(baseline)/'pcode-0-0.bin'
        assert candidate.read_bytes() == native.read_bytes()
        assert digest(candidate.read_bytes()) == row['predicted_sha256'] == row['native_sha256']
        comparisons.append(dict(row, candidate=candidate.relative_to(ROOT).as_posix(),
                                native=native.relative_to(ROOT).as_posix(),
                                source=Path(row['source']).relative_to(ROOT).as_posix(),
                                visibility='local-only' if label == 'project2' else 'repository'))
assert len(comparisons) == 11 and sum(r['allocations_exact'] for r in comparisons) == 598

def archive(files, path, visibility):
    rows = []
    with zipfile.ZipFile(path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, file in sorted(files.items()):
            raw = file.read_bytes()
            rows.append(dict(path=name, bytes=len(raw), sha256=digest(raw)))
            archive.writestr(name, raw)
        archive.writestr('checkpoint-files.json', json.dumps(dict(visibility=visibility, files=rows), indent=2))
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
        for row in rows:
            assert digest(archive.read(row['path'])) == row['sha256']
    return dict(path=path.relative_to(ROOT).as_posix(), bytes=path.stat().st_size,
                sha256=digest(path.read_bytes()), visibility=visibility, files=rows)

archives = [archive(public, ROOT/'research/evidence/gxw-source-allocation-20260927.zip',
                    'SCPI MIT-derived raw evidence and repository source snapshot; no vendor binaries'),
            archive(local, P/'gxw-source-allocation-local-20260927.zip',
                    'Local-only Project2, BoxID and Noeul inputs/outputs; redistribution permission not established')]
environment = []
for path in [Path('D:/GXWORKS2/Easysocket/Compiler/ECCompiler_IEC.dll'),
             Path('D:/GXWORKS2/Easysocket/CodeGenerator/ECCodeGenerator2.dll')]:
    environment.append(dict(path=str(path), bytes=path.stat().st_size, sha256=digest(path.read_bytes())))
manifest = dict(schema=1, created_utc=datetime.now(timezone.utc).isoformat(),
                base_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
                code_snapshot='Archived source bytes are authoritative; not a Git commit or release.',
                environment=environment, archives=archives, comparisons=comparisons,
                claims=dict(full_main_byte_identical=11, component_allocations_exact=598,
                            distinct_real_sources_for_full_main=2, scpi_caller_and_range_controls=10,
                            stored_assignment_poison_invariant=True,
                            native_width_checker_still_required=True),
                negative_evidence=['word-exhausted: compiler diagnostic 0x050f1035 on MAIN/SCPI_1.sPrm',
                                   'scpi-alias-device-forms: internal-site observer failures/timeouts preserved',
                                   'original predictor rejected alternate W/B ranges before model extension'],
                limits=['Q03UDV only in this source-allocation comparison',
                        'Original declaration CGTable is an input; no frontend reconstruction claim',
                        'No general latch, R/ZR, overlapping explicit address or temporary-lifetime model',
                        'No independent PLC or simulator execution validation',
                        'Variants and repeated component allocations are not independent real projects'])
(OUT/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n', encoding='utf-8')
print(json.dumps(dict(archives=[{k:v for k,v in a.items() if k!='files'}|dict(file_count=len(a['files'])) for a in archives],
                      comparisons=len(comparisons), allocation_count=598)))
