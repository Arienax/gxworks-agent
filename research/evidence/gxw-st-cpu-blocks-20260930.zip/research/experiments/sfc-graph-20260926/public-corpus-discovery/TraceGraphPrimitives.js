// Read-only, bounded ECCompiler observations. Never invoke or replace targets.
'use strict';
let serial = 0;
const seen = new Set();
function location(p) {
  const m = Process.findModuleByAddress(p);
  return m ? {module: m.name, rva: p.sub(m.base).toString()} : null;
}
function bytes(p, count) {
  try {
    const r = Process.findRangeByAddress(p);
    if (!r || r.protection.indexOf('r') < 0) return null;
    const n = Math.min(count, r.base.add(r.size).sub(p).toUInt32());
    return Array.from(new Uint8Array(p.readByteArray(n)), v => v.toString(16).padStart(2, '0')).join('');
  } catch (_) { return null; }
}
const specs = {
  ObjectNew: 1, ObjectDelete: 1, ChangeInit: 4,
  CompileStart: 28, Compile: 7, CompileEnd: 1, Link: 6,
  Load: 2, Save: 2, LoadFromProjectDB: 4, SaveToProjectDB: 4,
  InitializeAddressConverter: 25, SetSymbolicData: 4,
  GetSymbolicData: 4, SetSystemVariables: 3, Commit: 2,
  GetPCode: 7, GetPCodeInfo: 5, GetUnLinkedPCodeInfo: 5
};
const observer = Process.attachModuleObserver({onAdded(m) {
  if (!['eccompiler.dll', 'eccompiler_iec.dll'].includes(m.name.toLowerCase()) || seen.has(m.base.toString())) return;
  seen.add(m.base.toString());
  send({event: 'module', name: m.name, path: m.path, base: m.base.toString(), size: m.size, arch: Process.arch});
  for (const [name, count] of Object.entries(specs)) {
    const address = m.findExportByName(name);
    if (address === null) continue;
    Interceptor.attach(address, {
      onEnter(args) {
        this.id = ++serial;
        this.saved = [];
        for (let i = 0; i < count; ++i) this.saved.push(args[i]);
        const values = this.saved.map((p, i) => ({index: i, value: p.toString(), location: location(p), bytes: bytes(p, 256)}));
        const buffers = [];
        const bounded = (label, p, size) => {
          if (size >= 0 && size <= 0x1000000) buffers.push({label, address:p.toString(), requested_size:size, bytes:bytes(p,size)});
        };
        if (name === 'SetSystemVariables') bounded('system_variables', args[2], args[1].toInt32());
        if (name === 'InitializeAddressConverter') bounded('parameter_block', args[2], args[1].toInt32());
        if (name === 'CompileStart') bounded('parameter_block', args[3], args[2].toInt32());
        if (name === 'Compile') {
          bounded('symbolic_data', args[4], args[3].toInt32());
          const n = args[1].toInt32();
          if (n >= 0 && n <= 1024) {
            bounded('compile_descriptors', args[2], n * 28);
            for (let i=0; i<n; ++i) {
              const d = args[2].add(i*28);
              try {
                bounded('source_' + i, d.add(4).readPointer(), d.readS32());
                buffers.push({label:'name_' + i, bytes:bytes(d.add(8).readPointer(),256)});
              } catch (_) {}
            }
          }
        }
        let callStack = null;
        if (['Compile', 'CompileStart', 'LoadFromProjectDB'].includes(name)) {
          try { callStack = Thread.backtrace(this.context, Backtracer.ACCURATE).map(location); }
          catch (error) { callStack = {error:String(error)}; }
        }
        send({event:'enter', id:this.id, name, module:m.name, thread:this.threadId, caller:location(this.returnAddress),
              call_stack:callStack, args:values, buffers});
      },
      onLeave(result) {
        send({event:'leave', id:this.id, name, module:m.name, result:result.toString(),
          result_bytes: name === 'ObjectNew' ? bytes(result, m.name.toLowerCase().includes('_iec') ? 0x198 : 0x194) : null,
          args:this.saved.map((p, i) => ({index:i, value:p.toString(), bytes:bytes(p, 256)}))});
      }
    });
  }
}});
send({event:'ready', process_id:Process.id, arch:Process.arch});

// Read-only network records and normalized mode flags, pinned to entry bytes.
const guards={"data_entry": "b81a017a66e8f374040083ec", "mode_entry": "56578b7c240c8db1800a0000"};
let primitiveInstalled=false;
function ascii(p){try{let s='';for(let i=0;i<1024;i++){const n=p.add(i).readU8();if(!n)return s;if(n>127)return null;s+=String.fromCharCode(n);}return null;}catch(_){return null;}}
function primitives(){
 if(primitiveInstalled)return;
 const c=Process.findModuleByName('DZDataABS_Compiler_IEC.dll');if(!c)return;
 primitiveInstalled=true;
 const d=c.base.add(0x1005c).readPointer().sub(147021);
 const s=c.base.add(0x10110).readPointer().sub(6444);
 if(bytes(d.add(0x33583),12)!==guards.data_entry || bytes(s.add(0x49d7d),12)!==guards.mode_entry){send({event:'primitive-guard-failed'});return;}
 send({event:'primitive-hooks-installed',data:d.toString(),sic:s.toString()});
 Interceptor.attach(d.add(0x33583),{onEnter(a){this.output=a[2];},onLeave(r){
  if(r.toInt32()!==0)return;
  try{const n=this.output.add(20).readS32();const ptr=this.output.add(24).readPointer();if(n<0||n>1000)throw new Error('network size');const records=[];
   for(let i=0;i<n;i++){const e=ptr.add(i*52);const np=e.add(44).readS32();if(np<0||np>256)throw new Error('port count');const pp=e.add(48).readPointer();const ports=[];for(let j=0;j<np;j++)ports.push(bytes(pp.add(j*16),16));records.push({raw:bytes(e,52),symbol:ascii(e.add(16).readPointer()),name:ascii(e.add(24).readPointer()),ports});}
   send({event:'native-network-records',header:bytes(this.output,28),records});
  }catch(e){send({event:'primitive-observation-error',error:String(e)});}
 }});
 Interceptor.attach(s.add(0x49d7d),{onEnter(a){try{const self=this.context.ecx;const arr=self.add(0xa80);const n=arr.add(8).readS32();const i=a[0].toInt32();if(i<0||i>=n||n>8192)throw new Error('mode index');const e=arr.add(4).readPointer().add(i*4).readPointer();this.row={index:i,raw:bytes(e,16),flags:e.add(4).readU32()};}catch(e){this.row={error:String(e)};}},onLeave(r){send({event:'native-port-mode',...this.row,mode:r.toUInt32()&255});}});
}
Process.attachModuleObserver({onAdded(m){const name=m.name.toLowerCase();let p=null;if(name==='dzdataabs_compileradapter.dll')p=m.base.add(0x13cc0);if(name==='eccompiler_iec.dll')p=m.findExportByName('ObjectNew');if(p)Interceptor.attach(p,{onEnter(){primitives();}});}});
