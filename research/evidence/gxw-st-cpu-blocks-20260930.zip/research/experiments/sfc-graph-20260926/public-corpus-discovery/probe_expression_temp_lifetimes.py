"""Observe allocation/release across adjacent IN_OUT expression calls."""
from dataclasses import replace
from pathlib import Path
import base64,json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from gxw.structured_pou import parse_structured_pou
from gxw.structured_pou_writer import serialize_structured_pou
from gxw.project_metadata import mark_observed_source_compile_pending
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_program_check_resources import SCRIPT
from probe_minimal_conditional_port_writes import streams,observe,save
from native_gxw_tokens import native_batch,DEFAULT_DLL,native_il_projection
P=Path(__file__).resolve().parent
OUT=P/'expression-temp-lifetimes-20260930'


def main():
    OUT.mkdir(exist_ok=False);(OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    trace=OUT/'trace.js';trace.write_text('(()=>{'+(P/'native-allocation-bitmap-v2/observer.js').read_text()+'\n})();\n(()=>{'+SCRIPT+'\n})();',encoding='utf-8')
    plans=[('array-first','native-graph-inout-array-writeback/input-inverted/source.gxw',False),
           ('array-both','native-graph-inout-array-writeback/input-inverted/source.gxw',True),
           ('scalar-both','native-graph-inout-writeback-v2/output-bound/source.gxw',True)]
    ready=[]
    for case,rel,change in plans:
        d=OUT/case;d.mkdir();source=(P/rel).read_bytes();before=streams(source);receipt=None
        if change:
            name='1.Program.pou';doc=parse_structured_pou(before[name],logical_name=name)
            nodes=tuple(replace(n,ports=tuple(replace(port,port_kind_code=9) if port.local_x==0 and port.local_y==3 else port for port in n.ports)) if n.kind_code==2 else n for n in doc.nodes)
            assert sum(n.kind_code==2 for n in nodes)==2
            raw=mark_observed_source_compile_pending(serialize_structured_pou(replace(doc,nodes=nodes)),logical_name=name)
            source,receipt=patch_raw(source,name,before[name],raw)
            assert streams(source)==dict(before,**{name:raw})
        path=d/'input.gxw';path.write_bytes(source)
        save(d/'before-native.json',dict(case=case,input_sha256=sha256(source),receipt=receipt,
            hypotheses=['Temporary expressions may reuse storage after each call.',
                        'Temporary expressions may retain distinct storage for the whole compilation unit.',
                        'Copy-in and copyback may allocate different lifetimes even for the same inverted expression.']))
        ready.append((case,d,path))
    results=[];requests=[];keys=[]
    for case,d,path in ready:
        native,observed,process=observe(path,d,trace)
        messages=[json.loads(l) for l in (native/'events.jsonl').read_text().splitlines()]
        events=[m['payload'] for m in messages if m.get('type')=='send']
        failures=[m for m in messages if m.get('type')=='error' or 'error' in m.get('payload',{}).get('event','') or m.get('payload',{}).get('observation_error')]
        allocations=[e for e in events if e.get('event') in ('typed-allocation','pool-allocation','external-bitmap-change','component-userinfo-write')]
        code=(native/'pcode-0-0.bin').read_bytes()
        row=dict(case=case,native_directory=str(native),process=process,check=observed['check'],diagnostics=observed['diagnostics'],
             trace_errors=failures,pcode_sha256=sha256(code),bytes=len(code),allocations=allocations,reads=observed['resource_reads'])
        results.append(row);save(OUT/'comparison.json',results)
        print(json.dumps(dict(case=case,check=row['check'],errors=sorted(set(hex(x['code']) for x in row['diagnostics'] if x['kind']==2)),
             trace_errors=failures,typed=[{k:e[k] for k in ('type','category','after','caller','result')} for e in allocations if e['event']=='typed-allocation'],
             outside_changes=[{k:e[k] for k in ('action','start','count','caller')} for e in allocations if e['event']=='external-bitmap-change'])),flush=True)
        if failures or not any(e['event']=='typed-allocation' for e in allocations):raise RuntimeError('allocation evidence incomplete')
        if code:requests.append(dict(mode='decode',case=case,input_base64=base64.b64encode(code+b'\0').decode()));keys.append(case)
    decoded=native_batch(requests,OUT/'native-decode',dll=DEFAULT_DLL,cpu_code=0x208)
    save(OUT/'native-listings.json',[dict(case=k,return_code=r['return_code'],listing=native_il_projection(base64.b64decode(r['output_base64']),encoding='gb18030')) for k,r in zip(keys,decoded)])


if __name__=='__main__':main()
