"""Observe Q02/Q02H converter initialization in an owned offline build."""
from pathlib import Path
import json
import sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from replay_gxw_workspace import run,prepare,trace_prepared
from gxw.lossless import sha256
P=Path(__file__).resolve().parent
OUT=P/'q02-native-configuration'
SCRIPT=r"""
Process.attachModuleObserver({onAdded(m){
 if(!/^ECCodeGenerator2\.dll$/i.test(m.name))return;
 send({event:'module',path:m.path});
 for(const name of ['Open','SetVersion']){
  Interceptor.attach(m.getExportByName(name),{
   onEnter(a){this.name=name;this.handle=a[0].toString();
    if(name==='Open')send({event:name,handle:this.handle,cpu:a[1].toInt32(),mode:a[2].toInt32()});
    else {const n=a[1].toInt32();let values=[];if(n>=0&&n<=32)for(let i=0;i<n;i++)values.push(a[2].add(4*i).readU32());
     send({event:name,handle:this.handle,count:n,values:values});}
   },onLeave(r){send({event:this.name+'_result',handle:this.handle,result:r.toString()});}
  });
 }
}});
"""


def main():
    OUT.mkdir(exist_ok=False)
    (OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    source=P/'new-source-holdouts/case-00/input.gxw'
    for attempt in range(1,5):
        baseline=OUT/f'baseline-{attempt}'
        outcome=run(source,baseline,compile=True,export_project=True,snapshot_frontend=True,program_check=True,project_alias='Q02CONTROL')
        events=[json.loads(l) for l in (baseline/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
        if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
    script=OUT/'config.js';script.write_text(SCRIPT,encoding='utf-8')
    for attempt in range(1,5):
        traced=OUT/f'trace-{attempt}'
        prepare(source,traced,compile=True,export_project=True,snapshot_frontend=True,program_check=True,project_alias='Q02CONTROL')
        trace=trace_prepared(traced,script)
        events=[json.loads(l) for l in (traced/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
        if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
    observations=[json.loads(l) for l in (traced/'events.jsonl').read_text(encoding='utf-8').splitlines()]
    result=dict(source_sha256=sha256(source.read_bytes()),baseline=str(baseline),outcome=outcome,traced=str(traced),trace=trace,
        observations=observations,byte_identical=(baseline/'pcode-0-0.bin').exists() and (traced/'pcode-0-0.bin').exists() and
        (baseline/'pcode-0-0.bin').read_bytes()==(traced/'pcode-0-0.bin').read_bytes())
    (OUT/'comparison.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result),flush=True)


if __name__=='__main__':main()
