"""Read the controlled single-reference .tsk shape and correlate native tasks.

Task scheduling flags, resource assignment and called FBs remain outside this
reader. A POU without a direct task reference is not automatically dead code.
"""
from pathlib import Path
import json, struct, sys
ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'research')]
from gxw.lossless import inspect_project, sha256
P = Path(__file__).resolve().parent

def task_reference(raw):
    def text(offset):
        if offset + 4 > len(raw):raise ValueError('truncated task string')
        count=struct.unpack_from('<I',raw,offset)[0]; end=offset+4+count*2
        if not 1<=count<=8192 or end>len(raw):raise ValueError('unbounded task string')
        value=raw[offset+4:end].decode('utf-16le')
        if not value.endswith('\0') or '\0' in value[:-1]:raise ValueError('invalid task string terminator')
        return value[:-1],end
    if len(raw)<54:raise ValueError('truncated task prefix')
    first,offset=text(54);second,offset=text(offset)
    if raw[offset:offset+12]!=bytes.fromhex('1f0000000000000001000000'):
        raise ValueError('outside controlled single-reference task shape')
    reference_offset=offset+12;name,end=text(reference_offset)
    if raw[end:]!=bytes.fromhex('01000000010000000000'):
        raise ValueError('unknown task reference suffix')
    return dict(program_reference=name,reference_offset=reference_offset,
                reference_bytes=end-reference_offset,uninterpreted_strings=[first,second],
                prefix_sha256=sha256(raw[:54]),raw_sha256=sha256(raw),handling='partially-decoded')

if __name__=='__main__':
    out=P/'q-task-reference-corpus-v2';out.mkdir(exist_ok=False)
    (out/'probe.py').write_bytes(Path(__file__).read_bytes())
    native={}
    batch=P/'noeul-native-batch'
    for line in (batch/'cases.jsonl').read_text(encoding='utf-8').splitlines():
        row=json.loads(line)
        folder=batch/f"case-{row['index']:02d}"
        if not (folder/'native-events.jsonl').exists():continue
        events=[json.loads(s) for s in (folder/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
        parents=[e['id'] for e in events if e.get('operation')=='NativeCollection' and e['kind']==7]
        resources=[e for e in events if e.get('operation')=='NativeObject' and e['parent'] in parents]
        tasks=[dict(resource=r['name'],task=e['name']) for r in resources for e in events
               if e.get('operation')=='NativeObject' and e['parent']==r['id']]
        inventories={tuple(e['id']):e['count'] for e in events if e.get('operation')=='InventoryCount'}
        complete=len(parents)==1 and all(inventories.get(tuple(parent))==sum(
            e.get('operation')=='NativeObject' and e['parent']==parent for e in events)
            for parent in parents+[r['id'] for r in resources])
        native[row['input_sha256']]=dict(directory=str(folder.relative_to(P)),tasks=tasks,complete=complete,
            diagnostic=None if complete else 'Native resource/task inventory was not completed; empty events are not an empty task list.')
    rows=[]; gaps=[]
    for f in sorted((P/'noeul-public-corpus').rglob('*.gxw')):
        source=f.read_bytes();streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
        tasks=[]
        for name,raw in streams.items():
            if not name.endswith('.tsk'):continue
            try:reference=task_reference(raw)
            except ValueError as exc:
                gaps.append(dict(file=str(f.relative_to(P)),task=name,error=str(exc)));continue
            reference.update(task=name,resolved_source=reference['program_reference']+'.Program.pou' in streams)
            tasks.append(reference)
        references={r['program_reference']+'.Program.pou' for r in tasks}
        unreferenced=[n for n in streams if n.endswith('.Program.pou') and n not in references]
        control=native.get(sha256(source))
        exact=None if control is None or not control['complete'] else sorted(r['task'] for r in control['tasks'])==sorted(r['task'][:-4] for r in tasks)
        rows.append(dict(file=str(f.relative_to(P)),sha256=sha256(source),tasks=tasks,source_pous_without_direct_reference=unreferenced,
                         native_task_inventory=control,native_task_inventory_exact=exact))
    result=dict(summary=dict(projects=len(rows),tasks=sum(len(r['tasks']) for r in rows),
        resolved=sum(t['resolved_source'] for r in rows for t in r['tasks']),gaps=len(gaps),
        source_pous_without_direct_reference=sum(len(r['source_pous_without_direct_reference']) for r in rows),
        native_checked=sum(r['native_task_inventory_exact'] is not None for r in rows),
        native_inventory_exact=sum(r['native_task_inventory_exact'] is True for r in rows)),projects=rows,gaps=gaps,scope=__doc__)
    with (out/'comparison.json').open('x',encoding='utf-8') as f:json.dump(result,f,ensure_ascii=False,indent=2)
    print(json.dumps(dict(summary=result['summary'],gaps=gaps,
                         inventory_differences=[r for r in rows if r['native_task_inventory_exact'] is False]),ensure_ascii=True))
