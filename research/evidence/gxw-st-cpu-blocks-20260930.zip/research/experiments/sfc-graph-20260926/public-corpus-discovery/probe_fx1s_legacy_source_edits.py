"""Predict same-size and growing edits in a real legacy FX1S source frame.

Only fresh owned offline compiler workspaces are used. No PLC or simulator.
Unrelated nested streams, including old compiled caches, remain byte-identical
in each candidate; the independent native build must produce the new body.
"""
from pathlib import Path
import argparse
import json
import struct
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'research')]
from gxw.lossless import inspect_project, sha256
from gxw.token_listing import decode_token_listing
from gxw.token_pou import frame_token_pou
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import run
from gxw_corpus import project_token_context

P = Path(__file__).resolve().parent
OUT = P / 'fx1s-legacy-source-edits'


def main():
    global OUT
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--minimal', action='store_true', help='use a derived three-instruction control in the original container')
    args = parser.parse_args()
    if args.minimal:
        OUT = P / 'fx1s-legacy-minimal-source-edits'
    OUT.mkdir(exist_ok=False)
    (OUT / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    source = (P / 'additional-real-projects/case-08/input.gxw').read_bytes()
    image = inspect_project(source)
    context = project_token_context(image)
    assert context['token_profile'] == 'fx1s'
    stream = next(s for s in image.streams if s.logical_name == 'MAIN.Program.pou')
    listing = decode_token_listing(stream.raw, profile='fx1s', text_encoding=context['text_encoding'])
    instruction = next(r for r in listing.instructions if r.mnemonic == 'MOV' and r.args == ('K2', 'D3'))
    token = instruction.operands[0].tokens[0]
    assert token.raw.hex() == '04e80204' and len(stream.raw) - listing.source.body_end == 20
    ready = []
    for name, replacement in [('baseline', token.raw), ('same-size-k3', bytes.fromhex('04e80304')),
                              ('grow-k300', bytes.fromhex('05e82c0105'))]:
        target = OUT / name
        target.mkdir()
        if args.minimal:
            # LD X0; MOV K{value} D3; END. The selected MOV header and D3
            # operand are original source tokens. The LD and END spellings
            # are independently recorded native controls.
            body = bytes.fromhex('030003049c0004') + instruction.tokens[0].raw + replacement + instruction.tokens[-1].raw + bytes.fromhex('033403')
            updated = bytearray(stream.raw[:79] + body + stream.raw[listing.source.body_end:])
            delta = len(body) - len(listing.source.body)
        else:
            updated = bytearray(stream.raw[:token.offset] + replacement + stream.raw[token.offset + len(token.raw):])
            delta = len(replacement) - len(token.raw)
        for offset in (55, 59):
            struct.pack_into('<I', updated, offset, struct.unpack_from('<I', stream.raw, offset)[0] + delta)
        unchanged = name == 'baseline' and not args.minimal
        if unchanged:
            changed, receipt = source, dict(scope='unchanged baseline')
        else:
            changed, receipt = patch_raw(source, stream.logical_name, stream.raw, bytes(updated))
        before = {(s.layer, s.name): s.raw for s in image.streams}
        after = {(s.layer, s.name): s.raw for s in inspect_project(changed).streams}
        changed_streams = [list(k) for k in before.keys() | after.keys() if before.get(k) != after.get(k)]
        assert [s for s in changed_streams if s[0] == 'nested'] == ([] if unchanged else [['nested', stream.name]])
        framed = frame_token_pou(updated)
        assert len(updated) - framed.body_end == 20
        (target / 'source.gxw').write_bytes(changed)
        (target / 'predicted-body.bin').write_bytes(framed.body)
        prediction = dict(original_sha256=sha256(source), candidate_sha256=sha256(changed),
            control_scope='derived minimal source in real project container' if args.minimal else 'real full program',
            cpu_context=context, program=stream.logical_name, original_trailer_bytes=20,
            offset=token.offset, before=token.raw.hex(), after=replacement.hex(), size_delta=delta,
            receipt=receipt, changed_streams=changed_streams, unrelated_nested_preserved=True,
            hypothesis='Native compilation consumes edited source, including its bounded legacy frame, despite untouched stale compiler caches.')
        (target / 'prediction-before-native.json').write_text(json.dumps(prediction, indent=2), encoding='utf-8')
        ready.append((name, target))
    results = []
    for name, target in ready:
        path = target / 'source.gxw'
        phases = []
        for phase in ('compile', 'reopen'):
            for attempt in range(1, 5):
                native = target / f'{phase}-{attempt}'
                outcome = run(path, native, compile=True, program_check=True, export_project=True,
                    snapshot_frontend=True, project_alias='FX1SLEGACY')
                events = [json.loads(l) for l in (native / 'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
                if not any(e.get('operation') == 'NativeTemporaryDirectoryCollision' for e in events):
                    break
            actual = native / 'pcode-0-0.bin'
            row = dict(phase=phase, native_directory=str(native), outcome=outcome,
                predicted_body_exact=actual.exists() and actual.read_bytes() == (target / 'predicted-body.bin').read_bytes())
            phases.append(row)
            path = native / 'native-saved.gxw'
            if path.exists():
                saved = next(s.raw for s in inspect_project(path.read_bytes()).streams if s.logical_name == stream.logical_name)
                saved_frame = frame_token_pou(saved)
                row.update(saved_source_body_exact=saved_frame.body == (target / 'predicted-body.bin').read_bytes(),
                    saved_trailer_bytes=len(saved) - saved_frame.body_end)
            print(json.dumps(dict(case=name, phase=phase, rejected=outcome['compiler_rejected'],
                full_check=outcome['program_check_completed'], body_exact=row['predicted_body_exact'],
                saved_trailer_bytes=row.get('saved_trailer_bytes'), diagnostics=outcome['diagnostics'])), flush=True)
            if not path.exists() or outcome['compiler_rejected']:
                break
        results.append(dict(case=name, phases=phases))
        (OUT / 'comparison.json').write_text(json.dumps(results, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
