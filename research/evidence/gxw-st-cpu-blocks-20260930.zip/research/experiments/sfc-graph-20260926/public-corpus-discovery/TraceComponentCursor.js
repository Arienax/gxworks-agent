(()=>{
'use strict';
const active=new Map();let seq=0;
function str(p,bound){try{let s='';for(let i=0;i<bound;i++){const c=p.add(i).readU8();if(c===0)return s;if(c>127)return null;s+=String.fromCharCode(c);}}catch(e){}return null;}
function hex(p,n){try{return Array.from(new Uint8Array(p.readByteArray(n)),v=>v.toString(16).padStart(2,'0')).join('');}catch(e){return null;}}
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='eccompiler_iec.dll')return;
 Interceptor.attach(m.findExportByName('Compile'),{onEnter(a){
  this.prior=active.get(this.threadId);const names=[];const n=a[1].toInt32();if(n>=0&&n<=1024)for(let i=0;i<n;i++)names.push(str(a[2].add(i*28+8).readPointer(),512));
  active.set(this.threadId,names.some(s=>s&&s.indexOf('TimerProbe')>=0));
 },onLeave(){active.set(this.threadId,this.prior);}});
 Interceptor.attach(m.base.add(0x15a20),{onEnter(a){
  this.keep=!!active.get(this.threadId);if(!this.keep)return;
  this.id=++seq;this.position=a[0];this.record=a[1];this.user=a[3];this.before=this.position.readS32();this.option=a[2].toInt32();this.table=this.context.ecx.toString();this.caller=this.returnAddress.sub(m.base).toString();
 },onLeave(r){if(!this.keep)return;send({event:'component-cursor-read',sequence:this.id,table:this.table,requested:this.before,next:this.position.readS32(),option:this.option,result:r.toInt32(),caller_rva:this.caller,name:r.toInt32()?str(this.record,261):null,user_info_hex:this.user.isNull()?null:hex(this.user,26)});}});
}});
})();
