"""Fresh-check conditional materialization across alias calls and instances."""
from pathlib import Path
import base64,json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from probe_gxw_parameters import device_allocation_record
from probe_gxw_simple_fb import frame_source,observe_calls
from probe_gxw_sfc_graph import patch_raw
from source_q_allocation import groups
from source_q_label_binding import scalar
from source_q_direct_projection import project_projection
from native_gxw_tokens import native_batch,Q_DLL,native_il_records
from probe_gxw_program_check_resources import SCRIPT
from probe_minimal_conditional_port_writes import streams,splice,observe,save
P=Path(__file__).resolve().parent
OUT=P/'fresh-port-lifetimes-20260930'


def main():
    OUT.mkdir(exist_ok=False);(OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    trace=OUT/'trace.js';trace.write_text(SCRIPT,encoding='utf-8')
    originals={}
    for kind in ('int','string'):
        for value in ('literal','device'):
            parent='input-only' if value=='literal' else 'none'
            originals[kind,value]=(P/f'minimal-guard-boundaries-20260930/{parent}-{kind}-{value}/input.gxw').read_bytes()
    requests=[];request_keys=[]
    for kind,values in (('int',('K123','K456','K789')),('string',('"ONE"','"TWO"','"THREE"'))):
      for i,value in enumerate(values):
        op='MOV' if kind=='int' else '$MOV';pin='iUnitNo' if kind=='int' else 'iResStr'
        text=f"LD X1F\0OUT '_iEn\0LD X{2+2*i}F\0ANI X{3+2*i}F\0{op} {value} '_{pin}"
        if kind=='string':text+="\0LD '_TRUE\0MOV K1 '_iUnitNo"
        requests.append(dict(mode='encode',text=text,input_base64=base64.b64encode(text.encode()+b'\0\0').decode()));request_keys.append((kind,i))
    answers=native_batch(requests,OUT/'native-encode',dll=Q_DLL,cpu_code=209,native_versions=(25,),
        device_context=device_allocation_record(streams(originals['int','literal'])['Param.wpa']).raw)
    assert all(a['return_code']=='0x00000000' for a in answers)
    encoded={k:base64.b64decode(a['output_base64']) for k,a in zip(request_keys,answers)}
    ready=[]
    for kind in ('int','string'):
      for order in ('literal-device-literal','instance1-instance2-instance1'):
        case=kind+'-'+order;d=OUT/case;d.mkdir();base=originals[kind,'literal'];before=streams(base)
        frame=frame_source(before['MAIN.Program.pou']);call,=observe_calls(frame)['calls'];blocks=[]
        for i in range(3):
            direct=i==1 and order=='literal-device-literal'
            source=originals[kind,'device' if direct else 'literal']
            f=frame_source(streams(source)['MAIN.Program.pou']);c,=observe_calls(f)['calls']
            block=f.raw[c['offset']:c['offset']+c['length']]
            out=c['output_fragment'];a=out['offset']-c['offset'];b=a+out['length'];rows=groups(block[a:b])
            assert len(rows)==2 and rows[-1][-1][1]==0xa8
            rows[-1][-1]=scalar('D',(300+i) if kind=='int' else (400+32*i))
            block=block[:a]+b''.join(t for g in rows for t in g)+block[b:]
            if not direct:
                inp=c['input_fragment'];a=inp['offset']-c['offset'];b=a+inp['length']
                block=block[:a]+encoded[kind,i]+block[b:]
            if i==1 and order=='instance1-instance2-instance1':
                assert block.count(b'SCPI_1')==2
                block=block.replace(b'SCPI_1',b'SCPI_2')
            blocks.append(block)
        raw=splice(frame.raw,call['offset'],call['offset']+call['length'],b''.join(blocks))
        assert len(observe_calls(frame_source(raw))['calls'])==3
        source,receipt=patch_raw(base,'MAIN.Program.pou',before['MAIN.Program.pou'],raw)
        assert streams(source)==dict(before,**{'MAIN.Program.pou':raw})
        path=d/'input.gxw';path.write_bytes(source)
        prediction=project_projection(source,allow_scpi=True,resource_limit=1)[0];code=prediction.pop('output')
        (d/'predicted-0.bin').write_bytes(code)
        save(d/'before-native.json',dict(case=case,input_sha256=sha256(source),receipt=receipt,prediction=prediction,
            hypothesis='Materialized inputs persist per instance across direct alias calls. A second instance receives distinct storage; returning to the first reuses its address.'))
        ready.append((case,d,path,code))
    result=[];decodes=[];keys=[]
    for case,d,path,predicted in ready:
        native,observed,process=observe(path,d,trace);code=(native/'pcode-0-0.bin').read_bytes()
        row=dict(case=case,native_directory=str(native),process=process,check=observed['check'],diagnostics=observed['diagnostics'],
                 bytes=len(code),predicted_equal=predicted==code,exported=bool(observed['exported_sha256']),reads=observed['resource_reads'])
        if row['exported']:
            rd=d/'reopen';rd.mkdir();rn,ro,rp=observe(native/'native-saved.gxw',rd,trace)
            row['reopen']=dict(native_directory=str(rn),check=ro['check'],diagnostics=ro['diagnostics'],
                byte_identical=code==(rn/'pcode-0-0.bin').read_bytes(),reads=ro['resource_reads'])
        if code:decodes.append(dict(mode='decode',input_base64=base64.b64encode(code+b'\0').decode(),case=case));keys.append(case)
        result.append(row);save(OUT/'comparison.json',result)
        print(json.dumps(dict(case=case,predicted_equal=row['predicted_equal'],check=row['check'],exported=row['exported'],
            reopen=row.get('reopen',{}).get('byte_identical'),errors=sorted(set(hex(e['code']) for e in row['diagnostics'] if e['kind']==2)))),flush=True)
    decoded=native_batch(decodes,OUT/'native-decode',dll=Q_DLL,cpu_code=209,native_versions=(25,))
    save(OUT/'native-listings.json',[dict(case=k,return_code=r['return_code'],records=native_il_records(base64.b64decode(r['output_base64']),encoding='cp932')) for k,r in zip(keys,decoded)])


if __name__=='__main__':main()
