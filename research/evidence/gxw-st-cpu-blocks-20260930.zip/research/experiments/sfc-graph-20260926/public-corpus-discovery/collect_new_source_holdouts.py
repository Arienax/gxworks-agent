"""Collect frozen Git blobs from sources not used to recover the current rules."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[4]
P = Path(__file__).resolve().parent
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'research')]
import collect_additional_real_projects as collector
from gxw_corpus import analyze


def main():
    out = P/'new-source-holdouts'; out.mkdir(exist_ok=False)
    (out/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    collector.OUT = out
    plans = []
    for repo in json.loads((P/'new-source-discovery/discovery.json').read_text(encoding='utf-8')):
        for entry in repo.get('files', []):
            if entry['path'].lower().endswith('.gxw'):
                plans.append(dict(case=f'case-{len(plans):02d}', repository=repo['repository'], tree_sha=repo['sha'],
                    path=entry['path'], blob_sha=entry['sha'], url=entry['url']))
    (out/'plans.json').write_text(json.dumps(plans,indent=2),encoding='utf-8')
    with ThreadPoolExecutor(max_workers=3) as pool:
        rows = list(pool.map(collector.retrieve, plans))
    (out/'inventory.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
    scans = []
    for row in rows:
        directory=out/row['case']; source=directory/'input.gxw'
        if not source.exists():
            scans.append(dict(case=row['case'],error=row.get('error'))); continue
        try:
            result=analyze(source.read_bytes())
            (directory/'corpus-analysis.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
            programs=[dict(name=s['logical_name'],bytes=s['size'],**{k:s['program'].get(k) for k in
                ['layout','decoded_instructions','instruction_gaps','critical_token_gaps']}) for s in result['streams'] if 'program' in s]
            scans.append(dict(case=row['case'],context=result['token_context'],coverage=result['coverage'],programs=programs))
        except Exception as exc:
            scans.append(dict(case=row['case'],error=type(exc).__name__+': '+str(exc)))
    (out/'scan.json').write_text(json.dumps(scans,indent=2),encoding='utf-8')
    for row in scans: print(json.dumps(row,ensure_ascii=True),flush=True)


if __name__ == '__main__':
    main()
