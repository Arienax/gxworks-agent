"""Independent source occurrence checks; differences remain explicit gaps."""
from collections import Counter
import json
from pathlib import Path
import re
import sys

ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.declarations import parse_declarations
from gxw.lossless import inspect_project,sha256
from gxw.token_pou import frame_token_pou
from probe_gxw_native_listing import project_text_context
from probe_gxw_st_sources import replace_observed_st

P=Path(__file__).resolve().parent
OUT=P/'native-reference-real-corpus'
sources=[json.loads(l) for l in (OUT/'results.jsonl').read_text().splitlines()]
comparisons=[]
for item in sources:
    capture=json.loads((OUT/item['case']/'references.json').read_text(encoding='utf-8'))
    if not capture['queries']:continue
    native=capture['queries'][0]['rows']
    source=Path(item['source']).read_bytes()
    image=inspect_project(source)
    streams={s.logical_name:s.raw for s in image.streams if s.logical_name}
    context=project_text_context(next(r for n,r in streams.items() if n.endswith('.prj')))
    docs=[parse_declarations(raw,logical_name=name) for name,raw in streams.items() if name.endswith(('.Labels.lh','.gh'))]
    definitions={r.type_reference.casefold() for d in docs for r in d.rows if r.type_code==15}
    globals={r.name.casefold() for d in docs if d.scope=='global' for r in d.rows}
    for name,raw in streams.items():
        if not name.endswith('.Program.pou'):continue
        owner=name.removesuffix('.Program.pou')
        row=dict(case=item['case'],object=name,sha256=sha256(raw),handling='not-checkable')
        relevant=[n for n in native if n['source']==owner]
        if owner.casefold() in definitions:
            row['diagnostic']='FB definition can be expanded across instances; raw occurrence multiplicity is not directly comparable'
            comparisons.append(row);continue
        if not relevant:
            row['diagnostic']='no returned native source references; not classified as unused or complete'
            comparisons.append(row);continue
        try:
            frame=frame_token_pou(raw)
            expected=Counter(t.raw[2:-1].decode(context['text_encoding']).casefold() for t in frame.tokens if t.raw[1]==0xdf)
            actual=Counter(n['name'].casefold() for n in relevant)
            row.update(kind='simple-label-tokens',raw_occurrences=sum(expected.values()),native_rows=len(relevant),
                differences=[dict(name=k,raw=v,native=actual[k]) for k,v in expected.items() if v!=actual[k]])
            row['handling']='differs' if row['differences'] else 'occurrence-counts-agree'
        except ValueError:
            try:
                _,text=replace_observed_st(raw,'')
                # Bounded lexical control, not a new ST semantic parser. Keep
                # physical line positions while hiding comments and strings.
                masked=re.sub(r"\(\*.*?\*\)|'[^']*'|\"[^\"]*\"",lambda m:''.join('\n' if c=='\n' else ' ' for c in m[0]),text,flags=re.S)
                locals={r.name.casefold() for d in docs if d.owner_name==owner for r in d.rows}
                expected=Counter((i,t.casefold()) for i,line in enumerate(masked.splitlines()) for t in re.findall(r'[^\W\d]\w*',line) if t.casefold() in globals|locals)
                actual=Counter((n['top'],re.split(r'[.\[]',n['name'])[0].casefold()) for n in relevant if '.' not in n['name'])
                row.update(kind='ST-declared-identifier-lexical',raw_occurrences=sum(expected.values()),native_rows=len(relevant),
                    differences=[dict(line=k[0],name=k[1],raw=v,native=actual[k]) for k,v in expected.items() if v!=actual[k]])
                row['handling']='differs' if row['differences'] else 'occurrence-counts-agree'
            except ValueError as exc:
                row['diagnostic']=str(exc)
        comparisons.append(row)
(OUT/'source-occurrence-crosscheck.json').write_text(json.dumps(comparisons,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(objects=len(comparisons),handling=Counter(r['handling'] for r in comparisons),
                     matched_occurrences=sum(r.get('raw_occurrences',0) for r in comparisons if r['handling']=='occurrence-counts-agree'),
                     differences=[r for r in comparisons if r['handling']=='differs'])))
