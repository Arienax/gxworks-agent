"""Compare graph-selected source/declarations with native frontend buffers.

Native buffer identities come only from the accepted baseline capture. A
declaration's embedded owner is excluded from the payload fingerprint because
the independent owner-swap control establishes that native omission.
"""
from pathlib import Path
import json,struct,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from probe_gxw_task_graph import inspect_task_graph
P=Path(__file__).resolve().parent
out=P/'q-pou-graph-frontend-comparison';out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
def streams(data):return {s.logical_name:s.raw for s in inspect_project(data).streams if s.logical_name}
def label_key(data):
    end=58+2*struct.unpack_from('<I',data,54)[0]
    return sha256(data[:54]+data[end:])
baseline=P/'q-label-owner-binding-v2/baseline'
base=streams((baseline/'input.gxw').read_bytes())
native=json.loads((baseline/'comparison.json').read_text(encoding='utf-8'))['frontend_pous']
label_fingerprints={label_key(base[r['pou']+'.Labels.lh']):r['buffer16']['sha256'] for r in native}
source_fingerprints={sha256(base[r['pou']+'.Program.pou']):r['buffer24']['sha256'] for r in native}
rows=[]
for experiment in ['q-label-owner-binding-v2','q-pou-name-binding']:
    result=json.loads((P/experiment/'comparison.json').read_text(encoding='utf-8'))
    for case in result['cases']:
        source=(P/experiment/case['case']/'input.gxw').read_bytes()
        graph=inspect_task_graph(source);raw=streams(source)
        assert not graph['gaps']
        observed={r['pou']:dict(declarations=r.get('buffer16',r.get('declarations'))['sha256'],source=r.get('buffer24',r.get('source'))['sha256']) for r in case['frontend_pous']}
        expected={name:dict(declarations=label_fingerprints[label_key(raw[p['declarations']])],source=source_fingerprints[sha256(raw[p['source_program']])]) for name,p in graph['programs'].items()}
        assert observed==expected
        rows.append(dict(experiment=experiment,case=case['case'],input_sha256=sha256(source),
            native_exact=True,observed=observed,graph=graph['programs'],
            native_compile=case['native'],full_pcode=result['decoded'][result['files'][case['case']]['pcode-0-0.bin']]))
result=dict(summary=dict(cases=len(rows),program_bindings=sum(len(r['graph']) for r in rows),all_exact=True),cases=rows,
    reader_sha256=sha256((ROOT/'research/probe_gxw_task_graph.py').read_bytes()),scope=__doc__)
(out/'comparison.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result['summary']))
