"""Fresh-check prior scalar/array IN_OUT lowering, including inversion traps."""
from pathlib import Path
import base64,json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from probe_gxw_program_check_resources import SCRIPT
from probe_minimal_conditional_port_writes import observe,save
from native_gxw_tokens import native_batch,DEFAULT_DLL,native_il_projection
P=Path(__file__).resolve().parent
OUT=P/'fresh-inout-copyback-20260930'


def main():
    OUT.mkdir(exist_ok=False);(OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    trace=OUT/'trace.js';trace.write_text('(()=>{'+(P/'TraceCallableFormals.js').read_text()+'\n})();\n(()=>{'+SCRIPT+'\n})();',encoding='utf-8')
    cases=[('scalar-output','native-graph-inout-writeback-v2','output-bound'),
           ('array-output','native-graph-inout-array-writeback','output-bound'),
           ('array-input-inverted','native-graph-inout-array-writeback','input-inverted'),
           ('array-output-inverted','native-graph-inout-array-writeback','output-inverted')]
    ready=[]
    for case,parent,oldcase in cases:
        d=OUT/case;d.mkdir();old=P/parent/oldcase
        record=next(r for r in json.loads((P/parent/'comparison.json').read_text()) if r['case']==oldcase)
        baseline=P/parent/record['native_directory']
        source=(old/'source.gxw').read_bytes();path=d/'input.gxw';path.write_bytes(source)
        code=(baseline/'pcode-0-0.bin').read_bytes();(d/'prior-0.bin').write_bytes(code)
        save(d/'before-native.json',dict(case=case,input_sha256=sha256(source),prior_directory=str(baseline),
             prior_code_sha256=sha256(code),prior_listing=record['listing'],
             hypothesis='Fresh ProgramCheck may accept lowered copies even when inverted IN_OUT inputs lose writeback or inverted array outputs copy only one word.'))
        ready.append((case,d,path,code))
    rows=[];requests=[];keys=[]
    for case,d,path,prior in ready:
        native,result,process=observe(path,d,trace);code=(native/'pcode-0-0.bin').read_bytes()
        row=dict(case=case,native_directory=str(native),process=process,check=result['check'],diagnostics=result['diagnostics'],
                 prior_equal=code==prior,sha256=sha256(code),bytes=len(code),exported=bool(result['exported_sha256']),reads=result['resource_reads'])
        if row['exported']:
            rd=d/'reopen';rd.mkdir();rn,rr,rp=observe(native/'native-saved.gxw',rd,trace)
            row['reopen']=dict(native_directory=str(rn),check=rr['check'],diagnostics=rr['diagnostics'],
                identical=code==(rn/'pcode-0-0.bin').read_bytes(),reads=rr['resource_reads'])
        messages=[json.loads(l) for l in (native/'events.jsonl').read_text().splitlines()]
        row['formals']=[m['payload'] for m in messages if m.get('payload',{}).get('event')=='native-callable-formals']
        row['trace_errors']=[m for m in messages if m.get('type')=='error' or m.get('payload',{}).get('event','').endswith(('error','failed'))]
        rows.append(row);save(OUT/'comparison.json',rows)
        if code:requests.append(dict(mode='decode',case=case,input_base64=base64.b64encode(code+b'\0').decode()));keys.append(case)
        print(json.dumps(dict(case=case,prior_equal=row['prior_equal'],check=row['check'],exported=row['exported'],
            reopen=row.get('reopen',{}).get('identical'),errors=sorted(set(hex(e['code']) for e in row['diagnostics'] if e['kind']==2)),trace_errors=row['trace_errors'])),flush=True)
    decoded=native_batch(requests,OUT/'native-decode',dll=DEFAULT_DLL,cpu_code=0x208)
    save(OUT/'native-listings.json',[dict(case=k,return_code=r['return_code'],listing=native_il_projection(base64.b64decode(r['output_base64']),encoding='gb18030')) for k,r in zip(keys,decoded)])


if __name__=='__main__':main()
