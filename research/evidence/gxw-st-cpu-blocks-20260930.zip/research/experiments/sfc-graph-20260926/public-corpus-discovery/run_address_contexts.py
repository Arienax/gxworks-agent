"""Native address conversion across real CPUs and one isolated parameter edit."""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'research')]
from gxw.lossless import inspect_project, sha256
from gxw.declarations import parse_declarations
from replay_gxw_workspace import run

P = Path(__file__).resolve().parent
OUT = P / 'native-address-contexts'
OUT.mkdir(exist_ok=False)
sources = {'q': P / 'samples/project2.gxw', 'fx3u': P / 'samples/modbus-master.gxw',
           'fx1s': P / 'samples/stepper-2-1.gxw', 'structured': P / 'samples/boxid.gxw',
           'q_small_t': P / 'project2-timer-range-isolation/second/changed.gxw'}
devices = ['X7', 'X8', 'X10', 'X1F', 'X20', 'Y7', 'Y8', 'Y10', 'Y1F', 'Y20',
           'M0', 'M8191', 'M8192', 'D0', 'D100', 'D32767', 'D32768', 'D100.0', 'D100.F', 'D100.10',
           'W1A', 'W1FFF', 'W2000', 'T0', 'T255', 'T256', 'T1023', 'T1024', 'T2047', 'T2048',
           'ST0', 'ST1023', 'ST1024', 'C0', 'C199', 'C200', 'C255', 'C256', 'C1023', 'C1024',
           'R0', 'ZR0', 'B0', 'L0', 'S0', 'SM0', 'SD0', 'Z0', 'TN0', 'TC0', 'TS0']
for case, source in sources.items():
    queries = [dict(direction='iec', address=a, elements=n, attribute=t)
               for a in devices for n in [1, 2] for t in [0, 1]]
    expected = []
    for stream in inspect_project(source.read_bytes()).streams:
        if not (stream.logical_name or '').endswith(('.gh', '.Labels.lh')):
            continue
        document = parse_declarations(stream.raw, logical_name=stream.logical_name)
        for row in document.rows:
            if not row.device or not row.iec_address:
                continue
            for direction, address, target in [('iec', row.device, row.iec_address), ('melsec', row.iec_address, row.device)]:
                expected.append(dict(index=len(queries), name=row.name, object=stream.logical_name,
                                     declared_type=row.data_type, expected=target))
                queries.append(dict(direction=direction, address=address, elements=1, attribute=0))
    native = run(source, OUT / case, compile=True, export_project=True, project_alias='ADDRCTX', address_queries=queries)
    row = dict(case=case, source=str(source), source_sha256=sha256(source.read_bytes()),
               native={k:native[k] for k in ['returncode', 'open_succeeded', 'compile_completed', 'compiler_rejected', 'diagnostics', 'project_attributes']})
    answers = OUT / case / 'native-address-conversions.json'
    if answers.exists():
        answers = json.loads(answers.read_text(encoding='utf-8-sig'))
        row['declared_pairs'] = [dict(item, native=answers[item['index']], exact=answers[item['index']]['address'] == item['expected']) for item in expected]
        row['declared_pair_matches'] = sum(x['exact'] for x in row['declared_pairs'])
    with (OUT / 'results.jsonl').open('a', encoding='utf-8') as output:
        output.write(json.dumps(row) + '\n')
    print(json.dumps({k:v for k,v in row.items() if k != 'declared_pairs'}), flush=True)
