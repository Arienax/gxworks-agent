from pathlib import Path
from collections import Counter
import json,sys,base64,subprocess
ROOT=Path.cwd();sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.compiler_tables import parse_compiler_tables
from gxw.compiler_assignment import parse_compiler_assignment
from gxw.token_pou import frame_token_pou,parse_token_fragment
from probe_gxw_compiled_references import stored_records
from probe_gxw_operand_bindings import observed_q_address
P=ROOT/'research/experiments/sfc-graph-20260926/public-corpus-discovery';out=P/'q-simple-lowering-reconstruction-v2';out.mkdir(exist_ok=False);helper=P/'q-public-check-replay/PublicCheckOracle.exe';results=[]
for folder,ids in [('real-binary-public-check',['case-02']),('real-binary-public-check-multi',['case-05','case-09'])]:
 for caseid in ids:
  d=P/folder/caseid;case=json.loads((d/'comparison.json').read_text(encoding='utf-8'));ev=[x['payload'] for l in (d/case['trace_directory']/'events.jsonl').read_text(encoding='utf-8').splitlines() if (x:=json.loads(l)).get('type')=='send'];encoding=case['context']['text_encoding'];source=Path(case['source']).read_bytes();source_image=inspect_project(source);saved=(d/'untraced'/case['baseline']['native_export']['file']).read_bytes();table_raw=next(s.raw for s in inspect_project(saved).streams if s.logical_name=='CGTable.dat');tables=parse_compiler_tables(table_raw);pous=[tables.pou_at(r.table_offset) for r in tables.tables[1].records]
  compiles=[e for e in ev if e['event']=='sink-compile' and any(s['raw'].startswith('0c00000000000000ffffffff') and len(bytes.fromhex(s['raw']))>16 for s in e['sources'])]
  for c in compiles:
   check=[e for e in ev if e['event']=='check-instruction-code2' and e['compile_id']==c['compile_id']]
   if not check:continue
   assert len({e['device_context'] for e in check})==1;ctx=bytes.fromhex(check[0]['device_context']);s=c['sources'][0];scope=bytes.fromhex(s['name']['hex']);poun=scope.decode(encoding)+'.Program.pou';orig=next(x.raw for x in source_image.streams if x.logical_name==poun);fr=frame_token_pou(orig);assert fr.body==bytes.fromhex(s['raw'])[12:]
   groups,_=stored_records(fr,encoding=encoding);req=[];rebuilt_groups=[];binding_proof=[]
   for ordinal,g in enumerate(groups):
    tokens=parse_token_fragment(g['raw'],0,len(g['raw'])).tokens;changed=[]
    for t in tokens:
     if t.raw[1]!=0xdf:changed.append(t.raw);continue
     name=t.raw[2:-1];found=[]
     for pou in pous:
      if pou.name_bytes not in [scope,b'@GLOBALS']:continue
      for comp in tables.components(pou):
       if comp.name_bytes.lower()!=name.lower():continue
       a=parse_compiler_assignment(comp.user_info);ao=tables.component_address_offset(comp);ad=tables.address_at(ao) if ao>=0 else None
       if a.status=='decoded':family,n=a.device_family,a.number
       elif ad:
        projected=observed_q_address(ad.iec_address_bytes);assert projected['handling']!='opaque';assert not projected.get('addressing');family,n=projected['family'],projected['number']
       else:raise ValueError('unresolved component allocation')
       assert family in ['M','D','X','Y','T'];assert 0<=n<=65535
       value=n.to_bytes(max(1,(n.bit_length()+7)//8),'little');length=len(value)+3;encoded=bytes([length,{'M':0x90,'D':0xa8,'X':0x9c,'Y':0x9d,'T':0xc2}[family]])+value+bytes([length]);found.append((encoded,comp.record.table_offset,pou.record.table_offset))
     assert found and len({v[0] for v in found})==1;changed.append(found[0][0]);binding_proof.append(dict(source_offset=g['offset']+t.offset,name_hex=name.hex(),input_hex=t.raw.hex(),output_hex=found[0][0].hex(),candidates=[dict(component_offset=v[1],pou_offset=v[2]) for v in found]))
    rebuilt=b''.join(changed);rebuilt_groups.append(rebuilt)
    if g['labels']:
     assert tokens[0].raw[1]<0x80;req.append(dict(mode='check-instruction',ordinal=ordinal,input_base64=base64.b64encode(rebuilt).decode()))
   sub=out/f'{caseid}-{c["compile_id"]}';sub.mkdir();(sub/'device-context.bin').write_bytes(ctx);(sub/'requests.json').write_text(json.dumps(dict(cpu=209,versions=[1],device_context_sha256=sha256(ctx),source_sha256=sha256(source),source_stream_sha256=sha256(orig),compiler_table_sha256=sha256(table_raw),requests=req,bindings=binding_proof),indent=2),encoding='utf-8');protocol=''.join(f"check-instruction\t{i}\t{r['input_base64']}\n" for i,r in enumerate(req));run=subprocess.run([str(helper),'D:/GXWORKS2/Easysocket/CodeGenerator/ECCodeGenerator2.dll','209','1','q','1',str(sub/'device-context.bin')],input=protocol.encode('ascii'),capture_output=True,timeout=45,creationflags=subprocess.CREATE_NO_WINDOW);(sub/'stdout.jsonl').write_bytes(run.stdout);(sub/'stderr.bin').write_bytes(run.stderr);ans=[json.loads(l) for l in run.stdout.splitlines()];assert run.returncode==0 and len(ans)==len(req)
   for r,a in zip(req,ans):assert a['return_code']=='0x00000000';rebuilt_groups[r['ordinal']]=base64.b64decode(a['output_base64'])
   predicted=b''.join(rebuilt_groups);(sub/'predicted-pcode.bin').write_bytes(predicted);matches=[p.name for p in (d/'untraced').glob('pcode-*-0.bin') if p.read_bytes()==predicted];row=dict(case=caseid,compile_id=c['compile_id'],source_program=poun,groups=len(groups),bindings=len(binding_proof),normalized_groups=len(req),preserved_groups=len(groups)-len(req),predicted_sha256=sha256(predicted),exact_native_matches=matches);results.append(row);(sub/'comparison.json').write_text(json.dumps(row,indent=2),encoding='utf-8');print(json.dumps(row))
(out/'comparison.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
