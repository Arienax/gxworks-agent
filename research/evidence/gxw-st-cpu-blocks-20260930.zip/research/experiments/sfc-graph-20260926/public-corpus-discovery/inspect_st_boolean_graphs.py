"""Audit saved native BOOL node observations without recompiling projects.

Node records remain raw 73-byte observations. Only three integer accessors and
the bounded measured index predicate are interpreted; no complete AST claim.
"""
from pathlib import Path
import hashlib,json,struct,sys
P=Path(__file__).resolve().parent
ROOT=P.parents[3]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research'),str(P)]
from witness_st_conditional_transfers import decode,evaluate
from probe_minimal_conditional_port_writes import streams,save
from source_q_direct_declarations import DirectDeclarations
from gxw.project_metadata import read_project_text_context

LITERAL_TYPES={38,42,69,72,75,101,104,107}
EXPECTED_FALSE={'BOOL-recursive-left-stable-capture','BOOL-XOR-NOT-scalar','BOOL-XOR-right-NOT','BOOL-XOR-comparison-index','BOOL-XOR-dynamic-store-B2','BOOL-right-tree-AND-OR-B3'}


def gate_from_graph(graph,types):
    rows={r['id']:r for r in graph['rows'] if r['status']=='observed'}
    def predicate(id,seen):
        if id in seen or id not in rows:return None
        seen=seen|{id};r=rows[id];left,right,_=r['words_at_0c_10_14'];kind=r['kind_at_04']
        if left==right==0:return 1
        if kind in (0x164,0x165,0x166,0x16c):return 0
        if kind==0x168:
            a=predicate(left,seen)
            return 0 if a==0 else None if a is None else predicate(right,seen)
        if kind!=0x5b:return None
        visited=set()
        while right:
            if right in visited or right not in rows:return None
            visited.add(right);child=rows[right]
            if child['kind_at_04']==0x2e:return None
            leaf=child['words_at_0c_10_14'][0] if child['kind_at_04']==0x2c else right
            if leaf not in types or leaf not in rows:return None
            raw=bytes.fromhex(rows[leaf]['opaque_record'])
            if types[leaf] not in LITERAL_TYPES or struct.unpack_from('<I',raw,0x30)[0]:return 0
            right=child['words_at_0c_10_14'][1]
        return 1
    return predicate(graph['root'],set())


def main():
    groups=sys.argv[1:];assert groups
    cases=[]
    for group in groups:
        directory=P/group
        listings={r['case']:r['records'] for r in json.loads((directory/'native-listings.json').read_text())}
        for comparison in json.loads((directory/'comparison.json').read_text()):
            case=directory/comparison['case'];native=Path(comparison['native_directory'])
            source=(case/'input.gxw').read_bytes();before=json.loads((case/'before-native.json').read_text())
            assert hashlib.sha256(source).hexdigest()==before['input_sha256']
            messages=[json.loads(s) for s in (native/'events.jsonl').read_text().splitlines()]
            assert not any(e.get('type')=='error' for e in messages)
            events=[e['payload'] for e in messages if e.get('type')=='send']
            types={};nodes=0;kinds={};gate_count=0;unresolved_gates=0;leaf_count=0;dispatches=0;materializations=[]
            for e in events:
                for graph in [e['graph']] if 'graph' in e else []:
                    assert not graph['truncated']
                    for row in graph['rows']:
                        assert row['status']=='observed',row
                        raw=bytes.fromhex(row['opaque_record']);assert len(raw)==73
                        assert struct.unpack_from('<I',raw,4)[0]==row['kind_at_04']
                        assert list(struct.unpack_from('<III',raw,12))==row['words_at_0c_10_14']
                        nodes+=1;kind=hex(row['kind_at_04']);kinds[kind]=kinds.get(kind,0)+1
                if e['event']=='index-leaf-type':types[e['id']]=e['result']
                elif e['event']=='index-leaf-predicate':
                    raw=bytes.fromhex(e['record']['opaque_record'])
                    assert e['id'] in types
                    predicted=int(types[e['id']] in LITERAL_TYPES and struct.unpack_from('<I',raw,0x30)[0]==0)
                    assert predicted==e['result'];leaf_count+=1
                elif e['event']=='bool-materialization-gate':
                    predicted=gate_from_graph(e['graph'],types)
                    if predicted is None:unresolved_gates+=1
                    else:assert predicted==e['result'],(comparison['case'],e,predicted);gate_count+=1
                elif e['event']=='bool-operand-dispatch':
                    assert e['implementation']==dict(module='ECCompiler_IEC.dll',rva='0xcb330')
                    dispatches+=1
                elif e['event']=='bool-materialization-call':
                    materializations.append(dict(caller=e['caller'],arguments=e['words'],root=e['graph']['root']))
            code=(native/'pcode-0-0.bin').read_bytes()
            row=dict(group=group,case=comparison['case'],native_check=comparison['check'],
                source_prediction_before_native=before['prediction'].get('unsupported','prepared'),
                byte_prediction_before_native=comparison['predicted_equal'],
                raw_node_observations_verified=nodes,node_kind_observations=kinds,
                measured_index_leaf_predicates_verified=leaf_count,
                bounded_gate_predictions_verified=gate_count,unresolved_gate_predictions=unresolved_gates,
                virtual_dispatches_verified=dispatches,materialization_calls=materializations)
            if code:
                records=decode(code)
                assert [{k:v for k,v in r.items() if k not in ('offset','raw')} for r in records]==listings[comparison['case']]
                row['independent_lexical_equal']=True
                content={k:v for k,v in streams(source).items() if k!='CGTable.dat'}
                context=read_project_text_context(next(v for k,v in content.items() if k.endswith('.prj')))
                declarations=DirectDeclarations(content,context['text_encoding'],local_fb_definitions=('SCPI',),allow_string_arrays=True)
                declarations.add_owner('MAIN');a=declarations.bound['MAIN']['prober0']
                binding=dict(address=a['family']+str(a['number']),type=a['row'].data_type)
                witness=evaluate(records,{'result':binding},allow_boolean=True)
                expected=123 if a['row'].data_type=='INT' else comparison['case'] not in EXPECTED_FALSE
                assert witness['observations']['result']==expected
                row['finite_initialized_witness']=dict(binding=binding,**witness)
            cases.append(row)
    result=dict(groups=groups,cases=cases,
        raw_node_observations_verified=sum(c['raw_node_observations_verified'] for c in cases),
        measured_index_leaf_predicates_verified=sum(c['measured_index_leaf_predicates_verified'] for c in cases),
        bounded_gate_predictions_verified=sum(c['bounded_gate_predictions_verified'] for c in cases),
        unresolved_gate_predictions=sum(c['unresolved_gate_predictions'] for c in cases),
        virtual_dispatches_verified=sum(c['virtual_dispatches_verified'] for c in cases),
        scope='Read-only native 73-byte node observations with opaque bytes preserved in event traces. Known accessors read kind+4, left+0x0c and right+0x10. Partial gate prediction is checked against native return values; unsupported branches are counted. Finite initialized offline logic witnesses are not PLC execution or complete AST semantics.')
    save(P/groups[-1]/'boolean-graph-analysis.json',result)
    (P/groups[-1]/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    print(json.dumps({k:v for k,v in result.items() if k not in ('groups','cases','scope')}))


if __name__=='__main__':main()
