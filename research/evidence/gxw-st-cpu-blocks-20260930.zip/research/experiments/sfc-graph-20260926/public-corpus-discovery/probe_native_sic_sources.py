"""Capture native compiler input text for graph, ST and simple-ladder controls."""
from pathlib import Path
import json,struct,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from replay_gxw_workspace import prepare,trace_prepared
P=Path(__file__).resolve().parent
out=P/'native-sic-source-controls';out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
plans=[('graph-function','structured-graph-location-controls/function'),
       ('graph-parallel','structured-graph-location-controls/parallel'),
       ('graph-multi-network','structured-graph-location-controls/multi_network'),
       ('graph-TOF','graph-library-call-controls/TOF'),
       ('st-nested','ST-nested-FB-controls/single'),
       ('q-global-call','q-global-fb-calls/valid-global-call')]
rows=[]
for case,relative in plans:
    baseline=P/relative/'native';source=baseline/'native-saved.gxw';target=out/case
    prepare(source,target,compile=True,export_project=True,project_alias='SICOBSERVATION')
    process=trace_prepared(target,P/'TraceCompilerInputs.js')
    events=[json.loads(s) for s in (target/'events.jsonl').read_text().splitlines()]
    native=[json.loads(s) for s in (target/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    compiles=[e['payload'] for e in events if e.get('payload',{}).get('name')=='Compile' and e['payload'].get('event')=='enter']
    fragments=[]
    for ci,e in enumerate(compiles):
        buffers={b['label']:b for b in e['buffers']}
        descriptors=bytes.fromhex(buffers['compile_descriptors']['bytes'])
        assert len(descriptors)%28==0
        for index in range(len(descriptors)//28):
            d=descriptors[index*28:(index+1)*28]
            body=bytes.fromhex(buffers['source_'+str(index)]['bytes'] or '')
            name=bytes.fromhex(buffers['name_'+str(index)]['bytes'] or '').split(b'\0')[0]
            assert len(body)==struct.unpack_from('<I',d)[0]
            filename=f'compile-{ci:03d}-{index:02d}.sic'
            (target/filename).write_bytes(body)
            fragments.append(dict(call=ci,index=index,name_hex=name.hex(),name_ascii=name.decode('ascii',errors='backslashreplace'),
                descriptor_kind=struct.unpack_from('<i',d,12)[0],descriptor_tail_hex=d[16:].hex(),
                bytes=len(body),sha256=sha256(body),file=filename,
                text_ascii=body.decode('ascii',errors='backslashreplace'),
                symbolic_data_sha256=sha256(bytes.fromhex(buffers['symbolic_data']['bytes'] or ''))))
    outputs={p.name:sha256(p.read_bytes()) for p in target.glob('pcode-*.bin')}
    expected={p.name:sha256(p.read_bytes()) for p in baseline.glob('pcode-*.bin')}
    row=dict(case=case,baseline=str(baseline.relative_to(P)),input_sha256=sha256(source.read_bytes()),process=process,
        trace_errors=[e for e in events if e.get('type')=='error'],
        crt_checks=[e for e in native if e['operation']=='NativeCrtCharacterCase'],
        compile_completed=any(e['operation']=='Progress' and e.get('percent')==100 for e in native),
        diagnostics=[r for e in native for r in e.get('reports',[]) if r['kind'] in (2,3)],
        outputs=outputs,baseline_outputs=expected,baseline_pcode_exact=outputs==expected,fragments=fragments)
    rows.append(row);(target/'comparison.json').write_text(json.dumps(row,indent=2))
    (out/'comparison.json').write_text(json.dumps(dict(cases=rows),indent=2))
    print(json.dumps(dict(case=case,process=process,compile_completed=row['compile_completed'],
        baseline_pcode_exact=row['baseline_pcode_exact'],fragments=[dict(name=f['name_ascii'],kind=f['descriptor_kind'],bytes=f['bytes'],file=f['file']) for f in fragments if f['bytes']])),flush=True)
