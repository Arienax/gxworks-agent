"""Separate local/global/constant/array label resolution in FB inputs."""
from pathlib import Path
import base64,json,struct,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.declarations import parse_declarations,edit_declarations,serialize_declarations
from probe_gxw_simple_fb import frame_source,observe_calls
from probe_gxw_parameters import device_allocation_record
from probe_gxw_sfc_graph import patch_raw
from native_gxw_tokens import native_batch,Q_DLL
from replay_gxw_workspace import run
P=Path(__file__).resolve().parent
out=P/'scpi-label-inputs';out.mkdir(exist_ok=False)
source=(P/'scpi-instance-binding-controls/same-instance/native/native-saved.gxw').read_bytes()
streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
name='MAIN.Program.pou';frame=frame_source(streams[name]);call=observe_calls(frame)['calls'][0]
plans=[
 dict(case='local-auto',table='MAIN.Labels.lh',value="'InputValue",rows=[dict(name='InputValue',data_type='INT')]),
 dict(case='global-address',table='Global1.gh',value="'InputValue",rows=[dict(name='InputValue',data_type='INT',device='D200',iec_address='%MW0.200')]),
 dict(case='global-constant',table='Global1.gh',value="'InputValue",rows=[dict(name='InputValue',data_type='INT',class_name='VAR_GLOBAL_CONSTANT',initial_value='123')]),
 dict(case='local-array-static',table='MAIN.Labels.lh',value="'InputWords[1]",rows=[dict(name='InputWords',data_type='ARRAY [-2..2] OF INT')]),
 dict(case='global-array-static',table='Global1.gh',value="'InputWords[1]",rows=[dict(name='InputWords',data_type='ARRAY [-2..2] OF INT',device='D200',iec_address='%MW0.200')]),
 dict(case='local-array-dynamic',table='MAIN.Labels.lh',value="'InputWords[InputIndex]",rows=[dict(name='InputWords',data_type='ARRAY [-2..2] OF INT'),dict(name='InputIndex',data_type='INT')]),
]
requests=[]
for plan in plans:
 text=f"LD X1F\0OUT '_iEn\0LD '_TRUE\0MOV {plan['value']} '_iUnitNo"
 requests.append(dict(mode='encode',text=text,input_base64=base64.b64encode(text.encode()+b'\0\0').decode()))
answers=native_batch(requests,out/'native-encode',dll=Q_DLL,cpu_code=209,native_versions=(25,),device_context=device_allocation_record(streams['Param.wpa']).raw)
for plan,answer in zip(plans,answers):
 directory=out/plan['case'];directory.mkdir()
 if answer['return_code']!='0x00000000':
  (directory/'comparison.json').write_text(json.dumps(dict(plan,encode_failure=answer),indent=2));continue
 span=call['input_fragment'];a,b=span['offset'],span['offset']+span['length']
 replacement=base64.b64decode(answer['output_base64']);program=bytearray(frame.raw[:a]+replacement+frame.raw[b:])
 delta=len(program)-len(frame.raw)
 for offset in [55,59]:struct.pack_into('<I',program,offset,struct.unpack_from('<I',frame.raw,offset)[0]+delta)
 changed,receipt=patch_raw(source,name,frame.raw,bytes(program));receipts=[receipt]
 labels=plan['table'];document=parse_declarations(streams[labels],logical_name=labels)
 new=serialize_declarations(edit_declarations(document,upserts=plan['rows']))
 changed,receipt=patch_raw(changed,labels,streams[labels],new);receipts.append(receipt)
 after={s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}
 assert all(after[k]==v for k,v in streams.items() if k not in [name,labels])
 path=directory/'changed.gxw';path.write_bytes(changed)
 (directory/'mutation.json').write_text(json.dumps(dict(plan,source_sha256=sha256(source),changed_sha256=sha256(changed),replacement_base64=base64.b64encode(replacement).decode(),receipts=receipts,unrelated_payloads='byte-identical'),indent=2))
 queries=[dict(name=r['name'],keys=[dict(category=1,value=r['name'])]+([dict(category=4,value='MAIN')] if labels.startswith('MAIN') else [])) for r in plan['rows']]
 for attempt in range(1,9):
  target=directory/('native' if attempt==1 else 'native-v'+str(attempt))
  result=run(path,target,compile=True,export_project=True,project_alias='SCPILABEL',assignment_queries=queries)
  events=[json.loads(s) for s in (target/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
  if (target/'pcode-0-0.bin').exists() or not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
 row=dict(plan,native_directory=str(target.relative_to(P)),native={k:result[k] for k in ['returncode','compile_completed','compiler_rejected','diagnostics','outputs']})
 (directory/'comparison.json').write_text(json.dumps(row,indent=2))
 print(json.dumps(dict(case=plan['case'],value=plan['value'],native={k:row['native'][k] for k in ['returncode','compile_completed','compiler_rejected','diagnostics']})),flush=True)
