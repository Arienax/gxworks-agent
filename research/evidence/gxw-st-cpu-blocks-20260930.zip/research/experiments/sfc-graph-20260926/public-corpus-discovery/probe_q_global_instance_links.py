"""Observe two distinct global FB instance references through native CMP Read."""
from pathlib import Path
import base64,json,struct,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.declarations import parse_declarations,edit_declarations,serialize_declarations
from gxw.compiler_tables import parse_compiler_tables
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import run
from native_gxw_compiler import native_table_dump
P=Path(__file__).resolve().parent
out=P/'q-global-instance-links';out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
source=(P/'q-global-compile-dependencies/known-global-instance/input.gxw').read_bytes()
streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
logical='Global1.gh';doc=parse_declarations(streams[logical],logical_name=logical)
new=serialize_declarations(edit_declarations(doc,upserts=[dict(name='GlobalOther',data_type='SCPI',kind='function_block',class_name='VAR_GLOBAL')]))
changed,receipt=patch_raw(source,logical,streams[logical],new)
assert {s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}==dict(streams,**{logical:new})
path=out/'input.gxw';path.write_bytes(changed)
(out/'mutation.json').write_text(json.dumps(dict(source_sha256=sha256(source),changed_sha256=sha256(changed),receipt=receipt),indent=2),encoding='utf-8')
for attempt in range(1,9):
    native=out/('native' if attempt==1 else 'native-v'+str(attempt))
    result=run(path,native,compile=True,snapshot_frontend=True,export_project=True,project_alias='QGLOBALREFS')
    events=[json.loads(s) for s in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    if (native/'pcode-0-0.bin').exists() or not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
print(json.dumps({k:result[k] for k in ('returncode','open_succeeded','compile_completed','compiler_rejected','diagnostics')}),flush=True)
assert result['returncode']==0 and result['compile_completed'] and not result['compiler_rejected']
raw=(native/'compiler_DZComp/CGTable.dat').read_bytes();tables=parse_compiler_tables(raw)
oracle=out/'native-table-read';comparison=native_table_dump(raw,oracle,read_components=True)
references=[]
for row in [json.loads(s) for s in (oracle/'native-components.jsonl').read_text().splitlines()]:
    component=tables.component_at(row['requested_offset'])
    if tables.component_type(component)!=53:continue
    decoded=base64.b64decode(row['record_base64']);reference=struct.unpack_from('<I',decoded,0x111)[0]
    record=tables.tables[3].record_at(component.global_offset);_,fields=record.named_fields()
    references.append(dict(name=component.name_bytes.decode('ascii'),component_offset=component.record.table_offset,
        global_record_offset=record.table_offset,global_fields_hex=fields.hex(),native_reference=reference,
        field_at_8=struct.unpack_from('<I',fields,8)[0],resolved_pou=tables.pou_at(reference).name_bytes.decode('ascii')))
    assert struct.unpack_from('<I',fields,8)[0]==reference
assert len(references)==2 and len({r['native_reference'] for r in references})==2 and any(r['native_reference']>0 for r in references)
(out/'comparison.json').write_text(json.dumps(dict(native_comparison=comparison,references=references,scope=__doc__),indent=2),encoding='utf-8')
print(json.dumps(dict(references=references)),flush=True)
