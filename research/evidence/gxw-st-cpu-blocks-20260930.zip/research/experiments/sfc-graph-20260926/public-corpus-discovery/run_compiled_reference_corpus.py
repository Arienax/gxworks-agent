"""Apply the new source-to-compiled reference reading to existing native evidence."""
from collections import Counter
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from probe_gxw_compiled_references import inspect
P=Path(__file__).resolve().parent
OUT=P/'compiled-reference-real-corpus';OUT.mkdir(exist_ok=False)
rows=[]
for item in [json.loads(s) for s in (P/'native-reference-real-corpus/results.jsonl').read_text().splitlines()]:
    case=item['case']
    if case in ('two','same'):continue
    native=P/'native-reference-real-corpus'/case/'native'
    if case=='case-04':native=P/'fx1s-reference-native-idle-control/native'
    row=dict(case=case)
    try:
        result=inspect(native,OUT/case)
        row.update(handling='correlated',summary=result['summary'],
            gaps=[dict(program=p['name'],handling=p['handling'],diagnostic=p.get('diagnostic')) for p in result['programs'] if p['handling']=='opaque-preserved'])
    except (ValueError,FileNotFoundError) as exc:row.update(handling='not-correlated',diagnostic=str(exc))
    rows.append(row)
    with (OUT/'results.jsonl').open('a',encoding='utf-8') as out:out.write(json.dumps(row)+'\n')
print(json.dumps(dict(cases=len(rows),handling=Counter(r['handling'] for r in rows),
    correlated_groups=sum(r.get('summary',{}).get('correlated_groups',0) for r in rows),
    unmapped_source_groups=sum(r.get('summary',{}).get('unmapped_source_groups',0) for r in rows),
    gaps=[r for r in rows if r['handling']!='correlated' or r.get('gaps') or r.get('summary',{}).get('unmapped_source_groups')])))
