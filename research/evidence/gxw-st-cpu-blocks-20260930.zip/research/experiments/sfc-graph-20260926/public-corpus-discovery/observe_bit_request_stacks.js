// Read-only call-stack observations at the already measured slot-request entry.
// Accurate and fuzzy frames are kept separately; fuzzy frames are candidates.
// No recovered whole-function boundary or caller identity is assumed here.
Process.attachModuleObserver({
  onAdded(module) {
    if (module.name.toLowerCase() !== 'eccompiler_iec.dll') return;
    function location(address) {
      const owner = Process.findModuleByAddress(address);
      return owner ? {module: owner.name, rva: address.sub(owner.base).toString()} : {address: address.toString()};
    }
    function stack(context, kind) {
      try {
        return {status: 'observed', frames: Thread.backtrace(context, kind).slice(0, 16).map(location)};
      } catch (e) {
        return {status: 'unavailable', reason: String(e)};
      }
    }
    Interceptor.attach(module.base.add(0x6d4c0), {
      onEnter(args) {
        send({event: 'bit-request-stack', type: args[0].toInt32(),
          address: [args[1].toInt32(), args[2].toInt32()], count: args[3].toInt32(),
          caller: location(this.returnAddress),
          accurate: stack(this.context, Backtracer.ACCURATE),
          fuzzy: stack(this.context, Backtracer.FUZZY)});
      }
    });
    Interceptor.attach(module.base.add(0x7fc30), {
      onEnter(args) {
        const caller = location(this.returnAddress);
        if (caller.module !== module.name || !['0x8a8bd', '0xdb231', '0xdb260', '0xdb371'].includes(caller.rva)) return;
        this.materialization = {context: this.context.ecx, id: args[0].toInt32()};
        send({event: 'bool-materialization-call', entry: '0x7fc30', caller: caller,
          words: [0, 1, 2, 3].map(i => args[i].toInt32()),
          graph: graph(this.materialization.context, this.materialization.id)});
      },
      onLeave(result) {
        if (!this.materialization) return;
        send({event: 'bool-materialization-return', result: result.toInt32(),
          graph: graph(this.materialization.context, this.materialization.id)});
      }
    });
    Interceptor.attach(module.base.add(0x99a60), {
      onEnter(args) {
        const inner = this.context.ecx.add(4).readPointer();
        const implementation = inner.readPointer().add(0x34).readPointer();
        const context = inner.add(0x14).readPointer().add(0x30).readPointer();
        send({event: 'bool-operand-dispatch', forwarder: '0x99a60',
          vtable_slot: '0x34', implementation: location(implementation),
          argument0: args[0].toInt32(), graph: graph(context, args[0].toInt32())});
      }
    });
    function node(context, id) {
      try {
        if (id < 0 || id > 0x100000) return {status: 'unavailable', reason: 'outside bounded observation index'};
        const row = context.add(0x40).readPointer().add(id * 0x49);
        const bytes = new Uint8Array(row.readByteArray(0x49));
        return {status: 'observed', id: id, kind_at_04: row.add(4).readU32(),
          words_at_0c_10_14: [12, 16, 20].map(off => row.add(off).readU32()),
          opaque_record: Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('')};
      } catch (e) {
        return {status: 'unavailable', reason: String(e)};
      }
    }
    function graph(context, root) {
      const pending = [root], seen = new Set(), rows = [];
      while (pending.length && seen.size < 64) {
        const id = pending.pop();
        if (id <= 0 || seen.has(id)) continue;
        seen.add(id);
        const record = node(context, id);
        rows.push(record);
        if (record.status === 'observed') pending.push(...record.words_at_0c_10_14.slice(0, 2));
      }
      return {root: root, rows: rows, truncated: pending.length > 0,
        scope: 'Bounded traversal of offsets 0x0c and 0x10 read by native node accessors; other bytes remain opaque.'};
    }
    const gateCallers = new Set(['0x8a827', '0x8a858', '0x8a868', '0x8a88f', '0xdb1f1', '0xdb2b3', '0xdb31f']);
    Interceptor.attach(module.base.add(0x789b0), {
      onEnter(args) {
        const caller = location(this.returnAddress);
        if (caller.module !== module.name || !gateCallers.has(caller.rva)) return;
        this.gate = {event: 'bool-materialization-gate', caller: caller,
          context: this.context.ecx, id: args[0].toInt32()};
        this.gate.before = node(this.gate.context, this.gate.id);
        this.gate.graph = graph(this.gate.context, this.gate.id);
      },
      onLeave(result) {
        if (!this.gate) return;
        const g = this.gate;
        send({event: g.event, caller: g.caller, id: g.id, result: result.toInt32(),
          before: g.before, after: node(g.context, g.id), graph: g.graph});
      }
    });
    Interceptor.attach(module.base.add(0x763f0), {
      onEnter(args) {
        const caller = location(this.returnAddress);
        if (caller.module !== module.name || !['0x78a84', '0x78ae4', '0x78af7', '0x78b08'].includes(caller.rva)) return;
        this.literalIndex = {caller: caller, id: args[0].toInt32(), argument1: args[1].toInt32(),
          record: node(this.context.ecx, args[0].toInt32())};
      },
      onLeave(result) {
        if (this.literalIndex) send({event: 'index-leaf-predicate', ...this.literalIndex, result: result.toInt32()});
      }
    });
    Interceptor.attach(module.base.add(0x71190), {
      onEnter(args) {
        const caller = location(this.returnAddress);
        if (caller.module === module.name && caller.rva === '0x76405') this.leafId = args[0].toInt32();
      },
      onLeave(result) {
        if (this.leafId !== undefined) send({event: 'index-leaf-type', id: this.leafId, result: result.toInt32()});
      }
    });
    send({event: 'bit-request-stack-observer-installed', module: module.name, rva: '0x6d4c0'});
  }
});
