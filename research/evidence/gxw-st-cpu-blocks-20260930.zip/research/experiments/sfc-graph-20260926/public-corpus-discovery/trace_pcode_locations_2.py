import json
from pathlib import Path
import sys
import threading
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'research/experiments/re-tools')]
import frida
from replay_gxw_workspace import prepare
P=Path(__file__).resolve().parent
out=P/'native-pcode-location-trace-2'
queries=[dict(resource='MAIN',start_step=i,step_count=1,timestamp=0) for i in range(16)]
exe=prepare(P/'scpi-two-callers/native/native-saved.gxw',out,compile=True,export_project=True,
    project_alias='LOCATIONS',pcode_location_queries=queries)
device=frida.get_local_device();pid=device.spawn([str(exe),str(out/'plan.json')],cwd=str(out),stdio='pipe')
session=device.attach(pid);finished=threading.Event();session.on('detached',lambda *args:finished.set())
with (out/'trace.jsonl').open('w',encoding='utf-8') as log:
    script=session.create_script((P/'TracePCodeLocation.js').read_text(encoding='utf-8'))
    def message(msg,data):log.write(json.dumps(msg)+'\n');log.flush()
    script.on('message',message);script.load();device.resume(pid)
    if not finished.wait(50):device.kill(pid);raise TimeoutError('owned helper exceeded bound')
print(str(out))
