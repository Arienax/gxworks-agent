"""Controlled ST probes on Noeul projects, not independent real ST lineage.

All hypotheses and all inputs are saved before any native compile in this run.
Unchanged logical payloads are asserted byte-identical before native processing.
"""
from pathlib import Path
import base64,json,struct,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from gxw.declarations import parse_declarations,edit_declarations,serialize_declarations
from gxw.project_metadata import mark_observed_source_compile_pending
from probe_gxw_task_graph import inspect_task_graph
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_program_check_resources import SCRIPT
from probe_minimal_conditional_port_writes import streams,save,observe
from native_gxw_tokens import native_batch,native_il_records,Q_DLL
from model_q_st_program_lifetimes import predict
from probe_gxw_simple_fb import frame_source
from probe_minimal_conditional_port_writes import splice
P=Path(__file__).resolve().parent


def st_source(raw,text):
    encoded=(text+'\0').encode('utf-16le')
    new=bytearray(raw[:54]+b'\xc1'+bytes(8)+struct.pack('<II',1,len(encoded)//2)+encoded+bytes(28))
    struct.pack_into('<II',new,55,len(new)-83,len(new)-83)
    return bytes(new)


def wstring(value):
    raw=(value+'\0').encode('utf-16le');return struct.pack('<I',len(raw)//2)+raw


def main():
    config=json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
    out=P/config['directory'];out.mkdir(exist_ok=False);save(out/'experiment-plan.json',config)
    for name in (Path(__file__).name,'model_q_st_program_lifetimes.py','source_q_direct_declarations.py','source_q_st_expressions.py','source_q_label_binding.py','source_q_width.py','observe_expression_temporaries.js'):
        (out/name).write_bytes((P/name).read_bytes())
    trace=out/'trace.js';trace.write_text('(()=>{'+(P/'native-allocation-bitmap-v2/observer.js').read_text()+'\n'+(P/'observe_expression_temporaries.js').read_text()+'\n})();\n(()=>{'+SCRIPT+'\n})();',encoding='utf-8')
    ready=[]
    for plan in config['cases']:
        case=plan['case'];d=out/case;d.mkdir()
        original=(P/f'native-allocation-inventory/case-{plan["seed"]:02}/input.gxw').read_bytes()
        before=streams(original);graph=inspect_task_graph(original);changes={}
        resources=sorted(graph['resources'],key=lambda r:r['resource'])
        if plan.get('join'):
            assert len(resources)==1
            task=resources[0]['task'];old=before[task];names=sorted(graph['programs'])
            if plan.get('reverse'):names.reverse()
            changes[task]=old[:84]+struct.pack('<I',len(names))+b''.join(wstring(n)+struct.pack('<I',i+1)+wstring('') for i,n in enumerate(names))
        else:names=[graph['tasks'][r['task']]['entries'][0]['program_reference'] for i,r in enumerate(resources) if i in plan.get('st_resource_indices',range(len(resources)))]
        texts={}
        if plan.get('minimal_first_ladder'):
            name=graph['tasks'][resources[0]['task']]['entries'][0]['program_reference']+'.Program.pou'
            frame=frame_source(before[name])
            body=bytes.fromhex('0300030591900105054c03000504e8010408df53544154450804340204')
            changes[name]=mark_observed_source_compile_pending(splice(frame.raw,frame.body_offset,frame.body_end,body),logical_name=name)
        for i,name in enumerate(names):
            logical=name+'.Labels.lh';doc=parse_declarations(before[logical],logical_name=logical)
            doc=edit_declarations(doc,upserts=[dict(name=n,data_type='INT') for n in ('probeA','probeB','probeC','probeD','probeResult')])
            changes[logical]=mark_observed_source_compile_pending(serialize_declarations(doc),logical_name=logical)
            k=plan.get('constant',1)+i*10
            expression=plan.get('expression','(probeA + probeB) - (probeC + probeD)')
            text='\r\n'.join([f'{n} := {k+j};' for j,n in enumerate(('probeA','probeB','probeC','probeD'))]+[f'probeResult := {expression};'])+'\r\n'
            logical=name+'.Program.pou';texts[name]=text
            changes[logical]=mark_observed_source_compile_pending(st_source(before[logical],text),logical_name=logical)
        source=original;receipts=[]
        for name,raw in changes.items():source,receipt=patch_raw(source,name,before[name],raw);receipts.append(receipt)
        assert streams(source)==dict(before,**changes)
        path=d/'input.gxw';path.write_bytes(source);hypotheses=[]
        for stage in ('program','resource','project'):
            for scope in ('program','resource','project'):
                outputs,model=predict(source,stage,scope);h=stage+'-'+scope
                for i,r in enumerate(outputs):(d/f'predicted-{h}-{i}.bin').write_bytes(r['output'])
                hypotheses.append(dict(key=h,model=model,outputs=[dict(resource=r['resource'],programs=r['programs'],sha256=sha256(r['output']),bytes=len(r['output'])) for r in outputs]))
        save(d/'before-native.json',dict(case=case,source_sha256=sha256(original),input_sha256=sha256(source),source_texts=texts,
            changed_streams=list(changes),unchanged_streams={n:sha256(raw) for n,raw in before.items() if n not in changes},receipts=receipts,hypotheses=hypotheses,
            provenance='Noeul ladder project, unchanged baseline or controlled source replacements as specified in experiment plan; not an independent real ST source lineage.'))
        ready.append((case,d,path,hypotheses))
    rows=[];requests=[];keys=[]
    for case,d,path,hypotheses in ready:
        native,checked,process=observe(path,d,trace)
        matches={h['key']:[] for h in hypotheses};generated=[]
        for g in checked['generated']:
            code=(native/f'pcode-{g["index"]}-0.bin').read_bytes();generated.append(dict(name=g['name'],index=g['index'],bytes=len(code),sha256=sha256(code)))
            for h in hypotheses:matches[h['key']].append(code==(d/f'predicted-{h["key"]}-{g["index"]}.bin').read_bytes())
            if code:requests.append(dict(mode='decode',input_base64=base64.b64encode(code+b'\0').decode()));keys.append((case,g['name']))
        row=dict(case=case,native_directory=str(native),check=checked['check'],diagnostics=checked['diagnostics'],last_event=checked['last_event'],
            generated=generated,hypothesis_matches=matches,process=process)
        if checked['exported_sha256']:
            reopen=d/'reopen';reopen.mkdir();n,r,p=observe(native/'native-saved.gxw',reopen,trace)
            row['reopen']=dict(native_directory=str(n),check=r['check'],diagnostics=r['diagnostics'],same_codes=all((n/f'pcode-{g["index"]}-0.bin').read_bytes()==(native/f'pcode-{g["index"]}-0.bin').read_bytes() for g in checked['generated']))
        rows.append(row);save(out/'comparison.json',rows)
        print(json.dumps(dict(case=case,check=row['check'],diagnostics=row['diagnostics'],matches=matches,reopen=row.get('reopen'))),flush=True)
    answers=native_batch(requests,out/'native-decode',dll=Q_DLL,cpu_code=209,native_versions=(25,))
    listings=[]
    for key,request,answer in zip(keys,requests,answers,strict=True):
        assert answer['return_code']=='0x00000000' and answer['consumed_bytes']==len(base64.b64decode(request['input_base64']))-1
        listings.append(dict(case=key[0],resource=key[1],records=native_il_records(base64.b64decode(answer['output_base64']),encoding='cp949')))
    save(out/'native-listings.json',listings)
    from verify_temporary_check_correspondence import verify
    save(out/'current-check-export-correspondence.json',verify([out.name]))


if __name__=='__main__':main()
