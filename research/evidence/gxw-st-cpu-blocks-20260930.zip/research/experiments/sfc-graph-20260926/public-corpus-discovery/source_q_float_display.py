"""Source-only model of the pinned Q converter's binary32 display functions."""
from decimal import Decimal, ROUND_HALF_UP, localcontext
import math
import struct


def q_float_display(raw):
    if len(raw)!=7 or raw[0]!=7 or raw[-1]!=7 or raw[1] not in (0xec,0xed):
        raise ValueError('outside observed Q binary32 operand')
    bits=int.from_bytes(raw[2:6],'little');value=struct.unpack('<f',raw[2:6])[0]
    if not math.isfinite(value):raise ValueError('non-finite Q float')
    if value==0:
        if raw[1]==0xed:return 'E0.0'
        if bits:raise ValueError('Q decimal negative zero rejected')
        return 'E0'
    with localcontext() as ctx:
        ctx.prec=100
        exact=Decimal.from_float(value)
        rounded=exact.quantize(Decimal(1).scaleb(exact.adjusted()-6),rounding=ROUND_HALF_UP)
        exponent=rounded.adjusted()
        if raw[1]==0xec:
            if not -10<=exponent<=11:raise ValueError('Q decimal exponent outside -10..11')
            if exponent < -4:
                displayed=exact.quantize(Decimal('0.0000000001'),rounding=ROUND_HALF_UP)
                if not displayed:displayed=Decimal('-0.0000000001' if value<0 else '0.0000000001')
                return 'E'+format(displayed,'f').rstrip('0').rstrip('.')
            return 'E'+format(rounded.normalize(),'f')
        mantissa=format(rounded.scaleb(-exponent),'f').rstrip('0').rstrip('.')
        if '.' not in mantissa:mantissa+='.0'
        return 'E'+mantissa+(format(exponent,'+d') if exponent else '')
