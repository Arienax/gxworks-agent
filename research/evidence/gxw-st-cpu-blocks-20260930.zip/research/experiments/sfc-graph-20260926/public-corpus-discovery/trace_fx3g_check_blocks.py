"""Read-only native checker trace; only a newly spawned owned helper is attached."""
from pathlib import Path
import hashlib
import argparse
import json
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'research')]
from replay_gxw_workspace import prepare, trace_prepared

P = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('input', type=Path)
parser.add_argument('output', type=Path)
args = parser.parse_args()
OUT = args.output.resolve()
OUT.mkdir(exist_ok=False)
DLL = Path('D:/GXWORKS2/Easysocket/Compiler/ECCompiler_IEC.dll')
assert hashlib.sha256(DLL.read_bytes()).hexdigest() == 'f58e7c70b855526bf2f943399a14089f771a43109b13ee9af34c88fb065cf4d7'
SCRIPT = r'''
const attached = new Set();
function hex(p, n) {
  if (n < 0 || n > 32768) return null;
  return Array.from(new Uint8Array(p.readByteArray(n)), b => b.toString(16).padStart(2, '0')).join('');
}
function location(p) {
  const m = Process.findModuleByAddress(p);
  return m ? {module: m.name, rva: p.sub(m.base).toString()} : {address: p.toString()};
}
Process.attachModuleObserver({
  onAdded(m) {
    if (m.name.toLowerCase() !== 'eccompiler_iec.dll' || attached.has(m.base.toString())) return;
    attached.add(m.base.toString());
    send({event: 'attached', module: m.path, base: m.base.toString()});
    for (const rva of [0x3b630, 0x3caf0]) {
      Interceptor.attach(m.base.add(rva), {
        onEnter(a) {
          try {
            this.len = a[0]; this.step = a[2];
            const n = this.len.readS32();
            const backend = this.context.ecx.add(0x14).readPointer();
            this.row = {event: 'block-check', rva: '0x' + rva.toString(16),
              before_length: n, before_step: this.step.readS32(), argument_4: a[3].toInt32(),
              target: location(backend.readPointer().add(0x24).readPointer()),
              raw_hex: hex(a[1], n)};
          } catch (e) {send({event: 'observation-error', error: String(e)});}
        },
        onLeave(r) {
          if (!this.row || r.toInt32() === 0) return;
          try {
            send(Object.assign(this.row, {error: r.toString(),
              after_length: this.len.readS32(), after_step: this.step.readS32()}));
          } catch (e) {send({event: 'observation-error', error: String(e)});}
        }
      });
    }
    Interceptor.attach(m.base.add(0x3a3c0), {
      onEnter(a) {
        const error = a[0].toUInt32();
        if (error !== 0x050c9521 && error !== 0x050c9322) return;
        send({event: 'report-error', error: '0x' + error.toString(16),
          step: a[2].toInt32(), caller: location(this.returnAddress)});
      }
    });
  }
});

Process.attachModuleObserver({onAdded(m) {
  if (m.name.toLowerCase() !== 'eccodegeneratorfx2.dll') return;
  Interceptor.attach(m.findExportByName('ChangePToLDcode'), {
    onEnter(a) {
      try {
        this.length = a[1]; this.rows = a[3]; this.descriptor = a[4];
        const n = this.length.readS32();
        this.row = {event: 'pcode-to-ld', before_length: n, raw_hex: hex(a[2], n),
          before_rows: this.rows.readS32(), capacity: a[5].toInt32(), mode: a[6].toInt32(),
          descriptor_before: hex(this.descriptor, 11),
          descriptor_metadata: [0, 1, 6].map(o => this.descriptor.add(o).readU8())};
      } catch (e) {send({event: 'observation-error', error: String(e)});}
    },
    onLeave(r) {
      if (!this.row || r.toInt32() === 0) return;
      try {send(Object.assign(this.row, {error: r.toString(), after_length: this.length.readS32(),
        after_rows: this.rows.readS32(), descriptor_after: hex(this.descriptor, 11),
        error_offset: m.base.add(0x921a4).readS32()}));}
      catch (e) {send({event: 'observation-error', error: String(e)});}
    }
  });
  Interceptor.attach(m.base.add(0x3aed0), {
    onEnter(a) {
      try {
        const n = a[0].toUInt32() & 0xffff;
        this.row = {event: 'ladder-core', before_length: n, raw_hex: hex(a[1], n),
          limit: a[2].toInt32(), descriptor: hex(a[4], 12), capacity: a[5].toInt32(), mode: a[7].toInt32()};
      } catch (e) {send({event: 'observation-error', error: String(e)});}
    },
    onLeave(r) {const code = (r.toInt32() << 16) >> 16;
      if (this.row && code < 0) send(Object.assign(this.row, {result: code}));
    }
  });
}});

'''
script = OUT / 'trace.js'
script.write_text(SCRIPT, encoding='utf-8')
(OUT / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
for attempt in range(1, 5):
    native = OUT / f'native-{attempt}'
    prepare(args.input.resolve(), native,
            compile=True, export_project=True, program_check=True,
            project_alias='CHECKBLOCK')
    trace = trace_prepared(native, script)
    events = [json.loads(line) for line in (native / 'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    if not any(e.get('operation') == 'NativeTemporaryDirectoryCollision' for e in events):
        break
messages = [json.loads(line) for line in (native / 'events.jsonl').read_text(encoding='utf-8').splitlines()]
payloads = [r['payload'] for r in messages if r.get('type') == 'send']
summary = dict(trace=trace, trace_errors=[r for r in messages if r.get('type') == 'error'],
               payloads=payloads, last_event=events[-1],
               pcode_sha256=hashlib.sha256((native / 'pcode-0-0.bin').read_bytes()).hexdigest(),
               program_check_completed=any(e.get('operation')=='ProgramCheckCompleted' for e in events))
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
compact = [{k: v for k, v in row.items() if k != 'raw_hex'} for row in payloads]
print(json.dumps(dict(trace=trace, trace_errors=summary['trace_errors'], payloads=compact,
                     last_event=events[-1], pcode_sha256=summary['pcode_sha256']), ensure_ascii=True))

if not summary['program_check_completed'] or summary['trace_errors']:
    raise RuntimeError('Trace incomplete or instrument error; retained')
