"""Replay source text against the independently captured native frontend.

Redistributable controls contain only generated ST snippets, not public third
party programs or complete project containers. Real-project comparisons stay
local with source hashes. Compiler success is not a source-text validation.
"""
from pathlib import Path
import base64
import json
import struct
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'research')]
from gxw.lossless import inspect_project, inspect_program, sha256
from gxw.text_pou import parse_st_pou
from gxw_corpus import project_token_context
from probe_gxw_st_sources import snapshot_body

P = Path(__file__).resolve().parent
B = ROOT / 'research/experiments/structured-compiler-20260920'
OUT = P / 'st-text-source-crosscheck-v2'


def main():
    OUT.mkdir(exist_ok=False)
    (OUT / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    paths = [(path, False) for root in ('st-source-probe-1', 'st-source-probe-2')
        for path in (B / root).glob('*/native')]
    paths += [(path, False) for root in ('st-text-preservation', 'st-nul-suffix-control')
        for path in (P / root).glob('*/compile-*')]
    paths.append((P / 'boxid-parameter-init-native', True))
    rows, fixtures = [], []
    for native, real in paths:
        source = (native / 'input.gxw').read_bytes()
        image = inspect_project(source)
        context = project_token_context(image)
        request = json.loads((native / 'request.json').read_text(encoding='utf-8'))
        assert request['input_sha256'] == sha256(source)
        snapshot = json.loads((native / 'frontend-snapshot.json').read_text(encoding='utf-8'))
        for stream in image.streams:
            if not (stream.logical_name or '').endswith('.pou') or stream.raw[54] != 0xc1:
                continue
            program = parse_st_pou(stream.raw)
            body = snapshot_body(snapshot, stream.logical_name.removesuffix('.Program.pou'))
            count = struct.unpack_from('<I', body, 72)[0]
            text_bytes = body[76:76+count]
            assert len(text_bytes) == count and text_bytes[-1:] == b'\0'
            row = dict(native_directory=str(native), program=stream.logical_name,
                project_sha256=sha256(source), program_sha256=sha256(stream.raw), context=context,
                units=program.code_units, text_gap=program.diagnostic,
                native_text_bytes=len(text_bytes), raw_preserved=inspect_program(stream.raw).reconstruct() == stream.raw,
                native_text_matches=None if program.text is None else
                    program.text.encode(context['text_encoding']) + b'\0' == text_bytes)
            rows.append(row)
            if not real:
                case = dict(row, id=native.relative_to(ROOT / 'research/experiments').as_posix(),
                    program_base64=base64.b64encode(stream.raw).decode(),
                    frontend_text_base64=base64.b64encode(text_bytes).decode(),
                    native_request_sha256=sha256((native / 'request.json').read_bytes()),
                    native_snapshot_sha256=sha256((native / 'frontend-snapshot.json').read_bytes()),
                    native_binaries=request['native'])
                saved = native / 'native-saved.gxw'
                if saved.exists():
                    after = next(s.raw for s in inspect_project(saved.read_bytes()).streams if s.logical_name == stream.logical_name)
                    case.update(saved_program_base64=base64.b64encode(after).decode(),
                        saved_utf16_preserved=parse_st_pou(after).text_bytes == program.text_bytes)
                pcode = native / 'pcode-0-0.bin'
                if pcode.exists():
                    case['compiled_pcode_base64'] = base64.b64encode(pcode.read_bytes()).decode()
                fixtures.append(case)
    fixtures.sort(key=lambda r:r['id'])
    (OUT / 'comparison.json').write_text(json.dumps(rows, indent=2), encoding='utf-8')
    embedded = next(r for r in fixtures if '/embedded-nul/' in r['id'])
    clean = next(r for r in fixtures if '/without-nul/' in r['id'])
    comment = next(r for r in fixtures if '/unicode-comment/' in r['id'])
    assert embedded['compiled_pcode_base64'] == comment['compiled_pcode_base64']
    assert clean['compiled_pcode_base64'] != embedded['compiled_pcode_base64']
    destination = ROOT / 'tests/fixtures/gxw_st_text_native.json'
    assert not destination.exists()
    destination.write_text(json.dumps(dict(scope='Generated source envelopes versus offline native frontend; native acceptance does not prove that all source characters reached compilation.',
        cases=fixtures), indent=2) + '\n', encoding='utf-8')
    print(json.dumps(dict(programs=len(rows), source_text_matches=sum(r['native_text_matches'] is True for r in rows),
        text_gaps=sum(r['text_gap'] is not None for r in rows), differences=[r for r in rows if r['native_text_matches'] is False],
        raw_preserved=all(r['raw_preserved'] for r in rows), fixture_cases=len(fixtures), nul_suffix_not_compiled=True)))


if __name__ == '__main__':
    main()
