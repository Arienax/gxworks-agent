"""Keep public repository discovery separate from native format assumptions."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json
import urllib.parse
import urllib.request

P = Path(__file__).resolve().parent
OUT = P / 'cross-family-source-discovery'


def fetch(url, name):
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'GXWorks-format-research', 'Accept': 'application/vnd.github+json'})
        with urllib.request.urlopen(req, timeout=35) as response:
            payload = response.read(20 * 1024 * 1024)
        (OUT / name).write_bytes(payload)
        return json.loads(payload)
    except Exception as exc:
        result = dict(url=url, error=type(exc).__name__ + ': ' + str(exc))
        (OUT / name).write_text(json.dumps(result, indent=2), encoding='utf-8')
        return result


def main():
    OUT.mkdir(exist_ok=False)
    (OUT / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    queries = ['gxworks2', '"GX Works2"', 'L02CPU']
    with ThreadPoolExecutor(max_workers=3) as pool:
        results = list(pool.map(lambda pair: fetch('https://api.github.com/search/repositories?q=' + urllib.parse.quote(pair[1]) + '&per_page=40',
            f'search-{pair[0]}.json'), enumerate(queries)))
    repositories = {}
    for result in results:
        for item in result.get('items', []):
            repositories[item['full_name']] = dict(repository=item['full_name'], default_branch=item['default_branch'],
                description=item['description'], size=item['size'], fork=item['fork'])
    target = fetch('https://api.github.com/repos/Serhioromano/gxw2-libraries', 'libraries-repo.json')
    if 'default_branch' in target:
        repositories[target['full_name']] = dict(repository=target['full_name'], default_branch=target['default_branch'],
            description=target['description'], size=target['size'], fork=target['fork'])
    (OUT / 'repositories.json').write_text(json.dumps(list(repositories.values()), indent=2), encoding='utf-8')
    print(json.dumps(list(repositories.values()), ensure_ascii=True), flush=True)


if __name__ == '__main__':
    main()
