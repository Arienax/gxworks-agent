(()=>{
'use strict';
let installed=false,serial=0;const writers=new Set();
function str(p){try{let s='';for(let i=0;i<8192;i++){const c=p.add(i).readU8();if(c===0)return s;if(c>127)return null;s+=String.fromCharCode(c);}}catch(e){}return null;}
function locals(c){const p=c.ebp,fields={};for(const n of [0x880,0x884,0x888,0x88c,0x890,0x894,0x8a4,0x8a8,0x8ac,0x8cc])fields['minus_'+n.toString(16)]=p.sub(n).readS32();return fields;}
function install(){
 if(installed)return;
 const compiler=Process.findModuleByName('DZDataABS_Compiler_IEC.dll');if(!compiler)return;
 const base=compiler.base.add(SIC_IMPORT.iat_rva).readPointer().sub(SIC_IMPORT.target_rva);
 if(!Process.findRangeByAddress(base.add(0x50b84)))return;
 if(typeof DATA_IMPORT!=='undefined'){
  const dataBase=compiler.base.add(DATA_IMPORT.iat_rva).readPointer().sub(DATA_IMPORT.target_rva);
  Interceptor.attach(dataBase.add(0x2b4ee),{onEnter(a){send({event:'timer-parameter-input',raw_hex:Array.from(new Uint8Array(a[0].readByteArray(4)),v=>v.toString(16).padStart(2,'0')).join(''),words:[a[0].readU16(),a[0].add(2).readU16()]});}});
 }
 Interceptor.attach(base.add(0x50b84),{onEnter(){
  const kind=this.context.eax.toInt32();send({event:'timer-generator-dispatch',serial:++serial,kind,thread:this.threadId});
  if(kind===-1)return;
  const owner=this.context.esi.add(0x978).readPointer(),target=owner.readPointer().add(0x4c).readPointer(),key=target.toString();
  if(writers.has(key))return;
  Interceptor.attach(target,{onEnter(a){const caller=this.returnAddress.sub(base).toUInt32();if(caller<0x50b84||caller>=0x5171e)return;send({event:'timer-generated-text',caller_rva:'0x'+caller.toString(16),text:str(a[0]),arg1:a[1].toInt32(),thread:this.threadId});}});
  writers.add(key);
 }});
 for(const rva of [0x50c6c,0x50caa,0x50cd1,0x50cf8,0x50d36,0x50d5d,0x50d78,0x50dbf,0x50de6]){
  Interceptor.attach(base.add(rva),{onEnter(){send({event:'timer-variable-iteration',rva:'0x'+rva.toString(16),name:str(this.context.ebp.sub(0x43c)),current_id:this.context.ebp.sub(0x87c).readS32(),other_id:this.context.ebp.sub(0x463).readS32(),locals:locals(this.context),thread:this.threadId});}});
 }
 for(const rva of [0x50e2d,0x51146])Interceptor.attach(base.add(rva),{onEnter(){send({event:'timer-generator-locals',rva:'0x'+rva.toString(16),locals:locals(this.context),remainder:this.context.ebp.sub(0x89c).readS32(),thread:this.threadId});}});
 installed=true;send({event:'timer-generator-hooks',base:base.toString()});
}
Process.attachModuleObserver({onAdded(m){const n=m.name.toLowerCase();let t=null;if(n==='dzdataabs_compiler_iec.dll')t=m.findExportByName('DllGetClassObject');if(n==='dzdataabs_compileradapter.dll')t=m.base.add(0x13cc0);if(n==='eccompiler_iec.dll')t=m.findExportByName('ObjectNew');if(t)Interceptor.attach(t,{onEnter(){install();}});}});
})();
