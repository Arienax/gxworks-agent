'use strict';
const hooked=new Set();let matches=0;
function location(p) {
  const m=Process.findModuleByAddress(p);
  return m?{module:m.name,rva:p.sub(m.base).toString()}:{address:p.toString()};
}
function boundedText(p,wide) {
  if(p.isNull())return null;
  for(let i=0;i<512;i++)if((wide?p.add(i*2).readU16():p.add(i).readU8())===0)
    return wide?p.readUtf16String(i):p.readUtf8String(i);
  return null;
}
const observer=Process.attachModuleObserver({onAdded(m) {
  if(!/^(?:msvcr\d+|ucrtbase)\.dll$/i.test(m.name))return;
  // 32-bit public CRT prototypes: bounded format input only, no vararg reads.
  const specs={vsprintf:[1,false],vsprintf_s:[2,false],_vsnprintf:[2,false],_vsnprintf_s:[3,false],_vscprintf:[0,false],
    _vsnwprintf:[2,true],_vsnwprintf_s:[3,true],_vscwprintf:[0,true],
    __stdio_common_vsprintf:[4,false],__stdio_common_vswprintf:[4,true]};
  for(const [name,[index,wide]] of Object.entries(specs)) {
    const p=m.findExportByName(name);if(!p||hooked.has(p.toString()))continue;
    hooked.add(p.toString());send({event:'format-hook',module:m.name,name});
    Interceptor.attach(p,{onEnter(args) {
      if(matches>=128)return;
      let format=null;try{format=boundedText(args[index],wide);}catch(error){return;}
      if(format===null||(!format.includes('FOREIGN_NET')&&!format.includes('CG LABEL')))return;
      matches++;
      send({event:'foreign-net-format',crt:m.name,name,format,caller:location(this.returnAddress),
        stack:Thread.backtrace(this.context,Backtracer.ACCURATE).slice(0,16).map(location)});
    }});
  }
}});
send({event:'ready',pid:Process.id});
