"""Bind product writer output to native controls and all prior partial-tail inputs.

No native compilation in this verifier: exact output hashes bind to earlier
native compile/reopen artifacts. Corpus edits below are container-only probes
in memory, not claims that an arbitrary mutated payload is a valid GXW object.
"""
from pathlib import Path
import io,json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
import olefile
from gxw.container import CompoundFile
from gxw.container_writer import validate_cfb_streams,replace_project_stream
from gxw.declarations import parse_declarations,edit_declarations
from gxw.project_metadata import logical_mapping
from gxw.project_writer import build_gxw_project
from gxw.lossless import sha256
P=Path(__file__).resolve().parent
report=dict(native_control_matches=[],corpus=[],scope=__doc__)
source=(P/'scpi-label-inputs/global-constant/native/native-saved.gxw').read_bytes()
outer=validate_cfb_streams(source);nested=validate_cfb_streams(outer['_hdb'])
logical='Global1.gh';physical=logical_mapping(outer['projectdatalist.xml'])[logical]
doc=parse_declarations(nested[physical],logical_name=logical)
assert build_gxw_project(source,declarations={logical:doc}).data==source
for case,change in [('constant-value',dict(initial_value='124')),('comment-growth',dict(comment='Q'*3000))]:
 edited=edit_declarations(doc,upserts=[dict(name='InputValue',**change)])
 result=build_gxw_project(source,declarations={logical:edited})
 control=P/'partial-sector-label-edits'/case
 expected=(control/'changed.gxw').read_bytes()
 assert result.data==expected
 observation=json.loads((control/'comparison.json').read_text())
 native=observation['native'];assert native['open_succeeded'] and native['compile_completed'] and not native['compiler_rejected'] and not native['diagnostics']
 report['native_control_matches'].append(dict(case=case,output_sha256=sha256(result.data),
  matched_native_input=str((control/'changed.gxw').relative_to(ROOT)),native_observation=str((control/'comparison.json').relative_to(ROOT)),
  observation_sha256=sha256((control/'comparison.json').read_bytes()),allocations=result.report['allocations'],
  native_pcode_equal_to_baseline=observation['native_pcode_equal_to_baseline']))
scan=json.loads((P/'native-sector-tail-scan.json').read_text())
for row in scan['rows']:
 if not row['nested_tail_bytes']:continue
 path=P/row['path'];raw=path.read_bytes();assert sha256(raw)==row['sha256']
 inner=CompoundFile(raw).read_stream('_hdb');cfb=CompoundFile(inner)
 before=validate_cfb_streams(inner)
 name=next(n for n,data in before.items() if data)
 noop,mode=replace_project_stream(inner,name,before[name]);assert noop==inner
 # Arbitrary same-size probe is kept in memory. No semantic/native assertion.
 replacement=bytes([before[name][0]^1])+before[name][1:]
 changed,mode=replace_project_stream(inner,name,replacement)
 expected=dict(before,**{name:replacement});assert validate_cfb_streams(changed)==expected
 with olefile.OleFileIO(io.BytesIO(changed)) as external:
  observed={p[0]:external.openstream(p).read() for p in external.listdir()}
 assert observed==expected
 report['corpus'].append(dict(path=row['path'],source_sha256=row['sha256'],tail_bytes=row['nested_tail_bytes'],
  streams=len(before),no_op='byte-identical',edited_stream=name,mode=mode,
  unrelated_payloads='byte-identical',independent_reader='equal'))
report['summary']=dict(native_control_matches=len(report['native_control_matches']),partial_inputs=len(report['corpus']),
                      no_op_byte_identical=True,independent_equal=True,
                      new_native_compilations=0,source_projects='derivatives; not independent projects')
with (P/'partial-sector-product-writer-comparison.json').open('x') as f:json.dump(report,f,indent=2)
print(json.dumps(report['summary']),flush=True)
print(json.dumps(report['native_control_matches']),flush=True)
