"""Metadata-discovered source token listings versus independent native decoding."""
from collections import defaultdict
from pathlib import Path
import base64
import json
import sys
ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'research')]
from gxw.lossless import inspect_project, sha256
from gxw.token_pou import frame_token_pou
from gxw.token_listing import decode_token_program
from gxw.project_metadata import read_project_text_context
from probe_gxw_task_graph import inspect_task_graph
from native_gxw_tokens import native_batch, native_il_projection, canonical_record, listing_records

P = Path(__file__).resolve().parent
OUT = P/'additional-real-source-crosscheck/native-listings'


def main():
    OUT.mkdir(exist_ok=False); (OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    rows = []; batches = defaultdict(list)
    for path in sorted((P/'additional-real-projects').glob('case-*/input.gxw')):
        source = path.read_bytes(); image = inspect_project(source)
        streams = {s.logical_name: s.raw for s in image.streams if s.logical_name}
        context = read_project_text_context(next(v for k, v in streams.items() if k.endswith('.prj')))
        graph = inspect_task_graph(source)
        for info in graph['programs'].values():
            name = info['source_program']; raw = streams[name]
            row = dict(case=path.parent.name, program=name, sha256=sha256(raw), context=context)
            rows.append(row)
            try:
                frame = frame_token_pou(raw)
            except ValueError as exc:
                row.update(handling='unsupported-as-simple-ladder', reason=str(exc))
                continue
            listing = decode_token_program(frame, text_encoding=context['text_encoding'])
            row.update(body_sha256=sha256(frame.body), body_bytes=len(frame.body),
                reconstructed_identically=listing.reconstruct() == raw,
                native_compiler_bytes_identical=frame.body == (P/'additional-native-baselines'/path.parent.name/'native-1/pcode-0-0.bin').read_bytes(),
                records=listing_records(listing), gaps=[dict(offset=g.tokens[0].offset, reason=g.reason, raw=[t.raw.hex() for t in g.tokens]) for g in listing.gaps])
            cpu = {'FX3U/FX3UC': 0x208, 'FX1S': 0x206}[context['cpu']]
            batches[cpu].append((row, frame.body))
    (OUT/'source-predictions.json').write_text(json.dumps(rows, indent=2), encoding='utf-8')
    for cpu, batch in batches.items():
        results = native_batch([dict(mode='decode', input_base64=base64.b64encode(body + b'\0').decode(),
            source_sha256=row['sha256'], program=row['program'], case=row['case']) for row, body in batch], OUT/f'cpu-{cpu}', cpu_code=cpu)
        for (row, body), result in zip(batch, results, strict=True):
            row['native_response'] = result
            if result['return_code'] != '0x00000000' or result['consumed_bytes'] != len(body):
                row['handling'] = 'native-decoder-rejected'
                continue
            projection = native_il_projection(base64.b64decode(result['output_base64']), encoding=row['context']['text_encoding'])
            row['native_projection'] = projection
            a, b = [[canonical_record(r) for r in records] for records in (row['records'], projection['records'])]
            row['listing_agrees'] = a == b
            row['differences'] = [dict(index=i, ours=a[i] if i < len(a) else None, native=b[i] if i < len(b) else None)
                for i in range(max(len(a), len(b))) if (a[i] if i < len(a) else None) != (b[i] if i < len(b) else None)]
            row['handling'] = 'cross-checked' if a == b else 'differs'
    (OUT/'comparison.json').write_text(json.dumps(rows, indent=2), encoding='utf-8')
    print(json.dumps([dict(case=r['case'], program=r['program'], handling=r['handling'], gaps=r.get('gaps'),
        differences=r.get('differences')) for r in rows], ensure_ascii=True), flush=True)


if __name__ == '__main__':
    main()
