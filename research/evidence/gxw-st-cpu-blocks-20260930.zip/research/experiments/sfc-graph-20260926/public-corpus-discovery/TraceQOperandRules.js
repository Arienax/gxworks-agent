'use strict';
let request=0;
function hex(p,n){return Array.from(new Uint8Array(p.readByteArray(n)),b=>b.toString(16).padStart(2,'0')).join('');}
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='eccodegenerator2.dll')return;
 const base=m.base;
 Interceptor.attach(m.findExportByName('CheckInstructionCode2'),{onEnter(a){request++;}});
 Interceptor.attach(base.add(0x5190a),{onEnter(a){
   this.row={event:'operand-rule',request,family:a[0].toUInt32()&255,variant:a[1].toUInt32()&255,index:(a[3].toUInt32()&255)-1};
   this.row.descriptor=hex(a[2].add(this.row.index*18),18);
 },onLeave(r){this.row.result=(r.toInt32()<<16)>>16;send(this.row);}});
 Interceptor.attach(base.add(0x515f9),{onEnter(a){
   this.row={event:'operand-modifiers',request,index:(a[1].toUInt32()&255)-1};
   this.p=a[0].add(this.row.index*18);this.row.before=hex(this.p,18);
 },onLeave(r){this.row.result=(r.toInt32()<<16)>>16;this.row.after=hex(this.p,18);send(this.row);}});
}});
