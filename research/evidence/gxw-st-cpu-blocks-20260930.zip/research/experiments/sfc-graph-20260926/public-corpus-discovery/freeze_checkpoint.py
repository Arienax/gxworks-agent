"""Freeze selected raw evidence; unlicensed BoxID material remains local."""
from pathlib import Path
import hashlib,json,subprocess,zipfile
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[4]
P=Path(__file__).resolve().parent
RESULT=ROOT/'research/results/gxw-checkpoint-20260927';RESULT.mkdir(exist_ok=True)
digest=lambda raw:hashlib.sha256(raw).hexdigest()
public={};local={}
def add(target,path):
 path=path.resolve();path.relative_to(ROOT)
 if path.is_file():target[path.relative_to(ROOT).as_posix()]=path
 else:raise FileNotFoundError(path)
def top(target,directory,*,projects=True,frontend=False):
 if not directory.exists():return
 for p in directory.iterdir():
  if not p.is_file() or p.suffix not in {'.json','.jsonl','.bin','.gxw','.txt','.py','.js','.cs'}:continue
  if p.suffix=='.gxw' and not projects:continue
  if p.name=='frontend-snapshot.json' and not frontend:continue
  add(target,p)
def native(target,directory,*,frontend=False):
 top(target,directory,frontend=frontend)
 for name in ['CGTable.dat','DebugInformation2.dat','CallTree.dat','ResourceCallTree.dat']:
  path=directory/'compiler_DZComp'/name
  if path.exists():add(target,path)
scripts=['correlate_scpi_operand_bindings.py','correlate_scpi_callsite_aliases.py','correlate_scpi_complex_callers.py',
 'probe_scpi_repeated_complex_enable.py','probe_scpi_repeated_value_inputs.py','freeze_checkpoint.py']
for name in scripts:add(public,P/name)
for name in ['scpi-provenance.json','samples/scpi-SCPI_FB.gxw','samples/scpi-LICENSE.txt']:add(public,P/name)
for d in ['scpi-two-callers','scpi-instance-binding-controls/same-instance','native-fb-connection-type-controls/compound',
          'scpi-repeated-complex-enable/first','scpi-repeated-complex-enable/last'] + [
          'scpi-repeated-value-inputs/'+k+'-'+o for k in ['int','dint','string'] for o in ['literal-first','device-first']]:
 directory=P/d;top(public,directory)
 native(public,directory/'native')
 for suffix in ['source-connections','source-connections-wide']:
  top(public,directory/suffix);top(public,directory/suffix/'native-token-decode')
for d in ['scpi-exact-instance-operands','scpi-exact-instance-operands-v2','scpi-exact-instance-operands-v3','scpi-value-input-bindings-v2']:
 directory=P/d;top(public,directory)
 for case in directory.iterdir():
  if case.is_dir():top(public,case);top(public,case/'native-decode')
for case in ['same','two']:top(public,P/'native-fb-callsite-connections'/case);top(public,P/'native-fb-callsite-connections'/case/'native-token-decode')
for d in ['scpi-repeated-complex-enable/native-encode','scpi-repeated-value-inputs/native-encode']:top(public,P/d)
for name in ['research/probe_gxw_operand_bindings.py','research/probe_gxw_callsite_inputs.py','research/probe_gxw_simple_fb.py',
 'research/probe_gxw_simple_fb_connections.py','research/probe_gxw_compiled_references.py','research/probe_gxw_compiler_constants.py',
 'research/native_gxw_tokens.py','research/native/TokenOracle.cs','src/gxw/compiler_tables.py','src/gxw/compiler_debug.py',
 'tests/fixtures/gxw_callsite_inputs.json','tests/test_gxw_compiler.py']:
 add(public,ROOT/name)
array_cases=['static-layout-typed','string-layout','dynamic-layout','dynamic-index-shapes','dynamic-constant-folding',
 'word-bit-layout','word-bit-dynamic','word-bit-transfer','word-bit-call-q','word-bit-call-indexed-enable','word-bit-call-boolean-enable',
 'word-bit-call-specializations','word-bit-fb-output','word-bit-fb-members','word-bit-fb-two-instances',
 'word-bit-template-contrast','word-bit-template-body-edit','word-bit-template-alias','real-literal-rounding','real-literal-rounding-valid']
for case in array_cases:
 directory=P/'array-operand-controls'/case;top(local,directory)
 for child in directory.iterdir():
  if child.is_dir() and child.name not in ['correlation']:
   if child.name=='native' or child.name=='reopen' or 'trace' in child.name:
    native(local,child,frontend=case in ['word-bit-template-body-edit','word-bit-template-alias'])
   elif child.name=='native-table-reader':top(local,child)
top(local,P/'real-rounding-runtime-controls')
for name in ['samples/boxid.gxw','download-inventory.json','TraceRealConversion.js','TraceBooleanCallLowering.js','TraceAllTemplateOperands.js',
 'probe_array_operand_layout.py','correlate_array_operand_layout.py','correlate_boolean_call_transfers.py','correlate_instance_members.py',
 'probe_boolean_template_body_edit.py','probe_boolean_template_alias.py','probe_legacy_real_rounding.py','correlate_real_lowering_pipeline.py',
 'trace_all_template_operands.py','real-constant-conversion-disassembly.txt','real-codegenerator-conversion-disassembly.txt']:
 add(local,P/name)
for name in ['research/probe_gxw_call_transfers.py','research/probe_gxw_index_arithmetic.py','research/probe_gxw_template_operands.py','research/native/LegacyRealOracle.cs']:
 add(local,ROOT/name)
for p in public.values():
 if '/samples/' not in p.as_posix() and '/scpi-' not in p.as_posix():
  if p.suffix=='.py':add(local,p)
def archive(files,path,visibility):
 if path.exists():raise FileExistsError(path)
 rows=[]
 with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for name,p in sorted(files.items()):
   raw=p.read_bytes();rows.append(dict(path=name,bytes=len(raw),sha256=digest(raw)));z.writestr(name,raw)
  z.writestr('checkpoint-files.json',json.dumps(dict(visibility=visibility,files=rows),indent=2))
 with zipfile.ZipFile(path) as z:
  assert z.testzip() is None
  for row in rows:assert digest(z.read(row['path']))==row['sha256']
 return dict(path=path.relative_to(ROOT).as_posix(),bytes=path.stat().st_size,sha256=digest(path.read_bytes()),
             visibility=visibility,files=rows)
frozen=P/'checkpoint-frozen-20260927';frozen.mkdir(exist_ok=False)
a=archive(public,ROOT/'research/evidence/gxw-callsite-inputs-20260927.zip','repository evidence; includes original SCPI MIT notice; no vendor binaries')
b=archive(local,frozen/'gxw-array-real-local.zip','local-only BoxID-derived material; source license not found; no vendor binaries')
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
manifest=dict(schema=1,created_utc=datetime.now(timezone.utc).isoformat(),base_commit=base,
 code_snapshot='archive source bytes are authoritative; later worktree edits do not change this checkpoint',
 native_execution='fresh offline helper processes only; no PLC, simulator or device execution',archives=[a,b],
 independent_projects='SCPI and BoxID; variants and repeated native rows are not independent real projects',
 claims={
  'scpi':dict(real_fb_definitions=1,original_cases=3,new_caller_variants=8,new_expansions=16,
              groups_per_expansion=163,new_exact_groups=2608,new_stale_table_differences_corrected=158,
              wrong_caller_controls=16,wrong_caller_rejected=16),
  'boolean_transfers':dict(rewrites=12,exact=12,finite_width_and_runtime_bounds='not proved'),
  'template_body':dict(calls=4,changed_by_PLS_to_PLF_body_edit=3,unchanged_name_specialization=1,
                       alias_changes_remaining_call=True),
  'real_literals':dict(project_cases=13,complete_native_pipeline_exact=13,crt_neighborhood_cases=1178,
                       gcvt15_portable_candidate_counterexamples=4,portable_universal_converter=False)},
 exclusions=['GX vendor DLL/EXE binaries','foreign temporary directories','UI screenshots as substitutes for byte evidence',
             'raw BoxID-derived evidence from the repository-distributable archive'])
(RESULT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(base_commit=base,archives=[{k:v for k,v in x.items() if k!='files'}|dict(file_count=len(x['files'])) for x in [a,b]])))
