// Append within the same scope as the allocation observer. Read-only, x86.
const indexConsumption=new Map();let indexSerial=0;
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='eccompiler_iec.dll')return;
 const mask=()=>m.base.add(0x166fb8).readU32();
 function event(tid,value){const c=contexts.get(tid);if(c)emit({event:'index-register-lifetime',compile_id:c.compile_id,
   consumption:indexConsumption.get(tid)||null,mask:mask(),...value});}
 if(hex(m.base.add(0x321b0),3)!=='568bf1'||hex(m.base.add(0xcab70),2)!=='6aff'){
   emit({event:'index-register-guard-error'});return;
 }
 Interceptor.attach(m.base.add(0xcab70),{
  onEnter(a){if(!contexts.get(this.threadId))return;this.id=++indexSerial;this.prior=indexConsumption.get(this.threadId);
   indexConsumption.set(this.threadId,this.id);event(this.threadId,{phase:'consume-enter',args:[a[0].toInt32(),a[1].toInt32(),a[2].toInt32()],caller:loc(this.returnAddress)});},
  onLeave(r){if(!this.id)return;event(this.threadId,{phase:'consume-leave',result:r.toInt32()});indexConsumption.set(this.threadId,this.prior);}
 });
 Interceptor.attach(m.base.add(0x321b0),{
  onEnter(a){this.active=contexts.has(this.threadId);if(!this.active)return;this.slot=a[0].toInt32();this.caller=loc(this.returnAddress);this.before=mask();},
  onLeave(r){if(this.active)event(this.threadId,{phase:'select-register',slot:this.slot,result:r.toInt32(),before:this.before,caller:this.caller});}
 });
 // V2 with interior hooks terminated before PCode; no exception code was
 // captured. Keep only function entries/returns. V2 is not a completed oracle.
}});
