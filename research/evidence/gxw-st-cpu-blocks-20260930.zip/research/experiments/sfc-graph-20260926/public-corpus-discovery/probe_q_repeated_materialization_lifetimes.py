"""Discriminate port allocation reuse after intervening device aliases."""
from pathlib import Path
import json
import struct
import sys
ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'research')]
from gxw.lossless import inspect_project, sha256
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_simple_fb import frame_source, observe_calls
from replay_gxw_workspace import run
from source_q_direct_projection import project_projection
from source_q_allocation import groups

P = Path(__file__).resolve().parent
OUT = P/'q-repeated-materialization-lifetimes'


def payloads(raw):
    return {s.logical_name: s.raw for s in inspect_project(raw).streams if s.logical_name}


def main():
    OUT.mkdir(exist_ok=False)
    for name in ['probe_q_repeated_materialization_lifetimes.py', 'source_q_direct_projection.py', 'source_q_direct_declarations.py', 'source_q_call_connections.py', 'source_q_label_binding.py', 'source_q_allocation.py', 'source_q_width.py', 'q-width-static-tables.json']:
        (OUT/name).write_bytes((P/name).read_bytes())
    plans = [('bool-ABA', 'scpi-repeated-complex-enable/first/changed.gxw', [0, 1, 0]),
             ('int-ABA', 'scpi-repeated-value-inputs/int-literal-first/changed.gxw', [0, 1, 0]),
             ('string-ABA', 'scpi-repeated-value-inputs/string-literal-first/changed.gxw', [0, 1, 0]),
             ('int-AAA', 'scpi-repeated-value-inputs/int-literal-first/changed.gxw', [0, 0, 0]),
             ('string-BABA', 'scpi-repeated-value-inputs/string-literal-first/changed.gxw', [1, 0, 1, 0])]
    ready = []; results = []
    for case, relative, order in plans:
        directory = OUT/case; directory.mkdir()
        source = (P/relative).read_bytes(); before = payloads(source); logical = 'MAIN.Program.pou'
        frame = frame_source(before[logical]); calls = observe_calls(frame)['calls']
        assert len(calls) == 2 and all(c['instance'] == 'SCPI_1' for c in calls)
        assert calls[0]['offset']+calls[0]['length'] == calls[1]['offset']
        blocks = [frame.raw[c['offset']:c['offset']+c['length']] for c in calls]
        program = bytearray(frame.raw[:calls[0]['offset']]+b''.join(blocks[i] for i in order)+frame.raw[calls[-1]['offset']+calls[-1]['length']:])
        delta = len(program)-len(frame.raw)
        for offset in [55, 59]:
            struct.pack_into('<I', program, offset, struct.unpack_from('<I', frame.raw, offset)[0]+delta)
        assert len(observe_calls(frame_source(bytes(program)))['calls']) == len(order)
        changed, receipt = patch_raw(source, logical, before[logical], bytes(program))
        assert payloads(changed) == dict(before, **{logical: bytes(program)})
        path = directory/'input.gxw'; path.write_bytes(changed)
        predictions = project_projection(changed, allow_scpi=True, resource_limit=1)
        for row in predictions:
            (directory/f'predicted-{row["resource_index"]}.bin').write_bytes(row.pop('output'))
        (directory/'prediction-before-native.json').write_text(json.dumps(dict(source=str(P/relative), source_sha256=sha256(source),
            order=order, receipt=receipt, predictions=predictions, compiler_cache='byte-identical; not used by prediction'), indent=2), encoding='utf-8')
        ready.append((case, directory, path, predictions))
    for case, directory, path, predictions in ready:
        for attempt in range(1, 5):
            native = directory/f'native-{attempt}'
            outcome = run(path, native, compile=True, export_project=True, project_alias='QPORTLIFE')
            events = [json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
            if not any(e.get('operation') == 'NativeTemporaryDirectoryCollision' for e in events):
                break
        accepted = outcome['returncode'] == 0 and outcome['compile_completed'] and not outcome['compiler_rejected'] and (native/'native-saved.gxw').exists()
        row = dict(case=case, native_directory=str(native), native_accepted=accepted, outcome=outcome)
        if accepted:
            ours = (directory/'predicted-0.bin').read_bytes(); actual = (native/'pcode-0-0.bin').read_bytes()
            pg = [b''.join(g) for g in groups(ours)]; ng = [b''.join(g) for g in groups(actual)]
            differences = [dict(record=i, predicted=a.hex(), native=b.hex()) for i, (a, b) in enumerate(zip(pg, ng)) if a != b]
            row.update(byte_identical=ours == actual, predicted_sha256=sha256(ours), native_sha256=sha256(actual),
                predicted_records=len(pg), native_records=len(ng), different_records=differences)
        (directory/'comparison.json').write_text(json.dumps(row, indent=2), encoding='utf-8')
        results.append(row); (OUT/'comparison.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
        print(json.dumps(dict(case=case, native_accepted=accepted, byte_identical=row.get('byte_identical'),
            different_records=len(row.get('different_records', [])), examples=row.get('different_records', [])[:3], diagnostics=outcome['diagnostics'])), flush=True)


if __name__ == '__main__':
    main()
