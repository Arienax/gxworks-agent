"""Observe native compile inputs after imported versus fresh initialization."""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from replay_gxw_workspace import prepare,trace_prepared
P=Path(__file__).resolve().parent
out=P/'structured-negation-reload-trace-v2';out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
trace=P/'TraceNegationReloadV2.js'
source=P/'compile-pending-stale-cache/baseline-fresh/native-saved.gxw'
rows=[]
for case,fresh in [('cached',False),('fresh',True)]:
    target=out/case
    prepare(source,target,compile=True,export_project=True,project_alias='RELOADTRACE')
    plan=json.loads((target/'plan.json').read_text());plan.update(reset_compiler=fresh,fresh_compiler_state=fresh)
    (target/'plan.json').write_text(json.dumps(plan,indent=2))
    request=json.loads((target/'request.json').read_text());request['actual_plan_sha256']=sha256((target/'plan.json').read_bytes())
    (target/'request.json').write_text(json.dumps(request,indent=2))
    result=trace_prepared(target,trace)
    events=[json.loads(s) for s in (target/'events.jsonl').read_text().splitlines()]
    payloads=[e['payload'] for e in events if 'payload' in e]
    selected=[e for e in payloads if e.get('name') in ('Compile','CompileStart','Load','LoadFromProjectDB','ChangeInit','Memory.SetBuildData','Memory.ParseData')]
    row=dict(case=case,result=result,input_sha256=sha256(source.read_bytes()),events=selected,
        trace_errors=[e for e in events if e.get('type')=='error'],
        outputs={p.name:sha256(p.read_bytes()) for p in target.glob('pcode-*.bin')})
    rows.append(row);(out/'comparison.json').write_text(json.dumps(dict(cases=rows),indent=2))
    print(json.dumps(dict(case=case,result=result,trace_errors=row['trace_errors'],outputs=row['outputs'],observations=len(selected))),flush=True)
