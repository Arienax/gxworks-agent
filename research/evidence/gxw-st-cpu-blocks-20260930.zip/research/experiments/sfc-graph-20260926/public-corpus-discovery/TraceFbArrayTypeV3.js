// Read-only probes, located through an already resolved compiler import.
let installed=false,base=null;
function label(p){const m=Process.findModuleByAddress(p);return m?m.name+'+'+p.sub(m.base):p.toString();}
function bytes(p,n){try{return Array.from(new Uint8Array(p.readByteArray(n)),x=>x.toString(16).padStart(2,'0')).join('');}catch(_){return null;}}
function capture(context){const regs={};for(const key of ['eax','ebx','ecx','edx','esi','edi','ebp','esp'])regs[key]=context[key].toString();return {registers:regs,frame_minus_0x200:bytes(context.ebp.sub(0x200),0x200),stack:bytes(context.esp,64)};}
function install(phase){
 if(installed)return;
 const compiler=Process.findModuleByName('DZDataABS_Compiler_IEC.dll');if(!compiler)return;
 const target=compiler.base.add(65808).readPointer();base=target.sub(6444);
 if(bytes(target,16)!=='568bf18b4c240885c97507b801000150')return;
 for(const rva of [0x86249,0x8b3c9,0x8fbe4,0x9a9a8,0x9e10c,0x9ecba]){
  if(bytes(base.add(rva),5)!=='6834500c50')throw Error('Unexpected error-site bytes at '+rva.toString(16));
  Interceptor.attach(base.add(rva),{onEnter(){send({event:'array-type-rejection-site',rva:'0x'+rva.toString(16),...capture(this.context),backtrace:Thread.backtrace(this.context,Backtracer.ACCURATE).slice(0,14).map(label)});}});
 }
 Interceptor.attach(base.add(0x7e4d6),{onEnter(args){const code=args[0].toUInt32();if(code!==0x500c5034)return;send({event:'array-type-rejection-call',code:code.toString(16),return_site:label(this.returnAddress),...capture(this.context)});}});
 installed=true;send({event:'installed-via-resolved-import',phase,base:base.toString(),target:label(target)});
}
send({event:'ready',pid:Process.id});
Process.attachModuleObserver({onAdded(m){const n=m.name.toLowerCase();if(/compiler|converter/.test(n))send({event:'module',name:m.name});let t=null;if(n==='dzdataabs_compiler_iec.dll')t=m.findExportByName('DllGetClassObject');if(n==='dzdataabs_compileradapter.dll')t=m.base.add(0x13cc0);if(n==='eccompiler_iec.dll')t=m.findExportByName('ObjectNew');if(t)Interceptor.attach(t,{onEnter(){install(n);}});}});
