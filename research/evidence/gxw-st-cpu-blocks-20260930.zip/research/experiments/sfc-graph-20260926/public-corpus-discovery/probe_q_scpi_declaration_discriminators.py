"""Discriminate port-signature staleness and simple-label STRING array rejection."""
from pathlib import Path

P = Path(__file__).resolve().parent


def main():
    original = P/'probe_q_scpi_declaration_authority.py'
    code = original.read_text(encoding='utf-8')
    code = code.replace("OUT = P/'q-scpi-declaration-authority'", "OUT = P/'q-scpi-declaration-discriminators'")
    start = code.index('    plans = [\n'); end = code.index('    ready = []; results = []', start)
    code = code[:start]+'''    local_ids = sorted(r.record_id for r in doc.rows if r.class_code == 1)
    local_reverse = dict(zip(local_ids, reversed(local_ids)))
    short = edit_declarations(expanded, renames={'unused_text_matrix': 'txtarr'})
    plans = [
        ('only-local-ids-reversed', replace(doc, rows=tuple(replace(r, record_id=local_reverse.get(r.record_id, r.record_id)) for r in doc.rows))),
        ('port-ids-and-call-markers-reversed', replace(doc, rows=tuple(replace(r, record_id=reversed_ids[r.record_id]) for r in doc.rows))),
        ('short-string-array', short),
        ('short-string-array-empty-initial', edit_declarations(short, upserts=[dict(name='txtarr', initial_value='')])),
        ('long-name-string-scalar', edit_declarations(expanded, upserts=[dict(name='unused_text_matrix', data_type='STRING[5]', initial_value="''")])),
        ('short-string-array-length32', edit_declarations(short, upserts=[dict(name='txtarr', data_type='ARRAY [-1..1] OF STRING[32]', initial_value="[3('')]")])),
    ]
'''+code[end:]
    old = "        assert payloads(changed) == dict(before, **{logical: labels})"
    new = '''        expected = dict(before, **{logical: labels})
        if case == 'port-ids-and-call-markers-reversed':
            from probe_gxw_simple_fb import frame_source, observe_calls
            caller = 'MAIN.Program.pou'; frame = frame_source(before[caller]); replacements = {}
            tokens = {t.offset: t.raw for t in frame.tokens}
            for call in observe_calls(frame)['calls']:
                for direction in ['input', 'output']:
                    ports = [p for p in call['ports'] if p['direction'] == direction]
                    for target, origin in zip(ports, reversed(ports)):
                        replacements[target['offset']] = tokens[origin['offset']]
            body = b''.join(replacements.get(t.offset, t.raw) for t in frame.tokens)
            assert len(body) == len(frame.body)
            changed_caller = frame.raw[:frame.body_offset]+body+frame.raw[frame.body_end:]
            changed, caller_receipt = patch_raw(changed, caller, before[caller], changed_caller)
            receipt = dict(declaration=receipt, caller=caller_receipt)
            expected[caller] = changed_caller
        assert payloads(changed) == expected'''
    assert old in code; code = code.replace(old, new)
    out = P/'q-scpi-declaration-discriminators'; out.mkdir(exist_ok=False)
    (out/'generated-probe.py').write_text(code, encoding='utf-8')
    (out/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    code = code.replace('    OUT.mkdir(exist_ok=False)', '    assert OUT.is_dir()')
    exec(compile(code, str(out/'generated-probe.py'), 'exec'), dict(__file__=str(original), __name__='__main__'))


if __name__ == '__main__':
    main()
