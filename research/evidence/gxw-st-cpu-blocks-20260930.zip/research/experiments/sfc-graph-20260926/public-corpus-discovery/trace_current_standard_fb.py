import json,sys,hashlib
from pathlib import Path
from collections import Counter
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from replay_gxw_workspace import prepare,trace_prepared
P=Path(__file__).resolve().parent
out=P/'standard-FB-kind-traces'/'Q-TON-E-active-datamanager-v2'
prepare(P/'ST-standard-timer-controls/TON_E_member_read/changed.gxw',out,compile=True,export_project=True)
native=Path('D:/GXWORKS2/DNaviZero/DataAbsorber')
(out/'active-module-hashes.json').write_text(json.dumps({name:hashlib.sha256((native/name).read_bytes()).hexdigest() for name in ['DZDataABS_Compiler.dll','DZDataABS_DataManager.dll','DZDataABS_SICConverter.dll']},indent=2))
r=trace_prepared(out,P/'TraceCurrentStandardFBKind.js',timeout=45)
msgs=[json.loads(x) for x in (out/'events.jsonl').read_text().splitlines()]
rows=[m['payload'] for m in msgs if m.get('type')=='send' and m['payload'].get('event')=='standard-FB-kind']
summary=dict(trace=r,errors=[m for m in msgs if m.get('type')=='error'],calls=[dict(input=k[0],kind=k[1],caller=k[2],count=v) for k,v in Counter((x['input'],x['kind'],json.dumps(x['caller'])) for x in rows).items()])
(out/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary))
