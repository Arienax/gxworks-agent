"""Compare table-derived bindings with independent native PCode and queries."""
from pathlib import Path
import sys,json,re,base64
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from gxw.lossless import sha256
from gxw.compiler_tables import parse_compiler_tables
from probe_gxw_operand_bindings import resolve_operand,split_operands
from probe_gxw_library_sources import snapshot_library_pous,observed_builtin_template
P=Path(__file__).resolve().parent/'array-operand-controls'
for case in (sys.argv[1:] or ['static-layout-typed','string-layout','dynamic-layout']):
 out=P/case;comparison=json.loads((out/'comparison.json').read_text())
 trace=out/comparison['trace_attempts'][-1]['directory']
 read=json.loads((out/'correlation/compiled-references.json').read_text())
 assert all(sha256((trace/r['file']).read_bytes())==r['sha256'] for r in read['resources'])
 symbols=(out/'captured-symbols.bin').read_bytes();tables=parse_compiler_tables(symbols)
 assert json.loads((out/'native-table-reader/comparison.json').read_text())['input_sha256']==sha256(symbols)
 events=[json.loads(l).get('payload',{}) for l in (trace/'events.jsonl').read_text().splitlines()]
 generated=None;allocated=None;root_id=None
 for e in events:
  if e.get('event')!='enter' or e.get('name')!='Compile':continue
  b={v['label']:v for v in e['buffers']}
  for k,v in b.items():
   if not k.startswith('name_') or not v.get('bytes'):continue
   name=bytes.fromhex(v['bytes']).split(b'\0')[0]
   if name==b'POU_01':
    assert bytes.fromhex(b['symbolic_data']['bytes'])==symbols
    root_id=e['id'];generated=bytes.fromhex(b[k.replace('name_','source_')]['bytes']).decode('ascii')
   if root_id is not None and e['id']>root_id and name==b'Task_01':
    assert allocated is None
    allocated=parse_compiler_tables(bytes.fromhex(b['symbolic_data']['bytes']))
 assert generated is not None and allocated is not None
 dump=(out/'native-table-reader/native-table-dump.txt').read_text(encoding='cp1252')
 debug={int(m[1]):dict(line=int(m[2]),pou=int(m[4])) for m in re.finditer(r'^Index +(\d+) , Line +(-?\d+) , NW +(-?\d+) , POUIdx +(\d+)',dump,re.M)}
 pous=snapshot_library_pous(json.loads((out/'native/frontend-snapshot.json').read_text(encoding='utf-8-sig')))
 natives={c['line']['line_index']:c for c in comparison['calls']}
 assignments=json.loads((out/'native/native-device-assignments.json').read_text(encoding='utf-8-sig'))
 queried={a['name']:a for r in assignments for a in r['assignments'] if r['code']==0 and r['hresult']==0}
 rows=[]
 for line in generated.splitlines():
  point=re.search(r' D([0-9]+)$',line)
  if not point:continue
  position=debug[int(point[1])]
  if position['line'] not in natives:continue
  assert tables.pou_at(position['pou']).name_bytes==b'POU_01'
  body=line[:point.start()];function=re.fullmatch(r'F([0-9]+)\((.*)\)',body)
  bindings=[];predicted=[]
  if function:
   definition=tables.pou_at(int(function[1]));name=definition.name_bytes.decode()
   ports=tables.components(definition);actual=split_operands(function[2])
   source_ports=[(i+1,c) for i,c in enumerate(ports) if c.name_bytes!=b'ENO']
   assert len(actual)==len(source_ports)
   mapped={i:resolve_operand(a,tables,allocated,cpu='Q03UDV') for (i,c),a in zip(source_ports,actual)}
   bindings=list(mapped.values())
   library=[p for p in pous if p['library']=='@MELSEC' and p['name']==name];assert len(library)==1
   template=observed_builtin_template(base64.b64decode(library[0]['program_raw_base64']))
   for instruction in template['instructions']:
    args=[mapped.get(o['placeholder_id'],{}).get('operand') for o in instruction['operands']]
    predicted.append(dict(kind='instruction',op=instruction['opcode'],args=args))
  else:
   assignment=re.fullmatch(r'(K[0-9]+) := (K[0-9]+\[.*\]);',body)
   assert assignment,body
   dst=resolve_operand(assignment[1],tables,allocated,cpu='Q03UDV');src=resolve_operand(assignment[2],tables,allocated,cpu='Q03UDV')
   bindings=[src,dst];typ=tables.component_type(tables.component_at(int(assignment[1][1:])))
   op={2:'MOV',3:'DMOV',9:'EMOV',11:'DMOV',15:'$MOV'}.get(typ)
   predicted=[dict(kind='instruction',op=op,args=[src['operand'],dst['operand']])]
  observed=natives[position['line']]['records'];gaps=[g for b in bindings for g in b['gaps']]
  query_comparisons=[]
  for binding in bindings:
   if 'indices' not in binding or binding['operand'] is None:continue
   index=','.join(str(v['value']) for v in binding['indices'])
   full_name=binding['component']+'['+index+']';answer=queried.get(full_name)
   query_comparisons.append(dict(name=full_name,native=answer,operand_equal=answer is not None and answer['address']==binding['operand'],
                                 element_size_equal=answer is not None and answer['count']==binding['layout']['stride']))
  rows.append(dict(generated=line,source=natives[position['line']]['line'],bindings=bindings,predicted=predicted,observed=observed,
                   template_suffix_equal=observed[-len(predicted):]==predicted and not gaps,
                   native_assignment_comparisons=query_comparisons,gaps=gaps))
 result=dict(case=case,symbols_sha256=sha256(symbols),allocated_symbols_sha256=sha256(allocated.raw),
             decoded_resource_hashes=[r['sha256'] for r in read['resources']],rows=rows,
             summary=dict(statements=len(rows),native_suffix_exact=sum(r['template_suffix_equal'] for r in rows),
                          array_query_rows=sum(len(r['native_assignment_comparisons']) for r in rows),
                          native_query_exact=sum(q['operand_equal'] and q['element_size_equal'] for r in rows for q in r['native_assignment_comparisons']),
                          opaque_statements=sum(bool(r['gaps']) for r in rows)))
 (out/'binding-comparison.json').write_text(json.dumps(result,indent=2))
 print(json.dumps(dict(case=case,**result['summary'])),flush=True)
