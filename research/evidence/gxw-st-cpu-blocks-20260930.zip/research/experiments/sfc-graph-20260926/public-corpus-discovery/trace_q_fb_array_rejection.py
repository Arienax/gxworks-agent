"""Locate native FB-array rejection without modifying the observed process."""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path.insert(0,str(ROOT/'research'))
from replay_gxw_workspace import prepare,trace_prepared
P=Path(__file__).resolve().parent
out=P/'q-fb-array-type-trace';out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
for case in ['local-empty-initial','global-empty-initial']:
    target=out/case
    prepare(P/'q-fb-array-storage'/case/'input.gxw',target,compile=True,snapshot_frontend=True,export_project=True,project_alias='QFBARRAYTRACE')
    result=trace_prepared(target,P/'TraceFbArrayType.js')
    events=[json.loads(s) for s in (target/'events.jsonl').read_text(encoding='utf-8').splitlines()]
    selected=[e.get('payload',e) for e in events if e.get('type')=='error' or e.get('payload',{}).get('event')=='array-type-rejection']
    print(json.dumps(dict(case=case,process=result,events=selected)),flush=True)
