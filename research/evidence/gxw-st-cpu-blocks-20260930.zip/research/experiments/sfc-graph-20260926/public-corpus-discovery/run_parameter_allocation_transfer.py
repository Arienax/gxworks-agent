"""Transfer one observed Q device-allocation record between public projects."""
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'research')]
from gxw.container_writer import validate_cfb_streams, replace_project_stream
from gxw.project_metadata import logical_mapping, synchronize_history
from probe_gxw_integrity import inspect, observed_digest, FILES, TABLE_BYTES
from probe_gxw_native_listing import project_text_context
from probe_gxw_parameters import frame_parameters, device_allocation_record
from replay_gxw_workspace import run

P = Path(__file__).resolve().parent
OUT = P / 'project2-t-st-parameter-transfer'
OUT.mkdir(exist_ok=False)
source = (P / 'samples/project2.gxw').read_bytes()
donor = (P / 'noeul-native-batch/case-31/input.gxw').read_bytes()
assert inspect(source)['valid'] is True

def unpack(raw):
    outer = validate_cfb_streams(raw)
    inner_bytes = outer['_hdb'][:-TABLE_BYTES] if inspect(raw)['valid'] else outer['_hdb']
    nested = validate_cfb_streams(inner_bytes)
    mapping = logical_mapping(outer['projectdatalist.xml'])
    streams = {name: nested[physical] for name, physical in mapping.items() if physical in nested}
    contexts = [project_text_context(raw) for name, raw in streams.items() if name.endswith('.prj')]
    assert len(contexts) == 1 and contexts[0]['cpu'] == 'Q03UDV'
    return outer, nested, mapping, streams

outer, nested, mapping, streams = unpack(source)
_, _, _, donor_streams = unpack(donor)
old = streams['Param.wpa']
record = device_allocation_record(old)
replacement = device_allocation_record(donor_streams['Param.wpa'])
new = b''.join(replacement.raw if r.offset == record.offset else r.raw for r in frame_parameters(old)) + b'\xff\xff'
a, b = frame_parameters(old), frame_parameters(new)
assert len(a) == len(b)
assert all(x.raw == y.raw for x, y in zip(a, b) if x.tag != 0x2000)
assert device_allocation_record(new).raw == replacement.raw
physical = mapping['Param.wpa']
history, changes, preserved = synchronize_history(outer['history.xml'], {'Param.wpa': (physical, old, new)})
body, method = replace_project_stream(outer['_hdb'][:-TABLE_BYTES], physical, new)
assert validate_cfb_streams(body) == dict(nested, **{physical: new})
metadata = dict(outer, **{'history.xml': history})
table = b''.join(observed_digest(body if name == '_hdb' else metadata[name]) for name in FILES)
hdb = body + table
result, _ = replace_project_stream(source, '_hdb', hdb)
result, _ = replace_project_stream(result, 'history.xml', history)
result, _ = replace_project_stream(result, 'Project.gd2', observed_digest(hdb))
assert inspect(result)['valid'] is True
assert validate_cfb_streams(result) == dict(metadata, _hdb=hdb, **{'Project.gd2': observed_digest(hdb)})
(OUT / 'changed.gxw').write_bytes(result)
(OUT / 'mutation.json').write_text(json.dumps(dict(source_sha256=hashlib.sha256(source).hexdigest(),
    donor_sha256=hashlib.sha256(donor).hexdigest(), parameter_offset=record.offset,
    old_record_hex=record.raw.hex(), new_record_hex=replacement.raw.hex(), allocation_method=method,
    history_changes=changes, other_parameter_records='byte-identical', other_logical_payloads='byte-identical',
    scope='explicit offline parameter-record experiment; no device writes'), indent=2))
first = run(OUT / 'changed.gxw', OUT / 'native', compile=True, export_project=True, project_alias='TSTPARAM')
print(json.dumps({key: first[key] for key in ['returncode', 'open_succeeded', 'compile_completed',
    'compiler_rejected', 'diagnostics', 'last_event']}), flush=True)
if first.get('native_export'):
    second = run(OUT / 'native/native-saved.gxw', OUT / 'reopen', compile=True, export_project=True)
    print('reopen', second['returncode'], second['compile_completed'], second['diagnostics'],
          'compiled_identical', first['outputs'] == second['outputs'], flush=True)
