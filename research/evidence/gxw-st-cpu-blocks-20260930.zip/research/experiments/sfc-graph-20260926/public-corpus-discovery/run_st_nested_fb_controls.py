"""Real ST template -> native FB copy -> preserved nested-call mutations."""
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.declarations import parse_declarations,edit_declarations,serialize_declarations
from gxw.compiler_debug import parse_compiler_debug
from probe_gxw_st_sources import replace_observed_st
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_compiled_references import inspect
from probe_gxw_debug_locations import search_maps
from replay_gxw_workspace import run
P=Path(__file__).resolve().parent
OUT=P/'ST-nested-FB-controls'
source=(OUT/'native-copy-wrapper-generic/native-saved.gxw').read_bytes()
streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
new={}
name='Wrapper.Program.pou'
new[name],_=replace_observed_st(streams[name],'(* Nested call control *)\r\nInner(number:=number, in_out_character:=in_out_character);\r\n')
name='Wrapper.Labels.lh';d=parse_declarations(streams[name],logical_name=name)
new[name]=serialize_declarations(edit_declarations(d,remove=[r.name for r in d.rows if r.name not in ['number','in_out_character']],
    upserts=[dict(name='Inner',data_type='Keypad',kind='function_block')]))
name='POU_01.Labels.lh';d=parse_declarations(streams[name],logical_name=name)
new[name]=serialize_declarations(edit_declarations(d,upserts=[dict(name='Keypad_1',data_type='Wrapper',kind='function_block')]))
for case in ['single','repeated']:
    out=OUT/case;out.mkdir(exist_ok=True)
    if (out/'comparison.json').exists():continue
    replacements=dict(new)
    if case=='repeated':
        name='POU_01.Program.pou';_,text=replace_observed_st(streams[name],'')
        call='Keypad_1(number:= line1 , in_out_character:= character );'
        assert text.count(call)==1
        replacements[name],_=replace_observed_st(streams[name],text.replace(call,call+'\r\nKeypad_1(number:=line2, in_out_character:=currentUserId);'))
    changed=source;receipts=[]
    for name,raw in replacements.items():
        changed,receipt=patch_raw(changed,name,streams[name],raw);receipts.append(receipt)
    after={s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}
    assert all(after[n]==raw for n,raw in streams.items() if n not in replacements)
    path=out/'changed.gxw';path.write_bytes(changed)
    (out/'mutation.json').write_text(json.dumps(dict(source_sha256=sha256(source),changed_sha256=sha256(changed),
        receipts=receipts,unrelated_payloads='byte-identical'),indent=2),encoding='utf-8')
    q=[dict(name='all',keys=[],symbol='',scope='',declared=0,plural=0)]
    result=run(path,out/'native',compile=True,export_project=True,project_alias='NESTEDST',analysis_queries=q,analysis_version=3)
    comparison=dict(case=case,native={k:result[k] for k in ['returncode','compile_completed','compiler_rejected','diagnostics']})
    if result.get('native_export'):
        reopened=run(out/'native/native-saved.gxw',out/'reopen',compile=True,export_project=True)
        comparison['reopen']={k:reopened[k] for k in ['returncode','compile_completed','compiler_rejected','diagnostics']}
        comparison['reopen_pcode_equal']=result['outputs']==reopened['outputs']
        read=inspect(out/'native',out/'correlation');comparison['reader']=read['summary']
        debug=parse_compiler_debug(next(s.raw for s in inspect_project((out/'native/native-saved.gxw').read_bytes()).streams if s.logical_name=='DebugInformation2.dat'))
        comparison['elements']=[dict(index=i,fields=e.fields,names=[n.decode('cp1252') for n in e.names]) for i,e in enumerate(debug.elements)]
        comparison['search_maps']=search_maps(debug,encoding='cp1252')
    (out/'comparison.json').write_text(json.dumps(comparison,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in comparison.items() if k not in ['search_maps']}),flush=True)
