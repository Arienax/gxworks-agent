"""Independent typed arithmetic predictions, then control-flow slot discovery."""
from pathlib import Path
import base64,json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from gxw.declarations import parse_declarations,edit_declarations,serialize_declarations
from gxw.project_metadata import mark_observed_source_compile_pending
from probe_gxw_st_sources import replace_observed_st
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_program_check_resources import SCRIPT
from probe_minimal_conditional_port_writes import streams,observe,save
from source_q_st_expressions import predict
from native_gxw_tokens import native_batch,Q_DLL,native_il_records
P=Path(__file__).resolve().parent
OUT=P/'st-temporary-control-flow-20260930'


def pair(p):return f'({p}A + {p}B) - ({p}C + {p}D)'
def balanced(p):return f'(({p}A + {p}B) - ({p}C + {p}D)) + (({p}E + {p}F) - ({p}G + {p}H))'
def chain(p):return f'(((((({p}A + {p}B) - {p}C) + {p}D) - {p}E) + {p}F) - {p}G) + {p}H'


def main():
    global OUT
    config=json.loads(Path(sys.argv[1]).read_text()) if len(sys.argv)>1 else None
    if config:OUT=P/config['directory']
    OUT.mkdir(exist_ok=False)
    if config:save(OUT/'experiment-plan.json',config)
    for name in (Path(__file__).name,'source_q_st_expressions.py','source_q_direct_declarations.py','observe_expression_temporaries.js'):
        (OUT/name).write_bytes((P/name).read_bytes())
    extra=''
    if config and config.get('observer'):
        extra=(P/config['observer']).read_text();(OUT/config['observer']).write_text(extra)
    trace=OUT/'trace.js';trace.write_text('(()=>{'+(P/'native-allocation-bitmap-v2/observer.js').read_text()+'\n'+(P/'observe_expression_temporaries.js').read_text()+'\n'+extra+'\n})();\n(()=>{'+SCRIPT+'\n})();',encoding='utf-8')
    original=(P/'st-temporary-widths-20260930/int-dint-int/input.gxw').read_bytes();before=streams(original)
    name='POU_01.Labels.lh';doc=parse_declarations(before[name],logical_name=name)
    additions=[dict(name=prefix+s,data_type=kind) for prefix,kind in [('wide','DINT'),('real','REAL')] for s in ('E','F','G','H')]
    if config:additions+=config.get('declarations',[])
    labels=mark_observed_source_compile_pending(serialize_declarations(edit_declarations(doc,upserts=additions)),logical_name=name)
    plans={
      'typed-balanced-first':f'wideR := {balanced("wide")};\nprobeR1 := {pair("probe")};\nrealR := {balanced("real")};\n',
      'typed-chain-first':f'probeR1 := {balanced("probe")};\nwideR := {chain("wide")};\nrealR := {balanced("real")};\n',
      'if-else':f'IF probeA > probeB THEN\nprobeR1 := {pair("probe")};\nELSE\nprobeR1 := {balanced("probe")};\nEND_IF;\nprobeR2 := {pair("probe")};\n',
      'if-elsif-expression':f'IF (probeA + probeB) < (probeC + probeD) THEN\nprobeR1 := {pair("probe")};\nELSIF (probeE + probeF) > (probeG + probeH) THEN\nprobeR1 := {balanced("probe")};\nELSE\nprobeR1 := probeA + probeD;\nEND_IF;\nprobeR2 := {pair("probe")};\n',
      'while-expression':f'WHILE (probeA + probeB) < (probeC + probeD) DO\nprobeA := probeA + probeE;\nprobeR1 := {balanced("probe")};\nEND_WHILE;\nprobeR2 := {pair("probe")};\n',
      'for-expression':f'FOR probeA := probeB + probeC TO probeD + probeE BY 2 DO\nprobeR1 := {balanced("probe")};\nEND_FOR;\nprobeR2 := {pair("probe")};\n',
    }
    if config:plans=config['plans']
    ready=[]
    for case,text in plans.items():
        text=text.replace('\n','\r\n');d=OUT/case;d.mkdir();name='POU_01.Program.pou'
        raw,_=replace_observed_st(before[name],text);raw=mark_observed_source_compile_pending(raw,logical_name=name)
        source,one=patch_raw(original,name,before[name],raw)
        source,two=patch_raw(source,'POU_01.Labels.lh',before['POU_01.Labels.lh'],labels)
        assert streams(source)==dict(before,**{name:raw,'POU_01.Labels.lh':labels})
        path=d/'input.gxw';path.write_bytes(source);predicted=None;prediction=None
        if case.startswith('typed-'):
            prediction=predict(source);predicted=prediction.pop('output');(d/'predicted-0.bin').write_bytes(predicted)
        save(d/'before-native.json',dict(case=case,input_sha256=sha256(source),source_text=text,receipts=[one,two],prediction=prediction,
            hypotheses=['Typed arithmetic: native type separates word/doubleword; DINT and REAL share the latter.',
                'Control flow: inspect whether condition/intermediate lifetimes survive across body and branch boundaries, including pins and states 4/9/12.']))
        ready.append((case,d,path,predicted))
    rows=[];requests=[];keys=[]
    for case,d,path,predicted in ready:
        native,checked,process=observe(path,d,trace);code=(native/'pcode-0-0.bin').read_bytes()
        messages=[json.loads(l) for l in (native/'events.jsonl').read_text().splitlines()]
        events=[m['payload'] for m in messages if m.get('type')=='send']
        errors=[m for m in messages if m.get('type')=='error' or 'error' in m.get('payload',{}).get('event','') or m.get('payload',{}).get('observation_error')]
        temp=[e for e in events if e.get('event','').startswith('temporary-')]
        row=dict(case=case,native_directory=str(native),process=process,check=checked['check'],diagnostics=checked['diagnostics'],trace_errors=errors,
            bytes=len(code),sha256=sha256(code),prediction_identical=None if predicted is None else code==predicted,temporary_events=temp,
            pools=[e for e in events if e.get('event')=='pool-allocation'])
        reopen_selected=case in config.get('reopen',[]) if config else (case.startswith('typed-') or case in ('if-elsif-expression','for-expression'))
        if checked['exported_sha256'] and reopen_selected:
            rd=d/'reopen';rd.mkdir();rn,rc,rp=observe(native/'native-saved.gxw',rd,trace)
            row['reopen']=dict(native_directory=str(rn),check=rc['check'],diagnostics=rc['diagnostics'],identical=code==(rn/'pcode-0-0.bin').read_bytes())
        rows.append(row);save(OUT/'comparison.json',rows)
        print(json.dumps(dict(case=case,check=row['check'],bytes=len(code),prediction_identical=row['prediction_identical'],
            diagnostics=sorted(set(hex(e['code']) for e in row['diagnostics'] if e['kind']==2)),errors=errors,
            requests=[dict(type=e['args'][0],count=e['args'][3],mode=e['args'][4],pin=e['args'][6],number=e['result']) for e in temp if e.get('name')=='request'],
            states=sorted(set(s['state'] for e in temp if 'after' in e for s in e['after'])),
            reopen=row.get('reopen',{}).get('identical'))),flush=True)
        if errors:raise RuntimeError('trace incomplete')
        if code:requests.append(dict(mode='decode',case=case,input_base64=base64.b64encode(code+b'\0').decode()));keys.append(case)
    if requests:
        decoded=native_batch(requests,OUT/'native-decode',dll=Q_DLL,cpu_code=209,native_versions=(25,))
        save(OUT/'native-listings.json',[dict(case=k,return_code=r['return_code'],records=native_il_records(base64.b64decode(r['output_base64']),encoding='cp932')) for k,r in zip(keys,decoded)])


if __name__=='__main__':main()
