"""Test Q03UDV lexical rules as a hypothesis against actual Q02 decoding."""
from pathlib import Path
import base64
import json
import sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.token_pou import frame_token_pou
from gxw.token_listing import decode_token_listing
from native_gxw_tokens import native_batch,native_il_projection,listing_records,Q_DLL
from replay_gxw_workspace import run
P=Path(__file__).resolve().parent
OUT=P/'q02-source-holdouts'


def main():
    OUT.mkdir(exist_ok=False)
    (OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    requests=[];predictions=[]
    for case in range(16):
        source=P/f'new-source-holdouts/case-{case:02d}/input.gxw'
        for stream in inspect_project(source.read_bytes()).streams:
            if not (stream.logical_name or '').endswith('.pou'):continue
            raw=stream.raw; frame=frame_token_pou(raw)
            listing=decode_token_listing(raw,text_encoding='cp949',profile='q03udv')
            row=dict(case=f'case-{case:02d}',program=stream.logical_name,source=str(source),source_sha256=sha256(source.read_bytes()),
                program_sha256=sha256(raw),body_sha256=sha256(frame.body),body_bytes=len(frame.body),records=listing_records(listing),
                gaps=len(listing.gaps),hypothesis='Q03UDV lexical grammar transfer; no CPU capability inference')
            predictions.append(row)
            requests.append(dict(mode='decode',input_base64=base64.b64encode(frame.body+b'\0').decode(),program=stream.logical_name,case=row['case']))
    (OUT/'predictions-before-native.json').write_text(json.dumps(predictions,indent=2),encoding='utf-8')
    actual=native_batch(requests,OUT/'native',dll=Q_DLL,cpu_code=34,native_versions=())
    for row,native in zip(predictions,actual):
        row['native']=native
        row['native_full_consumption']=native['return_code']=='0x00000000' and native['consumed_bytes']==row['body_bytes']
        if row['native_full_consumption']:
            projection=native_il_projection(base64.b64decode(native['output_base64']),encoding='cp949')
            row['native_projection']=projection
            row['lexically_identical']=row['records']==projection['records']
            a,b=row['records'],projection['records']
            row['differences']=[dict(index=i,ours=a[i] if i<len(a) else None,native=b[i] if i<len(b) else None)
                for i in range(max(len(a),len(b))) if (a[i] if i<len(a) else None)!=(b[i] if i<len(b) else None)]
    (OUT/'comparison.json').write_text(json.dumps(predictions,indent=2),encoding='utf-8')
    print(json.dumps(dict(programs=len(predictions),instructions=sum(sum(r['kind']=='instruction' for r in row['records']) for row in predictions),
        gaps=sum(r['gaps'] for r in predictions),full_native=sum(r['native_full_consumption'] for r in predictions),
        lexical_matches=sum(r.get('lexically_identical',False) for r in predictions),
        differences=[dict(case=r['case'],program=r['program'],differences=r.get('differences')) for r in predictions if not r.get('lexically_identical')])),flush=True)
    controls=[]
    for case in [4,14,16]:
        source=P/f'new-source-holdouts/case-{case:02d}/input.gxw'; target=OUT/f'case-{case:02d}';target.mkdir()
        candidates={s.logical_name:frame_token_pou(s.raw).body for s in inspect_project(source.read_bytes()).streams if (s.logical_name or '').endswith('.pou')}
        for attempt in range(1,5):
            native=target/f'native-{attempt}'
            outcome=run(source,native,compile=True,program_check=True,export_project=True,snapshot_frontend=True,project_alias='QHOLDOUT')
            events=[json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
            if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
        outputs={p.name:p.read_bytes() for p in native.glob('pcode-*-0.bin')}
        row=dict(case=f'case-{case:02d}',native_directory=str(native),outcome=outcome,
            source_body_matches={name:[n for n,raw in outputs.items() if raw==body] for name,body in candidates.items()})
        controls.append(row);(OUT/'native-project-controls.json').write_text(json.dumps(controls,indent=2),encoding='utf-8')
        print(json.dumps(dict(case=row['case'],full_check=outcome['program_check_completed'],rejected=outcome['compiler_rejected'],
            diagnostics=outcome['diagnostics'],source_body_matches=row['source_body_matches'])),flush=True)


if __name__=='__main__':main()
