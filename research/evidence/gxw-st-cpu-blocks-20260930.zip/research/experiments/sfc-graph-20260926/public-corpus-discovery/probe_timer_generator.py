from pathlib import Path
import sys,json,hashlib
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from replay_gxw_workspace import prepare,trace_prepared
P=Path(__file__).resolve().parent
spec=next(s for s in json.loads((P/'compiler-iec-import-targets.json').read_text()) if s['target_dll']=='DZDataABS_SICConverter_IEC.dll')
cases=[('Q-TON_E',P/'ST-standard-timer-controls/TON_E_true/changed.gxw'),('FX-TON',P/'structured-graph-location-controls/library_fb/native/native-saved.gxw')]
for name,source in cases:
 out=P/'timer-generator-traces'/name
 prepare(source,out,compile=True,export_project=True)
 script=out/'TraceTimerGenerator.js'
 script.write_text('const SIC_IMPORT='+json.dumps(spec)+';\n'+(P/'TraceTimerGenerator.js').read_text()+'\n'+(ROOT/'research/native/CompilerTrace.js').read_text())
 result=trace_prepared(out,script,timeout=45)
 events=[json.loads(s) for s in (out/'events.jsonl').read_text().splitlines()]
 rows=[e['payload'] for e in events if e.get('payload',{}).get('event','').startswith('timer-')]
 summary=dict(trace=result,errors=[e for e in events if e.get('type')=='error'],rows=rows)
 (out/'timer-generated.json').write_text(json.dumps(summary,indent=2))
 print(json.dumps(dict(case=name,trace=result,errors=summary['errors'],dispatch=[r for r in rows if r['event']=='timer-generator-dispatch'],text=[r['text'] for r in rows if r['event']=='timer-generated-text'],locals=[r for r in rows if r['event']=='timer-generator-locals'])),flush=True)
