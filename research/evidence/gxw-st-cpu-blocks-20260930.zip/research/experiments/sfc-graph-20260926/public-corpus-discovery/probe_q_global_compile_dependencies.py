"""Test global type dependencies with no task program and an invalid FB body."""
from pathlib import Path
import json,struct,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.declarations import parse_declarations,edit_declarations,serialize_declarations
from gxw.compiler_tables import parse_compiler_tables
from gxw.compiler_assignment import parse_compiler_assignment
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import run
P=Path(__file__).resolve().parent
out=P/'q-global-compile-dependencies';out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
source=(P/'q-fb-compile-dependencies/bad-uncalled-undeclared/input.gxw').read_bytes()
streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
rows=[]
for case,typename in [('empty-globals',None),('known-global-instance','SCPI'),('unknown-global-instance','NeverFb')]:
    directory=out/case;directory.mkdir();changed=source;edits=[];expected=dict(streams)
    for logical,raw in streams.items():
        if logical.endswith('.tsk'):
            new=raw[:84]+struct.pack('<I',0);changed,receipt=patch_raw(changed,logical,raw,new);edits.append(receipt);expected[logical]=new
    if typename:
        logical='Global1.gh';doc=parse_declarations(streams[logical],logical_name=logical)
        new=serialize_declarations(edit_declarations(doc,upserts=[dict(name='GlobalInstance',data_type=typename,kind='function_block',class_name='VAR_GLOBAL')]))
        changed,receipt=patch_raw(changed,logical,streams[logical],new);edits.append(receipt);expected[logical]=new
    assert {s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}==expected
    path=directory/'input.gxw';path.write_bytes(changed)
    (directory/'mutation.json').write_text(json.dumps(dict(source_sha256=sha256(source),changed_sha256=sha256(changed),type_reference=typename,edits=edits,unrelated_payloads='byte-identical'),indent=2),encoding='utf-8')
    for attempt in range(1,9):
        native=directory/('native' if attempt==1 else 'native-v'+str(attempt))
        result=run(path,native,compile=True,snapshot_frontend=True,export_project=True,project_alias='QGLOBALDEPEND')
        events=[json.loads(s) for s in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
        if (native/'pcode-0-0.bin').exists() or not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
    row=dict(case=case,native_directory=str(native.relative_to(out)),native={k:result[k] for k in ('returncode','open_succeeded','compile_completed','compiler_rejected','diagnostics')})
    if row['native']['returncode']==0 and row['native']['compile_completed'] and not row['native']['compiler_rejected']:
        tables=parse_compiler_tables((native/'compiler_DZComp/CGTable.dat').read_bytes());row['compiled_pous']=[]
        for record in tables.tables[1].records:
            pou=tables.pou_at(record.table_offset);components=tables.components(pou)
            row['compiled_pous'].append(dict(name=pou.name_bytes.decode('cp949'),offset=record.table_offset,components=len(components),
                assigned=sum(parse_compiler_assignment(c.user_info).iec_address is not None for c in components),
                instances=[dict(name=c.name_bytes.decode('cp949'),target=c.instance_pou_offset) for c in components if c.instance_pou_offset is not None]))
        row['pcode']={f.name:dict(bytes=len(f.read_bytes()),sha256=sha256(f.read_bytes()),raw_hex=f.read_bytes().hex()) for f in native.glob('pcode-*.bin')}
    rows.append(row);(directory/'comparison.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
    print(json.dumps(row),flush=True)
(out/'comparison.json').write_text(json.dumps(dict(cases=rows,scope=__doc__),ensure_ascii=False,indent=2),encoding='utf-8')
