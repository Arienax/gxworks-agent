"""Unchosen bit patterns and rounding ties challenge the Q float display model."""
from pathlib import Path
import base64,json,random,struct,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from native_gxw_tokens import native_batch,native_il_projection,Q_DLL
from source_q_float_display import q_float_display
P=Path(__file__).resolve().parent
OUT=P/'q-float-bitpattern-holdouts'


def main():
    OUT.mkdir(exist_ok=False)
    for f in [Path(__file__),P/'source_q_float_display.py']:(OUT/f.name).write_bytes(f.read_bytes())
    rng=random.Random(270934)
    bits={rng.getrandbits(32) for _ in range(4096)}|{0,0x80000000,1,0x7f800000,0xff800000,0x7fc00001,0xffffffff,0x7fffff,0x800000}
    for integer in range(1234500,1234600):
        for value in [integer+.5,-integer-.5]:bits.add(struct.unpack('<I',struct.pack('<f',value))[0])
    plans=[];requests=[]
    for code in [0xec,0xed]:
        for n in sorted(bits):
            raw=bytes([7,code])+struct.pack('<I',n)+b'\x07';row=dict(raw=raw.hex())
            try:row['predicted']=q_float_display(raw)
            except ValueError as exc:row['gap']=str(exc)
            plans.append(row)
            body=bytes.fromhex('054c030205')+raw+bytes.fromhex('04a80004033403')
            requests.append(dict(mode='decode',input_base64=base64.b64encode(body+b'\0').decode()))
    (OUT/'predictions-before-native.json').write_text(json.dumps(plans,indent=2),encoding='utf-8')
    actual=native_batch(requests,OUT/'native',dll=Q_DLL,cpu_code=34,native_versions=())
    results=[]
    for row,answer in zip(plans,actual):
        result=dict(row,return_code=answer['return_code'])
        if answer['return_code']=='0x00000000':
            result['native']=native_il_projection(base64.b64decode(answer['output_base64']),encoding='cp949')['records'][0]['args'][0]
        result['agrees']=(result.get('predicted')==result['native'] if 'native' in result else 'gap' in result)
        results.append(result)
    (OUT/'comparison.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
    differences=[r for r in results if not r['agrees']]
    print(json.dumps(dict(cases=len(results),accepted=sum('native' in r for r in results),differences=len(differences),examples=differences[:30])),flush=True)


if __name__=='__main__':main()
