from pathlib import Path
import json,sys,base64
ROOT=Path.cwd();sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.token_pou import parse_token_region
from gxw.token_listing import decode_token_program
from native_gxw_tokens import native_batch,native_il_projection,listing_records,canonical_record
from gxw.lossless import sha256
P=ROOT/'research/experiments/sfc-graph-20260926/public-corpus-discovery'
OUT=P/'fx3g-real-pcode-lexical';OUT.mkdir(exist_ok=False)
source=P/'fx3g-library-native-baseline/native-1/pcode-0-0.bin'
raw=source.read_bytes();prog=parse_token_region(raw,0,len(raw));listing=decode_token_program(prog,profile='fx3u',text_encoding='cp1252')
starts=[t.offset for t in prog.tokens if t.raw[1]<0x80];ends=[];last=0
for start in starts:
 if start-last>24000:ends.append(prev);last=prev
 prev=start
ends.append(len(raw));chunks=[];last=0
for end in ends: chunks.append((last,end));last=end
req=[dict(mode='decode',input_base64=base64.b64encode(raw[a:b]+b'\0').decode(),source_sha256=sha256(raw),offset=a,length=b-a) for a,b in chunks]
rows=native_batch(req,OUT/'native',cpu_code=521)
native=[]
for (a,b),row in zip(chunks,rows):
 assert row['return_code']=='0x00000000',row
 assert row['consumed_bytes'] in (b-a,b-a+1),row
 proj=native_il_projection(base64.b64decode(row['output_base64']),encoding='cp1252');native+=proj['records'];assert not proj['text_gaps']
(OUT/'native-listing.json').write_text(json.dumps(native,indent=2),encoding='utf-8')
gaps=[]
for r in listing.gaps:
 a=r.tokens[0].offset;i=max(i for i,s in enumerate(starts) if s<=a);begin=starts[i];end=starts[i+1] if i+1<len(starts) else len(raw)
 gaps.append(dict(gap_offset=a,diagnostic=r.diagnostic if hasattr(r,'diagnostic') else r.reason,instruction_offset=begin,hex=raw[begin:end].hex()))
unique=list({g['instruction_offset']:g for g in gaps}.values())
small=native_batch([dict(mode='decode',input_base64=base64.b64encode(bytes.fromhex(g['hex'])+b'\0').decode(),offset=g['instruction_offset']) for g in unique],OUT/'gap-native',cpu_code=521)
for g,r in zip(unique,small):g['native']=native_il_projection(base64.b64decode(r['output_base64']),encoding='cp1252')['records'] if r['return_code']=='0x00000000' else r
result=dict(source_sha256=sha256(raw),bytes=len(raw),cpu_code=521,research_profile='fx3u-hypothesis',chunks=chunks,consumed=[r['consumed_bytes'] for r in rows],native_records=len(native),our_records=len(listing.records),gaps_before=len(gaps),affected_instructions=unique)
(OUT/'comparison-before.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=True))
