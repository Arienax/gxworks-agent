"""Cross-check predicted intermediate states against boundary-only native trace."""
import collections
import json
from pathlib import Path
import source_q_width as q

P=Path(__file__).resolve().parent
def main():
    events=[json.loads(s)['payload'] for s in (P/'q-width-corpus-trace/events.jsonl').read_text().splitlines() if json.loads(s).get('type')=='send']
    counts=collections.Counter();fails=[];operands={};costs={}
    for e in events:
        event=e['event'];rid=e['request']
        try:
            if event=='q-operand-cost':
                d,c=q.operand(bytes.fromhex(e['raw']))
                operands[rid,e['index']-1]=q.validate_descriptor(d)
                costs[rid,e['index']-1]=c
                actual=[d.hex(),c];expected=[e['descriptor'],e['cost']]
            elif event in ('q71-operand-type','q71-compact-operand'):
                d=operands[rid,e['index']]
                fn=q.group_ok if event=='q71-operand-type' else q.compact
                actual=[d.hex(),-int(fn(e['family'],e['variant'],e['index'],d))]
                expected=[e['operand'],e['result']]
            elif event=='q71-application-width':
                ds=[operands[rid,i] for i in range(e['count'])]
                c=sum(costs[rid,i] for i in range(e['count']))
                if (e['family'],e['variant'])!=(0x4c,0):c+=sum(q.group_extra(e['family'],e['variant'],i,d) for i,d in enumerate(ds))
                actual=[''.join(d.hex() for d in ds),c,q.application(e['family'],e['variant'],ds,c)]
                expected=[e['operands'],e['cost'],e['result']]
            else:continue
            counts[event]+=1
            if actual!=expected:fails.append(dict(event=event,request=rid,sequence=e['sequence'],expected=expected,actual=actual))
        except (q.Unsupported,KeyError,IndexError) as exc:
            counts['unsupported']+=1
            fails.append(dict(event=event,request=rid,sequence=e['sequence'],error=str(exc)))
    result=dict(counts=dict(counts),failures=fails)
    out=P/'q-width-stage-comparison.json'
    out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(counts=counts,failures=len(fails),first=fails[:8])))

if __name__=='__main__':main()
