"""Visible host for an isolated replay whose native paste presents a modal.

The native dialog is handled through normal Computer Use, never intercepted.
Only the copied helper source is adapted for an explicit colocated plan.
"""
import hashlib
import json
import os
from pathlib import Path
import subprocess

from replay_gxw_workspace import prepare


def prepare_visible(source, output, **options):
    exe = prepare(source, output, **options)
    output = Path(output).resolve()
    source = output / 'WorkspaceReplayOracle.cs'
    old = 'static void Main(string[] args){'
    new = '''static void Main(string[] args){
        if(args.Length==0)args=new string[]{Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"plan.json")};
        Directory.SetCurrentDirectory(Path.GetDirectoryName(Path.GetFullPath(args[0])));
        var experimentWindow=new System.Windows.Forms.Form();
        experimentWindow.Text="GXW isolated paste experiment";
        experimentWindow.Width=640;experimentWindow.Height=300;
        experimentWindow.Show();System.Windows.Forms.Application.DoEvents();'''
    text = source.read_text(encoding='utf-8')
    if text.count(old) != 1:
        raise ValueError('helper entry point differs')
    source.write_text(text.replace(old, new), encoding='utf-8')
    csc = Path(os.environ['WINDIR']) / 'Microsoft.NET/Framework/v4.0.30319/csc.exe'
    result = subprocess.run([str(csc), '/nologo', '/platform:x86', '/target:winexe',
        '/r:System.Web.Extensions.dll', '/r:System.Windows.Forms.dll', '/out:' + str(exe),
        *[str(output / name) for name in ['WorkspaceReplayOracle.cs',
            'NativeFrontendSnapshot.cs', 'NativeSfcGraphOracle.cs', 'NativeWorkspaceCopyOracle.cs']]],
        capture_output=True, timeout=20)
    (output / 'visible-build.stdout.txt').write_bytes(result.stdout)
    (output / 'visible-build.stderr.txt').write_bytes(result.stderr)
    result.check_returncode()
    request = json.loads((output / 'request.json').read_text())
    request.update(source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
        launch='own visible WinForms host; colocated plan.json; native modal behavior unchanged')
    (output / 'request.json').write_text(json.dumps(request, indent=2) + '\n')
    return exe
