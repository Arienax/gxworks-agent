"""Follow the separate 200-slot expression temporary manager."""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from probe_minimal_conditional_port_writes import observe,save
from probe_gxw_program_check_resources import SCRIPT
P=Path(__file__).resolve().parent
OUT=P/'expression-slot-transitions-20260930'


def main():
    assert sha256(Path('D:/GXWORKS2/Easysocket/Compiler/ECCompiler_IEC.dll').read_bytes())=='f58e7c70b855526bf2f943399a14089f771a43109b13ee9af34c88fb065cf4d7'
    OUT.mkdir(exist_ok=False);(OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    trace=OUT/'trace.js';trace.write_text('(()=>{'+(P/'native-allocation-bitmap-v2/observer.js').read_text()+'\n'+(P/'observe_expression_temporaries.js').read_text()+'\n})();\n(()=>{'+SCRIPT+'\n})();',encoding='utf-8')
    rows=[]
    for case in ('array-both','scalar-both'):
        old=P/'expression-temp-lifetimes-20260930'/case;d=OUT/case;d.mkdir()
        native,checked,process=observe(old/'input.gxw',d,trace)
        messages=[json.loads(l) for l in (native/'events.jsonl').read_text().splitlines()]
        events=[m['payload'] for m in messages if m.get('type')=='send']
        errors=[m for m in messages if m.get('type')=='error' or 'error' in m.get('payload',{}).get('event','') or m.get('payload',{}).get('observation_error')]
        prior=next(r for r in json.loads((old.parent/'comparison.json').read_text()) if r['case']==case)
        code=(native/'pcode-0-0.bin').read_bytes()
        row=dict(case=case,native_directory=str(native),check=checked['check'],diagnostics=checked['diagnostics'],process=process,
            trace_errors=errors,prior_identical=sha256(code)==prior['pcode_sha256'],
            temporary_events=[e for e in events if e.get('event','').startswith('temporary-')])
        rows.append(row);save(OUT/'comparison.json',rows)
        print(json.dumps(dict(case=case,check=row['check'],prior_identical=row['prior_identical'],errors=errors,
          events=[{k:v for k,v in e.items() if k in ('event','name','args','result','output','before_counters','after_counters','caller')} for e in row['temporary_events'] if e.get('name')!='reset-slots'])),flush=True)
        if errors:raise RuntimeError('temporary observation failed; retained')


if __name__=='__main__':main()
