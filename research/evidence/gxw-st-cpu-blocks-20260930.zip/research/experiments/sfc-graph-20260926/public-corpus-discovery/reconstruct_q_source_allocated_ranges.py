"""Build complete MAIN candidates without consuming native assigned CGTables."""
from pathlib import Path
import base64,json,re,subprocess,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.compiler_tables import parse_compiler_tables
from gxw.token_pou import parse_token_fragment
from gxw.project_metadata import read_project_text_context
from probe_gxw_simple_fb import frame_source
from probe_gxw_compiled_references import stored_records
from probe_gxw_operand_bindings import resolve_simple_instance_label,observed_q_address
from probe_gxw_parameters import device_allocation_record
from source_q_allocation import predict,groups
P=Path(__file__).resolve().parent
OUT=P/'q-source-allocated-range-reconstruction';OUT.mkdir(exist_ok=False)
(OUT/'probe.py').write_bytes(Path(__file__).read_bytes());(OUT/'source_q_allocation.py').write_bytes((P/'source_q_allocation.py').read_bytes())
plans=[r for r in json.loads((P/'native-allocation-range-holdouts/comparison.json').read_text()) if not r['baseline']['compiler_rejected']]
def scalar(family,number):
 codes={'SM':0x91,'M':0x90,'D':0xa8,'T':0xc2,'C':0xc5,'X':0x9c,'Y':0x9d,'W':0xb4,'B':0xa0}
 n=max(1,(number.bit_length()+7)//8)
 if family not in codes or number<0 or n>2:raise ValueError('unrecovered scalar operand encoding')
 return bytes([n+3,codes[family]])+number.to_bytes(n,'little')+bytes([n+3])
results=[]
for plan in plans:
 source=Path(plan['source']).read_bytes();streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
 context=read_project_text_context(next(v for k,v in streams.items() if k.endswith('.prj')));assert context['cpu']=='Q03UDV'
 predicted=predict(streams,scpi_calls=True);tables=predicted['tables'];directory=OUT/plan['case'];directory.mkdir()
 (directory/'predicted-CGTable.bin').write_bytes(predicted['raw'])
 # Counterfactual: every stored assignment is poisoned before predicting.
 poison=bytearray(streams['CGTable.dat']);old=parse_compiler_tables(bytes(poison))
 for r in old.tables[2].records:poison[r.offset+len(r.raw)-26:r.offset+len(r.raw)]=bytes([0xfe])*26
 again=predict(dict(streams,**{'CGTable.dat':bytes(poison)}),scpi_calls=True)
 assert again['raw']==predicted['raw'] and again['allocations']==predicted['allocations']
 (directory/'source-allocation.json').write_text(json.dumps(dict(source_sha256=sha256(source),allocations=predicted['allocations'],stored_assignment_poison_invariant=True),indent=2))
 frame=frame_source(streams['MAIN.Program.pou']);parts=[];requests=[];substitutions=[]
 allocated={a['component_offset']:a for a in predicted['allocations']}
 def simple_label(label):
  hits=[]
  for r in tables.tables[1].records:
   pou=tables.pou_at(r.table_offset)
   if pou.name_bytes not in [b'MAIN',b'@GLOBALS']:continue
   for c in tables.components(pou):
    if c.name_bytes.lower()!=label.lower():continue
    if c.record.table_offset in allocated:
     a=allocated[c.record.table_offset];hits.append(scalar(a['family'],a['number']))
    else:
     off=tables.component_address_offset(c);assert off>=0
     a=observed_q_address(tables.address_at(off).iec_address_bytes);assert a['handling']!='opaque' and not a.get('addressing')
     hits.append(scalar(a['family'],a['number']))
  if not hits or len(set(hits))!=1:raise ValueError('unresolved simple label')
  return hits[0]
 def emit(raw,instance=None,aliases=None,placeholder=False):
  tokens=parse_token_fragment(raw,0,len(raw)).tokens;changed=[];n=0
  for t in tokens:
   if t.raw[1]!=0xdf:changed.append(t.raw);continue
   label=t.raw[2:-1];key=label.decode(context['text_encoding'])
   if placeholder:
    if not key.startswith('_'):raise ValueError('caller label lacks placeholder')
    key=key[1:]
   if aliases and key.lower() in aliases:encoded=aliases[key.lower()];origin='caller-raw-alias'
   elif key=='TRUE' and placeholder:encoded=scalar('SM',400);origin='observed-TRUE'
   elif instance is not None:
    match=re.fullmatch(r'([^\[\]]+)(?:\[(-?[0-9]+(?:\s*,\s*-?[0-9]+)*)\])?',key)
    if not match:raise ValueError('unrecovered instance label grammar')
    pou=tables.pou_at(tables.component_instance_pou_offset(tables.component_at(instance)))
    members=[c for c in tables.components(pou) if c.name_bytes.lower()==match[1].encode('ascii').lower()]
    if len(members)!=1:raise ValueError('instance member not unique')
    component=members[0];allocation=allocated[component.record.table_offset];relative=0
    if match[2] is not None:
     array=tables.array_at(tables.component_array_offset(component));indices=[int(v) for v in match[2].split(',')]
     if len(indices)!=len(array.dimensions):raise ValueError('array index rank')
     for value,dimension in zip(indices,array.dimensions):
      ix=value-dimension.lower
      if not 0<=ix<dimension.extent:raise ValueError('array index bound')
      relative=relative*dimension.extent+ix
     if allocation['count']%array.total_count:raise ValueError('fractional element size')
     relative*=allocation['count']//array.total_count
    encoded=scalar(allocation['family'],allocation['number']+relative);origin='predicted-instance-allocation'
   else:encoded=simple_label(label);origin='source-declaration'
   changed.append(encoded);n+=1;substitutions.append(dict(label_hex=label.hex(),output=encoded.hex(),origin=origin))
  value=b''.join(changed);index=len(parts);parts.append(value)
  if n:requests.append(dict(index=index,raw=value.hex(),input_base64=base64.b64encode(value).decode()))
 def emit_fragment(raw,**kwargs):
  for g in groups(raw):emit(b''.join(g),**kwargs)
 if not predicted['calls']:emit_fragment(frame.body)
 else:
  cursor=frame.tokens[0].offset
  for call in predicted['calls']:
   c=call['call'];emit_fragment(frame.raw[cursor:c['offset']])
   for item in call['materialized']:
    for g in item['groups']:emit(b''.join(g),instance=call['instance_offset'],aliases=call['aliases'],placeholder=True)
   body=frame_source(streams[c['definition']+'.Program.pou']);emit_fragment(body.body,instance=call['instance_offset'],aliases=call['aliases'])
   cursor=c['offset']+c['length']
  emit_fragment(frame.raw[cursor:frame.tokens[0].offset+len(frame.body)])
 device_context=device_allocation_record(streams['Param.wpa']).raw;(directory/'device-context.bin').write_bytes(device_context)
 (directory/'requests.json').write_text(json.dumps(dict(source_sha256=sha256(source),cpu=209,versions=[1],device_context_sha256=sha256(device_context),requests=requests,bindings=substitutions),indent=2))
 protocol=''.join(f"check-instruction\t{i}\t{r['input_base64']}\n" for i,r in enumerate(requests))
 run=subprocess.run([str(P/'q-public-check-replay/PublicCheckOracle.exe'),'D:/GXWORKS2/Easysocket/CodeGenerator/ECCodeGenerator2.dll','209','1','q','1',str(directory/'device-context.bin')],input=protocol.encode(),capture_output=True,timeout=45,creationflags=subprocess.CREATE_NO_WINDOW)
 (directory/'stdout.jsonl').write_bytes(run.stdout);(directory/'stderr.bin').write_bytes(run.stderr)
 answers=[json.loads(l) for l in run.stdout.splitlines()];assert run.returncode==0 and len(answers)==len(requests)
 for req,answer in zip(requests,answers):assert answer['return_code']=='0x00000000';parts[req['index']]=base64.b64decode(answer['output_base64'])
 output=b''.join(parts);(directory/'predicted-pcode.bin').write_bytes(output)
 # Native output is first read here, after all predicted bytes are fixed.
 baseline=Path(plan['baseline_directory']);native=(baseline/'pcode-0-0.bin').read_bytes()
 nt=parse_compiler_tables(next(s.raw for s in inspect_project((baseline/'native-saved.gxw').read_bytes()).streams if s.logical_name=='CGTable.dat'))
 allocation_exact=[nt.component_at(a['component_offset']).user_info.hex()==a['raw'] for a in predicted['allocations']]
 row=dict(case=plan['case'],source=str(Path(plan['source']).resolve()),source_sha256=sha256(source),records=len(parts),bindings=len(substitutions),allocations=len(allocation_exact),allocations_exact=sum(allocation_exact),stored_assignment_poison_invariant=True,source_parameter_context=True,uses_postallocation_table=False,predicted_sha256=sha256(output),native_sha256=sha256(native),byte_identical=output==native,scope='Source-only address prediction for bounded direct globals/locals, arrays and SCPI call profile. Public native Q instruction-width check still used. No independent execution validation.')
 (directory/'comparison.json').write_text(json.dumps(row,indent=2));results.append(row);(OUT/'comparison.json').write_text(json.dumps(results,indent=2));print(json.dumps(row),flush=True)
 if not row['byte_identical'] or not all(allocation_exact):raise ValueError('prediction disagrees; preserve counterexample')
