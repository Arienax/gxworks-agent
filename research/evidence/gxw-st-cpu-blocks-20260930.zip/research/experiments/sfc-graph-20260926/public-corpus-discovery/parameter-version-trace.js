// Read-only instruction/call observations for the pinned Workspace DLL.
function where(p){try{const m=Process.findModuleByAddress(p);return m?{module:m.name,rva:p.sub(m.base).toString()}:p.toString();}catch(e){return String(e);}}
function u32(p){try{return p.readU32();}catch(_){return null;}}
function buf(p,n){try{return Array.from(new Uint8Array(p.readByteArray(n)));}catch(_){return null;}}
function observe(m){
 if(m.name.toLowerCase().includes('navi'))send({event:'navi_module',name:m.name,path:m.path,base:m.base.toString()});
 if(m.name.toLowerCase()==='dzdatanavigatorserver.dll')Interceptor.attach(m.base.add(0x23f70),{onEnter(a){send({event:'set_parameter_version',version:a[1].toUInt32(),group:a[2].toInt32(),caller:where(this.returnAddress),stack:Thread.backtrace(this.context,Backtracer.ACCURATE).slice(0,10).map(where)});}});
 if(m.name.toLowerCase()==='_dnavi.dll'){
  const attached=new Set();
  Interceptor.attach(m.base.add(0xdd70),{onEnter(a){this.out=a[0];send({event:'dnavi_version_enter',self:this.context.ecx.toString(),bytes:buf(this.context.ecx,100)});},onLeave(r){send({event:'dnavi_version_leave',return_value:r.toString(),version:u32(this.out)});}});
  Interceptor.attach(m.base.add(0xdd95),function(){const obj=this.context.eax;const target=obj.readPointer().add(0x21c).readPointer();send({event:'version_backend',object:obj.toString(),target:where(target),bytes:buf(obj,100)});if(attached.has(target.toString()))return;attached.add(target.toString());Interceptor.attach(target,{onEnter(a){this.out=a[0];send({event:'version_backend_enter',self:this.context.ecx.toString(),arg:a[0].toString()});},onLeave(r){send({event:'version_backend_leave',result:r.toString(),version:u32(this.out)});}});});
 }
 if(m.name.toLowerCase()==='dzdatanavigatorserver.dll')Interceptor.attach(m.base.add(149107),{onEnter(a){this.group=a[2].toInt32();try{send({event:'cpu_selection',group:this.group,cpu:a[1].readPointer().readUtf16String()});}catch(_){}},onLeave(r){send({event:'cpu_selected',group:this.group,result:r.toString()});}});
 if(m.name.toLowerCase()!=='dzdataabs_workspace.dll')return;
 Interceptor.attach(m.base.add(0x85985),{onEnter(a){this.version=a[1];this.code=a[2];send({event:'parameter_version_enter',self:a[0].toString(),version:u32(a[1]),code:u32(a[2])});},onLeave(r){send({event:'parameter_version_leave',hresult:r.toString(),version:u32(this.version),code:u32(this.code)});}});

 const attached=new Set();
 for(const [rva,name,slot] of [[0x85a2f,'initialize',28],[0x85a4e,'read_version',280]])Interceptor.attach(m.base.add(rva),function(){const obj=this.context.eax;const target=obj.readPointer().add(slot).readPointer();send({event:'parameter_version_target',name,target:where(target),object:obj.toString(),object_bytes:buf(obj,64)});if(attached.has(target.toString()))return;attached.add(target.toString());Interceptor.attach(target,{onEnter(a){this.out=a[1];this.obj=a[0];send({event:'parameter_component_enter',name,args:[a[0],a[1],a[2],a[3]].map(x=>x.toString()),object_bytes:buf(a[0],64)});},onLeave(r){send({event:'parameter_component_leave',name,hresult:r.toString(),out:u32(this.out),object_bytes:buf(this.obj,64)});}});});
 send({event:'parameter_version_hooks',module:m.name,base:m.base.toString()});
}
Process.attachModuleObserver({onAdded:observe});
