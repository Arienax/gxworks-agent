"""Inspect the pinned Q converter's descriptor lookup without touching a project."""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path.insert(0,str(ROOT/'research/experiments/re-tools'))
import pefile,capstone
P=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output',default='q-instruction-query-initial')
parser.add_argument('--queries',type=Path)
args=parser.parse_args()
out=P/args.output;out.mkdir(exist_ok=False)
dll=Path('D:/GXWORKS2/Easysocket/CodeGenerator/ECCodeGenerator2.dll')
digest=hashlib.sha256(dll.read_bytes()).hexdigest()
assert digest=='2e5c47b0a0d0b59eb26dbab149862a05983a1fa9519a75e446bc680e7cc16f73'
queries=json.loads(args.queries.read_text()) if args.queries else [[0,0],[0x34,0],[0x64,0],[0x21,0],[0x40,0],[0x49,0x22]]
(out/'requests.json').write_text(json.dumps(dict(dll_sha256=digest,cpu=209,queries=queries),indent=2))
source=out/'QueryInstructionCatalog.cs';source.write_bytes((P/source.name).read_bytes())
exe=out/'QueryInstructionCatalog.exe'
compiler=Path('C:/Windows/Microsoft.NET/Framework/v4.0.30319/csc.exe')
build=subprocess.run([str(compiler),'/nologo','/platform:x86','/out:'+str(exe),str(source)],capture_output=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
(out/'build.stdout.txt').write_bytes(build.stdout);(out/'build.stderr.txt').write_bytes(build.stderr)
assert build.returncode==0
run=subprocess.run([str(exe),str(dll)],input=''.join(f'{a}\t{b}\n' for a,b in queries).encode(),capture_output=True,timeout=45,creationflags=subprocess.CREATE_NO_WINDOW)
(out/'native-stdout.jsonl').write_bytes(run.stdout);(out/'native-stderr.bin').write_bytes(run.stderr)
(out/'process.json').write_text(json.dumps(dict(returncode=run.returncode,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),exe_sha256=hashlib.sha256(exe.read_bytes()).hexdigest()),indent=2))
assert run.returncode==0
rows=[json.loads(s) for s in run.stdout.splitlines()];assert len(rows)==len(queries)
pe=pefile.PE(str(dll));im=pe.get_memory_mapped_image();base=pe.OPTIONAL_HEADER.ImageBase
md=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32)
for address,size in [(0x60b9,0x20),(0x47e9,0x18),(0x8806,0x50),(0x2bc6b,0xd0),(0x3e7c7,0x501)]:
 (out/(hex(address)+'.txt')).write_text('\n'.join(f'{i.address-base:08x}: {i.mnemonic} {i.op_str}' for i in md.disasm(im[address:address+size],base+address)))
print(json.dumps(dict(queries=len(rows),accepted=sum(r['result']=='0x00000000' for r in rows),active_cpu_words=sorted({r['active_cpu_word'] for r in rows}))))
if len(rows)<10:print(json.dumps(rows))
