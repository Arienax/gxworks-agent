// Read-only error-site capture in an owned offline helper.
function label(address) {
  const module=Process.findModuleByAddress(address);
  return module ? module.name+'+'+address.sub(module.base) : address.toString();
}
function bytes(address,length) {
  try {return Array.from(new Uint8Array(address.readByteArray(length)),x=>x.toString(16).padStart(2,'0')).join('');}
  catch (_) {return null;}
}
Process.attachModuleObserver({onAdded(module) {
  if(module.name.toLowerCase()!=='dzdataabs_sicconverter_iec.dll')return;
  send({event:'module',name:module.name,base:module.base.toString(),size:module.size});
  Interceptor.attach(module.base.add(0x7e4d6),{onEnter(args) {
    const code=args[0].toUInt32();
    if(code!==0x500c5034)return;
    send({event:'array-type-rejection',code:code.toString(16),return_site:label(this.returnAddress),
      registers:{eax:this.context.eax.toString(),ebx:this.context.ebx.toString(),ecx:this.context.ecx.toString(),
        edx:this.context.edx.toString(),esi:this.context.esi.toString(),edi:this.context.edi.toString()},
      frame_minus_0x200:bytes(this.context.ebp.sub(0x200),0x200),
      backtrace:Thread.backtrace(this.context,Backtracer.ACCURATE).slice(0,14).map(label)});
  }});
}});
