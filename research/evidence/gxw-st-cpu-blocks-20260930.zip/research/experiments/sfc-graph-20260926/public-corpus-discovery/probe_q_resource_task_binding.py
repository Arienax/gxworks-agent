"""Swap existing resource-to-task references without changing any source POU.

Two existing resources are selected from the input. Only their counted .res
suffix names are exchanged; their stale compiled code copies remain intact
before the isolated native rebuild. This distinguishes references from names.
"""
from pathlib import Path
import base64, json, struct, sys
ROOT = Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.container_writer import validate_cfb_streams
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import run
from native_gxw_tokens import native_batch,native_il_projection,Q_DLL

P=Path(__file__).resolve().parent
out=P/'q-resource-task-binding-v2';out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
source=(P/'q-source-constant-edits/baseline-1/source.gxw').read_bytes()
assert not validate_cfb_streams(source).get('Project.gd2')
streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
def resource(raw):
    cursor=54;spans=[]
    for _ in range(2):
        size=struct.unpack_from('<I',raw,cursor)[0];start=cursor+4;end=start+size
        assert end+8<=len(raw) and not any(raw[end:end+8]);spans.append((start,size));cursor=end+8
    assert struct.unpack_from('<I',raw,cursor)[0]==1
    count=struct.unpack_from('<I',raw,cursor+4)[0]
    text=raw[cursor+8:cursor+8+count*2].decode('utf-16le');assert text.endswith('\0') and '\0' not in text[:-1]
    end=cursor+8+count*2;assert raw[end:]==struct.pack('<II',4,1)
    return dict(reference=text[:-1],suffix_offset=cursor,name_offset=cursor+4,name_end=end,code_spans=spans)
resources={name:resource(raw) for name,raw in streams.items() if name.endswith('.res')}
assert len(resources)>=2
names=sorted(resources);a,b=names[:2]
modified=source;receipts=[];expected=dict(streams)
for name,other in [(a,b),(b,a)]:
    raw=streams[name];item=resources[name];target=resources[other]['reference'];assert target+'.tsk' in streams
    encoded=(target+'\0').encode('utf-16le')
    new=raw[:item['name_offset']]+struct.pack('<I',len(encoded)//2)+encoded+raw[item['name_end']:]
    assert resource(new)['reference']==target and new[:item['name_offset']]==raw[:item['name_offset']]
    modified,receipt=patch_raw(modified,name,raw,new);receipts.append(dict(resource=name,old=item['reference'],new=target,receipt=receipt));expected[name]=new
assert {s.logical_name:s.raw for s in inspect_project(modified).streams if s.logical_name}==expected
(out/'mutation.json').write_text(json.dumps(dict(input_sha256=sha256(source),output_sha256=sha256(modified),resources=resources,receipts=receipts,
    preservation='All source POUs, declarations, tasks and preexisting compiled code bytes are unchanged before native rebuild.'),indent=2),encoding='utf-8')
rows=[];requests=[];files={}
for case,data in [('baseline',source),('swapped',modified)]:
    directory=out/case;directory.mkdir();path=directory/'input.gxw';path.write_bytes(data)
    for attempt in range(1,9):
        native=directory/('native' if attempt==1 else 'native-v'+str(attempt))
        result=run(path,native,compile=True,snapshot_frontend=True,export_project=True,project_alias='QRESOURCEBIND')
        events=[json.loads(s) for s in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
        if (native/'pcode-0-0.bin').exists() or not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
    row=dict(case=case,native_directory=str(native.relative_to(out)),native={k:result[k] for k in ('returncode','open_succeeded','compile_completed','compiler_rejected','diagnostics')})
    snapshot=json.loads((native/'frontend-snapshot.json').read_text(encoding='utf-8-sig'))
    pool=next(r['data'] for r in snapshot['build']['relocations'] if r['offset']==36)
    task_buffer=base64.b64decode(pool['raw']); task_rows=[]
    for offset in range(0,len(task_buffer),24):
        fields={}
        for field,label in [(0,'task'),(12,'resource')]:
            blob=next(r['data'] for r in pool['relocations'] if r['offset']==offset+field)
            fields[label]=base64.b64decode(blob['raw']).rstrip(b'\0').decode('cp949')
        task_rows.append(fields)
    row['native_task_bindings']=task_rows
    row['native_resources']=[dict(index=e['index'],name=e['name']) for e in events if e.get('operation')=='Resource']
    if row['native']['compile_completed'] and not row['native']['compiler_rejected']:
        files[case]={}
        for f in sorted(native.glob('pcode-*.bin')):
            raw=f.read_bytes();files[case][f.name]=len(requests)
            requests.append(dict(mode='decode',input_base64=base64.b64encode(raw+b'\0').decode()))
    rows.append(row);(directory/'comparison.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
    print(json.dumps(row),flush=True)
answers=native_batch(requests,out/'native-pcode-decode',dll=Q_DLL,cpu_code=209)
decoded=[]
for request,answer in zip(requests,answers,strict=True):
    assert answer['return_code']=='0x00000000' and answer['consumed_bytes']==len(base64.b64decode(request['input_base64']))-1
    projection=native_il_projection(base64.b64decode(answer['output_base64']),encoding='cp949');assert not projection['text_gaps']
    decoded.append(projection['records'])
result=dict(cases=rows,files=files,decoded=decoded,scope=__doc__)
with (out/'comparison.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2,ensure_ascii=False)
print(json.dumps(dict(record_counts={case:{name:len(decoded[i]) for name,i in files.items()} for case,files in files.items()})),flush=True)
