"""Cross-check portable compile-root graphs against independent native inventories."""
from pathlib import Path
import json, sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from probe_gxw_task_graph import inspect_task_graph
from gxw.lossless import sha256
P=Path(__file__).resolve().parent
out=P/'q-task-graph-crosscheck-v2';out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
reference=json.loads((P/'q-task-reference-corpus-v2/comparison.json').read_text(encoding='utf-8'))
rows=[]
def bindings(graph):
    return sorted((r['resource'][:-4],r['task'][:-4]) for r in graph['resources'])
for index,old in enumerate(reference['projects']):
    source=(P/old['file']).read_bytes();graph=inspect_task_graph(source)
    native=old['native_task_inventory']
    checked=native is not None and native['complete']
    exact=bindings(graph)==sorted((r['resource'],r['task']) for r in native['tasks']) if checked else None
    assert exact is not False
    assert not graph['gaps']
    (out/f'graph-{index:02d}.json').write_text(json.dumps(graph,ensure_ascii=False,indent=2),encoding='utf-8')
    rows.append(dict(file=old['file'],sha256=graph['project_sha256'],tasks=len(graph['tasks']),
        resources=len(graph['resources']),programs=len(graph['programs']),entries=sum(len(t['entries']) for t in graph['tasks'].values()),
        native_exact=exact,gaps=graph['gaps']))
controls=[]
for experiment in ['q-task-st-order','q-resource-task-binding-v2','q-resource-folder-binding','q-label-owner-binding-v2','q-pou-name-binding']:
    result=json.loads((P/experiment/'comparison.json').read_text(encoding='utf-8'))
    for case in result['cases']:
        folder=P/experiment/case['case'];path=folder/('changed.gxw' if experiment=='q-task-st-order' else 'input.gxw')
        graph=inspect_task_graph(path.read_bytes())
        assert not graph['gaps']
        native=case.get('native_task_bindings')
        exact=bindings(graph)==sorted((r['resource'],r['task']) for r in native) if native is not None else None
        assert exact is not False
        (out/(experiment+'-'+case['case']+'.json')).write_text(json.dumps(graph,ensure_ascii=False,indent=2),encoding='utf-8')
        controls.append(dict(experiment=experiment,case=case['case'],bindings=bindings(graph),native_exact=exact,
            tasks={name:[(e['program_reference'],e['stored_order']) for e in task['entries']] for name,task in graph['tasks'].items()}))
def pcode(experiment,case):
    result=json.loads((P/experiment/'comparison.json').read_text(encoding='utf-8'))
    row=next(r for r in result['cases'] if r['case']==case)
    directory=P/experiment/row['native_directory']
    return {f.name:f.read_bytes() for f in sorted(directory.glob('pcode-*.bin'))}
equivalence={}
equivalence['ST_serialized_permutation']=pcode('q-task-st-order','two-ST')==pcode('q-task-st-order','two-ST-shuffle')
equivalence['resource_cached_name_swap']=pcode('q-resource-task-binding-v2','baseline')==pcode('q-resource-task-binding-v2','swapped')
a=pcode('q-resource-folder-binding','baseline');b=pcode('q-resource-folder-binding','swapped')
equivalence['resource_folder_swap']={name:a[name]==b[{'pcode-0-0.bin':'pcode-1-0.bin','pcode-1-0.bin':'pcode-0-0.bin'}.get(name,name)] for name in a}
result=dict(summary=dict(projects=len(rows),tasks=sum(r['tasks'] for r in rows),entries=sum(r['entries'] for r in rows),
    programs=sum(r['programs'] for r in rows),native_checked=sum(r['native_exact'] is not None for r in rows),native_exact=sum(r['native_exact'] is True for r in rows)),
    projects=rows,controls=controls,pcode_equivalence=equivalence,reader_sha256=sha256((ROOT/'research/probe_gxw_task_graph.py').read_bytes()))
(out/'comparison.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(summary=result['summary'],controls=controls,pcode_equivalence=equivalence)))
