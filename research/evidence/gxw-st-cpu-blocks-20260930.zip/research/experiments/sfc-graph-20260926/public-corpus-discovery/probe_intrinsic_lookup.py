from pathlib import Path
import json,sys,hashlib
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from replay_gxw_workspace import prepare,trace_prepared
P=Path(__file__).resolve().parent
assert hashlib.sha256(Path('D:/GXWORKS2/Easysocket/Compiler/ECCompiler_IEC.dll').read_bytes()).hexdigest()=='f58e7c70b855526bf2f943399a14089f771a43109b13ee9af34c88fb065cf4d7'
for name,source in [('TON_E',P/'ST-standard-timer-controls/TON_E_true/changed.gxw'),('alias-TON_E',P/'library-fb-alias-controls/TON_E/changed.gxw')]:
 out=P/'intrinsic-name-lookup-v2'/name
 prepare(source,out,compile=True,export_project=True)
 print(name,json.dumps(trace_prepared(out,P/'TraceIntrinsicLookup.js',timeout=45)),flush=True)
 rows=[json.loads(line).get('payload',{}) for line in (out/'events.jsonl').read_text(encoding='utf-8').splitlines()]
 selected=[r for r in rows if 'TON' in r.get('name','') or 'CTU' in r.get('name','')]
 print(json.dumps(dict(events=len(rows),selected=selected)),flush=True)
