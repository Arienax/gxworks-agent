"""Competing source-only allocation hypotheses for small multi-program ST probes.

Not a general ST compiler. No cache, native output, or allocation trace input.
"""
import re
from gxw.project_metadata import read_project_text_context
from probe_gxw_task_graph import inspect_task_graph
from probe_gxw_st_sources import replace_observed_st
from probe_minimal_conditional_port_writes import streams
from source_q_direct_declarations import DirectDeclarations
from source_q_st_expressions import expression
from source_q_label_binding import scalar, integer16
from source_q_width import rewrite
from probe_gxw_simple_fb import frame_source, observe_calls
from source_q_allocation import groups


def predict(source, declaration_stage, slot_scope):
    content={k:v for k,v in streams(source).items() if k!='CGTable.dat'}
    context=read_project_text_context(next(v for k,v in content.items() if k.endswith('.prj')))
    assert context['cpu']=='Q03UDV'
    graph=inspect_task_graph(source);assert not graph['gaps']
    resources=sorted(graph['resources'],key=lambda r:r['resource'].encode(context['text_encoding']))
    programs=[[e['program_reference'] for e in sorted(graph['tasks'][r['task']]['entries'],key=lambda e:e['stored_order'])] for r in resources]
    decl=DirectDeclarations(content,context['text_encoding']);slots=[];events=[];result=[]
    assert all(decl.ranges[f]['handling']=='unset' for f in ('W','R','ZR'))
    if declaration_stage=='project':
        for names in programs:
            for name in names:decl.add_owner(name)
    def emit(op,variant,*raw):return rewrite(bytes([5,op,3,variant,5])+b''.join(raw))
    for resource,names in zip(resources,programs,strict=True):
        if slot_scope=='resource':slots=[]
        if declaration_stage=='resource':
            for name in names:decl.add_owner(name)
        records=[]
        for owner in names:
            if declaration_stage=='program':decl.add_owner(owner)
            if slot_scope=='program':slots=[]
            raw_source=content[owner+'.Program.pou']
            if raw_source[54]==1:
                assert len(names)==1, 'Mixed language within a resource remains unsupported'
                frame=frame_source(raw_source);calls=observe_calls(frame)
                assert not calls['gaps'] and not calls['calls']
                for tokens in groups(frame.body):
                    bound=[decl.bind(owner,t[2:-1]) if t[1]==0xdf else t for t in tokens]
                    raw=b''.join(bound)
                    records.append(rewrite(raw) if bound!=tokens else raw)
                continue
            records.append(bytes.fromhex('0300030591900105'))
            def variable(name):
                item=decl.bound[owner][name.casefold()]
                assert item['row'].data_type=='INT' and item['row'].class_code==1
                return decl.bind(owner,name.encode(context['text_encoding'])),None
            def acquire():
                for i,s in enumerate(slots):
                    if not s['live']:
                        s['live']=True;events.append(dict(owner=owner,action='reuse',number=s['number']));return s['raw'],i
                family,number,_=decl.allocate('D',1,fixed_pool='D')
                slots.append(dict(raw=scalar(family,number),number=number,live=True))
                events.append(dict(owner=owner,action='create',number=number));return slots[-1]['raw'],len(slots)-1
            def release(v):
                if v[1] is not None:assert slots[v[1]]['live'];slots[v[1]]['live']=False
            def lower(node,dest=None):
                if isinstance(node,str):return variable(node)
                if isinstance(node,int):return integer16(node),None
                op,a,b=node;assert op in ('+','-')
                lhs=lower(a);rhs=lower(b);target=dest if dest else acquire()
                records.append(emit(0x49,1 if op=='+' else 3,lhs[0],rhs[0],target[0]))
                release(lhs);release(rhs);return target
            _,text=replace_observed_st(content[owner+'.Program.pou'],'')
            for statement in text.split(';'):
                if not statement.strip():continue
                m=re.fullmatch(r'\s*([A-Za-z_][A-Za-z_0-9]*)\s*:=\s*(.*?)\s*',statement,re.S);assert m
                target=variable(m[1]);node=expression(m[2])
                if isinstance(node,(str,int)):
                    value=lower(node);records.append(emit(0x4c,0,value[0],target[0]))
                else:lower(node,target)
        ending=b'' if content[names[-1]+'.Program.pou'][54]==1 else bytes.fromhex('033303020204340204')
        result.append(dict(resource=resource['resource'],programs=names,
            output=b''.join(records)+ending))
    return result,dict(declaration_stage=declaration_stage,slot_scope=slot_scope,allocations=decl.allocations,temporary_events=events)
