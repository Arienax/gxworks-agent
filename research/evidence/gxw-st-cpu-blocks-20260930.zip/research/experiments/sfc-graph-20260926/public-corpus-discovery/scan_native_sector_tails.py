"""Measure omitted EOF padding across saved native artifacts and source samples."""
from pathlib import Path
import hashlib,io,json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.container import CompoundFile
from gxw.project_metadata import logical_mapping
import olefile
P=Path(__file__).resolve().parent
class StrictSectorReader(CompoundFile):
 def _sector(self,sector_id,*,byte_count=None):
  return super()._sector(sector_id) # Pre-fix whole-sector requirement.
paths=sorted(set(P.rglob('native-saved.gxw'))|set((P/'samples').glob('*.gxw')))
rows=[];affected=[]
for path in paths:
 raw=path.read_bytes();row=dict(path=str(path.relative_to(P)),kind='source-sample' if path.parent==P/'samples' else 'native-export',
                              sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
 rows.append(row)
 try:
  outer=CompoundFile(raw);inner=outer.read_stream('_hdb');cfb=CompoundFile(inner)
  row.update(nested_bytes=len(inner),nested_tail_bytes=len(inner)%cfb.sector_size)
  if not row['nested_tail_bytes']:continue
  mapping={v:k for k,v in logical_mapping(outer.read_stream('projectdatalist.xml')).items()}
  strict=StrictSectorReader(inner);recovered=[]
  with olefile.OleFileIO(io.BytesIO(inner)) as independent:
   for entry in cfb.iter_streams():
    try:strict.read_entry(entry)
    except ValueError as exc:
     body=cfb.read_entry(entry);external=independent.openstream(entry.name).read()
     recovered.append(dict(logical_name=mapping.get(entry.name),physical_name=entry.name,bytes=len(body),
                           sha256=hashlib.sha256(body).hexdigest(),old_error=str(exc),independent_equal=body==external))
  row['recovered_streams']=recovered
  if recovered:affected.append(row)
 except (ValueError,KeyError,IndexError) as exc:row['error']=str(exc)
summary=dict(scanned=len(rows),source_samples=sum(r['kind']=='source-sample' for r in rows),
             omitted_padding=sum(bool(r.get('nested_tail_bytes')) for r in rows),
             affected_exports=len(affected),recovered_streams=sum(len(r['recovered_streams']) for r in affected),
             remaining_errors=sum('error' in r for r in rows),
             independent_equal=all(s['independent_equal'] for r in affected for s in r['recovered_streams']))
result=dict(summary=summary,scope='Saved derivatives are not independent projects; full source/path hashes retained. No native compilation is run by this scan.',rows=rows)
with (P/'native-sector-tail-scan.json').open('x') as f:json.dump(result,f,indent=2)
print(json.dumps(summary));print(json.dumps([dict(path=r['path'],tail=r['nested_tail_bytes'],streams=r['recovered_streams']) for r in affected]))
