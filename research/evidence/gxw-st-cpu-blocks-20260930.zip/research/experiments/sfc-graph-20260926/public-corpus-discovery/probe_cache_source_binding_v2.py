"""Contrast imported compiler cache with fresh compile after one source edit."""
from pathlib import Path
import json,os,subprocess,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_simple_fb import frame_source
from replay_gxw_workspace import prepare
P=Path(__file__).resolve().parent
out=P/'cache-source-binding-v2';out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
from probe_gxw_st_sources import replace_observed_st
from gxw.token_listing import decode_token_listing
q_source=P/'q-cache-source-binding/baseline.gxw'
q=q_source.read_bytes();streams={s.logical_name:s.raw for s in inspect_project(q).streams if s.logical_name}
logical='SCPI.Program.pou';raw=streams[logical];listing=decode_token_listing(raw,profile='q03udv',text_encoding='cp949')
first=listing.instructions[0];assert first.mnemonic=='LD' and first.tokens[0].raw==bytes.fromhex('04000204')
new=raw[:first.tokens[0].offset+1]+b'\x01'+raw[first.tokens[0].offset+2:]
assert decode_token_listing(new,profile='q03udv',text_encoding='cp949').instructions[0].mnemonic=='LDI'
q_changed,receipt=patch_raw(q,logical,raw,new)
assert {s.logical_name:s.raw for s in inspect_project(q_changed).streams if s.logical_name}==dict(streams,**{logical:new})
(out/'q-invert.gxw').write_bytes(q_changed)
q_mutation=dict(source=str(q_source),source_sha256=sha256(q),changed_sha256=sha256(q_changed),logical=logical,edit='LD -> LDI',receipt=receipt,unrelated_payloads='byte-identical')
st_source=P/'ST-nested-FB-controls/single/native/native-saved.gxw'
st=st_source.read_bytes();streams={s.logical_name:s.raw for s in inspect_project(st).streams if s.logical_name}
logical='Wrapper.Program.pou';raw=streams[logical];_,text=replace_observed_st(raw,'')
new,_=replace_observed_st(raw,text+'NeverDeclared := 1;\r\n')
st_changed,receipt=patch_raw(st,logical,raw,new)
assert {s.logical_name:s.raw for s in inspect_project(st_changed).streams if s.logical_name}==dict(streams,**{logical:new})
(out/'st-baseline.gxw').write_bytes(st);(out/'st-undefined.gxw').write_bytes(st_changed)
st_mutation=dict(source=str(st_source),source_sha256=sha256(st),changed_sha256=sha256(st_changed),logical=logical,edit='append NeverDeclared := 1;',receipt=receipt,unrelated_payloads='byte-identical')
(out/'mutations.json').write_text(json.dumps([q_mutation,st_mutation],indent=2))
rows=[]
for case,filename,fresh in [('q-invert-cached','q-invert.gxw',False),('q-invert-fresh','q-invert.gxw',True),
        ('st-baseline-cached','st-baseline.gxw',False),('st-undefined-cached','st-undefined.gxw',False),('st-undefined-fresh','st-undefined.gxw',True)]:
    target=out/case;exe=prepare(out/filename,target,compile=True,export_project=True,project_alias='QCACHEBIND')
    plan=json.loads((target/'plan.json').read_text());plan.update(reset_compiler=fresh,fresh_compiler_state=fresh)
    (target/'plan.json').write_text(json.dumps(plan,indent=2))
    code=(target/'WorkspaceReplayOracle.cs').read_text()
    old='            if(!Convert.ToBoolean(plan["compile"]))return;'
    assert code.count(old)==1
    code=code.replace(old,'            CompileStatusSnapshot(workspace,id,"before-build");\n'+old)
    old='            bool compilerRejected=WaitReports(compiler,changeSfc?168:40,"Progress");'
    assert code.count(old)==1
    code=code.replace(old,old+'\n            CompileStatusSnapshot(workspace,id,"after-build");')
    (target/'WorkspaceReplayOracle.cs').write_text(code)
    (target/'NativeCompileStatusSnapshotV2.cs').write_bytes((P/'NativeCompileStatusSnapshotV2.cs').read_bytes())
    csc=Path(os.environ['WINDIR'])/'Microsoft.NET/Framework/v4.0.30319/csc.exe'
    build=subprocess.run([str(csc),'/nologo','/platform:x86','/r:System.Web.Extensions.dll','/r:System.Windows.Forms.dll','/out:'+str(exe),
        *[str(target/n) for n in ['WorkspaceReplayOracle.cs','NativeFrontendSnapshot.cs','NativeSfcGraphOracle.cs','NativeWorkspaceCopyOracle.cs','NativeCompileStatusSnapshotV2.cs']]],
        capture_output=True,timeout=20,creationflags=subprocess.CREATE_NO_WINDOW)
    (target/'status-build.stdout.bin').write_bytes(build.stdout);(target/'status-build.stderr.bin').write_bytes(build.stderr);build.check_returncode()
    request=json.loads((target/'request.json').read_text());request.update(actual_helper_sha256=sha256((target/'WorkspaceReplayOracle.cs').read_bytes()),status_snapshot_sha256=sha256((target/'NativeCompileStatusSnapshotV2.cs').read_bytes()))
    (target/'request.json').write_text(json.dumps(request,indent=2))
    process=subprocess.run([str(exe),str(target/'plan.json')],cwd=target,capture_output=True,timeout=50,creationflags=subprocess.CREATE_NO_WINDOW)
    (target/'process.stdout.bin').write_bytes(process.stdout);(target/'process.stderr.bin').write_bytes(process.stderr)
    events=[json.loads(s) for s in (target/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    snapshots={};phase=None
    for e in events:
        if e['operation']=='CompileStatusSnapshotBegin':phase=e['phase'];snapshots[phase]=[]
        elif e['operation'] in ('CompileStatusSnapshotNode','CompileAllAfterSnapshot','LabelModeSnapshot'):snapshots[phase].append(e)
    diagnostics={json.dumps({k:v for k,v in r.items() if k!='raw_base64'},sort_keys=True) for e in events for r in e.get('reports',[]) if r['kind'] in (2,3)}
    row=dict(case=case,input_sha256=sha256((out/filename).read_bytes()),fresh_backend=fresh,returncode=process.returncode,
        compile_completed=any(e['operation']=='Progress' and e.get('percent')==100 for e in events),
        diagnostics=[json.loads(r) for r in sorted(diagnostics)],snapshots=snapshots,
        outputs={f.name:dict(bytes=f.stat().st_size,sha256=sha256(f.read_bytes())) for f in target.glob('pcode-*.bin')},
        exported=(target/'native-saved.gxw').exists(),last_event=events[-1])
    rows.append(row);(target/'comparison.json').write_text(json.dumps(row,indent=2));print(json.dumps({k:v for k,v in row.items() if k not in ("snapshots","last_event")}),flush=True)
(out/'comparison.json').write_text(json.dumps(dict(cases=rows),indent=2))
