from pathlib import Path
import sys,json,base64
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from replay_gxw_workspace import prepare,trace_prepared
from gxw.lossless import sha256
P=Path(__file__).resolve().parent
out=P/'native-array-expression-trace-v8';out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
fixture=json.loads((ROOT/'tests/fixtures/gxw_callable_ports.json').read_text())
rows=[]
for name in ['int3-output-bound','int3-input-inverted','dint2-input-inverted','int3-output-inverted']:
 source=P/'native-graph-inout-array-width-controls'/name/'source.gxw'
 expected=next(x for x in fixture['cases'] if x['case']=='array-width-'+name)
 assert sha256(source.read_bytes())==expected['source_sha256']
 directory=out/name
 prepare(source,directory,compile=True,export_project=True,project_alias='ARRAYEXPR')
 result=trace_prepared(directory,P/'TraceArrayExpressionV8.js')
 events=[json.loads(line) for line in (directory/'events.jsonl').read_text().splitlines()]
 errors=[r for r in events if r.get('type')=='error' or r.get('payload',{}).get('event','').endswith(('error','failed'))]
 exact=(directory/'native-saved.gxw').exists() and (directory/'pcode-0-0.bin').read_bytes()==base64.b64decode(expected['pcode_base64'])
 row=dict(case=name,process=result,exact_pcode=exact,errors=errors,event_count=len(events));rows.append(row)
 (out/'comparison.json').write_text(json.dumps(rows,indent=2));print(json.dumps(row),flush=True)
