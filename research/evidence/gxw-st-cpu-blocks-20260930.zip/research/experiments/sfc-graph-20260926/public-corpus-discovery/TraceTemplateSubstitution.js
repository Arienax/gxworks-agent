(()=>{
'use strict';
const active=new Map(),pending=new Map();let seq=0;
function str(p,bound){try{let s='';for(let i=0;i<bound;i++){const c=p.add(i).readU8();if(c===0)return s;if(c>127)return null;s+=String.fromCharCode(c);}}catch(e){}return null;}
function hex(p,n){return Array.from(new Uint8Array(p.readByteArray(n)),v=>v.toString(16).padStart(2,'0')).join('');}
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='eccompiler_iec.dll')return;
 Interceptor.attach(m.findExportByName('Compile'),{onEnter(a){
  this.prior=active.get(this.threadId);const names=[];const n=a[1].toInt32();if(n>=0&&n<=1024)for(let i=0;i<n;i++)names.push(str(a[2].add(i*28+8).readPointer(),512));
  active.set(this.threadId,names.includes('POU_01'));
 },onLeave(){active.set(this.threadId,this.prior);}});
 Interceptor.attach(m.base.add(0x86595),{onEnter(){
  if(!active.get(this.threadId))return;
  const sp=this.context.esp,raw=this.context.ebx.sub(20);
  pending.set(this.threadId,{event:'template-substitution',sequence:++seq,operand:str(sp.add(0x44).readPointer().readPointer(),512),ordinal_zero_based:sp.add(0x1c).readS32(),before_hex:hex(raw,25),descriptor:raw.toString()});
 }});
 Interceptor.attach(m.base.add(0x866ca),{onEnter(){
  const row=pending.get(this.threadId);if(!row)return;pending.delete(this.threadId);
  row.after_hex=hex(this.context.ebx.sub(20),25);send(row);
 }});
}});
})();
