"""Compare full native PCode using the independent installed vendor decoder."""
from pathlib import Path
import argparse,base64,json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from native_gxw_tokens import native_batch,native_il_projection,Q_DLL
P=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output-name',default='native-pcode-control-comparison')
args=parser.parse_args()
out=P/args.output_name;out.mkdir(exist_ok=False)
cases={'constant-baseline':P/'scpi-label-inputs/global-constant/native',
       'constant-value':P/'partial-sector-label-edits/constant-value/native',
       'comment-growth':P/'partial-sector-label-edits/comment-growth/native',
       'index-baseline':P/'scpi-label-inputs/global-array-static/native'}
cases.update({c:P/'scpi-index-grammar'/c/'native' for c in ['decimal-plus','k-decimal','h-hex','iec-hex','rank-three','rank-three-axis']})
requests=[];dedup={};files={}
for case,native in cases.items():
 outcome=json.loads((native/'outcome.json').read_text())
 assert outcome['open_succeeded'] and outcome['compile_completed'] and not outcome['compiler_rejected']
 files[case]={}
 for f in sorted(native.glob('pcode-*.bin')):
  raw=f.read_bytes();key=sha256(raw)
  if key not in dedup:
   dedup[key]=len(requests);requests.append(dict(mode='decode',input_base64=base64.b64encode(raw+b'\0').decode()))
  files[case][f.name]=dict(bytes=len(raw),sha256=key,request=dedup[key])
 assert files[case]
answers=native_batch(requests,out/'native-decode',dll=Q_DLL,cpu_code=209)
decoded=[]
for request,answer in zip(requests,answers):
 assert answer['return_code']=='0x00000000'
 assert answer['consumed_bytes']==len(base64.b64decode(request['input_base64']))-1
 projection=native_il_projection(base64.b64decode(answer['output_base64']),encoding='cp932')
 assert not projection['text_gaps'];decoded.append(projection['records'])
comparisons=[]
for case in cases:
 if case.endswith('baseline'):continue
 baseline='constant-baseline' if case in ['constant-value','comment-growth'] else 'index-baseline'
 assert files[case].keys()==files[baseline].keys()
 changes=[];raw_changed=[]
 for name,actual in files[case].items():
  before=files[baseline][name]
  if before['sha256']!=actual['sha256']:raw_changed.append(name)
  a,b=decoded[before['request']],decoded[actual['request']]
  assert len(a)==len(b)
  changes += [dict(file=name,record=i,before=x,after=y) for i,(x,y) in enumerate(zip(a,b)) if x!=y]
 if case=='constant-value':
  assert len(changes)==1
  assert changes[0]['before']['op']==changes[0]['after']['op']=='MOV'
  assert changes[0]['before']['args']==['K123','D12949']
  assert changes[0]['after']['args']==['K124','D12949']
 elif case in ['rank-three','rank-three-axis']:
  value='D209' if case=='rank-three' else 'D202'
  # The preserved SCPI body reads _iUnitNo once. Earlier 20-group alias
  # corrections also included 19 BOOL-port uses, not 20 uses of this input.
  assert len(changes)==1
  for change in changes:
   expected=dict(change['before'],args=[value if a=='D203' else a for a in change['before']['args']])
   assert expected==change['after']
 else:assert not raw_changed and not changes
 comparisons.append(dict(case=case,baseline=baseline,raw_changed_files=raw_changed,changes=changes))
report=dict(files=files,decoded=decoded,comparisons=comparisons,
            scope='Exact accepted native PCode plus independent vendor text decoding; no PLC execution or runtime equivalence claim')
with (out/'comparison.json').open('x') as f:json.dump(report,f,indent=2)
print(json.dumps([dict(case=c['case'],raw_changed_files=c['raw_changed_files'],instruction_changes=len(c['changes'])) for c in comparisons]))
