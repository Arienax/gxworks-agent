"""Bounded source-only expansion of converted GX Works2 SFC graph references.

No native output/cache data are inputs. Opaque graphical cache is inventoried,
not decoded. FX3U real-source controls and native FX3U/Q00J topology controls
provide the observed instruction, registration and block shapes. Other shapes
fail explicitly. This intermediate SFC representation is not a Q ladder grammar.
"""
import struct
from gxw.lossless import inspect_project, sha256
from gxw.project_metadata import read_project_text_context
from gxw.token_pou import parse_token_fragment
from probe_gxw_task_graph import inspect_task_graph, _text
from probe_gxw_sfc_sources import framing
from probe_gxw_sfc_graph import compiled_graph


def groups(raw):
    result = []
    for token in parse_token_fragment(raw, 0, len(raw)).tokens:
        if token.raw[1] < 0x90:
            result.append([])
        if not result:
            raise ValueError('graph operand without an instruction')
        result[-1].append(token.raw)
    return result


def reference(raw, device):
    if len(raw) not in (4, 5) or raw[:2] != bytes([len(raw), device]) or raw[-1] != len(raw):
        raise ValueError('outside observed SFC reference encoding')
    return int.from_bytes(raw[2:-1], 'little')


def expand_block(raw):
    f, graph = framing(raw), compiled_graph(raw)
    zooms, transitions, actions = {}, {}, {}
    for child in f['children']:
        code = bytes.fromhex(child['token_hex'])
        if any(t.raw[1] == 0xdf for t in parse_token_fragment(code, 0, len(code)).tokens):
            raise ValueError('unresolved label in child program')
        target, key = (zooms, child['name']) if child['kind'] == 'zoom' else (transitions, child['number'])
        if key in target:
            raise ValueError('ambiguous child identity')
        target[key] = code
    for action in f['actions']:
        registrations = action['registrations']
        if (action['number'] in actions or len(registrations) != 1
                or registrations[0]['qualifier'] != 0 or registrations[0]['zoom'] not in zooms):
            raise ValueError('outside observed unique unqualified action registration')
        actions[action['number']] = zooms[registrations[0]['zoom']]
    result, insertions, block_calls = [], [], []
    for group in groups(raw[graph['code_offset']:graph['code_offset'] + graph['code_size']]):
        opcode, operands = group[0].hex(), group[1:]
        result.append(b''.join(group))
        if opcode in ('056c021705', '056c020f05', '056c041c05', '056c041405'):
            count = 1 if opcode in ('056c021705', '056c020f05') else 2
            if len(operands) != count:
                raise ValueError('unexpected SFC step arity')
            for operand in operands:
                reference(operand, 0x98)
            key = reference(operands[-1], 0x98)
            if key not in actions:
                raise ValueError('missing action registration')
            code, kind = actions[key], 'action'
        elif opcode in ('056c020405', '056c021d05', '056c020505', '056c021f05', '056c020605', '056c022005'):
            if len(operands) != 1:
                raise ValueError('unexpected SFC transition arity')
            key = reference(operands[0], 0x99)
            if key not in transitions:
                raise ValueError('missing transition body')
            code, kind = transitions[key], 'transition'
        elif opcode in ('0562020005', '0542020005', '0542010105') and len(operands) == 1:
            reference(operands[0], 0x98)
            continue
        elif opcode == '056c041505' and len(operands) == 2:
            reference(operands[0], 0x98)
            block_calls.append(reference(operands[1], 0xdc))
            continue
        elif opcode == '056c010a05' and not operands:
            continue
        else:
            raise ValueError('unobserved SFC graph instruction ' + opcode)
        insertions.append(dict(kind=kind, reference=key, bytes=len(code), sha256=sha256(code)))
        result.append(code)
    return b''.join(result), dict(insertions=insertions, block_calls=block_calls, cache=graph,
        source_sha256=sha256(raw), framing_tail=f['tail_hex'])


def project_projection(source):
    streams = {s.logical_name: s.raw for s in inspect_project(source).streams if s.logical_name}
    metadata, = [raw for name, raw in streams.items() if name.endswith('.prj')]
    if read_project_text_context(metadata)['cpu'] not in ('FX3U/FX3UC', 'Q00J'):
        raise ValueError('outside observed FX3U/Q00J SFC CPU')
    task_graph = inspect_task_graph(source)
    if task_graph['gaps'] or len(task_graph['resources']) != 1:
        raise ValueError('incomplete or unobserved SFC resource/task graph')
    resource = task_graph['resources'][0]
    task = task_graph['tasks'][resource['task']]
    if not task['entries']:
        raise ValueError('empty SFC task: native completion can return stale resource code')
    output, blocks, ordered = [bytes.fromhex('056c010005')], [], []
    for entry in task['entries']:
        declaration = streams[entry['declarations']]
        _, owner_end = _text(declaration, 54)
        if (declaration[owner_end:owner_end + 20] != bytes.fromhex('0000000100000000010000000000010000000000')
                or owner_end + 24 > len(declaration)):
            raise ValueError('outside observed SFC declaration header')
        number = struct.unpack_from('<I', declaration, owner_end + 20)[0]
        if number > 255 or any(b[0] == number for b in ordered):
            raise ValueError('unobserved or duplicate SFC block number')
        ordered.append((number, entry, owner_end + 20))
    # Independent mutations of the declaration field (0/1 -> 1/0; 1 -> 7)
    # change native ordering and block wrappers. Task order changes do neither.
    for number, entry, number_offset in sorted(ordered, key=lambda b: b[0]):
        body, evidence = expand_block(streams[entry['source_program']])
        output.extend([bytes.fromhex('056c01020504dc') + bytes([number, 4]), body, bytes.fromhex('056c010305')])
        blocks.append(dict(program=entry['source_program'], wrapper_number=number,
            declarations=entry['declarations'], block_number_offset=number_offset, **evidence))
    output.append(bytes.fromhex('056c010105033403'))
    return b''.join(output), dict(blocks=blocks, resource=resource['resource'],
        scope='bounded converted FX3U/Q00J SFC expansion; graphical cache and execution semantics unclaimed')
