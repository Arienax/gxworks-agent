(()=>{
'use strict';
let done=false;
function loc(p){const m=Process.findModuleByAddress(p);return m?{module:m.name,path:m.path,rva:p.sub(m.base).toString()}:null;}
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='eccompiler_iec.dll')return;
 const t=m.findExportByName('Compile');if(!t)return;
 Interceptor.attach(t,{onEnter(a){
  if(done)return;done=true;
  const compiler=Process.findModuleByName('DZDataABS_Compiler_IEC.dll');
  if(!compiler){send({event:'error-missing-compiler'});return;}
  const rows=IAT_SPECS.map(s=>{
   try{const target=compiler.base.add(s.iat_rva).readPointer(),range=Process.findRangeByAddress(target);
    return {...s,target:target.toString(),inferred_base:target.sub(s.target_rva).toString(),location:loc(target),range,actual_hex:Array.from(new Uint8Array(target.readByteArray(16)),v=>v.toString(16).padStart(2,'0')).join('')};
   }catch(e){return {...s,error:String(e)};}
  });
  send({event:'resolved-iat-snapshot',rows});
 }});
}});
})();
