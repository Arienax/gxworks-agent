"""Does one library body edit affect different output argument forms equally?"""
from pathlib import Path
import base64,json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from gxw.lossless import inspect_project,sha256
from probe_gxw_library_archive import decode_library_archive,encode_library_literals,frame_library_text,observed_source_body
from probe_gxw_library_sources import snapshot_library_pous
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_compiled_references import inspect,stored_records,parse_token_fragment
from replay_gxw_workspace import run
P=Path(__file__).resolve().parent/'array-operand-controls'
baseline=P/'word-bit-template-contrast';out=P/'word-bit-template-body-edit';out.mkdir(exist_ok=False)
source=(baseline/'changed.gxw').read_bytes();before={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
lib='MELSECFunction.lif';raw=before[lib];plain=decode_library_archive(raw[20:]).decoded
definitions=[d for d in frame_library_text(plain)['definitions'] if d['name']=='PLS_M' and 'Q03UDV' in (d['sections'] or [])]
assert len(definitions)==1;definition=definitions[0]
body=observed_source_body(definition);assert body==b'#PLS1##@3\r\n'
old=b'#PLS1';new=b'#PLF1';offset=definition['offset']+definition['raw'].index(body)
changed_plain=plain[:offset]+new+plain[offset+len(old):]
packed=raw[:20]+encode_library_literals(changed_plain)
assert decode_library_archive(packed[20:]).decoded==changed_plain
changed,receipt=patch_raw(source,lib,raw,packed)
after={s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}
assert all(after[k]==v for k,v in before.items() if k!=lib)
(out/'changed.gxw').write_bytes(changed)
(out/'mutation.json').write_text(json.dumps(dict(source_sha256=sha256(source),changed_sha256=sha256(changed),library=lib,
 source_offset=offset,old=old.decode(),new=new.decode(),source_prefix_suffix='byte-identical',unrelated_payloads='byte-identical',receipt=receipt),indent=2))
native=run(out/'changed.gxw',out/'native',compile=True,export_project=True,snapshot_frontend=True)
print(json.dumps({k:native.get(k) for k in ['compile_completed','compiler_rejected','diagnostics']}),flush=True)
result=dict(native=native);(out/'comparison.json').write_text(json.dumps(result,indent=2))
assert native.get('native_export') and not native.get('compiler_rejected')
def library(path):return {(r['library'],r['name']):r for r in snapshot_library_pous(json.loads(path.read_text(encoding='utf-8-sig')))}
old_lib=library(baseline/'native/frontend-snapshot.json');new_lib=library(out/'native/frontend-snapshot.json');key=('@MELSEC','PLS_M')
old_body=base64.b64decode(old_lib[key]['program_raw_base64']);new_body=base64.b64decode(new_lib[key]['program_raw_base64'])
assert old_body.count(old)==1
result['frontend_body_exact']=new_body==old_body.replace(old,new)
result['unrelated_native_libraries_exact']=old_lib.keys()==new_lib.keys() and all(new_lib[k]==v for k,v in old_lib.items() if k!=key)
read=inspect(out/'native',out/'correlation');decoded=read['decoded_fragments']
original=json.loads((baseline/'comparison.json').read_text());expected={r['line']['text']:r for r in original['calls']};rows=[]
for e in read['expansions']:
 for occurrence in e.get('occurrences',[]):
  text=occurrence.get('source_line',{}).get('text','')
  if text not in expected:continue
  records=[r for g in occurrence['compiled_records'] for r in decoded[g['decode_request']].get('records',[])]
  before_records=expected[text]['records'];edits=[]
  if len(records)==len(before_records):
   edits=[dict(position=i,before=a,after=b) for i,(a,b) in enumerate(zip(before_records,records)) if a!=b]
  rows.append(dict(source=text,before=before_records,after=records,instruction_counts_equal=len(records)==len(before_records),edits=edits))
result['call_differences']=rows;result['raw_group_differences']=[]
for f in native['outputs']:
 a=(baseline/'native'/f).read_bytes();b=(out/'native'/f).read_bytes()
 if a==b:continue
 ga,sa=stored_records(parse_token_fragment(a,0,len(a)),encoding='cp1252');gb,sb=stored_records(parse_token_fragment(b,0,len(b)),encoding='cp1252')
 assert len(ga)==len(gb) and sa==sb
 for x,y in zip(ga,gb):
  assert (x['offset'],x['stored_step'],x['stored_width'])==(y['offset'],y['stored_step'],y['stored_width'])
  if x['raw']!=y['raw']:result['raw_group_differences'].append(dict(file=f,offset=x['offset'],step=x['stored_step'],old_hex=x['raw'].hex(),new_hex=y['raw'].hex()))
result['summary']=dict(calls=len(rows),changed_calls=sum(bool(r['edits']) for r in rows),unchanged_calls=sum(r['before']==r['after'] for r in rows),changed_raw_groups=len(result['raw_group_differences']))
(out/'comparison.json').write_text(json.dumps(result,indent=2))
print(json.dumps(dict(**result['summary'],frontend_body_exact=result['frontend_body_exact'],unrelated_native_libraries_exact=result['unrelated_native_libraries_exact'],changes=[dict(source=r['source'],edits=r['edits']) for r in rows])),flush=True)
# A fresh reopen distinguishes a preserved input library from a transient
# snapshot or stale generation result. The project remains offline and isolated.
reopened=run(out/'native/native-saved.gxw',out/'reopen',compile=True,export_project=True,snapshot_frontend=True)
result['reopen']=reopened
if reopened.get('native_export') and not reopened.get('compiler_rejected'):
 result['reopened_library_exact']=library(out/'reopen/frontend-snapshot.json')==new_lib
 result['reopened_pcode_exact']=all((out/'native'/f).read_bytes()==(out/'reopen'/f).read_bytes() for f in native['outputs'])
(out/'comparison.json').write_text(json.dumps(result,indent=2))
print(json.dumps(dict(reopened_library_exact=result.get('reopened_library_exact'),reopened_pcode_exact=result.get('reopened_pcode_exact'))),flush=True)
