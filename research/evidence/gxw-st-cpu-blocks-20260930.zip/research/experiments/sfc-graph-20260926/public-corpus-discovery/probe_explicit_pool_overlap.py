"""Distinguish explicit-address reservation from collision and rejection."""
from dataclasses import replace
from pathlib import Path
import json
import sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.declarations import parse_declarations,serialize_declarations,edit_declarations
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import prepare,trace_prepared
from probe_gxw_program_check_resources import SCRIPT,inspect_run
from source_q_direct_projection import project_projection

P=Path(__file__).resolve().parent
OUT=P/'explicit-pool-overlap-20260930-controls'
def payloads(raw):return {s.logical_name:s.raw for s in inspect_project(raw).streams if s.logical_name}

def main():
    OUT.mkdir(exist_ok=False)
    (OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    original=(P/'noeul-native-batch/case-08/input.gxw').read_bytes();streams=payloads(original)
    global_name='Global1.gh';globals_=parse_declarations(streams[global_name],logical_name=global_name)
    local_name=next(n for n,b in streams.items() if n.endswith('.Labels.lh') and any(r.name=='EMSTP' for r in parse_declarations(b,logical_name=n).rows))
    local=parse_declarations(streams[local_name],logical_name=local_name)
    plans=[]
    for name,typ,start in [('global-outside','INT',100),('global-dint-outside','DINT',6654),('global-dint-crosses-lower','DINT',6655)]:
        d=edit_declarations(globals_,upserts=[dict(name='PROBE_RESERVED',data_type=typ)])
        d=replace(d,rows=tuple(replace(r,device='D'+str(start),iec_address='%M'+('D' if typ=='DINT' else 'W')+'0.'+str(start)) if r.name=='PROBE_RESERVED' else r for r in d.rows))
        plans.append((name,global_name,serialize_declarations(d)))
    d=replace(local,rows=tuple(replace(r,device='D100',iec_address='%MW0.100') if r.name=='EMSTP' else r for r in local.rows))
    plans.append(('local-explicit-outside',local_name,serialize_declarations(d)))
    ready=[]
    for name,logical,updated in plans:
        directory=OUT/name;directory.mkdir()
        source,receipt=(original,None) if logical is None else patch_raw(original,logical,streams[logical],updated)
        assert payloads(source)==(streams if logical is None else dict(streams,**{logical:updated}))
        path=directory/'input.gxw';path.write_bytes(source)
        try:
            pred=project_projection(source)
            model=dict(status='predicted',outputs=[dict(index=r['resource_index'],sha256=sha256(r['output'])) for r in pred])
        except ValueError as e:model=dict(status='unsupported',reason=str(e))
        (directory/'prediction-before-native.json').write_text(json.dumps(dict(source_sha256=sha256(source),receipt=receipt,model=model,
            hypotheses=['Explicit device reservation shifts automatic STATE allocation below occupied words.',
                        'Automatic allocation retains D13311, producing overlap.',
                        'Native compilation rejects overlapping explicit and automatic ranges.'],
            untouched_nested_payloads='byte-identical'),indent=2),encoding='utf-8')
        ready.append((name,directory,path,model))
    results=[]
    for name,directory,path,model in ready:
        script=directory/'trace.js';script.write_text(SCRIPT,encoding='utf-8')
        queries=[dict(name=n,keys=[dict(category=1,value=n)]) for n in ['STATE','EMSTP','MODE','METAL','PROBE_RESERVED']]
        for attempt in range(1,5):
            native=directory/f'native-{attempt}'
            prepare(path,native,compile=True,program_check=True,export_project=True,snapshot_frontend=True,
                assignment_queries=queries,project_alias='RESERVE')
            process=trace_prepared(native,script)
            events=[json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
            if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
        observed=inspect_run(native);assignment=native/'native-device-assignments.json'
        assignments=json.loads(assignment.read_text(encoding='utf-8-sig')) if assignment.exists() else None
        row=dict(case=name,native_directory=str(native),trace=process,model=model,check=observed['check'],
            diagnostics=observed['diagnostics'],assignments=assignments,export=observed['exported_sha256'])
        results.append(row);(OUT/'comparison.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
        print(json.dumps(dict(case=name,check=row['check'],export=bool(row['export']),assignments=assignments,
            errors=[{k:v for k,v in r.items() if k!='raw_base64'} for r in row['diagnostics'] if r['kind']==2]),ensure_ascii=True),flush=True)

if __name__=='__main__':main()
