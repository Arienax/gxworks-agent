"""Independent decode of the last FX lexical gap in the public source corpus."""
from pathlib import Path
import base64
import json
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'research')]
from gxw.lossless import inspect_project, sha256
from gxw.token_pou import frame_token_pou
from native_gxw_tokens import native_batch, native_il_projection

P = Path(__file__).resolve().parent
OUT = P / 'modbus-source-lexical-control'


def main():
    OUT.mkdir(exist_ok=False)
    (OUT / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    source = (P / 'samples/modbus-master.gxw').read_bytes()
    program, = [s for s in inspect_project(source).streams if (s.logical_name or '').endswith('.pou')]
    body = frame_token_pou(program.raw).body
    # The source record at 196 has one header followed by five already known
    # operand tokens. Do not assign a mnemonic until the native result arrives.
    fragment = program.raw[196:221]
    assert fragment.hex() == '055f0b240504ea010404ea010404ea000404ea010404a80004'
    inputs = [dict(mode='decode', source_sha256=sha256(source), program_sha256=sha256(program.raw),
        scope='full real source', input_base64=base64.b64encode(body + b'\0').decode()),
        dict(mode='decode', scope='bounded source record', input_base64=base64.b64encode(fragment + b'\0').decode())]
    results = native_batch(inputs, OUT / 'native', cpu_code=520)
    summary = []
    for request, result in zip(inputs, results, strict=True):
        decoded = native_il_projection(base64.b64decode(result['output_base64']), encoding='cp1252')
        summary.append(dict(scope=request['scope'], return_code=result['return_code'],
            consumed=result['consumed_bytes'], records=decoded['records']))
    (OUT / 'comparison.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
    print(json.dumps([dict(scope=s['scope'], return_code=s['return_code'], consumed=s['consumed'],
        records=s['records'] if s['scope']=='bounded source record' else len(s['records'])) for s in summary]))


if __name__ == '__main__':
    main()
