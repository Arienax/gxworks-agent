"""Reopen native saves of targeted edits to unconverted FX SFC source grids."""
from pathlib import Path
import json
import sys
ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'research')]
from gxw.lossless import sha256
from replay_gxw_workspace import run

P = Path(__file__).resolve().parent
OUT = P/'pending-sfc-reload'


def main():
    OUT.mkdir(exist_ok=False); (OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    rows = []
    for tag in ['pending-FX-jump-target0', 'pending-FX-action30']:
        original = P/'sfc-source-targeted-mutations'/tag
        path = original/'native-1/native-saved.gxw'; target = OUT/tag; target.mkdir()
        candidate = (original/'candidate.bin').read_bytes()
        (target/'candidate.bin').write_bytes(candidate)
        (target/'input.json').write_text(json.dumps(dict(source=str(path), source_sha256=sha256(path.read_bytes()),
            candidate_sha256=sha256(candidate), source_chars_sha256=sha256((original/'source-chars.bin').read_bytes())), indent=2), encoding='utf-8')
        for attempt in range(1, 5):
            native = target/f'native-{attempt}'
            outcome = run(path, native, compile=True, change_sfc=True, program_check=True,
                snapshot_frontend=True, export_project=True, project_alias='SFCRELOAD', sfc_graph_chars=original/'source-chars.bin')
            events = [json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
            if not any(e.get('operation') == 'NativeTemporaryDirectoryCollision' for e in events):
                break
        code = native/'pcode-0-0.bin'; graph = native/'sfc-native-graph.json'
        row = dict(case=tag, native_directory=str(native), outcome=outcome,
            full_pcode_identical=code.exists() and code.read_bytes() == candidate,
            source_character_operation=json.loads(graph.read_text(encoding='utf-8-sig'))['decode_result'] if graph.exists() else 'missing')
        rows.append(row); (OUT/'comparison.json').write_text(json.dumps(rows, indent=2), encoding='utf-8')
        print(json.dumps(dict(**{k: v for k, v in row.items() if k != 'outcome'}, compiler_rejected=outcome['compiler_rejected'],
            program_check_completed=outcome['program_check_completed'], diagnostics=outcome['diagnostics'])), flush=True)


if __name__ == '__main__':
    main()
