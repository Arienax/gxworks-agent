"""Native grid -> PCode research experiment, preserves failures and raw buffers."""
from pathlib import Path
import argparse
import base64
import hashlib
import json
import os
import subprocess
import sys

P=Path(__file__).resolve().parent
ROOT=P.parents[3]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from native_gxw_tokens import DEFAULT_DLL,DLL_SHA256

def run(requests,out):
    assert hashlib.sha256(DEFAULT_DLL.read_bytes()).hexdigest()==DLL_SHA256
    out.mkdir(exist_ok=False)
    source=out/'LadderReverseOracle.cs';source.write_bytes((P/source.name).read_bytes())
    (out/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    (out/'requests.json').write_text(json.dumps(dict(dll_path=str(DEFAULT_DLL),dll_sha256=DLL_SHA256,
        requests=requests,scope='offline owned native grid buffers; no project or device'),indent=2),encoding='utf-8')
    compiler=Path(os.environ['WINDIR'])/'Microsoft.NET/Framework/v4.0.30319/csc.exe'
    exe=out/'LadderReverseOracle.exe'
    build=subprocess.run([str(compiler),'/nologo','/platform:x86','/r:System.Web.Extensions.dll','/out:'+str(exe),str(source)],
        capture_output=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
    (out/'build.stdout.bin').write_bytes(build.stdout);(out/'build.stderr.bin').write_bytes(build.stderr)
    if build.returncode:raise RuntimeError('build failure; retained')
    protocol=''.join(json.dumps(dict(r,id=i))+'\n' for i,r in enumerate(requests))
    try:
        process=subprocess.run([str(exe),str(DEFAULT_DLL),str(out)],input=protocol.encode('ascii'),capture_output=True,
            timeout=45,creationflags=subprocess.CREATE_NO_WINDOW)
        status,stdout,stderr=process.returncode,process.stdout,process.stderr
    except subprocess.TimeoutExpired as e:status,stdout,stderr='timeout',e.stdout or b'',e.stderr or b''
    (out/'native-stdout.jsonl').write_bytes(stdout);(out/'native-stderr.bin').write_bytes(stderr)
    rows=[json.loads(line) for line in stdout.splitlines()]
    (out/'process.json').write_text(json.dumps(dict(returncode=status,completed=len(rows),requested=len(requests)),indent=2),encoding='utf-8')
    if status or len(rows)!=len(requests) or any(not r['guards_intact'] or not r['pointers_unchanged'] for r in rows):
        raise RuntimeError('native reverse failed; retained')
    return rows

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('output',type=Path)
    parser.add_argument('--limit',type=int,default=1);args=parser.parse_args()
    parent=P/'fx3g-ladder-call-corpus';native=parent/'reusable-oracle'
    calls=json.loads((parent/'calls.json').read_text(encoding='utf-8'))
    selected=[c for c in calls if c['return_code']==0 and c['metadata'][1]>0][:args.limit]
    requests=[]
    for c in selected:
        i=c['id'];requests.append(dict(source_id=i,height=c['metadata'][1],input_hex=c['input_hex'],
            tokens_base64=base64.b64encode((native/f'{i:04}.tokens.bin').read_bytes()).decode('ascii'),
            cells_base64=base64.b64encode((native/f'{i:04}.cells.bin').read_bytes()).decode('ascii')))
    rows=run(requests,args.output.resolve());compared=[]
    for i,(r,q) in enumerate(zip(rows,requests)):
        raw=(args.output/f'{i:04}.output-buffer.bin').read_bytes()[:r['output_size']]
        original=bytes.fromhex(q['input_hex'])
        compared.append(dict(native=r,source_id=q['source_id'],input_bytes=len(original),output_hex=raw.hex(),
            byte_identical=raw==original,byte_identical_without_sentinel=raw==original[:-1],
            cells_unchanged=(args.output/f'{i:04}.cells-after.bin').read_bytes()==base64.b64decode(q['cells_base64']),
            tokens_unchanged=(args.output/f'{i:04}.tokens-after.bin').read_bytes()==base64.b64decode(q['tokens_base64'])))
    (args.output/'comparison.json').write_text(json.dumps(compared,indent=2),encoding='utf-8')
    print(json.dumps(dict(calls=len(rows),return_codes={c:sum(r['return_code']==c for r in rows) for c in {r['return_code'] for r in rows}},
        byte_identical=sum(r['byte_identical'] for r in compared),byte_identical_without_sentinel=sum(r['byte_identical_without_sentinel'] for r in compared),
        gaps=[dict(r,output_hex=r['output_hex'][:240]) for r in compared if not r['byte_identical'] and not r['byte_identical_without_sentinel']][:5])))

if __name__=='__main__':main()
