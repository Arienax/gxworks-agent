from pathlib import Path
import base64,json,struct,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.structured_pou import parse_structured_pou
from gxw.project_metadata import mark_observed_source_compile_pending
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import prepare,trace_prepared
from native_gxw_tokens import native_batch,native_il_projection,DEFAULT_DLL
P=Path(__file__).resolve().parent
out=P/'native-callable-port-order';out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
rows=[]
controls=[(f'{kind}-{name}',seed,symbol,order) for kind,seed,symbol in [('MOV','function','MOV'),('TON','library_fb','TIMER_A')] for name,order in [('inputs',(1,0,2,3)),('outputs',(0,1,3,2)),('all',(3,2,1,0))]]
for case,seed,symbol,order in controls:
 directory=out/case;directory.mkdir()
 source=(P/'structured-graph-location-controls'/seed/'native/native-saved.gxw').read_bytes()
 streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name};logical='1.Program.pou';old=streams[logical]
 raw=old
 if seed=='function':
  f=json.loads((ROOT/'tests/fixtures/gxw_structured_54_58.json').read_text())['54'];raw=base64.b64decode(f['program_pou_base64'])
 program=parse_structured_pou(raw,logical_name=logical);node=next(n for n in program.nodes if n.symbol==symbol)
 start=node.offset+node.record_length-sum(p.size for p in node.ports)
 assert len(node.ports)==4 and all(p.size==16 for p in node.ports)
 records=[raw[start+i*16:start+(i+1)*16] for i in range(4)]
 updated=bytearray(raw);updated[start:start+64]=b''.join(records[i] for i in order);updated=mark_observed_source_compile_pending(bytes(updated),logical_name=logical)
 patched,receipt=patch_raw(source,logical,old,updated)
 assert {s.logical_name:s.raw for s in inspect_project(patched).streams if s.logical_name}==dict(streams,**{logical:updated})
 path=directory/'source.gxw';path.write_bytes(patched)
 (directory/'mutation.json').write_text(json.dumps(dict(seed=seed,symbol=symbol,order=order,source_sha256=sha256(source),updated_sha256=sha256(patched),receipt=receipt),indent=2))
 for attempt in range(3):
  native=directory/('native' if not attempt else f'native-attempt-{attempt}');prepare(path,native,compile=True,export_project=True,project_alias='CALLABLEFLAGS')
  process=trace_prepared(native,P/'TraceGraphPrimitives.js')
  native_events=[json.loads(s) for s in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
  if native_events[-1]['operation']!='NativeTemporaryDirectoryCollision':break
 events=[json.loads(s) for s in (native/'events.jsonl').read_text().splitlines()];fragments=[]
 for event in events:
  payload=event.get('payload',{})
  if payload.get('event')!='enter' or payload.get('name')!='Compile':continue
  buffers={b['label']:b for b in payload['buffers']}
  for key,b in buffers.items():
   if not key.startswith('source_') or not b['bytes']:continue
   i=key.removeprefix('source_');name=bytes.fromhex(buffers['name_'+i]['bytes']).split(b'\0')[0];body=bytes.fromhex(b['bytes']);assert len(body)==b['requested_size']
   file=f'compile-{payload["id"]}-{i}.sic';(directory/file).write_bytes(body)
   fragments.append(dict(name=name.decode('ascii',errors='backslashreplace'),text=body.decode('ascii',errors='backslashreplace'),file=file,sha256=sha256(body)))
 diagnostics={json.dumps({k:v for k,v in r.items() if k!='raw_base64'},sort_keys=True) for e in native_events for r in e.get('reports',[]) if r['kind'] in (2,3)}
 row=dict(case=case,process=process,native_directory=str(native.relative_to(out)),fragments=fragments,diagnostics=[json.loads(d) for d in sorted(diagnostics)],crt_checks=[e for e in native_events if e['operation']=='NativeCrtCharacterCase'],trace_errors=[e for e in events if e.get('type')=='error'],exported=(native/'native-saved.gxw').exists(),last_event=native_events[-1],compile_completed=any(e['operation']=='Progress' and e.get('percent')==100 for e in native_events),outputs={p.name:sha256(p.read_bytes()) for p in native.glob('pcode-*.bin')})
 rows.append(row);(directory/'comparison.json').write_text(json.dumps(row,indent=2));(out/'comparison.json').write_text(json.dumps(rows,indent=2))
 print(json.dumps(dict(case=case,exported=row['exported'],diagnostics=row['diagnostics'],source=[f['text'] for f in fragments if f['name']=='1'])),flush=True)
selected=[r for r in rows if r['exported'] and not any(d['kind']==2 for d in r['diagnostics'])]
paths=[out/r['native_directory']/'pcode-0-0.bin' for r in selected]
answers=native_batch([dict(mode='decode',input_base64=base64.b64encode(p.read_bytes()+b'\0').decode()) for p in paths],out/'decode',dll=DEFAULT_DLL,cpu_code=0x208)
decoded=[]
for row,path,a in zip(selected,paths,answers,strict=True):
 assert a['return_code']=='0x00000000' and a['consumed_bytes']==path.stat().st_size
 listing=native_il_projection(base64.b64decode(a['output_base64']),encoding='gb18030');assert not listing['text_gaps'];decoded.append(dict(case=row['case'],records=listing['records'],pcode_sha256=sha256(path.read_bytes())))
(out/'native-decoded.json').write_text(json.dumps(decoded,indent=2));print(json.dumps(dict(accepted=len(selected),total=len(rows))))
