// Owned helper only, read-only ECCompiler_IEC 15.50 instruction sink.
'use strict';
const contexts = new Map();
let sequence = 0, nextCompile = 0;
function hex(p, n) { return Array.from(new Uint8Array(p.readByteArray(n)), b => b.toString(16).padStart(2, '0')).join(''); }
function string(p, bound) {
  const bytes=[];
  for(let i=0;i<bound;i++) {const b=p.add(i).readU8();if(!b)return {hex:bytes.map(x=>x.toString(16).padStart(2,'0')).join(''),latin1:String.fromCharCode(...bytes),terminated:true};bytes.push(b);}
  return {hex:bytes.map(x=>x.toString(16).padStart(2,'0')).join(''),terminated:false};
}
function loc(p){const m=Process.findModuleByAddress(p);return m?{module:m.name,rva:p.sub(m.base).toString()}:null;}
function emit(e){if(sequence<100000)send({...e,sequence:++sequence});else if(sequence===100000){sequence++;send({event:'sink-limit-error'});}}
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='eccompiler_iec.dll')return;
 try {
  if(Process.arch!=='ia32')throw new Error('x86 required');
  const b='6aff6806040f1064a100000000506489'.match(/../g).map(x=>parseInt(x,16)),v=m.base.add(0xf0406).toUInt32();
  for(let i=0;i<4;i++)b[3+i]=(v>>>(8*i))&255;
  if(hex(m.base.add(0xaed60),16)!==b.map(x=>x.toString(16).padStart(2,'0')).join(''))throw new Error('record-sink guard');
  emit({event:'sink-module',path:m.path,base:m.base.toString()});
  Interceptor.attach(m.findExportByName('Compile'),{
   onEnter(a){
    this.prior=contexts.get(this.threadId);this.id=++nextCompile;
    const count=a[1].toInt32(),names=[],sources=[];
    try {
     if(count<0||count>4096)throw new Error('compile count bound');
     for(let i=0;i<count;i++){
      const d=a[2].add(i*28),n=d.readS32(),name=string(d.add(8).readPointer(),1024);names.push(name);
      if(n<0||n>0x200000)throw new Error('source length bound');
      sources.push({index:i,name,raw:hex(d.add(4).readPointer(),n)});
     }
     contexts.set(this.threadId,{compile_id:this.id,names});
     const symbolsSize=a[3].toInt32();
     if(symbolsSize<0||symbolsSize>0x1000000)throw new Error('symbol length bound');
     emit({event:'sink-compile',compile_id:this.id,names,sources,symbolic_data:hex(a[4],symbolsSize)});
    }catch(e){contexts.set(this.threadId,null);emit({event:'sink-compile-error',compile_id:this.id,error:String(e)});}
   },onLeave(r){emit({event:'sink-compile-result',compile_id:this.id,result:r.toInt32()});contexts.set(this.threadId,this.prior);}
  });
  Interceptor.attach(m.base.add(0xaed60),{onEnter(a){
   const context=contexts.get(this.threadId);if(!context)return;
   try {
    const r=a[0],count=r.add(12).readU8();if(count>9)throw new Error('operand count bound');
    const operands=[];
    for(let i=0;i<count;i++){
     const p=r.add(13+i*25),operand={raw:hex(p,25)};
     if((p.add(24).readU8()&1)&&!p.readPointer().isNull())operand.string=string(p.readPointer(),4096);
     operands.push(operand);
    }
    emit({event:'sink-record',compile_id:context.compile_id,name:string(r.readPointer(),128),opcode:r.add(4).readS32(),source:r.add(8).readS32(),count,mode:a[1].toInt32(),operands,raw:hex(r,238),caller:loc(this.returnAddress)});
   }catch(e){emit({event:'sink-record-error',compile_id:context.compile_id,error:String(e)});}
  }});
 }catch(e){emit({event:'sink-guard-error',error:String(e)});}
}});
