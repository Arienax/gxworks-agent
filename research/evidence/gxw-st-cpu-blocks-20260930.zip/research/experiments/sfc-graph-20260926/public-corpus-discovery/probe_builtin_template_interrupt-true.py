import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.declarations import parse_declarations,edit_declarations,serialize_declarations
from probe_gxw_st_sources import replace_observed_st
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import run,prepare,trace_prepared
from probe_gxw_compiled_references import inspect
P=Path(__file__).resolve().parent
out=P/'builtin-template-call-controls'/'interrupt-true';out.mkdir(parents=True,exist_ok=False)
source=(P/'samples/boxid.gxw').read_bytes();streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
program='POU_01.Program.pou';labels='POU_01.Labels.lh'
_,old=replace_observed_st(streams[program],'')
calls=['DI_M(TRUE);','EI_M(TRUE);']
new,_=replace_observed_st(streams[program],old+'\r\n'+'\r\n'.join(calls)+'\r\n')
d=parse_declarations(streams[labels],logical_name=labels)
replacements={program:new,labels:serialize_declarations(edit_declarations(d,upserts=[dict(name='BuiltinD',data_type='ARRAY[0..3] OF INT'),dict(name='BuiltinB',data_type='BOOL')]))}
changed=source;receipts=[]
for name,raw in replacements.items():
 changed,receipt=patch_raw(changed,name,streams[name],raw);receipts.append(receipt)
after={s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}
assert all(after[n]==raw for n,raw in streams.items() if n not in replacements)
(out/'changed.gxw').write_bytes(changed)
(out/'mutation.json').write_text(json.dumps(dict(calls=calls,source_sha256=sha256(source),changed_sha256=sha256(changed),receipts=receipts,unrelated_payloads='byte-identical'),indent=2))
r=run(out/'changed.gxw',out/'native',compile=True,export_project=True,snapshot_frontend=True)
print(json.dumps(r),flush=True)
if r.get('native_export'):
 print(json.dumps(inspect(out/'native',out/'correlation')['summary']),flush=True)
 prepare(out/'changed.gxw',out/'trace',compile=True,export_project=True)
 print(json.dumps(trace_prepared(out/'trace',ROOT/'research/native/CompilerTrace.js',timeout=45)),flush=True)
