"""Exercise the shared read-only diagnostic capture with real native failures."""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[4];sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from probe_minimal_conditional_port_writes import observe,save
from probe_gxw_program_check_resources import SCRIPT
P=Path(__file__).resolve().parent


def main():
    out=P/'fresh-check-diagnostic-capture-20260930';out.mkdir(exist_ok=False)
    (out/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    (out/'probe_gxw_program_check_resources.py').write_bytes((ROOT/'research/probe_gxw_program_check_resources.py').read_bytes())
    trace=out/'trace.js';trace.write_text(SCRIPT,encoding='utf-8')
    plans=[('original-noeul',P/'native-allocation-inventory/case-10/input.gxw',True,False),
        ('st-25-moves',P/'st-temporary-capacity-rung-controls-20260930/plain-25-moves/input.gxw',True,False),
        ('st-24-moves',P/'st-temporary-capacity-rung-controls-20260930/plain-24-moves/input.gxw',False,True),
        ('three-resources',P/'cross-source-st-lifetime-holdouts-20260930/three-separate-resources/input.gxw',False,True),
        ('fx-duplicate-coils',P/'program-check-freshness/known-invalid-duplicate-coils.gxw',True,True)]
    save(out/'before-native.json',[dict(case=c,input=str(p),sha256=sha256(p.read_bytes()),expected_backend_rejected=rejected,expected_public_completed=completed)for c,p,rejected,completed in plans])
    rows=[]
    for case,path,rejected,completed in plans:
        d=out/case;d.mkdir();n,r,process=observe(path,d,trace)
        assert r['backend_check_rejected'] is rejected
        assert (r['check'] is not None) is completed
        if completed:assert r['check']['rejected'] is rejected
        assert len(r['diagnostic_projection_failures'])==(0 if completed else 1)
        assert not r['trace_errors']
        row=dict(case=case,native_directory=str(n),check=r['check'],backend_rejected=r['backend_check_rejected'],
            completed_indices=r['backend_completed_check_indices'],projection_failures=len(r['diagnostic_projection_failures']),
            backend_diagnostics=[{k:v for k,v in e.items() if k not in ('raw_hex','target')} for e in r['backend_check_diagnostics']],
            pcode_hashes={f.name:sha256(f.read_bytes()) for f in n.glob('pcode-*-0.bin')},exported=bool(r['exported_sha256']),process=process)
        rows.append(row);save(out/'comparison.json',rows)
        print(json.dumps({k:v for k,v in row.items() if k not in ('native_directory','process','pcode_hashes')}),flush=True)
    assert rows[0]['backend_diagnostics'][0]['arguments']==['Y25']
    assert rows[1]['backend_diagnostics'][0]['code']==0x050c9521
    assert rows[3]['completed_indices']==[0,1,2]
    for case in ('original-noeul','st-25-moves','st-24-moves'):
        n=out/case/'native-1';baseline=P/'q-fresh-check-report-conversion-20260930'/case/'native-1'
        for f in n.glob('pcode-*-0.bin'):assert f.read_bytes()==(baseline/f.name).read_bytes()
    save(out/'verification.json',dict(native_cases=5,matched_expected_backend_rejections=3,
        public_checks_completed=3,public_projection_failures=2,unchanged_q_pcode=True,
        no_native_return_overrides=True,all_trace_errors_empty=True,
        scope='Actual owned-helper native observations. Backend rejection does not upgrade an incomplete public/project check to accepted or fully checked.'))


if __name__=='__main__':main()
