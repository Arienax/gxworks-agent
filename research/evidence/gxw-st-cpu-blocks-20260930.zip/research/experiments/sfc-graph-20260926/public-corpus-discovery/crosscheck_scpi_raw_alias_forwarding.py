"""Predict raw FB operand forwarding from caller bytes, not saved allocation."""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from probe_gxw_simple_fb import frame_source,observe_calls
P=Path(__file__).resolve().parent
OUT=P/'scpi-alias-device-methods'
def groups(raw):
 # Independent length scanner; preserve opaque operand bytes and their order.
 result=[];offset=0
 while offset<len(raw):
  size=raw[offset]
  if size<2 or offset+size>len(raw) or raw[offset+size-1]!=size:raise ValueError('token frame')
  token=raw[offset:offset+size]
  if token[1]<0x90:result.append([token])
  else:
   if not result:raise ValueError('unattached operand')
   result[-1].append(token)
  offset+=size
 return result
def caller_candidates(frame,call):
 result={}
 for direction in ['input','output']:
  span=call[direction+'_fragment'];blob=frame.raw[span['offset']:span['offset']+span['length']]
  g=groups(blob);assert len(g)==4 and [row[0][1] for row in g]==[0,0x20,0,0x4c]
  assert len(g[0])>=2 and len(g[1])>=2 and len(g[2])==2 and g[2][1][1]==0xdf and g[2][1][2:-1]==b'_TRUE'
  assert len(g[3][0])==5 and g[3][0][3]==0 # MOV word form, not other 4c forms.
  for data in ([g[0][1:],g[1][1:]], [g[3][1:-1],[g[3][-1]]] if direction=='input' else [[g[3][1]],g[3][2:]]):
   operand,label=(data[0],data[1]) if direction=='input' else (data[1],data[0])
   assert len(label)==1 and label[0][1]==0xdf and label[0][2:3]==b'_'
   pin=label[0][3:-1].decode('ascii');assert pin not in result
   port=next(p for p in call['ports'] if p['direction']==direction and p['name']==pin)
   assert port['type_marker'] in ['B','W'] and operand
   # This is a scoped hypothesis for these direct LD/OUT and MOV templates.
   raw=b''.join(operand);immediate=0xe3<=operand[0][1]<=0xee
   result[pin]=dict(port=pin,direction=direction,raw=raw.hex(),predicted_alias=not immediate,source_fragment=dict(span))
 return result
results=[]
for case in json.loads((OUT/'comparison.json').read_text()):
 assert not case['errors'] and all(case['exact_pcode'].values())
 source=Path(case['source']).read_bytes();assert sha256(source)==case['source_sha256']
 raw=next(s.raw for s in inspect_project(source).streams if s.logical_name=='MAIN.Program.pou');frame=frame_source(raw);calls=observe_calls(frame)['calls'];assert len(calls)==2
 candidates=[caller_candidates(frame,c) for c in calls]
 ev=[e['payload'] for line in (Path(case['trace_directory'])/'events.jsonl').read_text().splitlines() if (e:=json.loads(line)).get('type')=='send']
 starts=[e['sequence'] for e in ev if e.get('event')=='alias-decision' and e['role']=='input-bool'];assert len(starts)==2
 evidence=[]
 for i,(call,pins) in enumerate(zip(calls,candidates)):
  stop=starts[i+1] if i+1<len(starts) else 10**12
  epoch=[e for e in ev if starts[i]-1<=e['sequence']<stop]
  for pin,h in pins.items():
   expected_name=call['instance']+'.'+pin
   stores=[e for e in epoch if e['event']=='alias-store-request' and e['first']['latin1']==pin]
   # BOOL setter returns just before its enclosing decision event.
   if pin=='iEn':
    dec=next(e for e in ev if e.get('event')=='alias-decision' and e['sequence']==starts[i]);stores=[e for e in ev if e.get('event')=='alias-store-request' and e['decision_id']==dec['decision_id']]
   actual=[e for e in epoch if e['event']=='label-binding' and e.get('lookup',{}).get('name',{}).get('latin1')==expected_name]
   assert actual and all(e['result']==0 for e in actual)
   exact=[e['output']==h['raw'] for e in actual]
   predicted=h['predicted_alias'];assert bool(stores)==predicted
   if predicted:assert len(stores)==1 and all(exact)
   else:assert not any(exact)
   other=candidates[1-i][pin]['raw'];negative=sum(e['output']==other for e in actual)
   if predicted:assert not negative
   evidence.append(dict(h,call=i,instance=call['instance'],observed_alias=bool(stores),native_bindings=len(actual),raw_exact=sum(exact),wrong_call_raw_matches=negative,bindings=[dict(binding_id=e['binding_id'],input=e['input'],output=e['output'],caller=e['caller'],sequence=e['sequence']) for e in actual]))
 summary=dict(case=case['case'],calls=2,ports=len(evidence),aliases=sum(e['predicted_alias'] for e in evidence),matched_alias_bindings=sum(e['raw_exact'] for e in evidence if e['predicted_alias']),non_alias_bindings=sum(e['native_bindings'] for e in evidence if not e['predicted_alias']),wrong_call_matches=sum(e['wrong_call_raw_matches'] for e in evidence if e['predicted_alias']))
 row=dict(summary=summary,evidence=evidence,scope='Q03UDV native compiler 15.50; controlled direct BOOL and word MOV connection templates. Source raw prediction is independent of native formatter and saved CGTable; native trace is checked against untraced full PCode. No claim about runtime alias stability or general instruction validity.')
 (OUT/case['case']/'raw-forwarding.json').write_text(json.dumps(row,indent=2));results.append(row);print(json.dumps(summary))
(OUT/'raw-forwarding.json').write_text(json.dumps(results,indent=2))
