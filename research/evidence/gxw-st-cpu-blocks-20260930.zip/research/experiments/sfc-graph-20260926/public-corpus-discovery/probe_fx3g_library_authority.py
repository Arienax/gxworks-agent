"""Single-stream library controls against an unchanged native frontend path."""
from pathlib import Path
import base64
import argparse
import json
import struct
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'research')]
from gxw.lossless import inspect_project, sha256
from gxw.text_pou import parse_st_pou
from gxw.declarations import _string
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_library_sources import snapshot_library_pous
from replay_gxw_workspace import run
from probe_fx3g_library_declarations import native_global_rows, source_rows

P = Path(__file__).resolve().parent
OUT = P / 'fx3g-library-authority'


def main():
    global OUT
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--extensions', action='store_true')
    args = parser.parse_args()
    if args.extensions:
        OUT = P / 'fx3g-declaration-extension-controls'
    OUT.mkdir(exist_ok=False)
    (OUT / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    source = (P / 'cross-family-source-holdouts/case-00/input.gxw').read_bytes()
    streams = {s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
    lnb = 'F_DISBON.Program\\UtilsV5.lnb'
    lbo = 'F_DISBON.Program\\UtilsV5.lbo'
    # Same-size edits in a comment distinguish the source copies without
    # changing the PLC program's instructions or repairing its baseline errors.
    old = 'Check if bit'.encode('utf-16le')
    tags = ((lnb, 'LNBSR if bit'), (lbo, 'LBOSR if bit'))
    plans = []
    for name, text in tags:
        raw = streams[name]
        assert raw.count(old) == 1 and len(text.encode('utf-16le')) == len(old)
        plans.append((name[-3:] + '-only', name, raw.replace(old, text.encode('utf-16le'))))
    # Each of the six suspected address slots has a different marker. This
    # probe asks which text reaches the frontend, not whether these addresses
    # constitute a valid PLC assignment.
    global_name = 'Global1.gh'
    raw = streams[global_name]
    edited = raw
    changes = list(zip((146, 152, 162, 168, 178, 184),
                       ('D100', 'D101', 'D102', 'D103', 'D104', 'D105')))
    for offset, value in reversed(changes):
        assert edited[offset:offset+6] == _string('')
        edited = edited[:offset] + _string(value) + edited[offset+6:]
    plans.append(('structure-array-fields', global_name, edited))
    if args.extensions:
        raw = streams[global_name]
        # Hypothesis: the apparent DWORD at 174 is a counted empty string
        # without a terminator, not a fixed integer field.
        third_slot = raw[:174] + _string('D106') + raw[178:]
        # Generate a scalar structure declaration with two member pairs; all
        # remaining rows and the structure definition itself stay unchanged.
        scalar = b''.join((_string('AM_EVENTS'), _string('ST_AM_EVENT'), struct.pack('<I',8),
            _string(''), _string(''), struct.pack('<II',1,2),
            *(_string(v) for v in ('D110','D111','D112','D113','', '')),
            struct.pack('<I',1), _string(''), struct.pack('<II',0,9), _string('ST_AM_EVENT')))
        plans = [('array-third-slot',global_name,third_slot),
                 ('scalar-member-pairs',global_name,raw[:58]+scalar+raw[248:])]
    results = []
    for case, name, replacement in plans:
        directory = OUT / case
        directory.mkdir()
        changed, receipt = patch_raw(source, name, streams[name], replacement)
        after = {s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}
        assert set(after) == set(streams)
        assert [k for k in streams if streams[k] != after[k]] == [name]
        path = directory / 'candidate.gxw'
        path.write_bytes(changed)
        (directory / 'prediction-before-native.json').write_text(json.dumps(dict(
            source_sha256=sha256(source), candidate_sha256=sha256(changed), target=name,
            receipt=receipt, other_nested_payloads_byte_identical=True), indent=2), encoding='utf-8')
        for attempt in range(1, 5):
            native = directory / f'native-{attempt}'
            outcome = run(path, native, compile=True, snapshot_frontend=True,
                          program_check=True, project_alias='LIBCTRL')
            events = [json.loads(x) for x in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
            if not any(x.get('operation') == 'NativeTemporaryDirectoryCollision' for x in events):
                break
        row = dict(case=case, native_directory=str(native), outcome=outcome)
        if (native / 'frontend-snapshot.json').exists():
            snap = json.loads((native / 'frontend-snapshot.json').read_text(encoding='utf-8'))
            if name != global_name:
                matches = [r for r in snapshot_library_pous(snap) if (r['library'],r['name']) == ('UtilsV5','F_DISBON')]
                assert len(matches) == 1
                raw = base64.b64decode(matches[0]['program_raw_base64'])
                count, = struct.unpack_from('<I',raw,72)
                text = raw[76:76+count]
                row.update(frontend_text=text.decode('cp1252'), frontend_sha256=sha256(text))
            else:
                pool = next(r['data'] for r in snap['build']['relocations'] if r['offset'] == 20)
                raw = base64.b64decode(next(r['data']['raw'] for r in pool['relocations'] if r['offset'] == 8))
                row.update(native_global_rows=native_global_rows(raw))
                try:
                    row['source_rows'] = source_rows(replacement,False)
                except ValueError as exc:
                    row['source_hypothesis_gap'] = str(exc)
        pcode = native/'pcode-0-0.bin'
        baseline = P/'fx3g-library-native-baseline/native-1/pcode-0-0.bin'
        row['compiled_body_matches_baseline'] = pcode.exists() and pcode.read_bytes() == baseline.read_bytes()
        results.append(row)
        (OUT/'comparison.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
        print(json.dumps(dict(case=case, open=outcome['open_succeeded'], rejected=outcome['compiler_rejected'],
            compiled_body_matches_baseline=row['compiled_body_matches_baseline'],
            frontend_tag=(row.get('frontend_text') or '')[:40],
            first_global=(row.get('native_global_rows') or [None])[0])),flush=True)


if __name__ == '__main__':
    main()
