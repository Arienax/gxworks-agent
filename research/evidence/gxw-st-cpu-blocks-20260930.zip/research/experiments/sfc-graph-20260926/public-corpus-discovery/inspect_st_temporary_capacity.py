"""Cross-check first-fit reuse against saved native slot snapshots.

The rule checked here is deliberately restricted to slots in states 1/2 with
pin flag29 clear. Other native states are retained as unhandled observations.
No allocator or compiler code is invoked by this analyzer.
"""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from probe_minimal_conditional_port_writes import save
from verify_temporary_check_correspondence import verify
P=Path(__file__).resolve().parent


def main():
    groups=sys.argv[1:] or ['st-temporary-capacity-holdouts-20260930','st-temporary-capacity-check-minimization-20260930','st-temporary-capacity-rung-controls-20260930']
    cases=[]
    for group in groups:
        for case in json.loads((P/group/'comparison.json').read_text()):
            n=Path(case['native_directory']);selections=[];requests=[]
            for e in case['temporary_events']:
                if e.get('name')=='select':
                    before=e['before'];row=dict(compile_id=e['compile_id'],sequence=e['sequence'],request_type=e['args'][0],request_count=e['args'][1],native_index=e['result'],before=before)
                    if any(s['state'] not in (1,2) or s['flag29'] for s in before):
                        row.update(handling='unhandled-state-or-pin')
                    else:
                        used={s['index']:s for s in before};expected=None;chosen=None
                        for i in range(200):
                            s=used.get(i)
                            if s is None:expected=i;break
                            if s['state']==2 and s['type']==row['request_type'] and s['count']>=row['request_count']:
                                expected=i;chosen=s;break
                        if expected is None:expected=200
                        assert expected==row['native_index'],row
                        row.update(handling='verified-first-fit',expected_index=expected,
                            reused_capacity=None if chosen is None else chosen['count'],
                            later_exact_fit=[] if chosen is None else [s['index'] for s in before if s['index']>chosen['index'] and s['state']==2 and s['type']==row['request_type'] and s['count']==row['request_count']])
                    selections.append(row)
                elif e.get('name')=='request' and e['args'][1:3]==[-1,-1]:
                    typ,count=e['args'][0],e['args'][3]
                    matches=[s for s in e['after'] if s['type']==typ and s['operand'][0]==e['result']]
                    assert len(matches)==1
                    chosen=matches[0];previous=next((s for s in e['before'] if s['index']==chosen['index']),None)
                    if previous is not None:assert chosen['count']==previous['count']
                    requests.append(dict(compile_id=e['compile_id'],sequence=e['sequence'],type=typ,requested_count=count,
                        index=chosen['index'],address=chosen['operand'],capacity=chosen['count'],
                        reused=previous is not None,capacity_preserved=previous is not None and chosen['count']==previous['count']))
            cases.append(dict(group=group,case=case['case'],input_sha256=sha256((n/'input.gxw').read_bytes()),
                prediction_identical=case['prediction_identical'],check=case['check'],
                selections=selections,requests=requests))
    allselections=[s for c in cases for s in c['selections']];allrequests=[s for c in cases for s in c['requests']]
    summary=dict(cases=len(cases),selections=len(allselections),verified_first_fit=sum(s['handling']=='verified-first-fit' for s in allselections),
        unhandled_selections=sum(s['handling']!='verified-first-fit' for s in allselections),
        larger_slot_before_later_exact_fit=sum(bool(s.get('later_exact_fit')) and s['reused_capacity']>s['request_count'] for s in allselections),
        reused_larger_capacity=sum(s['reused'] and s['capacity']>s['requested_count'] for s in allrequests),
        capacity_preserved_on_reuse=sum(s['capacity_preserved'] for s in allrequests))
    out=P/groups[-1]
    save(out/'slot-capacity-analysis.json',dict(scope='Saved native selection/request snapshots; not a general model of states other than 1/2 or pinned slots.',summary=summary,cases=cases))
    save(out/'current-check-export-correspondence.json',verify(groups))
    (out/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    print(json.dumps(summary))


if __name__=='__main__':main()
