"""Offline witness for saved straight-line nested-index counterexamples.

This is not a PLC executor or general simulator. It accepts only the observed
MOV/DMOV, integer +/-, multiply-by-one, LD SM400 and terminators. It evaluates
the finite initialized examples with explicit word storage and records every
indexed read. No PLC/simulator is loaded. Source evaluation is separate from
the token walk and uses the declared array bounds.
"""
from pathlib import Path
import ast,json,re,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from gxw.token_pou import LadderToken
from gxw.token_q import q_instruction_header,q_operand_groups
from gxw.project_metadata import read_project_text_context
from probe_gxw_st_sources import replace_observed_st
from probe_minimal_conditional_port_writes import streams,save
from source_q_direct_declarations import DirectDeclarations
P=Path(__file__).resolve().parent
OUT=P/'st-nested-index-counterexamples-20260930'


def decode(raw):
    groups=[];pending=[];at=0
    while at<len(raw):
        size=raw[at];token=raw[at:at+size]
        if size<2 or len(token)!=size or token[-1]!=size:raise ValueError('token framing')
        if token[1]<0x80:
            if pending:groups.append(pending)
            pending=[]
        pending.append(LadderToken(at,token));at+=size
    if pending:groups.append(pending)
    result=[]
    for tokens in groups:
        op,arity=q_instruction_header(tokens[0].raw)
        operands=q_operand_groups(tuple(tokens[1:]),text_encoding='cp932')
        if arity!=len(operands):raise ValueError('token arity')
        result.append(dict(kind='instruction',op=op,args=[t for _,t in operands],offset=tokens[0].offset,
            raw=''.join(t.raw.hex() for t in tokens),operand_bytes=[''.join(t.raw.hex() for t in ts) for ts,_ in operands]))
    return result


def source_witness(source):
    content={k:v for k,v in streams(source).items() if k!='CGTable.dat'}
    context=read_project_text_context(next(v for k,v in content.items() if k.endswith('.prj')))
    if context['cpu']!='Q03UDV':raise ValueError('CPU')
    decl=DirectDeclarations(content,context['text_encoding']);decl.add_owner('POU_01')
    variables={name:0 for name in decl.bound['POU_01']};arrays={}
    for name,item in decl.bound['POU_01'].items():
        if item.get('dimensions'):
            if len(item['dimensions'])!=1:raise ValueError('only one-dimensional witness arrays')
            arrays[name]={i:0 for i in range(item['dimensions'][0]['lower'],item['dimensions'][0]['upper']+1)}
    _,text=replace_observed_st(content['POU_01.Program.pou'],'')
    def evaluate(node):
        if isinstance(node,ast.Name):return variables[node.id.casefold()]
        if isinstance(node,ast.Constant) and type(node.value) is int:return node.value
        if isinstance(node,ast.Subscript) and isinstance(node.value,ast.Name):
            return arrays[node.value.id.casefold()][evaluate(node.slice)]
        if isinstance(node,ast.UnaryOp) and isinstance(node.op,ast.USub):return -evaluate(node.operand)
        if isinstance(node,ast.BinOp):
            left,right=evaluate(node.left),evaluate(node.right)
            if isinstance(node.op,ast.Add):return left+right
            if isinstance(node.op,ast.Sub):return left-right
        raise ValueError('source outside witness grammar')
    assignments=[]
    for statement in text.split(';'):
        if not statement.strip():continue
        target,expression=statement.split(':=')
        value=evaluate(ast.parse(expression.strip(),mode='eval').body)
        if not -32768<=value<=32767:raise ValueError('source witness would overflow INT')
        destination=ast.parse(target.strip(),mode='eval').body
        if isinstance(destination,ast.Name):variables[destination.id.casefold()]=value
        elif isinstance(destination,ast.Subscript) and isinstance(destination.value,ast.Name):
            arr=arrays[destination.value.id.casefold()];index=evaluate(destination.slice)
            if index not in arr:raise ValueError('source witness index outside declared bounds')
            arr[index]=value
        else:raise ValueError('source assignment target')
        assignments.append(dict(target=target.strip(),value=value))
    item=decl.bound['POU_01']['prober1']
    return dict(result=variables['prober1'],destination=item['family']+str(item['number']),assignments=assignments,source_text=text)


def token_witness(records,destination):
    memory={};steps=[];indexed_reads=[]
    def signed(value,bits):
        value&=(1<<bits)-1
        return value-(1<<bits) if value&(1<<(bits-1)) else value
    def address(token):
        match=re.fullmatch(r'([DZ])([0-9]+)(?:Z([0-9]+))?',token)
        if not match:raise ValueError('unobserved witness address '+token)
        family,number,z=match.groups();number=int(number)
        if z is not None:number+=signed(memory.get(('Z',int(z)),0),16)
        if number<0:raise ValueError('negative physical address')
        return family,number
    def read(token,bits):
        if re.fullmatch(r'K-?[0-9]+',token):return int(token[1:])
        if re.fullmatch(r'H[0-9A-F]+',token):return int(token[1:],16)
        family,number=address(token)
        if (family,number) not in memory:raise ValueError('uninitialized witness read '+token)
        value=memory[(family,number)]
        if bits==32:
            if (family,number+1) not in memory:raise ValueError('uninitialized upper word '+token)
            value|=memory[(family,number+1)]<<16
        value=signed(value,bits)
        if 'Z' in token[1:]:indexed_reads.append(dict(token=token,effective=family+str(number),value=value,bits=bits))
        return value
    def write(token,value,bits):
        family,number=address(token);memory[(family,number)]=value&0xffff
        if bits==32:memory[(family,number+1)]=(value>>16)&0xffff
        return family+str(number)
    for record in records:
        op,args=record['op'],record['args']
        if op=='LD' and args==['SM400'] or op in ('FEND','NOP','END') and not args:continue
        width=32 if op.startswith('D') else 16
        if op in ('MOV','DMOV') and len(args)==2:value=read(args[0],width)
        elif op in ('+','-','D+','D-') and len(args) in (2,3):
            left,right=(read(args[0],width),read(args[1],width)) if len(args)==3 else (read(args[1],width),read(args[0],width))
            value=left-right if op.endswith('-') else left+right
        elif op=='*' and len(args)==3 and args[1]=='K1':value=read(args[0],16);width=32
        else:raise ValueError('instruction outside bounded witness: '+str(record))
        effective=write(args[-1],value,width)
        steps.append(dict(offset=record['offset'],op=op,args=args,bits=width,value=signed(value,width),effective_destination=effective))
    return dict(result=read(destination,16),steps=steps,indexed_reads=indexed_reads)


def main():
    plan=json.loads((OUT/'experiment-plan.json').read_text())
    native_listings={r['case']:r['records'] for r in json.loads((OUT/'native-listings.json').read_text())}
    result=[]
    for row in json.loads((OUT/'comparison.json').read_text()):
        d=OUT/row['case'];native=Path(row['native_directory']);source=(d/'input.gxw').read_bytes();code=(native/'pcode-0-0.bin').read_bytes()
        witness=source_witness(source);assert witness['result']==plan['expected_source_results'][row['case']]
        decoded=decode(code)
        assert [{k:r[k] for k in ('kind','op','args')} for r in decoded]==native_listings[row['case']]
        actual=token_witness(decoded,witness['destination'])
        messages=[json.loads(l) for l in (native/'events.jsonl').read_text().splitlines()]
        sink=[m['payload'] for m in messages if m.get('type')=='send' and m['payload'].get('event')=='sink-record']
        aliased=[dict(op=e['name']['latin1'],operands=e['operands']) for e in sink
            if len(e['operands'])==3 and e['operands'][0]['raw']==e['operands'][1]['raw'] and e['operands'][0]['raw'].startswith('5a000000')]
        record=dict(case=row['case'],input_sha256=sha256(source),pcode_sha256=sha256(code),source=witness,token_witness=actual,
            source_matches_token=witness['result']==actual['result'],core_matches_native_decode=True,
            preencoding_identical_indexed_operands=aliased,check=row['check'],reopen=row.get('reopen'),decoded=decoded)
        result.append(record)
        print(json.dumps(dict(case=row['case'],source=witness['result'],token=actual['result'],equal=record['source_matches_token'],sink_aliases=len(aliased))),flush=True)
    save(OUT/'offline-witnesses.json',dict(scope='Initialized finite straight-line integer cases, no uninitialized reads or INT source overflow. Offline arithmetic witness, not physical PLC execution.',cases=result))
    (OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())


if __name__=='__main__':main()
