"""Isolated offline controls for typed arrays and address arithmetic."""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from gxw.lossless import inspect_project,sha256
from gxw.declarations import parse_declarations,edit_declarations,serialize_declarations
from probe_gxw_st_sources import replace_observed_st
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_compiled_references import inspect
from replay_gxw_workspace import run,prepare,trace_prepared
from native_gxw_compiler import native_table_dump
P=Path(__file__).resolve().parent
case=sys.argv[1] if len(sys.argv)>1 else 'static-layout'
source=(P/'samples/boxid.gxw').read_bytes()
before={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
global_rows=[];local_rows=[];calls=[]
if case in ('static-layout','static-layout-md','static-layout-typed'):
 specs=[('Bits','ARRAY[-2..1] OF BOOL','M1100','%MX0.1100','PLS_M',[-2,-1,0,1],None),
        ('Words','ARRAY[-2..1] OF INT','D100','%MW0.100','MOV_M',[-2,-1,0,1],'SinkInt'),
        ('Doubles','ARRAY[3..5] OF DINT','D200','%MW0.200','DMOV_M',[3,4,5],'SinkDInt'),
        ('Reals','ARRAY[-1..1] OF REAL','D220','%MW0.220','EMOV_M',[-1,0,1],'SinkReal'),
        ('Times','ARRAY[1..3] OF TIME','D240','%MW0.240','DMOV_M',[1,2,3],'SinkTime'),
        ('Matrix','ARRAY[1..2,-1..1] OF INT','D300','%MW0.300','MOV_M',['1,-1','1,0','1,1','2,-1','2,0','2,1'],'SinkInt')]
 for name,typ,device,iec,fn,indices,sink in specs:
  for scope in ['G','L']:
   row=dict(name=scope+'_'+name,data_type=typ)
   if scope=='G':
    if case!='static-layout' and name in ('Doubles','Reals','Times'):iec=iec.replace('%MW','%MD')
    row.update(device=device,iec_address=iec);global_rows.append(row)
   else:local_rows.append(row)
   for index in indices:
    argument=f'{scope}_{name}[{index}]'
    if case=='static-layout-typed' and name=='Times':calls.append(f'{sink} := {argument};')
    else:calls.append(f'{fn}(TRUE, {argument}'+(f', {sink}' if sink else '')+');')
 local_rows += [dict(name='Sink'+t,data_type=t.upper()) for t in ['Int','DInt','Real','Time']]
elif case=='string-layout':
 for length in [1,2,3,4,5,20]:
  for scope in ['G','L']:
   row=dict(name=f'{scope}_Text{length}',data_type=f'ARRAY[-1..1] OF STRING[{length}]')
   if scope=='G':row.update(device=f'D{400+length*100}',iec_address=f'%MW0.{400+length*100}');global_rows.append(row)
   else:local_rows.append(row)
   calls += [f'SinkText{length} := {scope}_Text{length}[{index}];' for index in [-1,0,1]]
  local_rows.append(dict(name=f'SinkText{length}',data_type=f'STRING[{length}]'))
elif case in ('dynamic-layout','dynamic-index-shapes','dynamic-constant-folding'):
 specs=[('Words','ARRAY[-2..1] OF INT','D100','%MW0.100','MOV_M','IndexA','SinkInt'),
        ('Doubles','ARRAY[3..5] OF DINT','D200','%MD0.200','DMOV_M','IndexA','SinkDInt'),
        ('Matrix','ARRAY[1..2,-1..1] OF INT','D300','%MW0.300','MOV_M','IndexA,IndexB','SinkInt'),
        ('Text5','ARRAY[-1..1] OF STRING[5]','D500','%MW0.500',None,'IndexA','SinkText5')]
 for name,typ,device,iec,fn,indices,sink in specs:
  for scope in ['G','L']:
   row=dict(name=scope+'_'+name,data_type=typ)
   if scope=='G':row.update(device=device,iec_address=iec);global_rows.append(row)
   else:local_rows.append(row)
   argument=f'{scope}_{name}[{indices}]'
   calls.append(f'{fn}(TRUE, {argument}, {sink});' if fn else f'{sink} := {argument};')
 local_rows += [dict(name=n,data_type=t) for n,t in [('SinkInt','INT'),('SinkDInt','DINT'),('SinkText5','STRING[5]'),('IndexA','INT'),('IndexB','INT')]]
 if case=='dynamic-index-shapes':
  global_rows.append(dict(name='G_Bits',data_type='ARRAY[-2..1] OF BOOL',device='M1100',iec_address='%MX0.1100'))
  local_rows.append(dict(name='L_Bits',data_type='ARRAY[-2..1] OF BOOL'))
  calls=['MOV_M(TRUE, G_Words[IndexA], L_Words[IndexB]);',
         'DMOV_M(TRUE, G_Doubles[IndexA], L_Doubles[IndexB]);',
         'MOV_M(TRUE, G_Words[IndexA+1], SinkInt);',
         'MOV_M(TRUE, G_Matrix[1,IndexB], SinkInt);',
         'MOV_M(TRUE, G_Matrix[IndexA,0], SinkInt);',
         'MOV_M(TRUE, G_Matrix[IndexA,IndexB], L_Matrix[IndexB,IndexA]);',
         'SinkText5 := G_Text5[IndexA+1];',
         'L_Text5[IndexB] := G_Text5[IndexA];',
         'PLS_M(TRUE, G_Bits[IndexA]);',
         'PLS_M(TRUE, L_Bits[IndexB]);']
 if case=='dynamic-constant-folding':
  calls=['MOV_M(TRUE, G_Matrix[2,IndexB], SinkInt);',
         'MOV_M(TRUE, G_Matrix[2,IndexB+1], SinkInt);',
         'MOV_M(TRUE, G_Matrix[IndexA,1], SinkInt);',
         'MOV_M(TRUE, G_Matrix[2,0], SinkInt);',
         'MOV_M(TRUE, G_Words[IndexA], L_Words[IndexA]);',
         'MOV_M(TRUE, G_Matrix[2,IndexB], L_Matrix[2,IndexA]);',
         'DMOV_M(TRUE, G_Doubles[IndexA], L_Doubles[IndexA]);',
         'L_Text5[IndexA] := G_Text5[IndexA];']
elif case in ('word-bit-layout','word-bit-dynamic','word-bit-transfer','word-bit-call-specializations','word-bit-call-q','word-bit-fb-output','word-bit-fb-members','word-bit-fb-two-instances','word-bit-template-contrast','word-bit-call-indexed-enable','word-bit-call-boolean-enable'):
 global_rows=[dict(name='G_WordBits',data_type='ARRAY[-2..17] OF BOOL',device='D700.E',iec_address='%MX0.700.14')]
 local_rows=[dict(name='IndexA',data_type='INT')]
 indices=[-2,-1,0,1,13,14,15,16,17] if case=='word-bit-layout' else ['IndexA']
 calls=[f'PLS_M(TRUE, G_WordBits[{i}]);' for i in indices]
 if case=='word-bit-transfer':
  local_rows += [dict(name='IndexB',data_type='INT'),dict(name='SinkBit',data_type='BOOL'),dict(name='L_Bits',data_type='ARRAY[-2..17] OF BOOL')]
  calls=['SinkBit := G_WordBits[IndexA];',
         'G_WordBits[IndexA] := SinkBit;',
         'L_Bits[IndexB] := G_WordBits[IndexA];',
         'G_WordBits[IndexA] := L_Bits[IndexB];',
         'PLS_M(G_WordBits[IndexA], SinkBit);']
 if case in ('word-bit-call-specializations','word-bit-call-q'):
  local_rows.append(dict(name='EnableBit',data_type='BOOL'))
  functions=('PLS','PLF','ALT','ALTP','SET','RST') if case=='word-bit-call-specializations' else ('PLS','PLF','SET','RST')
  calls=[f'{fn}_M(EnableBit, G_WordBits[IndexA]);' for fn in functions]
 if case in ('word-bit-fb-output','word-bit-fb-members','word-bit-fb-two-instances'):
  local_rows += [dict(name='IndexB',data_type='INT'),dict(name='EdgeProbe',data_type='R_TRIG',kind='function_block'),dict(name='LatchProbe',data_type='SR',kind='function_block')]
  calls=['EdgeProbe(_CLK := G_WordBits[IndexA], Q => G_WordBits[IndexB]);',
         'LatchProbe(_S1 := G_WordBits[IndexA], RESET := FALSE, Q1 => G_WordBits[IndexB]);']
  if case=='word-bit-fb-members':
   calls=['EdgeProbe(_CLK := G_WordBits[IndexA]);','G_WordBits[IndexB] := EdgeProbe.Q;',
          'LatchProbe(_S1 := G_WordBits[IndexA], RESET := FALSE);','G_WordBits[IndexB] := LatchProbe.Q1;']
  if case=='word-bit-fb-two-instances':
   local_rows[-1]=dict(name='EdgeProbe2',data_type='R_TRIG',kind='function_block')
   calls=['EdgeProbe(_CLK := G_WordBits[IndexA]);','G_WordBits[IndexB] := EdgeProbe.Q;',
          'EdgeProbe2(_CLK := G_WordBits[IndexB]);','G_WordBits[IndexA] := EdgeProbe2.Q;']
 if case=='word-bit-template-contrast':
  local_rows += [dict(name='EnableBit',data_type='BOOL'),dict(name='SinkBit',data_type='BOOL'),dict(name='L_Bits',data_type='ARRAY[-2..17] OF BOOL')]
  calls=['PLS_M(EnableBit, SinkBit);','PLS_M(EnableBit, G_WordBits[-2]);',
         'PLS_M(EnableBit, G_WordBits[IndexA]);','PLS_M(EnableBit, L_Bits[IndexA]);']
 if case=='word-bit-call-indexed-enable':
  local_rows += [dict(name='IndexB',data_type='INT')]
  calls=['PLS_M(G_WordBits[IndexA], G_WordBits[IndexB]);','PLS_M(G_WordBits[IndexA], G_WordBits[IndexA]);',
         'SET_M(G_WordBits[IndexA], G_WordBits[IndexB]);']
 if case=='word-bit-call-boolean-enable':
  local_rows += [dict(name='IndexB',data_type='INT'),dict(name='EnableBit',data_type='BOOL')]
  calls=['PLS_M(EnableBit AND G_WordBits[IndexA], G_WordBits[IndexB]);',
         'PLS_M(NOT G_WordBits[IndexA], G_WordBits[IndexB]);',
         'PLS_M(G_WordBits[IndexA] OR G_WordBits[IndexB], G_WordBits[IndexA]);',
         'PLS_M(G_WordBits[IndexA] XOR G_WordBits[IndexB], G_WordBits[IndexA]);']
elif case in ('real-literal-rounding','real-literal-rounding-valid'):
 local_rows=[dict(name='SinkReal',data_type='REAL')]
 calls=[f'SinkReal := {v};' for v in ['1.23456789','1.2345674','1.2345675','1.2345685','-1.23456789','0.000123456789','123456789.0',
        '1.0000000596046448','1.0000001192092896','16777217.0','-0.0','0.0','1.1754944E-38','3.4028234E38']]
 if case=='real-literal-rounding-valid':calls=[c for c in calls if '1.1754944E-38' not in c]
else:raise ValueError('Unknown bounded control')
name='POU_01.Program.pou';_,original=replace_observed_st(before[name],'')
program,_=replace_observed_st(before[name],original+'\r\n'+'\r\n'.join(calls)+'\r\n')
changed,receipt=patch_raw(source,name,before[name],program);receipts=[receipt];changed_names={name}
for labels,rows in [('Control.gh',global_rows),('POU_01.Labels.lh',local_rows)]:
 if not rows:continue
 doc=parse_declarations(before[labels],logical_name=labels)
 edited=serialize_declarations(edit_declarations(doc,upserts=rows))
 changed,receipt=patch_raw(changed,labels,before[labels],edited);receipts.append(receipt);changed_names.add(labels)
after={s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}
assert all(after[k]==v for k,v in before.items() if k not in changed_names)
out=P/'array-operand-controls'/case;out.mkdir(parents=True,exist_ok=False)
(out/'changed.gxw').write_bytes(changed)
(out/'mutation.json').write_text(json.dumps(dict(source_sha256=sha256(source),changed_sha256=sha256(changed),calls=calls,globals=global_rows,locals=local_rows,unrelated_payloads='byte-identical',receipts=receipts),indent=2))
queries=[dict(name=r['name'],keys=[dict(category=1,value=r['name'])]+([] if r in global_rows else [dict(category=4,value='POU_01')])) for r in global_rows+local_rows]
native=run(out/'changed.gxw',out/'native',compile=True,export_project=True,snapshot_frontend=True,assignment_queries=queries)
result=dict(native=native)
print(json.dumps({k:native.get(k) for k in ['returncode','compile_completed','compiler_rejected','diagnostics']}),flush=True)
(out/'comparison.json').write_text(json.dumps(result,indent=2))
if native.get('compiler_rejected') or not native.get('native_export'):sys.exit(1)
read=inspect(out/'native',out/'correlation');decoded=read['decoded_fragments']
result['calls']=[dict(line=o['source_line'],records=[r for g in o['compiled_records'] for r in decoded[g['decode_request']].get('records',[])]) for e in read['expansions'] for o in e.get('occurrences',[]) if o.get('source_line',{}).get('text','') in calls]
hook=out/'CombinedTrace.js'
hook.write_text((ROOT/'research/native/CompilerTrace.js').read_text()+'\n'+(P/'TraceTemplateSubstitution.js').read_text())
attempts=[]
for attempt in range(1,9):
 trace_dir=out/('trace' if attempt==1 else f'trace-v{attempt}')
 prepare(out/'changed.gxw',trace_dir,compile=True,export_project=True)
 traced=trace_prepared(trace_dir,hook,timeout=55);attempts.append(dict(directory=trace_dir.name,outcome=traced))
 events=[json.loads(l) for l in (trace_dir/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
 if (trace_dir/'pcode-0-0.bin').exists():break
 if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):raise RuntimeError('Trace failure retained')
else:raise RuntimeError('Eight fresh trace processes collided')
result['trace_attempts']=attempts
result['trace_pcode_equal']=all((trace_dir/f).read_bytes()==(out/'native'/f).read_bytes() for f in native['outputs'])
captured=[]
for line in (trace_dir/'events.jsonl').read_text().splitlines():
 event=json.loads(line).get('payload',{})
 if event.get('event')!='enter' or event.get('name')!='Compile':continue
 buffers={v['label']:v for v in event['buffers']}
 if any(k.startswith('name_') and v.get('bytes') and bytes.fromhex(v['bytes']).split(b'\0')[0]==b'POU_01' for k,v in buffers.items()):captured.append(bytes.fromhex(buffers['symbolic_data']['bytes']))
assert len(captured)==1
(out/'captured-symbols.bin').write_bytes(captured[0])
result['table_reader']=native_table_dump(captured[0],out/'native-table-reader',read_constants=True)
(out/'comparison.json').write_text(json.dumps(result,indent=2))
print(json.dumps(dict(calls=len(result['calls']),trace_pcode_equal=result['trace_pcode_equal'],output=str(out))),flush=True)
