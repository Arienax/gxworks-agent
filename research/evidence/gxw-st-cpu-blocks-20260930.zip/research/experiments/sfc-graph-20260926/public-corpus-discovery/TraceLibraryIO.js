"use strict";
const handles = new Map();
const captures = new Map();
function location(p) { const m=Process.findModuleByAddress(p);return m?m.name+"+"+p.sub(m.base):p.toString(); }
function stack(ctx) { return Thread.backtrace(ctx,Backtracer.ACCURATE).map(location); }
for (const name of ["CreateFileW","CreateFileA"]) {
 Interceptor.attach(Module.getGlobalExportByName(name),{onEnter(a){try{this.path=name.endsWith("W")?a[0].readUtf16String():a[0].readCString();}catch(e){}},onLeave(r){if(this.path&&/\.(lib|lif|asc)$/i.test(this.path)){handles.set(r.toString(),this.path);send({event:"library-open",path:this.path,handle:r.toString(),stack:stack(this.context)});}}});
}
Interceptor.attach(Module.getGlobalExportByName("ReadFile"),{onEnter(a){this.name=handles.get(a[0].toString());this.buf=a[1];this.size=a[2].toUInt32();this.actual=a[3];},onLeave(r){if(!this.name||r.toInt32()===0)return;const n=this.actual.isNull()?this.size:this.actual.readU32();send({event:"library-read",path:this.name,size:n,head:Array.from(new Uint8Array(this.buf.readByteArray(Math.min(n,64)))),stack:stack(this.context)});}});
Interceptor.attach(Module.getGlobalExportByName("WriteFile"),{onEnter(a){
 const key=a[0].toString(),name=handles.get(key);
 if(!globalThis.CAPTURE_DIRECTORY||!name||!name.toLowerCase().endsWith(".asc"))return;
 let capture=captures.get(key);
 if(!capture){const path=globalThis.CAPTURE_DIRECTORY+"/"+name.split(/[\\/]/).pop()+".capture";capture=new File(path,"wb");captures.set(key,capture);send({event:"library-capture",source:name,path});}
 capture.write(a[1].readByteArray(a[2].toUInt32()));capture.flush();
}});
Interceptor.attach(Module.getGlobalExportByName("CloseHandle"),{onEnter(a){const key=a[0].toString();handles.delete(key);const f=captures.get(key);if(f){captures.delete(key);f.close();}}});
