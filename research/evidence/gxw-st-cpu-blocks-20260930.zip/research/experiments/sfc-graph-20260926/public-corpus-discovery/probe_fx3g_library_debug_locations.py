from pathlib import Path
from collections import Counter
import sys,json
ROOT=Path(__file__).resolve().parents[4];sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from replay_gxw_workspace import run
from gxw.lossless import sha256
from gxw.token_pou import parse_token_region
from gxw.token_listing import decode_token_program
from gxw.compiler_debug import parse_compiler_debug
import probe_gxw_debug_locations as reader
P=Path(__file__).resolve().parent;OUT=P/'fx3g-library-debug-locations-v5';OUT.mkdir(exist_ok=False)
(OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
source=P/'cross-family-source-holdouts/case-00/input.gxw';previous=P/'fx3g-original-fresh-check/native-1'
pcode=(previous/'pcode-0-0.bin').read_bytes();listing=decode_token_program(parse_token_region(pcode,0,len(pcode)),profile='fx3g',text_encoding='cp1252')
steps=sorted({r.step for r in listing.records if getattr(r,'step',None) is not None});assert len(steps)<=4096
queries=[dict(resource='MAIN',start_step=s,step_count=1,timestamp=0) for s in steps]
(OUT/'queries-before-native.json').write_text(json.dumps(dict(source_sha256=sha256(source.read_bytes()),pcode_sha256=sha256(pcode),queries=queries),indent=2),encoding='utf-8')
for attempt in range(1,5):
 native=OUT/f'native-{attempt}';outcome=run(source,native,compile=True,export_project=True,snapshot_compiler_cache=True,program_check=True,pcode_location_queries=queries,project_alias='FX3GLOC')
 events=[json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
 if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
answers=json.loads((native/'native-pcode-locations.json').read_text(encoding='utf-8-sig'))
debugraw=(native/'compiler_DZComp/DebugInformation2.dat').read_bytes();debug=parse_compiler_debug(debugraw);maps=reader.search_maps(debug,encoding='cp1252');reader.search_maps=lambda d,encoding:maps
comparisons=[]
for a in answers:
 ours=reader.lookup(debug,'MAIN',a['query']['start_step'],encoding='cp1252')
 comparisons.append(dict(step=a['query']['start_step'],ours=ours,native=a['location'],native_code=a['code'],equal=ours.get('location')==a['location'] if ours['handling'].startswith('native-compatible') or ours['handling'] in ('no-stored-element','native-terminal-step') else None))
(OUT/'comparisons.json').write_text(json.dumps(comparisons,indent=2),encoding='utf-8')
summary=dict(queries=len(answers),native_success=sum(a['code']==0 for a in answers),handling=dict(Counter(c['ours']['handling'] for c in comparisons)),differences=sum(c['equal'] is False for c in comparisons),comparable=sum(c['equal'] is not None for c in comparisons),pcode_unchanged=(native/'pcode-0-0.bin').read_bytes()==pcode,debug_sha256=sha256(debugraw),debug_elements=len(debug.elements))
(OUT/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');print(json.dumps(summary))
