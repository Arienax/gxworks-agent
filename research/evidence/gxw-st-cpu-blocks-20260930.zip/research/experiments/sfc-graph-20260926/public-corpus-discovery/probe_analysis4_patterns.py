import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from replay_gxw_workspace import run
P=Path(__file__).resolve().parent
out=P/'analysis4-collection-patterns'
patterns=[15,0,1,2,4,8,16,31,255,0xffffffff]
queries=[dict(name=f'all-{n}',keys=[],declared=1,plural=1,collect_pattern=n,symbol='',scope='') for n in patterns]
for name in ('TimerProbe.EN','TimerProbe.ENO','EN','ENO'):
 queries.append(dict(name=name,keys=[],declared=1,plural=1,collect_pattern=0xffffffff,symbol=name,scope='POU_01' if '.' in name else 'POU_01.TimerProbe'))
r=run(P/'ST-standard-timer-controls/TON_E_member_read/native/native-saved.gxw',out,compile=True,analysis_version=4,analysis_queries=queries)
print(json.dumps(r),flush=True)
f=out/'native-program-analysis.json'
if f.exists():
 data=json.loads(f.read_text(encoding='utf-8-sig'))
 summary=[dict(query=q['query'],hr=q['hresult'],code=q['code'],count=q['count'],timer=[{k:v for k,v in row.items() if k!='raw_base64'} for row in q['rows'] if 'timerprobe' in str(row).lower()]) for q in data['queries']]
 (out/'summary.json').write_text(json.dumps(summary,indent=2))
 print(json.dumps([dict(query=q['query']['name'],hr=q['hr'],code=q['code'],count=q['count'],names=sorted(set(r['name'] for r in q['timer']))) for q in summary]))
