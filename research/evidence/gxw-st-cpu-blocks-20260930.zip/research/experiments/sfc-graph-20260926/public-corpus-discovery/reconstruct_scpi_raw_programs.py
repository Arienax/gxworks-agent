"""Assemble complete controlled MAIN PCode, including materialized constants."""
from pathlib import Path
import base64,json,re,subprocess,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.compiler_tables import parse_compiler_tables
from gxw.token_pou import parse_token_fragment
from probe_gxw_simple_fb import frame_source,observe_calls
from probe_gxw_operand_bindings import resolve_simple_instance_label
P=Path(__file__).resolve().parent
OUT=P/'scpi-raw-program-reconstruction';OUT.mkdir(exist_ok=False)
(OUT/'probe.py').write_bytes(Path(__file__).read_bytes())
rows=[]
for case in json.loads((P/'scpi-alias-device-methods/comparison.json').read_text()):
 assert all(case['exact_pcode'].values()) and not case['errors']
 source=Path(case['source']).read_bytes();assert sha256(source)==case['source_sha256']
 frame=frame_source(next(s.raw for s in inspect_project(source).streams if s.logical_name=='MAIN.Program.pou'));calls=observe_calls(frame)['calls'];assert len(calls)==2
 baseline=Path(case['baseline_directory']);tables=parse_compiler_tables(next(s.raw for s in inspect_project((baseline/'native-saved.gxw').read_bytes()).streams if s.logical_name=='CGTable.dat'))
 main=next(tables.pou_at(r.table_offset) for r in tables.tables[1].records if tables.pou_at(r.table_offset).name_bytes==b'MAIN')
 instance=next(c.record.table_offset for c in tables.components(main) if c.name_bytes==b'SCPI_1')
 proof=json.loads((P/'scpi-alias-device-methods'/case['case']/'raw-forwarding.json').read_text())
 directory=OUT/case['case'];directory.mkdir();parts=[];cursor=frame.tokens[0].offset;preserved=0;materialized=0
 for i,call in enumerate(calls):
  outside=frame.raw[cursor:call['offset']];assert not any(t.raw[1]==0xdf for t in parse_token_fragment(outside,0,len(outside)).tokens)
  parts.append(outside);preserved+=len(outside)
  nonalias=[e for e in proof['evidence'] if e['call']==i and not e['predicted_alias']]
  if nonalias:
   assert len(nonalias)==1 and nonalias[0]['port']=='iUnitNo' and nonalias[0]['direction']=='input'
   span=call['input_fragment'];blob=frame.raw[span['offset']:span['offset']+span['length']];tokens=parse_token_fragment(blob,0,len(blob)).tokens
   groups=[]
   for t in tokens:
    if t.raw[1]<0x90:groups.append([])
    groups[-1].append(t.raw)
   assert len(groups)==4 and groups[2][1][2:-1]==b'_TRUE' and groups[3][-1][2:-1]==b'_iUnitNo'
   bound=resolve_simple_instance_label("'iUnitNo",instance,tables,cpu='Q03UDV',encoding='cp932');m=re.fullmatch(r'D([0-9]+)',bound.get('operand') or '');assert m and not bound['gaps']
   number=int(m[1]);n=max(1,(number.bit_length()+7)//8);assert n<=2
   dst=bytes([n+3,0xa8])+number.to_bytes(n,'little')+bytes([n+3])
   # Observed TRUE lowering; source literal bytes themselves are untouched.
   candidate=[groups[2][0]+bytes.fromhex('0591900105'),b''.join(groups[3][:-1])+dst]
   materialized+=len(candidate);ctx=P/'scpi-raw-expansion-reconstruction'/(case['case']+'-'+str(i))/'device-context.bin'
   protocol=''.join(f'check-instruction\t{k}\t'+base64.b64encode(b).decode()+'\n' for k,b in enumerate(candidate))
   run=subprocess.run([str(P/'q-public-check-replay/PublicCheckOracle.exe'),'D:/GXWORKS2/Easysocket/CodeGenerator/ECCodeGenerator2.dll','209','1','q','1',str(ctx)],input=protocol.encode(),capture_output=True,timeout=45,creationflags=subprocess.CREATE_NO_WINDOW)
   (directory/f'caller-{i}-stdout.jsonl').write_bytes(run.stdout);(directory/f'caller-{i}-stderr.bin').write_bytes(run.stderr)
   (directory/f'caller-{i}-requests.json').write_text(json.dumps(dict(bound=bound,inputs=[b.hex() for b in candidate]),indent=2))
   answers=[json.loads(l) for l in run.stdout.splitlines()];assert run.returncode==0 and len(answers)==len(candidate) and all(a['return_code']=='0x00000000' for a in answers)
   parts.extend(base64.b64decode(a['output_base64']) for a in answers)
  bodyfile=P/'scpi-raw-expansion-reconstruction'/(case['case']+'-'+str(i))/'predicted-body.bin';parts.append(bodyfile.read_bytes())
  cursor=call['offset']+call['length']
 end=frame.tokens[0].offset+len(frame.body);suffix=frame.raw[cursor:end]
 assert not any(t.raw[1]==0xdf for t in parse_token_fragment(suffix,0,len(suffix)).tokens)
 preserved+=len(suffix);parts.append(suffix);predicted=b''.join(parts);(directory/'predicted-pcode.bin').write_bytes(predicted)
 native=(baseline/'pcode-0-0.bin').read_bytes();row=dict(case=case['case'],source_sha256=sha256(source),calls=2,body_records=326,materialized_caller_records=materialized,preserved_outer_bytes=preserved,output_bytes=len(predicted),predicted_sha256=sha256(predicted),native_sha256=sha256(native),byte_identical=predicted==native,scope='Full MAIN only; allocations supplied by native CGTable; widths supplied by pinned Q public check interface; no PLC/simulator validation.')
 (directory/'comparison.json').write_text(json.dumps(row,indent=2));rows.append(row);print(json.dumps(row),flush=True)
 assert row['byte_identical']
(OUT/'comparison.json').write_text(json.dumps(rows,indent=2))
