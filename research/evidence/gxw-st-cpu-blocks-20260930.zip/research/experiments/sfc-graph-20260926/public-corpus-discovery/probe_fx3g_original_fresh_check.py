from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[4];sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from replay_gxw_workspace import run
from gxw.lossless import sha256
P=Path(__file__).resolve().parent;OUT=P/'fx3g-original-fresh-check';OUT.mkdir(exist_ok=False)
(OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
source=P/'cross-family-source-holdouts/case-00/input.gxw'
for attempt in range(1,5):
 native=OUT/f'native-{attempt}';outcome=run(source,native,compile=True,program_check=True,export_project=True,snapshot_frontend=True,project_alias='FX3GFRESH')
 events=[json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
 if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
pcode=native/'pcode-0-0.bin';baseline=P/'fx3g-library-native-baseline/native-1/pcode-0-0.bin'
result=dict(source_sha256=sha256(source.read_bytes()),outcome=outcome,native_directory=str(native),same_pcode_as_historical=pcode.exists() and pcode.read_bytes()==baseline.read_bytes(),errors=[e for e in outcome['diagnostics'] if e['kind']==2])
(OUT/'comparison.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(dict(open=outcome['open_succeeded'],compile=outcome['compile_completed'],check=outcome['program_check_completed'],rejected=outcome['compiler_rejected'],saved=(native/'native-saved.gxw').exists(),same_pcode_as_historical=result['same_pcode_as_historical'],errors=result['errors']),ensure_ascii=True))
