"""Cross-check full predicted bytes against native public width checking."""
import base64
import collections
import json
from pathlib import Path
import source_q_width as q

P=Path(__file__).resolve().parent
def main():
    folder=P/'q-width-corpus-trace'
    requests=json.loads((folder/'requests.json').read_text())
    native=[json.loads(s) for s in (folder/'baseline-stdout.jsonl').read_text().splitlines()]
    fails=[];counts=collections.Counter()
    for row,actual in zip(requests,native,strict=True):
        raw=bytes.fromhex(row['raw']);expected=base64.b64decode(actual['output_base64'])
        try:
            result=q.rewrite(raw)
            if result!=expected:
                counts['different']+=1
                fails.append(dict(raw=raw.hex(),expected=expected.hex(),actual=result.hex(),id=actual['id']))
            else:counts['byte-identical']+=1
        except ValueError as e:
            counts['unsupported']+=1
            fails.append(dict(raw=raw.hex(),expected=expected.hex(),error=str(e),id=actual['id']))
    result=dict(counts=dict(counts),failures=fails)
    (P/'q-width-output-comparison.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(counts=counts,first=fails[:12])))

if __name__=='__main__':main()
