"""Discriminate temporary-specific bank choice from declaration fallback."""
from pathlib import Path
import json,struct,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from probe_gxw_parameters import project_allocation_ranges
from probe_retain_class10_holdouts import patch_pool_metadata
from probe_minimal_conditional_port_writes import streams,observe,save
from probe_gxw_program_check_resources import SCRIPT
from source_q_st_expressions import predict
P=Path(__file__).resolve().parent
OUT=P/'st-temporary-banks-20260930-v2'


def patch_observed_renamed_metadata(source,name,old,new,pools):
    """Pinned native rename alias with independent ID, size and digest checks."""
    from gxw.container_writer import validate_cfb_streams,replace_stream_within_allocation
    from gxw.project_metadata import logical_mapping,current_rows,md5_base64,synchronize_history
    outer=validate_cfb_streams(source);assert not outer.get('Project.gd2')
    nested=validate_cfb_streams(outer['_hdb']);mapping=logical_mapping(outer['projectdatalist.xml']);physical=mapping[name]
    assert nested[physical]==old and len(old)==len(new)==550
    ranges={r['name']:r for r in project_allocation_ranges(old)['ranges']}
    allowed={i for key in pools for i in range(ranges[key]['offset'],ranges[key]['offset']+8)}
    assert all(a==b or i in allowed for i,(a,b) in enumerate(zip(old,new)))
    matches=[{k:v.text.strip() for k,v in r.fields().items()} for r in current_rows(outer['history.xml'],'DSHISTORY','D_History')[0]
             if r.fields().get('iProjectdataID') and r.fields()['iProjectdataID'].text.strip()==physical]
    row,=matches;alias=row['szProjectdataName']
    assert (name,alias)==('NESTEDST.prj','BoxID_sample_project.prj') and alias not in mapping
    assert row['iFileSize']==str(len(old)) and row['szMD5val']==md5_base64(old)
    history,changes,preserved=synchronize_history(outer['history.xml'],{alias:(physical,old,new)})
    hdb=replace_stream_within_allocation(outer['_hdb'],physical,new)
    result=replace_stream_within_allocation(source,'_hdb',hdb)
    result=replace_stream_within_allocation(result,'history.xml',history)
    assert validate_cfb_streams(hdb)==dict(nested,**{physical:new})
    assert validate_cfb_streams(result)==dict(outer,_hdb=hdb,**{'history.xml':history})
    return result,dict(logical_name=name,preserved_history_alias=alias,physical_id=physical,
        verified_original_size=len(old),verified_original_md5=row['szMD5val'],metadata_changes=changes,preserved_metadata=preserved)


def main():
    OUT.mkdir(exist_ok=False);(OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    trace=OUT/'trace.js';trace.write_text('(()=>{'+(P/'native-allocation-bitmap-v2/observer.js').read_text()+'\n'+(P/'observe_expression_temporaries.js').read_text()+'\n})();\n(()=>{'+SCRIPT+'\n})();',encoding='utf-8')
    plans=[('chain-D13-W8','chain-eight',(7000,7012),(256,263)),
           ('balanced-D13-W8','balanced-eight',(7000,7012),(256,263)),
           ('balanced-D15-W8','balanced-eight',(7000,7014),(256,263)),
           ('balanced-W-only','balanced-eight',(0xffffffff,0xffffffff),(256,287))]
    ready=[]
    for case,kind,d_range,w_range in plans:
        d=OUT/case;d.mkdir();source=(P/'st-temp-predictions-20260930'/kind/'input.gxw').read_bytes();before=streams(source)
        name=next(n for n in before if n.endswith('.prj'));ranges={r['name']:r for r in project_allocation_ranges(before[name])['ranges']}
        raw=bytearray(before[name]);pools=dict(D=d_range,W=w_range)
        for key,pair in pools.items():struct.pack_into('<II',raw,ranges[key]['offset'],*pair)
        source,receipt=patch_observed_renamed_metadata(source,name,before[name],bytes(raw),pools)
        assert streams(source)==dict(before,**{name:bytes(raw)})
        path=d/'input.gxw';path.write_bytes(source)
        prediction=predict(source);code=prediction.pop('output');(d/'ordinary-fallback-predicted.bin').write_bytes(code)
        save(d/'before-native.json',dict(case=case,input_sha256=sha256(source),pools=pools,receipt=receipt,
            ordinary_fallback_prediction=prediction,
            competing_hypothesis='Temporary allocation uses selector 24/25/26/27 from default word family, rather than ordinary selector 4 cross-bank fallback.'))
        ready.append((case,d,path,code))
    results=[]
    for case,d,path,predicted in ready:
        native,checked,process=observe(path,d,trace);code=(native/'pcode-0-0.bin').read_bytes()
        messages=[json.loads(l) for l in (native/'events.jsonl').read_text().splitlines()]
        events=[m['payload'] for m in messages if m.get('type')=='send']
        errors=[m for m in messages if m.get('type')=='error' or 'error' in m.get('payload',{}).get('event','') or m.get('payload',{}).get('observation_error')]
        row=dict(case=case,native_directory=str(native),process=process,check=checked['check'],diagnostics=checked['diagnostics'],trace_errors=errors,
             bytes=len(code),ordinary_fallback_prediction_equal=code==predicted,
             pools=[e for e in events if e.get('event')=='pool-allocation'],temporary_events=[e for e in events if e.get('event','').startswith('temporary-')])
        results.append(row);save(OUT/'comparison.json',results)
        print(json.dumps(dict(case=case,check=row['check'],bytes=len(code),ordinary_fallback_prediction_equal=row['ordinary_fallback_prediction_equal'],
            diagnostics=sorted(set(hex(e['code']) for e in row['diagnostics'] if e['kind']==2)),errors=errors,
            temporary_allocations=[{k:e[k] for k in ('kind','count','selector','result','after')} for e in row['pools'] if e['allocation_id'] is None])),flush=True)
        if errors:raise RuntimeError('trace incomplete')


if __name__=='__main__':main()
