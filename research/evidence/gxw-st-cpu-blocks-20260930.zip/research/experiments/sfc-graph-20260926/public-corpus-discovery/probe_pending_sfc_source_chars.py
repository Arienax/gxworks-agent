"""Cross-check mode-one serialized SFC character grids against native APIs."""
from pathlib import Path
import json
import struct
import sys
ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'research')]
from gxw.lossless import inspect_project, sha256
from probe_gxw_sfc_sources import framing
from probe_gxw_sfc_graph import compiled_graph
from replay_gxw_workspace import run

P = Path(__file__).resolve().parent
OUT = P/'pending-sfc-source-chars-v3'


def source_chars(raw):
    f = framing(raw); start, size = f['graph']['offset'], f['graph']['size']
    if struct.unpack_from('<III', raw, start + 4) != (0, 1, 21516):
        raise ValueError('outside observed mode-one SFC source character extent')
    chars = raw[start + 16:start + 21528]
    if len(chars) != 21512:
        raise ValueError('truncated source characters')
    cache_start = start + 21528; cache_size = struct.unpack_from('<I', raw, cache_start)[0]
    if cache_start + cache_size + 8 != start + size or raw[cache_start + cache_size:start + size] != b'\0' * 8:
        raise ValueError('unrecognized opaque graph cache suffix')
    width, height, used_x, used_y = struct.unpack_from('<4H', chars)
    if not width or not height or width * height > 3072:
        raise ValueError('SFC grid exceeds fixed source allocation')
    cells = [dict(x=i % width, y=i // width, offset=8 + 3*i, raw=chars[8 + 3*i:11 + 3*i].hex())
             for i in range(width * height) if any(chars[8 + 3*i:11 + 3*i])]
    return chars, dict(source_offset=start + 16, bytes=len(chars), sha256=sha256(chars), width=width, height=height,
        uninterpreted_header_pair=[used_x, used_y], cells=cells, cache_offset=cache_start, cache_bytes=cache_size,
        cache_sha256=sha256(raw[cache_start:cache_start + cache_size]), cell_semantics='uninterpreted')


def main():
    OUT.mkdir(exist_ok=False); (OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    ready = []
    for name in ['q00j-empty.gxw', 'q00j-transition-converted.gxw', 'jump3-pending.gxw', 'three-steps-reopen.gxw']:
        path = P.parent/name; source = path.read_bytes()
        program, = [s for s in inspect_project(source).streams if (s.logical_name or '').endswith('.pou')]
        chars, evidence = source_chars(program.raw)
        directory = OUT/path.stem; directory.mkdir(); (directory/'source-chars.bin').write_bytes(chars)
        (directory/'source-before-native.json').write_text(json.dumps(dict(source=str(path), source_sha256=sha256(source),
            program=program.logical_name, source_program_sha256=sha256(program.raw), layout=evidence), indent=2), encoding='utf-8')
        ready.append((path, directory, program.logical_name, evidence))
    results = []
    for path, directory, logical, evidence in ready:
        for attempt in range(1, 5):
            native = directory/f'native-{attempt}'
            outcome = run(path, native, compile=True, change_sfc=True, snapshot_frontend=True, export_project=True,
                sfc_graph_chars=directory/'source-chars.bin', project_alias='SFCSRCGRID')
            events = [json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
            if not any(e.get('operation') == 'NativeTemporaryDirectoryCollision' for e in events):
                break
        row = dict(case=path.name, native_directory=str(native), outcome=outcome,
            sfc_events=[e for e in events if e.get('operation', '').startswith('SFC.')])
        if (native/'sfc-native-graph.json').exists():
            row['native_graph'] = json.loads((native/'sfc-native-graph.json').read_text(encoding='utf-8-sig'))
        if (native/'sfc-encoded-tokens.bin').exists():
            encoded = (native/'sfc-encoded-tokens.bin').read_bytes()
            row.update(encoded_hex=encoded.hex(), encoded_sha256=sha256(encoded))
            if (native/'native-saved.gxw').exists():
                streams = {s.logical_name: s.raw for s in inspect_project((native/'native-saved.gxw').read_bytes()).streams if s.logical_name}
                raw = streams[logical]; graph = compiled_graph(raw)
                whole = raw[graph['code_offset']:graph['code_offset'] + graph['code_size']]
                row.update(workspace_graph_identical=whole == encoded, workspace_graph_hex=whole.hex())
        (directory/'comparison.json').write_text(json.dumps(row, indent=2), encoding='utf-8')
        results.append(row); (OUT/'comparison.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
        print(json.dumps(dict(case=path.name, returncode=outcome['returncode'], compile_completed=outcome['compile_completed'],
            compiler_rejected=outcome['compiler_rejected'], workspace_graph_identical=row.get('workspace_graph_identical'),
            sfc_events=[e for e in row['sfc_events'] if e['operation'] in ['SFC.CheckResult', 'SFC.EncodeResult', 'SFC.EncodeSkipped']],
            last_event=outcome.get('last_event'))), flush=True)


if __name__ == '__main__':
    main()
