"""Resolve repeated SCPI pin aliases using preserved caller fragments."""
from pathlib import Path
import base64,collections,copy,json,re,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.compiler_debug import parse_compiler_debug
from probe_gxw_simple_fb import frame_source,observe_calls
from probe_gxw_compiled_references import stored_records
P=Path(__file__).resolve().parent
cases={'two':('scpi-two-callers/native','native-fb-callsite-connections/two'),
       'same':('scpi-instance-binding-controls/same-instance/native','native-fb-callsite-connections/same'),
       'compound':('native-fb-connection-type-controls/compound/native','native-fb-connection-type-controls/compound/source-connections-wide')}
for case,(nativepath,connectionpath) in cases.items():
 out=P/'scpi-exact-instance-operands-v2'/case
 baseline=json.loads((out/'comparison.json').read_text(encoding='utf-8'))
 source=(P/nativepath/'native-saved.gxw').read_bytes();assert sha256(source)==baseline['export_sha256']
 streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
 debug=parse_compiler_debug(streams['DebugInformation2.dat']);assert sha256(debug.raw)==baseline['debug_sha256']
 connections=json.loads((P/connectionpath/'connections.json').read_text(encoding='utf-8'))
 expansions=[]
 for original in baseline['expansions']:
  entry=copy.deepcopy(original);e=debug.elements[entry['element']];name=entry['parent']+'.Program.pou'
  parent_candidates=[(i,parent) for i,parent in enumerate(debug.elements)
                     if parent.names[2]==e.names[3] and parent.names[4]==b'' and parent.resource_bytes==e.resource_bytes
                     and parent.linked_step_end+1==e.linked_step_start]
  assert len(parent_candidates)==1
  parent_index,parent=parent_candidates[0];frame=frame_source(streams[name]);groups,_=stored_records(frame,encoding='cp932')
  marker_offsets=[g['offset'] for g in groups if g['stored_step']==parent.fields[0]];assert len(marker_offsets)==1
  calls=[c for c in observe_calls(frame)['calls'] if c['offset']==marker_offsets[0]
         and c['definition']=='SCPI' and c['instance']==entry['instance'] and not c['gaps']];assert len(calls)==1
  call=calls[0]
  matches=[c for p in connections['programs'] if p['name']==name for c in p.get('calls',[])
           if c['offset']==call['offset'] and c['sha256']==call['sha256']];assert len(matches)==1
  captured=matches[0];bindings=[]
  for direction in ('input','output'):
   fragment=captured['connection_fragments'][direction];span=call[direction+'_fragment']
   blob=streams[name][span['offset']:span['offset']+span['length']]
   assert fragment['sha256']==sha256(blob) and base64.b64decode(fragment['raw_base64'])==blob
   assert fragment['native_return_code']=='0x00000000' and not fragment['text_gaps']
   bindings.extend(fragment['bindings'])
  entry['callsite']=dict(program=name,offset=call['offset'],sha256=call['sha256'],
                        parent_debug_index=parent_index,parent_debug_raw_base64=base64.b64encode(parent.raw).decode(),
                        source_stored_step=parent.fields[0],connections=captured['connection_fragments'])
  summary=collections.Counter()
  for row in entry['rows']:
   overlay={};proof=[]
   for bound in row['bindings']:
    if bound.get('base',{}).get('handling')!='stored-embedded-operand':continue
    matching=[b for b in bindings if b['port'].lower()==bound['component'].lower()]
    if len(matching)!=1:continue
    b=matching[0]
    # Only directly observed native source devices; do not replace a stored
    # variable allocation by a literal or infer a compound enable expression.
    if not re.fullmatch(r'(?:X[0-9A-F]+|[MD][0-9]+)',b['operand']):continue
    overlay[bound['token']]=b['operand'];proof.append(dict(source_token=bound['token'],
      stored_allocation=bound['operand'],callsite_operand=b['operand'],connection=b))
   expected=copy.deepcopy(row['expected_records'])
   for source_record,target in zip(row['source_records'],expected):
    if source_record['kind']=='instruction':
     target['args']=[overlay.get(s,t) for s,t in zip(source_record['args'],target['args'])]
   row.update(callsite_expected_records=expected,callsite_aliases=proof,
              callsite_exact=not row['gaps'] and expected==row['compiled_records'])
   summary['source_groups']+=1;summary['exact']+=row['callsite_exact'];summary['alias_occurrences']+=len(proof)
   summary['corrected_groups']+=row['callsite_exact'] and row['handling']=='lowering-difference'
  entry['callsite_summary']=dict(summary);expansions.append(entry)
 result=dict(case=case,export_sha256=baseline['export_sha256'],expansions=expansions,
             scope='bounded direct pin alias reconstruction from per-call source fragments, independently checked against native code; no runtime indirect target resolution')
 # Swapping just one call's alias source must remain distinguishable from
 # its true independently decoded native region.
 if case=='same':
  negative=[]
  for ordinal,entry in enumerate(expansions):
   wrong=expansions[1-ordinal];count=0
   for row,other in zip(entry['rows'],wrong['rows']):
    assert row['source']['sha256']==other['source']['sha256']
    count+=row['compiled_records']!=other['callsite_expected_records']
   negative.append(dict(element=entry['element'],wrong_callsite_offset=wrong['callsite']['offset'],differing_groups=count))
  result['swapped_callsite_negative_controls']=negative
 (out/'callsite-comparison.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
 print(json.dumps(dict(case=case,expansions=[dict(instance=e['instance'],**e['callsite_summary']) for e in expansions],
                       negative_controls=result.get('swapped_callsite_negative_controls',[]))))
