"""Compare each source pin occurrence with each independently decoded expansion."""
import base64
from collections import Counter
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.compiler_debug import parse_compiler_debug
from gxw.token_pou import parse_token_fragment
from probe_gxw_simple_fb import frame_source
from native_gxw_tokens import native_batch,native_il_projection,Q_DLL
P=Path(__file__).resolve().parent
OUT=P/'fb-pin-compiled-lowering';OUT.mkdir(exist_ok=False)

def records(frame):
    result=[];step=0
    for t in frame.tokens:
        if len(t.raw)==2 or t.raw[1]<0x90:
            width=1 if len(t.raw)<=3 else int.from_bytes(t.raw[2:3],'little',signed=True)
            if width<0:raise ValueError('negative stored width')
            result.append(dict(offset=t.offset,step=step,width=width,raw=t.raw,labels=[]));step+=width
        else:
            if not result:raise ValueError('unbound operand')
            result[-1]['raw']+=t.raw
            if t.raw[1]==0xdf:result[-1]['labels'].append(t.raw[2:-1].decode('cp949'))
    return result,step

for case,relative in [('two','scpi-two-callers/native'),('same','scpi-instance-binding-controls/same-instance/native'),
                      ('compound','native-fb-connection-type-controls/compound/native')]:
    source=P/relative
    streams={s.logical_name:s.raw for s in inspect_project((source/'native-saved.gxw').read_bytes()).streams if s.logical_name}
    groups,total=records(frame_source(streams['SCPI.Program.pou']))
    binary=(source/'pcode-0-0.bin').read_bytes();compiled,compiled_steps=records(parse_token_fragment(binary,0,len(binary)))
    debug=parse_compiler_debug((source/'compiler_DZComp/DebugInformation2.dat').read_bytes())
    pins={'iEn','iUnitNo','iPrm','iResStr','oRecvCmdDone','oRecvCmdNum','oRecvData'}
    result=dict(case=case,source_sha256=sha256((source/'native-saved.gxw').read_bytes()),compiled_sha256=sha256(binary),
                source_stored_steps=total,compiled_stored_steps=compiled_steps,occurrences=[])
    requests=[]
    for index,e in enumerate(debug.elements):
        if e.names[2]!=b'SCPI':continue
        table=debug.offset_tables[e.offset_table_index]
        for group in groups:
            labels=sorted(pins.intersection(group['labels']))
            if not labels:continue
            mapped=[r for r in table.rows if r[0]+e.fields[0]==group['step']]
            selected=[g for r in mapped for g in compiled if e.linked_step_start+r[1]<=g['step']<=e.linked_step_start+r[2]]
            item=dict(element=index,instance=e.names[4].decode('cp949'),source_labels=labels,source_step=group['step'],
                source_offset=group['offset'],source_raw_hex=group['raw'].hex(),debug_rows=mapped,
                compiled_groups=[dict(offset=g['offset'],step=g['step'],width=g['width'],raw_hex=g['raw'].hex()) for g in selected])
            result['occurrences'].append(item)
            for blob,target in [(group['raw'],item)]+[(g['raw'],cg) for g,cg in zip(selected,item['compiled_groups'])]:
                target['decode_request']=len(requests)
                requests.append(dict(mode='decode',input_base64=base64.b64encode(blob+b'\0').decode()))
    directory=OUT/case;directory.mkdir()
    answers=native_batch(requests,directory/'native-decode',dll=Q_DLL,cpu_code=209)
    for item in result['occurrences']:
        for target in [item]+item['compiled_groups']:
            answer=answers[target['decode_request']];target['native_return_code']=answer['return_code']
            if answer['return_code']=='0x00000000':target['decoded']=native_il_projection(base64.b64decode(answer['output_base64']),encoding='cp949')
    (directory/'lowering.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(dict(case=case,occurrences=len(result['occurrences']),iEn=[dict(element=i,operands=dict(Counter(a for r in result['occurrences'] if r['element']==i and r['source_labels']==['iEn'] for cg in r['compiled_groups'] for instruction in cg.get('decoded',{}).get('records',[]) if instruction['kind']=='instruction' for a in instruction['args']))) for i in sorted({r['element'] for r in result['occurrences']})])),flush=True)
