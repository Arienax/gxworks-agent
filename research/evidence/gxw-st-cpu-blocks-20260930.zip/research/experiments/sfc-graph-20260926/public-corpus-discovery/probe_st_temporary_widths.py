"""Test capacity-compatible reuse across INT, DINT and REAL source expressions.

Predictions cover slot addresses/capacity before native execution, not PCode.
The REAL cases use variables only; no REAL parsing/rounding rule is inferred.
"""
from pathlib import Path
import base64,json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from gxw.declarations import parse_declarations,edit_declarations,serialize_declarations
from gxw.project_metadata import mark_observed_source_compile_pending,read_project_text_context
from probe_gxw_st_sources import replace_observed_st
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_program_check_resources import SCRIPT
from probe_minimal_conditional_port_writes import streams,observe,save
from source_q_direct_declarations import DirectDeclarations
from native_gxw_tokens import native_batch,Q_DLL,native_il_records
P=Path(__file__).resolve().parent
OUT=P/'st-temporary-widths-20260930'


def prediction(source,order):
    content={k:v for k,v in streams(source).items() if k!='CGTable.dat'}
    context=read_project_text_context(next(v for k,v in content.items() if k.endswith('.prj')))
    decl=DirectDeclarations(content,context['text_encoding']);decl.add_owner('POU_01')
    slots=[];requests=[]
    for kind in order:
        count=1 if kind=='int' else 2
        live=[]
        for _ in range(2):
            index=next((i for i,s in enumerate(slots) if s['state']==2 and s['count']>=count),None)
            if index is None:
                family,number,_=decl.allocate('D',count,fixed_pool='D')
                index=len(slots);slots.append(dict(family=family,number=number,count=count,state=2))
            slots[index]['state']=1;live.append(index)
            requests.append(dict(kind=kind,count=count,slot=index,number=slots[index]['number']))
        for index in live:slots[index]['state']=2
    return dict(declarations=decl.allocations,slots=slots,requests=requests)


def main():
    OUT.mkdir(exist_ok=False)
    for name in (Path(__file__).name,'source_q_direct_declarations.py','observe_expression_temporaries.js'):
        (OUT/name).write_bytes((P/name).read_bytes())
    trace=OUT/'trace.js';trace.write_text('(()=>{'+(P/'native-allocation-bitmap-v2/observer.js').read_text()+'\n'+(P/'observe_expression_temporaries.js').read_text()+'\n})();\n(()=>{'+SCRIPT+'\n})();',encoding='utf-8')
    original=(P/'st-temp-predictions-20260930/balanced-eight/input.gxw').read_bytes();before=streams(original)
    name='POU_01.Labels.lh';doc=parse_declarations(before[name],logical_name=name)
    additions=[dict(name=prefix+s,data_type=kind) for prefix,kind in [('wide','DINT'),('real','REAL')] for s in ('A','B','C','D','R')]
    labels=mark_observed_source_compile_pending(serialize_declarations(edit_declarations(doc,upserts=additions)),logical_name=name)
    plans=[('int','dint','int'),('dint','int','dint'),('real','dint','int'),('dint','real','int')]
    ready=[]
    for order in plans:
        case='-'.join(order);d=OUT/case;d.mkdir()
        lines=[]
        for kind in order:
            prefix={'int':'probe','dint':'wide','real':'real'}[kind]
            target=prefix+('R1' if kind=='int' else 'R')
            lines.append(f'{target} := ({prefix}A + {prefix}B) - ({prefix}C + {prefix}D);')
        text='\r\n'.join(lines)+'\r\n';name='POU_01.Program.pou'
        raw,_=replace_observed_st(before[name],text);raw=mark_observed_source_compile_pending(raw,logical_name=name)
        source,one=patch_raw(original,name,before[name],raw)
        source,two=patch_raw(source,'POU_01.Labels.lh',before['POU_01.Labels.lh'],labels)
        assert streams(source)==dict(before,**{name:raw,'POU_01.Labels.lh':labels})
        path=d/'input.gxw';path.write_bytes(source);predicted=prediction(source,order)
        save(d/'before-native.json',dict(case=case,input_sha256=sha256(source),source_text=text,receipts=[one,two],prediction=predicted,
            hypothesis='Native slot type is device family; reuse first unpinned state-2 slot whose stored capacity is at least requested count, including DINT/REAL -> INT.'))
        ready.append((case,d,path,predicted))
    rows=[];requests=[];keys=[]
    for case,d,path,predicted in ready:
        native,checked,process=observe(path,d,trace);code=(native/'pcode-0-0.bin').read_bytes()
        messages=[json.loads(l) for l in (native/'events.jsonl').read_text().splitlines()]
        events=[m['payload'] for m in messages if m.get('type')=='send']
        errors=[m for m in messages if m.get('type')=='error' or 'error' in m.get('payload',{}).get('event','') or m.get('payload',{}).get('observation_error')]
        temp=[e for e in events if e.get('event','').startswith('temporary-')]
        actual=[dict(count=e['args'][3],number=e['result']) for e in temp if e.get('name')=='request']
        expected=[dict(count=e['count'],number=e['number']) for e in predicted['requests']]
        row=dict(case=case,native_directory=str(native),process=process,check=checked['check'],diagnostics=checked['diagnostics'],trace_errors=errors,
            bytes=len(code),sha256=sha256(code),prediction_matches=actual==expected,predicted=predicted,actual_requests=actual,temporary_events=temp,
            pools=[e for e in events if e.get('event')=='pool-allocation'])
        if checked['exported_sha256']:
            rd=d/'reopen';rd.mkdir();rn,rc,rp=observe(native/'native-saved.gxw',rd,trace)
            row['reopen']=dict(native_directory=str(rn),check=rc['check'],diagnostics=rc['diagnostics'],identical=code==(rn/'pcode-0-0.bin').read_bytes())
        rows.append(row);save(OUT/'comparison.json',rows)
        print(json.dumps(dict(case=case,check=row['check'],prediction_matches=row['prediction_matches'],requests=actual,
            diagnostics=sorted(set(hex(e['code']) for e in row['diagnostics'] if e['kind']==2)),errors=errors,
            creations=[{k:e[k] for k in ('type','count','output')} for e in temp if e['event']=='temporary-create'],reopen=row.get('reopen',{}).get('identical'))),flush=True)
        if errors:raise RuntimeError('trace incomplete')
        if code:requests.append(dict(mode='decode',case=case,input_base64=base64.b64encode(code+b'\0').decode()));keys.append(case)
    if requests:
        decoded=native_batch(requests,OUT/'native-decode',dll=Q_DLL,cpu_code=209,native_versions=(25,))
        save(OUT/'native-listings.json',[dict(case=k,return_code=r['return_code'],records=native_il_records(base64.b64decode(r['output_base64']),encoding='cp932')) for k,r in zip(keys,decoded)])


if __name__=='__main__':main()
