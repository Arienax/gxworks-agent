// Observations only. Addresses pinned to ECCompiler_IEC f58e7c70... .
'use strict';
let serial=0, active=null, block=null;
function hex(p,n) { try { return Array.from(new Uint8Array(p.readByteArray(n)),x=>x.toString(16).padStart(2,'0')).join(''); } catch(_) {return null;} }
function cstr(p) { try {let a=[];for(let i=0;i<128;i++){let b=p.add(i).readU8();if(!b)break;a.push(b);}return String.fromCharCode(...a);}catch(_){return null;} }
function token(p){try{const n=p.readU8();return {address:p.toString(),bytes:hex(p,n),following:hex(p,96)};}catch(_){return null;}}
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='eccompiler_iec.dll')return;
 const loc=p=>({rva:p.sub(m.base).toString(),module:m.name});
 const hooks=new Set();
 function observeVirtual(table,slot){
  const target=table.add(slot).readPointer(),key=target.toString();
  if(hooks.has(key))return;hooks.add(key);
  send({event:'virtual_target',slot,target:loc(target),bytes:hex(target,32)});
  Interceptor.attach(target,{onEnter(args){
   if(!active)return;this.id=active.id;
   this.saved=[args[0],args[1],args[2]];
   send({event:'virtual_enter',id:this.id,slot,target:loc(target),self:this.context.ecx.toString(),
    args:this.saved.map(p=>({value:p.toString(),bytes:hex(p,40),cstring:cstr(p)}))});
  },onLeave(result){if(!this.id)return;send({event:'virtual_leave',id:this.id,slot,result:result.toString(),args:this.saved.map(p=>({value:p.toString(),bytes:hex(p,40)}))});}});
 }
 Interceptor.attach(m.base.add(0xea290),{onEnter(args){
  this.old=block;block=++serial;send({event:'block_enter',block,token:token(args[0])});
 },onLeave(result){send({event:'block_leave',block,result:result.toString()});block=this.old;}});
 Interceptor.attach(m.base.add(0xe9620),{onEnter(args){
  this.old=active;active={id:++serial,block};this.id=active.id;
  const self=this.context.ecx,backend=self.add(4).readPointer(),table=backend.readPointer();
  for(const slot of [0x144,0x148,0x14c])observeVirtual(table,slot);
  send({event:'value_enter',id:this.id,block,self:self.toString(),token:token(args[0]),previous:token(self.add(0x38).readPointer())});
 },onLeave(result){send({event:'value_leave',id:this.id,result:result.toString()});active=this.old;}});
 for(const [rva,name] of [[0xe9750,'lookup_return'],[0xe97cb,'input_classify'],[0xe97db,'device_binding_branch'],[0xe981a,'binding_return']]){
  Interceptor.attach(m.base.add(rva),{onEnter(){
   if(!active)return;const sp=this.context.esp;
   send({event:name,...active,eax:this.context.eax.toString(),kind:sp.add(0x18).readS32(),
    formal:cstr(sp.add(0x10).readPointer()),resolved:cstr(sp.add(0x14).readPointer()),operand:hex(sp.add(0x38),40),
    operand_length:sp.add(0x1c).readS32()});
  }});
 }
}});
