"""Preserve a real failed project and test two isolated declaration repairs."""
from pathlib import Path
import json
import sys
ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'research')]
from gxw.lossless import inspect_project, sha256
from gxw.declarations import parse_declarations, serialize_declarations, edit_declarations
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import run
from source_q_direct_projection import project_projection
from compare_q_direct_projection import compare_native
from probe_gxw_simple_fb import frame_source, observe_calls

P = Path(__file__).resolve().parent
OUT = P/'q-real-missing-declarations'


def payloads(raw):
    return {s.logical_name: s.raw for s in inspect_project(raw).streams if s.logical_name}


def main():
    OUT.mkdir(exist_ok=False)
    for name in ['probe_q_real_missing_declarations.py', 'compare_q_direct_projection.py', 'source_q_direct_projection.py', 'source_q_direct_declarations.py', 'source_q_call_connections.py', 'source_q_label_binding.py', 'source_q_allocation.py', 'source_q_width.py', 'q-width-static-tables.json']:
        (OUT/name).write_bytes((P/name).read_bytes())
    baseline = P/'noeul-native-batch/case-10'; source = (baseline/'input.gxw').read_bytes(); before = payloads(source)
    logical = next(n for n in before if n.endswith('.Labels.lh') and any(not r.data_type for r in parse_declarations(before[n], logical_name=n).rows))
    doc = parse_declarations(before[logical], logical_name=logical)
    missing = [r for r in doc.rows if not r.data_type]; assert len(missing) == 2
    frame = frame_source(before[doc.owner_name+'.Program.pou'])
    observed = observe_calls(frame); assert not observed['calls'] and not observed['gaps']
    labels = {t.raw[2:-1] for t in frame.tokens if t.raw[1] == 0xdf}
    assert not any(r.name.encode('cp949') in labels for r in missing)
    evidence = dict(source=str(baseline/'input.gxw'), source_sha256=sha256(source),
        missing=[dict(name=r.name, type_code=r.type_code, record_id=r.record_id) for r in missing],
        exact_source_label_references=0, original_outcome=json.loads((baseline/'outcome.json').read_text()),
        scope='Controlled repair alternatives; INT is an experiment, not a recovery of intended semantics.')
    (OUT/'original-failure.json').write_text(json.dumps(evidence, indent=2), encoding='utf-8')
    plans = [('remove-unused-empty-types', edit_declarations(doc, remove=[r.name for r in missing])),
             ('assign-int-to-empty-types', edit_declarations(doc, upserts=[dict(name=r.name, data_type='INT', initial_value='0') for r in missing]))]
    ready = []; results = []
    for case, document in plans:
        directory = OUT/case; directory.mkdir()
        changed_labels = serialize_declarations(document)
        changed, receipt = patch_raw(source, logical, before[logical], changed_labels)
        assert payloads(changed) == dict(before, **{logical: changed_labels})
        path = directory/'input.gxw'; path.write_bytes(changed)
        predictions = project_projection(changed)
        for row in predictions:
            (directory/f'predicted-{row["resource_index"]}.bin').write_bytes(row.pop('output'))
        (directory/'prediction-before-native.json').write_text(json.dumps(dict(receipt=receipt, predictions=predictions,
            compiler_cache='byte-identical; not read during prediction'), indent=2), encoding='utf-8')
        ready.append((case, directory, path, predictions))
    for case, directory, path, predictions in ready:
        for attempt in range(1, 5):
            native = directory/f'native-{attempt}'
            outcome = run(path, native, compile=True, export_project=True, project_alias='QMISSINGDECL')
            events = [json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
            if not any(e.get('operation') == 'NativeTemporaryDirectoryCollision' for e in events):
                break
        accepted = outcome['returncode'] == 0 and outcome['compile_completed'] and not outcome['compiler_rejected'] and (native/'native-saved.gxw').exists()
        row = dict(case=case, native_directory=str(native), native_accepted=accepted, outcome=outcome,
            programs=compare_native(predictions, directory, native) if accepted else [])
        (directory/'comparison.json').write_text(json.dumps(row, indent=2), encoding='utf-8')
        results.append(row); (OUT/'comparison.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
        print(json.dumps(dict(case=case, native_accepted=accepted, programs=row['programs'], diagnostics=outcome['diagnostics'])), flush=True)


if __name__ == '__main__':
    main()
