"""Competing scopes for native ST call expansion across task-selected POUs.

Uses source content and project ranges only. The phase/scope selectors describe
alternative hypotheses, not multiple supported production allocation modes.
"""
from gxw.project_metadata import read_project_text_context
from probe_gxw_task_graph import inspect_task_graph
from probe_minimal_conditional_port_writes import streams
from source_q_direct_declarations import DirectDeclarations
from source_q_st_calls import predict


def predict_programs(source,*,declaration_stage='program',temporary_scope='program',pointer_scope='project'):
    content={k:v for k,v in streams(source).items() if k!='CGTable.dat'}
    context=read_project_text_context(next(v for k,v in content.items() if k.endswith('.prj')))
    graph=inspect_task_graph(source)
    if graph['gaps']:raise ValueError('task graph has gaps')
    resources=sorted(graph['resources'],key=lambda r:r['resource'].encode(context['text_encoding']))
    programs=[[e['program_reference'] for e in sorted(graph['tasks'][r['task']]['entries'],key=lambda e:e['stored_order'])] for r in resources]
    flat=[name for names in programs for name in names]
    if len(set(flat))!=len(flat):raise ValueError('repeated POU task binding outside experiment')
    decl=DirectDeclarations(content,context['text_encoding'],local_fb_definitions=('SCPI',),allow_string_arrays=True)
    slots=[];pointer=decl.ranges['P']['lower'];rows=[];outputs=[]
    if declaration_stage=='project':
        for owner in flat:decl.add_owner(owner)
    for resource,names in zip(resources,programs,strict=True):
        if declaration_stage=='resource':
            for owner in names:decl.add_owner(owner)
        if temporary_scope=='resource':slots=[]
        if pointer_scope=='resource':pointer=decl.ranges['P']['lower']
        parts=[]
        for owner in names:
            if temporary_scope=='program':slots=[]
            if pointer_scope=='program':pointer=decl.ranges['P']['lower']
            model=predict(source,('SCPI',),allow_inputs=True,allow_omitted=True,allow_members=True,owner=owner,
                allocation_context=decl,temporary_context=slots,pointer_start=pointer,allocate_owner=declaration_stage=='program')
            pointer=model['next_pointer'];ending=bytes.fromhex('033303020204340204')
            assert model['output'].endswith(ending)
            parts.append(model['output'][:-len(ending)])
            rows.append(dict(owner=owner,resource=resource['resource'],**{k:v for k,v in model.items() if k!='output'}))
        outputs.append(dict(resource=resource['resource'],output=b''.join(parts)+ending))
    return outputs,dict(declaration_stage=declaration_stage,temporary_scope=temporary_scope,pointer_scope=pointer_scope,programs=rows)
