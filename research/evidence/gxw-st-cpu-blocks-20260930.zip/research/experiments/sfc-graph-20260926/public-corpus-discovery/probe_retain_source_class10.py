"""Test the statically decoded source class 10 (VAR_RETAIN)."""
from dataclasses import replace
from pathlib import Path
import json,struct,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.declarations import parse_declarations,serialize_declarations
from probe_gxw_parameters import project_allocation_ranges
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import prepare,trace_prepared
from probe_gxw_program_check_resources import SCRIPT,inspect_run
P=Path(__file__).resolve().parent
OUT=P/'retain-source-class10-20260930'

def main():
    OUT.mkdir(exist_ok=False);(OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    original=(P/'noeul-native-batch/case-08/input.gxw').read_bytes()
    streams={s.logical_name:s.raw for s in inspect_project(original).streams if s.logical_name}
    metadata_name=next(n for n in streams if n.endswith('.prj'));old=streams[metadata_name]
    label_name=next(n for n,b in streams.items() if n.endswith('.Labels.lh') and any(r.name=='EMSTP' for r in parse_declarations(b,logical_name=n).rows))
    doc=parse_declarations(streams[label_name],logical_name=label_name)
    ranges={r['name']:r for r in project_allocation_ranges(old)['ranges']};unset=(0xffffffff,0xffffffff)
    specs=[('local10-no-pool',10,{}),
           ('local10-D1',10,dict(latch_D1=(6000,6007))),
           ('local10-D2',10,dict(latch_D2=(6100,6107))),
           ('local10-both',10,dict(latch_D1=(6000,6007),latch_D2=(6100,6107))),
           ('local10-W1',10,dict(latch_W1=(512,519))),
           ('local10-W2',10,dict(latch_W2=(768,775)))]
    script=OUT/'trace.js';script.write_text('(()=>{'+(P/'native-allocation-bitmap-v2/observer.js').read_text(encoding='utf-8')+'\n})();\n(()=>{'+SCRIPT+'\n})();',encoding='utf-8')
    results=[]
    for case,category,changes in specs:
        directory=OUT/case;directory.mkdir();new=bytearray(old)
        for bank,pair in changes.items():struct.pack_into('<II',new,ranges[bank]['offset'],*pair)
        source,receipt=patch_raw(original,metadata_name,old,bytes(new));receipts=[receipt]
        if category is not None:
            labels=serialize_declarations(replace(doc,rows=tuple(replace(r,class_code=category) if r.name=='STATE' else r for r in doc.rows)))
            source,receipt=patch_raw(source,label_name,streams[label_name],labels);receipts.append(receipt)
        path=directory/'input.gxw';path.write_bytes(source)
        (directory/'prediction-before-native.json').write_text(json.dumps(dict(input_sha256=sha256(source),receipts=receipts,
            source_class=category,changes=changes,hypothesis='SICConverter 0x95195 names source class 10 VAR_RETAIN. Expect native retain category and descriptor 28..30; no-pool should reject rather than use ordinary D.'),indent=2),encoding='utf-8')
        for attempt in range(1,5):
            native=directory/f'native-{attempt}';prepare(path,native,compile=True,program_check=True,export_project=True,snapshot_frontend=True,project_alias='RETAINPOOL')
            trace=trace_prepared(native,script)
            events=[json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
            if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
        observed=inspect_run(native);messages=[json.loads(l) for l in (native/'events.jsonl').read_text(encoding='utf-8').splitlines()]
        emitted=[r['payload'] for r in messages if r.get('type')=='send'];typed=[r for r in emitted if r.get('event')=='typed-allocation'];pools=[r for r in emitted if r.get('event')=='pool-allocation']
        errors=[r for r in messages if r.get('type')=='error' or 'error' in r.get('payload',{}).get('event','') or 'observation_error' in r.get('payload',{})]
        row=dict(case=case,native_directory=str(native),trace=trace,check=observed['check'],diagnostics=observed['diagnostics'],generated=observed['generated'],trace_errors=errors,typed=typed,pools=pools)
        results.append(row);(OUT/'comparison.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
        print(json.dumps(dict(case=case,check=row['check'],trace_errors=errors,allocations=[dict(type=r['type'],category=r['category'],raw=r.get('after'),result=r['result']) for r in typed],
            descriptors=[{k:v for k,v in d.items() if k!='bitmap'} for d in pools[0]['descriptors'] if 24<=d['index']<=30] if pools else [],
            errors=[{k:v for k,v in r.items() if k!='raw_base64'} for r in row['diagnostics'] if r['kind']==2]),ensure_ascii=True),flush=True)

if __name__=='__main__':main()
