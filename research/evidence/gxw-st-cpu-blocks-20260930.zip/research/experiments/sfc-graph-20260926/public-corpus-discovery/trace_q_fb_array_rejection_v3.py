"""Locate rejected native array type using resolved imports in an owned helper."""
from pathlib import Path
import hashlib,json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path.insert(0,str(ROOT/'research'))
from replay_gxw_workspace import prepare,trace_prepared
P=Path(__file__).resolve().parent
out=P/'q-fb-array-type-trace-v3';out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
assert hashlib.sha256(Path('D:/GXWORKS2/DNaviZero/DataAbsorber/DZDataABS_SICConverter_IEC.dll').read_bytes()).hexdigest()=='670fd037852287e4c99de6aa58d19ea0ba9505f10bb46969d2e17d1e54b863f6'
for case in ['local-empty-initial','global-empty-initial']:
    target=out/case
    prepare(P/'q-fb-array-storage'/case/'input.gxw',target,compile=True,snapshot_frontend=True,export_project=True,project_alias='QFBARRAYTRACE')
    result=trace_prepared(target,P/'TraceFbArrayTypeV3.js')
    events=[json.loads(s) for s in (target/'events.jsonl').read_text(encoding='utf-8').splitlines()]
    selected=[e.get('payload',e) for e in events if e.get('type')=='error' or e.get('payload',{}).get('event')!='module']
    (target/'selected-events.json').write_text(json.dumps(selected,indent=2))
    print(json.dumps(dict(case=case,process=result,events=selected)),flush=True)
