"""Compare source-only lifetime hypotheses on a native-copied two-resource seed."""
from pathlib import Path
import base64,itertools,json,struct,sys
ROOT=Path(__file__).resolve().parents[4];sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from gxw.project_metadata import mark_observed_source_compile_pending
from probe_gxw_st_sources import replace_observed_st
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_parameters import project_allocation_ranges
from probe_minimal_conditional_port_writes import streams,save,observe
from model_q_st_call_programs import predict_programs
from native_gxw_tokens import native_batch,native_il_records,Q_DLL
from verify_temporary_check_correspondence import verify
P=Path(__file__).resolve().parent


def main():
    config=json.loads(Path(sys.argv[1]).read_text());out=P/config['directory'];out.mkdir(exist_ok=False)
    save(out/'experiment-plan.json',config)
    for name in (Path(__file__).name,'model_q_st_call_programs.py','source_q_st_calls.py','source_q_direct_declarations.py','source_q_st_expressions.py'):
        (out/name).write_bytes((P/name).read_bytes())
    original=(P/'cross-origin-multi-pou-seed-v3-20260930/native-copy/native-saved.gxw').read_bytes();before=streams(original)
    trace=out/'trace.js';trace.write_bytes((P/'cross-origin-st-calls-v3-20260930/trace.js').read_bytes());ready=[]
    for plan in config['cases']:
        d=out/plan['case'];d.mkdir();changes={};texts={}
        for i,owner in enumerate(('MAIN','ProbeNext')):
            k=plan.get('constant',11)+20*i
            text=f'probeArray[0] := {k}; probeArray[1] := {k+11}; probeIndex := 0; First(value := probeArray[probeIndex], idx := probeIndex, result := probeR0); probeR1 := (probeIndex + 2) + (probeIndex + 3); ProbeB(value := probeArray[probeIndex], idx := probeIndex, result := probeR2);'
            name=owner+'.Program.pou';changes[name],_=replace_observed_st(before[name],text);texts[owner]=text
        text='saved := value; '+('IF idx > 0 THEN saved := saved + 1; END_IF; ' if plan['branches'] else '')+'idx := idx + 1; result := saved;'
        changes['SCPI.Program.pou'],_=replace_observed_st(before['SCPI.Program.pou'],text);texts['SCPI']=text
        if 'pointer_range' in plan:
            name=next(k for k in before if k.endswith('.prj'));raw=bytearray(before[name])
            pool=next(r for r in project_allocation_ranges(raw)['ranges'] if r['name']=='P');struct.pack_into('<II',raw,pool['offset'],*plan['pointer_range']);changes[name]=bytes(raw)
        source=original;receipts=[]
        for name,raw in list(changes.items()):
            if not name.endswith('.prj'):raw=mark_observed_source_compile_pending(raw,logical_name=name)
            changes[name]=raw;source,receipt=patch_raw(source,name,before[name],raw);receipts.append(receipt)
        assert streams(source)==dict(before,**changes)
        path=d/'input.gxw';path.write_bytes(source);hypotheses=[]
        for stage,temps,pointers in itertools.product(('program','project'),repeat=3):
            key='-'.join((stage,temps,pointers))
            try:
                outputs,model=predict_programs(source,declaration_stage=stage,temporary_scope=temps,pointer_scope=pointers)
                h=dict(key=key,model=model,outputs=[])
                for i,r in enumerate(outputs):
                    (d/f'predicted-{key}-{i}.bin').write_bytes(r['output']);h['outputs'].append(dict(resource=r['resource'],sha256=sha256(r['output']),bytes=len(r['output'])))
            except ValueError as exc:h=dict(key=key,unsupported=str(exc))
            hypotheses.append(h)
        save(d/'before-native.json',dict(input_sha256=sha256(source),original_sha256=sha256(original),hypotheses=hypotheses,
            source_texts=texts,receipts=receipts,changed_streams=list(changes),unchanged_streams={k:sha256(v) for k,v in before.items() if k not in changes},
            hypothesis='Declarations interleave with code per program; slots reset per program while reservations persist; P pointer scope is not yet established across resources.'))
        ready.append((plan,d,path,hypotheses))
    rows=[];requests=[];keys=[]
    for plan,d,path,hypotheses in ready:
        native,result,proc=observe(path,d,trace);matches={h['key']:[] if 'outputs' in h else None for h in hypotheses}
        for g in result['generated']:
            code=(native/f'pcode-{g["index"]}-0.bin').read_bytes()
            for h in hypotheses:
                if 'outputs' in h:matches[h['key']].append(code==(d/f'predicted-{h["key"]}-{g["index"]}.bin').read_bytes())
            if code:requests.append(dict(mode='decode',input_base64=base64.b64encode(code+b'\0').decode()));keys.append((plan['case'],g['name'],g['index']))
        row=dict(case=plan['case'],native_directory=str(native),check=result['check'],diagnostics=result['diagnostics'],backend_rejected=result['backend_check_rejected'],process=proc,matches=matches)
        if result['exported_sha256']:
            rd=d/'reopen';rd.mkdir();rn,rr,rp=observe(native/'native-saved.gxw',rd,trace)
            row['reopen']=dict(native_directory=str(rn),check=rr['check'],diagnostics=rr['diagnostics'],identical=all((native/f'pcode-{g["index"]}-0.bin').read_bytes()==(rn/f'pcode-{g["index"]}-0.bin').read_bytes() for g in result['generated']))
        rows.append(row);save(out/'comparison.json',rows)
        print(json.dumps(dict(case=row['case'],check=row['check'],matches=matches,diagnostics=sorted(set(hex(e['code']) for e in row['diagnostics'] if e['kind']==2)),reopen=row.get('reopen',{}).get('identical'))),flush=True)
    answers=native_batch(requests,out/'native-decode',dll=Q_DLL,cpu_code=209,native_versions=(25,));listings=[]
    for key,req,a in zip(keys,requests,answers,strict=True):
        assert a['return_code']=='0x00000000' and a['consumed_bytes']==len(base64.b64decode(req['input_base64']))-1
        listings.append(dict(case=key[0],resource=key[1],index=key[2],records=native_il_records(base64.b64decode(a['output_base64']),encoding='cp932')))
    save(out/'native-listings.json',listings);save(out/'current-check-export-correspondence.json',verify([out.name]))


if __name__=='__main__':main()
