"""Check the native GUI save/hash/export sequence on the public Korean corpus."""
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'research')]
from replay_gxw_workspace import run

P = Path(__file__).resolve().parent
OUT = P / 'noeul-save-reopen-native-hash'
OUT.mkdir(exist_ok=False)
for case in sorted((P / 'noeul-native-batch').glob('case-*'), key=lambda x: int(x.name.split('-')[1])):
    directory = OUT / case.name
    directory.mkdir()
    source = case / 'input.gxw'
    row = dict(case=case.name, input_sha256=hashlib.sha256(source.read_bytes()).hexdigest())
    try:
        first = run(source, directory / 'save', compile=True, export_project=True,
                    project_alias='CORPUS' + case.name.split('-')[1])
        row['save'] = {k: first[k] for k in ['returncode', 'compile_completed', 'compiler_rejected', 'diagnostics']}
        if first['returncode'] == 0 and first['compile_completed'] and not first['compiler_rejected']:
            second = run(directory / 'save/native-saved.gxw', directory / 'reopen',
                         compile=True, export_project=True)
            row['reopen'] = {k: second[k] for k in ['returncode', 'compile_completed', 'compiler_rejected', 'diagnostics']}
            row['compiled_outputs_identical'] = first['outputs'] == second['outputs']
        else:
            row['reopen'] = None
    except Exception as exc:
        row['error'] = str(exc)
    with (OUT / 'results.jsonl').open('a', encoding='utf-8') as output:
        output.write(json.dumps(row, ensure_ascii=True) + '\n')
    print(json.dumps({k: v for k, v in row.items() if k not in ['save', 'reopen']}, ensure_ascii=True), flush=True)
