"""Bind the causal runtime controls to raw compile inputs and native outputs."""
from pathlib import Path
import hashlib,json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research/experiments/re-tools')]
import pefile,capstone
from gxw.lossless import sha256
P=Path(__file__).resolve().parent
out=P/'native-crt-root-cause';out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
trace=P/'structured-negation-reload-trace-v5'
rows=[]
for case in ['cached','fresh']:
    target=trace/case
    events=[json.loads(s).get('payload',{}) for s in (target/'events.jsonl').read_text().splitlines()]
    parsed=next(e for e in events if e.get('name')=='Memory.ParseData' and e.get('event')=='frontend_enter')
    body=next(b for a in parsed['build']['arrays'] if a['label']=='pou' for r in a['records'] if r['name']=='1'
              for b in r['payloads'] if b['pointer_offset']==24)
    sic=next(bytes.fromhex(b['bytes']) for e in events if e.get('name')=='Compile' and e.get('event')=='enter'
             for b in e['buffers'] if b['label']=='source_0' and b['bytes'] and b['bytes'].startswith('4e30204c44'))
    (out/(case+'-frontend-body.bin')).write_bytes(bytes.fromhex(body['bytes']))
    (out/(case+'-compiler-input.sic')).write_bytes(sic)
    row=dict(case=case,input_sha256=sha256((target/'input.gxw').read_bytes()),options=parsed['options'],
        frontend_body_sha256=sha256(bytes.fromhex(body['bytes'])),frontend_body_bytes=body['size'],
        compiler_input_sha256=sha256(sic),compiler_input_text=sic.decode('ascii'),
        negation=[e for e in events if e.get('event')=='negation-conversion' and e.get('input')=='%IX2'],
        character_operations=[e for e in events if e.get('event')=='negation-ctype' and e.get('input') in (78,110,0)],
        pcode_sha256=sha256((target/'pcode-0-0.bin').read_bytes()))
    rows.append(row)
assert rows[0]['input_sha256']==rows[1]['input_sha256']
assert rows[0]['frontend_body_sha256']==rows[1]['frontend_body_sha256']
assert rows[0]['options']==rows[1]['options']
assert rows[0]['compiler_input_text'].replace('%IX2','NOT(%IX2)')==rows[1]['compiler_input_text']
assert rows[0]['pcode_sha256']=='f9da33d72e20a6a947a2a9e342ab8818821787eef4b4ff7ce17c5d4e6811e1df'
assert rows[1]['pcode_sha256']=='9ed6174f8ffe7544980b2468f929a1a4eaddc55158136c43ccda7b33510bbe31'
control=json.loads((P/'native-crt-codepage-control/comparison.json').read_text())['cases']
assert control[0]['outputs']['pcode-0-0.bin']==control[2]['outputs']['pcode-0-0.bin']==rows[0]['pcode_sha256']
assert control[1]['outputs']['pcode-0-0.bin']==rows[1]['pcode_sha256']
guards=json.loads((P/'native-crt-guard-check/comparison.json').read_text())['cases']
assert guards[0]['returncode']==4 and not guards[0]['outputs'] and not guards[0]['compile_completed']
assert guards[1]['outputs']['pcode-0-0.bin']['sha256']==rows[1]['pcode_sha256']
static=[]
for path,rva,size in [(Path('D:/GXWORKS2/DNaviZero/DataAbsorber/DZDataABS_SICConverter_IEC.dll'),0x3ef05,0xab),
                      (Path('C:/Windows/SysWOW64/msvcr71.dll'),0x2031e,0x85)]:
    raw=path.read_bytes();pe=pefile.PE(data=raw);md=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32)
    instructions=[dict(rva=hex(i.address-pe.OPTIONAL_HEADER.ImageBase),bytes=i.bytes.hex(),mnemonic=i.mnemonic,operands=i.op_str)
                  for i in md.disasm(pe.get_data(rva,size),pe.OPTIONAL_HEADER.ImageBase+rva)]
    static.append(dict(path=str(path),sha256=sha256(raw),rva=hex(rva),instructions=instructions))
references=['compile-pending-stale-cache/comparison.json','compile-pending-stale-cache/native-decoded.json',
    'structured-cache-reload/comparison.json','structured-cache-reload/native-decoded.json',
    'native-crt-codepage-control/comparison.json','native-crt-codepage-control/decoded.json',
    'native-crt-runtime-control/comparison.json','native-crt-runtime-control/decoded.json',
    'native-crt-guard-check/comparison.json','native-crt-guard-check/q-fresh/outcome.json',
    'structured-negation-reload-trace-v5/cached/events.jsonl','structured-negation-reload-trace-v5/fresh/events.jsonl',
    'compile-pending-header-corpus/comparison.json']
result=dict(finding='In the inspected offline helper, CRT code-page state can remove graph negation before ECCompiler receives its source.',
    correction='R.gxw is not evidence that stale PCode caused the lost ANI. A correctly compiled/saved project reproduces it; changing only CRT code page repairs or reproduces the result.',
    input_and_conversion=rows,causal_controls=control,static=static,
    evidence=[dict(path=p,sha256=sha256((P/p).read_bytes())) for p in references],
    implementation=dict(helper='research/native/WorkspaceReplayOracle.cs',
        helper_sha256=sha256((ROOT/'research/native/WorkspaceReplayOracle.cs').read_bytes()),
        behavior='Check active CRT ASCII upper/lower classification before and after IEC Build, record module/hash/codepage, and reject invalid results before exposing PCode/export. No locale mutation.'),
    limitations=['Installed GX Works2 DLLs and the two inspected MSVCR71 builds only; no universal CP54936/compiler claim.',
        'The checks observe the helper thread before/after Build, not every worker or intermediate runtime state.',
        'Successful CRT checks do not prove compile semantics, source/cache freshness, or runtime PLC behavior.',
        'Pending header markers report pending status; they do not establish cache invalidation.',
        'Cached controls deliberately preserved backend state in owned offline processes; no original project or system runtime file was modified.'],
    failed_observations=[dict(path='structured-cache-reload-trace',reason='Broad Workspace instrumentation timed out in both cases; no accepted compile output.'),
        dict(path='structured-negation-reload-trace',reason='Mistyped entry guard skipped negation observation.'),
        dict(path='structured-negation-reload-trace-v3',reason='CRT offsets belonged to the bundled runtime, not the loaded system runtime; CRT-specific guard skipped hooks.'),
        dict(path='structured-negation-reload-trace-v4',reason='Guard corrected from bundled DLL but loaded system DLL still differed; no CRT-specific observation accepted.')])
(out/'comparison.json').write_text(json.dumps(result,indent=2))
print(json.dumps(dict(source_bytes_identical=True,frontend_payload_identical=True,compiler_options_identical=True,
    causal_codepage_controls=len(control),invalid_runtime_rejected=True,valid_fx_and_q_outputs_preserved=True)),flush=True)
