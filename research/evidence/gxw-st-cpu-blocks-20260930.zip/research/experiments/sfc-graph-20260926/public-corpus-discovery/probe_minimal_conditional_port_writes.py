"""Isolate writable input aliases and conditional outputs under fresh checks."""
from pathlib import Path
import base64
import json
import struct
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'research')]
from gxw.lossless import inspect_project, sha256
from probe_gxw_simple_fb import frame_source, observe_calls
from probe_gxw_parameters import device_allocation_record
from probe_gxw_sfc_graph import patch_raw
from native_gxw_tokens import native_batch, Q_DLL, native_il_records
from replay_gxw_workspace import prepare, trace_prepared
from probe_gxw_program_check_resources import SCRIPT, inspect_run
from source_q_direct_projection import project_projection

P = Path(__file__).resolve().parent
OUT = P/'minimal-conditional-port-writes-20260930'


def save(path, value):
    path.write_text(json.dumps(value, indent=2)+'\n', encoding='utf-8')


def streams(source):
    return {s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}


def splice(raw, start, end, replacement):
    result = bytearray(raw[:start]+replacement+raw[end:])
    for offset in (55, 59):
        struct.pack_into('<I', result, offset, struct.unpack_from('<I', raw, offset)[0]+len(replacement)-(end-start))
    return bytes(result)


def observe(path, directory, trace):
    for attempt in range(1, 5):
        native = directory/f'native-{attempt}'
        prepare(path, native, compile=True, program_check=True, export_project=True,
                snapshot_frontend=True, project_alias='PORTWRITES')
        process = trace_prepared(native, trace)
        events = [json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
        if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):
            break
    result = inspect_run(native)
    if process['timed_out'] or result['trace_errors']:
        raise RuntimeError('incomplete native observation; retained')
    return native, result, process


def main():
    OUT.mkdir(exist_ok=False)
    for name in (Path(__file__).name, 'source_q_direct_projection.py', 'source_q_direct_declarations.py',
                 'source_q_call_connections.py', 'source_q_label_binding.py', 'source_q_width.py'):
        (OUT/name).write_bytes((P/name).read_bytes())
    trace = OUT/'trace.js'; trace.write_text(SCRIPT, encoding='utf-8')
    texts = {
        'int-body': "LD SM400\0MOV K7 'iUnitNo\0MOV 'iUnitNo 'oRecvCmdNum",
        'string-body': 'LD SM400\0$MOV "WRITE" \'iResStr\0$MOV \'iResStr \'oRecvData',
        'int-output': "LD X4F\0ANI X5F\0MOV '_oRecvCmdNum D300",
        'string-output': "LD X4F\0ANI X5F\0$MOV '_oRecvData D400",
    }
    original = (P/'q-conditional-value-connections/int-device/input.gxw').read_bytes()
    encoded = native_batch([dict(mode='encode', name=k, text=t, input_base64=base64.b64encode(t.encode()+b'\0\0').decode())
                            for k,t in texts.items()], OUT/'native-encode', dll=Q_DLL, cpu_code=209,
                           native_versions=(25,), device_context=device_allocation_record(streams(original)['Param.wpa']).raw)
    assert all(r['return_code']=='0x00000000' for r in encoded), encoded
    tokens = {k:base64.b64decode(r['output_base64']) for k,r in zip(texts,encoded)}
    ready = []
    for kind in ('int', 'string'):
      for value in ('device', 'literal'):
        case = kind+'-'+value; directory = OUT/case; directory.mkdir()
        source = (P/f'q-conditional-value-connections/{case}/input.gxw').read_bytes()
        before = streams(source); receipts = []
        name = 'MAIN.Program.pou'; frame = frame_source(before[name]); calls = observe_calls(frame)['calls']
        assert len(calls)==2 and calls[0]['offset']+calls[0]['length']==calls[1]['offset']
        raw = splice(frame.raw, calls[1]['offset'], calls[1]['offset']+calls[1]['length'], b'')
        out = calls[0]['output_fragment']
        raw = splice(raw, out['offset'], out['offset']+out['length'], tokens[kind+'-output'])
        source, receipt = patch_raw(source, name, before[name], raw); receipts.append(receipt)
        name = 'SCPI.Program.pou'; frame = frame_source(before[name])
        body = splice(frame.raw, frame.body_offset, frame.body_end, tokens[kind+'-body'])
        source, receipt = patch_raw(source, name, before[name], body); receipts.append(receipt)
        after = streams(source)
        assert after==dict(before, **{'MAIN.Program.pou':raw, 'SCPI.Program.pou':body})
        path = directory/'input.gxw'; path.write_bytes(source)
        prediction = project_projection(source, allow_scpi=True, resource_limit=1)[0]
        (directory/'predicted-0.bin').write_bytes(prediction['output'])
        save(directory/'prediction-before-native.json', dict(case=case, input_sha256=sha256(source), receipts=receipts,
            prediction={k:v for k,v in prediction.items() if k!='output'}, body_text=texts[kind+'-body'],
            output_text=texts[kind+'-output'], hypothesis='Direct input/output D connections alias despite conditional guards; literals copy into persistent allocated input storage.'))
        ready.append((case,directory,path,prediction))
    results = []; decodes = []; decode_keys = []
    for case,directory,path,prediction in ready:
        native,result,process = observe(path,directory,trace)
        code = (native/'pcode-0-0.bin').read_bytes()
        row = dict(case=case, native_directory=str(native), process=process, check=result['check'], diagnostics=result['diagnostics'],
                   predicted_equal=code==prediction['output'], sha256=sha256(code), exported=bool(result['exported_sha256']),
                   reads=result['resource_reads'])
        if result['exported_sha256']:
            reopen = directory/'reopen'; reopen.mkdir()
            reopened,checked,proc = observe(native/'native-saved.gxw',reopen,trace)
            row['reopen'] = dict(native_directory=str(reopened), check=checked['check'], diagnostics=checked['diagnostics'],
                                 byte_identical=code==(reopened/'pcode-0-0.bin').read_bytes(), reads=checked['resource_reads'])
        decodes.append(dict(mode='decode', input_base64=base64.b64encode(code+b'\0').decode(), case=case));decode_keys.append(case)
        results.append(row); save(OUT/'comparison.json',results)
        print(json.dumps({k:v for k,v in row.items() if k not in ('reads','reopen')}|dict(reopen=row.get('reopen',{}).get('byte_identical'))),flush=True)
    decoded = native_batch(decodes, OUT/'native-decode', dll=Q_DLL, cpu_code=209,native_versions=(25,))
    save(OUT/'native-listings.json', [dict(case=k, return_code=r['return_code'],
        records=native_il_records(base64.b64decode(r['output_base64']),encoding='cp932')) for k,r in zip(decode_keys,decoded)])


if __name__=='__main__':
    main()
