"""Separate serialized UTF-16 source from the native compiler text transport."""
from pathlib import Path
import argparse
import base64
import json
import struct
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'research')]
from gxw.lossless import inspect_project, inspect_program, sha256
from gxw.text_pou import parse_st_pou
from gxw_corpus import project_token_context
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_st_sources import snapshot_body
from replay_gxw_workspace import run

P = Path(__file__).resolve().parent
OUT = P / 'st-text-preservation'


def envelope(raw, text_bytes):
    assert len(text_bytes) % 2 == 0
    updated = bytearray(raw[:71] + text_bytes + b'\0\0' + raw[-28:])
    struct.pack_into('<I', updated, 67, len(text_bytes) // 2 + 1)
    struct.pack_into('<II', updated, 55, len(updated) - 83, len(updated) - 83)
    return bytes(updated)


def main():
    global OUT
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--nul-control', action='store_true')
    args = parser.parse_args()
    if args.nul_control:
        OUT = P / 'st-nul-suffix-control'
    OUT.mkdir(exist_ok=False)
    (OUT / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    seed = ROOT / 'research/experiments/structured-compiler-20260920/gui-st-project/st-control.gxw'
    source = seed.read_bytes()
    context = project_token_context(inspect_project(source))
    stream, = [s for s in inspect_project(source).streams if (s.logical_name or '').endswith('.pou')]
    plans = [
        ('unicode-comment', '(* \U0001f680; \u6c49\u5b57; \u03a9 *)\r\nY0:=X0;\r\n'.encode('utf-16le')),
        ('mixed-line-endings', '(* source\r\nlayout *)\nY0\t:= X0;\r\n'.encode('utf-16le')),
        ('embedded-nul', 'Y0:=X0;\r\n\0D0:=1;\r\n'.encode('utf-16le')),
        ('unpaired-surrogate', '(* '.encode('utf-16le') + bytes.fromhex('00d8') + ' *)\r\nY0:=X0;\r\n'.encode('utf-16le')),
    ]
    if args.nul_control:
        plans = [('without-nul', 'Y0:=X0;\r\nD0:=1;\r\n'.encode('utf-16le'))]
    ready = []
    for name, payload in plans:
        target = OUT / name
        target.mkdir()
        updated = envelope(stream.raw, payload)
        changed, receipt = patch_raw(source, stream.logical_name, stream.raw, updated)
        original_streams = {(s.layer, s.name): s.raw for s in inspect_project(source).streams}
        after_streams = {(s.layer, s.name): s.raw for s in inspect_project(changed).streams}
        touched = [list(k) for k in original_streams.keys() | after_streams.keys() if original_streams.get(k) != after_streams.get(k)]
        assert [s for s in touched if s[0] == 'nested'] == [['nested', stream.name]]
        (target / 'source.gxw').write_bytes(changed)
        (target / 'source-program.bin').write_bytes(updated)
        parsed = parse_st_pou(updated)
        prediction = dict(source_sha256=sha256(source), program=stream.logical_name,
            project_context=context,
            candidate_sha256=sha256(changed), utf16_hex=payload.hex(), decoded_text=parsed.text,
            text_gap=parsed.diagnostic, unchanged_unrelated_nested=True, touched=touched, receipt=receipt,
            cp936_strict_representable=None)
        if parsed.text is not None:
            try:
                encoded = parsed.text.encode('cp936') + b'\0'
                prediction.update(cp936_strict_representable=True, exact_frontend_candidate=encoded.hex())
            except UnicodeError:
                prediction['cp936_strict_representable'] = False
        (target / 'prediction-before-native.json').write_text(json.dumps(prediction, indent=2), encoding='utf-8')
        ready.append((name, target, updated))
    results = []
    for name, target, original_pou in ready:
        path = target / 'source.gxw'
        phases = []
        for phase in ('compile', 'reopen'):
            for attempt in range(1, 5):
                native = target / f'{phase}-{attempt}'
                outcome = run(path, native, compile=True, program_check=True, export_project=True,
                    snapshot_frontend=True, project_alias='STTEXT')
                events = [json.loads(l) for l in (native / 'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
                if not any(e.get('operation') == 'NativeTemporaryDirectoryCollision' for e in events):
                    break
            row = dict(phase=phase, native_directory=str(native), outcome=outcome)
            snapshot = native / 'frontend-snapshot.json'
            if snapshot.exists():
                body = snapshot_body(json.loads(snapshot.read_text(encoding='utf-8')), stream.logical_name.removesuffix('.Program.pou'))
                (native / 'source-frontend-body.bin').write_bytes(body)
                count = struct.unpack_from('<I', body, 72)[0]
                row.update(frontend_length=count, frontend_hex=body[76:76+count].hex())
            path = native / 'native-saved.gxw'
            if path.exists():
                saved = next(s.raw for s in inspect_project(path.read_bytes()).streams if s.logical_name == stream.logical_name)
                (native / 'saved-source-program.bin').write_bytes(saved)
                saved_source = parse_st_pou(saved)
                row.update(saved_utf16_hex=saved_source.text_bytes.hex(),
                    utf16_source_preserved=saved_source.text_bytes == parse_st_pou(original_pou).text_bytes,
                    saved_text_gap=saved_source.diagnostic)
            phases.append(row)
            print(json.dumps(dict(case=name, phase=phase, rejected=outcome['compiler_rejected'],
                full_check=outcome['program_check_completed'], frontend_hex=row.get('frontend_hex'),
                utf16_preserved=row.get('utf16_source_preserved'), diagnostics=outcome['diagnostics'])), flush=True)
            if not path.exists() or outcome['compiler_rejected']:
                break
        results.append(dict(case=name, phases=phases))
        (OUT / 'comparison.json').write_text(json.dumps(results, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
