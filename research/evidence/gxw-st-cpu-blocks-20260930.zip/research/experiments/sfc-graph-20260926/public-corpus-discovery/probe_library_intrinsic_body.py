"""Separate source IL lowering from compiler-recognized timer names."""
from pathlib import Path
import sys,json,base64
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from gxw.lossless import inspect_project,sha256
from probe_gxw_library_archive import decode_library_archive,encode_library_literals,frame_library_text,observed_source_body
from probe_gxw_library_sources import snapshot_library_pous
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import run
from probe_gxw_compiled_references import inspect
P=Path(__file__).resolve().parent
results=[]
for name,baseline in [('TON_E',P/'ST-standard-timer-controls/TON_E_true'),('LIB_ALIAS_TON_E',P/'library-fb-alias-controls/TON_E')]:
 out=P/'library-intrinsic-body-controls'/name;out.mkdir(parents=True,exist_ok=False)
 source=(baseline/'changed.gxw').read_bytes();before={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
 lib='IECFunction.lif';raw=before[lib];plain=decode_library_archive(raw[20:]).decoded
 selected=[d for d in frame_library_text(plain)['definitions'] if d['name']==name and (d['sections'] is None or 'Q03UDV' in d['sections'])]
 assert len(selected)==1
 definition=selected[0];body=observed_source_body(definition)
 assert body==b'LD\tTRUE (* To get no warning message during check *)\r\n'
 offset=definition['offset']+definition['raw'].index(body)+len(body)
 inserted=b'ST\tQ\r\n'
 changed_plain=plain[:offset]+inserted+plain[offset:]
 packed=raw[:20]+encode_library_literals(changed_plain)
 changed,receipt=patch_raw(source,lib,raw,packed)
 after={s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}
 assert all(after[k]==v for k,v in before.items() if k!=lib)
 (out/'changed.gxw').write_bytes(changed)
 (out/'mutation.json').write_text(json.dumps(dict(source_sha256=sha256(source),changed_sha256=sha256(changed),source_offset=offset,inserted=inserted.decode(),source_prefix_suffix='byte-identical',unrelated_payloads='byte-identical',receipt=receipt),indent=2))
 native=run(out/'changed.gxw',out/'native',compile=True,export_project=True,snapshot_frontend=True)
 row=dict(name=name,native=native)
 if native.get('native_export') and not native.get('compiler_rejected'):
  row['pcode_equal_to_original']=all((baseline/'native'/f).read_bytes()==(out/'native'/f).read_bytes() for f in native['outputs'])
  entries=snapshot_library_pous(json.loads((out/'native/frontend-snapshot.json').read_text(encoding='utf-8-sig')))
  entry=next(e for e in entries if (e['library'],e['name'])==('@IEC',name))
  row['frontend_body_contains_mutation']=body+inserted in base64.b64decode(entry['program_raw_base64'])
  correlated=inspect(out/'native',out/'correlation');decoded=correlated['decoded_fragments']
  row['compiled_library_regions']=[dict(names=e['stored_names'],code=[decoded[g['decode_request']].get('records') for g in e['compiled_records']]) for e in correlated['expansions'] if e['handling'].startswith('compiled-library-region')]
 (out/'comparison.json').write_text(json.dumps(row,indent=2));results.append(row)
 print(json.dumps(row),flush=True)
(P/'library-intrinsic-body-controls/comparison.json').write_text(json.dumps(results,indent=2))
