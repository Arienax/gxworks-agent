"""Keep graph source edits small while distinguishing library bodies and calls."""
from dataclasses import replace
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.structured_pou import parse_structured_pou
from gxw.structured_pou_writer import serialize_structured_pou
from gxw.declarations import parse_declarations,edit_declarations,serialize_declarations
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_compiled_references import inspect
from probe_gxw_debug_locations import lookup
from gxw.compiler_debug import parse_compiler_debug
from replay_gxw_workspace import run
P=Path(__file__).resolve().parent
OUT=P/'graph-library-call-controls';OUT.mkdir(exist_ok=True)
source=(P/'structured-graph-location-controls/library_fb/native/native-saved.gxw').read_bytes()
streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
name='1.Program.pou';program=parse_structured_pou(streams[name],logical_name=name)
for case in ['same_instance','TOF','TP']:
    out=OUT/case;out.mkdir(exist_ok=True)
    if (out/'comparison.json').exists():continue
    nodes=tuple(replace(n,symbol='TIMER_A') if case=='same_instance' and n.symbol=='TIMER_B'
                else replace(n,type_name=case) if case!='same_instance' and n.kind_code==2 else n for n in program.nodes)
    replacements={name:serialize_structured_pou(replace(program,nodes=nodes))}
    if case!='same_instance':
        labels='1.Labels.lh';d=parse_declarations(streams[labels],logical_name=labels)
        replacements[labels]=serialize_declarations(edit_declarations(d,upserts=[dict(name=n.symbol,data_type=case,kind='function_block') for n in nodes if n.kind_code==2]))
    changed=source;receipts=[]
    for logical,raw in replacements.items():
        changed,receipt=patch_raw(changed,logical,streams[logical],raw);receipts.append(receipt)
    after={s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}
    assert all(after[n]==raw for n,raw in streams.items() if n not in replacements)
    path=out/'changed.gxw';path.write_bytes(changed)
    (out/'mutation.json').write_text(json.dumps(dict(source_sha256=sha256(source),changed_sha256=sha256(changed),receipts=receipts,
        changed_streams=list(replacements),unrelated_payloads='byte-identical'),indent=2),encoding='utf-8')
    result=run(path,out/'native',compile=True,export_project=True,project_alias='LIBRARYCALL',
        analysis_queries=[dict(name='all',keys=[],symbol='',scope='',declared=0,plural=0)],analysis_version=3,
        pcode_location_queries=[dict(resource='MAIN',start_step=i,step_count=1,timestamp=0) for i in range(256)])
    comparison=dict(case=case,native={k:result[k] for k in ['returncode','compile_completed','compiler_rejected','diagnostics']})
    if result.get('native_export'):
        reopened=run(out/'native/native-saved.gxw',out/'reopen',compile=True,export_project=True)
        comparison['reopen']={k:reopened[k] for k in ['returncode','compile_completed','compiler_rejected','diagnostics']}
        comparison['reopen_pcode_equal']=result['outputs']==reopened['outputs']
        read=inspect(out/'native',out/'correlation');comparison['reader']=read['summary']
        comparison['elements']=[{k:e[k] for k in ['element_index','stored_names','fields','stored_instance_paths','handling']} for e in read['expansions']]
        debug=parse_compiler_debug(next(s.raw for s in inspect_project((out/'native/native-saved.gxw').read_bytes()).streams if s.logical_name=='DebugInformation2.dat'))
        actual=json.loads((out/'native/native-pcode-locations.json').read_text(encoding='utf-8-sig'))
        comparisons=[]
        for row in actual:
            q=row['query'];want=lookup(debug,q['resource'],q['start_step'],encoding='cp936')
            comparisons.append(dict(query=q,reader=want,native=row,equal=want['location']==row['location']))
        (out/'location-comparison.json').write_text(json.dumps(comparisons,indent=2),encoding='utf-8')
        comparison['locations']=dict(total=len(comparisons),exact=sum(r['equal'] for r in comparisons),
            native_locations=sum(r['native']['location'] is not None for r in comparisons))
        refs=json.loads((out/'native/native-program-analysis.json').read_text(encoding='utf-8-sig'))
        comparison['native_references']=refs
    (out/'comparison.json').write_text(json.dumps(comparison,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in comparison.items() if k!='native_references'}),flush=True)
