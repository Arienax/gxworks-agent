"""Package redistributable raw source slices and independent native readings.

This archive supports the production Q lexical reader; it contains no vendor
binaries and no source from the project2 corpus item with unresolved licensing.
"""
from pathlib import Path
import base64, json, platform, sys, zipfile

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'research')]
from gxw.lossless import inspect_project, sha256
from gxw.token_pou import frame_token_pou
from native_gxw_tokens import native_il_projection

P = Path(__file__).resolve().parent
target = ROOT / 'research/evidence/gxw-q-token-grammar-20260927.zip'
files = {}
def add(name, raw):
    assert name not in files
    files[name] = raw
def add_json(name, data):
    add(name, (json.dumps(data, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))

sources = {sha256(f.read_bytes()): f for root in ['samples', 'noeul-public-corpus'] for f in (P/root).rglob('*.gxw')}
programs = []
for folder in sorted((P/'native-listing-own-context').glob('case-*')):
    listing = json.loads((folder/'listing.json').read_text(encoding='utf-8'))
    if listing['context']['cpu'] != 'Q03UDV' or not (folder/'native/requests.json').exists():
        continue
    source = sources[listing['source_sha256']]
    if source.name == 'project2.gxw':
        continue
    assert 'noeul-public-corpus' in source.parts or source.name == 'scpi-SCPI_FB.gxw'
    streams = {s.logical_name: s.raw for s in inspect_project(source.read_bytes()).streams if s.logical_name}
    prefix = f'real/{folder.name}'
    for name in ('requests.json', 'native-stdout.jsonl', 'process.json', 'native-stderr.bin'):
        add(prefix + '/native/' + name, (folder/'native'/name).read_bytes())
    meta = [(n,r) for n,r in streams.items() if n.endswith('.prj')]
    assert len(meta) == 1
    add(prefix + '/metadata.prj', meta[0][1])
    requests = json.loads((folder/'native/requests.json').read_text(encoding='utf-8'))['requests']
    answers = [json.loads(s) for s in (folder/'native/native-stdout.jsonl').read_text(encoding='utf-8').splitlines()]
    for index, (request, answer) in enumerate(zip(requests, answers)):
        raw = streams[request['program']]
        frame = frame_token_pou(raw)
        assert sha256(raw) == request['source_sha256']
        assert frame.body + b'\0' == base64.b64decode(request['input_base64'])
        assert answer['return_code'] == '0x00000000' and answer['consumed_bytes'] == len(frame.body)
        native = native_il_projection(base64.b64decode(answer['output_base64']), encoding=listing['context']['text_encoding'])
        assert not native['text_gaps']
        name = prefix + f'/source-{index}.pou'
        add(name, raw)
        programs.append(dict(source=name, request_index=index, native_prefix=prefix+'/native',
                             original_project=str(source.relative_to(P)), project_sha256=listing['source_sha256'],
                             logical_name=request['program'], source_sha256=sha256(raw),
                             body_sha256=sha256(frame.body), context=listing['context'], records=len(native['records'])))

for root in ('q-token-catalog', 'q-token-catalog-v2', 'q-instruction-query-initial',
             'q-instruction-query-catalog', 'q-header-catalog-controls', 'q-header-version25-controls',
             'q-stored-width-controls', 'q-operand-catalog-controls'):
    for file in (P/root).rglob('*'):
        if file.is_file() and file.suffix.lower() not in ('.exe', '.dll', '.pyc'):
            add('controls/' + str(file.relative_to(P)).replace('\\', '/'), file.read_bytes())
for file in ('QueryInstructionCatalog.cs', 'query_q_instruction_catalog.py',
             'extract_q_instruction_catalog.py', 'probe_q_token_lexical.py',
             'probe_q_operand_catalog.py', 'probe_q_header_catalog.py',
             'crosscheck_q_real_programs.py', 'freeze_q_token_evidence.py'):
    add('scripts/' + file, (P/file).read_bytes())
for file in ('research/native_gxw_tokens.py', 'research/native/TokenOracle.cs',
             'research/probe_gxw_native_listing.py', 'research/probe_gxw_compiled_references.py'):
    add('scripts/' + file, (ROOT/file).read_bytes())
add('licenses/No-Eul-MIT.txt', (P/'noeul-public-corpus/LICENSE.txt').read_bytes())
add('licenses/SCPI-MIT.txt', (P/'samples/scpi-LICENSE.txt').read_bytes())
add('licenses/SCPI-provenance.json', (P/'scpi-provenance.json').read_bytes())
manifest = dict(schema_version=1, date='2026-09-27', programs=programs,
    environment=dict(platform=platform.platform(), python=platform.python_version(), native_adapter='fresh x86 offline process, CPU 209, no project/device API'),
    origins=[dict(repo='https://github.com/No-Eul/GX-Works2-Practice', commit='0fff8f3672dea198952bfa4b519ce13764d6fc73', license='MIT'),
             dict(provenance='licenses/SCPI-provenance.json', license='MIT')],
    summary=dict(programs=len(programs), projects=len({p['project_sha256'] for p in programs}), records=sum(p['records'] for p in programs)),
    distinctions=['Native text conversion is independent of the Python lexical table, not proof of compilation or execution.',
                  'Header controls: 2618 exact successes, 30 native failures without versions; those 30 succeed with SetVersion(25). The portable reader conservatively retains these version-dependent families as gaps.',
                  '766 descriptor lookups: 574 entries, 192 holes. Lookup success alone does not establish text-decoder acceptance.',
                  '354 numeric/modifier raw controls match native text. Float formatting remains unsupported.',
                  'First table extraction incorrectly treated alignment as a prefix; its failure and script are retained.',
                  'Q stored widths are signed bytes; positive stored values are preserved, not recomputed or validated.',
                  'The complete local corpus comparison also includes one unlicensed project: 76 POUs, 36 projects, 7513 records. That project is omitted from this archive.'],
    files=[dict(path=n, bytes=len(b), sha256=sha256(b)) for n,b in sorted(files.items())])
add_json('manifest.json', manifest)
with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, raw in sorted(files.items()):
        z.writestr(name, raw)
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    for record in manifest['files']:
        assert sha256(z.read(record['path'])) == record['sha256']
print(json.dumps(dict(path=str(target), sha256=sha256(target.read_bytes()), bytes=target.stat().st_size, files=len(files), summary=manifest['summary'])))
