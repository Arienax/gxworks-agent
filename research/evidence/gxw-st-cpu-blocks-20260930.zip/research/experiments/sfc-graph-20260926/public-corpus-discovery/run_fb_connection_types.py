"""Distinguish wider FB pin templates and compound BOOL source wiring."""
import base64
import json
from pathlib import Path
import struct
import sys

ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.token_pou import frame_token_pou
from native_gxw_tokens import native_batch,Q_DLL
from probe_gxw_parameters import device_allocation_record
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_simple_fb import observe_calls
from probe_gxw_simple_fb_connections import inspect as connections
from replay_gxw_workspace import run

P=Path(__file__).resolve().parent
OUT=P/'native-fb-connection-type-controls'
OUT.mkdir(exist_ok=False)
source=(P/'scpi-two-callers/native/native-saved.gxw').read_bytes()
streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
name='MAIN.Program.pou'
frame=frame_token_pou(streams[name])
call=observe_calls(frame)['calls'][0]
texts={
    'dint':"LD '_TRUE\0DMOV D200 '_iPrm",
    'string_in':"LD '_TRUE\0$MOV D220 '_iResStr",
    'string_out':"LD '_TRUE\0$MOV '_oRecvData D260",
    'compound':"LD X1F\0AND X0\0OUT '_iEn\0LD '_TRUE\0MOV K1 '_iUnitNo",
}
answers=native_batch([dict(mode='encode',label=k,input_base64=base64.b64encode(v.encode('ascii')+b'\0\0').decode()) for k,v in texts.items()],
    OUT/'native-encode',dll=Q_DLL,cpu_code=209,native_versions=(25,),device_context=device_allocation_record(streams['Param.wpa']).raw)
encoded={name:base64.b64decode(r['output_base64']) for name,r in zip(texts,answers) if r['return_code']=='0x00000000'}
print(json.dumps({name:r['return_code'] for name,r in zip(texts,answers)}),flush=True)
for case in ['dint','string','compound']:
    directory=OUT/case
    directory.mkdir()
    replacements=[]
    for direction in ['input','output']:
        span=call[direction+'_fragment'];start=span['offset'];end=start+span['length']
        original=frame.raw[start:end]
        new=original
        if case=='dint' and direction=='input':new+=encoded['dint']
        if case=='string':new+=encoded['string_in' if direction=='input' else 'string_out']
        if case=='compound' and direction=='input':new=encoded['compound']
        replacements.append((start,end,new))
    program=frame.raw
    for start,end,new in sorted(replacements,reverse=True):program=program[:start]+new+program[end:]
    program=bytearray(program)
    delta=len(program)-len(frame.raw)
    for offset in [55,59]:struct.pack_into('<I',program,offset,struct.unpack_from('<I',frame.raw,offset)[0]+delta)
    changed,receipt=patch_raw(source,name,frame.raw,bytes(program))
    path=directory/'changed.gxw';path.write_bytes(changed)
    (directory/'mutation.json').write_text(json.dumps(dict(source_sha256=sha256(source),case=case,receipt=receipt),indent=2),encoding='utf-8')
    query=[dict(name='SCPI_1',keys=[dict(category=1,value='SCPI_1'),dict(category=4,value='MAIN')])]
    native=run(path,directory/'native',compile=True,export_project=True,project_alias='FBPINTYPE',assignment_queries=query)
    row=dict(case=case,native={k:native[k] for k in ['returncode','compile_completed','compiler_rejected','diagnostics']})
    if native.get('native_export'):
        again=run(directory/'native/native-saved.gxw',directory/'reopen',compile=True,export_project=True,assignment_queries=query)
        row['reopen_equal']=native['outputs']==again['outputs']
        row['reopen']={k:again[k] for k in ['returncode','compile_completed','compiler_rejected','diagnostics']}
        captured=json.loads((directory/'native/native-device-assignments.json').read_text(encoding='utf-8-sig'))
        row['pins']=[a for a in captured[0]['assignments'] if a['name'] in ['SCPI_1.iPrm','SCPI_1.iResStr','SCPI_1.oRecvData','SCPI_1.iEn']]
    read=connections(changed,directory/'source-connections')
    row['source_connections']=read['summary']
    (directory/'comparison.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
    print(json.dumps(row),flush=True)
