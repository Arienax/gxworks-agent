"""Retain the native global-instance counterexample for portable reader checks."""
from pathlib import Path
import base64,hashlib,json
ROOT=Path(__file__).resolve().parents[4]
P=Path(__file__).resolve().parent
directory=P/'q-global-instance-links/native-table-read'
def artifact(path):
    raw=path.read_bytes()
    return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),base64=base64.b64encode(raw).decode())
request=json.loads((directory/'request.json').read_text())
assert hashlib.sha256((ROOT/'research/native/CompilerTableOracle.cs').read_bytes()).hexdigest()==request['adapter_source_sha256']
result=dict(schema=1,source='MIT SCPI derivative with two global instances and no task programs',
    scope='Native compiler-table scalar FB references and raw replay; no body execution or source validation claim',
    source_project_sha256=hashlib.sha256((P/'q-global-instance-links/input.gxw').read_bytes()).hexdigest(),
    source_control='research/experiments/sfc-graph-20260926/public-corpus-discovery/probe_q_global_instance_links.py',
    source_control_sha256=hashlib.sha256((P/'q-global-instance-links/probe.py').read_bytes()).hexdigest(),
    license=(P/'samples/scpi-LICENSE.txt').read_text(encoding='utf-8-sig'),
    native_request=request,native_process=json.loads((directory/'process.json').read_text()),
    native_original_comparison=json.loads((directory/'comparison.json').read_text()),
    original_failure='Portable instance traversal omitted both global references; old textual dump matching also omitted native unknown-type (?) timer names.',
    artifacts={name:artifact(directory/name) for name in ['CGTable.dat','native-components.jsonl','native-replay.bin','native-table-dump.txt']})
target=ROOT/'tests/fixtures/gxw_global_instances.json'
with target.open('x',encoding='utf-8') as f:json.dump(result,f,ensure_ascii=False,indent=2)
print(json.dumps(dict(path=str(target.relative_to(ROOT)),bytes=target.stat().st_size,sha256=hashlib.sha256(target.read_bytes()).hexdigest())))
