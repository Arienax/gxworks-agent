from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from replay_gxw_workspace import prepare,trace_prepared
P=Path(__file__).resolve().parent
out=P/'timer-parameter-controls/high-150/component-cursor-trace'
prepare(out.parent/'changed.gxw',out,compile=True,export_project=True)
print(json.dumps(trace_prepared(out,P/'TraceComponentCursor.js',timeout=45)),flush=True)
events=[json.loads(l) for l in (out/'events.jsonl').read_text().splitlines()]
rows=[e['payload'] for e in events if e.get('payload',{}).get('event')=='component-cursor-read']
negative=[dict(before=rows[max(0,i-2):i],read=r,after=rows[i+1:i+3]) for i,r in enumerate(rows) if r['requested']<0]
result=dict(total_calls=len(rows),negative=negative,errors=[e for e in events if e.get('type')=='error'])
(out/'cursor-comparison.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result),flush=True)
