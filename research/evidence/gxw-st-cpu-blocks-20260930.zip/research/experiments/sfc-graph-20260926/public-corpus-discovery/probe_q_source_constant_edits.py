"""Native compile/reopen checks for source-bound Q integer operand edits.

Only isolated copies of two MIT No-Eul projects are changed. The existing
experimental integrity-aware container writer retains all unrelated payloads.
This does not enable Q editing in the product or claim runtime equivalence.
"""
from pathlib import Path
import base64, json, sys

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'research')]
from gxw.lossless import inspect_project, sha256
from gxw.token_listing import decode_token_listing
from gxw.project_metadata import read_project_text_context
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import run
from native_gxw_tokens import native_batch, native_il_projection, Q_DLL

P = Path(__file__).resolve().parent
out = P / 'q-source-constant-edits'
out.mkdir(exist_ok=False)
(out / 'probe.py').write_bytes(Path(__file__).read_bytes())
plans = [dict(case='comparison', prefix='2023-04-13 #1', program='기본동작.Program.pou', offset=93, old='K1', new='K2', payload='02'),
         dict(case='timer', prefix='2023-04-13 #1', program='응용동작1.Program.pou', offset=1012, old='K313', new='K314', payload='3a01'),
         dict(case='signed', prefix='2023-05-10 #1', program='연속동작.Program.pou', offset=148, old='K-1', new='K-2', payload='feff')]

def compile_owned(path, directory):
    for attempt in range(1, 9):
        target = directory / ('native' if attempt == 1 else 'native-v' + str(attempt))
        result = run(path, target, compile=True, export_project=True, project_alias='QTOKENEDIT')
        events = [json.loads(s) for s in (target/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
        if (target/'pcode-0-0.bin').exists() or not any(e.get('operation') == 'NativeTemporaryDirectoryCollision' for e in events):
            break
    accepted = result['returncode'] == 0 and result['open_succeeded'] and result['compile_completed'] and not result['compiler_rejected'] and (target/'native-saved.gxw').exists()
    return dict(directory=str(target.relative_to(out)), accepted=accepted,
                outcome={k:result[k] for k in ('returncode','open_succeeded','compile_completed','compiler_rejected','diagnostics','project_codepage')})

def streams(source):
    image = inspect_project(source)
    assert not image.diagnostics and not any(s.error for s in image.streams)
    return {s.logical_name:s.raw for s in image.streams if s.logical_name}

bases = {}; rows = []
for plan in plans:
    paths = list((P/'noeul-public-corpus').glob(plan['prefix'] + '*.gxw'))
    assert len(paths) == 1
    source = paths[0].read_bytes()
    key = sha256(source)
    if key not in bases:
        directory = out / ('baseline-' + str(len(bases)))
        directory.mkdir()
        path = directory/'source.gxw'; path.write_bytes(source)
        bases[key] = dict(source=str(paths[0].relative_to(P)), source_sha256=key, **compile_owned(path, directory))
        print(json.dumps(dict(phase='baseline', **bases[key])), flush=True)
    if not bases[key]['accepted']:
        rows.append(dict(plan, skipped='baseline native compilation failed'))
        continue
    original = streams(source)
    context = read_project_text_context(next(raw for n,raw in original.items() if n.endswith('.prj')))
    raw = original[plan['program']]
    before = decode_token_listing(raw, profile='q03udv', text_encoding=context['text_encoding'])
    matches = [(record, operand) for record in before.instructions for operand in record.operands
               if len(operand.tokens) == 1 and operand.tokens[0].offset == plan['offset']]
    assert len(matches) == 1
    record, operand = matches[0]
    token = operand.tokens[0]
    assert operand.text == plan['old'] and token.raw[1] == 0xe8
    payload = bytes.fromhex(plan['payload']); assert len(payload) == len(token.raw) - 3
    start = token.offset + 2
    changed_pou = raw[:start] + payload + raw[start + len(payload):]
    after = decode_token_listing(changed_pou, profile='q03udv', text_encoding=context['text_encoding'])
    diffs = [(i,a,b) for i,(a,b) in enumerate(zip(before.instructions, after.instructions, strict=True)) if a != b]
    assert len(diffs) == 1 and diffs[0][2].args == tuple(plan['new'] if o is operand else o.text for o in record.operands)
    changed, receipt = patch_raw(source, plan['program'], raw, changed_pou)
    payloads = streams(changed)
    assert payloads == dict(original, **{plan['program']:changed_pou})
    directory = out/plan['case']; directory.mkdir()
    path = directory/'changed.gxw'; path.write_bytes(changed)
    mutation = dict(plan, project_source=str(paths[0].relative_to(P)), source_sha256=key, output_sha256=sha256(changed),
                    source_instruction=dict(op=record.mnemonic,args=list(record.args),stored_width=record.step_width),
                    changed_source_record=diffs[0][0], container=receipt, unrelated_logical_payloads='byte-identical')
    (directory/'mutation.json').write_text(json.dumps(mutation,indent=2),encoding='utf-8')
    native = compile_owned(path, directory)
    row = dict(plan, baseline=bases[key]['directory'], native=native)
    if native['accepted']:
        saved = streams((out/native['directory']/'native-saved.gxw').read_bytes())
        row['native_saved_pou_byte_identical'] = saved[plan['program']] == changed_pou
        reopened = directory/'reopen'; reopened.mkdir()
        row['reopen'] = compile_owned(out/native['directory']/'native-saved.gxw', reopened)
        row['reopen_pcode_byte_identical'] = {f.name:f.read_bytes() for f in (out/native['directory']).glob('pcode-*.bin')} == {f.name:f.read_bytes() for f in (out/row['reopen']['directory']).glob('pcode-*.bin')}
    rows.append(row)
    (directory/'native-comparison.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
    print(json.dumps(row),flush=True)

# Decode whole independent compiler outputs, not just the edited source slice.
requests=[]; indices={}; files={}
for row in rows:
    if not row.get('native',{}).get('accepted'):continue
    for directory in (row['baseline'],row['native']['directory']):
        if directory in files:continue
        files[directory]={}
        for file in sorted((out/directory).glob('pcode-*.bin')):
            raw=file.read_bytes(); key=sha256(raw)
            if key not in indices:
                indices[key]=len(requests)
                requests.append(dict(mode='decode',input_base64=base64.b64encode(raw+b'\0').decode()))
            files[directory][file.name]=dict(sha256=key,request=indices[key])
answers=native_batch(requests,out/'native-pcode-decode',dll=Q_DLL,cpu_code=209)
decoded=[]
for request,answer in zip(requests,answers,strict=True):
    assert answer['return_code']=='0x00000000'
    assert answer['consumed_bytes']==len(base64.b64decode(request['input_base64']))-1
    projection=native_il_projection(base64.b64decode(answer['output_base64']),encoding='cp949')
    assert not projection['text_gaps']; decoded.append(projection['records'])
for row in rows:
    if not row.get('native',{}).get('accepted'):continue
    a,b=files[row['baseline']],files[row['native']['directory']]
    assert a.keys()==b.keys()
    changes=[]
    for name in a:
        x,y=decoded[a[name]['request']],decoded[b[name]['request']]
        assert len(x)==len(y)
        changes += [dict(file=name,record=i,before=p,after=q) for i,(p,q) in enumerate(zip(x,y,strict=True)) if p!=q]
    row['compiled_changes']=changes
    row['only_intended_operand_changed']=len(changes)==1 and changes[0]['after']==dict(changes[0]['before'],args=[row['new'] if v==row['old'] else v for v in changes[0]['before']['args']])
result=dict(baselines=bases,cases=rows,compiled_files=files,decoded=decoded,scope=__doc__)
with (out/'comparison.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2,ensure_ascii=False)
print(json.dumps([dict(case=r['case'],accepted=r.get('native',{}).get('accepted'),only_intended_operand_changed=r.get('only_intended_operand_changed'),changes=r.get('compiled_changes')) for r in rows]),flush=True)
