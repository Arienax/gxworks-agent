"""Verify cross-resource predictions against saved native bytes and allocation hooks."""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[4];sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from probe_minimal_conditional_port_writes import save,streams
from witness_st_conditional_transfers import decode,evaluate
from verify_temporary_check_correspondence import verify
from inspect_cross_origin_st_calls import GROUPS
P=Path(__file__).resolve().parent
GROUP='cross-origin-multi-pou-lifetimes-20260930'


def main():
    out=P/GROUP;plans={p['case']:p for p in json.loads((out/'experiment-plan.json').read_text())['cases']}
    listings={(r['case'],r['resource']):r['records'] for r in json.loads((out/'native-listings.json').read_text())};rows=[]
    for c in json.loads((out/'comparison.json').read_text()):
        d=out/c['case'];n=Path(c['native_directory']);before=json.loads((d/'before-native.json').read_text());source=(d/'input.gxw').read_bytes()
        assert sha256(source)==before['input_sha256']==sha256((n/'input.gxw').read_bytes())
        content=streams(source);assert all(sha256(content[name])==digest for name,digest in before['unchanged_streams'].items())
        h=next(h for h in before['hypotheses'] if h['key']=='program-program-project')
        row=dict(case=c['case'],input_sha256=sha256(source),accepted=bool(c['check'] and not c['check']['rejected']),
            diagnostic_codes=sorted(set(hex(e['code']) for e in c['diagnostics'] if e['kind']==2)),
            matching_hypotheses=[k for k,v in c['matches'].items() if v and all(v)],untouched_logical_payloads=len(before['unchanged_streams']))
        if row['accepted']:
            assert c['reopen']['check'] and not c['reopen']['check']['rejected'] and c['reopen']['identical']
            assert 'program-program-project' in row['matching_hypotheses']
            programs=h['model']['programs'];results=[]
            for i,program in enumerate(programs):
                owner=program['owner'];resource=program['resource'].removesuffix('.res');raw=(n/f'pcode-{i}-0.bin').read_bytes()
                assert raw==(d/f'predicted-program-program-project-{i}.bin').read_bytes()
                records=decode(raw);assert [{k:v for k,v in r.items() if k not in ('raw','offset')} for r in records]==listings[c['case'],resource]
                obs={}
                for name in ('probeR0','probeR1','probeR2'):
                    a=next(a for a in program['declarations'] if a['owner']==owner and a['name']==name)
                    obs[name]=dict(address=a['allocated_family']+str(a['number']),type=a['data_type'])
                witness=evaluate(records,obs);k=plans[c['case']].get('constant',11)+20*i
                assert list(witness['observations'].values())==[k,7,k+11+int(plans[c['case']]['branches'])]
                results.append(dict(owner=owner,resource=resource,pcode_sha256=sha256(raw),native_core_lexical_equal=True,predicted_bytes_equal=True,
                    pointer_labels=[r['text'] for r in records if r['kind']=='label'],observations=obs,witness=witness))
            events=[m['payload'] for line in (n/'events.jsonl').read_text().splitlines() if (m:=json.loads(line)).get('type')=='send']
            actual_alloc=[r for r in events if r.get('event')=='typed-allocation' and r['result']==1]
            predicted_alloc=programs[-1]['declarations'];assert len(actual_alloc)==len(predicted_alloc)
            for a,b in zip(actual_alloc,predicted_alloc,strict=True):assert bytes.fromhex(a['after'])==bytes.fromhex(b['raw'])
            actual_temps=[r for r in events if r.get('event')=='temporary-create']
            observed=sorted((int.from_bytes(bytes.fromhex(r['output'])[8:12],'little'),r['count']*(2 if r['type']==100 else 1),r['type']) for r in actual_temps)
            expected=sorted([(r['number'],r['width'],68) for p in programs for r in p['input_buffers']]+
                [(r['number'],r['width'],100 if r['kind']=='double' else 68) for p in programs for r in p['slots']])
            assert observed==expected
            row.update(resources=results,typed_allocations_equal=len(actual_alloc),physical_temporary_allocations_equal=len(observed),
                input_capture_creates=sum(r['caller']['rva']=='0xca1cf' for r in actual_temps))
        else:assert c['case']=='branches-two-pointers' and 'unsupported' in h and '0x500c9004' in row['diagnostic_codes']
        rows.append(row)
    result=dict(group=GROUP,cases=rows,accepted_projects=sum(r['accepted'] for r in rows),
        accepted_resource_outputs=sum(len(r.get('resources',[])) for r in rows),
        scope='Q03UDV SCPI-derived native copied two-resource project; controlled ST, no PLC execution.',
        findings=['Declarations and instance locals allocate per POU as each POU is compiled; physical reservations persist.',
            'Reusable temporary slots reset between the two observed POUs/resources; input captures remain separate physical reservations.',
            'P jump-label allocation advances across resources. Four static IF expansions need four pointers project-wide; resetting per resource predicts incorrect bytes and incorrect acceptance.',
            'Same names in different program scopes create separate persistent instance locals and capture buffers.'])
    save(out/'multi-pou-analysis.json',result);save(out/'aggregate-check-correspondence.json',verify(GROUPS+[GROUP]))
    (out/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    print(json.dumps(dict(accepted_projects=result['accepted_projects'],accepted_resource_outputs=result['accepted_resource_outputs'],
        results=[dict(case=r['case'],accepted=r['accepted'],matches=r['matching_hypotheses'],allocations=r.get('typed_allocations_equal'),temporaries=r.get('physical_temporary_allocations_equal'),
            labels={x['resource']:x['pointer_labels'] for x in r.get('resources',[])}) for r in rows])))


if __name__=='__main__':main()
