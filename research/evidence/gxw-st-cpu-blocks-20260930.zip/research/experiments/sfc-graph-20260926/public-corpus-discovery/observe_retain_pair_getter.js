// Read-only observation of the actual paired range provider; no injected calls.
const attached = new Set();
function location(p) {const m=Process.findModuleByAddress(p);return m?{module:m.name,rva:p.sub(m.base).toString()}:null;}
Process.attachModuleObserver({onAdded(m) {
 if(m.name.toLowerCase()!=='eccompiler_iec.dll')return;
 if(m.base.add(0x2fd00).readU8()!==0x83)throw new Error('range getter guard');
 Interceptor.attach(m.base.add(0x2fd00),{onEnter(a) {try {
  const provider=this.context.ecx.add(0x71e).readPointer();
  if(provider.isNull())return;
  const target=provider.readPointer().add(0x68).readPointer();
  if(attached.has(target.toString()))return;
  attached.add(target.toString());
  send({event:'retain-pair-provider',target:location(target)});
  Interceptor.attach(target,{onEnter(a) {
   this.row={event:'retain-pair-query',selector:a[0].toInt32(),caller:location(this.returnAddress)};
   this.pointers=[a[1],a[2],a[3],a[4]];
  },onLeave(r) {try {
   this.row.result=r.toInt32();this.row.values=this.pointers.map(p=>p.readS32());send(this.row);
  }catch(e){send({event:'retain-pair-error',error:String(e)});}}});
 }catch(e){send({event:'retain-provider-error',error:String(e)});}}});
}});
