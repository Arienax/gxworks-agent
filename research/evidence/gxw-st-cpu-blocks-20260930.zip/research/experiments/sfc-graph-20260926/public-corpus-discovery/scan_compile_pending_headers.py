"""Count observed source status headers without promoting bytes to semantics."""
from collections import Counter
from pathlib import Path
import json, struct, sys, zipfile
ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project, sha256
from gxw.project_metadata import mark_observed_source_compile_pending, read_project_text_context
P = Path(__file__).resolve().parent
out = P/'compile-pending-header-corpus'; out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
seen = set(); projects = []; groups = Counter(); failures = []


def inspect(raw, origin):
    digest = sha256(raw)
    if digest in seen: return
    seen.add(digest)
    image = inspect_project(raw)
    streams = {s.logical_name:s.raw for s in image.streams if s.logical_name and s.raw is not None}
    context = {}; prj = [v for k,v in streams.items() if k.endswith('.prj')]
    if len(prj)==1:
        try: context = read_project_text_context(prj[0])
        except ValueError as exc: context = dict(diagnostic=str(exc))
    items = []
    for name, payload in streams.items():
        suffix = next((s for s in ('.Program.pou','.Labels.lh','.gh') if name.endswith(s)), None)
        if suffix is None: continue
        marker = struct.unpack_from('<I',payload,50)[0] if len(payload)>=54 else None
        try:
            updated = mark_observed_source_compile_pending(payload,logical_name=name)
            handling = 'matches-observed-header'; reason = None
            assert updated[:50] == payload[:50] and updated[54:] == payload[54:]
        except ValueError as exc: handling = 'unsupported'; reason = str(exc)
        key = (context.get('cpu','unknown'), suffix, payload[:34].hex(), marker, handling)
        groups[key] += 1
        items.append(dict(logical_name=name,payload_sha256=sha256(payload),bytes=len(payload),
            prefix34=payload[:34].hex(),stored_marker=marker,handling=handling,reason=reason))
    projects.append(dict(origin=origin,sha256=digest,context=context,diagnostics=list(image.diagnostics),items=items))
    if image.diagnostics: failures.append(dict(origin=origin,sha256=digest,diagnostics=list(image.diagnostics)))


for archive in sorted((ROOT/'research/evidence').glob('*.zip')):
    with zipfile.ZipFile(archive) as z:
        for member in z.infolist():
            if member.filename.lower().endswith('.gxw'):
                inspect(z.read(member),dict(archive=str(archive.relative_to(ROOT)),member=member.filename))
for path in sorted((P/'noeul-public-corpus').rglob('*.gxw')):
    inspect(path.read_bytes(),dict(path=str(path.relative_to(ROOT))))
summary = dict(unique_project_bytes=len(seen),source_declaration_payloads=sum(groups.values()),
    matched=sum(n for key,n in groups.items() if key[-1]=='matches-observed-header'),
    unsupported=sum(n for key,n in groups.items() if key[-1]=='unsupported'),inventory_failures=len(failures))
rows = [dict(cpu=k[0],suffix=k[1],prefix34=k[2],stored_marker=k[3],handling=k[4],count=n)
        for k,n in sorted(groups.items(),key=lambda row:str(row[0]))]
(out/'comparison.json').write_text(json.dumps(dict(summary=summary,groups=rows,projects=projects,failures=failures,
    scope='Byte-shape coverage only; shared header does not prove native pending semantics for every CPU/project mode. Project hashes deduplicate snapshots, not independent original projects.'),ensure_ascii=True,indent=2))
print(json.dumps(dict(summary=summary,groups=rows)),flush=True)
