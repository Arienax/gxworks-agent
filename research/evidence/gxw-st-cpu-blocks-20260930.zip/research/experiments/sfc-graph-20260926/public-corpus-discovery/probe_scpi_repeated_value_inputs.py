"""Compare copy/alias changes for repeated INT, DINT and STRING FB inputs."""
from pathlib import Path
import base64,json,struct,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from probe_gxw_simple_fb import frame_source,observe_calls
from probe_gxw_parameters import device_allocation_record
from probe_gxw_sfc_graph import patch_raw
from native_gxw_tokens import native_batch,Q_DLL
from replay_gxw_workspace import run
P=Path(__file__).resolve().parent
out=P/'scpi-repeated-value-inputs';out.mkdir(exist_ok=False)
source=(P/'scpi-instance-binding-controls/same-instance/native/native-saved.gxw').read_bytes()
streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
name='MAIN.Program.pou';frame=frame_source(streams[name]);calls=observe_calls(frame)['calls']
specs=[('int','MOV','iUnitNo','K123','D200'),('dint','DMOV','iPrm','K123456','D202'),
       ('string','$MOV','iResStr','"ONE"','D220')]
plans=[];requests=[]
for kind,op,port,literal,device in specs:
 for order in ['literal-first','device-first']:
  rows=[]
  for i,value in enumerate([literal,device] if order=='literal-first' else [device,literal]):
   text=f"LD X{i+1}F\0OUT '_iEn\0LD '_TRUE\0{op} {value} '_{port}"
   if kind!='int':text+=f"\0LD '_TRUE\0MOV K{i+1} '_iUnitNo"
   rows.append(len(requests));requests.append(dict(mode='encode',text=text,input_base64=base64.b64encode(text.encode()+b'\0\0').decode()))
  plans.append(dict(case=kind+'-'+order,requests=rows,port=port))
answers=native_batch(requests,out/'native-encode',dll=Q_DLL,cpu_code=209,native_versions=(25,),device_context=device_allocation_record(streams['Param.wpa']).raw)
for plan in plans:
 directory=out/plan['case'];directory.mkdir();program=frame.raw;replacements=[]
 for call,index in zip(calls,plan['requests']):
  answer=answers[index];assert answer['return_code']=='0x00000000'
  span=call['input_fragment'];replacements.append((span['offset'],span['offset']+span['length'],base64.b64decode(answer['output_base64'])))
 for a,b,replacement in reversed(replacements):program=program[:a]+replacement+program[b:]
 program=bytearray(program);delta=len(program)-len(frame.raw)
 for offset in [55,59]:struct.pack_into('<I',program,offset,struct.unpack_from('<I',frame.raw,offset)[0]+delta)
 assert len(observe_calls(frame_source(bytes(program)))['calls'])==2
 changed,receipt=patch_raw(source,name,frame.raw,bytes(program));path=directory/'changed.gxw';path.write_bytes(changed)
 after={s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}
 assert all(after[k]==v for k,v in streams.items() if k!=name)
 (directory/'mutation.json').write_text(json.dumps(dict(plan,source_sha256=sha256(source),changed_sha256=sha256(changed),receipt=receipt,unrelated_payloads='byte-identical'),indent=2))
 for attempt in range(1,9):
  target=directory/('native' if attempt==1 else 'native-v'+str(attempt))
  result=run(path,target,compile=True,export_project=True,project_alias='SCPIVALUES')
  events=[json.loads(l) for l in (target/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
  if (target/'pcode-0-0.bin').exists() or not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
 row=dict(plan,native_directory=str(target.relative_to(P)),native={k:result[k] for k in ['returncode','compile_completed','compiler_rejected','diagnostics','outputs']})
 (directory/'comparison.json').write_text(json.dumps(row,indent=2));print(json.dumps(dict(case=plan['case'],directory=str(target),native={k:row['native'][k] for k in ['returncode','compile_completed','compiler_rejected','diagnostics']})),flush=True)
