from pathlib import Path
import sys,json,struct
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from gxw.lossless import inspect_project,sha256
from probe_gxw_parameters import frame_parameters
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_compiled_references import inspect
from replay_gxw_workspace import prepare,trace_prepared,run
P=Path(__file__).resolve().parent
specs=json.loads((P/'compiler-iec-import-targets.json').read_text())
sic=next(s for s in specs if s['target_dll']=='DZDataABS_SICConverter_IEC.dll')
data=next(s for s in specs if s['target_dll']=='DZDataABS_DataManager_IEC.dll')
source=(P/'ST-standard-timer-controls/TON_HIGH/changed.gxw').read_bytes()
before={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
name='Param.wpa';raw=before[name];records=[r for r in frame_parameters(raw) if r.tag==0x1000]
assert len(records)==1 and len(records[0].raw)==8
r=records[0];assert struct.unpack_from('<HH',r.raw,4)==(100,1000)
out=P/'timer-parameter-controls/high-150';out.mkdir(parents=True,exist_ok=False)
offset=r.offset+6;modified=raw[:offset]+struct.pack('<H',150)+raw[offset+2:]
changed,receipt=patch_raw(source,name,raw,modified)
after={s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}
assert all(after[k]==v for k,v in before.items() if k!=name)
(out/'changed.gxw').write_bytes(changed)
(out/'mutation.json').write_text(json.dumps(dict(source_sha256=sha256(source),changed_sha256=sha256(changed),stream=name,record_tag=0x1000,offset=offset,before=1000,after=150,unrelated_payloads='byte-identical',receipt=receipt),indent=2))
native=run(out/'changed.gxw',out/'native',compile=True,export_project=True,snapshot_frontend=True)
print(json.dumps(native),flush=True)
comparison=dict(native=native)
if native.get('native_export') and not native.get('compiler_rejected'):
 read=inspect(out/'native',out/'correlation');decoded=read['decoded_fragments']
 comparison['compiled_library_regions']=[dict(names=e['stored_names'],code=[decoded[g['decode_request']].get('records') for g in e['compiled_records']]) for e in read['expansions'] if e['handling'].startswith('compiled-library-region')]
 prepare(out/'changed.gxw',out/'trace',compile=True,export_project=True)
 script=out/'trace/TraceTimerGenerator.js'
 script.write_text('const SIC_IMPORT='+json.dumps(sic)+';const DATA_IMPORT='+json.dumps(data)+';\n'+(P/'TraceTimerGenerator.js').read_text()+'\n'+(ROOT/'research/native/CompilerTrace.js').read_text())
 comparison['trace']=trace_prepared(out/'trace',script,timeout=45)
 messages=[json.loads(l) for l in (out/'trace/events.jsonl').read_text().splitlines()]
 comparison['trace_errors']=[m for m in messages if m.get('type')=='error']
 rows=[m['payload'] for m in messages if m.get('payload',{}).get('event','').startswith('timer-')]
 (out/'trace/timer-generated.json').write_text(json.dumps(rows,indent=2))
 comparison['generated_text']=[r['text'] for r in rows if r['event']=='timer-generated-text']
 comparison['parameter_calls']=[r for r in rows if r['event']=='timer-parameter-input']
 comparison['trace_pcode_exact']=all((out/'trace'/f).read_bytes()==(out/'native'/f).read_bytes() for f in native['outputs'])
 comparison['reopen']=run(out/'native/native-saved.gxw',out/'reopen',compile=True,export_project=True)
 comparison['reopen_pcode_exact']=all((out/'reopen'/f).read_bytes()==(out/'native'/f).read_bytes() for f in native['outputs'])
(out/'comparison.json').write_text(json.dumps(comparison,indent=2))
print(json.dumps({k:v for k,v in comparison.items() if k not in ('native','reopen')}),flush=True)
