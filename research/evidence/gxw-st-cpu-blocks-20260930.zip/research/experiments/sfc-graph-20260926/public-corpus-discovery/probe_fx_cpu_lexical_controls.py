"""Cross-check existing FX lexical controls on both observed adapter CPUs.

This checks spelling and boundaries, not CPU instruction availability. Inputs
come from earlier native outputs; the additional RET token is from a real
source whose full body independently matched the native project compiler.
"""
from pathlib import Path
import base64
import json
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'research')]
from gxw.lossless import sha256
from native_gxw_tokens import native_batch, native_il_projection, canonical_record

P = Path(__file__).resolve().parent
OUT = P / 'fx-cpu-lexical-controls'


def main():
    OUT.mkdir(exist_ok=False)
    (OUT / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    bodies = {}
    for name in ('native-conversion-ladder-mode.json', 'native-operand-corpus-20260920.json'):
        path = ROOT / 'research/results/token-20260919' / name
        for row in json.loads(path.read_text(encoding='utf-8'))['cases']:
            if row.get('body_hex'):
                bodies.setdefault(row['body_hex'], dict(source=str(path.relative_to(ROOT)),
                    source_sha256=sha256(path.read_bytes()), case_id=row.get('id'), text=row.get('text')))
    bodies['056c012405033403'] = dict(source='real FX3U case-00 source offset 1507',
        expected=[dict(kind='instruction', op='RET', args=[]), dict(kind='instruction', op='END', args=[])])
    rows = []
    for body, source in bodies.items():
        rows.append(dict(mode='decode', body_hex=body, provenance=source,
            input_base64=base64.b64encode(bytes.fromhex(body) + b'\0').decode()))
    (OUT / 'predictions.json').write_text(json.dumps(rows, indent=2), encoding='utf-8')
    outputs = {}
    for cpu in (0x208, 0x206):
        outputs[cpu] = native_batch(rows, OUT / f'cpu-{cpu}', cpu_code=cpu)
    differences = []
    accepted = {}
    for cpu, results in outputs.items():
        accepted[str(cpu)] = sum(r['return_code'] == '0x00000000' for r in results)
    for index, (left, right) in enumerate(zip(outputs[0x208], outputs[0x206], strict=True)):
        keys = ('return_code', 'consumed_bytes', 'output_base64')
        if any(left[k] != right[k] for k in keys):
            differences.append(dict(index=index, body_hex=rows[index]['body_hex'], fx3u=left, fx1s=right))
    ret_results = {}
    for cpu in (0x208, 0x206):
        last = outputs[cpu][-1]
        records = native_il_projection(base64.b64decode(last['output_base64']), encoding='cp936')['records']
        assert records == rows[-1]['provenance']['expected']
        encoded = native_batch([dict(mode='encode', text='RET;END',
            input_base64=base64.b64encode(b'RET\0END\0\0').decode())], OUT / f'ret-encode-{cpu}', cpu_code=cpu)[0]
        ret_results[str(cpu)] = dict(decode=last, encode=encoded)
    report = dict(controls=len(rows), accepted=accepted, differences=differences, ret=ret_results,
        scope='Native lexical conversion only; no CPU instruction-availability or project-validity inference')
    (OUT / 'comparison.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(dict(controls=len(rows), accepted=accepted, differences=len(differences), ret=ret_results)))


if __name__ == '__main__':
    main()
