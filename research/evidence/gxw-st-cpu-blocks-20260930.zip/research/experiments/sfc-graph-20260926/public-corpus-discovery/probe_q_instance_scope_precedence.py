"""Determine local/global same-name resolution with independent type controls."""
from pathlib import Path
import base64,json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.declarations import parse_declarations,edit_declarations,serialize_declarations
from gxw.compiler_tables import parse_compiler_tables
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_operand_bindings import resolve_simple_instance_label
from replay_gxw_workspace import run
from native_gxw_tokens import native_batch,native_il_projection,Q_DLL
P=Path(__file__).resolve().parent
out=P/'q-instance-scope-precedence';out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
source=(P/'q-global-fb-calls/valid-global-call/input.gxw').read_bytes()
streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
plans=[('both-fb','SCPI',None),('global-scalar-local-fb','SCPI','INT'),('local-scalar-global-fb','INT',None)]
rows=[];requests=[];files={}
for case,local_type,global_type in plans:
    directory=out/case;directory.mkdir();changed=source;edits=[];expected=dict(streams)
    for logical,datatype in [('MAIN.Labels.lh',local_type),('Global1.gh',global_type)]:
        if datatype is None:continue
        document=parse_declarations(streams[logical],logical_name=logical)
        row=dict(name='GlobalInstance',data_type=datatype,kind='function_block' if datatype=='SCPI' else 'variable')
        if logical.endswith('.gh'):row['class_name']='VAR_GLOBAL'
        new=serialize_declarations(edit_declarations(document,upserts=[row]))
        changed,receipt=patch_raw(changed,logical,streams[logical],new);edits.append(receipt);expected[logical]=new
    assert {s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}==expected
    path=directory/'input.gxw';path.write_bytes(changed)
    (directory/'mutation.json').write_text(json.dumps(dict(source_sha256=sha256(source),changed_sha256=sha256(changed),local_type=local_type,global_type=global_type or 'SCPI',edits=edits,unrelated_payloads='byte-identical'),indent=2),encoding='utf-8')
    for attempt in range(1,9):
        native=directory/('native' if attempt==1 else 'native-v'+str(attempt))
        result=run(path,native,compile=True,snapshot_frontend=True,export_project=True,project_alias='QSCOPESHADOW')
        events=[json.loads(s) for s in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
        if (native/'pcode-0-0.bin').exists() or not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
    row=dict(case=case,native_directory=str(native.relative_to(out)),native={k:result[k] for k in ('returncode','open_succeeded','compile_completed','compiler_rejected','diagnostics')})
    if row['native']['returncode']==0 and row['native']['compile_completed'] and not row['native']['compiler_rejected']:
        tables=parse_compiler_tables((native/'compiler_DZComp/CGTable.dat').read_bytes());row['instances']=[]
        for record in tables.tables[1].records:
            pou=tables.pou_at(record.table_offset)
            for component in tables.components(pou):
                reference=tables.component_instance_pou_offset(component)
                if reference is not None:
                    row['instances'].append(dict(owner=pou.name_bytes.decode('ascii'),instance=component.name_bytes.decode('ascii'),
                        component_offset=component.record.table_offset,pou_offset=reference,
                        ports={n:resolve_simple_instance_label("'"+n,component.record.table_offset,tables,cpu='Q03UDV',encoding='ascii')['operand'] for n in ['iUnitNo','oSendDone']}))
        files[case]={}
        for f in native.glob('pcode-*.bin'):
            raw=f.read_bytes();files[case][f.name]=len(requests);requests.append(dict(mode='decode',input_base64=base64.b64encode(raw+b'\0').decode()))
    rows.append(row);(directory/'comparison.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
    print(json.dumps(row),flush=True)
answers=native_batch(requests,out/'native-pcode-decode',dll=Q_DLL,cpu_code=209)
decoded=[]
for request,answer in zip(requests,answers,strict=True):
    assert answer['return_code']=='0x00000000' and answer['consumed_bytes']==len(base64.b64decode(request['input_base64']))-1
    projection=native_il_projection(base64.b64decode(answer['output_base64']),encoding='cp949');assert not projection['text_gaps'];decoded.append(projection['records'])
(out/'comparison.json').write_text(json.dumps(dict(cases=rows,files=files,decoded=decoded,scope=__doc__),ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(main_pcode={case:decoded[names['pcode-0-0.bin']] for case,names in files.items()})),flush=True)
