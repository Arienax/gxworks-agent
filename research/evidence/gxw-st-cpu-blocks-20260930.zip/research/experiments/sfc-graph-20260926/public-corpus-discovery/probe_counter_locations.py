import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from replay_gxw_workspace import run,prepare,trace_prepared
from gxw.lossless import inspect_project
from gxw.compiler_debug import parse_compiler_debug
from probe_gxw_debug_locations import lookup,search_maps
P=Path(__file__).resolve().parent
for kind in ['CTU','CTD','CTUD']:
 source=P/'ST-standard-counter-controls'/kind/'native/native-saved.gxw'
 out=P/'standard-counter-locations'/kind
 r=run(source,out,compile=True,pcode_location_queries=[dict(resource='MAIN',start_step=i,step_count=1,timestamp=0) for i in range(310)])
 debug=parse_compiler_debug(next(s.raw for s in inspect_project(source.read_bytes()).streams if s.logical_name=='DebugInformation2.dat'))
 rows=json.loads((out/'native-pcode-locations.json').read_text(encoding='utf-8-sig'))
 matches=[dict(query=q['query'],native=q,reader=lookup(debug,'MAIN',q['query']['start_step'],encoding='cp1252')) for q in rows]
 summary=dict(kind=kind,total=len(rows),exact=sum(x['native']['location']==x['reader']['location'] for x in matches),maps=search_maps(debug,encoding='cp1252'),queries=matches)
 (out/'initial-comparison.json').write_text(json.dumps(summary,indent=2))
 print(json.dumps(dict(kind=kind,exact=summary['exact'],sample=[q for q in rows if q['location'] and q['location']['program_kind']==192][:2])),flush=True)
out=P/'standard-counter-traces'/'CTUD'
prepare(P/'ST-standard-counter-controls/CTUD/changed.gxw',out,compile=True,export_project=True)
print(json.dumps(trace_prepared(out,ROOT/'research/native/CompilerTrace.js',timeout=45)),flush=True)
