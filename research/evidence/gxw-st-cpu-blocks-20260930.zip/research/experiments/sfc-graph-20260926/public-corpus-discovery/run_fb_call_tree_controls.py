"""Distinguish actual call sites from native declaration/reference caches."""
import json
from pathlib import Path
import struct
import sys

ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.declarations import parse_declarations,edit_declarations,serialize_declarations
from gxw.compiler_call_tree import parse_compiler_call_tree
from probe_gxw_simple_fb import frame_source,observe_calls
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import run

P=Path(__file__).resolve().parent
OUT=P/'fb-call-tree-controls'
OUT.mkdir(exist_ok=False)
source=(P/'scpi-instance-binding-controls/same-instance/native/native-saved.gxw').read_bytes()
streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
frame=frame_source(streams['MAIN.Program.pou'])
calls=observe_calls(frame)['calls']
for case,keep,remove in [('one_call',1,[]),('zero_calls',0,[]),('one_instance',2,['SCPI_2']),('zero_instances',0,['SCPI_1','SCPI_2'])]:
    directory=OUT/case;directory.mkdir()
    changed=source;receipts=[]
    body=frame.raw
    for call in reversed(calls[keep:]):body=body[:call['offset']]+body[call['offset']+call['length']:]
    body=bytearray(body)
    for off in [55,59]:struct.pack_into('<I',body,off,struct.unpack_from('<I',frame.raw,off)[0]+len(body)-len(frame.raw))
    if bytes(body)!=frame.raw:
        changed,receipt=patch_raw(changed,'MAIN.Program.pou',frame.raw,bytes(body));receipts.append(receipt)
    if remove:
        name='MAIN.Labels.lh'
        labels=serialize_declarations(edit_declarations(parse_declarations(streams[name],logical_name=name),remove=remove))
        changed,receipt=patch_raw(changed,name,streams[name],labels);receipts.append(receipt)
    path=directory/'changed.gxw';path.write_bytes(changed)
    row=dict(case=case,source_sha256=sha256(source),changed_sha256=sha256(changed),keep_calls=keep,removed_declarations=remove,receipts=receipts)
    (directory/'mutation.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
    query=[dict(name='all',keys=[],symbol='',scope='',declared=0,plural=0)]
    native=run(path,directory/'native',compile=True,export_project=True,project_alias='CALLTREECTRL',
               remake_call_tree=True,analysis_queries=query,analysis_version=3)
    row['native']={k:native[k] for k in ['returncode','compile_completed','compiler_rejected','diagnostics','outputs','last_event']}
    cache=directory/'native/compiler_DZComp/CallTree.dat'
    if cache.exists():
        tree=parse_compiler_call_tree(cache.read_bytes())
        row['tree']=dict(sha256=sha256(tree.raw),main=[dict(key=n.ascii_key,refs=[r.ascii_key for r in n.references]) for n in tree.maps[1] if n.kind_code==23 and n.names[2].ascii_key=='MAIN'],resource_raw_hex=tree.resource_tree.hex() if tree.resource_tree else None)
    refs=directory/'native/native-program-analysis.json'
    if refs.exists():
        from collections import Counter
        data=json.loads(refs.read_text(encoding='utf-8-sig'))['queries'][0]['rows']
        row['references']=dict(count=len(data),instances=dict(Counter(r['instance'] for r in data)))
    (directory/'comparison.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in row.items() if k!='receipts'}),flush=True)
