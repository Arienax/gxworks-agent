(()=>{
'use strict';
const active=new Map();let seq=0;
function str(p,bound){try{let s='';for(let i=0;i<bound;i++){const c=p.add(i).readU8();if(c===0)return s;if(c>127)return null;s+=String.fromCharCode(c);}}catch(e){}return null;}
function hex(p,n){return Array.from(new Uint8Array(p.readByteArray(n)),v=>v.toString(16).padStart(2,'0')).join('');}
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='eccompiler_iec.dll')return;
 Interceptor.attach(m.findExportByName('Compile'),{onEnter(a){
  this.prior=active.get(this.threadId);const names=[];const n=a[1].toInt32();if(n>=0&&n<=1024)for(let i=0;i<n;i++)names.push(str(a[2].add(i*28+8).readPointer(),512));
  active.set(this.threadId,names.includes('POU_01'));
 },onLeave(){active.set(this.threadId,this.prior);}});
 Interceptor.attach(m.base.add(0x13d80),{onEnter(a){
  this.keep=!!active.get(this.threadId);if(!this.keep)return;
  this.id=++seq;this.position=a[0];this.record=a[1];this.before=this.position.readS32();this.caller=this.returnAddress.sub(m.base).toString();
  this.stack=Thread.backtrace(this.context,Backtracer.ACCURATE).slice(0,8).map(p=>{const mod=Process.findModuleByAddress(p);return mod?mod.name+'+'+p.sub(mod.base):p.toString();});
 },onLeave(r){if(!this.keep)return;send({event:'template-constant-read',sequence:this.id,requested:this.before,next:this.position.readS32(),result:r.toInt32(),caller_rva:this.caller,stack:this.stack,kind:this.record.add(8).readU32(),spelling:str(this.record.readPointer(),65536),value_hex:hex(this.record.add(12),12)});}});
}});
})();
