// Native type resolver and rejection branches; observation only.
let installed=false,base=null;
function bytes(p,n){try{return Array.from(new Uint8Array(p.readByteArray(n)),x=>x.toString(16).padStart(2,'0')).join('');}catch(_){return null;}}
function str(p){try{let s='';for(let i=0;i<1024;i++){const n=p.add(i).readU8();if(!n)return s;if(n>127)return null;s+=String.fromCharCode(n);}}catch(_){}return null;}
function u32(p){try{return p.readU32();}catch(_){return null;}}
function capture(c){const regs={};for(const k of ['eax','ebx','ecx','edx','esi','edi','ebp','esp'])regs[k]=c[k].toString();return {registers:regs,frame_minus_0x200:bytes(c.ebp.sub(0x200),0x200)};}
function install(phase){
 if(installed)return;
 const compiler=Process.findModuleByName('DZDataABS_Compiler_IEC.dll');if(!compiler)return;
 const target=compiler.base.add(65808).readPointer();base=target.sub(6444);
 if(bytes(target,16)!=='568bf18b4c240885c97507b801000150')return;
 installed=true;
 Interceptor.attach(base.add(0x9afe2),{onEnter(a){this.input=str(a[0]);this.caller=this.returnAddress.sub(base).toString();this.out=[a[1],a[2],a[3],a[4]];},onLeave(ret){let name=null;try{name=str(this.out[2].readPointer());}catch(_){}send({event:'resolved-declaration-type',input:this.input,caller:this.caller,result:ret.toInt32(),type:u32(this.out[0]),parameter:u32(this.out[1]),reference:name,error:u32(this.out[3])});}});
 send({event:'installed-via-resolved-import',phase,base:base.toString()});
}
send({event:'ready',pid:Process.id});
Process.attachModuleObserver({onAdded(m){const n=m.name.toLowerCase();let t=null;if(n==='dzdataabs_compiler_iec.dll')t=m.findExportByName('DllGetClassObject');if(n==='dzdataabs_compileradapter.dll')t=m.base.add(0x13cc0);if(n==='eccompiler_iec.dll')t=m.findExportByName('ObjectNew');if(t)Interceptor.attach(t,{onEnter(){install(n);}});}});
