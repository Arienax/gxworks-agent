"""Probe all existing Noeul native baselines without executing a vendor DLL."""
from pathlib import Path
import contextlib
import io
import json
import re

P=Path(__file__).resolve().parent
OUT=P/'q-real-corpus-portable-v4'

def main():
    OUT.mkdir(exist_ok=False)
    path=P/'reconstruct_q_source_allocated_real_multi.py'
    code=path.read_text(encoding='utf-8')
    start=code.index('plans=[]')
    end=code.index('\ndef scalar(',start)
    plans=r"""plans=[]
inventory=[]
for folder in sorted((P/'noeul-native-batch').glob('case-*')):
 if not (folder/'input.gxw').exists():continue
 source=(folder/'input.gxw').read_bytes();graph=inspect_task_graph(source)
 inventory.append(dict(case=folder.name,resources=len(graph['resources']),gaps=graph['gaps']))
 previous=[]
 # Candidate byte ordering; independently checked against complete native outputs.
 # These projects use cp949. This does not establish arbitrary-locale collation.
 for resource_index,resource in enumerate(sorted(graph['resources'],key=lambda r:r['resource'].encode('cp949'))):
  task=graph['tasks'][resource['task']]
  if len(task['entries'])!=1:raise ValueError('multiple programs per task are not reconstructed by this runner')
  entry=task['entries'][0]
  plans.append(dict(case=folder.name+'-'+str(resource_index),source=str(folder/'input.gxw'),baseline_directory=str(folder),root_name=entry['program_reference'],program_stream=entry['source_program'],prior_names=list(previous),resource_index=resource_index))
  previous.append(entry['program_reference'])
(OUT/'inventory.json').write_text(json.dumps(inventory,indent=2),encoding='utf-8')
"""
    code=code[:start]+plans+code[end:]
    start=code.index(" protocol=''.join(");end=code.index(" output=b''.join(parts)",start)
    code=code[:start]+" from source_q_width import rewrite\n for req in requests:parts[req['index']]=rewrite(bytes.fromhex(req['raw']))\n"+code[end:]
    code,n=re.subn(r"OUT=P/'[^']+';OUT.mkdir\(exist_ok=False\)",lambda _:f'OUT=Path({OUT.as_posix()!r})',code,count=1)
    assert n==1 and 'subprocess.run' not in code
    code=code.replace('Public native Q instruction-width check still used.','Python-only Q71 widths; no native code executed during prediction. Unbound raw instructions retained.')
    start=code.index(' def simple_label(label):');end=code.index(' def emit(',start)
    code=code[:start]+" from source_q_label_binding import binder\n simple_label=binder(streams,tables,predicted['allocations'],root,context['text_encoding'])\n"+code[end:]
    identity_source=(P/'reconstruct_q_source_allocated_order.py').read_text(encoding='utf-8')
    identities=identity_source[identity_source.index(' def identities(table):'):identity_source.index(' row=dict(')]
    start=code.index(' allocation_exact=[');end=code.index(' row=dict(',start)
    code=code[:start]+identities+code[end:]
    before_native=" baseline=Path(plan['baseline_directory']);native="
    assert before_native in code
    code=code.replace(before_native," baseline=Path(plan['baseline_directory'])\n native_outcome=json.loads((baseline/'outcome.json').read_text(encoding='utf-8'))\n if native_outcome['compiler_rejected']:\n  row=dict(case=plan['case'],handling='not-checkable-native-rejected',candidate_sha256=sha256(output),diagnostics=native_outcome['diagnostics']);results.append(row);(directory/'comparison.json').write_text(json.dumps(row,indent=2));(OUT/'comparison.json').write_text(json.dumps(results,indent=2));continue\n native=")
    # Continue after mismatches: the failure set is the purpose of this run.
    code=code.replace(" if not row['byte_identical'] or not all(allocation_exact):raise ValueError('prediction disagrees; preserve counterexample')",'')
    start=code.index('for plan in plans:\n')+len('for plan in plans:\n')
    code=code[:start]+" try:\n"+'\n'.join(' '+line for line in code[start:].splitlines())+"\n except Exception as exc:\n  import traceback\n  row=dict(case=plan['case'],error=type(exc).__name__+': '+str(exc),traceback=traceback.format_exc());results.append(row);(OUT/'comparison.json').write_text(json.dumps(results,indent=2));print(json.dumps(row),flush=True)\n"
    (OUT/'runner.py').write_text(code,encoding='utf-8')
    for name in ['source_q_width.py','source_q_allocation.py','source_q_label_binding.py','q-width-static-tables.json']:
        (OUT/name).write_bytes((P/name).read_bytes())
    captured=io.StringIO()
    with contextlib.redirect_stdout(captured):exec(compile(code,str(OUT/'runner.py'),'exec'),dict(__file__=str(path),__name__='__main__'))
    (OUT/'run.jsonl').write_text(captured.getvalue(),encoding='utf-8')
    rows=json.loads((OUT/'comparison.json').read_text(encoding='utf-8'))
    print(json.dumps(dict(programs=len(rows),exact=sum(r.get('byte_identical',False) for r in rows),gaps=[r for r in rows if not r.get('byte_identical') or r.get('allocations')!=r.get('allocations_exact')],records=sum(r.get('records',0) for r in rows))))

if __name__=='__main__':main()
