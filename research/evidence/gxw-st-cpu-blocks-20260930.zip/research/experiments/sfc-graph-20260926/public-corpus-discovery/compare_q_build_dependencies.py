"""Cross-check declaration membership against freshly built compiler tables."""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from probe_gxw_build_dependencies import inspect_build_dependencies
from gxw.compiler_tables import parse_compiler_tables
from gxw.lossless import sha256
P=Path(__file__).resolve().parent
out=P/'q-build-dependency-comparison-v2';out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
for name in ['probe_gxw_build_dependencies.py','probe_gxw_task_graph.py','probe_gxw_simple_fb.py']:
    (out/name).write_bytes((ROOT/'research'/name).read_bytes())
rows=[]
def check(source_path,native,identity):
    source=source_path.read_bytes();result=inspect_build_dependencies(source)
    table_path=native/'compiler_DZComp/CGTable.dat'
    if not table_path.exists():
        rows.append(dict(identity=identity,source_sha256=sha256(source),status='native compiler table not captured'));return
    raw=table_path.read_bytes();tables=parse_compiler_tables(raw)
    native_names=[tables.pou_at(r.table_offset).name_bytes.decode('cp949') for r in tables.tables[1].records]
    native_users=sorted(set(native_names)&set(result['program_identities']))
    expected=result['declaration_reachability']['programs']
    index=len(rows)
    (out/f'graph-{index:02d}.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    exact=native_users==expected
    rows.append(dict(identity=identity,source_sha256=sha256(source),compiler_table_sha256=sha256(raw),
        native_user_definitions=native_users,expected_declaration_definitions=expected,
        observed_body_candidates=result['observed_body_reachability']['programs'],membership_exact=exact,
        unresolved_active_types=len(result['declaration_reachability']['unresolved'])))
    assert exact
for experiment in ['q-compile-root-validation','q-fb-compile-dependencies','q-declaration-compile-dependencies','q-global-compile-dependencies','q-global-fb-calls']:
    corpus=json.loads((P/experiment/'comparison.json').read_text(encoding='utf-8'))
    for case in corpus['cases']:
        if case['native']['returncode']!=0 or not case['native']['compile_completed'] or case['native']['compiler_rejected']:continue
        check(P/experiment/case['case']/'input.gxw',P/experiment/case['native_directory'],experiment+'/'+case['case'])
reference=json.loads((P/'q-task-reference-corpus-v2/comparison.json').read_text(encoding='utf-8'))
for case in reference['projects']:
    native=case['native_task_inventory']
    if native is None or not native['complete']:continue
    check(P/case['file'],P/native['directory'],case['file'])
summary=dict(cases=len(rows),checked=sum('membership_exact' in r for r in rows),exact=sum(r.get('membership_exact') is True for r in rows),
    user_programs=sum(len(r.get('native_user_definitions',[])) for r in rows),
    body_and_declaration_sets_differ=sum(r.get('expected_declaration_definitions')!=r.get('observed_body_candidates') for r in rows if 'membership_exact' in r))
(out/'comparison.json').write_text(json.dumps(dict(summary=summary,cases=rows,scope=__doc__),ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary))
