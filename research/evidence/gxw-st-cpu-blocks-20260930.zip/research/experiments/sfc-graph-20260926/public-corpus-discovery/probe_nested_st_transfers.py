"""Observe two-level local FB transfers with outer indexed formals held live.

Predictions are source-only hypotheses saved before native use. The original
BoxID-derived project remains local; only six selected logical payloads change.
"""
from pathlib import Path
from dataclasses import replace
import base64,json,sys
ROOT=Path(__file__).resolve().parents[4];sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from gxw.declarations import parse_declarations,edit_declarations,serialize_declarations
from gxw.project_metadata import mark_observed_source_compile_pending
from probe_gxw_st_sources import replace_observed_st
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_program_check_resources import SCRIPT
from probe_minimal_conditional_port_writes import streams,observe,save
from native_gxw_tokens import native_batch,Q_DLL,native_il_records
from source_q_st_calls import predict
P=Path(__file__).resolve().parent


def formals(raw,logical,*,keep_inner=False,scope=5,data_type='INT'):
    doc=parse_declarations(raw,logical_name=logical)
    keep={'number','in_out_character'}|({'Inner'} if keep_inner else set())
    doc=edit_declarations(doc,remove=[r.name for r in doc.rows if r.name not in keep],
        renames={'number':'result','in_out_character':'value'},upserts=[dict(name=n,data_type=data_type) for n in ('result','value')])
    value=next(r for r in doc.rows if r.name=='value')
    idx=replace(value,name='idx',record_id=max(r.record_id for r in doc.rows)+1)
    doc=replace(doc,rows=tuple(replace(r,class_code=scope) if r.name=='value' else r for r in doc.rows)+(idx,))
    doc=edit_declarations(doc,upserts=[dict(name='idx',data_type='INT')])
    return doc


def main():
    config=json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
    out=P/config['directory'];out.mkdir(exist_ok=False);save(out/'experiment-plan.json',config)
    for name in (Path(__file__).name,'source_q_st_calls.py','source_q_direct_declarations.py','source_q_st_expressions.py','source_q_label_binding.py','source_q_width.py','observe_expression_temporaries.js','observe_index_register_lifetime.js'):
        (out/name).write_bytes((P/name).read_bytes())
    trace=out/'trace.js';trace.write_text('(()=>{'+(P/'native-allocation-bitmap-v2/observer.js').read_text()+'\n'+(P/'observe_expression_temporaries.js').read_text()+'\n'+(P/'observe_index_register_lifetime.js').read_text()+'\n})();\n(()=>{'+SCRIPT+'\n})();',encoding='utf-8')
    original=(P/'ST-nested-FB-controls/single/native/native-saved.gxw').read_bytes();before=streams(original)
    ready=[]
    for plan in config['cases']:
        case=plan['case'];d=out/case;d.mkdir();changes={}
        outer_type=plan.get('outer_type','INT');inner_type=plan.get('inner_type','INT')
        rootname='POU_01.Labels.lh';root=parse_declarations(before[rootname],logical_name=rootname)
        root=edit_declarations(root,upserts=[dict(name='probeArray',data_type='ARRAY[0..3] OF '+outer_type),dict(name='probeIndex',data_type='INT')]+
            [dict(name=n,data_type=outer_type)for n in ('probeResult','probeR0','probeR1','probeR2')])
        for instance_name in plan.get('root_instances',[]):
            original_instance=next(r for r in root.rows if r.name=='Keypad_1')
            root=replace(root,rows=root.rows+(replace(original_instance,name=instance_name,record_id=max(r.record_id for r in root.rows)+1),))
        wrapper=formals(before['Wrapper.Labels.lh'],'Wrapper.Labels.lh',keep_inner=True,scope=plan['outer_class'],data_type=outer_type)
        wrapper=edit_declarations(wrapper,upserts=[dict(name='localArray',data_type='ARRAY[0..3] OF '+inner_type),dict(name='innerResult',data_type=inner_type)])
        wrapper=replace(wrapper,rows=tuple(replace(r,class_code=plan.get('wrapper_classes',{}).get(r.name,r.class_code),
            record_id=plan.get('wrapper_record_ids',{}).get(r.name,r.record_id),
            initial_value=plan.get('wrapper_initial_values',{}).get(r.name,r.initial_value)) for r in wrapper.rows))
        assert len({r.record_id for r in wrapper.rows})==len(wrapper.rows)
        inner=formals(before['Keypad.Labels.lh'],'Keypad.Labels.lh',scope=plan.get('inner_class',5),data_type=inner_type)
        for name,doc in [(rootname,root),('Wrapper.Labels.lh',wrapper),('Keypad.Labels.lh',inner)]:
            changes[name]=mark_observed_source_compile_pending(serialize_declarations(doc),logical_name=name)
        initial='probeArray[0] := 11;\nprobeArray[1] := 22;\nprobeIndex := 0;\n'
        main=initial+'IF probeIndex > -1 THEN\nKeypad_1(value := probeArray[probeIndex], idx := probeIndex, result := probeResult);\nEND_IF;\nprobeR0 := probeArray[0];\nprobeR1 := probeArray[1];\nprobeR2 := probeResult;\n'
        change='value := value + 10;' if plan['outer_class']==5 else 'value := 77;'
        body=change+'\nlocalArray[0] := 100;\nlocalArray[1] := 200;\nInner(value := '+plan['inner_actual']+', idx := idx, result := innerResult);\nresult := value + innerResult;\n'
        inner_body='value := value + 7;\nidx := idx + 1;\nresult := value;\n'
        texts={'POU_01':plan.get('root_source',main),'Wrapper':plan.get('wrapper_source',body),'Keypad':plan.get('inner_source',inner_body)}
        for owner,text in texts.items():
            name=owner+'.Program.pou';raw,_=replace_observed_st(before[name],text.replace('\n','\r\n'))
            changes[name]=mark_observed_source_compile_pending(raw,logical_name=name)
        source=original;receipts=[]
        for name,raw in changes.items():source,receipt=patch_raw(source,name,before[name],raw);receipts.append(receipt)
        assert streams(source)==dict(before,**changes)
        path=d/'input.gxw';path.write_bytes(source)
        try:
            prediction=predict(source,definitions=('Wrapper','Keypad'),max_call_depth=2,allow_inputs=config.get('allow_inputs',False),allow_omitted=config.get('allow_omitted',False),allow_members=config.get('allow_members',False))
            code=prediction.pop('output');(d/'predicted-0.bin').write_bytes(code)
        except ValueError as exc:
            if not config.get('allow_unsupported_discovery'):raise
            prediction=dict(handling='unsupported-before-native',reason=str(exc));code=None
        save(d/'before-native.json',dict(input_sha256=sha256(source),texts=texts,prediction=prediction,receipts=receipts,
            changed_streams=list(changes),unchanged_streams={k:sha256(v)for k,v in before.items() if k not in changes},
            hypothesis=plan.get('hypothesis','All nested FB bodies share the current program temporary manager. Live outer IN_OUT copies cannot be reused by an inner call. Forwarded scalar formals preserve their actual aliases without new transfer phases.')))
        ready.append((case,d,path,code))
    rows=[];requests=[];keys=[]
    for case,d,path,predicted in ready:
        n,r,proc=observe(path,d,trace)
        messages=[json.loads(l) for l in (n/'events.jsonl').read_text().splitlines()]
        events=[m['payload']for m in messages if m.get('type')=='send']
        errors=[m for m in messages if m.get('type')=='error']+[e for e in events if 'error' in e.get('event','') or e.get('observation_error')]
        row=dict(case=case,native_directory=str(n),check=r['check'],backend_rejected=r['backend_check_rejected'],diagnostics=r['diagnostics'],backend_diagnostics=r['backend_check_diagnostics'],
            prediction_identical=None if predicted is None else predicted==(n/'pcode-0-0.bin').read_bytes(),trace_errors=errors,process=proc)
        for g in r['generated']:
            code=(n/f'pcode-{g["index"]}-0.bin').read_bytes()
            if code:requests.append(dict(mode='decode',input_base64=base64.b64encode(code+b'\0').decode()));keys.append((case,g['name'],g['index']))
        if r['exported_sha256']:
            rd=d/'reopen';rd.mkdir();rn,rr,rp=observe(n/'native-saved.gxw',rd,trace)
            row['reopen']=dict(native_directory=str(rn),check=rr['check'],diagnostics=rr['diagnostics'],identical=all((n/f'pcode-{g["index"]}-0.bin').read_bytes()==(rn/f'pcode-{g["index"]}-0.bin').read_bytes() for g in r['generated']))
        rows.append(row);save(out/'comparison.json',rows)
        print(json.dumps(dict(case=case,check=row['check'],prediction_identical=row['prediction_identical'],errors=errors,diagnostics=sorted(set(hex(e['code'])for e in row['diagnostics'] if e['kind']==2)),reopen_identical=row.get('reopen',{}).get('identical'),reopen_check=row.get('reopen',{}).get('check'))),flush=True)
        assert not errors
    answers=native_batch(requests,out/'native-decode',dll=Q_DLL,cpu_code=209,native_versions=(25,))
    listings=[]
    for key,req,a in zip(keys,requests,answers,strict=True):
        assert a['return_code']=='0x00000000' and a['consumed_bytes']==len(base64.b64decode(req['input_base64']))-1
        listings.append(dict(case=key[0],resource=key[1],index=key[2],records=native_il_records(base64.b64decode(a['output_base64']),encoding='cp932')))
    save(out/'native-listings.json',listings)


if __name__=='__main__':main()
