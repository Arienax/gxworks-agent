"""Trace incomplete fresh checks; no suppression or result overrides."""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from probe_minimal_conditional_port_writes import observe,save
from probe_gxw_program_check_resources import SCRIPT
P=Path(__file__).resolve().parent


def main():
    out=P/(sys.argv[1] if len(sys.argv)>1 else 'q-fresh-check-failure-chain-20260930');out.mkdir(exist_ok=False)
    (out/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    trace=out/'trace.js';trace.write_text('(()=>{'+(P/'observe_q_check_failures.js').read_text()+'\n})();\n(()=>{'+SCRIPT+'\n})();',encoding='utf-8')
    plans=[('original-noeul',P/'native-allocation-inventory/case-10/input.gxw'),
        ('st-25-moves',P/'st-temporary-capacity-rung-controls-20260930/plain-25-moves/input.gxw'),
        ('st-24-moves',P/'st-temporary-capacity-rung-controls-20260930/plain-24-moves/input.gxw')]
    save(out/'before-native.json',[dict(case=c,input=str(p),sha256=sha256(p.read_bytes()))for c,p in plans]);rows=[]
    for case,path in plans:
        d=out/case;d.mkdir();n,r,process=observe(path,d,trace)
        messages=[json.loads(l)for l in (n/'events.jsonl').read_text().splitlines()]
        events=[m['payload']for m in messages if m.get('type')=='send']
        own=[e for e in events if 'trace_sequence' in e]
        row=dict(case=case,native_directory=str(n),check=r['check'],last_event=r['last_event'],diagnostics=r['diagnostics'],process=process,
            errors=[m for m in messages if m.get('type')=='error']+[e for e in own if e.get('event')=='observation-error'],events=own)
        rows.append(row);save(out/'comparison.json',rows)
        compact=[{k:v for k,v in e.items() if k!='input_hex'}for e in own if e['event'] not in ('q-pcode-to-ladder','progress-result') or e.get('result',e.get('hresult',0))!=0]
        print(json.dumps(dict(case=case,check=r['check'],last_event=r['last_event'],events=compact)),flush=True)


if __name__=='__main__':main()
