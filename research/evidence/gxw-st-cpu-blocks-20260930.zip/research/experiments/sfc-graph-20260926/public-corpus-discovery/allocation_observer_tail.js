// Appended to the lean Compile observer. Function boundaries only.
const allocationContexts=new Map(),poolContexts=new Map();let nextAllocation=0,nextPool=0;
function bitmap(p){if(p.isNull())return null;const n=p.readU32();if(n>0x200000||n%8)throw new Error('bitmap capacity bound');return {address:p.toString(),capacity:n,raw:hex(p.add(4),n/8)};}
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='eccompiler_iec.dll')return;
 try{
  if(hex(m.base.add(0x52e70),3)!=='568bf1'||hex(m.base.add(0x324d0),4)!=='8b442410')throw new Error('allocation function guards');
  Interceptor.attach(m.base.add(0x52e70),{onEnter(a){const c=contexts.get(this.threadId);if(!c)return;
   this.prior=allocationContexts.get(this.threadId);this.row={event:'typed-allocation',compile_id:c.compile_id,allocation_id:++nextAllocation,type:a[0].toInt32(),arg2:a[2].toInt32(),category:a[3].toInt32(),caller:loc(this.returnAddress),sizes:[],pools:[]};allocationContexts.set(this.threadId,this.row);
   try{this.out=a[4];this.row.before=hex(this.out,26);this.row.type_parameter=a[1].isNull()?null:hex(a[1],12);
    if(this.row.type===0x33&&!a[1].isNull()){const p=a[1].readPointer();this.row.array_header=p.isNull()?null:hex(p,12);}
   }catch(e){this.row.observation_error=String(e);}
  },onLeave(r){if(!this.row)return;this.row.result=r.toInt32();try{this.row.after=hex(this.out,26);}catch(e){this.row.observation_error=String(e);}emit(this.row);allocationContexts.set(this.threadId,this.prior);}});
  Interceptor.attach(m.base.add(0x519f0),{onEnter(a){const d=allocationContexts.get(this.threadId);if(!d)return;this.parent=d;this.row={type:a[0].toInt32(),parameter:a[1].toInt32()};},onLeave(r){if(this.row){this.row.bytes=r.toInt32();this.parent.sizes.push(this.row);}}});
  for(const [rva,kind] of [[0x47180,'word'],[0x474a0,'bit']])Interceptor.attach(m.base.add(rva),{onEnter(a){const c=contexts.get(this.threadId);if(!c)return;
   this.prior=poolContexts.get(this.threadId);const d=allocationContexts.get(this.threadId);this.row={event:'pool-allocation',pool_id:++nextPool,allocation_id:d?d.allocation_id:null,compile_id:c.compile_id,kind,count:a[0].toInt32(),selector:a[2].toInt32(),caller:loc(this.returnAddress),searches:[],marks:[],descriptors:[]};poolContexts.set(this.threadId,this.row);if(d)d.pools.push(this.row.pool_id);
   try{this.out=a[1];this.row.before=hex(this.out,26);const base=this.context.ecx;for(let i=0;i<=34;i++){const p=base.add(0xe+i*22);this.row.descriptors.push({index:i,raw:hex(p,22),code:p.readU8(),end:p.add(4).readS32(),limit:p.add(8).readU32(),bitmap:p.add(16).readPointer().toString()});}}
   catch(e){this.row.observation_error=String(e);}
  },onLeave(r){if(!this.row)return;this.row.result=r.toInt32();try{this.row.after=hex(this.out,26);}catch(e){this.row.observation_error=String(e);}emit(this.row);poolContexts.set(this.threadId,this.prior);}});
  Interceptor.attach(m.base.add(0x324d0),{onEnter(a){const p=poolContexts.get(this.threadId);if(!p)return;this.parent=p;this.row={count:a[1].toUInt32(),limit:a[2].toUInt32(),start:a[3].toUInt32()};try{this.ptr=a[0];this.row.before=bitmap(this.ptr);}catch(e){this.row.observation_error=String(e);}},onLeave(r){if(!this.row)return;this.row.result=r.toInt32();try{this.row.after=bitmap(this.ptr);}catch(e){this.row.observation_error=String(e);}this.parent.searches.push(this.row);}});
  Interceptor.attach(m.base.add(0x32420),{onEnter(a){const p=poolContexts.get(this.threadId);if(!p)return;this.parent=p;this.row={start:a[1].toUInt32(),count:a[2].toUInt32()};try{this.ptr=a[0];this.row.before=bitmap(this.ptr);}catch(e){this.row.observation_error=String(e);}},onLeave(r){if(!this.row)return;try{this.row.after=bitmap(this.ptr);}catch(e){this.row.observation_error=String(e);}this.parent.marks.push(this.row);}});
 }catch(e){emit({event:'allocation-guard-error',error:String(e)});}
}});
