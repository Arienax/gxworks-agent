"""Grow real ST source/declarations with an independent native xref check."""
from collections import Counter
import json
from pathlib import Path
import re
import sys

ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.declarations import parse_declarations,edit_declarations,serialize_declarations
from gxw.lossless import inspect_project,sha256
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_st_sources import replace_observed_st
from probe_gxw_native_references import inspect as capture

P=Path(__file__).resolve().parent
OUT=P/'boxid-real-st-global-rename'
OUT.mkdir(exist_ok=False)
original=(P/'samples/boxid.gxw').read_bytes()
streams={s.logical_name:s.raw for s in inspect_project(original).streams if s.logical_name}
documents={n:parse_declarations(raw,logical_name=n) for n,raw in streams.items() if n.endswith('.gh')}
names=[r.name for d in documents.values() for r in d.rows]
assert len(set(n.casefold() for n in names))==len(names)
renames={name:'RealSTGlobalLabel_'+str(i).zfill(3)+'_Preserved' for i,name in enumerate(names)}
folded={a.casefold():b for a,b in renames.items()}
updates={name:serialize_declarations(edit_declarations(doc,renames={r.name:renames[r.name] for r in doc.rows})) for name,doc in documents.items()}
changes=[]
for name,raw in streams.items():
    if not name.endswith('.Program.pou'):continue
    _,text=replace_observed_st(raw,'')
    # This real source has ordinary quoted strings and nonnested comments.
    # Native xrefs are the independent check, not this bounded token scan.
    assert not re.search(r"\(\*(?:(?!\*\)).)*\(\*",text,re.S)
    tokens=re.compile(r"\(\*.*?\*\)|'[^']*'|\"[^\"]*\"|[^\W\d]\w*",re.S)
    changed=[]
    def replace(match):
        token=match[0]
        replacement=folded.get(token.casefold())
        if replacement:
            changed.append(dict(start=match.start(),end=match.end(),before=token,after=replacement))
            return replacement
        return token
    new_text=tokens.sub(replace,text)
    if new_text!=text:
        new,_=replace_observed_st(raw,new_text)
        updates[name]=new
        changes.append(dict(object=name,before_bytes=len(raw),after_bytes=len(new),tokens=changed))
result=original
receipts=[]
for name,raw in updates.items():
    result,receipt=patch_raw(result,name,streams[name],raw)
    receipts.append(dict(object=name,receipt=receipt))
after={s.logical_name:s.raw for s in inspect_project(result).streams if s.logical_name}
assert after==dict(streams,**updates)
(OUT/'renamed.gxw').write_bytes(result)
(OUT/'mutation.json').write_text(json.dumps(dict(source_sha256=sha256(original),result_sha256=sha256(result),
    renames=renames,source_changes=changes,receipts=receipts,unrelated_logical_payloads='byte-identical'),ensure_ascii=False,indent=2),encoding='utf-8')
native=capture(OUT/'renamed.gxw',OUT/'native-check')
print(json.dumps(dict(phase='compile',handling=native['handling'],native=native['native'])),flush=True)
if native['handling']=='native-query-completed':
    reopened=capture(OUT/'native-check/native/native-saved.gxw',OUT/'reopen-check')
    baseline=json.loads((P/'native-reference-real-corpus/case-00/references.json').read_text(encoding='utf-8'))
    def normalize(rows,reverse):
        out=[]
        for row in rows:
            data={k:v for k,v in row.items() if k!='raw_base64'}
            if reverse:data['name']=next((old for old,new in renames.items() if new==data['name']),data['name'])
            out.append(json.dumps(data,sort_keys=True))
        return Counter(out)
    before=normalize(baseline['queries'][0]['rows'],False)
    changed=normalize(native['queries'][0]['rows'],True)
    again=normalize(reopened['queries'][0]['rows'],True)
    summary=dict(renamed_globals=len(renames),source_tokens_changed=sum(len(c['tokens']) for c in changes),
        source_lengths=[dict(object=c['object'],before=c['before_bytes'],after=c['after_bytes']) for c in changes],
        compiled_equal=native['native']['outputs']==baseline['native']['outputs'],
        compiled_equal_after_reopen=native['native']['outputs']==reopened['native']['outputs'],
        reference_rows=sum(before.values()),native_references_equal=before==changed,native_references_equal_after_reopen=before==again,
        differences=dict(missing=list((before-changed).items()),added=list((changed-before).items())),
        reopen_handling=reopened['handling'])
    (OUT/'semantic-comparison.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(summary),flush=True)
