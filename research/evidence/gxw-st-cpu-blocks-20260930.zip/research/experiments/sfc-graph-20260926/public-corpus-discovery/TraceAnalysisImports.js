"use strict";
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=="dzdataabs_compileradapter.dll")return;
 Interceptor.attach(m.base.add(0x8d35),{onEnter(args){this.obj=this.context.ecx;},onLeave(ret){
 try{const obj=this.obj.add(0x14).readPointer(),vt=obj.readPointer();
 const slots=[0xb8,0xbc,0xf0,0x10c].map(s=>{const a=vt.add(s).readPointer(),owner=Process.findModuleByAddress(a);return {slot:s,address:a.toString(),module:owner?owner.name:null,rva:owner?a.sub(owner.base).toString():null,path:owner?owner.path:null};});
 send({event:"analysis-backend",result:ret.toInt32(),slots});
 const c=Process.getModuleByName("DZDataABS_Compiler.dll");
 const imports=[0x10030,0x1014c,0x10004].map(r=>{const a=c.base.add(r).readPointer(),owner=Process.findModuleByAddress(a);return {rva:r,target:a.toString(),module:owner?owner.name:null,range:Process.findRangeByAddress(a),bytes:Array.from(new Uint8Array(a.readByteArray(32)))};});
 send({event:"analysis-import-targets",imports,wrapper:Array.from(new Uint8Array(c.base.add(0x5a87).readByteArray(32)))});
 }catch(e){send({event:"analysis-backend-error",error:String(e)});}
 }});
}});
