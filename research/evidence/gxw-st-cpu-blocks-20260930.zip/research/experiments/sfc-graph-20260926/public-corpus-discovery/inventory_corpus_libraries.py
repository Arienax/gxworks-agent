"""Reuse existing native snapshots; cluster library payloads, retaining source hashes."""
import base64,json,sys
from pathlib import Path
from collections import Counter
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from probe_gxw_library_sources import snapshot_library_pous,observed_library_declarations,observed_builtin_template,observed_library_il
P=Path(__file__).resolve().parent
results=[];catalogs={};definitions={}
for f in sorted((P/'native-allocation-inventory').glob('case-*/frontend-snapshot.json')):
 outcome=json.loads((f.parent/'outcome.json').read_text());request=json.loads((f.parent/'request.json').read_text())
 assert outcome['returncode']==0 and outcome['open_succeeded']
 assert sha256((f.parent/'input.gxw').read_bytes())==request['input_sha256']
 raw=f.read_bytes();pous=snapshot_library_pous(json.loads(raw.decode('utf-8-sig')));keys=[]
 for pou in pous:
  key=sha256(json.dumps(pou,sort_keys=True).encode());keys.append(key)
  if key in definitions:continue
  item=dict(library=pou['library'],name=pou['name'],source_snapshot=str(f.relative_to(P)),raw=pou)
  try:item['declarations']=observed_library_declarations(base64.b64decode(pou['declaration_raw_base64']))
  except ValueError as exc:item['declaration_gap']=str(exc)
  body=base64.b64decode(pou['program_raw_base64'])
  if not body:item['body_handling']='no-native-buffer'
  else:
   try:
    item['body']=observed_builtin_template(body) if pou['library']=='@MELSEC' else observed_library_il(body)
    item['body_handling']=item['body']['handling']
   except ValueError as exc:item['body_handling']='opaque-preserved';item['body_gap']=str(exc)
  definitions[key]=item
 catalog=sha256(json.dumps(keys).encode());catalogs.setdefault(catalog,dict(definitions=keys,pou_count=len(keys)))
 row=dict(case=f.parent.name,source_sha256=request['input_sha256'],snapshot_sha256=sha256(raw),attributes=outcome['project_attributes'],catalog=catalog,pou_count=len(pous));results.append(row)
 print(json.dumps({k:v for k,v in row.items() if k in ('case','attributes','pou_count','catalog')}),flush=True)
summary=dict(snapshots=len(results),catalogs=len(catalogs),unique_definitions=len(definitions),body_handling=dict(Counter(v['body_handling'] for v in definitions.values())),declaration_gaps=sum('declaration_gap' in v for v in definitions.values()))
(P/'corpus-native-library-inventory.json').write_text(json.dumps(dict(summary=summary,projects=results,catalogs=catalogs,definitions=definitions),indent=2))
print(json.dumps(summary),flush=True)
