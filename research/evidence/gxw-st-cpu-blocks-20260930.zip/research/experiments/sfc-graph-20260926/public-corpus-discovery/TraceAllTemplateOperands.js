// Observe every template operand, including literal and temporary bindings.
(()=>{
'use strict';const active=new Map(),pending=new Map();let seq=0;
function str(p,n){try{let s='';for(let i=0;i<n;i++){const c=p.add(i).readU8();if(!c)return s;if(c>127)return null;s+=String.fromCharCode(c);}}catch(_){}return null;}
function hex(p,n){return Array.from(new Uint8Array(p.readByteArray(n)),v=>v.toString(16).padStart(2,'0')).join('');}
function loc(p){const m=Process.findModuleByAddress(p);return m?{module:m.name,rva:p.sub(m.base).toString()}:null;}
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='eccompiler_iec.dll')return;
 Interceptor.attach(m.findExportByName('Compile'),{onEnter(a){
  this.prior=active.get(this.threadId);const names=[];const n=a[1].toInt32();
  if(n>=0&&n<=1024)for(let i=0;i<n;i++)names.push(str(a[2].add(i*28+8).readPointer(),512));
  active.set(this.threadId,names.includes('POU_01'));send({event:'all-template-compile',names});
 },onLeave(){active.set(this.threadId,this.prior);}});
 Interceptor.attach(m.base.add(0x86345),{onEnter(){
  if(!active.get(this.threadId))return;
  const sp=this.context.esp;
  pending.set(this.threadId,{event:'all-template-operand',sequence:++seq,operand:str(sp.add(0x44).readPointer().readPointer(),512),
   position:sp.add(0x38).readS32(),stack:Thread.backtrace(this.context,Backtracer.ACCURATE).slice(0,8).map(loc)});
 }});
 Interceptor.attach(m.base.add(0x86595),{onEnter(){
  const row=pending.get(this.threadId);if(!row)return;
  row.path='placeholder';row.ordinal_zero_based=this.context.esp.add(0x1c).readS32();row.before_hex=hex(this.context.ebx.sub(20),25);
 }});
 Interceptor.attach(m.base.add(0x866ca),{onEnter(){
  const row=pending.get(this.threadId);if(!row)return;pending.delete(this.threadId);
  row.path=row.path||'literal-or-unresolved';row.after_hex=hex(this.context.ebx.sub(20),25);send(row);
 }});
}});
})();
