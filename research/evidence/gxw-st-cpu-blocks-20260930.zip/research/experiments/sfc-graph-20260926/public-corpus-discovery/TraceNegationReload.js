// Read-only source frontend observations. Layouts come from the pinned native
// ParseData debug-export code; never call or modify any intercepted function.
{
  const targets = {
    'dzdataabs_datamanager_iec.dll': {
      '?Initialize@CDZDataABS_OnMemoryDataManager@@QAEJJPBD@Z': ['Memory.Initialize', 2],
      '?SetBuildData@CDZDataABS_OnMemoryDataManager@@QAEJPAU_stBuildData@@PAU_stParameterData@@PAK@Z': ['Memory.SetBuildData', 3],
      '?ParseData@CDZDataABS_OnMemoryDataManager@@QAEJXZ': ['Memory.ParseData', 0]
    },
    'dzdataabs_sicconverter_iec.dll': {
      '?Initialize@CDZDataABS_ProcessManager@@QAEJPAVCDZDataABS_OnMemoryDataManager@@@Z': ['Process.Initialize', 1],
      '?Build@CDZDataABS_ProcessManager@@QAEJJ@Z': ['Process.Build', 1]
    }
  };
  function cstring(p) {
    try {
      const raw = bytes(p,512);
      if(raw===null) return null;
      const pairs=raw.match(/../g)||[]; const zero=pairs.indexOf('00');
      if(zero<0) return null;
      return p.readUtf8String(zero);
    } catch (_) { return null; }
  }
  function captureArrays(p,specs) {
    const arrays=[];
    for (const [label, offset, stride, nameOffset, payloads] of specs) {
      const count = p.add(offset+4).readS32();
      const arr = p.add(offset).readPointer();
      const item = {label, count, address:arr.toString(), stride, records:[]};
      if (count < 0 || count > 4096) { item.error='count outside observation bound'; arrays.push(item); continue; }
      for (let i=0;i<count;i++) {
        const d=arr.add(i*stride);
        const record={raw:bytes(d,stride), name:cstring(d.add(nameOffset).readPointer()), payloads:[]};
        if(label==='task') record.resource_name=cstring(d.add(12).readPointer());
        for(const [pointerOffset,sizeOffset] of payloads) {
          const size=d.add(sizeOffset).readS32();
          const address=d.add(pointerOffset).readPointer();
          record.payloads.push({pointer_offset:pointerOffset, size_offset:sizeOffset, size,
            address:address.toString(), bytes:size>=0 && size<=0x1000000 ? bytes(address,size) : null});
        }
        item.records.push(record);
      }
      arrays.push(item);
    }
    return arrays;
  }
  function buildData(p) {
    const result = {address:p.toString(), header:bytes(p, 0x34), name:cstring(p.readPointer()), libraries:[], arrays:[]};
    result.arrays=captureArrays(p,[
      ['resource', 0x0c, 16, 0, [[8,12]]],
      ['global', 0x14, 16, 0, [[8,12]]],
      ['structure', 0x1c, 16, 0, [[8,12]]],
      ['task', 0x24, 24, 0, [[16,20]]],
      ['pou', 0x2c, 56, 8, [[16,20],[24,28]]]
    ]);
    const libCount=p.add(4).readS32(); const libs=p.add(8).readPointer();
    result.library_count=libCount;
    if(libCount<0||libCount>64) throw new Error('library count outside observation bound');
    for(let i=0;i<libCount;i++) {
      const d=libs.add(i*32);
      result.libraries.push({raw:bytes(d,32),name:cstring(d.readPointer()),arrays:captureArrays(d,[
        ['global',8,16,0,[[8,12]]], ['structure',16,16,0,[[8,12]]], ['pou',24,56,8,[[16,20],[24,28]]]
      ])});
    }
    return result;
  }
  globalThis.observeFrontend = function(m) {
    const exports=targets[m.name.toLowerCase()];
    if(!exports) return;
    send({event:'frontend_module', name:m.name, path:m.path, base:m.base.toString(), size:m.size});
    for(const [symbol,[name,count]] of Object.entries(exports)) {
      const address=m.findExportByName(symbol);
      if(!address) {send({event:'frontend_missing',name,symbol});continue;}
      Interceptor.attach(address, {
        onEnter(args) {
          this.id=++serial; this.self=this.context.ecx;
          const event={event:'frontend_enter',id:this.id,name,module:m.name,self:this.self.toString(),
            caller:location(this.returnAddress), args:[], call_stack:Thread.backtrace(this.context,Backtracer.ACCURATE).map(location)};
          try {
            for(let i=0;i<count;i++) event.args.push({value:args[i].toString(),bytes:bytes(args[i],128)});
            if(name==='Memory.Initialize') {event.cpu=args[0].toUInt32();event.path=cstring(args[1]);}
            if(name==='Memory.SetBuildData' || name==='Memory.ParseData') {
              event.cpu=this.self.add(0x44).readU32();
              const b=name==='Memory.SetBuildData'?args[0]:this.self.add(0x74).readPointer();
              const param=name==='Memory.SetBuildData'?args[1]:this.self.add(0x78).readPointer();
              const options=name==='Memory.SetBuildData'?args[2]:this.self.add(0x7c).readPointer();
              event.build=buildData(b); event.parameter=bytes(param,96);
              const size=param.add(4).readS32();
              event.parameter_block=size>=0&&size<=0x1000000?bytes(param.readPointer(),size):null;
              event.options=[];
              for(let i=0;i<256;i++){const v=options.add(i*4).readU32();event.options.push(v);if(v===0xffffffff)break;}
            }
          } catch(error) {event.error=String(error);}
          send(event);
        },
        onLeave(result) {send({event:'frontend_leave',id:this.id,name,result:result.toString()});}
      });
    }
  };
}


// Read-only, bounded ECCompiler observations. Never invoke or replace targets.
'use strict';
let serial = 0;
const seen = new Set();
function location(p) {
  const m = Process.findModuleByAddress(p);
  return m ? {module: m.name, rva: p.sub(m.base).toString()} : null;
}
function bytes(p, count) {
  try {
    const r = Process.findRangeByAddress(p);
    if (!r || r.protection.indexOf('r') < 0) return null;
    const n = Math.min(count, r.base.add(r.size).sub(p).toUInt32());
    return Array.from(new Uint8Array(p.readByteArray(n)), v => v.toString(16).padStart(2, '0')).join('');
  } catch (_) { return null; }
}
const specs = {
  ObjectNew: 1, ObjectDelete: 1, ChangeInit: 4,
  CompileStart: 28, Compile: 7, CompileEnd: 1, Link: 6,
  Load: 2, Save: 2, LoadFromProjectDB: 4, SaveToProjectDB: 4,
  InitializeAddressConverter: 25, SetSymbolicData: 4,
  GetSymbolicData: 4, SetSystemVariables: 3, Commit: 2,
  GetPCode: 7, GetPCodeInfo: 5, GetUnLinkedPCodeInfo: 5
};
const observer = Process.attachModuleObserver({onAdded(m) {
  if (!['eccompiler.dll', 'eccompiler_iec.dll'].includes(m.name.toLowerCase()) || seen.has(m.base.toString())) return;
  seen.add(m.base.toString());
  send({event: 'module', name: m.name, path: m.path, base: m.base.toString(), size: m.size, arch: Process.arch});
  for (const [name, count] of Object.entries(specs)) {
    const address = m.findExportByName(name);
    if (address === null) continue;
    Interceptor.attach(address, {
      onEnter(args) {
        this.id = ++serial;
        this.saved = [];
        for (let i = 0; i < count; ++i) this.saved.push(args[i]);
        const values = this.saved.map((p, i) => ({index: i, value: p.toString(), location: location(p), bytes: bytes(p, 256)}));
        const buffers = [];
        const bounded = (label, p, size) => {
          if (size >= 0 && size <= 0x1000000) buffers.push({label, address:p.toString(), requested_size:size, bytes:bytes(p,size)});
        };
        if (name === 'SetSystemVariables') bounded('system_variables', args[2], args[1].toInt32());
        if (name === 'InitializeAddressConverter') bounded('parameter_block', args[2], args[1].toInt32());
        if (name === 'CompileStart') bounded('parameter_block', args[3], args[2].toInt32());
        if (name === 'Compile') {
          bounded('symbolic_data', args[4], args[3].toInt32());
          const n = args[1].toInt32();
          if (n >= 0 && n <= 1024) {
            bounded('compile_descriptors', args[2], n * 28);
            for (let i=0; i<n; ++i) {
              const d = args[2].add(i*28);
              try {
                bounded('source_' + i, d.add(4).readPointer(), d.readS32());
                buffers.push({label:'name_' + i, bytes:bytes(d.add(8).readPointer(),256)});
              } catch (_) {}
            }
          }
        }
        let callStack = null;
        if (['Compile', 'CompileStart', 'LoadFromProjectDB'].includes(name)) {
          try { callStack = Thread.backtrace(this.context, Backtracer.ACCURATE).map(location); }
          catch (error) { callStack = {error:String(error)}; }
        }
        send({event:'enter', id:this.id, name, module:m.name, thread:this.threadId, caller:location(this.returnAddress),
              call_stack:callStack, args:values, buffers});
      },
      onLeave(result) {
        send({event:'leave', id:this.id, name, module:m.name, result:result.toString(),
          result_bytes: name === 'ObjectNew' ? bytes(result, m.name.toLowerCase().includes('_iec') ? 0x198 : 0x194) : null,
          args:this.saved.map((p, i) => ({index:i, value:p.toString(), bytes:bytes(p, 256)}))});
      }
    });
  }
}});
send({event:'ready', process_id:Process.id, arch:Process.arch});

const frontendSpecs=[{"name": "DZDataABS_DataManager_IEC.dll", "size": 888832, "iat": 65628, "anchor": 147021, "exports": {"?Initialize@CDZDataABS_OnMemoryDataManager@@QAEJJPBD@Z": 147021, "?ParseData@CDZDataABS_OnMemoryDataManager@@QAEJXZ": 159818, "?SetBuildData@CDZDataABS_OnMemoryDataManager@@QAEJPAU_stBuildData@@PAU_stParameterData@@PAK@Z": 127776}}, {"name": "DZDataABS_SICConverter_IEC.dll", "size": 1458176, "iat": 65808, "anchor": 6444, "exports": {"?Build@CDZDataABS_ProcessManager@@QAEJJ@Z": 16057, "?Initialize@CDZDataABS_ProcessManager@@QAEJPAVCDZDataABS_OnMemoryDataManager@@@Z": 6444, "?RunWriteBuild@CDZDataABS_ProcessManager@@QAEJJPAU_stRunWriteBuildData@@J@Z": 13464}}];
let frontendInstalled=false;
function installFrontend(){
 if(frontendInstalled)return;
 const c=Process.findModuleByName('DZDataABS_Compiler_IEC.dll');if(!c)return;
 frontendInstalled=true;
 for(const spec of frontendSpecs){
  const b=c.base.add(spec.iat).readPointer().sub(spec.anchor);
  if(spec.name==='DZDataABS_SICConverter_IEC.dll')observeNegation(b);
  globalThis.observeFrontend({name:spec.name,path:'resolved compiler IAT',base:b,size:spec.size,findExportByName(n){return spec.exports[n]===undefined?null:b.add(spec.exports[n]);}});
 }
}
Process.attachModuleObserver({onAdded(m){
 const n=m.name.toLowerCase();let address=null;
 if(n==='dzdataabs_compileradapter.dll')address=m.base.add(0x13cc0);
 if(n==='eccompiler_iec.dll')address=m.findExportByName('ObjectNew');
 if(address)Interceptor.attach(address,{onEnter(){installFrontend();}});
}});

function ascii(p){try{let s='';for(let i=0;i<1024;i++){let n=p.add(i).readU8();if(!n)return s;if(n>127)return null;s+=String.fromCharCode(n);}return null;}catch(_){return null;}}
function observeNegation(b){
 if(bytes(b.add(0x3ef05),10)!=='b8dd018b66e856970600') {send({event:'negation-guard-mismatch',bytes:bytes(b.add(0x3ef05),10)});return;}
 Interceptor.attach(b.add(0x3ef05),{onEnter(a){this.out=a[0];this.input=ascii(a[1]);this.mode=a[2].toUInt32()&255;},onLeave(ret){let output=null;try{output=ascii(this.out.readPointer());}catch(_){}send({event:'negation-conversion',input:this.input,mode:this.mode,output:output,result:ret.toString()});}});
 for(const [name,iat,caller] of [['lower',0xee4f0,0x3ef28],['is-lower',0xee4f8,0x3ef67]]) {
  Interceptor.attach(b.add(iat).readPointer(),{onEnter(a){this.selected=this.returnAddress.equals(b.add(caller));if(this.selected)this.input=a[0].toInt32();},onLeave(ret){if(this.selected)send({event:'negation-ctype',name:name,input:this.input,result:ret.toInt32()});}});
 }
}
Process.attachModuleObserver({onAdded(m){if(m.name.toLowerCase()!=='msvcr71.dll')return;
 for(const name of ['_setmbcp','_getmbcp','setlocale']){const p=m.findExportByName(name);if(!p)continue;Interceptor.attach(p,{onEnter(a){this.value=a[0].toInt32();this.locale=name==='setlocale'?ascii(a[1]):null;this.caller=location(this.returnAddress);},onLeave(r){send({event:'crt-codepage',name:name,value:this.value,locale:this.locale,result:r.toInt32(),caller:this.caller});}});}
}});
