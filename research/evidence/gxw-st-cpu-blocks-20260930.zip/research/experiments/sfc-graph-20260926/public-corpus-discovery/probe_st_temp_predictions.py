"""Predict deeper ST expression bytecode before native compilation."""
from dataclasses import replace
from pathlib import Path
import base64,json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from gxw.declarations import parse_declarations,serialize_declarations
from gxw.project_metadata import mark_observed_source_compile_pending
from probe_gxw_st_sources import replace_observed_st
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_program_check_resources import SCRIPT
from probe_minimal_conditional_port_writes import streams,observe,save
from source_q_st_expressions import predict
from native_gxw_tokens import native_batch,Q_DLL,native_il_records
P=Path(__file__).resolve().parent
OUT=P/'st-temp-predictions-20260930'


def main():
    OUT.mkdir(exist_ok=False)
    for name in (Path(__file__).name,'source_q_st_expressions.py','source_q_direct_declarations.py','source_q_width.py'):(OUT/name).write_bytes((P/name).read_bytes())
    trace=OUT/'trace.js';trace.write_text('(()=>{'+(P/'native-allocation-bitmap-v2/observer.js').read_text()+'\n'+(P/'observe_expression_temporaries.js').read_text()+'\n})();\n(()=>{'+SCRIPT+'\n})();',encoding='utf-8')
    original=(P/'st-temp-lifetimes-20260930/balanced-pair/input.gxw').read_bytes();before=streams(original)
    labels='POU_01.Labels.lh';doc=parse_declarations(before[labels],logical_name=labels)
    assert sum(r.name=='Keypad_1' and r.type_code==15 for r in doc.rows)==1
    raw_labels=mark_observed_source_compile_pending(serialize_declarations(replace(doc,rows=tuple(r for r in doc.rows if r.name!='Keypad_1'))),logical_name=labels)
    plans={
      'chain-eight':'probeR1 := ((((((probeA + probeB) - probeC) + probeD) - probeE) + probeF) - probeG) + probeH;\r\nprobeR2 := ((probeA + probeB) + probeC) - probeD;\r\n',
      'balanced-eight':'probeR1 := ((probeA + probeB) - (probeC + probeD)) + ((probeE + probeF) - (probeG + probeH));\r\nprobeR2 := (probeA + probeB) - (probeC + probeD);\r\n',
      'balanced-order':'probeR2 := (probeA + probeB) - (probeC + probeD);\r\nprobeR1 := ((probeA + probeB) - (probeC + probeD)) + ((probeE + probeF) - (probeG + probeH));\r\n',
    }
    ready=[]
    for case,text in plans.items():
        d=OUT/case;d.mkdir();name='POU_01.Program.pou';raw,_=replace_observed_st(before[name],text)
        raw=mark_observed_source_compile_pending(raw,logical_name=name)
        source,one=patch_raw(original,name,before[name],raw);source,two=patch_raw(source,labels,before[labels],raw_labels)
        assert streams(source)==dict(before,**{name:raw,labels:raw_labels})
        path=d/'input.gxw';path.write_bytes(source);prediction=predict(source);code=prediction.pop('output')
        (d/'predicted-0.bin').write_bytes(code)
        save(d/'prediction-before-native.json',dict(input_sha256=sha256(source),receipts=[one,two],prediction=prediction,
            scope='Unused root FB declaration removed to isolate expression allocation; every other logical payload preserved.'))
        ready.append((case,d,path,code,prediction))
    rows=[];requests=[];keys=[]
    for case,d,path,predicted,prediction in ready:
        native,checked,process=observe(path,d,trace);code=(native/'pcode-0-0.bin').read_bytes()
        messages=[json.loads(l) for l in (native/'events.jsonl').read_text().splitlines()]
        events=[m['payload'] for m in messages if m.get('type')=='send']
        errors=[m for m in messages if m.get('type')=='error' or 'error' in m.get('payload',{}).get('event','') or m.get('payload',{}).get('observation_error')]
        row=dict(case=case,native_directory=str(native),process=process,check=checked['check'],diagnostics=checked['diagnostics'],trace_errors=errors,
            byte_identical=code==predicted,predicted_sha256=sha256(predicted),native_sha256=sha256(code),
            temporary_events=[e for e in events if e.get('event','').startswith('temporary-')])
        rows.append(row);save(OUT/'comparison.json',rows)
        print(json.dumps(dict(case=case,check=row['check'],byte_identical=row['byte_identical'],bytes=len(code),
            predicted_slots=prediction['slots'],native_requests=[e['result'] for e in row['temporary_events'] if e.get('name')=='request'],errors=errors)),flush=True)
        if errors:raise RuntimeError('trace incomplete')
        if code:requests.append(dict(mode='decode',case=case,input_base64=base64.b64encode(code+b'\0').decode()));keys.append(case)
    if requests:
        decoded=native_batch(requests,OUT/'native-decode',dll=Q_DLL,cpu_code=209,native_versions=(25,))
        save(OUT/'native-listings.json',[dict(case=k,return_code=r['return_code'],records=native_il_records(base64.b64decode(r['output_base64']),encoding='cp932')) for k,r in zip(keys,decoded)])


if __name__=='__main__':main()
