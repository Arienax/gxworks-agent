"""Novel operand/header combinations; freeze predictions before native check."""
import base64
import collections
import hashlib
import itertools
import json
from pathlib import Path
import subprocess
import sys
import source_q_width as q

P=Path(__file__).resolve().parent
WIDE='--wide' in sys.argv
OUT=P/('q-width-all-application-holdouts' if WIDE else 'q-width-holdouts')

def token(code,value):
    n=max(1,(value.bit_length()+7)//8)
    return bytes([n+3,code])+value.to_bytes(n,'little')+bytes([n+3])

def main():
    OUT.mkdir(exist_ok=False)
    for name in ['source_q_width.py','q-width-static-tables.json','probe_q_width_holdouts.py']:
        (OUT/name).write_bytes((P/name).read_bytes())
    pool=[('D17',token(0xa8,17)),('D4096',token(0xa8,4096)),('DZ',token(0xf0,3)+token(0xa8,33)),('@D',token(0xf3,0)+token(0xa8,55)),('@DZ',token(0xf3,0)+token(0xf0,2)+token(0xa8,44)),('Z0',token(0xcc,0)),('Z2',token(0xcc,2)),('ZR65536',token(0xb0,65536)),('ZR65536Z',token(0xf0,1)+token(0xb0,65536)),('D.bit',token(0xf2,3)+token(0xa8,55)),('M17',token(0x90,17)),('T9',token(0xc2,9)),('K7',token(0xe8,7)),('K65536',token(0xe9,65536)),('U0G',token(0xf8,0)+token(0xab,3)),('U3E0G',token(0xf8,0x3e0)+token(0xab,10000)),('U3E0GZ',token(0xf8,0x3e0)+token(0xf0,2)+token(0xab,10001)),('U3E0ZG',token(0xf0,2)+token(0xf8,0x3e0)+token(0xab,10002)),('J0B',token(0xf9,0)+token(0xa0,0x45))]
    pool += [(f'K{k}M{n}',token(0xf1,k)+token(0x90,n)) for k,n in itertools.product([1,4,8],[16,17])]
    catalog=json.loads((q.ROOT/'src/gxw/templates/q03udv-token-grammar.json').read_text())['headers']
    headers=[(r['family'],r['variant']) for r in q.TABLES['application']]
    if WIDE:headers=[tuple(int(x,16) for x in key.split(':')) for key in catalog if 0x40<=int(key[:2],16)<0x70]
    headers += [(f,0) for f in range(0x40) if f'{f:02x}:00' in catalog and f not in (4,5,10,11,21,22,0x3c,0x3f)]
    rows=[];seen=set()
    discovery={r['raw'] for r in json.loads((P/'q-width-corpus-trace/requests.json').read_text())}
    for f,v in headers:
        h=bytes([4,f,127,4]) if f<0x40 else bytes([5,f,127,v,5])
        try:name,arity=q.q_instruction_header(h)
        except ValueError:continue
        defaults=[token(0xa8,101+i*2) for i in range(arity)]
        variants=[('default',defaults)]
        for label,t in pool:
            for i in range(arity):
                ds=defaults.copy();ds[i]=t;variants.append((f'{label}@{i}',ds))
            if arity:variants.append((f'{label}@all',[t]*arity))
            if arity==3:variants.append((f'{label}@first=third',[t,defaults[1],t]))
        for label,ds in variants:
            for pulse in ([False,True] if f>=0x40 else [False]):
                head=bytes([6,f,127,v,2,6]) if pulse else h
                raw=head+b''.join(ds)
                if raw in seen or raw.hex() in discovery:continue
                seen.add(raw)
                r=dict(family=f,variant=v,name=name,label=label,pulse=pulse,raw=raw.hex())
                try:r['prediction']=q.rewrite(raw).hex()
                except ValueError as e:r['unsupported']=str(e)
                rows.append(r)
    (OUT/'predictions-before-native.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
    dll=Path('D:/GXWORKS2/Easysocket/CodeGenerator/ECCodeGenerator2.dll')
    assert hashlib.sha256(dll.read_bytes()).hexdigest()==q.TABLES['dll_sha256']
    context=P/'q-width-corpus-trace/device-context.bin'
    protocol=''.join(f"check-instruction\t{i}\t{base64.b64encode(bytes.fromhex(r['raw'])).decode()}\n" for i,r in enumerate(rows))
    (OUT/'input.txt').write_text(protocol,encoding='ascii')
    run=subprocess.run([str((P/'q-public-check-replay/PublicCheckOracle.exe').resolve()),str(dll),'209','1','q','1',str(context.resolve())],input=protocol.encode(),capture_output=True,timeout=50,creationflags=subprocess.CREATE_NO_WINDOW)
    (OUT/'stdout.jsonl').write_bytes(run.stdout);(OUT/'stderr.bin').write_bytes(run.stderr)
    answers=[json.loads(l) for l in run.stdout.splitlines()]
    assert run.returncode==0 and len(answers)==len(rows)
    counts=collections.Counter();failures=[];unsupported=[]
    for r,a in zip(rows,answers):
        if a['return_code']!='0x00000000':counts['native-rejected']+=1;continue
        expected=base64.b64decode(a['output_base64']).hex()
        if 'unsupported' in r:counts['unsupported']+=1;unsupported.append(dict(**r,native=expected));continue
        if r['prediction']==expected:counts['byte-identical']+=1
        else:counts['different']+=1;failures.append(dict(**r,native=expected))
    result=dict(total=len(rows),counts=dict(counts),failures=failures,unsupported=unsupported)
    (OUT/'comparison.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(total=len(rows),counts=counts,first=failures[:12],unsupported=unsupported[:3])))

if __name__=='__main__':main()
