from pathlib import Path
import sys,json,base64
ROOT=Path(__file__).resolve().parents[4];sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.declarations import parse_declarations,edit_declarations,serialize_declarations,_string
from probe_gxw_integrity import patch_verified_payloads
from replay_gxw_workspace import run
from native_gxw_tokens import native_batch,native_il_projection
from probe_fx3g_library_roundtrip import st_envelope
P=Path(__file__).resolve().parent;OUT=P/'library-constant-authority-v2'
BASE=P/'fx3g-library-source-roundtrip-v6/true-source-only/compile-1'
SOURCE='GVL_AM\\AlarmManger.lng';COPY='GVL_AM\\AlarmManger.lgv';MAIN='MAIN.Program.pou'

def main():
 OUT.mkdir(exist_ok=False);(OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
 original=(BASE/'native-saved.gxw').read_bytes();streams={s.logical_name:s.raw for s in inspect_project(original).streams if s.logical_name}
 baseline,_=patch_verified_payloads(original,{MAIN:(streams[MAIN],st_envelope(streams[MAIN],'D0 := c_AM_ERROR;\r\n'))})
 document=parse_declarations(streams[SOURCE],logical_name=SOURCE)
 modified=serialize_declarations(edit_declarations(document,upserts=[dict(name='c_AM_ERROR',initial_value='300')]))
 copy=streams[COPY];a=copy.index(_string('c_AM_ERROR'));b=copy.index(_string('c_AM_WARNING'));record=copy[a:b];assert record.count(_string('3'))==1
 companion_changed=copy[:a]+record.replace(_string('3'),_string('4'))+copy[b:]
 cases=[('baseline',None,None,'K3'),('source-only-growth',SOURCE,modified,'K300'),('companion-only',COPY,companion_changed,'K3')]
 results=[]
 for case,target,changed,expected in cases:
  out=OUT/case;out.mkdir();candidate,receipt=patch_verified_payloads(baseline,{target:(streams[target],changed)}) if target else (baseline,{})
  after={s.logical_name:s.raw for s in inspect_project(candidate).streams if s.logical_name}
  touched=[k for k in streams if streams[k]!=after[k]];assert set(touched)=={MAIN}|({target} if target else set())
  path=out/'candidate.gxw';path.write_bytes(candidate)
  (out/'prediction-before-native.json').write_text(json.dumps(dict(source_sha256=sha256(original),candidate_sha256=sha256(candidate),touched=touched,receipt=receipt,expected_constant=expected,other_nested_payloads_byte_identical=True),indent=2),encoding='utf-8')
  row=dict(case=case,expected_constant=expected,phases=[])
  for phase in ('compile','reopen'):
   for attempt in range(1,5):
    native=out/f'{phase}-{attempt}';outcome=run(path,native,compile=True,export_project=True,program_check=True,snapshot_frontend=True,project_alias='LIBCONST')
    events=[json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
   result=dict(phase=phase,native_directory=str(native),outcome=outcome)
   pcode=native/'pcode-0-0.bin'
   if pcode.exists():
    code=pcode.read_bytes();result.update(pcode_sha256=sha256(code),pcode_bytes=len(code))
    response,=native_batch([dict(mode='decode',input_base64=base64.b64encode(code+b'\0').decode())],native/'independent-decoder',cpu_code=521)
    result['native_decoded']=native_il_projection(base64.b64decode(response['output_base64']),encoding='cp1252')['records'] if response['return_code']=='0x00000000' else response
   path=native/'native-saved.gxw'
   if path.exists():
    saved={s.logical_name:s.raw for s in inspect_project(path.read_bytes()).streams if s.logical_name}
    doc=parse_declarations(saved[SOURCE],logical_name=SOURCE)
    result['saved_initial_value']=next(r.initial_value for r in doc.rows if r.name=='c_AM_ERROR')
   row['phases'].append(result);(out/'comparison.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
   print(json.dumps(dict(case=case,phase=phase,open=outcome['open_succeeded'],rejected=outcome['compiler_rejected'],saved=path.exists(),initial=result.get('saved_initial_value'),pcode=result.get('pcode_sha256'),listing=result.get('native_decoded')),ensure_ascii=True),flush=True)
   if not path.exists() or outcome['compiler_rejected']:break
  results.append(row);(OUT/'comparison.json').write_text(json.dumps(results,indent=2),encoding='utf-8')

if __name__=='__main__':main()
