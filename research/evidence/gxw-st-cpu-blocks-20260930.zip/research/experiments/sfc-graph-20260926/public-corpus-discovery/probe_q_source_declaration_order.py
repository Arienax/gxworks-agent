"""Native counterfactuals: source row order, record IDs and new declarations."""
from dataclasses import replace
from pathlib import Path
import json
import sys
ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'research')]
from gxw.lossless import inspect_project, sha256
from gxw.declarations import parse_declarations, serialize_declarations, edit_declarations
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import run
from source_q_direct_projection import project_projection
from compare_q_direct_projection import compare_native

P = Path(__file__).resolve().parent
OUT = P/'q-source-declaration-order'


def payloads(raw):
    return {s.logical_name: s.raw for s in inspect_project(raw).streams if s.logical_name}


def main():
    OUT.mkdir(exist_ok=False)
    for name in ['probe_q_source_declaration_order.py', 'compare_q_direct_projection.py', 'source_q_direct_projection.py', 'source_q_direct_declarations.py', 'source_q_call_connections.py', 'source_q_label_binding.py', 'source_q_allocation.py', 'source_q_width.py', 'q-width-static-tables.json']:
        (OUT/name).write_bytes((P/name).read_bytes())
    source = (P/'noeul-native-batch/case-08/input.gxw').read_bytes(); before = payloads(source)
    logical = next(n for n in before if n.endswith('.Labels.lh') and any(r.name == 'EMSTP' for r in parse_declarations(before[n], logical_name=n).rows))
    doc = parse_declarations(before[logical], logical_name=logical)
    reversed_ids = dict(zip(sorted(r.record_id for r in doc.rows), sorted((r.record_id for r in doc.rows), reverse=True)))
    expanded = edit_declarations(doc, upserts=[dict(name='unused_matrix', data_type='ARRAY [-2..0,3..4] OF DINT', initial_value='[6(0)]')])
    expanded = replace(expanded, rows=tuple(replace(r, record_id=1 if r.name == 'unused_matrix' else r.record_id+1) for r in expanded.rows))
    plans = [
        ('rows-reversed', replace(doc, rows=tuple(reversed(doc.rows)))),
        ('record-ids-reversed', replace(doc, rows=tuple(replace(r, record_id=reversed_ids[r.record_id]) for r in doc.rows))),
        ('new-matrix-oldest-id', expanded),
        ('existing-int-to-dint', edit_declarations(doc, upserts=[dict(name='STATE', data_type='DINT', initial_value='0')])),
    ]
    ready = []; results = []
    for case, document in plans:
        directory = OUT/case; directory.mkdir()
        labels = serialize_declarations(document)
        changed, receipt = patch_raw(source, logical, before[logical], labels)
        assert payloads(changed) == dict(before, **{logical: labels})
        path = directory/'input.gxw'; path.write_bytes(changed)
        predictions = project_projection(changed)
        for row in predictions:
            (directory/f'predicted-{row["resource_index"]}.bin').write_bytes(row.pop('output'))
        (directory/'prediction-before-native.json').write_text(json.dumps(dict(source_sha256=sha256(source), changed_sha256=sha256(changed),
            mutation=case, receipt=receipt, compiler_cache='byte-identical, excluded from prediction', predictions=predictions), indent=2), encoding='utf-8')
        ready.append((case, directory, path, predictions))
    for case, directory, path, predictions in ready:
        for attempt in range(1, 5):
            native = directory/f'native-{attempt}'
            outcome = run(path, native, compile=True, export_project=True, project_alias='QDECLORDER')
            events = [json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
            if not any(e.get('operation') == 'NativeTemporaryDirectoryCollision' for e in events):
                break
        accepted = outcome['returncode'] == 0 and outcome['compile_completed'] and not outcome['compiler_rejected'] and (native/'native-saved.gxw').exists()
        row = dict(case=case, native_directory=str(native), native_accepted=accepted, outcome=outcome,
                   programs=compare_native(predictions, directory, native) if accepted else [])
        (directory/'comparison.json').write_text(json.dumps(row, indent=2), encoding='utf-8')
        results.append(row)
        (OUT/'comparison.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
        print(json.dumps(dict(case=case, native_accepted=accepted, programs=row['programs'], diagnostics=outcome['diagnostics'])), flush=True)


if __name__ == '__main__':
    main()
