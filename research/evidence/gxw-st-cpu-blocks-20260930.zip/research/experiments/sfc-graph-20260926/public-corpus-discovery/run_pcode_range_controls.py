"""Read-only native forward source-range controls on isolated real projects."""
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from replay_gxw_workspace import run
P=Path(__file__).resolve().parent
OUT=P/'native-pcode-range-controls'
cases=[('two',P/'scpi-two-callers/native/native-saved.gxw','MAIN',1,[('MAIN',4),('MAIN',6),('SCPI',0),('SCPI',7),('SCPI',458)]),
       ('same',P/'scpi-instance-binding-controls/same-instance/native/native-saved.gxw','MAIN',1,[('SCPI',0),('SCPI',7),('SCPI',458)]),
       ('st',P/'samples/boxid.gxw','POU_01',193,[('POU_01',1),('POU_01',35),('Keypad',4),('Keypad',7),('Keypad',9)])]
for name,path,resource,kind,points in cases:
    out=OUT/name
    if (out/'outcome.json').exists():continue
    queries=[]
    for mode in ['basic','debug']:
        for pou,step in points+[(points[0][0],1000000),('NO_SUCH_POU',0)]:
            for count in [-1,1,2]:
                queries.append(dict(mode=mode,resource=resource,library='',pou=pou,program_kind=kind,network=-1,
                                    start_step=step,step_count=count,element_id=-1))
    queries.append(queries[-1]|dict(pou=points[0][0],start_step=points[0][1],resource='NO_SUCH_RESOURCE'))
    result=run(path,out,compile=True,export_project=True,project_alias='RANGES',pcode_range_queries=queries)
    print(json.dumps(dict(case=name,outcome=result)),flush=True)
    if (out/'native-pcode-ranges.json').exists():
        rows=json.loads((out/'native-pcode-ranges.json').read_text(encoding='utf-8-sig'))
        for row in rows:
            for r in row['ranges']:r.pop('raw_base64')
        print(json.dumps(dict(case=name,queries=rows)),flush=True)
