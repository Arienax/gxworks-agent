"""Distinguish ST FB call expansion, instance state and aliased native xrefs."""
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.declarations import parse_declarations,edit_declarations,serialize_declarations
from probe_gxw_st_sources import replace_observed_st
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_compiled_references import inspect
from replay_gxw_workspace import run
P=Path(__file__).resolve().parent
OUT=P/'ST-repeated-FB-controls';OUT.mkdir(exist_ok=True)
source=(P/'samples/boxid.gxw').read_bytes()
streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
name='POU_01.Program.pou'
_,text=replace_observed_st(streams[name],'')
call='Keypad_1(number:= line1 , in_out_character:= character );'
assert text.count(call)==1
for case,instance in [('same','Keypad_1'),('separate','Keypad_2')]:
    out=OUT/case;out.mkdir(exist_ok=True)
    if (out/'comparison.json').exists():continue
    added=f'{instance}(number:= line2 , in_out_character:= currentUserId );'
    updated,_=replace_observed_st(streams[name],text.replace(call,call+'\r\n'+added))
    changed,receipt=patch_raw(source,name,streams[name],updated)
    touched={name};receipts=[receipt]
    if case=='separate':
        labels='POU_01.Labels.lh';touched.add(labels)
        d=parse_declarations(streams[labels],logical_name=labels)
        new=serialize_declarations(edit_declarations(d,upserts=[dict(name=instance,data_type='Keypad',kind='function_block')]))
        changed,receipt=patch_raw(changed,labels,streams[labels],new);receipts.append(receipt)
    after={s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}
    assert all(after[n]==raw for n,raw in streams.items() if n not in touched)
    path=out/'changed.gxw';path.write_bytes(changed)
    (out/'mutation.json').write_text(json.dumps(dict(source_sha256=sha256(source),changed_sha256=sha256(changed),
        added_call=added,receipts=receipts,unrelated_payloads='byte-identical'),indent=2),encoding='utf-8')
    q=[dict(name='all',keys=[],symbol='',scope='',declared=0,plural=0)]
    result=run(path,out/'native',compile=True,export_project=True,project_alias='STREPEATED',analysis_queries=q,analysis_version=3)
    comparison=dict(case=case,native={k:result[k] for k in ['returncode','compile_completed','compiler_rejected','diagnostics']})
    if result.get('native_export'):
        reopened=run(out/'native/native-saved.gxw',out/'reopen',compile=True,export_project=True)
        comparison['reopen']={k:reopened[k] for k in ['returncode','compile_completed','compiler_rejected','diagnostics']}
        comparison['reopen_pcode_equal']=result['outputs']==reopened['outputs']
        read=inspect(out/'native',out/'correlation')
        comparison['reader']=read['summary']
        fragments=read['decoded_fragments']
        comparison['expansions']=[]
        for e in read['expansions']:
            if e['source']!='Keypad.Program.pou':continue
            picked=[]
            for o in e['occurrences']:
                line=o.get('source_line',{})
                if line.get('line_index') not in [4,7,8,9]:continue
                picked.append(dict(line=line,debug_rows=o['debug_rows'],compiled=[r for g in o['compiled_records']
                    for r in fragments[g['decode_request']].get('records',[])]))
            comparison['expansions'].append(dict(index=e['element_index'],paths=e['stored_instance_paths'],fields=e['fields'],points=picked))
        refs=json.loads((out/'native/native-program-analysis.json').read_text(encoding='utf-8-sig'))['queries'][0]['rows']
        comparison['native_pin_references']=[r for r in refs if r['source']=='Keypad' and r['name'].lower() in ['number','in_out_character']]
    (out/'comparison.json').write_text(json.dumps(comparison,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in comparison.items() if k not in ['native_pin_references','expansions']}),flush=True)
