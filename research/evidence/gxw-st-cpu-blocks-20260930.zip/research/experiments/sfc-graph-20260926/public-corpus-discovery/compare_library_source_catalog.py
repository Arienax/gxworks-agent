from pathlib import Path
import sys,json,collections
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from gxw.lossless import inspect_project,sha256
from probe_gxw_library_archive import decode_library_archive,frame_library_text
from probe_gxw_library_sources import snapshot_library_pous
P=Path(__file__).resolve().parent
rows=[]
for case in ['case-00','case-05']:
 directory=P/'native-allocation-inventory'/case
 native=snapshot_library_pous(json.loads((directory/'frontend-snapshot.json').read_text(encoding='utf-8-sig')))
 selected=collections.defaultdict(list);sources=[]
 for stream in inspect_project((directory/'input.gxw').read_bytes()).streams:
  if not stream.logical_name or not stream.logical_name.endswith('.lif'):continue
  library='@IEC' if stream.logical_name=='IECFunction.lif' else '@MELSEC'
  decoded=decode_library_archive(stream.raw[20:]);framed=frame_library_text(decoded.decoded)
  definitions=framed['definitions'];eligible=[d for d in definitions if d['sections'] is None or 'Q03UDV' in d['sections']]
  for d in eligible:selected[(library,d['name'])].append((stream.logical_name,d))
  sources.append(dict(logical_name=stream.logical_name,compressed_sha256=sha256(stream.raw),decoded_sha256=sha256(decoded.decoded),definitions=len(definitions),eligible=len(eligible),framing_byte_equal=b''.join(r['raw'] for r in framed['regions'])==decoded.decoded))
 observed={(p['library'],p['name']) for p in native};predicted=set(selected)
 row=dict(case=case,cpu='Q03UDV',sources=sources,native=len(observed),predicted=len(predicted),missing=sorted(observed-predicted),extra=sorted(predicted-observed),duplicate_eligible={str(k):[(n,d['offset']) for n,d in v] for k,v in selected.items() if len(v)>1})
 rows.append(row);print(json.dumps(row))
(P/'library-source-catalog-comparison.json').write_text(json.dumps(rows,indent=2))
