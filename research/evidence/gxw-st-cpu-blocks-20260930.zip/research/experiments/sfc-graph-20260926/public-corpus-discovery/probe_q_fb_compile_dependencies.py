"""Test whether declarations or call sites trigger FB source validation."""
from pathlib import Path
import base64,json,struct,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.declarations import parse_declarations,edit_declarations,serialize_declarations
from probe_gxw_simple_fb import frame_source,observe_calls
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_parameters import device_allocation_record
from replay_gxw_workspace import run
from native_gxw_tokens import native_batch,native_il_projection,Q_DLL
P=Path(__file__).resolve().parent
out=P/'q-fb-compile-dependencies';out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
source=(P/'scpi-instance-binding-controls/same-instance/native/native-saved.gxw').read_bytes()
streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
caller=frame_source(streams['MAIN.Program.pou']);definition=frame_source(streams['SCPI.Program.pou'])
calls=observe_calls(caller);assert len(calls['calls'])==2 and not calls['gaps']
without_calls=bytearray(caller.raw)
for call in reversed(calls['calls']):del without_calls[call['offset']:call['offset']+call['length']]
delta=len(without_calls)-len(caller.raw)
for offset in (55,59):struct.pack_into('<I',without_calls,offset,struct.unpack_from('<I',caller.raw,offset)[0]+delta)
assert not observe_calls(frame_source(bytes(without_calls)))['calls']
requests=[]
for text in ["LD 'iEn\0OUT 'oSendDone","LD 'NeverDeclared\0OUT 'oSendDone"]:
    requests.append(dict(mode='encode',text=text,input_base64=base64.b64encode(text.encode('ascii')+b'\0\0').decode()))
answers=native_batch(requests,out/'native-source-encode',dll=Q_DLL,cpu_code=209,native_versions=(25,),device_context=device_allocation_record(streams['Param.wpa']).raw)
definitions=[]
for answer in answers:
    assert answer['return_code']=='0x00000000'
    body=base64.b64decode(answer['output_base64'])
    new=bytearray(definition.raw[:definition.body_offset]+body+definition.raw[definition.body_end:])
    for offset in (55,59):struct.pack_into('<I',new,offset,struct.unpack_from('<I',definition.raw,offset)[0]+len(new)-len(definition.raw))
    assert frame_source(bytes(new)).body==body;definitions.append(bytes(new))
plans=[('valid-called',False,False,False,False),('bad-called',True,False,False,False),
       ('bad-uncalled-declared',True,True,False,False),('bad-uncalled-undeclared',True,True,True,False),
       ('bad-unassigned-caller',True,False,False,True)]
rows=[];requests=[];files={}
for case,bad,remove_calls,remove_instances,unassign in plans:
    directory=out/case;directory.mkdir();changed=source;replacements={'SCPI.Program.pou':definitions[int(bad)]}
    if remove_calls:replacements['MAIN.Program.pou']=bytes(without_calls)
    if remove_instances:
        doc=parse_declarations(streams['MAIN.Labels.lh'],logical_name='MAIN.Labels.lh')
        replacements['MAIN.Labels.lh']=serialize_declarations(edit_declarations(doc,remove=['SCPI_1','SCPI_2']))
    if unassign:
        raw=streams['MAIN.tsk'];assert struct.unpack_from('<I',raw,84)[0]==1
        replacements['MAIN.tsk']=raw[:84]+struct.pack('<I',0)
    receipts=[]
    for logical,new in replacements.items():
        changed,receipt=patch_raw(changed,logical,streams[logical],new);receipts.append(receipt)
    assert {s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}==dict(streams,**replacements)
    path=directory/'input.gxw';path.write_bytes(changed)
    (directory/'mutation.json').write_text(json.dumps(dict(source_sha256=sha256(source),changed_sha256=sha256(changed),bad=bad,
        remove_calls=remove_calls,remove_instances=remove_instances,unassign=unassign,receipts=receipts,unrelated_payloads='byte-identical'),indent=2),encoding='utf-8')
    for attempt in range(1,9):
        native=directory/('native' if attempt==1 else 'native-v'+str(attempt))
        result=run(path,native,compile=True,snapshot_frontend=True,export_project=True,project_alias='QFBDEPENDENCY')
        events=[json.loads(s) for s in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
        if (native/'pcode-0-0.bin').exists() or not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
    row=dict(case=case,native_directory=str(native.relative_to(out)),native={k:result[k] for k in ('returncode','open_succeeded','compile_completed','compiler_rejected','diagnostics')})
    if row['native']['returncode']==0 and row['native']['compile_completed'] and not row['native']['compiler_rejected']:
        files[case]={}
        for f in sorted(native.glob('pcode-*.bin')):
            raw=f.read_bytes();files[case][f.name]=len(requests)
            requests.append(dict(mode='decode',input_base64=base64.b64encode(raw+b'\0').decode()))
    rows.append(row);(directory/'comparison.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
    print(json.dumps(row),flush=True)
answers=native_batch(requests,out/'native-pcode-decode',dll=Q_DLL,cpu_code=209)
decoded=[]
for request,answer in zip(requests,answers,strict=True):
    assert answer['return_code']=='0x00000000' and answer['consumed_bytes']==len(base64.b64decode(request['input_base64']))-1
    projection=native_il_projection(base64.b64decode(answer['output_base64']),encoding='cp949');assert not projection['text_gaps'];decoded.append(projection['records'])
(out/'comparison.json').write_text(json.dumps(dict(cases=rows,files=files,decoded=decoded,scope=__doc__),ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(record_counts={case:{name:len(decoded[i]) for name,i in units.items()} for case,units in files.items()})),flush=True)
