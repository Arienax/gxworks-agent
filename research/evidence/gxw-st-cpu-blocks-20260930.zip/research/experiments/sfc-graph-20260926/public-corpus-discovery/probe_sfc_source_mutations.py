"""Predict edits to converted branches and unconverted source grids, preserving opaque bytes."""
from pathlib import Path
import json
import struct
import sys
ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'research')]
from gxw.lossless import inspect_project, sha256
from gxw.token_pou import parse_token_fragment
from probe_gxw_sfc_sources import framing
from probe_gxw_sfc_graph import compiled_graph, patch_raw
from replay_gxw_workspace import run
from source_fx_sfc_projection import project_projection
from probe_pending_sfc_source_chars import source_chars

P = Path(__file__).resolve().parent
OUT = P/'sfc-source-targeted-mutations'


def program(source):
    return next(s for s in inspect_project(source).streams if (s.logical_name or '').endswith('.pou'))


def virtual_converted_source(raw, tokens):
    _, info = source_chars(raw); frame = framing(raw); start = frame['graph']['offset']
    cache = raw[info['cache_offset']:info['cache_offset'] + info['cache_bytes']]
    block = struct.pack('<IIII', 16 + len(tokens) + len(cache), 0, 0, len(tokens) + 4) + tokens + cache
    result = raw[:start - 4] + struct.pack('<I', len(block)) + block + raw[start + frame['graph']['size']:]
    compiled_graph(result)
    return result


def main():
    OUT.mkdir(exist_ok=False)
    for f in [Path(__file__), P/'source_fx_sfc_projection.py', P/'probe_pending_sfc_source_chars.py']:
        (OUT/f.name).write_bytes(f.read_bytes())
    plans = []
    for tag in ['parallel', 'selective']:
        path = P.parent/f'{tag}-project-1/native/native-saved.gxw'; source = path.read_bytes(); s = program(source)
        frame = framing(s.raw); updated = bytearray(s.raw)
        # Change transition-number identities while retaining all code bodies.
        for c in frame['children']:
            if c['kind'] == 'transition' and c['number'] in (0, 1):
                struct.pack_into('<I', updated, c['size_offset'] - 8, 1 - c['number'])
        plans.append((tag+'-swap-transition-references', path, source, s, bytes(updated), None))
    path = P.parent/'three-steps-reopen.gxw'; source = path.read_bytes(); s = program(source)
    chars, info = source_chars(s.raw); frame = framing(s.raw); start = info['source_offset']
    prior = P/'pending-sfc-source-chars-v3/three-steps-reopen/native-1/sfc-encoded-tokens.bin'
    graph_tokens = prior.read_bytes()
    updated = bytearray(s.raw); jump = next(c for c in info['cells'] if c['y'] == 9 and c['x'] == 0)
    assert bytes.fromhex(jump['raw']) == bytes.fromhex('6f0100')
    struct.pack_into('<H', updated, start + jump['offset'] + 1, 0)
    assert graph_tokens.endswith(bytes.fromhex('056202000504980104056c010a05'))
    predicted_graph = graph_tokens[:-9] + bytes.fromhex('04980004056c010a05')
    plans.append(('pending-FX-jump-target0', path, source, s, bytes(updated), predicted_graph))
    updated = bytearray(s.raw); offset = start + 15368 + 7*2 + 1
    assert struct.unpack_from('<H', updated, offset)[0] == 20
    struct.pack_into('<H', updated, offset, 30)
    action, = [a for a in frame['actions'] if a['number'] == 20]
    struct.pack_into('<I', updated, action['number_offset'], 30)
    assert graph_tokens.count(bytes.fromhex('04981404')) == 1
    predicted_graph = graph_tokens.replace(bytes.fromhex('04981404'), bytes.fromhex('04981e04'))
    plans.append(('pending-FX-action30', path, source, s, bytes(updated), predicted_graph))
    path = P.parent/'q00j-transition-converted.gxw'; source = path.read_bytes(); s = program(source)
    chars, info = source_chars(s.raw); updated = bytearray(s.raw); start = info['source_offset']
    assert chars[6:8] == b'\x03\0' and chars[98:101] == b'\0'*3
    updated[start + 98:start + 101] = bytes.fromhex('6fe703')
    struct.pack_into('<H', updated, start + 6, 4)
    predicted_graph = bytes.fromhex('056c02170504980004056c0204050499000405620200050598e70305056c010a05')
    plans.append(('pending-Q-add-end', path, source, s, bytes(updated), predicted_graph))
    ready = []
    for tag, path, source, stream, updated, predicted_graph in plans:
        directory = OUT/tag; directory.mkdir()
        changed, receipt = patch_raw(source, stream.logical_name, stream.raw, updated)
        (directory/'source.gxw').write_bytes(changed)
        if predicted_graph is None:
            candidate, projection = project_projection(changed)
        else:
            chars, info = source_chars(updated); (directory/'source-chars.bin').write_bytes(chars)
            (directory/'predicted-graph.bin').write_bytes(predicted_graph)
            converted = virtual_converted_source(updated, predicted_graph)
            virtual, _ = patch_raw(changed, stream.logical_name, updated, converted)
            candidate, projection = project_projection(virtual)
        (directory/'candidate.bin').write_bytes(candidate)
        differences = [dict(offset=i, before=a, after=b) for i, (a, b) in enumerate(zip(stream.raw, updated, strict=True)) if a != b]
        (directory/'prediction-before-native.json').write_text(json.dumps(dict(source=str(path), source_sha256=sha256(source),
            changed_sha256=sha256(changed), raw_changes=differences, receipt=receipt, candidate_sha256=sha256(candidate), projection=projection,
            prediction_scope='converted graphs: source expansion; pending grids: explicitly predicted graph edits plus source expansion'), indent=2), encoding='utf-8')
        ready.append((tag, directory, candidate, predicted_graph))
    results = []
    for tag, directory, candidate, predicted_graph in ready:
        for attempt in range(1, 5):
            native = directory/f'native-{attempt}'
            outcome = run(directory/'source.gxw', native, compile=True, change_sfc=True, program_check=True,
                snapshot_frontend=True, export_project=True, project_alias='SFCGRIDEDIT',
                sfc_graph_chars=directory/'source-chars.bin' if predicted_graph is not None else None)
            events = [json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
            if not any(e.get('operation') == 'NativeTemporaryDirectoryCollision' for e in events):
                break
        output = native/'pcode-0-0.bin'; encoded = native/'sfc-encoded-tokens.bin'
        row = dict(case=tag, native_directory=str(native), outcome=outcome,
            full_pcode_identical=output.exists() and output.read_bytes() == candidate,
            graph_prediction_identical=(encoded.exists() and encoded.read_bytes() == predicted_graph) if predicted_graph is not None else None)
        (directory/'comparison.json').write_text(json.dumps(row, indent=2), encoding='utf-8')
        results.append(row); (OUT/'comparison.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
        print(json.dumps(dict(**{k: v for k, v in row.items() if k != 'outcome'}, compile_completed=outcome['compile_completed'],
            program_check_completed=outcome['program_check_completed'], compiler_rejected=outcome['compiler_rejected'], diagnostics=outcome['diagnostics'])), flush=True)


if __name__ == '__main__':
    main()
