"""Test the two counted-string arrays observed at the end of a Q .tsk.

Fresh owned offline projects only. The hypothesis is serialized program names
followed by a parallel string array; the latter's role is not assumed. Native
frontend buffers and complete compiler outputs are retained to distinguish it.
"""
from pathlib import Path
import base64, json, struct, sys
ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'research')]
from gxw.lossless import inspect_project, sha256
from gxw.container_writer import validate_cfb_streams
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import run
from native_gxw_tokens import native_batch, native_il_projection, Q_DLL

P = Path(__file__).resolve().parent
out = P/'q-task-sequences'; out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
source = (P/'q-source-constant-edits/baseline-0/source.gxw').read_bytes()
assert not validate_cfb_streams(source).get('Project.gd2')
streams = {s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
task = '응용동작1.tsk'; old = streams[task]
A, B = '기본동작', '응용동작1'
def strings(values):
    result=struct.pack('<I',len(values))
    for value in values:
        text=(value+'\0').encode('utf-16le')
        result+=struct.pack('<I',len(text)//2)+text
    return result
assert old==old[:84]+strings([B])+strings([''])
plans=[('baseline',[B],['']),('single-named',[B],['FIRST']),
       ('two',[A,B],['','']),('reverse',[B,A],['','']),
       ('two-named',[A,B],['FIRST','SECOND']),('duplicate',[A,A],['','']),('empty',[],[])]
rows=[];requests=[];files={}
for case,names,extra in plans:
    directory=out/case;directory.mkdir()
    new=old[:84]+strings(names)+strings(extra)
    changed,receipt=(source,{'unchanged':True}) if new==old else patch_raw(source,task,old,new)
    payloads={s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}
    assert payloads==dict(streams,**{task:new})
    path=directory/'changed.gxw';path.write_bytes(changed)
    mutation=dict(task=task,source_sha256=sha256(source),changed_sha256=sha256(changed),
                  names=names,extra=extra,original_task_hex=old.hex(),changed_task_hex=new.hex(),container=receipt)
    (directory/'mutation.json').write_text(json.dumps(mutation,indent=2),encoding='utf-8')
    for attempt in range(1,9):
        native=directory/('native' if attempt==1 else 'native-v'+str(attempt))
        result=run(path,native,compile=True,snapshot_frontend=True,export_project=True,project_alias='QTASKSEQUENCE')
        events=[json.loads(s) for s in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
        if (native/'pcode-0-0.bin').exists() or not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
    row=dict(case=case,names=names,extra=extra,native_directory=str(native.relative_to(out)),
             native={k:result[k] for k in ('returncode','open_succeeded','compile_completed','compiler_rejected','diagnostics')})
    snapshot=native/'frontend-snapshot.json'
    if snapshot.exists():
        build=json.loads(snapshot.read_text(encoding='utf-8-sig'))['build']
        row['native_task_buffer']=next(r['data'] for r in build['relocations'] if r['offset']==36)
    if row['native']['compile_completed'] and not row['native']['compiler_rejected']:
        files[case]={}
        for f in sorted(native.glob('pcode-*.bin')):
            raw=f.read_bytes();files[case][f.name]=len(requests)
            requests.append(dict(mode='decode',input_base64=base64.b64encode(raw+b'\0').decode()))
    rows.append(row)
    (directory/'comparison.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in row.items() if k!='native_task_buffer'}),flush=True)
answers=native_batch(requests,out/'native-pcode-decode',dll=Q_DLL,cpu_code=209)
decoded=[]
for request,answer in zip(requests,answers,strict=True):
    assert answer['return_code']=='0x00000000' and answer['consumed_bytes']==len(base64.b64decode(request['input_base64']))-1
    projection=native_il_projection(base64.b64decode(answer['output_base64']),encoding='cp949')
    assert not projection['text_gaps'];decoded.append(projection['records'])
result=dict(cases=rows,files=files,decoded=decoded,scope=__doc__)
with (out/'comparison.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2,ensure_ascii=False)
print(json.dumps(dict(record_counts={case:{name:len(decoded[index]) for name,index in units.items()} for case,units in files.items()})),flush=True)
