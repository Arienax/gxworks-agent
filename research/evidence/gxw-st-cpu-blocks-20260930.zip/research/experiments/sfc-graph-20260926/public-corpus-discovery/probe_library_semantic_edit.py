"""Offline semantic library mutation starting with a native-compiled project."""
from pathlib import Path
import sys,json,base64
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from gxw.lossless import inspect_project,sha256
from probe_gxw_library_archive import decode_library_archive,encode_library_literals,frame_library_text,observed_source_body
from probe_gxw_library_sources import snapshot_library_pous
from gxw.container_writer import validate_cfb_streams,replace_project_stream
from gxw.project_metadata import logical_mapping,current_rows,md5_base64,synchronize_history
from replay_gxw_workspace import run
from probe_gxw_compiled_references import stored_records,native_batch,parse_token_fragment,native_il_projection,Q_DLL
P=Path(__file__).resolve().parent
baseline=P/'ST-standard-counter-controls/CTU'
out=P/'library-repack-controls/CTU-semantic-edit-v2'
out.mkdir(parents=True,exist_ok=False)
source=(baseline/'native/native-saved.gxw').read_bytes()
before={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
name=next(n for n in before if n.lower() in ('iecfunction.lif','iec.lif'))
raw=before[name];plain=decode_library_archive(raw[20:]).decoded
definitions=[d for d in frame_library_text(plain)['definitions'] if d['name']=='CTU' and (d['sections'] is None or 'Q03UDV' in d['sections'])]
assert len(definitions)==1
definition=definitions[0];old=b'INC_M\tCV';new=b'DEC_M\tCV'
assert len(old)==len(new) and definition['raw'].count(old)==1 and old in observed_source_body(definition)
offset=definition['offset']+definition['raw'].index(old)
changed_plain=plain[:offset]+new+plain[offset+len(old):]
packed=raw[:20]+encode_library_literals(changed_plain)
assert decode_library_archive(packed[20:]).decoded==changed_plain
# This native export has renamed the library in the current directory, but
# retained its original history name. Bind the observed exception by ID, old
# size and old digest; preserve that historical name. This is not a relaxation
# of the general-purpose project writer's name-binding rule.
outer=validate_cfb_streams(source);assert not outer.get('Project.gd2')
physical=logical_mapping(outer['projectdatalist.xml'])[name]
nested=validate_cfb_streams(outer['_hdb']);assert nested[physical]==raw
rows,_=current_rows(outer['history.xml'],'DSHISTORY','D_History')
matches=[r.fields() for r in rows if r.fields().get('iProjectdataID') and r.fields()['iProjectdataID'].text.strip()==physical]
assert len(matches)==1
fields=matches[0];history_name=fields['szProjectdataName'].text.strip()
assert (name,history_name)==('IEC.lif','IECFunction.lif')
assert fields['iFileSize'].text.strip()==str(len(raw)) and fields['szMD5val'].text.strip()==md5_base64(raw)
history,changes,preserved=synchronize_history(outer['history.xml'],{history_name:(physical,raw,packed)})
hdb,_=replace_project_stream(outer['_hdb'],physical,packed)
changed,_=replace_project_stream(source,'_hdb',hdb)
changed,_=replace_project_stream(changed,'history.xml',history)
assert validate_cfb_streams(hdb)==dict(nested,**{physical:packed})
assert validate_cfb_streams(changed)==dict(outer,_hdb=hdb,**{'history.xml':history})
receipt=dict(metadata_changes=changes,preserved_metadata=preserved,history_name_preserved=history_name,observed_current_name=name,physical_id=physical)
after={s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}
assert all(after[n]==b for n,b in before.items() if n!=name)
(out/'changed.gxw').write_bytes(changed)
(out/'mutation.json').write_text(json.dumps(dict(source_sha256=sha256(source),changed_sha256=sha256(changed),logical_name=name,source_offset=offset,old=old.decode(),new=new.decode(),source_prefix_suffix='byte-identical',unrelated_payloads='byte-identical',receipt=receipt),indent=2))
r=run(out/'changed.gxw',out/'native',compile=True,export_project=True,snapshot_frontend=True)
print(json.dumps(r),flush=True)
if not r.get('native_export') or r.get('compiler_rejected'):raise RuntimeError('semantic compile/export failed; evidence retained')
def snapshot(path):
 return {(x['library'],x['name']):x for x in snapshot_library_pous(json.loads(path.read_text(encoding='utf-8-sig')))}
original=snapshot(baseline/'native/frontend-snapshot.json');current=snapshot(out/'native/frontend-snapshot.json')
key=('@IEC','CTU');old_body=base64.b64decode(original[key]['program_raw_base64']);new_body=base64.b64decode(current[key]['program_raw_base64'])
comparison=dict(native_frontend_opcode_only=new_body==old_body.replace(old,new),unrelated_native_libraries_exact=all(current[k]==v for k,v in original.items() if k!=key),compile_path='project-owned compiler, ToBackward(1), fresh Initialize, Build(0,-1); no incremental-cache claim')
requests=[];differences=[]
for f in r['outputs']:
 a=(baseline/'native'/f).read_bytes();b=(out/'native'/f).read_bytes()
 if not a and not b:continue
 ga,sa=stored_records(parse_token_fragment(a,0,len(a)),encoding='cp1252');gb,sb=stored_records(parse_token_fragment(b,0,len(b)),encoding='cp1252')
 assert len(ga)==len(gb) and sa==sb
 for x,y in zip(ga,gb):
  assert (x['offset'],x['stored_step'],x['stored_width'])==(y['offset'],y['stored_step'],y['stored_width'])
  if x['raw']==y['raw']:continue
  row=dict(file=f,offset=x['offset'],stored_step=x['stored_step'],old_raw_hex=x['raw'].hex(),new_raw_hex=y['raw'].hex(),decode_index=len(requests))
  differences.append(row)
  requests.extend(dict(mode='decode',input_base64=base64.b64encode(g['raw']+b'\0').decode()) for g in (x,y))
answers=native_batch(requests,out/'native-decode-difference',dll=Q_DLL,cpu_code=209)
for d in differences:
 for side,answer in zip(('old','new'),answers[d['decode_index']:d['decode_index']+2]):
  assert answer['return_code']=='0x00000000'
  assert answer['consumed_bytes']==len(bytes.fromhex(d[side+'_raw_hex']))
  d[side+'_decoded']=native_il_projection(base64.b64decode(answer['output_base64']),encoding='cp1252')
comparison['pcode_differences']=differences
exported={s.logical_name:s.raw for s in inspect_project((out/'native/native-saved.gxw').read_bytes()).streams if s.logical_name}
export_name=next(n for n in exported if n.lower() in ('iecfunction.lif','iec.lif'))
comparison.update(exported_library_payload_exact=exported[export_name]==packed,exported_source_exact=decode_library_archive(exported[export_name][20:]).decoded==changed_plain)
(out/'comparison.json').write_text(json.dumps(comparison,indent=2))
print(json.dumps(comparison),flush=True)
reopen=run(out/'native/native-saved.gxw',out/'reopen',compile=True,export_project=True,snapshot_frontend=True)
comparison['reopen']=reopen
if reopen.get('native_export'):
 comparison['reopened_library_buffers_exact']=snapshot(out/'reopen/frontend-snapshot.json')==current
 comparison['reopened_pcode_exact']=all((out/'native'/f).read_bytes()==(out/'reopen'/f).read_bytes() for f in r['outputs'])
(out/'comparison.json').write_text(json.dumps(comparison,indent=2))
print(json.dumps(dict(reopen=bool(reopen.get('native_export')),reopened_pcode_exact=comparison.get('reopened_pcode_exact'))),flush=True)
