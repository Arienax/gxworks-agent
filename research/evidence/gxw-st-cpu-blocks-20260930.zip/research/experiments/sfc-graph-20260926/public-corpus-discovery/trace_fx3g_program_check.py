from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[4];sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from replay_gxw_workspace import prepare,trace_prepared
P=Path(__file__).resolve().parent;OUT=P/'fx3g-program-check-trace-v2';OUT.mkdir(exist_ok=False)
SCRIPT=r'''
const seen = new Set();
Process.attachModuleObserver({
  onAdded(m) {
    send({event: 'module', name: m.name, path: m.path});
    if (!/^ECCodeGenerator.*\.dll$/i.test(m.name)) return;
    for (const e of m.enumerateExports()) {
      if (e.type !== 'function' || !e.name.startsWith('Check')) continue;
      Interceptor.attach(e.address, {
        onLeave(r) {
          const key = m.name + '!' + e.name + ':' + r.toString();
          if (!seen.has(key)) {
            seen.add(key);
            send({event: 'check-return', module: m.name, name: e.name, result: r.toString()});
          }
        }
      });
    }
  }
});
'''
script=OUT/'trace.js';script.write_text(SCRIPT,encoding='utf-8');(OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
for attempt in range(1,5):
 native=OUT/f'native-{attempt}';prepare(P/'fx3g-without-modbus-task/candidate.gxw',native,compile=True,export_project=True,program_check=True,project_alias='CHECKTRACE');trace=trace_prepared(native,script)
 events=[json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
 if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
messages=[json.loads(l) for l in (native/'events.jsonl').read_text(encoding='utf-8').splitlines()];payloads=[r['payload'] for r in messages if r.get('type')=='send'];summary=dict(trace=trace,checks=[r for r in payloads if r['event']=='check-return'],modules=[r for r in payloads if r['event']=='module' and 'GXWORKS2' in r['path'].upper()],last_event=events[-1]);(OUT/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');print(json.dumps(dict(trace=trace,checks=summary['checks'],modules=[r['name'] for r in summary['modules']],last_event=events[-1]),ensure_ascii=True))
