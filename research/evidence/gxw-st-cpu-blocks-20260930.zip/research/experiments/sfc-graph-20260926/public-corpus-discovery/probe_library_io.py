from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from replay_gxw_workspace import prepare,trace_prepared
P=Path(__file__).resolve().parent
out=P/'library-io-trace'
prepare(P/'native-allocation-inventory/case-00/input.gxw',out,snapshot_frontend=True)
print(json.dumps(trace_prepared(out,P/'TraceLibraryIO.js',timeout=45)))
for line in (out/'events.jsonl').read_text(encoding='utf-8').splitlines():print(line)
