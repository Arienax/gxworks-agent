"""Query every linked step in real Q/FX/simple/ST offline controls."""
from collections import Counter
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from gxw.compiler_debug import parse_compiler_debug
from gxw.lossless import inspect_project,sha256
from probe_gxw_debug_locations import lookup
from probe_gxw_native_listing import project_text_context
from replay_gxw_workspace import run
P=Path(__file__).resolve().parent
OUT=P/'compiled-source-map-real-controls';OUT.mkdir(exist_ok=True)
for name,filename,case in [('q','project2.gxw','case-02'),('fx3u','modbus-master.gxw','case-01'),
                           ('fx1s','stepper-2-1.gxw','case-04'),('st','boxid.gxw','case-00')]:
    if (OUT/name/'comparison.json').exists():continue
    source=P/'samples'/filename
    context=project_text_context(next(s.raw for s in inspect_project(source.read_bytes()).streams if (s.logical_name or '').endswith('.prj')))
    previous=P/'native-reference-real-corpus'/case/'native'
    if name=='fx1s':previous=P/'fx1s-reference-native-idle-control/native'
    debug=parse_compiler_debug((previous/'compiler_DZComp/DebugInformation2.dat').read_bytes())
    ends={}
    for e in debug.elements:
        resource=e.resource_bytes.decode(context['text_encoding']);ends[resource]=max(ends.get(resource,0),e.linked_step_end)
    queries=[dict(resource=r,start_step=s,step_count=1,timestamp=0) for r,end in ends.items() for s in range(end+3)]
    if not queries:
        events=[json.loads(s) for s in (previous/'native-events.jsonl').read_text(encoding='utf-8').splitlines()]
        resources=[r['name'] for r in events if r['operation']=='Resource']
        queries=[dict(resource=r,start_step=s,step_count=1,timestamp=0) for r in resources for s in range(16)]
    assert len(queries)<=4096
    native=run(source,OUT/name,compile=True,export_project=True,project_alias='DEBUGLOCATION',pcode_location_queries=queries)
    row=dict(case=name,source_sha256=sha256(source.read_bytes()),native={k:native[k] for k in ['returncode','compile_completed','compiler_rejected','last_event','diagnostics']})
    answers=OUT/name/'native-pcode-locations.json'
    if answers.exists():
        debug=parse_compiler_debug((OUT/name/'compiler_DZComp/DebugInformation2.dat').read_bytes())
        comparisons=[]
        for a in json.loads(answers.read_text(encoding='utf-8-sig')):
            q=a['query'];ours=lookup(debug,q['resource'],q['start_step'],encoding=context['text_encoding'])
            comparable=ours['handling'] in ['native-compatible-simple-location','native-compatible-search-gap','no-stored-element']
            comparisons.append(dict(query=q,ours=ours,native=a['location'],native_code=a['code'],
                comparable=comparable,equal=ours['location']==a['location'] if comparable else None))
        (OUT/name/'independent-comparison.json').write_text(json.dumps(comparisons,indent=2),encoding='utf-8')
        row.update(queries=len(comparisons),handling=dict(Counter(r['ours']['handling'] for r in comparisons)),
                   native_success=sum(r['native_code']==0 for r in comparisons),
                   checked=sum(r['comparable'] for r in comparisons),differences=[r for r in comparisons if r['equal'] is False])
    (OUT/name/'comparison.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
    print(json.dumps(row),flush=True)
