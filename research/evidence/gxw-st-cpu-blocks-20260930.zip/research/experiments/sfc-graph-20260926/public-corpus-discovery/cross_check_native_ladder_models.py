"""Existing Core lowering versus independently recovered native cell graphs."""
from pathlib import Path
import base64
import itertools
import json
import random
import sys

ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from plc.ir import lower_rung_instructions
from native_gxw_tokens import native_batch
from native_gxw_ladder import native_ladder_batch
from check_native_ladder_boolean_graph import graph,evaluate

P=Path(__file__).resolve().parent
OUT=P/'native-ladder-model-cross-check'

def input_value(element, values):
    if element['type']=='parallel_block':
        return any(all(input_value(c,values) for c in branch) for branch in element['branches'])
    assert element['type'] in ('NO','NC')
    value=values[element['address']]
    return value if element['type']=='NO' else not value

def model_outputs(model, values):
    header=model['header_element']
    shared=([header] if header else [])+model['shared_inputs']
    enabled=all(input_value(e,values) for e in shared)
    return {o['address']:enabled and all(input_value(e,values) for e in b['inputs'])
            for b in model['branches'] for o in b['outputs']}

def main():
    OUT.mkdir(exist_ok=False)
    (OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    rng=random.Random(20260928)
    def contact():return dict(type=rng.choice(('NO','NC')),address='X'+str(rng.randrange(6)))
    def element():
        if rng.random()<.45:
            return dict(type='parallel_block',branches=[[contact() for _ in range(rng.randint(1,3))] for _ in range(rng.randint(2,3))])
        return contact()
    cases=[]
    for i in range(512):
        branches=rng.randint(1,3)
        header=contact() if rng.random()<.35 else None
        shared=[contact() for _ in range(rng.randint(0,2))]
        if branches>1 and not header and not shared:shared=[contact()]
        model=dict(rung_id=i+1,header_element=header,shared_inputs=shared,branches=[dict(
            branch_id=j+1,inputs=[element() for _ in range(rng.randint(0 if header or shared else 1,3))],
            outputs=[dict(type='COIL',address='Y'+str(j))]) for j in range(branches)])
        instructions=lower_rung_instructions(model)
        lines=[' '.join([r['op'],*r['args']]) for r in instructions]
        cases.append(dict(id=i,model=model,instructions=instructions,lines=lines))
    (OUT/'predictions-before-native.json').write_text(json.dumps(cases,indent=2),encoding='utf-8')
    enc=native_batch([dict(mode='encode',input_base64=base64.b64encode(('\0'.join(c['lines'])+'\0\0').encode('ascii')).decode())
                      for c in cases],OUT/'encode',cpu_code=521)
    assert all(r['return_code']=='0x00000000' for r in enc)
    requests=[dict(case=i,input_base64=base64.b64encode(base64.b64decode(r['output_base64'])+b'\0').decode()) for i,r in enumerate(enc)]
    native=native_ladder_batch(requests,OUT/'ladder')
    result=[]
    for i,(case,request,n) in enumerate(zip(cases,requests,native,strict=True)):
        row=dict(id=i,native=n,input_bytes=len(base64.b64decode(request['input_base64'])))
        if n['return_code']!='0x00000000':row['status']='native-rejected'
        elif n['consumed_bytes']!=row['input_bytes']:row['status']='partial-native-conversion'
        else:
            try:
                g=graph((OUT/'ladder'/f'{i:04}.cells.bin').read_bytes(),(OUT/'ladder'/f'{i:04}.tokens.bin').read_bytes(),n['metadata'])
                differences=[]
                for bits in itertools.product((False,True),repeat=6):
                    values=dict(zip(('X'+str(j) for j in range(6)),bits))
                    expected=model_outputs(case['model'],values);actual=evaluate(g,values)
                    if actual!=expected:differences.append(dict(inputs=values,expected=expected,actual=actual))
                row.update(status='different' if differences else 'equivalent',assignments=64,differences=differences)
            except ValueError as e:row.update(status='unsupported-grid',reason=str(e))
        result.append(row)
    (OUT/'comparison.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    from collections import Counter
    print(json.dumps(dict(cases=len(cases),statuses=dict(Counter(r['status'] for r in result)),
        non_equivalent=[dict(id=r['id'],status=r['status'],reason=r.get('reason'),first_difference=next(iter(r.get('differences',[])),None)) for r in result if r['status']!='equivalent'])))

if __name__=='__main__':main()
