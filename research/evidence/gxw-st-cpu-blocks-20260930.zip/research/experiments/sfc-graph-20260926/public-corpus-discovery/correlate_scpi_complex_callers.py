"""Independent caller-region reconstruction for mixed repeated SCPI enables."""
from pathlib import Path
import copy,json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256,inspect_project
from probe_gxw_simple_fb import frame_source
from probe_gxw_simple_fb_connections import inspect as inspect_connections
from probe_gxw_compiled_references import stored_records
from probe_gxw_callsite_inputs import compare_callsite_inputs
P=Path(__file__).resolve().parent
value_cases=[kind+'-'+order for kind in ['int','dint','string'] for order in ['literal-first','device-first']]
cases=(value_cases if 'values' in sys.argv else ['first','last'])
for case in cases:
 values=case in value_cases
 parent=P/('scpi-repeated-value-inputs' if values else 'scpi-repeated-complex-enable')/case
 source=(parent/'native/native-saved.gxw').read_bytes()
 connection_file=parent/'source-connections/connections.json'
 connections=json.loads(connection_file.read_text(encoding='utf-8')) if connection_file.exists() else inspect_connections(source,connection_file.parent)
 baseline=json.loads((P/('scpi-value-input-bindings-v2' if values else 'scpi-exact-instance-operands-v3')/case/'comparison.json').read_text())
 assert sha256(source)==baseline['export_sha256']==connections['source_sha256']
 streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
 entries=[]
 for original in baseline['expansions']:
  e=copy.deepcopy(original);name=e['parent']+'.Program.pou'
  groups,_=stored_records(frame_source(streams[name]),encoding='cp932')
  offsets=[g['offset'] for g in groups if g['stored_step']==e['parent_source_step']];assert len(offsets)==1
  calls=[c for p in connections['programs'] if p['name']==name for c in p['calls'] if c['offset']==offsets[0]];assert len(calls)==1
  call=calls[0];assert call['instance']==e['instance'] and call['definition']=='SCPI' and not call['gaps']
  allocations={b['component']:b['operand'] for r in e['rows'] for b in r['bindings'] if 'component' in b}
  inputs=call['connection_fragments']['input'];assert not inputs['text_gaps']
  lowering=compare_callsite_inputs(inputs['records'],call['ports'],e['parent_compiled_records'],allocations)
  overlay={b['port'].lower():b['operand'] for b in lowering['bindings']} if not lowering['gaps'] else {}
  output=call['connection_fragments']['output'];assert not output['text_gaps'] and not output['uninterpreted_groups']
  for b in output['bindings']:overlay[b['port'].lower()]=b['operand']
  corrected=exact=0
  for row in e['rows']:
   expected=copy.deepcopy(row['expected_records'])
   token_map={b['token']:overlay[b['component'].lower()] for b in row['bindings'] if b.get('component','').lower() in overlay}
   for s,t in zip(row['source_records'],expected):
    if s['kind']=='instruction':t['args']=[token_map.get(a,b) for a,b in zip(s['args'],t['args'])]
   row.update(callsite_expected_records=expected,callsite_exact=not row['gaps'] and not lowering['gaps'] and expected==row['compiled_records'])
   exact+=row['callsite_exact'];corrected+=row['callsite_exact'] and row['handling']=='lowering-difference'
  wrong=next(x for x in baseline['expansions'] if x['element']!=e['element'])
  negative=compare_callsite_inputs(inputs['records'],call['ports'],wrong['parent_compiled_records'],allocations)
  e.update(callsite=call,input_lowering=lowering,wrong_caller_negative=negative,
           callsite_summary=dict(source_groups=len(e['rows']),exact=exact,corrected_groups=corrected))
  entries.append(e)
 result=dict(case=case,source_sha256=sha256(source),expansions=entries)
 filename='callsite-comparison-v2.json' if 'v2' in sys.argv else 'callsite-comparison.json'
 (parent/filename).write_text(json.dumps(result,indent=2))
 print(json.dumps(dict(case=case,expansions=[dict(element=e['element'],**e['callsite_summary'],inputs=e['input_lowering']['bindings'],
  gaps=e['input_lowering']['gaps'],wrong_caller_gaps=e['wrong_caller_negative']['gaps']) for e in entries])))
