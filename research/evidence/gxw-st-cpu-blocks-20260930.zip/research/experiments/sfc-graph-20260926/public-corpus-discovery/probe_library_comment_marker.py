"""Distinguish reading the repacked project library from installation fallback."""
from pathlib import Path
import sys,json,base64
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from gxw.lossless import inspect_project,sha256
from probe_gxw_library_archive import decode_library_archive,encode_library_literals,frame_library_text,observed_source_body
from probe_gxw_library_sources import snapshot_library_pous
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import run
P=Path(__file__).resolve().parent
baseline=P/'ST-standard-counter-controls/CTU'
out=P/'library-repack-controls/CTU-comment-marker'
out.mkdir(parents=True,exist_ok=False)
source=(baseline/'changed.gxw').read_bytes()
before={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
name='IECFunction.lif';raw=before[name];plain=decode_library_archive(raw[20:]).decoded
definitions=[d for d in frame_library_text(plain)['definitions'] if d['name']=='CTU' and (d['sections'] is None or 'Q03UDV' in d['sections'])]
assert len(definitions)==1
definition=definitions[0];old=b'Up-counter';new=b'REPROBE000'
assert len(old)==len(new) and definition['raw'].count(old)==1
offset=definition['offset']+definition['raw'].index(old)
assert old in observed_source_body(definition)
changed_plain=plain[:offset]+new+plain[offset+len(old):]
assert changed_plain[:offset]==plain[:offset] and changed_plain[offset+len(old):]==plain[offset+len(old):]
packed=raw[:20]+encode_library_literals(changed_plain)
changed,receipt=patch_raw(source,name,raw,packed)
after={s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}
assert all(after[n]==b for n,b in before.items() if n!=name)
(out/'changed.gxw').write_bytes(changed)
(out/'mutation.json').write_text(json.dumps(dict(source_sha256=sha256(source),changed_sha256=sha256(changed),logical_name=name,source_offset=offset,old=old.decode(),new=new.decode(),source_prefix_suffix='byte-identical',unrelated_payloads='byte-identical',receipt=receipt),indent=2))
r=run(out/'changed.gxw',out/'native',compile=True,export_project=True,snapshot_frontend=True)
print(json.dumps(r),flush=True)
if not r.get('native_export'):raise RuntimeError('marker compile/export failed; evidence retained')
def snapshot(path):
 return {(x['library'],x['name']):x for x in snapshot_library_pous(json.loads(path.read_text(encoding='utf-8-sig')))}
original=snapshot(baseline/'native/frontend-snapshot.json');current=snapshot(out/'native/frontend-snapshot.json')
key=('@IEC','CTU');old_body=base64.b64decode(original[key]['program_raw_base64']);new_body=base64.b64decode(current[key]['program_raw_base64'])
same_pcode=all((baseline/'native'/f).read_bytes()==(out/'native'/f).read_bytes() for f in r['outputs'])
exported={s.logical_name:s.raw for s in inspect_project((out/'native/native-saved.gxw').read_bytes()).streams if s.logical_name}
export_name=next(n for n in exported if n.lower() in ('iecfunction.lif','iec.lif'))
comparison=dict(native_frontend_marker_only=new_body==old_body.replace(old,new),unrelated_native_libraries_exact=all(current[k]==v for k,v in original.items() if k!=key),native_pcode_equal_to_baseline=same_pcode,exported_logical_name=export_name,exported_library_payload_exact=exported[export_name]==packed,exported_source_exact=decode_library_archive(exported[export_name][20:]).decoded==changed_plain)
reopen=run(out/'native/native-saved.gxw',out/'reopen',compile=True,export_project=True,snapshot_frontend=True)
comparison['reopen']=reopen
if reopen.get('native_export'):
 comparison['reopened_library_buffers_exact']=snapshot(out/'reopen/frontend-snapshot.json')==current
 comparison['reopened_pcode_exact']=all((out/'native'/f).read_bytes()==(out/'reopen'/f).read_bytes() for f in r['outputs'])
(out/'comparison.json').write_text(json.dumps(comparison,indent=2))
print(json.dumps(comparison),flush=True)
