"""Mix real Q structured-text FB expansion with standard timer library bodies."""
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.declarations import parse_declarations,edit_declarations,serialize_declarations
from gxw.compiler_debug import parse_compiler_debug
from probe_gxw_st_sources import replace_observed_st
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_compiled_references import inspect
from probe_gxw_debug_locations import lookup,search_maps
from replay_gxw_workspace import run
P=Path(__file__).resolve().parent
OUT=P/'ST-standard-timer-controls';OUT.mkdir(exist_ok=True)
source=(P/'samples/boxid.gxw').read_bytes()
streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
program='POU_01.Program.pou';labels='POU_01.Labels.lh'
_,original=replace_observed_st(streams[program],'')
d=parse_declarations(streams[labels],logical_name=labels)
for case,timer_type,enable in [('TON','TON',None),('TON_HIGH','TON_HIGH',None),
        ('TON_E_default','TON_E',None),('TON_E_false','TON_E','FALSE'),('TON_E_symbol','TON_E','EnableProbe'),
        ('TON_E_true','TON_E','TRUE'),('TON_E_member_assign','TON_E',None),('TON_E_member_read','TON_E','TRUE')]:
    out=OUT/case;out.mkdir(exist_ok=True)
    if (out/'comparison.json').exists():continue
    call='TimerProbe('+('EN := '+enable+', ' if enable is not None else '')+'IN := TRUE, PT := T#1s);'
    if case=='TON_E_member_assign':call='TimerProbe.EN := TRUE;\r\n'+call
    if case=='TON_E_member_read':call+='\r\nEnableProbe := TimerProbe.ENO;'
    new,_=replace_observed_st(streams[program],original+'\r\n'+call+'\r\n')
    upserts=[dict(name='TimerProbe',data_type=timer_type,kind='function_block')]
    if enable=='EnableProbe' or case=='TON_E_member_read':upserts.append(dict(name='EnableProbe',data_type='BOOL'))
    replacements={program:new,labels:serialize_declarations(edit_declarations(d,upserts=upserts))}
    changed=source;receipts=[]
    for name,raw in replacements.items():
        changed,receipt=patch_raw(changed,name,streams[name],raw);receipts.append(receipt)
    after={s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}
    assert all(after[n]==raw for n,raw in streams.items() if n not in replacements)
    path=out/'changed.gxw';path.write_bytes(changed)
    (out/'mutation.json').write_text(json.dumps(dict(source_sha256=sha256(source),changed_sha256=sha256(changed),receipts=receipts,
        call=call,timer_type=timer_type,unrelated_payloads='byte-identical'),indent=2),encoding='utf-8')
    assignments=[dict(name=scope+'.'+symbol,keys=[dict(category=1,value=symbol),dict(category=4,value=scope)])
        for symbol,scope in [('TimerProbe','POU_01'),('TimerProbe.EN','POU_01'),('TimerProbe.ENO','POU_01'),
                             ('EN','POU_01.TimerProbe'),('ENO','POU_01.TimerProbe')]] if case in ('TON_E_true','TON_E_member_assign','TON_E_member_read') else None
    analysis=[dict(name='all',keys=[],symbol='',scope='',declared=0,plural=0)]
    if assignments:analysis.extend(dict(name=s,keys=[],symbol=s,scope='POU_01',declared=0,plural=0) for s in ['TimerProbe.EN','TimerProbe.ENO'])
    result=run(path,out/'native',compile=True,export_project=True,project_alias='STTIMER',assignment_queries=assignments,
        analysis_queries=analysis,analysis_version=3,
        pcode_location_queries=[dict(resource='MAIN',start_step=i,step_count=1,timestamp=0) for i in range(640)])
    comparison=dict(case=case,native={k:result[k] for k in ['returncode','compile_completed','compiler_rejected','diagnostics']})
    if result.get('native_export'):
        reopened=run(out/'native/native-saved.gxw',out/'reopen',compile=True,export_project=True)
        comparison['reopen']={k:reopened[k] for k in ['returncode','compile_completed','compiler_rejected','diagnostics']}
        comparison['reopen_pcode_equal']=result['outputs']==reopened['outputs']
        read=inspect(out/'native',out/'correlation');comparison['reader']=read['summary']
        debug=parse_compiler_debug(next(s.raw for s in inspect_project((out/'native/native-saved.gxw').read_bytes()).streams if s.logical_name=='DebugInformation2.dat'))
        comparison['elements']=[dict(index=i,kind=e.kind_code,names=[v.decode('cp1252') for v in e.names],fields=e.fields,rows=debug.offset_tables[e.offset_table_index].rows) for i,e in enumerate(debug.elements)]
        comparison['search_maps']=search_maps(debug,encoding='cp1252')
        actual=json.loads((out/'native/native-pcode-locations.json').read_text(encoding='utf-8-sig'))
        rows=[]
        for row in actual:
            q=row['query'];want=lookup(debug,q['resource'],q['start_step'],encoding='cp1252')
            rows.append(dict(query=q,reader=want,native=row,equal=want['location']==row['location']))
        (out/'location-comparison.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
        comparison['locations']=dict(total=len(rows),exact=sum(r['equal'] for r in rows),native_locations=sum(r['native']['location'] is not None for r in rows))
    (out/'comparison.json').write_text(json.dumps(comparison,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in comparison.items() if k not in ['elements','search_maps']}),flush=True)
