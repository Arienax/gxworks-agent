"""Change only a value-port connection guard; preserve body and failures."""
from pathlib import Path
import base64,json,struct,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from probe_gxw_simple_fb import frame_source,observe_calls
from probe_gxw_parameters import device_allocation_record
from probe_gxw_sfc_graph import patch_raw
from native_gxw_tokens import native_batch,Q_DLL
from replay_gxw_workspace import run
P=Path(__file__).resolve().parent
out=P/'scpi-guarded-condition-pairs';out.mkdir(exist_ok=False)
plans=[];requests=[]
for kind,value in [('literal','K123'),('device','D200')]:
 for label,guard in [('true',"'_TRUE"),('false',"'_FALSE"),('x1','X1')]:
  text=f"LD X1F\0OUT '_iEn\0LD {guard}\0MOV {value} '_iUnitNo"
  plans.append(dict(case=kind+'-'+label,kind=kind,guard=guard,value=value))
  requests.append(dict(mode='encode',text=text,input_base64=base64.b64encode(text.encode()+b'\0\0').decode()))
base=(P/'scpi-guarded-inputs/int-device/changed.gxw').read_bytes()
streams={s.logical_name:s.raw for s in inspect_project(base).streams if s.logical_name}
answers=native_batch(requests,out/'native-encode',dll=Q_DLL,cpu_code=209,native_versions=(25,),device_context=device_allocation_record(streams['Param.wpa']).raw)
for plan,answer in zip(plans,answers):
 parent=P/'scpi-guarded-inputs'/('int-'+plan['kind']);source=(parent/'changed.gxw').read_bytes()
 streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
 name='MAIN.Program.pou';frame=frame_source(streams[name]);call=observe_calls(frame)['calls'][0]
 assert answer['return_code']=='0x00000000'
 a=call['input_fragment']['offset'];b=a+call['input_fragment']['length'];replacement=base64.b64decode(answer['output_base64'])
 program=bytearray(frame.raw[:a]+replacement+frame.raw[b:]);delta=len(program)-len(frame.raw)
 for offset in [55,59]:struct.pack_into('<I',program,offset,struct.unpack_from('<I',frame.raw,offset)[0]+delta)
 changed,receipt=patch_raw(source,name,frame.raw,bytes(program))
 after={s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}
 assert all(after[k]==v for k,v in streams.items() if k!=name)
 directory=out/plan['case'];directory.mkdir();path=directory/'changed.gxw';path.write_bytes(changed)
 (directory/'mutation.json').write_text(json.dumps(dict(plan,source_sha256=sha256(source),changed_sha256=sha256(changed),receipt=receipt,unrelated_payloads='byte-identical'),indent=2))
 for attempt in range(1,9):
  target=directory/('native' if attempt==1 else 'native-v'+str(attempt))
  result=run(path,target,compile=True,export_project=True,project_alias='SCPIGUARDPAIR')
  events=[json.loads(l) for l in (target/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
  if (target/'pcode-0-0.bin').exists() or not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
 row=dict(plan,native_directory=str(target.relative_to(P)),native={k:result[k] for k in ['returncode','compile_completed','compiler_rejected','diagnostics','outputs']})
 if result.get('compile_completed') and not result.get('compiler_rejected'):
  row['complete_pcode_equal_to_X0_guard']=all(f.read_bytes()==(parent/'native'/f.name).read_bytes() for f in target.glob('pcode-*.bin'))
  saved={s.logical_name:s.raw for s in inspect_project((target/'native-saved.gxw').read_bytes()).streams if s.logical_name}
  row['input_fragment_preserved_on_export']=observe_calls(frame_source(saved[name]))['calls'][0]['input_fragment']['sha256']==sha256(replacement)
 (directory/'comparison.json').write_text(json.dumps(row,indent=2));print(json.dumps({k:v for k,v in row.items() if k!='native'}|dict(native={k:row['native'][k] for k in ['returncode','compile_completed','compiler_rejected','diagnostics']})),flush=True)
