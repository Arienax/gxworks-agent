"""Observe an existing isolated offline fixture in a fresh owned helper."""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from replay_gxw_workspace import prepare,trace_prepared
P=Path(__file__).resolve().parent
case=sys.argv[1] if len(sys.argv)>1 else 'word-bit-dynamic'
parent=P/'array-operand-controls'/case
tag=sys.argv[2] if len(sys.argv)>2 else 'all-template'
hook={'all-template':'TraceAllTemplateOperands.js','boolean-call':'TraceBooleanCallLowering.js','real-conversion':'TraceRealConversion.js'}[tag]
for attempt in range(1,9):
 out=parent/(f'{tag}-trace' if attempt==1 else f'{tag}-trace-v{attempt}')
 if out.exists():continue
 prepare(parent/'changed.gxw',out,compile=True,export_project=True)
 result=trace_prepared(out,P/hook,timeout=55)
 native=[json.loads(l) for l in (out/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
 if (out/'pcode-0-0.bin').exists():break
 if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in native):raise RuntimeError('Unexpected trace failure retained')
else:raise RuntimeError('Fresh process collision bound reached')
events=[json.loads(l) for l in (out/'events.jsonl').read_text().splitlines()]
result.update(pcode_equal=all(p.read_bytes()==(parent/'native'/p.name).read_bytes() for p in out.glob('pcode-*.bin')),
 rows=[e['payload'] for e in events if e.get('payload',{}).get('event')=='all-template-operand' or e.get('payload',{}).get('event','').startswith(('call-specialized-','real-'))],
 errors=[e for e in events if e.get('type')=='error'])
(out/'comparison.json').write_text(json.dumps(result,indent=2))
preview=result['rows'][:8] if tag=='real-conversion' else result['rows']
print(json.dumps(dict(output=str(out),pcode_equal=result['pcode_equal'],row_count=len(result['rows']),rows=[{k:v for k,v in r.items() if k not in ('stack','nodes','before_nodes','after_nodes')} for r in preview],errors=result['errors'])))
