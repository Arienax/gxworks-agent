// Observe CRT conversions through the compiler's resolved import addresses.
(()=>{
'use strict';const active=new Map(),crtHooks=new Set();let seq=0;
function crtAttach(address,callbacks){const key=address.toString();if(crtHooks.has(key))return;crtHooks.add(key);const m=Process.findModuleByAddress(address);send({event:'real-runtime-import',module:m.name,path:m.path,rva:address.sub(m.base).toString()});Interceptor.attach(address,callbacks);}
function str(p,n){try{let s='';for(let i=0;i<n;i++){const c=p.add(i).readU8();if(!c)return s;if(c>127)return null;s+=String.fromCharCode(c);}}catch(_){}return null;}
function hex(p,n){return Array.from(new Uint8Array(p.readByteArray(n)),v=>v.toString(16).padStart(2,'0')).join('');}
function loc(p){const m=Process.findModuleByAddress(p);return m?{module:m.name,rva:p.sub(m.base).toString()}:null;}
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()==='eccodegenerator2.dll'){
  Interceptor.attach(m.base.add(0x4bb7f),{onEnter(a){
   if(!active.get(this.threadId))return;this.value=this.context.esp.add(8);this.row={event:'real-codegen-range-conversion',sequence:++seq,kind:a[0].toUInt32()&255,input_binary64_hex:hex(this.value,8),caller:loc(this.returnAddress)};
  },onLeave(r){if(this.row){this.row.rounded_binary64_hex=hex(this.value,8);this.row.result_u16=r.toUInt32()&65535;send(this.row);}}});
 }
 if(m.name.toLowerCase()!=='eccompiler_iec.dll')return;
 Interceptor.attach(m.findExportByName('Compile'),{onEnter(a){this.prior=active.get(this.threadId);const names=[];const n=a[1].toInt32();if(n>=0&&n<=1024)for(let i=0;i<n;i++)names.push(str(a[2].add(i*28+8).readPointer(),512));active.set(this.threadId,names.includes('POU_01'));},onLeave(){active.set(this.threadId,this.prior);}});
 Interceptor.attach(m.base.add(0xa5650),{onEnter(a){
  if(!active.get(this.threadId)||a[0].toInt32()!==0x112)return;this.out=a[2];this.typ=a[3];this.ref=a[1].toInt32();
 },onLeave(r){if(this.out&&[9,10].includes(this.typ.readS32()))send({event:'real-constant-descriptor',sequence:++seq,reference:this.ref,type:this.typ.readS32(),raw_hex:hex(this.out,25),result:r.toInt32()});}});
 crtAttach(m.base.add(0x11636c).readPointer(),{onEnter(a){
  if(!active.get(this.threadId))return;const format=str(a[1],128);
  if(!format||!/%[-+ #0-9.]*[eEgGfF]/.test(format)||format.replace(/%[-+ #0-9.]*[eEgGfF]/,'').includes('%'))return;
  this.out=a[0];this.row={event:'real-sprintf',sequence:++seq,format,input_binary64_hex:hex(this.context.esp.add(12),8),caller:loc(this.returnAddress)};
 },onLeave(r){if(this.row){this.row.output=str(this.out,512);this.row.length=r.toInt32();send(this.row);}}});
 crtAttach(m.base.add(0x116348).readPointer(),{onEnter(a){
  if(!active.get(this.threadId))return;this.out=a[3];this.row={event:'real-gcvt',sequence:++seq,precision:a[2].toInt32(),input_binary64_hex:hex(this.context.esp.add(4),8),caller:loc(this.returnAddress)};
 },onLeave(){if(this.row){this.row.output=str(this.out,512);send(this.row);}}});
 for(const [name,rva] of [['atof',0x11630c],['strtod',0x1162b8]])crtAttach(m.base.add(rva).readPointer(),{onEnter(a){
  if(!active.get(this.threadId))return;const input=str(a[0],256);if(input&&/[.eE]/.test(input)&&/^[-+0-9.eE]+$/.test(input))send({event:'real-'+name,sequence:++seq,input,caller:loc(this.returnAddress)});
 }});
}});
})();
