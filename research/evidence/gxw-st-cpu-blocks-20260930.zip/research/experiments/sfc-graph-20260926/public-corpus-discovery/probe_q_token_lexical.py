"""Compare a table-driven Q header projection with real native-decoded source.

Only lexical names/arity are projected here. Raw records remain authoritative;
the observed table does not prove instruction availability or execution effects.
"""
from pathlib import Path
import base64,collections,json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.token_pou import parse_token_fragment
from gxw.lossless import sha256
from probe_gxw_compiled_references import stored_records
from native_gxw_tokens import native_il_projection
P=Path(__file__).resolve().parent
CATALOG=json.loads((P/'q-token-catalog-v2/catalog.json').read_text())
LOOKUP={(e['family'],e['variant']):CATALOG['rows'][e['index']] for e in CATALOG['edges'] if e['index'] is not None}
OPERANDS={int(r['code'],16):r for r in json.loads((P/'q-token-catalog-v2/operand-catalog.json').read_text())['rows']}


def header_name(raw):
 """Observed native 0x3dcb7 dispatch with unsupported modifiers kept opaque."""
 result=dict(raw_hex=raw.hex(),handling='opaque-preserved',name=None,arity=None)
 if raw==b'\x02\x02':return dict(result,handling='decoded',name='NOP',arity=0)
 if len(raw)<3 or raw[0]!=len(raw) or raw[-1]!=len(raw):return result
 if raw[1] in (0x3c,0x3f) or raw[1]>=0x80:return result
 variant=raw[3] if len(raw)>=5 else 0
 modifier=raw[4] if len(raw)>=6 else 0xff
 desc=LOOKUP.get((raw[1],variant))
 if desc is None or modifier not in (0xff,2,0x10,0x11,0x12,0x0a):return result
 if modifier==0x0a and not (len(desc['name'])>1 and desc['name'][1]=='.'):return result
 name=desc['name'];suffix=raw[5:-1]
 if len(name)>1 and name[1]=='.':
  try:name=name+suffix.decode('ascii')
  except UnicodeDecodeError:return result
 elif len(raw)>6:return result
 if modifier==2:
  if len(desc['name'])>1 and desc['name'][1]=='.':name=name[0]+'P'+name[1:]
  elif raw[1]!=0x65 or variant not in (5,6,7,0x22,0x23,0x48,0x49):name+='P'
 elif modifier in (0x10,0x11,0x12):name={0x10:'LD',0x11:'AND',0x12:'OR'}[modifier]+name
 else:name=name.removeprefix(',')
 return dict(result,handling='decoded',name=name,arity=desc['fields'][0],descriptor_index=desc['index'])


def operand_atom(raw, *, encoding):
 """0x3e283 numeric/text projection; float display stays opaque for now."""
 if len(raw)<3 or raw[0]!=len(raw) or raw[-1]!=len(raw):return None
 code=raw[1];value=raw[2:-1]
 if code in (0xdf,0xee):
  # The Q string formatter replaces one final NUL by the closing quote;
  # empty strings have an observed one-NUL payload (0x3e326..0x3e358).
  if code==0xee and value.endswith(b'\0'):value=value[:-1]
  try:text=value.decode(encoding)
  except (UnicodeError,LookupError):return None
  if '\0' in text:return None
  return "'"+text if code==0xdf else '"'+text+'"'
 desc=OPERANDS.get(code)
 if desc is None:return None
 kind=desc['format_kind'];prefix=desc['name']
 if kind==6:return prefix if code in (0xf3,0xf5) else None
 if kind not in (0,1,4) or not 1<=len(value)<=4:return None
 if code==0xe8 and len(value)>2:return None
 # E8 uses signed 16 bits only for two payload bytes. E9 uses a signed
 # DWORD after zero extension of shorter encodings (0x3df49, 0x3e4f5).
 signed=kind==1 and len(value)==(2 if code==0xe8 else 4)
 number=int.from_bytes(value,'little',signed=signed)
 if kind==4:
  number=format(number,'X')
  if code!=0xf2 and number[0] in 'ABCDEF':number='0'+number
 return prefix+str(number)


def operand_groups(tokens, *, encoding):
 """Bound one lexical operand at each base, preserving modifier raw order."""
 groups=[];prefix='';index=None;bit=None;raw=[]
 for token in tokens:
  code=token.raw[1];text=operand_atom(token.raw,encoding=encoding)
  if text is None:return None
  raw.append(token.raw.hex())
  if code in (0xf0,0xf6):
   if index is not None:return None
   index=text
  elif code==0xf2:
   if bit is not None:return None
   bit=text
  elif code in (0xf1,0xf3):prefix+=text
  elif code in (0xf8,0xf9,0xfc):prefix+=text+'\\'
  elif 0x90<=code<=0xef:
   groups.append(dict(text=prefix+text+(index or '')+(bit or ''),raw_hex=raw))
   prefix='';index=bit=None;raw=[]
  else:return None
 return None if raw else groups


def group_record(raw, *, encoding):
 frame=parse_token_fragment(raw,0,len(raw));tokens=frame.tokens
 if not tokens:return None
 header=tokens[0].raw
 if header[1] in (0x80,0x82) and len(header)>=4 and len(tokens)==1:
  try:text=header[3:-1].decode(encoding)
  except (UnicodeError,LookupError):return None
  if '\0' in text:return None
  return dict(kind='statement' if header[1]==0x80 else 'note',text=text)
 if len(header) in (3,4) and header[1]==0x3c and len(tokens)==2 and tokens[1].raw[1] in (0xd0,0xd1):
  text=operand_atom(tokens[1].raw,encoding=encoding)
  return dict(kind='label',text=text) if text is not None else None
 head=header_name(header);operands=operand_groups(tokens[1:],encoding=encoding)
 if head['name'] is None or operands is None or len(operands)!=head['arity']:return None
 return dict(kind='instruction',op=head['name'],args=[o['text'] for o in operands])


if __name__=='__main__':
 out=P/'q-real-header-comparison';out.mkdir(exist_ok=False)
 native=P/'noeul-native-token-decode'
 requests=json.loads((native/'requests.json').read_text(encoding='utf-8'))['requests']
 answers=[json.loads(s) for s in (native/'native-stdout.jsonl').read_text(encoding='utf-8').splitlines()]
 cases=[];counts=collections.Counter();shapes=collections.defaultdict(collections.Counter);gaps=[];examples={}
 for index,(request,answer) in enumerate(zip(requests,answers)):
  body=base64.b64decode(request['input_base64'])[:-1]
  assert request['body_sha256']==sha256(body) and answer['return_code']=='0x00000000' and answer['consumed_bytes']==len(body)
  records=native_il_projection(base64.b64decode(answer['output_base64']),encoding='cp949')
  assert not records['text_gaps']
  assert records['records']==json.loads((native/f'records-{index}.json').read_text(encoding='utf-8'))
  groups,_=stored_records(parse_token_fragment(body,0,len(body)),encoding='cp949')
  assert len(groups)==len(records['records'])
  rows=[]
  for group,actual in zip(groups,records['records']):
   frame=parse_token_fragment(group['raw'],0,len(group['raw']));tokens=frame.tokens
   header=header_name(tokens[0].raw)
   exact=actual['kind']=='instruction' and header['name']==actual['op'] and header['arity']==len(actual['args'])
   counts['records']+=1;counts['header_exact']+=exact
   row=dict(offset=group['offset'],raw_hex=group['raw'].hex(),header=header,native=actual,header_exact=exact)
   rows.append(row)
   if not exact:gaps.append(dict(case=index,**row))
   if actual['kind']=='instruction' and len(tokens)-1==len(actual['args']):
    for token,argument in zip(tokens[1:],actual['args']):
     key=(token.raw[1],len(token.raw));shapes[key][argument.split(' ')[0][:1]]+=1
     examples.setdefault(key,[])
     if len(examples[key])<5:examples[key].append(dict(raw_hex=token.raw.hex(),native=argument))
   else:counts['multi_token_operand_records']+=1
  cases.append(dict(index=index,body_sha256=sha256(body),provenance=request['provenance'],rows=rows))
 operand_shapes=[dict(code=hex(k[0]),length=k[1],count=sum(v.values()),prefixes=dict(v),examples=examples[k]) for k,v in sorted(shapes.items())]
 result=dict(summary=dict(counts),cases=cases,gaps=gaps,operand_shapes=operand_shapes)
 with (out/'comparison.json').open('x') as f:json.dump(result,f,indent=2)
 print(json.dumps(dict(summary=dict(counts),gap_examples=gaps[:3],operand_shapes=operand_shapes)))
