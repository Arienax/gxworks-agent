"""Bind ProgramCheck's actual workspace reads to current and exported code.

Only attach a newly spawned owned offline helper. Workspace.GetPCode ABI is
from the installed type library (slot 1720, 48-byte resource ID, three buffers).
No calls are injected by the trace; the native reader's own results are copied.
"""
from pathlib import Path
import argparse
import json
import sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from replay_gxw_workspace import prepare,trace_prepared,source_output_context
from gxw.lossless import inspect_project,sha256
from gxw.token_resource import parse_token_resource

SCRIPT=r'''
let serial=0,phase='startup',checkIndex=-1,checkTarget=null;
function id(a){return Array.from({length:12},(_,i)=>a[i+1].toUInt32());}
function loc(p){const m=Process.findModuleByAddress(p);return m?{module:m.name,rva:p.sub(m.base).toString()}:{address:p.toString()};}
function hex(p,n){if(n<0||n>16777216)throw new Error('buffer bound');return Array.from(new Uint8Array(p.readByteArray(n)),b=>b.toString(16).padStart(2,'0')).join('');}
Process.attachModuleObserver({onAdded(m){
  const name=m.name.toLowerCase();
  if(name==='dzdataabs_compileradapter.dll')Interceptor.attach(m.base.add(86113),{
    onEnter(a){checkIndex++;phase='check';checkTarget=id(a);send({event:'check-start',serial:serial++,check_index:checkIndex,target:checkTarget,kind:a[13].toUInt32()});}
  });
  if(name!=='dzdataabs_workspace.dll')return;
  Interceptor.attach(m.base.add(0x8663c),{
    onEnter(a){phase=checkIndex<0?'publish-before-check':'publish-before-export';send({event:'publish',serial:serial++,phase:phase,target:id(a)});}
  });
  Interceptor.attach(m.base.add(0x78d08),{
    onEnter(a){
      try{
        this.row={event:'workspace-pcode-read',serial:serial++,phase:phase,check_index:checkIndex,
          check_target:checkTarget,target:id(a),caller:loc(this.returnAddress),
          stack:Thread.backtrace(this.context,Backtracer.ACCURATE).slice(0,12).map(loc)};
        this.sizes=[a[13],a[15],a[17]];this.buffers=[a[14],a[16],a[18]];this.code=a[19];
        this.row.requested_sizes=this.sizes.map(p=>p.isNull()?null:p.readS32());
      }catch(e){send({event:'observation-error',error:String(e)});}
    },
    onLeave(r){if(!this.row)return;try{
      const code=this.code.readS32();
      this.row.hresult=r.toInt32();this.row.code=code;
      this.row.buffers=this.sizes.map((p,i)=>{const n=p.isNull()?null:p.readS32();return {size:n,
        raw_hex:code===0&&r.toInt32()>=0&&!this.buffers[i].isNull()&&n!==null?hex(this.buffers[i],n):null};});
      send(this.row);
    }catch(e){send({event:'observation-error',error:String(e)});}}
  });
}});
'''

def resource_regions(source):
    rows=[]
    for s in inspect_project(source).streams:
        if not (s.logical_name or '').endswith('.res'):continue
        row=dict(name=s.logical_name,sha256=sha256(s.raw))
        try:
            parsed=parse_token_resource(s.raw)
            row['regions']=[dict(offset=o,size=n,sha256=sha256(s.raw[o:o+n])) for o,n in parsed.code_spans]
        except ValueError as e:row['unsupported']=str(e)
        rows.append(row)
    return rows

def inspect_run(native):
    events=[json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    messages=[json.loads(l) for l in (native/'events.jsonl').read_text(encoding='utf-8').splitlines()]
    errors=[m for m in messages if m.get('type')=='error' or m.get('payload',{}).get('event')=='observation-error']
    trace=[m['payload'] for m in messages if m.get('type')=='send']
    names={tuple(e['id']):e['name'] for e in events if e.get('operation')=='NativeObject'}
    generated={e['name']:dict(index=e['index'],channels=[(native/f'pcode-{e["index"]}-{i}.bin').read_bytes() for i in range(3)])
        for e in events if e.get('operation')=='Resource'}
    reads=[]
    for r in trace:
        if r.get('event')!='workspace-pcode-read':continue
        name=names.get(tuple(r['target']));g=generated.get(name)
        row={k:v for k,v in r.items() if k!='buffers'}
        row['resource_name']=name;row['buffers']=[]
        for i,b in enumerate(r['buffers']):
            raw=None if b['raw_hex'] is None else bytes.fromhex(b['raw_hex'])
            if raw is not None:(native/f'checked-read-{r["serial"]}-{i}.bin').write_bytes(raw)
            row['buffers'].append(dict(size=b['size'],sha256=None if raw is None else sha256(raw),
                matches_current=None if raw is None or g is None else raw==g['channels'][i]))
        reads.append(row)
    check=next((e for e in reversed(events) if e.get('operation')=='ProgramCheckCompleted'),None)
    exported=native/'native-saved.gxw'
    source=(native/'input.gxw').read_bytes()
    result=dict(check=check,trace_errors=errors,last_event=events[-1] if events else None,
        input_sha256=sha256(source),input_resources=resource_regions(source),
        generated=[dict(name=k,index=v['index'],channels=[dict(size=len(b),sha256=sha256(b)) for b in v['channels']]) for k,v in generated.items()],
        source_context=source_output_context(source,{k:v['channels'][0] for k,v in generated.items()}),
        check_starts=[r for r in trace if r.get('event')=='check-start'],resource_reads=reads,
        exported_sha256=sha256(exported.read_bytes()) if exported.exists() else None,
        exported_resources=resource_regions(exported.read_bytes()) if exported.exists() else None,
        diagnostics=[dict(phase=e['operation'],**r) for e in events for r in e.get('reports',[]) if r.get('kind') in (2,3)])
    (native/'resource-correspondence.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    return result

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('input',type=Path);p.add_argument('output',type=Path)
    p.add_argument('--change-sfc',action='store_true');p.add_argument('--sfc-chars',type=Path);p.add_argument('--legacy-check',action='store_true')
    a=p.parse_args();out=a.output.resolve();out.mkdir(exist_ok=False)
    script=out/'trace.js';script.write_text(SCRIPT,encoding='utf-8')
    (out/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    for attempt in range(1,5):
        native=out/f'native-{attempt}'
        prepare(a.input.resolve(),native,compile=True,export_project=True,program_check=True,snapshot_frontend=True,
            project_alias='CHECKMATRIX',change_sfc=a.change_sfc,sfc_graph_chars=a.sfc_chars,refresh_program_check=not a.legacy_check)
        trace=trace_prepared(native,script)
        events=[json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
        if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
    result=inspect_run(native)
    print(json.dumps(dict(native=str(native),trace=trace,check=result['check'],reads=len(result['resource_reads']),
        errors=result['trace_errors'],export=bool(result['exported_sha256']),
        read_contexts=[dict(phase=r['phase'],name=r['resource_name'],caller=r['caller'],buffers=r['buffers']) for r in result['resource_reads']]),ensure_ascii=True))

if __name__=='__main__':main()
