"""Does matching source POU/resource naming expose the unchanged native rejection?

Native SetObjectName changes only owned imported copies before compilation.
This is a diagnostic experiment, not a production repair or a check bypass.
"""
from pathlib import Path
import json,subprocess,sys
ROOT=Path(__file__).resolve().parents[4];sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from replay_gxw_workspace import prepare,trace_prepared
from probe_gxw_program_check_resources import SCRIPT,inspect_run
from probe_minimal_conditional_port_writes import save
P=Path(__file__).resolve().parent


def main():
    resources=len(sys.argv)>1 and sys.argv[1]=='resources'
    out=P/('q-check-resource-name-alignment-20260930' if resources else 'q-check-source-name-alignment-20260930');out.mkdir(exist_ok=False)
    (out/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    trace=out/'trace.js';trace.write_text('(()=>{'+(P/'observe_q_check_failures.js').read_text()+'\n})();\n(()=>{'+SCRIPT+'\n})();',encoding='utf-8')
    plans=[('original-noeul',P/'native-allocation-inventory/case-10/input.gxw',[('기본동작','MAIN'),('응용동작1','MAIN1')]),
        ('st-25-moves',P/'st-temporary-capacity-rung-controls-20260930/plain-25-moves/input.gxw',[('POU_01','MAIN')]),
        ('st-24-moves',P/'st-temporary-capacity-rung-controls-20260930/plain-24-moves/input.gxw',[('POU_01','MAIN')])]
    save(out/'before-native.json',[dict(case=c,input=str(p),sha256=sha256(p.read_bytes()),rename_kind='resource' if resources else 'source-pou',
        renames=[(new,old) for old,new in renames] if resources else renames,
        expected='Same resource bytes. Negative cases should surface native diagnostics and remain rejected; positive control should pass.')for c,p,renames in plans]);rows=[]
    for case,path,renames in plans:
        d=out/case;d.mkdir();native=d/'native-1';prepare(path,native,compile=True,program_check=True,export_project=True,snapshot_frontend=True,project_alias='CHECKNAMES')
        source=native/'WorkspaceReplayOracle.cs';text=source.read_text(encoding='utf-8-sig')
        needle='    static JavaScriptSerializer json=new JavaScriptSerializer();'
        extra='''    [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int LookupIdFn(IntPtr self,ObjectId parent,int kind,IntPtr name,out ObjectId found,out int code);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int RenameIdFn(IntPtr self,ObjectId target,IntPtr name,out int code);
'''
        assert text.count(needle)==1;text=text.replace(needle,extra+needle)
        needle='            if(plan.ContainsKey("native_copy"))CopyNativeObject(workspace,id,root,plan);'
        assert text.count(needle)==1
        extra=''
        for old,new in renames:
            extra+='''            {
                ObjectId selected;
                Check("DiagnosticRename.Lookup",Slot<LookupIdFn>(workspace,1784)(workspace,id,26,BStr(OLD),out selected,out code),code);
                Check("DiagnosticRename.SetObjectName",Slot<RenameIdFn>(workspace,60)(workspace,selected,BStr(NEW),out code),code);
                Record(new {operation="DiagnosticRename",old_name=OLD,new_name=NEW,id=selected.words});
            }
'''.replace('OLD',json.dumps(old,ensure_ascii=True)).replace('NEW',json.dumps(new))
        if resources:
            mapping='new string[]{'+','.join(json.dumps(old,ensure_ascii=True) for old,new in renames)+'}'
            extra='''            {
                ObjectId resourceCollection;
                Check("DiagnosticRename.Collection",Slot<CollectionFn>(workspace,36)(workspace,id,Convert.ToInt32(plan["program_check_collection"]),out resourceCollection,out code),code);
                var resourcesToRename=Inventory(workspace,resourceCollection);
                string[] names=NAMES;
                if(names.Length!=resourcesToRename.Count)throw new Exception("Resource rename count");
                for(int i=0;i<names.Length;i++) {
                    Check("DiagnosticRename.SetResourceName",Slot<RenameIdFn>(workspace,60)(workspace,resourcesToRename[i],BStr(names[i]),out code),code);
                    Record(new {operation="DiagnosticResourceRename",new_name=names[i],id=resourcesToRename[i].words});
                }
            }
'''.replace('NAMES',mapping)
        text=text.replace(needle,extra+needle);source.write_text(text,encoding='utf-8-sig')
        csc=Path('C:/Windows/Microsoft.NET/Framework/v4.0.30319/csc.exe');exe=native/'WorkspaceReplayOracle.exe'
        build=subprocess.run([str(csc),'/nologo','/platform:x86','/r:System.Web.Extensions.dll','/r:System.Windows.Forms.dll','/out:'+str(exe)]+[str(native/n) for n in ('WorkspaceReplayOracle.cs','NativeFrontendSnapshot.cs','NativeSfcGraphOracle.cs','NativeWorkspaceCopyOracle.cs')],capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW,timeout=30)
        (d/'build.stdout').write_bytes(build.stdout);assert build.returncode==0,build.stdout
        save(d/'helper-patch-provenance.json',dict(source_sha256=sha256(source.read_bytes()),exe_sha256=sha256(exe.read_bytes()),
            rename_kind='resource' if resources else 'source-pou',renames=[(new,old) for old,new in renames] if resources else renames,
            change='Native name changes on isolated imported copy before compilation. No native result overrides. Original prepare hashes retained.'))
        process=trace_prepared(native,trace);checked=inspect_run(native)
        baseline=P/'q-fresh-check-report-conversion-20260930'/case/'native-1'
        equality={f.name:f.read_bytes()==(baseline/f.name).read_bytes() for f in native.glob('pcode-*-0.bin')}
        row=dict(case=case,native_directory=str(native),check=checked['check'],last_event=checked['last_event'],diagnostics=checked['diagnostics'],same_resource_bytes=equality,process=process)
        rows.append(row);save(out/'comparison.json',rows);print(json.dumps(row),flush=True)


if __name__=='__main__':main()
