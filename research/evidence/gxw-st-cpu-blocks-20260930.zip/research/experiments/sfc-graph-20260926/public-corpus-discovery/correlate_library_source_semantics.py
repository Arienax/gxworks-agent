from pathlib import Path
import sys,json,collections,base64,re
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from gxw.lossless import inspect_project,sha256
from probe_gxw_library_archive import decode_library_archive,frame_library_text,observed_source_declarations,observed_source_body
from probe_gxw_library_sources import snapshot_library_pous,observed_library_declarations,observed_library_text
P=Path(__file__).resolve().parent
result=[]
for label,cpu,directory in [('Q-new','Q03UDV',P/'native-allocation-inventory/case-00'),('Q-old','Q03UDV',P/'native-allocation-inventory/case-05'),('FX','FX3U',P/'native-library-frontend-snapshot')]:
 native=snapshot_library_pous(json.loads((directory/'frontend-snapshot.json').read_text(encoding='utf-8-sig')))
 selected=collections.defaultdict(list)
 for stream in inspect_project((directory/'input.gxw').read_bytes()).streams:
  if not stream.logical_name or not stream.logical_name.endswith('.lif'):continue
  library='@IEC' if stream.logical_name.lower() in ('iecfunction.lif','iec.lif') else '@MELSEC'
  framed=frame_library_text(decode_library_archive(stream.raw[20:]).decoded)
  for d in framed['definitions']:
   if d['sections'] is None or cpu in d['sections']:selected[(library,d['name'])].append((stream.logical_name,d))
 counts=collections.Counter();differences=[];classes=collections.Counter();initial_transforms=collections.Counter();type_transforms=collections.Counter();details=[]
 observed={(p['library'],p['name']) for p in native}
 for p in native:
  key=(p['library'],p['name']);candidates=selected.get(key,[])
  if len(candidates)!=1:differences.append(dict(library=key[0],name=key[1],reason='definition selection',candidates=len(candidates)));continue
  stream,d=candidates[0];source=observed_source_declarations(d)
  if source['gaps']:differences.append(dict(library=key[0],name=key[1],reason='source declaration gap',raw=[g['raw'].hex() for g in source['gaps']]));continue
  source_rows=[r for r in source['rows'] if r['name'].upper() not in ['EN','ENO']]
  decoded=observed_library_declarations(base64.b64decode(p['declaration_raw_base64']))['rows'];returns=[r for r in decoded if r['record_id']==0xffffffff];native_rows=[r for r in decoded if r['record_id']!=0xffffffff]
  names_equal=[r['name'] for r in source_rows]==[r['name'] for r in native_rows]
  counts['definitions']+=1;counts['declaration_names_equal']+=names_equal
  if not names_equal:differences.append(dict(library=key[0],name=key[1],reason='row names',source=[r['name'] for r in source_rows],native=[r['name'] for r in native_rows]))
  if names_equal:
   for s,n in zip(source_rows,native_rows):
    classes[(s['source_class'],n['class_code'])]+=1
    if s['data_type_raw']!=n['data_type']:type_transforms[(s['data_type_raw'],n['data_type'])]+=1
    if s['initial_raw']!=n['initial_value']:initial_transforms[(s['data_type_raw'],s['initial_raw'],n['initial_value'])]+=1
  program=base64.b64decode(p['program_raw_base64']);body=observed_source_body(d)
  native_body=observed_library_text(program,native_kind=program[42]).encode('ascii') if program else None
  equal=body==native_body;counts['body_exact']+=equal
  if not equal:differences.append(dict(library=key[0],name=key[1],reason='body',source=None if body is None else body.hex(),native=None if native_body is None else native_body.hex()))
  details.append(dict(library=key[0],name=key[1],stream=stream,source_offset=d['offset'],source_sha256=sha256(d['raw']),full_port_names=[r['name'] for r in source['rows']],flags=[x['directive'] for x in d['preceding_directives']],return_type_raw=d['return_type_raw'],native_return_rows=returns,body_exact=equal,declaration_names_equal=names_equal))
 row=dict(label=label,cpu=cpu,input_sha256=sha256((directory/'input.gxw').read_bytes()),native=len(native),predicted=len(selected),missing=sorted(observed-set(selected)),extra=sorted(set(selected)-observed),counts=dict(counts),classes=[dict(source_class=k[0],native_class=k[1],count=v) for k,v in classes.items()],type_transforms=[dict(source=k[0],native=k[1],count=v) for k,v in type_transforms.items()],initial_transforms=[dict(source_type=k[0],source_initial=k[1],native_initial=k[2],count=v) for k,v in initial_transforms.items()],differences=differences,definitions=details)
 result.append(row);print(json.dumps(dict(label=label,native=len(native),predicted=len(selected),counts=dict(counts),missing=len(row['missing']),extra=len(row['extra']),type_transforms=len(type_transforms),differences=len(differences))));print('differences sample',json.dumps(differences[:2]))
(P/'library-source-semantic-comparison-v3.json').write_text(json.dumps(result,indent=2))
