"""Test source-derived device forwarding without changing the bounded reader."""
from pathlib import Path
import copy,json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256,inspect_project
from probe_gxw_simple_fb import frame_source
from probe_gxw_simple_fb_connections import inspect as inspect_connections
from probe_gxw_compiled_references import stored_records
from probe_gxw_callsite_inputs import compare_callsite_inputs
P=Path(__file__).resolve().parent
for case in ['int-z0','int-z1','int-indirect','int-buffer']:
 parent=P/'scpi-indexed-inputs'/case
 source=(parent/'native/native-saved.gxw').read_bytes()
 connection_file=parent/'source-connections/connections.json'
 connections=json.loads(connection_file.read_text(encoding='utf-8')) if connection_file.exists() else inspect_connections(source,connection_file.parent)
 baseline=json.loads((P/'scpi-indexed-input-bindings'/('indexed-'+case)/'comparison.json').read_text())
 assert sha256(source)==baseline['export_sha256']==connections['source_sha256']
 streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
 results=[]
 for original in baseline['expansions']:
  e=copy.deepcopy(original);name=e['parent']+'.Program.pou'
  groups,_=stored_records(frame_source(streams[name]),encoding='cp932')
  offsets=[g['offset'] for g in groups if g['stored_step']==e['parent_source_step']];assert len(offsets)==1
  calls=[c for p in connections['programs'] if p['name']==name for c in p['calls'] if c['offset']==offsets[0]];assert len(calls)==1
  call=calls[0];assert not call['gaps'] and call['instance']==e['instance']
  inputs=call['connection_fragments']['input'];assert not inputs['text_gaps']
  reader=compare_callsite_inputs(inputs['records'],call['ports'],e['parent_compiled_records'])
  if inputs['records'][-1]['args'][0]==json.loads((parent/'mutation.json').read_text())['value']:
   # Experimental hypothesis from source alone; native body is the oracle.
   assert len(inputs['records'])==4 and inputs['records'][2]==dict(kind='instruction',op='LD',args=["'_TRUE"])
   assert inputs['records'][0]==dict(kind='instruction',op='LD',args=['X1F'])
   assert inputs['records'][1]==dict(kind='instruction',op='OUT',args=["'_iEn"])
   assert inputs['records'][3]['op']=='MOV' and inputs['records'][3]['args'][1]=="'_iUnitNo"
   assert not e['parent_compiled_records']
   overlay={'ien':'X1F','iunitno':inputs['records'][3]['args'][0]}
  else:
   assert not reader['gaps'];overlay={b['port'].lower():b['operand'] for b in reader['bindings']}
  output=call['connection_fragments']['output'];assert not output['text_gaps'] and not output['uninterpreted_groups']
  for b in output['bindings']:overlay[b['port'].lower()]=b['operand']
  exact=corrected=0;differences=[]
  for row in e['rows']:
   expected=copy.deepcopy(row['expected_records'])
   token_map={b['token']:overlay[b['component'].lower()] for b in row['bindings'] if b.get('component','').lower() in overlay}
   for s,t in zip(row['source_records'],expected):
    if s['kind']=='instruction':t['args']=[token_map.get(a,b) for a,b in zip(s['args'],t['args'])]
   matched=not row['gaps'] and expected==row['compiled_records']
   row.update(source_forwarding_expected=expected,source_forwarding_exact=matched)
   exact+=matched;corrected+=matched and row['handling']=='lowering-difference'
   if not matched:differences.append(row)
  e.update(callsite=call,existing_reader=reader,source_forwarding_overlay=overlay,
           source_forwarding_summary=dict(groups=len(e['rows']),exact=exact,corrected=corrected),differences=differences)
  results.append(e)
 result=dict(case=case,export_sha256=sha256(source),expansions=results,
             scope='experimental source operand forwarding; no runtime alias or index-register stability proof')
 (parent/'source-forwarding-comparison.json').write_text(json.dumps(result,indent=2))
 print(json.dumps(dict(case=case,expansions=[dict(e['source_forwarding_summary'],reader_gaps=e['existing_reader']['gaps']) for e in results])),flush=True)
