"""Separate declaration/type allocation from FB body call dependencies."""
from pathlib import Path
import base64,json,struct,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.declarations import parse_declarations,edit_declarations,serialize_declarations
from gxw.compiler_tables import parse_compiler_tables
from gxw.compiler_assignment import parse_compiler_assignment
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import run
from native_gxw_tokens import native_batch,native_il_projection,Q_DLL
P=Path(__file__).resolve().parent
out=P/'q-declaration-compile-dependencies';out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
plans=[('unknown-type-uncalled','bad-uncalled-declared',dict(upserts=[dict(name='SCPI_1',data_type='NeverFb',kind='function_block')]),False),
       ('unknown-type-unassigned','bad-unassigned-caller',dict(upserts=[dict(name='SCPI_1',data_type='NeverFb',kind='function_block')]),False),
       ('remove-uncalled-instance','valid-called',dict(remove=['SCPI_2']),False)]
rows=[];requests=[];files={}
for case,base,edits,unused in plans:
    source=(P/'q-fb-compile-dependencies'/base/'input.gxw').read_bytes()
    streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
    logical='MAIN.Labels.lh';doc=parse_declarations(streams[logical],logical_name=logical)
    new=serialize_declarations(edit_declarations(doc,**edits));changed,receipt=patch_raw(source,logical,streams[logical],new)
    assert {s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}==dict(streams,**{logical:new})
    directory=out/case;directory.mkdir();path=directory/'input.gxw';path.write_bytes(changed)
    (directory/'mutation.json').write_text(json.dumps(dict(base=base,source_sha256=sha256(source),changed_sha256=sha256(changed),edits=edits,receipt=receipt,unrelated_payloads='byte-identical'),indent=2),encoding='utf-8')
    for attempt in range(1,9):
        native=directory/('native' if attempt==1 else 'native-v'+str(attempt))
        result=run(path,native,compile=True,snapshot_frontend=True,export_project=True,project_alias='QDECLDEPENDENCY')
        events=[json.loads(s) for s in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
        if (native/'pcode-0-0.bin').exists() or not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
    row=dict(case=case,native_directory=str(native.relative_to(out)),native={k:result[k] for k in ('returncode','open_succeeded','compile_completed','compiler_rejected','diagnostics')})
    if row['native']['returncode']==0 and row['native']['compile_completed'] and not row['native']['compiler_rejected']:
        files[case]={}
        for f in sorted(native.glob('pcode-*.bin')):
            raw=f.read_bytes();files[case][f.name]=len(requests)
            requests.append(dict(mode='decode',input_base64=base64.b64encode(raw+b'\0').decode()))
        tables=parse_compiler_tables((native/'compiler_DZComp/CGTable.dat').read_bytes())
        row['compiled_pous']=[]
        for record in tables.tables[1].records:
            pou=tables.pou_at(record.table_offset);components=tables.components(pou)
            row['compiled_pous'].append(dict(name=pou.name_bytes.decode('cp949'),offset=record.table_offset,components=len(components),
                assigned=sum(parse_compiler_assignment(c.user_info).iec_address is not None for c in components)))
    rows.append(row);(directory/'comparison.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
    print(json.dumps(row),flush=True)
answers=native_batch(requests,out/'native-pcode-decode',dll=Q_DLL,cpu_code=209)
decoded=[]
for request,answer in zip(requests,answers,strict=True):
    assert answer['return_code']=='0x00000000' and answer['consumed_bytes']==len(base64.b64decode(request['input_base64']))-1
    projection=native_il_projection(base64.b64decode(answer['output_base64']),encoding='cp949');assert not projection['text_gaps'];decoded.append(projection['records'])
(out/'comparison.json').write_text(json.dumps(dict(cases=rows,files=files,decoded=decoded,scope=__doc__),ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(main_pcode={case:decoded[names['pcode-0-0.bin']] for case,names in files.items()})),flush=True)
