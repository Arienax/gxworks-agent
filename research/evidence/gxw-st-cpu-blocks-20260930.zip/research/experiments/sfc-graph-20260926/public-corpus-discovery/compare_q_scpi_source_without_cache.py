"""Compare SCPI MAIN source predictions without any saved compiler table."""
from pathlib import Path
import json
import sys
import traceback
ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'research')]
from gxw.lossless import inspect_project, sha256
from gxw.compiler_tables import parse_compiler_tables
from source_q_direct_projection import project_projection

P = Path(__file__).resolve().parent
OUT = P/'q-scpi-source-without-cache-v2'


def native_assignments(source, roots, encoding):
    tables = parse_compiler_tables(next(s.raw for s in inspect_project(source).streams if s.logical_name == 'CGTable.dat'))
    result = {}
    def visit(owner, pou):
        for c in tables.components(pou):
            name = c.name_bytes.decode(encoding)
            if tables.component_type(c) == 53:
                visit(owner+'.'+name, tables.pou_at(tables.component_instance_pou_offset(c)))
            else:
                result[owner.encode(encoding).hex()+':'+c.name_bytes.hex()] = c.user_info.hex()
    for name in ['@GLOBALS', *roots]:
        hits = [tables.pou_at(r.table_offset) for r in tables.tables[1].records if tables.pou_at(r.table_offset).name_bytes == name.encode(encoding)]
        if len(hits) != 1:
            raise ValueError('native root not unique')
        visit(name, hits[0])
    return result


def main():
    OUT.mkdir(exist_ok=False)
    for name in ['compare_q_scpi_source_without_cache.py', 'source_q_direct_projection.py', 'source_q_direct_declarations.py', 'source_q_call_connections.py', 'source_q_label_binding.py', 'source_q_allocation.py', 'source_q_width.py', 'q-width-static-tables.json']:
        (OUT/name).write_bytes((P/name).read_bytes())
    plans = json.loads((P/'scpi-alias-device-methods/comparison.json').read_text())
    plans += [r for r in json.loads((P/'native-allocation-range-holdouts/comparison.json').read_text()) if not r['baseline']['compiler_rejected']]
    plans += [r for r in json.loads((P/'native-allocation-fragmented-holdout/comparison.json').read_text()) if not r['baseline']['compiler_rejected']]
    predictions = {}; results = []
    for plan in plans:
        directory = OUT/plan['case']; directory.mkdir()
        try:
            rows = project_projection(Path(plan['source']).read_bytes(), allow_scpi=True, resource_limit=1)
            for row in rows:
                (directory/f'predicted-{row["resource_index"]}.bin').write_bytes(row.pop('output'))
            (directory/'prediction.json').write_text(json.dumps(rows, indent=2), encoding='utf-8')
            predictions[plan['case']] = rows
        except Exception as exc:
            predictions[plan['case']] = dict(error=type(exc).__name__+': '+str(exc), traceback=traceback.format_exc())
            (directory/'prediction-error.json').write_text(json.dumps(predictions[plan['case']], indent=2), encoding='utf-8')
    for plan in plans:
        rows = predictions[plan['case']]; directory = OUT/plan['case']
        if isinstance(rows, dict):
            result = dict(case=plan['case'], **rows)
        else:
            native = Path(plan['baseline_directory'])
            actual = native_assignments((native/'native-saved.gxw').read_bytes(), [r['program'] for r in rows], 'cp932')
            programs = []
            for row in rows:
                i = row['resource_index']; theirs = (native/f'pcode-{i}-0.bin').read_bytes(); ours = (directory/f'predicted-{i}.bin').read_bytes()
                diffs = [dict(identity=k, predicted=v, native=actual.get(k)) for k, v in row['assignments'].items() if actual.get(k) != v]
                programs.append(dict(program=row['program'], records=row['records'], byte_identical=ours == theirs,
                    predicted_sha256=sha256(ours), native_sha256=sha256(theirs), allocations=len(row['allocations']), allocation_differences=diffs))
            result = dict(case=plan['case'], native=str(native), programs=programs)
        results.append(result)
        (directory/'comparison.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
        (OUT/'comparison.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
        print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
