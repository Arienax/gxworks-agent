"""Cross resource cache contents with task membership; keep sources unchanged."""
from pathlib import Path
import json
import struct
import sys

ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.token_resource import parse_token_resource
from probe_gxw_task_graph import task_records
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import run

P=Path(__file__).resolve().parent
OUT=P/'iec-cache-authority'


def main():
    OUT.mkdir(exist_ok=False)
    (OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    baseline=P/'fx3g-library-source-roundtrip-v6/true-source-only/compile-1'
    source=(baseline/'native-saved.gxw').read_bytes()
    streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
    expected=(baseline/'pcode-0-0.bin').read_bytes()
    poison=(P/'program-check-freshness/fresh-pcode-1/pcode-0-0.bin').read_bytes()
    assert len(poison)==36 and poison != expected
    resource=parse_token_resource(streams['MAIN.res'])
    bad_resource=resource.raw[:54]+b''.join(struct.pack('<I',len(poison))+poison+bytes(8) for _ in range(2))+resource.raw[resource.suffix_offset:]
    task=task_records(streams['MAIN.tsk'])
    prefix=bytearray(bytes.fromhex(task['opaque_prefix_hex']))
    struct.pack_into('<I',prefix,len(prefix)-4,0)
    plans=[('active-task-bad-cache',False,True),('empty-task-good-cache',True,False),('empty-task-bad-cache',True,True)]
    rows=[]
    for name,empty,bad in plans:
        directory=OUT/name
        directory.mkdir()
        candidate=source
        edits=[]
        if empty:
            candidate,receipt=patch_raw(candidate,'MAIN.tsk',streams['MAIN.tsk'],bytes(prefix))
            edits.append(receipt)
        if bad:
            candidate,receipt=patch_raw(candidate,'MAIN.res',streams['MAIN.res'],bad_resource)
            edits.append(receipt)
        after={s.logical_name:s.raw for s in inspect_project(candidate).streams if s.logical_name}
        touched=[n for n in streams if streams[n]!=after[n]]
        assert set(touched)==({'MAIN.tsk'} if empty else set()) | ({'MAIN.res'} if bad else set())
        path=directory/'input.gxw'
        path.write_bytes(candidate)
        (directory/'prediction-before-native.json').write_text(json.dumps(dict(source_sha256=sha256(source),
            candidate_sha256=sha256(candidate),task_empty=empty,cached_code_sha256=sha256(poison if bad else expected),
            source_and_libraries_unchanged=True,touched=touched,edits=edits),indent=2),encoding='utf-8')
        for attempt in range(1,5):
            native=directory/f'native-{attempt}'
            outcome=run(path,native,compile=True,snapshot_frontend=True,export_project=True,
                        program_check=True,project_alias='CACHEAGE')
            events=[json.loads(s) for s in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
            if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
        file=native/'pcode-0-0.bin'
        actual=file.read_bytes() if file.exists() else None
        row=dict(case=name,native_directory=str(native),outcome=outcome,task_empty=empty,
            output_bytes=len(actual) if actual is not None else None,
            output_sha256=sha256(actual) if actual is not None else None,
            matches_cached_code=actual==(poison if bad else expected),matches_original_source_code=actual==expected,
            output_hex=actual.hex() if actual is not None else None)
        rows.append(row)
        (OUT/'comparison.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
        print(json.dumps(dict(case=name,output_bytes=row['output_bytes'],cached_match=row['matches_cached_code'],
            source_match=row['matches_original_source_code'],rejected=outcome['compiler_rejected'],
            check_target=outcome['program_check_target'])),flush=True)


if __name__=='__main__':main()
