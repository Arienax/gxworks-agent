"""Bounded raw source BOOL and MOV/DMOV/$MOV call connections."""
from gxw.token_q import q_instruction_header
from source_q_allocation import groups


def opcode(group):
    result = q_instruction_header(group[0])
    if result is None:
        raise ValueError('opaque call instruction')
    return result[0]


def placeholder(token):
    if token[1:3] != b'\xdf_':
        raise ValueError('call target is not a placeholder')
    return token[3:-1].decode('ascii')


def source_connections(frame, call):
    aliases = {}; materialized = []; connected = set()
    for direction in ['input', 'output']:
        span = call[direction+'_fragment']
        instructions = groups(frame.raw[span['offset']:span['offset']+span['length']])
        segments = []
        for g in instructions:
            if opcode(g) in ('LD', 'LDI'):
                segments.append([])
            if not segments:
                raise ValueError('connection does not begin with LD/LDI')
            segments[-1].append(g)
        for segment in segments:
            last = segment[-1]; op = opcode(last)
            if op == 'OUT':
                if len(last) != 2:
                    raise ValueError('OUT connection arity')
                if direction == 'input':
                    pin = placeholder(last[1]); prefix = segment[:-1]
                    if not prefix or opcode(prefix[0]) not in ('LD', 'LDI'):
                        raise ValueError('BOOL connection has no condition')
                    direct = len(prefix) == 1 and opcode(prefix[0]) == 'LD'
                    if direct:
                        operands = prefix[0][1:]
                    else:
                        if any(opcode(g) not in ('AND', 'ANI', 'OR', 'ORI') for g in prefix[1:]):
                            raise ValueError('compound BOOL operator outside observed profile')
                        if any(len(g) != 2 or g[1][1] not in (0x90, 0x91, 0x9c) for g in prefix):
                            raise ValueError('compound BOOL device outside observed profile')
                        operands = None
                else:
                    prefix = segment[:-1]
                    if not prefix or opcode(prefix[0]) not in ('LD', 'LDI') or len(prefix[0]) != 2:
                        raise ValueError('BOOL output connection shape')
                    pin = placeholder(prefix[0][1]); operands = last[1:]
                    direct = len(prefix) == 1 and opcode(prefix[0]) == 'LD'
                    if any(opcode(g) not in ('AND', 'ANI', 'OR', 'ORI') or len(g) != 2 or g[1][1] not in (0x90, 0x91, 0x9c) for g in prefix[1:]):
                        raise ValueError('compound BOOL output outside observed profile')
                marker = 'B'
            elif op in ('MOV', 'DMOV', '$MOV'):
                unconditional = len(segment) == 2 and opcode(segment[0]) == 'LD' and segment[0][1:] == [bytes.fromhex('08df5f5452554508')]
                if not unconditional:
                    prefix = segment[:-1]
                    if not prefix or opcode(prefix[0]) not in ('LD', 'LDI'):
                        raise ValueError('conditional value connection shape')
                    if any(opcode(g) not in ('AND', 'ANI', 'OR', 'ORI') for g in prefix[1:]):
                        raise ValueError('conditional value expression operator')
                    if any(len(g) != 2 or g[1][1] not in (0x90, 0x91, 0x9c) for g in prefix):
                        raise ValueError('conditional value device outside source profile')
                if len(last) < 3:
                    raise ValueError('value connection arity')
                marker = {'MOV': 'W', 'DMOV': 'D', '$MOV': 'S'}[op]
                if direction == 'input':
                    pin = placeholder(last[-1]); operands = last[1:-1]
                    direct = not 0xe3 <= operands[0][1] <= 0xee
                    if direct and not unconditional and (len(operands) != 1 or operands[0][1] != 0xa8):
                        raise ValueError('conditional device alias outside observed D profile')
                else:
                    pin = placeholder(last[1]); operands = last[2:]; direct = True
            else:
                raise ValueError('unrecovered call connection instruction')
            ports = [p for p in call['ports'] if p['direction'] == direction and p['name'] == pin and p['type_marker'] == marker]
            if len(ports) != 1 or pin.casefold() in connected:
                raise ValueError('missing or duplicate typed connection')
            connected.add(pin.casefold())
            if operands is not None and (not operands or any(t[1] == 0xdf for t in operands)):
                raise ValueError('unresolved source operand in call connection')
            if direct:
                aliases[pin.casefold()] = b''.join(operands)
                if op in ('MOV', 'DMOV', '$MOV') and not unconditional:
                    # Native keeps the condition records but eliminates the
                    # device copy into a port alias, even for conditional input.
                    materialized.append(dict(port=pin, groups=segment[:-1], mode='condition-prefix-only', phase=direction))
            else:
                materialized.append(dict(port=pin, groups=segment, phase=direction))
    return aliases, materialized
