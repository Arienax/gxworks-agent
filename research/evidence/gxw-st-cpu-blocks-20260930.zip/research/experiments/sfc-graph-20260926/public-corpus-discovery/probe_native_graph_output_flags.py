"""Separate node kinds from raw port flags using native SIC and PCode."""
from pathlib import Path
import base64,json,struct,sys,zipfile
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.structured_pou import parse_structured_pou
from gxw.project_metadata import mark_observed_source_compile_pending
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import prepare,trace_prepared
from native_gxw_tokens import native_batch,native_il_projection,DEFAULT_DLL
P=Path(__file__).resolve().parent
out=P/'native-graph-output-flags';out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
archive=ROOT/'research/evidence/gxw-abi-checkpoint-20260919.zip'
with zipfile.ZipFile(archive) as z:source=z.read('frozen/base_spaced.gxw')
streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
logical='1.Program.pou';raw=streams[logical];program=parse_structured_pou(raw,logical_name=logical)
rows=[]
for role,kinds in [('contact',[(3,10),(3,18)]),('coil',[(5,8)])]:
    node=next(n for n in program.nodes if n.kind.value==role)
    for kind,port_code in kinds:
        case=f'{role}-{kind:02d}-port-{port_code:03d}';directory=out/case;directory.mkdir()
        updated=bytearray(raw);struct.pack_into('<I',updated,node.offset+8,kind)
        port_offset=node.offset+node.record_length-sum(p.size for p in node.ports)+20
        assert struct.unpack_from('<I',updated,port_offset)[0]==node.ports[1].port_kind_code
        struct.pack_into('<I',updated,port_offset,port_code)
        updated=mark_observed_source_compile_pending(bytes(updated),logical_name=logical)
        patched,receipt=patch_raw(source,logical,raw,updated)
        assert {s.logical_name:s.raw for s in inspect_project(patched).streams if s.logical_name}==dict(streams,**{logical:updated})
        path=directory/'source.gxw';path.write_bytes(patched)
        (directory/'mutation.json').write_text(json.dumps(dict(archive=str(archive.relative_to(ROOT)),archive_sha256=sha256(archive.read_bytes()),
            member='frozen/base_spaced.gxw',source_sha256=sha256(source),target_role=role,node_offset=node.offset,
            old_kind=node.kind_code,new_kind=kind,port_offset=port_offset,old_port_code=node.ports[1].port_kind_code,new_port_code=port_code,changed_sha256=sha256(patched),receipt=receipt,unrelated_payloads='byte-identical'),indent=2))
        for attempt in range(3):
            native=directory/('native' if attempt==0 else f'native-attempt-{attempt}')
            prepare(path,native,compile=True,export_project=True,project_alias='GRAPHFLAGS')
            process=trace_prepared(native,P/'TraceGraphPrimitives.js')
            startup=[json.loads(line) for line in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
            if startup[-1]['operation']!='NativeTemporaryDirectoryCollision':break
        events=[json.loads(s) for s in (native/'events.jsonl').read_text().splitlines()]
        native_events=[json.loads(s) for s in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
        fragments=[]
        for e in events:
            payload=e.get('payload',{})
            if payload.get('event')!='enter' or payload.get('name')!='Compile':continue
            buffers={b['label']:b for b in payload['buffers']}
            for key,b in buffers.items():
                if not key.startswith('source_') or not b['bytes']:continue
                index=key.removeprefix('source_');name=bytes.fromhex(buffers['name_'+index]['bytes']).split(b'\0')[0]
                body=bytes.fromhex(b['bytes']);assert len(body)==b['requested_size']
                filename=f'compile-{payload["id"]}-{index}.sic';(directory/filename).write_bytes(body)
                fragments.append(dict(name_ascii=name.decode('ascii',errors='backslashreplace'),text_ascii=body.decode('ascii',errors='backslashreplace'),file=filename,sha256=sha256(body)))
        diagnostics={json.dumps({k:v for k,v in r.items() if k!='raw_base64'},sort_keys=True)
                     for e in native_events for r in e.get('reports',[]) if r['kind'] in (2,3)}
        row=dict(case=case,role=role,kind=kind,port_code=port_code,native_directory=str(native.relative_to(out)),process=process,fragments=fragments,
            compile_completed=any(e['operation']=='Progress' and e.get('percent')==100 for e in native_events),
            crt_checks=[e for e in native_events if e['operation']=='NativeCrtCharacterCase'],
            trace_errors=[e for e in events if e.get('type')=='error'],diagnostics=[json.loads(d) for d in sorted(diagnostics)],
            exported=(native/'native-saved.gxw').exists(),last_event=native_events[-1],
            outputs={p.name:sha256(p.read_bytes()) for p in native.glob('pcode-*.bin')})
        rows.append(row);(directory/'comparison.json').write_text(json.dumps(row,indent=2))
        (out/'comparison.json').write_text(json.dumps(dict(cases=rows),indent=2))
        print(json.dumps(dict(case=case,process=process,compile_completed=row['compile_completed'],exported=row['exported'],
            diagnostics=row['diagnostics'],source=[f['text_ascii'] for f in fragments if f['name_ascii']=='1'])),flush=True)
selected=[r for r in rows if r['exported'] and r['compile_completed'] and not any(d['kind']==2 for d in r['diagnostics'])]
paths=[out/r['native_directory']/'pcode-0-0.bin' for r in selected]
answers=native_batch([dict(mode='decode',input_base64=base64.b64encode(p.read_bytes()+b'\0').decode()) for p in paths],out/'native-decode',dll=DEFAULT_DLL,cpu_code=0x208)
decoded=[]
for row,path,answer in zip(selected,paths,answers,strict=True):
    assert answer['return_code']=='0x00000000' and answer['consumed_bytes']==path.stat().st_size
    projection=native_il_projection(base64.b64decode(answer['output_base64']),encoding='gb18030');assert not projection['text_gaps']
    decoded.append(dict(case=row['case'],pcode_sha256=sha256(path.read_bytes()),records=projection['records']))
(out/'native-decoded.json').write_text(json.dumps(decoded,indent=2))
print(json.dumps(dict(accepted=len(selected),cases=len(rows),decoded=decoded)),flush=True)
