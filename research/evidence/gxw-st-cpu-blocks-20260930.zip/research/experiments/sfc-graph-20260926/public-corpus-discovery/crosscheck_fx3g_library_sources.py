"""All custom library source objects against an independent native ABI capture.

The real project and its source stay local. The comparison records byte hashes,
counts, and gaps. Neither a compiler frontend match nor raw replay establishes
valid PLC behavior; the baseline project's full program check is rejected.
"""
from pathlib import Path
import base64
import json
import struct
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project, inspect_program, sha256
from gxw.declarations import parse_declarations, serialize_declarations, parse_structure_declarations
from gxw.text_pou import parse_st_pou
from gxw_corpus import analyze, project_token_context
from probe_gxw_library_sources import snapshot_library_pous, observed_library_declarations
from probe_fx3g_library_declarations import native_global_rows

P = Path(__file__).resolve().parent
NATIVE = P/'fx3g-library-native-baseline/native-1'


def child(blob, offset):
    matches = [r['data'] for r in blob['relocations'] if r['offset'] == offset]
    if len(matches) != 1:
        raise ValueError('ambiguous ABI relocation')
    return matches[0]


def raw(blob):
    return base64.b64decode(blob['raw'],validate=True)


def name(blob):
    data = raw(blob)
    if data[-1:] != b'\0' or b'\0' in data[:-1]:
        raise ValueError('invalid ABI name')
    return data[:-1].decode('cp1252')


def table_pool(pool):
    if len(raw(pool)) % 16:
        raise ValueError('invalid native table pool')
    result = {}
    for offset in range(0,len(raw(pool)),16):
        key = name(child(pool,offset))
        if key in result:
            raise ValueError('duplicate native table identity')
        payload = raw(child(pool,offset+8))
        assert len(payload) == struct.unpack_from('<I',raw(pool),offset+12)[0]
        result[key] = payload
    return result


def main():
    out = P/'fx3g-complete-source-crosscheck-v2'
    out.mkdir(exist_ok=False)
    (out/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    source = (NATIVE/'input.gxw').read_bytes()
    request = json.loads((NATIVE/'request.json').read_text(encoding='utf-8'))
    assert request['input_sha256'] == sha256(source)
    snapshot = json.loads((NATIVE/'frontend-snapshot.json').read_text(encoding='utf-8'))
    image = inspect_project(source)
    context = project_token_context(image)
    pous = {(r['library'],r['name']):(base64.b64decode(r['program_raw_base64']),base64.b64decode(r['declaration_raw_base64']))
            for r in snapshot_library_pous(snapshot)}
    tables = {(None,'global'):table_pool(child(snapshot['build'],20))}
    project_pous = child(snapshot['build'],44)
    for offset in range(0,len(raw(project_pous)),56):
        pous[(None,name(child(project_pous,offset+8)))] = (raw(child(project_pous,offset+24)),raw(child(project_pous,offset+16)))
    libs = child(snapshot['build'],8)
    for offset in range(0,len(raw(libs)),32):
        library = name(child(libs,offset))
        tables[(library,'global')] = table_pool(child(libs,offset+8))
        tables[(library,'structure')] = table_pool(child(libs,offset+16))
    comparisons = []
    for stream in image.streams:
        logical = stream.logical_name or ''
        if not logical.endswith(('.lnb','.pou','.lnl','.lh','.lng','.gh','.lns')):
            continue
        if '\\' in logical:
            owner, suffix = logical.rsplit('\\',1)
            library = suffix[:-4]
        else:
            owner, library = logical.rsplit('.',1)[0], None
        row = dict(logical_name=logical, source_sha256=sha256(stream.raw), matches=False)
        try:
            if logical.endswith(('.lnb','.pou')):
                source_text = parse_st_pou(stream.raw)
                native,_ = pous[(library,owner.removesuffix('.Program'))]
                count, = struct.unpack_from('<I',native,72)
                assert 80 + count == len(native) and native[42] == 193 and native[-4:] == bytes(4)
                row.update(kind='program', matches=source_text.text.encode(context['text_encoding']) + b'\0' == native[76:76+count],
                    raw_preserved=inspect_program(stream.raw,token_profile=None).reconstruct() == stream.raw)
            elif logical.endswith('.lns'):
                document = parse_structure_declarations(stream.raw,logical_name=logical)
                expected = native_global_rows(tables[(library,'structure')][owner],structure=True)
                fields = ('record_id','name','data_type','initial_value','comment')
                row.update(kind='structure', count=len(document.members),
                    matches=[{k:getattr(r,k) for k in fields} for r in document.members] == expected,
                    raw_preserved=document.reconstruct() == stream.raw)
            else:
                document = parse_declarations(stream.raw,logical_name=logical)
                if logical.endswith(('.lng','.gh')):
                    expected = native_global_rows(tables[(library,'global')][owner])
                    return_match = True
                else:
                    _,native = pous[(library,document.owner_name)]
                    parsed = observed_library_declarations(native)
                    assert parsed['fully_framed']
                    expected = parsed['rows']
                    returns = [r for r in expected if r['record_id'] == 0xffffffff]
                    return_match = (len(returns)==1 and returns[0]['name']==document.owner_name and
                        returns[0]['data_type']==document.owner_return_type and returns[0]['class_code']==4) if document.owner_return_type else not returns
                    expected = [r for r in expected if r['record_id'] != 0xffffffff]
                fields = ('record_id','name','data_type','class_code','initial_value','comment')
                row.update(kind='declarations', count=len(document.rows),
                    matches=return_match and [{k:getattr(r,k) for k in fields} for r in document.rows] == [{k:r[k] for k in fields} for r in expected],
                    raw_preserved=serialize_declarations(document) == stream.raw,
                    opaque_extensions=sum(bool(r.value_extension) for r in document.rows))
        except (ValueError,KeyError) as exc:
            row['gap'] = str(exc)
        comparisons.append(row)
    summary = dict(objects=len(comparisons), matches=sum(r['matches'] for r in comparisons),
        raw_preserved=all(r.get('raw_preserved') for r in comparisons),
        programs=sum(r.get('kind')=='program' for r in comparisons),
        declaration_rows=sum(r.get('count',0) for r in comparisons if r.get('kind')=='declarations'),
        structure_members=sum(r.get('count',0) for r in comparisons if r.get('kind')=='structure'),
        gaps=[r for r in comparisons if not r['matches']],
        source_sha256=sha256(source), native_snapshot_sha256=sha256((NATIVE/'frontend-snapshot.json').read_bytes()),
        native=request['native'], native_acceptance='baseline full program check rejected')
    (out/'comparison.json').write_text(json.dumps(dict(summary=summary,objects=comparisons),indent=2),encoding='utf-8')
    (out/'corpus-analysis.json').write_text(json.dumps(analyze(source),indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in summary.items() if k!='native'}))


if __name__=='__main__':
    main()
