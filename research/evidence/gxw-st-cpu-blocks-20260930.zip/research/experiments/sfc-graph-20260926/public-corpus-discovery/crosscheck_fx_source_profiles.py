"""Replay independent native outputs through explicit FX source profiles."""
from pathlib import Path
import base64
import json
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'research')]
from gxw.lossless import inspect_project, inspect_program, sha256
from gxw.token_listing import decode_token_program, decode_token_listing
from gxw.token_pou import parse_token_fragment
from gxw_corpus import project_token_context, program_report
from native_gxw_tokens import native_il_projection, listing_records, canonical_record

P = Path(__file__).resolve().parent
OUT = P / 'fx-profile-source-reading'


def comparable(records):
    return [canonical_record(r) for r in records]


def main():
    OUT.mkdir(exist_ok=False)
    (OUT / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    native_path = P / 'additional-real-source-crosscheck/native-listings/comparison.json'
    native_rows = json.loads(native_path.read_text(encoding='utf-8'))
    programs = []
    for saved in native_rows:
        source = (P / 'additional-real-projects' / saved['case'] / 'input.gxw').read_bytes()
        image = inspect_project(source)
        context = project_token_context(image)
        raw = next(s.raw for s in image.streams if s.logical_name == saved['program'])
        assert sha256(raw) == saved['sha256']
        projection = inspect_program(raw, logical_name=saved['program'],
            token_profile=context['token_profile'], text_encoding=context['text_encoding'])
        report = program_report(raw, saved['program'], [], token_profile=context['token_profile'],
            text_encoding=context['text_encoding'])
        row = dict(case=saved['case'], program=saved['program'], source_sha256=sha256(source),
            program_sha256=sha256(raw), context=context, layout=projection.layout,
            reconstructed_identically=projection.reconstruct() == raw,
            critical_token_gaps=report.get('critical_token_gaps'),
            decoded_instructions=report.get('decoded_instructions'))
        if saved.get('native_response'):
            listing = decode_token_listing(raw, profile=context['token_profile'], text_encoding=context['text_encoding'])
            assert sha256(listing.source.body) == saved['body_sha256']
            native = saved['native_response']
            assert native['return_code'] == '0x00000000' and native['consumed_bytes'] == len(listing.source.body)
            expected = native_il_projection(base64.b64decode(native['output_base64']), encoding=context['text_encoding'])
            row['listing_agrees'] = comparable(listing_records(listing)) == comparable(expected['records'])
            row['gaps'] = [dict(offset=g.tokens[0].offset, reason=g.reason) for g in listing.gaps]
            compiled = P / 'additional-native-baselines' / saved['case'] / 'native-1/pcode-0-0.bin'
            row['native_compiler_body_identical'] = listing.source.body == compiled.read_bytes()
        programs.append(row)
    control_rows = []
    for cpu, profile in ((520, 'fx3u'), (518, 'fx1s')):
        directory = P / 'fx-cpu-lexical-controls' / f'cpu-{cpu}'
        requests = json.loads((directory / 'requests.json').read_text(encoding='utf-8'))['requests']
        responses = [json.loads(s) for s in (directory / 'native-stdout.jsonl').read_text(encoding='utf-8').splitlines()]
        for index, (request, response) in enumerate(zip(requests, responses, strict=True)):
            body = bytes.fromhex(request['body_hex'])
            listing = decode_token_program(parse_token_fragment(body, 0, len(body)), profile=profile, text_encoding='cp936')
            expected = native_il_projection(base64.b64decode(response['output_base64']), encoding='cp936')
            agrees = comparable(listing_records(listing)) == comparable(expected['records'])
            control_rows.append(dict(cpu=cpu, index=index, agrees=agrees,
                raw_preserved=listing.reconstruct() == body,
                gaps=[dict(offset=g.tokens[0].offset, reason=g.reason) for g in listing.gaps],
                **({} if agrees else dict(ours=listing_records(listing), native=expected['records']))))
    result = dict(programs=programs, native_evidence_sha256=sha256(native_path.read_bytes()),
        controls=dict(count=len(control_rows), matches=sum(r['agrees'] for r in control_rows),
            opaque=sum(bool(r['gaps']) for r in control_rows), differences=[r for r in control_rows if not r['agrees']]),
        all_raw_preserved=all(r['raw_preserved'] for r in control_rows) and all(r['reconstructed_identically'] for r in programs))
    (OUT / 'comparison.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps(dict(programs=programs, controls={k:v for k,v in result['controls'].items() if k!='differences'},
        all_raw_preserved=result['all_raw_preserved']), ensure_ascii=True))


if __name__ == '__main__':
    main()
