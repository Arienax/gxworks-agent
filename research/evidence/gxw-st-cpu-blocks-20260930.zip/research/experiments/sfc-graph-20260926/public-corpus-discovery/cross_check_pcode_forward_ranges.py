"""Compare stored source/compiled spans with native GetPCodeRange by instance."""
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project
from gxw.compiler_debug import parse_compiler_debug
from probe_gxw_debug_locations import search_maps
from replay_gxw_workspace import run
P=Path(__file__).resolve().parent
OUT=P/'native-pcode-forward-cross-check'
for case in ['two','same','st']:
    source=P/'native-pcode-range-controls'/case/'native-saved.gxw'
    out=OUT/case
    if (out/'comparison.json').exists():continue
    raw=next(s.raw for s in inspect_project(source.read_bytes()).streams if s.logical_name=='DebugInformation2.dat')
    debug=parse_compiler_debug(raw)
    maps=search_maps(debug,encoding='cp1252')['maps']
    queries=[];expected=[]
    for entry in maps[0]:
        for group in entry['groups']:
            for element_index in group:
                element=debug.elements[element_index]
                table=debug.offset_tables[element.offset_table_index]
                for row_index,row in enumerate(table.rows):
                    if row[0]<0 or row[1]<0 or row[2]<row[1]:continue
                    start=element.linked_step_start+row[1]
                    count=row[2]-row[1]+1
                    step=row[0]+element.fields[0]
                    # /PC is observed in the native parser; a linked position
                    # selects a specific expansion of an otherwise same instance.
                    for suffix in ['',f'\t/PC{start}']:
                        queries.append(dict(mode='basic',resource='MAIN',library='',pou=entry['key']['text']+suffix,
                            program_kind=element.kind_code,network=-1,start_step=step,step_count=1,element_id=-1))
                        expected.append(dict(element=element_index,row_index=row_index,row=row,
                            start_step=start,step_count=count))
    out.mkdir(parents=True,exist_ok=True)
    (out/'expected.json').write_text(json.dumps(expected,indent=2),encoding='utf-8')
    native=run(source,out/'native',compile=True,export_project=True,project_alias='FWDRANGE',pcode_range_queries=queries)
    actual=json.loads((out/'native/native-pcode-ranges.json').read_text(encoding='utf-8-sig'))
    rows=[]
    for want,got in zip(expected,actual,strict=True):
        ranges=[dict(resource=r['resource'],start_step=r['start_step'],step_count=r['step_count']) for r in got['ranges']]
        exact=got['code']==0 and len(ranges)==1 and ranges[0]==dict(resource='MAIN',start_step=want['start_step'],step_count=want['step_count'])
        rows.append(dict(expected=want,query=got['query'],code=got['code'],ranges=ranges,exact=exact))
    summary={mode:dict(total=len(sub),exact=sum(r['exact'] for r in sub),null=sum(r['ranges']==[dict(resource=None,start_step=-1,step_count=-1)] for r in sub))
             for mode,sub in [(mode,[r for r in rows if ('\t/PC' in r['query']['pou'])==pc]) for mode,pc in [('default',False),('pc_selected',True)]]}
    (out/'comparison.json').write_text(json.dumps(dict(summary=summary,rows=rows),indent=2),encoding='utf-8')
    print(json.dumps(dict(case=case,native_returncode=native['returncode'],summary=summary,
        mismatches=[r for r in rows if not r['exact'] and '\t/PC' in r['query']['pou']][:5])),flush=True)
