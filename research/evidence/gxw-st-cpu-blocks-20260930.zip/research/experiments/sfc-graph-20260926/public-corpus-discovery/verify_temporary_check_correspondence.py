"""Verify saved current/check/export bytes without invoking a native compiler."""
from pathlib import Path
import json,struct,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path.insert(0,str(ROOT/'src'))
from gxw.lossless import inspect_project,sha256
P=Path(__file__).resolve().parent
SIGNATURE=bytes.fromhex('01000000000001000000000001000a00000000000200000001000000010000000000')


def verify(groups):
    rows=[]
    for group in groups:
        for case in json.loads((P/group/'comparison.json').read_text()):
            phases=[('compile',Path(case['native_directory']))]
            if 'reopen' in case:phases.append(('reopen',Path(case['reopen']['native_directory'])))
            for phase,n in phases:
                r=json.loads((n/'resource-correspondence.json').read_text())
                assert sha256((n/'input.gxw').read_bytes())==r['input_sha256']
                if not r['check']:
                    assert not r['exported_sha256']
                    if not r['check_starts']:
                        rejected=any(d.get('kind')==2 for d in r['diagnostics'])
                        rows.append(dict(group=group,case=case['case'],phase=phase,precheck_rejection=rejected,
                            incomplete_before_check=not rejected,last_event=r['last_event']));continue
                reads=[x for x in r['resource_reads'] if x['phase']=='check' and x['caller']['rva']=='0x82a34' and x['hresult']>=0 and x['code']==0]
                covered={x['resource_name'] for x in reads}=={x['name'] for x in r['generated']}
                if r['check']:assert covered
                for x in reads:
                    index=next(g['index'] for g in r['generated'] if g['name']==x['resource_name'])
                    for i,b in enumerate(x['buffers']):
                        actual=(n/f'checked-read-{x["serial"]}-{i}.bin').read_bytes()
                        current=(n/f'pcode-{index}-{i}.bin').read_bytes()
                        assert actual==current and b['matches_current'] and sha256(actual)==b['sha256']
                spans=[]
                if r['exported_sha256']:
                    export=(n/'native-saved.gxw').read_bytes();assert sha256(export)==r['exported_sha256']
                    payloads={s.logical_name:s.raw for s in inspect_project(export).streams if s.logical_name}
                    for g in r['generated']:
                        raw=payloads[g['name']+'.res'];code=(n/f'pcode-{g["index"]}-0.bin').read_bytes()
                        assert raw.startswith(SIGNATURE)
                        length=struct.unpack_from('<I',raw,54)[0];assert raw[58:58+length]==code
                        next_length=58+length+8;assert raw[58+length:next_length]==b'\0'*8
                        second=struct.unpack_from('<I',raw,next_length)[0]
                        assert raw[next_length+4:next_length+4+second]==code
                        spans.append(dict(resource=g['name'],bytes=len(code),sha256=sha256(code),copies=2))
                row=dict(group=group,case=case['case'],phase=phase,
                    input_sha256=r['input_sha256'],read_count=len(reads),exported_regions=spans,
                    checked_resource_coverage_complete=covered,
                    backend_check_rejected=r.get('backend_check_rejected'),
                    backend_completed_check_indices=r.get('backend_completed_check_indices'),
                    diagnostic_projection_failures=len(r.get('diagnostic_projection_failures',[])))
                if r['check']:row['accepted']=not r['check']['rejected']
                else:row.update(incomplete_check=True,last_event=r['last_event'])
                rows.append(row)
    checked_payloads=sum(r.get('read_count',0)*3 for r in rows)
    exported_copies=sum(s['copies'] for r in rows for s in r.get('exported_regions',[]))
    return dict(phases=rows,checked=sum('accepted' in r for r in rows),
        precheck_rejections=sum(r.get('precheck_rejection',False) for r in rows),
        incomplete_checks=sum(r.get('incomplete_check',False) for r in rows),
        incomplete_before_check=sum(r.get('incomplete_before_check',False) for r in rows),
        backend_rejected_phases=sum(r.get('backend_check_rejected') is True for r in rows),
        diagnostic_projection_failures=sum(r.get('diagnostic_projection_failures',0) for r in rows),
        checked_payloads_verified=checked_payloads,exported_copies_verified=exported_copies,
        actual_checked_payloads_match=True if checked_payloads else None,
        exported_copies_match=True if exported_copies else None,
        notes=['An initial ad-hoc verifier incorrectly sliced the constant signature to 33 bytes. The exact constant is 34 bytes; corrected before asserting correspondence.',
               'Q resource verification compares both bounded raw copies; it does not invoke the FX-only END parser.',
               'A checker error after it starts is incomplete_check, not a frontend rejection. Saved bytes can match even when checking fails.',
               'Match fields are null when no corresponding saved payloads or exports exist; no empty-set success claim.',
               'A captured backend rejection can coexist with an incomplete public check when diagnostic projection fails. Neither means acceptance or that all project resources were checked.'])


if __name__=='__main__':
    groups=sys.argv[1:] or ['st-temporary-bank-holdouts-20260930','st-temporary-widths-20260930','st-temporary-control-flow-20260930']
    result=verify(groups)
    (P/'temporary-check-correspondence-20260930.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('phases','notes')}))
