"""Distinguish graph references, record order and task order on a real project."""
from pathlib import Path
import json
import struct
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'research')]
from gxw.lossless import inspect_project, sha256
from probe_gxw_sfc_sources import framing, native_children
from probe_gxw_sfc_graph import compiled_graph, patch_raw
from probe_gxw_task_graph import inspect_task_graph
from replay_gxw_workspace import run
from source_fx_sfc_projection import project_projection

P = Path(__file__).resolve().parent
OUT = P/'real-sfc-source-expansion'


def streams(source):
    return {s.logical_name: s.raw for s in inspect_project(source).streams if s.logical_name}


def child_patch(raw, child, code):
    start, end = child['token_offset'], child['token_offset'] + child['token_size']
    updated = bytearray(raw[:start] + code + raw[end:])
    for offset in (child['size_offset'], child['payload_offset']):
        struct.pack_into('<I', updated, offset, len(code) + 20)
    assert updated[start + len(code):] == raw[end:]
    return bytes(updated)


def main():
    OUT.mkdir(exist_ok=False)
    for f in [Path(__file__), P/'source_fx_sfc_projection.py', ROOT/'research/probe_gxw_task_graph.py',
              ROOT/'research/probe_gxw_sfc_sources.py', ROOT/'research/probe_gxw_sfc_graph.py']:
        (OUT/f.name).write_bytes(f.read_bytes())
    path = P/'additional-real-projects/case-03/input.gxw'
    source = path.read_bytes(); original = streams(source)
    graph = inspect_task_graph(source)
    logical = graph['programs']['MAIN_Block001']['source_program']
    raw = original[logical]; layout = framing(raw)
    plans = [('baseline-original', {})]
    action = next(c for c in layout['children'] if c['kind'] == 'zoom' and c['token_hex'] == '032303049d0204')
    plans.append(('grow-action', {logical: child_patch(raw, action,
        bytes.fromhex(action['token_hex'] + '032303049d0504'))}))
    transition = next(c for c in layout['children'] if c['kind'] == 'transition' and c['number'] == 3)
    plans.append(('change-transition-device', {logical: child_patch(raw, transition,
        bytes.fromhex('030003049c0104030c03049c0504'))}))
    updated = bytearray(raw)
    for members, start, end in [
        ([c for c in layout['children'] if c['kind'] == 'zoom'], layout['zoom_count_offset'] + 4, layout['action_count_offset']),
        (layout['actions'], layout['action_count_offset'] + 4, layout['transition_count_offset']),
        ([c for c in layout['children'] if c['kind'] == 'transition'], layout['transition_count_offset'] + 4, layout['tail_offset'])]:
        updated[start:end] = b''.join(raw[m['record_offset']:m['record_offset'] + m['record_size']] for m in reversed(members))
    plans.append(('reverse-all-record-arrays', {logical: bytes(updated)}))
    actions = [next(a for a in layout['actions'] if a['number'] == n) for n in (10, 11)]
    updated = bytearray(raw)
    for index, a in enumerate(actions):
        start, end = a['record_offset'], a['record_offset'] + a['record_size']
        old_name = a['registrations'][0]['zoom']; new_name = actions[1-index]['registrations'][0]['zoom']
        assert len(old_name) == len(new_name)
        updated[start:end] = raw[start:end].replace(old_name.encode('utf-16le'), new_name.encode('utf-16le'))
    plans.append(('swap-action-registrations', {logical: bytes(updated)}))
    updated = bytearray(raw)
    for c in layout['children']:
        if c['kind'] == 'transition' and c['number'] in (1, 2):
            struct.pack_into('<I', updated, c['size_offset'] - 8, 3 - c['number'])
    plans.append(('swap-transition-numbers', {logical: bytes(updated)}))
    task_name = graph['resources'][0]['task']; task_raw = bytearray(original[task_name])
    for entry in graph['tasks'][task_name]['entries']:
        struct.pack_into('<I', task_raw, entry['order_offset'], 3 - entry['stored_order'])
    plans.append(('reverse-task-order', {task_name: bytes(task_raw)}))
    updated = bytearray(raw)
    graph_tokens = compiled_graph(raw)['tokens']
    token, = [t for t in graph_tokens if t['raw'] == '04980a04']
    updated[token['offset'] + 2] = 20
    struct.pack_into('<I', updated, actions[0]['number_offset'], 20)
    plans.append(('renumber-action-reference', {logical: bytes(updated)}))
    ready = []
    for tag, replacements in plans:
        directory = OUT/tag; directory.mkdir(); patched = source; receipts = []
        for name, replacement in replacements.items():
            patched, receipt = patch_raw(patched, name, original[name], replacement)
            receipts.append(receipt)
        changed = streams(patched)
        assert changed == dict(original, **replacements)
        caches = {name: compiled_graph(value)['cache_sha256'] for name, value in changed.items() if name.endswith('.pou')}
        assert caches == {name: compiled_graph(value)['cache_sha256'] for name, value in original.items() if name.endswith('.pou')}
        candidate, prediction = project_projection(patched)
        (directory/'source.gxw').write_bytes(patched); (directory/'candidate.bin').write_bytes(candidate)
        evidence = dict(case=tag, original=str(path), original_sha256=sha256(source), patched_sha256=sha256(patched),
            replacements={name: dict(old_sha256=sha256(original[name]), new_sha256=sha256(value)) for name, value in replacements.items()},
            receipts=receipts, unrelated_payloads='byte-identical', opaque_graph_cache_sha256=caches,
            candidate_sha256=sha256(candidate), candidate_bytes=len(candidate), prediction=prediction)
        (directory/'prediction-before-native.json').write_text(json.dumps(evidence, indent=2), encoding='utf-8')
        ready.append((tag, directory, patched, candidate))
    results = []
    for tag, directory, patched, candidate in ready:
        for attempt in range(1, 5):
            native = directory/f'native-{attempt}'
            outcome = run(directory/'source.gxw', native, compile=True, change_sfc=True,
                export_project=True, snapshot_frontend=True, program_check=True, project_alias='SFCSOURCE')
            events = [json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
            if not any(e.get('operation') == 'NativeTemporaryDirectoryCollision' for e in events):
                break
        output = native/'pcode-0-0.bin'
        accepted = outcome['returncode'] == 0 and outcome['compile_completed'] and not outcome['compiler_rejected'] and (native/'native-saved.gxw').exists()
        child_matches = None
        if (native/'frontend-snapshot.json').exists():
            observed = native_children(json.loads((native/'frontend-snapshot.json').read_text(encoding='utf-8-sig')))
            children = [c for name, raw in streams(patched).items() if name.endswith('.pou') for c in framing(raw)['children']]
            child_matches = all(observed.get((c['kind'], c['name'])) == bytes.fromhex(c['token_hex']) for c in children)
        row = dict(case=tag, native_directory=str(native), native_accepted=accepted,
            full_pcode_identical=output.exists() and output.read_bytes() == candidate,
            native_child_bodies_identical=child_matches,
            actual_sha256=sha256(output.read_bytes()) if output.exists() else None, outcome=outcome)
        (directory/'comparison.json').write_text(json.dumps(row, indent=2), encoding='utf-8')
        results.append(row); (OUT/'comparison.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
        print(json.dumps({k: v for k, v in row.items() if k != 'outcome'}, ensure_ascii=True), flush=True)


if __name__ == '__main__':
    main()
