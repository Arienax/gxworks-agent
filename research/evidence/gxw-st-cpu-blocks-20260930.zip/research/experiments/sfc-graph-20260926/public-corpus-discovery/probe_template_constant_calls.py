from pathlib import Path
import sys,json,collections
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from replay_gxw_workspace import prepare,trace_prepared
P=Path(__file__).resolve().parent
out=P/'builtin-template-call-controls/prefixed-radix-constants/constant-call-trace'
prepare(out.parent/'changed.gxw',out,compile=True,export_project=True)
print(json.dumps(trace_prepared(out,P/'TraceTemplateConstants.js',timeout=45)),flush=True)
events=[json.loads(l) for l in (out/'events.jsonl').read_text().splitlines()]
rows=[e['payload'] for e in events if e.get('payload',{}).get('event')=='template-constant-read']
result=dict(total_calls=len(rows),callers=dict(collections.Counter(r['caller_rva'] for r in rows)),rows=rows,errors=[e for e in events if e.get('type')=='error'],pcode_equal=(out/'pcode-0-0.bin').read_bytes()==(out.parent/'native/pcode-0-0.bin').read_bytes())
(out/'comparison.json').write_text(json.dumps(result,indent=2))
print(json.dumps({k:v for k,v in result.items() if k!='rows'}),flush=True)
print(json.dumps([r for r in rows if r['requested'] in [445,461,478,497,515,534]]),flush=True)
