"""Separate local declaration ownership by folder, payload owner and logical name.

All variants use two simple ST POUs in one native-validated task, distinct
local constants and unchanged task order. No runtime or device session.
"""
from pathlib import Path
import base64,json,struct,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.declarations import parse_declarations,edit_declarations,serialize_declarations
from gxw.container_writer import validate_cfb_streams,replace_stream_within_allocation
from gxw.project_metadata import current_rows,logical_mapping
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import run
from native_gxw_tokens import native_batch,native_il_projection,Q_DLL
P=Path(__file__).resolve().parent
out=P/'q-label-owner-binding-v2';out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
seed=(P/'q-task-st-order/two-ST/changed.gxw').read_bytes()
assert not validate_cfb_streams(seed).get('Project.gd2')
streams={s.logical_name:s.raw for s in inspect_project(seed).streams if s.logical_name}
A,B='기본동작','응용동작1'
def st(raw,text):
    text=(text+'\0').encode('utf-16le')
    result=bytearray(raw[:54]+b'\xc1'+bytes(8)+struct.pack('<II',1,len(text)//2)+text+bytes(28))
    struct.pack_into('<II',result,55,len(result)-83,len(result)-83)
    return bytes(result)
def string(value):
    raw=(value+'\0').encode('utf-16le');return struct.pack('<I',len(raw)//2)+raw
source=seed;receipts=[]
for name,mark,add in [(A,'11','100'),(B,'22','200')]:
    logical=name+'.Labels.lh';doc=parse_declarations(streams[logical],logical_name=logical)
    new=serialize_declarations(edit_declarations(doc,upserts=[dict(name='OwnerMark',data_type='INT',class_name='VAR_CONSTANT',initial_value=mark)]))
    source,receipt=patch_raw(source,logical,streams[logical],new);receipts.append(receipt)
    logical=name+'.Program.pou';new=st(streams[logical],'STATE := OwnerMark + '+add+';\r\n')
    source,receipt=patch_raw(source,logical,streams[logical],new);receipts.append(receipt)
(out/'baseline-preparation.json').write_text(json.dumps(dict(seed_sha256=sha256(seed),source_sha256=sha256(source),receipts=receipts),indent=2),encoding='utf-8')
streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
outer=validate_cfb_streams(source);xml=outer['projectdatalist.xml'];xml_rows,encoding=current_rows(xml,'DSPROJECTDATA','D_Projectdata')
fields={r.fields()['szName'].text:r.fields() for r in xml_rows if r.fields().get('szName') and r.fields().get('bScrapFlag').text=='false'}
plans=[('baseline',False,False),('folder-swap',True,False),('payload-owner-swap',False,True),('folder-and-owner-swap',True,True)]
rows=[];requests=[];files={}
for case,swap_folder,swap_owner in plans:
    directory=out/case;directory.mkdir();changed=source;edits=[]
    if swap_folder:
        modified=bytearray(xml)
        for name,other in [(A,B),(B,A)]:
            logical=name+'.Labels.lh';node=fields[logical]['uiFolderNo'];new=fields[other+'.Labels.lh']['uiFolderNo'].text.encode(encoding)
            assert len(new)==node.content_end-node.content_start
            modified[node.content_start:node.content_end]=new
            edits.append(dict(logical_name=logical,field='uiFolderNo',old=node.text,new=new.decode(encoding)))
        modified=bytes(modified);assert logical_mapping(modified)==logical_mapping(xml)
        changed=replace_stream_within_allocation(changed,'projectdatalist.xml',modified)
        assert validate_cfb_streams(changed)==dict(outer,**{'projectdatalist.xml':modified})
        assert {s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}==streams
    if swap_owner:
        for name,other in [(A,B),(B,A)]:
            logical=name+'.Labels.lh';raw=streams[logical];doc=parse_declarations(raw,logical_name=logical)
            assert doc.owner_name==name
            count=struct.unpack_from('<I',raw,54)[0];end=58+count*2
            new=raw[:54]+string(other)+raw[end:]
            modified=parse_declarations(new,logical_name=logical)
            assert modified.owner_name==other and [r.raw for r in modified.rows]==[r.raw for r in doc.rows]
            changed,receipt=patch_raw(changed,logical,raw,new)
            edits.append(dict(logical_name=logical,field='embedded_owner',old=name,new=other,receipt=receipt))
    path=directory/'input.gxw';path.write_bytes(changed)
    (directory/'mutation.json').write_text(json.dumps(dict(source_sha256=sha256(source),changed_sha256=sha256(changed),edits=edits),indent=2),encoding='utf-8')
    for attempt in range(1,9):
        native=directory/('native' if attempt==1 else 'native-v'+str(attempt))
        result=run(path,native,compile=True,snapshot_frontend=True,export_project=True,project_alias='QLABELOWNER')
        events=[json.loads(s) for s in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
        if (native/'pcode-0-0.bin').exists() or not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
    row=dict(case=case,native_directory=str(native.relative_to(out)),native={k:result[k] for k in ('returncode','open_succeeded','compile_completed','compiler_rejected','diagnostics')})
    snapshot=native/'frontend-snapshot.json'
    if snapshot.exists():
        build=json.loads(snapshot.read_text(encoding='utf-8-sig'))['build']
        pool=next(r['data'] for r in build['relocations'] if r['offset']==44)
        records=[]
        for offset in range(0,len(base64.b64decode(pool['raw'])),56):
            frontend_fields={}
            for field,label in [(8,'pou'),(16,'buffer16'),(24,'buffer24')]:
                blob=next(r['data'] for r in pool['relocations'] if r['offset']==offset+field)
                data=base64.b64decode(blob['raw']);frontend_fields[label]=data.rstrip(b'\0').decode('cp949') if field==8 else dict(bytes=len(data),sha256=sha256(data),base64=blob['raw'])
            records.append(frontend_fields)
        row['frontend_pous']=records
    if row['native']['returncode']==0 and row['native']['compile_completed'] and not row['native']['compiler_rejected']:
        files[case]={}
        for f in sorted(native.glob('pcode-*.bin')):
            raw=f.read_bytes();files[case][f.name]=len(requests)
            requests.append(dict(mode='decode',input_base64=base64.b64encode(raw+b'\0').decode()))
    rows.append(row);(directory/'comparison.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in row.items() if k!='frontend_pous'}),flush=True)
answers=native_batch(requests,out/'native-pcode-decode',dll=Q_DLL,cpu_code=209)
decoded=[]
for request,answer in zip(requests,answers,strict=True):
    assert answer['return_code']=='0x00000000' and answer['consumed_bytes']==len(base64.b64decode(request['input_base64']))-1
    projection=native_il_projection(base64.b64decode(answer['output_base64']),encoding='cp949');assert not projection['text_gaps']
    decoded.append(projection['records'])
result=dict(cases=rows,files=files,decoded=decoded,scope=__doc__)
(out/'comparison.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(main_pcode={case:decoded[names['pcode-0-0.bin']] for case,names in files.items()})),flush=True)
