"""Capture compiler-boundary sources for conditional FB connections."""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from replay_gxw_workspace import prepare,trace_prepared
P=Path(__file__).resolve().parent
for case in sys.argv[1:] or ['int-literal','int-device']:
 parent=P/'scpi-guarded-inputs'/case
 for attempt in range(1,9):
  out=parent/('compiler-trace' if attempt==1 else 'compiler-trace-v'+str(attempt))
  if out.exists():
   if (out/'pcode-0-0.bin').exists() and not (out/'comparison.json').exists():
    result=dict(reused_completed_trace=True);break
   continue
  prepare(parent/'changed.gxw',out,compile=True,export_project=True)
  result=trace_prepared(out,ROOT/'research/native/CompilerTrace.js',timeout=55)
  native=[json.loads(s) for s in (out/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
  if (out/'pcode-0-0.bin').exists():break
  if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in native):raise RuntimeError('Unexpected trace failure retained')
 else:raise RuntimeError('Fresh helper collision bound reached')
 events=[json.loads(s) for s in (out/'events.jsonl').read_text().splitlines()]
 summary=[]
 for event in events:
  e=event.get('payload',{})
  if e.get('event')!='enter' or e.get('name')!='Compile':continue
  buffers={b['label']:b for b in e['buffers']};units=[]
  for key,b in buffers.items():
   if key.startswith('name_'):
    name=bytes.fromhex(b['bytes']).split(b'\0')[0].decode('ascii','backslashreplace')
    captured=buffers[key.replace('name_','source_')]
    source=bytes.fromhex(captured['bytes']) if captured['bytes'] is not None else b'' if captured['requested_size']==0 else None
    units.append(dict(name=name,bytes=captured['requested_size'],prefix_hex=source[:80].hex() if source is not None else None))
  summary.append(dict(module=e['module'],id=e['id'],units=units))
 result.update(compiles=summary,pcode_equal=all(f.read_bytes()==(parent/'native'/f.name).read_bytes() for f in out.glob('pcode-*.bin')),
               errors=[e for e in events if e.get('type')=='error'])
 (out/'comparison.json').write_text(json.dumps(result,indent=2));print(json.dumps(dict(case=case,**result)),flush=True)
