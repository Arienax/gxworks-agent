from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from replay_gxw_workspace import prepare,trace_prepared
P=Path(__file__).resolve().parent
out=P/'analysis-import-target-trace'
prepare(P/'ST-standard-timer-controls/TON_E_member_read/native/native-saved.gxw',out,compile=True,analysis_version=3,analysis_queries=[dict(name='all',keys=[],declared=1,plural=1,symbol='',scope='')])
r=trace_prepared(out,P/'TraceAnalysisImports.js',timeout=45)
print(json.dumps(r))
for line in (out/'events.jsonl').read_text().splitlines():
 if 'analysis-' in line:print(line)
