"""Offline holdouts for shifted pools, alternate banks and allocation failure."""
from pathlib import Path
import json,struct,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from probe_gxw_parameters import project_allocation_ranges
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import prepare,run,trace_prepared
from source_q_allocation import predict
P=Path(__file__).resolve().parent
OUT=P/'native-allocation-range-holdouts';OUT.mkdir(exist_ok=False)
(OUT/'probe.py').write_bytes(Path(__file__).read_bytes());(OUT/'predictor-before.py').write_bytes((P/'source_q_allocation.py').read_bytes())
hook=OUT/'observer.js';hook.write_bytes((P/'native-allocation-bitmap-v2/observer.js').read_bytes())
assert sha256(Path('D:/GXWORKS2/Easysocket/Compiler/ECCompiler_IEC.dll').read_bytes())=='f58e7c70b855526bf2f943399a14089f771a43109b13ee9af34c88fb065cf4d7'
source=(P/'scpi-instance-binding-controls/same-instance/native/native-saved.gxw').read_bytes()
streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name};name=next(n for n in streams if n.endswith('.prj'));old=streams[name]
metadata=project_allocation_ranges(old);byname={r['name']:r for r in metadata['ranges']}
specs={'shifted':{'D':(8000,9000),'M':(5000,6000),'T':(128,255)},'word-fallback':{'D':(7000,7003),'W':(0x100,0x7ff)},'bit-fallback':{'M':(5000,5003),'B':(0x100,0x3ff)},'word-exhausted':{'D':(7000,7003)}}
rows=[]
for case,changes in specs.items():
 directory=OUT/case;directory.mkdir();raw=bytearray(old)
 for key,pair in changes.items():struct.pack_into('<II',raw,byname[key]['offset'],*pair)
 changed,receipt=patch_raw(source,name,old,bytes(raw));path=directory/'changed.gxw';path.write_bytes(changed)
 after={s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name};assert all(after[k]==v for k,v in streams.items() if k!=name)
 mutation=dict(source_sha256=sha256(source),changed_sha256=sha256(changed),changes=changes,receipt=receipt,unrelated_payloads='byte-identical',legacy_range_copy='preserved; only authoritative extended pairs changed')
 (directory/'mutation.json').write_text(json.dumps(mutation,indent=2))
 try:
  prediction=predict(after,scpi_calls=True);pre=dict(allocations=prediction['allocations'],status='predicted')
 except Exception as exc:pre=dict(status='not-predicted',error=str(exc))
 (directory/'prediction-before-native.json').write_text(json.dumps(pre,indent=2))
 for attempt in range(1,5):
  baseline_dir=directory/f'untraced-{attempt}';baseline=run(path,baseline_dir,compile=True,export_project=True,snapshot_frontend=True,project_alias='ALLOCRANGE')
  ne=[json.loads(l) for l in (baseline_dir/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
  if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in ne):break
 for attempt in range(1,5):
  traced=directory/f'trace-{attempt}';prepare(path,traced,compile=True,export_project=True,snapshot_frontend=True,project_alias='ALLOCRANGE');process=trace_prepared(traced,hook)
  ne=[json.loads(l) for l in (traced/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
  if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in ne):break
 raw_events=[json.loads(l) for l in (traced/'events.jsonl').read_text().splitlines()];events=[e['payload'] for e in raw_events if e.get('type')=='send']
 def errors_in(obj):
  if isinstance(obj,dict):return any(k.endswith('error') for k in obj) or str(obj.get('event','')).endswith('-error') or any(errors_in(v) for v in obj.values())
  if isinstance(obj,list):return any(errors_in(v) for v in obj)
  return False
 errors=[e for e in raw_events if e.get('type')=='error' or errors_in(e.get('payload'))]
 codes={f.name:f.read_bytes() for f in baseline_dir.glob('pcode-*.bin')};exact={n:(traced/n).exists() and (traced/n).read_bytes()==b for n,b in codes.items()}
 allocations=[e for e in events if e['event']=='typed-allocation'];pools=[e for e in events if e['event']=='pool-allocation']
 row=dict(case=case,source=str(path),source_sha256=sha256(changed),baseline_directory=str(baseline_dir),trace_directory=str(traced),baseline=baseline,process=process,errors=errors,exact_pcode=exact,allocations=allocations,pools=pools)
 (directory/'comparison.json').write_text(json.dumps(row,indent=2));rows.append(row);(OUT/'comparison.json').write_text(json.dumps(rows,indent=2))
 print(json.dumps(dict(case=case,returncode=baseline['returncode'],compile_completed=baseline['compile_completed'],compiler_rejected=baseline['compiler_rejected'],diagnostics=baseline['diagnostics'],errors=errors,exact=exact,pool_count=len(pools))),flush=True)
 if errors or not all(exact.values()):break
