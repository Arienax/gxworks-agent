from pathlib import Path
import sys,json,base64
ROOT=Path(__file__).resolve().parents[4];sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.declarations import parse_declarations,parse_structure_declarations,_string
from probe_gxw_integrity import patch_verified_payloads
from replay_gxw_workspace import run
from probe_gxw_library_sources import snapshot_library_pous,observed_library_declarations
from crosscheck_fx3g_library_sources import child,raw,name,table_pool
from probe_fx3g_library_declarations import native_global_rows
P=Path(__file__).resolve().parent;OUT=P/'library-declaration-authority'
BASE=P/'fx3g-library-source-roundtrip-v6/true-source-only/compile-1'
TARGETS=[('FB_AM_BUZZER.Labels\\AlarmManger.lnl','.llv','Reset'),('GVL_AM\\AlarmManger.lng','.lgv','c_AM_ERROR'),('ST_AM_ALARM\\AlarmManger.lns','.lst','Latch')]

def main():
 OUT.mkdir(exist_ok=False);(OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
 source=(BASE/'native-saved.gxw').read_bytes();streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name};metadata=[]
 for target,suffix,label in TARGETS:
  d=parse_structure_declarations(streams[target],logical_name=target) if target.endswith('.lns') else parse_declarations(streams[target],logical_name=target)
  row,=[r for r in (d.members if target.endswith('.lns') else d.rows) if r.name==label]
  original=row.comment;assert len(original)>8
  metadata.append(dict(target=target,companion=target[:-4]+suffix,row=label,original=original,source_tag='SRC_'+original[4:],companion_tag='CPY_'+original[4:]))
 results=[]
 for case in ('companion-only','conflicting-copies'):
  out=OUT/case;out.mkdir();replacements={}
  for m in metadata:
   for target,tag in [(m['companion'],m['companion_tag'])]+([(m['target'],m['source_tag'])] if case=='conflicting-copies' else []):
    old=streams[target];needle=_string(m['original']);assert old.count(needle)==1
    new=old.replace(needle,_string(tag));assert len(new)==len(old);replacements[target]=(old,new)
  candidate,receipt=patch_verified_payloads(source,replacements)
  after={s.logical_name:s.raw for s in inspect_project(candidate).streams if s.logical_name}
  touched=[k for k in streams if streams[k]!=after[k]];assert set(touched)==set(replacements)
  path=out/'candidate.gxw';path.write_bytes(candidate)
  (out/'prediction-before-native.json').write_text(json.dumps(dict(source_sha256=sha256(source),candidate_sha256=sha256(candidate),touched=touched,receipt=receipt,metadata=metadata,expected_pcode_sha256=sha256((BASE/'pcode-0-0.bin').read_bytes())),indent=2),encoding='utf-8')
  row=dict(case=case,phases=[])
  for phase in ('compile','reopen'):
   for attempt in range(1,5):
    native=out/f'{phase}-{attempt}';outcome=run(path,native,compile=True,export_project=True,snapshot_frontend=True,program_check=True,project_alias='DECLCOPY')
    events=[json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
   result=dict(phase=phase,native_directory=str(native),outcome=outcome,observations=[])
   if (native/'frontend-snapshot.json').exists():
    snap=json.loads((native/'frontend-snapshot.json').read_text(encoding='utf-8'))
    local,=[r for r in snapshot_library_pous(snap) if (r['library'],r['name'])==('AlarmManger','FB_AM_BUZZER')]
    localrows=observed_library_declarations(base64.b64decode(local['declaration_raw_base64']))['rows']
    libs=child(snap['build'],8);offset,=[i for i in range(0,len(raw(libs)),32) if name(child(libs,i))=='AlarmManger']
    globals_=table_pool(child(libs,offset+8));structures=table_pool(child(libs,offset+16))
    native_rows=[localrows,native_global_rows(globals_['GVL_AM']),native_global_rows(structures['ST_AM_ALARM'],structure=True)]
    for m,rows in zip(metadata,native_rows,strict=True):
     actual,=[r for r in rows if r['name']==m['row']]
     result['observations'].append(dict(target=m['target'],native_comment=actual['comment'],expected_comment=m['source_tag'] if case=='conflicting-copies' else m['original']))
   pcode=native/'pcode-0-0.bin';result['pcode_matches_baseline']=pcode.exists() and pcode.read_bytes()==(BASE/'pcode-0-0.bin').read_bytes()
   path=native/'native-saved.gxw'
   if path.exists():
    saved={s.logical_name:s.raw for s in inspect_project(path.read_bytes()).streams if s.logical_name}
    result['saved_markers']=[dict(target=m['target'],copies=[dict(logical_name=n,counts={tag:saved[n].count(_string(m[tag])) for tag in ('original','source_tag','companion_tag')}) for n in (m['target'],m['companion'])]) for m in metadata]
   row['phases'].append(result)
   (out/'comparison.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
   print(json.dumps(dict(case=case,phase=phase,open=outcome['open_succeeded'],rejected=outcome['compiler_rejected'],saved=path.exists(),pcode_matches_baseline=result['pcode_matches_baseline'],observations=result['observations'],saved_markers=result.get('saved_markers')),ensure_ascii=True),flush=True)
   if not path.exists() or outcome['compiler_rejected']:break
  results.append(row);(OUT/'comparison.json').write_text(json.dumps(results,indent=2),encoding='utf-8')

if __name__=='__main__':main()
