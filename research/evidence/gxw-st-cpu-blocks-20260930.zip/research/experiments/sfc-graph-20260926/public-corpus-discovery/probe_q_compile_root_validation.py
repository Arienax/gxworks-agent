"""Distinguish task emission roots from source validation dependencies.

Accepted MIT-derived ST controls retain both POU declarations and source
envelopes. A single source syntax/name failure is moved between assigned and
unassigned POUs; empty tasks provide an independent emission control.
"""
from pathlib import Path
import base64,json,struct,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.container_writer import validate_cfb_streams
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import run
from native_gxw_tokens import native_batch,native_il_projection,Q_DLL
P=Path(__file__).resolve().parent
out=P/'q-compile-root-validation';out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
source=(P/'q-label-owner-binding-v2/baseline/input.gxw').read_bytes()
assert not validate_cfb_streams(source).get('Project.gd2')
streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
A,B='기본동작','응용동작1';task=B+'.tsk'
def string(value):
    raw=(value+'\0').encode('utf-16le');return struct.pack('<I',len(raw)//2)+raw
def task_bytes(names):
    return streams[task][:84]+struct.pack('<I',len(names))+b''.join(string(n)+struct.pack('<I',i+1)+string('') for i,n in enumerate(names))
def st(raw,text):
    text=(text+'\0').encode('utf-16le')
    result=bytearray(raw[:54]+b'\xc1'+bytes(8)+struct.pack('<II',1,len(text)//2)+text+bytes(28))
    struct.pack_into('<II',result,55,len(result)-83,len(result)-83)
    return bytes(result)
plans=[('single-valid',[B],None,None),
       ('unassigned-syntax-error',[B],A,'STATE := ;\r\n'),
       ('unassigned-name-error',[B],A,'STATE := NeverDeclared;\r\n'),
       ('assigned-syntax-error',[B],B,'STATE := ;\r\n'),
       ('empty-task-valid',[],None,None),
       ('empty-task-syntax-error',[],A,'STATE := ;\r\n')]
rows=[];requests=[];files={}
for case,names,edited,text in plans:
    directory=out/case;directory.mkdir();changed=source;edits=[]
    new=task_bytes(names);changed,receipt=patch_raw(changed,task,streams[task],new);edits.append(receipt)
    expected=dict(streams,**{task:new})
    if edited:
        logical=edited+'.Program.pou';new=st(streams[logical],text)
        changed,receipt=patch_raw(changed,logical,streams[logical],new);edits.append(receipt);expected[logical]=new
    assert {s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}==expected
    path=directory/'input.gxw';path.write_bytes(changed)
    (directory/'mutation.json').write_text(json.dumps(dict(source_sha256=sha256(source),changed_sha256=sha256(changed),task_programs=names,
        edited_program=edited,st_text=text,edits=edits,preservation='Every unrelated logical payload is byte-identical.'),indent=2),encoding='utf-8')
    for attempt in range(1,9):
        native=directory/('native' if attempt==1 else 'native-v'+str(attempt))
        result=run(path,native,compile=True,snapshot_frontend=True,export_project=True,project_alias='QROOTVALIDATION')
        events=[json.loads(s) for s in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
        if (native/'pcode-0-0.bin').exists() or not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
    row=dict(case=case,task_programs=names,edited_program=edited,native_directory=str(native.relative_to(out)),
        native={k:result[k] for k in ('returncode','open_succeeded','compile_completed','compiler_rejected','diagnostics')})
    snapshot=native/'frontend-snapshot.json'
    if snapshot.exists():
        pool=next(r['data'] for r in json.loads(snapshot.read_text(encoding='utf-8-sig'))['build']['relocations'] if r['offset']==44)
        row['frontend_pous']=[base64.b64decode(r['data']['raw']).rstrip(b'\0').decode('cp949') for r in pool['relocations'] if r['offset']%56==8]
    if row['native']['returncode']==0 and row['native']['compile_completed'] and not row['native']['compiler_rejected']:
        files[case]={}
        for f in sorted(native.glob('pcode-*.bin')):
            raw=f.read_bytes();files[case][f.name]=len(requests)
            requests.append(dict(mode='decode',input_base64=base64.b64encode(raw+b'\0').decode()))
    rows.append(row);(directory/'comparison.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
    print(json.dumps(row),flush=True)
answers=native_batch(requests,out/'native-pcode-decode',dll=Q_DLL,cpu_code=209)
decoded=[]
for request,answer in zip(requests,answers,strict=True):
    assert answer['return_code']=='0x00000000' and answer['consumed_bytes']==len(base64.b64decode(request['input_base64']))-1
    projection=native_il_projection(base64.b64decode(answer['output_base64']),encoding='cp949');assert not projection['text_gaps'];decoded.append(projection['records'])
(out/'comparison.json').write_text(json.dumps(dict(cases=rows,files=files,decoded=decoded,scope=__doc__),ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(main_pcode={case:decoded[names['pcode-0-0.bin']] for case,names in files.items()})),flush=True)
