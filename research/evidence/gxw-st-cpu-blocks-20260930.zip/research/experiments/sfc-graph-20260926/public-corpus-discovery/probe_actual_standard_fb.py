from pathlib import Path
import sys,json,hashlib
from collections import Counter
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from replay_gxw_workspace import prepare,trace_prepared
P=Path(__file__).resolve().parent
imports=json.loads((P/'compiler-iec-import-targets.json').read_text())
export=next(s for s in json.loads((P/'standard-fb-exports.json').read_text()) if s['name'].startswith('?GetStandardFBKind@'))
target=next(s for s in imports if s['target_dll']==export['dll'])|dict(hook_rva=export['rva'])
for name,source in [('TON_E',P/'ST-standard-timer-controls/TON_E_true/changed.gxw'),('alias',P/'library-fb-alias-controls/TON_E/changed.gxw')]:
 out=P/'actual-standard-fb-traces'/name
 prepare(source,out,compile=True,export_project=True)
 script=out/'TraceActualStandardFB.js'
 script.write_text('const TARGET_SPECS='+json.dumps([target])+';\n'+(P/'TraceActualStandardFB.js').read_text())
 result=trace_prepared(out,script,timeout=45)
 messages=[json.loads(s) for s in (out/'events.jsonl').read_text().splitlines()]
 rows=[m['payload'] for m in messages if m.get('payload',{}).get('event')=='actual-standard-fb-kind']
 selected=[r for r in rows if 'TON' in (r['input'] or '')]
 summary=dict(trace=result,installed=[m['payload'] for m in messages if m.get('payload',{}).get('event')=='installed-via-resolved-iat'],errors=[m for m in messages if m.get('type')=='error'],total_calls=len(rows),calls=[dict(name=k[0],result=k[1],caller=k[2],count=v) for k,v in Counter((r['input'],r['result'],json.dumps(r['caller'])) for r in rows).items()],timer_calls=selected)
 (out/'summary.json').write_text(json.dumps(summary,indent=2))
 print(json.dumps(dict(case=name,trace=result,total_calls=len(rows),timer_calls=selected,errors=summary['errors'])),flush=True)
