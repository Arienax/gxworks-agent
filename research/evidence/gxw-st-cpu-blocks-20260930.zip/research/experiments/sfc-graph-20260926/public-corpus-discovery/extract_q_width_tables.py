"""Extract static Q71 width operands; never load or execute the vendor DLL."""
import hashlib
import json
import struct
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[1] / 're-tools'))
import pefile

def main():
    dll = Path(r'D:\GXWORKS2\Easysocket\CodeGenerator\ECCodeGenerator2.dll')
    digest = hashlib.sha256(dll.read_bytes()).hexdigest()
    assert digest == '2e5c47b0a0d0b59eb26dbab149862a05983a1fa9519a75e446bc680e7cc16f73'
    pe = pefile.PE(str(dll))
    app = []
    for i in range(256):
        raw = pe.get_data(0x10c350 + i * 11, 11)
        if raw[0] == 255:
            break
        app.append(dict(family=raw[0], variant=raw[1], values=list(struct.unpack_from('<4H', raw, 2)), kind=raw[10], raw=raw.hex()))
    basic = []
    for i in range(64):
        raw = pe.get_data(0xcb7e0 + i * 6, 6)
        basic.append(dict(family=i, kind=raw[5], raw=raw.hex()))
    groups = []
    for f in range(0x40, 0x70):
        row = pe.get_data(0x160e70 + (f - 0x40)*6, 6)
        for i in range(row[1]):
            raw = pe.get_data(0x160f90 + (row[0]+i)*14, 14)
            groups.append(dict(family=f, variant=raw[0], mask=int.from_bytes(raw[2:4], 'little'), raw=raw.hex()))
    result = dict(dll_sha256=digest, application=app, basic=basic, groups=groups)
    operand_rules=[]
    for i in range(700):
        raw=pe.get_data(0xc6690+i*4,4)
        if raw[0]==255:break
        offset=int.from_bytes(raw[2:4],'little')
        params=[]
        if offset!=0x7fff:
            n=pe.get_data(0xc7000+offset,1)[0]
            for class_id in pe.get_data(0xc7001+offset,n):
                rule=pe.get_data(0xc7318+class_id*16,16)
                params.append(dict(class_id=class_id,mask=int.from_bytes(rule[:2],'little'),devices=rule[2:].hex()))
        operand_rules.append(dict(family=raw[0],variant=raw[1],offset=offset,parameters=params))
    result['operand_rules']=operand_rules
    result['special_widths']={f'{f:02x}':pe.get_data(rva,n*3).hex() for f,rva,n in [(0x42,0xcbfa4,2),(0x62,0xcbfac,2),(0x6c,0xcbfb8,35)]}
    catalog=json.loads((HERE.parents[3]/'src/gxw/templates/q03udv-token-grammar.json').read_text())['headers']
    arities={}
    for key in catalog:
        f,v=(int(s,16) for s in key.split(':'))
        if f<0x40:count=pe.get_data(0xc6220+f,1)[0]
        elif f==0x40:count=pe.get_data(0xc56fc+v*6,1)[0]
        elif f in (0x42,0x62,0x6c):count=int.from_bytes(pe.get_data({0x42:0xca914,0x62:0xca915,0x6c:0xca917}[f]+v,1),'little',signed=True)
        elif 0x42<f<0x70:
            offset=int.from_bytes(pe.get_data(0xc2140+f*2,2),'little')+v
            count=pe.get_data(0xc46e2+offset*6,1)[0]
        else:continue
        arities[key]=count
    result['dispatch_arity']=arities
    z_limits=[]
    for i in range(1000):
        raw=pe.get_data(0xc92c8+i*16,16)
        if raw[0]==255:break
        z_limits.append(dict(family=raw[0],variant=raw[1],words=list(struct.unpack_from('<7H',raw,2))))
    result['z_limits']=z_limits
    for key, rva, size in [('device_classes',0xcbd48,512), ('basic_device_widths',0x163b90,23*16), ('operand_flags',0xc62a0,112*3), ('q71_operand_flags',0xc6540,112*3)]:
        result[key] = pe.get_data(rva,size).hex()
    (HERE/'q-width-static-tables.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')

if __name__ == '__main__':
    main()
