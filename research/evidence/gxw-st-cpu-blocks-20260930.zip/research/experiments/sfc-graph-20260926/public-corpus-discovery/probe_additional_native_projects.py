"""Independent native baselines for newly retrieved real GXW projects."""
from pathlib import Path
import json
import sys
ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'research')]
from gxw.lossless import inspect_project, sha256
from probe_gxw_simple_fb import frame_source
from replay_gxw_workspace import run

P = Path(__file__).resolve().parent
OUT = P/'additional-native-baselines'


def main():
    OUT.mkdir(exist_ok=False)
    (OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    plans = json.loads((P/'additional-real-projects/inventory.json').read_text(encoding='utf-8'))
    ready = []; results = []
    for plan in plans:
        directory = OUT/plan['case']; directory.mkdir()
        source = Path(plan['source']); raw = source.read_bytes(); predictions = []
        for stream in inspect_project(raw).streams:
            if not (stream.logical_name or '').endswith('.pou'):
                continue
            row = dict(logical=stream.logical_name, sha256=sha256(stream.raw), input_bytes=len(stream.raw))
            try:
                frame = frame_source(stream.raw)
                if any(t.raw[1] == 0xdf for t in frame.tokens):
                    raise ValueError('source has unresolved labels')
                filename = f'candidate-{len(predictions)}.bin'
                (directory/filename).write_bytes(frame.body)
                row.update(handling='raw-source-body-candidate', candidate_file=filename, candidate_sha256=sha256(frame.body))
            except ValueError as exc:
                row.update(handling='opaque-preserved', reason=str(exc))
            predictions.append(row)
        (directory/'predictions-before-native.json').write_text(json.dumps(dict(source=str(source), sha256=sha256(raw), programs=predictions), indent=2), encoding='utf-8')
        ready.append((plan, directory, source, predictions))
    for plan, directory, source, predictions in ready:
        for attempt in range(1, 5):
            native = directory/f'native-{attempt}'
            outcome = run(source, native, compile=True, export_project=True, snapshot_frontend=True,
                          change_sfc=plan['case'] == 'case-03', project_alias='EXTRAREAL')
            events = [json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
            if not any(e.get('operation') == 'NativeTemporaryDirectoryCollision' for e in events):
                break
        accepted = outcome['returncode'] == 0 and outcome['compile_completed'] and not outcome['compiler_rejected'] and (native/'native-saved.gxw').exists()
        outputs = {f.name: f.read_bytes() for f in native.glob('pcode-*-0.bin')}
        row = dict(case=plan['case'], source=str(source), native_directory=str(native),
            native_accepted=accepted, outcome=outcome, programs=predictions,
            outputs={n: dict(bytes=len(b), sha256=sha256(b)) for n, b in outputs.items()})
        for pred in predictions:
            if 'candidate_file' in pred:
                candidate = (directory/pred['candidate_file']).read_bytes()
                pred['byte_identical_outputs'] = [n for n, b in outputs.items() if candidate == b]
        if (native/'native-saved.gxw').exists():
            row['exported_programs'] = [dict(name=s.logical_name, bytes=len(s.raw), sha256=sha256(s.raw))
                for s in inspect_project((native/'native-saved.gxw').read_bytes()).streams if (s.logical_name or '').endswith(('.pou', '.lh'))]
        (directory/'comparison.json').write_text(json.dumps(row, indent=2), encoding='utf-8')
        results.append(row); (OUT/'comparison.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
        print(json.dumps(dict(case=plan['case'], native_accepted=accepted, outputs=row['outputs'], programs=predictions,
            diagnostics=outcome['diagnostics'], last_event=outcome.get('last_event') if not accepted else None)), flush=True)


if __name__ == '__main__':
    main()
