"""Discriminate SFC block identity/order from opaque local-declaration fields."""
from pathlib import Path
import json
import struct
import sys
ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'research')]
from gxw.lossless import inspect_project, sha256
from probe_gxw_task_graph import inspect_task_graph, _text
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import run
from source_fx_sfc_projection import expand_block, project_projection

P = Path(__file__).resolve().parent
OUT = P/'real-sfc-block-identity'


def inventory(source):
    return {s.logical_name: s.raw for s in inspect_project(source).streams if s.logical_name}


def field_hypothesis(source):
    streams = inventory(source); graph = inspect_task_graph(source)
    blocks = []
    for name, program in graph['programs'].items():
        label = streams[program['declarations']]
        _, end = _text(label, 54)
        number = struct.unpack_from('<I', label, end + 20)[0]
        assert number <= 255
        body, evidence = expand_block(streams[program['source_program']])
        blocks.append((number, body, name, program['declarations'], end + 20))
    assert len({b[0] for b in blocks}) == len(blocks)
    candidate = bytes.fromhex('056c010005')
    for number, body, *_ in sorted(blocks):
        candidate += bytes.fromhex('056c01020504dc') + bytes([number, 4]) + body + bytes.fromhex('056c010305')
    candidate += bytes.fromhex('056c010105033403')
    return candidate, [dict(number=n, program=p, declarations=l, number_offset=o) for n, _, p, l, o in blocks]


def main():
    OUT.mkdir(exist_ok=False)
    (OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    source = (P/'additional-real-projects/case-03/input.gxw').read_bytes()
    original = inventory(source); graph = inspect_task_graph(source)
    labels = [graph['programs'][f'MAIN_Block{i:03d}']['declarations'] for i in range(2)]
    plans = []
    for tag, numbers in [('block1-field7', {1: 7}), ('swap-block-fields', {0: 1, 1: 0})]:
        changed = source
        for index, number in numbers.items():
            name = labels[index]; raw = original[name]; _, end = _text(raw, 54)
            updated = bytearray(raw); struct.pack_into('<I', updated, end + 20, number)
            changed, _ = patch_raw(changed, name, raw, bytes(updated))
        plans.append((tag, changed, 'field hypothesis; full program check omitted, original already rejects'))
    for tag in ['grow-action', 'swap-action-registrations', 'reverse-task-order']:
        plans.append((tag, (P/'real-sfc-source-expansion'/tag/'source.gxw').read_bytes(),
            'conversion/export/reload only; separate full-check rejection retained in real-sfc-source-expansion'))
    ready = []
    for tag, data, scope in plans:
        directory = OUT/tag; directory.mkdir(); (directory/'source.gxw').write_bytes(data)
        field_code, fields = field_hypothesis(data); task_code, _ = project_projection(data)
        (directory/'candidate-field.bin').write_bytes(field_code)
        (directory/'candidate-task.bin').write_bytes(task_code)
        (directory/'predictions-before-native.json').write_text(json.dumps(dict(scope=scope, fields=fields,
            source_sha256=sha256(data), candidate_field_sha256=sha256(field_code), candidate_task_sha256=sha256(task_code)), indent=2), encoding='utf-8')
        ready.append((tag, directory, field_code, task_code, scope))
    results = []
    for tag, directory, field_code, task_code, scope in ready:
        attempts = []
        for phase, path in [('convert-export', directory/'source.gxw'), ('reload-convert-export', None)]:
            if path is None:
                path = native/'native-saved.gxw'
                if not path.exists():
                    break
            for attempt in range(1, 5):
                native = directory/f'{phase}-{attempt}'
                outcome = run(path, native, compile=True, change_sfc=True, snapshot_frontend=True,
                    export_project=True, project_alias='SFCFIELD')
                events = [json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
                if not any(e.get('operation') == 'NativeTemporaryDirectoryCollision' for e in events):
                    break
            output = native/'pcode-0-0.bin'
            actual = output.read_bytes() if output.exists() else None
            item = dict(phase=phase, native_directory=str(native), outcome=outcome,
                conversion_export_succeeded=outcome['returncode'] == 0 and outcome['compile_completed'] and not outcome['compiler_rejected'] and (native/'native-saved.gxw').exists(),
                field_hypothesis_exact=actual == field_code, task_hypothesis_exact=actual == task_code,
                actual_sha256=sha256(actual) if actual is not None else None)
            attempts.append(item)
            print(json.dumps(dict(case=tag, **{k: v for k, v in item.items() if k != 'outcome'})), flush=True)
        row = dict(case=tag, scope=scope, phases=attempts)
        (directory/'comparison.json').write_text(json.dumps(row, indent=2), encoding='utf-8')
        results.append(row); (OUT/'comparison.json').write_text(json.dumps(results, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
