"""Measure the newly recovered native assignment query on real source labels."""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'research')]
from probe_gxw_native_assignments import inspect

P = Path(__file__).resolve().parent
OUT = P / 'native-assignment-real-corpus'
OUT.mkdir(exist_ok=False)
sources = [json.loads(line) for line in (P / 'native-allocation-inventory/results.jsonl').read_text().splitlines()]
for source in sources:
    row = dict(case=source['case'], source=source['source'], source_sha256=source['source_sha256'])
    try:
        result = inspect(Path(source['source']), OUT / ('case-' + str(source['case']).zfill(2)))
        row.update(summary=result['summary'], addresses=result['address_statuses'],
                   expanded_rows=result['expanded_assignment_rows'], gaps=result['gaps'], native=result['native'])
    except Exception as exc:
        row['error'] = str(exc)
    with (OUT / 'results.jsonl').open('a', encoding='utf-8') as output:
        output.write(json.dumps(row) + '\n')
    print(json.dumps({k: v for k, v in row.items() if k not in ['native', 'source']}), flush=True)
