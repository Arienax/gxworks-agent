"""Saved-byte, finite integer witnesses for the measured ST FB transfers."""
from pathlib import Path
import json,sys
P=Path(__file__).resolve().parent
ROOT=P.parents[3]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research'),str(P)]
from probe_minimal_conditional_port_writes import save
from source_q_st_calls import predict
from witness_nested_index_alias import decode,token_witness
from verify_temporary_check_correspondence import verify


def main():
    groups=['st-fb-index-capture-20260930','st-fb-index-liveness-20260930','st-fb-index-predictions-20260930']
    fields={'index':'probeIndex','scalar':'probeOther','result':'probeResult','array0':'probeR0','array1':'probeR1','array2':'probeR2'}
    rows=[]
    for group in groups:
        directory=P/group
        plan=json.loads((directory/'experiment-plan.json').read_text()) if (directory/'experiment-plan.json').exists() else {}
        listings={(r['case'],r['resource']):r['records'] for r in json.loads((directory/'native-listings.json').read_text())}
        for case in json.loads((directory/'comparison.json').read_text()):
            d=directory/case['case'];n=Path(case['native_directory'])
            if not case['check']:
                rows.append(dict(group=group,case=case['case'],handling='rejected-before-current-check',diagnostics=case['diagnostics']));continue
            prediction=predict((d/'input.gxw').read_bytes());code=(n/'pcode-0-0.bin').read_bytes()
            assert prediction['output']==code
            binding={a['name']:a['allocated_family']+str(a['number']) for a in prediction['declarations'] if a['owner']=='POU_01'}
            records=decode(code)
            assert [{k:r[k] for k in ('kind','op','args')} for r in records]==listings[(case['case'],'MAIN')]
            outcomes={key:token_witness(records,binding[name])['result'] for key,name in fields.items()}
            expected=plan.get('expected_offline_results',{}).get(case['case'])
            if expected:assert all(outcomes[k]==v for k,v in expected.items())
            witness=token_witness(records,binding['probeResult'])
            rows.append(dict(group=group,case=case['case'],handling='offline-initialized-integer-witness',
                source_prediction_equals_current=True,core_decode_equals_native=True,bindings=binding,outcomes=outcomes,
                before_native_expected=expected,transfers=prediction['transfers'],steps=witness['steps'],indexed_reads=witness['indexed_reads']))
            print(json.dumps(dict(group=group,case=case['case'],outcomes=outcomes,predicted_before_native=expected is not None)),flush=True)
    output=P/'st-fb-index-predictions-20260930'
    save(output/'offline-transfer-witnesses.json',dict(scope='Finite initialized INT arithmetic; no uninitialized native memory reads; not PLC execution and not a general language-semantics claim.',cases=rows))
    correspondence=verify(groups);save(output/'current-check-export-correspondence.json',correspondence)
    (output/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    print(json.dumps({k:v for k,v in correspondence.items() if k not in ('phases','notes')}))


if __name__=='__main__':main()
