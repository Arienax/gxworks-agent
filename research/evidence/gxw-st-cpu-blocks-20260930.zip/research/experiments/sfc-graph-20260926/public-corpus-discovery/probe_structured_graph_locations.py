"""Fresh native location/xref controls for archived vendor-saved graphical POUs."""
from collections import Counter
import json
from pathlib import Path
import sys
import zipfile
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.compiler_debug import parse_compiler_debug
from gxw.structured_pou import parse_structured_pou
from probe_gxw_debug_locations import search_maps
from replay_gxw_workspace import run
P=Path(__file__).resolve().parent
OUT=P/'structured-graph-location-controls';OUT.mkdir(exist_ok=True)
for case,archive,member in [('function','gxw-20260910.zip','fnc.gxw'),
    ('parallel','gxw-generation-20260910.zip','relay_parallel_compile.gxw'),
    ('library_fb','gxw-generation-20260910.zip','fresh_fbd_compile.gxw'),
    ('multi_network','gxw-block-generation-20260913.zip','samples/R_compile.gxw')]:
    out=OUT/case;out.mkdir(exist_ok=True)
    if (out/'comparison.json').exists():continue
    with zipfile.ZipFile(ROOT/'research/evidence'/archive) as z:raw=z.read(member)
    source=out/'source.gxw';source.write_bytes(raw)
    (out/'source.json').write_text(json.dumps(dict(archive=archive,member=member,sha256=sha256(raw)),indent=2))
    queries=[dict(resource='MAIN',start_step=i,step_count=1,timestamp=0) for i in range(160)]
    result=run(source,out/'native',compile=True,export_project=True,project_alias='GRAPHLOC',
        pcode_location_queries=queries,analysis_queries=[dict(name='all',keys=[],symbol='',scope='',declared=0,plural=0)],analysis_version=3)
    summary=dict(case=case,native={k:result[k] for k in ['returncode','compile_completed','compiler_rejected','diagnostics']})
    if result.get('native_export'):
        streams={s.logical_name:s.raw for s in inspect_project((out/'native/native-saved.gxw').read_bytes()).streams if s.logical_name}
        debug=parse_compiler_debug(streams['DebugInformation2.dat'])
        summary['elements']=[dict(index=i,kind=e.kind_code,fields=e.fields,names=[v.decode('cp936') for v in e.names],rows=debug.offset_tables[e.offset_table_index].rows) for i,e in enumerate(debug.elements)]
        summary['search_maps']=search_maps(debug,encoding='cp936')
        summary['graph']={}
        for name,blob in streams.items():
            if not name.endswith('.Program.pou'):continue
            p=parse_structured_pou(blob,logical_name=name)
            summary['graph'][name]=[dict(offset=n.offset,kind=n.kind.value,symbol=n.symbol,bbox=[n.bbox.left,n.bbox.top,n.bbox.right,n.bbox.bottom]) for n in p.nodes]
        refs=json.loads((out/'native/native-program-analysis.json').read_text(encoding='utf-8-sig'))['queries'][0]['rows']
        loc=json.loads((out/'native/native-pcode-locations.json').read_text(encoding='utf-8-sig'))
        unique=[]
        for l in loc:
            if l['location'] is not None and l['location'] not in unique:unique.append(l['location'])
        summary['native_locations']=unique;summary['native_references']=refs
        summary['location_counts']=dict(Counter(str(l['code']) for l in loc))
    (out/'comparison.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in summary.items() if k not in ['native_references','search_maps']}),flush=True)
