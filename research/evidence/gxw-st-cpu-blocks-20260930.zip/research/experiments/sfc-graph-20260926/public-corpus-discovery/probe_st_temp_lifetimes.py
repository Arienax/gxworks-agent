"""Probe expression liveness in a real Q ST source container."""
from pathlib import Path
import base64,json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from gxw.declarations import parse_declarations,edit_declarations,serialize_declarations
from gxw.project_metadata import mark_observed_source_compile_pending
from probe_gxw_st_sources import replace_observed_st
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_program_check_resources import SCRIPT
from probe_minimal_conditional_port_writes import streams,observe,save
from native_gxw_tokens import native_batch,Q_DLL,native_il_records
P=Path(__file__).resolve().parent
OUT=P/'st-temp-lifetimes-20260930'


def main():
    OUT.mkdir(exist_ok=False);(OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    trace=OUT/'trace.js';trace.write_text('(()=>{'+(P/'native-allocation-bitmap-v2/observer.js').read_text()+'\n'+(P/'observe_expression_temporaries.js').read_text()+'\n})();\n(()=>{'+SCRIPT+'\n})();',encoding='utf-8')
    original=(P/'ST-nested-FB-controls/single/native/native-saved.gxw').read_bytes();before=streams(original)
    declarations='POU_01.Labels.lh';doc=parse_declarations(before[declarations],logical_name=declarations)
    variables=['probe'+n for n in ('A','B','C','D','E','F','G','H','R1','R2')]
    new_labels=mark_observed_source_compile_pending(serialize_declarations(edit_declarations(doc,upserts=[dict(name=n,data_type='INT') for n in variables])),logical_name=declarations)
    plans={
      'add-pair':'probeR1 := probeA + probeB;\r\nprobeR2 := probeC + probeD;\r\n',
      'balanced-pair':'probeR1 := (probeA + probeB) - (probeC + probeD);\r\nprobeR2 := (probeE + probeF) - (probeG + probeH);\r\n',
      'left-nested-pair':'probeR1 := ((probeA + probeB) + probeC) + probeD;\r\nprobeR2 := ((probeE + probeF) + probeG) + probeH;\r\n',
    }
    ready=[]
    for case,text in plans.items():
        d=OUT/case;d.mkdir();name='POU_01.Program.pou'
        raw,_=replace_observed_st(before[name],text);raw=mark_observed_source_compile_pending(raw,logical_name=name)
        source,one=patch_raw(original,name,before[name],raw)
        source,two=patch_raw(source,declarations,before[declarations],new_labels)
        assert streams(source)==dict(before,**{name:raw,declarations:new_labels})
        path=d/'input.gxw';path.write_bytes(source)
        save(d/'before-native.json',dict(case=case,input_sha256=sha256(source),receipts=[one,two],source_text=text,
            hypotheses=['Final assignment can target the declared destination directly.',
                        'Balanced operands require simultaneous temporary slots.',
                        'Successive assignments can reuse compatible slots after their values die.']))
        ready.append((case,d,path))
    result=[];requests=[];keys=[]
    for case,d,path in ready:
        native,observed,process=observe(path,d,trace);code=(native/'pcode-0-0.bin').read_bytes()
        messages=[json.loads(l) for l in (native/'events.jsonl').read_text().splitlines()]
        events=[m['payload'] for m in messages if m.get('type')=='send']
        errors=[m for m in messages if m.get('type')=='error' or 'error' in m.get('payload',{}).get('event','') or m.get('payload',{}).get('observation_error')]
        row=dict(case=case,native_directory=str(native),process=process,check=observed['check'],diagnostics=observed['diagnostics'],
            trace_errors=errors,bytes=len(code),sha256=sha256(code),temporary_events=[e for e in events if e.get('event','').startswith('temporary-')],
            pools=[e for e in events if e.get('event')=='pool-allocation'],typed=[e for e in events if e.get('event')=='typed-allocation'])
        result.append(row);save(OUT/'comparison.json',result)
        print(json.dumps(dict(case=case,check=row['check'],errors=sorted(set(hex(x['code']) for x in row['diagnostics'] if x['kind']==2)),
             trace_errors=errors,bytes=len(code),creations=[{k:e[k] for k in ('type','count','output','before_counters','after_counters')} for e in row['temporary_events'] if e['event']=='temporary-create'],
             request_count=sum(e.get('name')=='request' for e in row['temporary_events']))),flush=True)
        if errors:raise RuntimeError('temporary observation failed')
        if code:requests.append(dict(mode='decode',case=case,input_base64=base64.b64encode(code+b'\0').decode()));keys.append(case)
    if requests:
        decoded=native_batch(requests,OUT/'native-decode',dll=Q_DLL,cpu_code=209,native_versions=(25,))
        save(OUT/'native-listings.json',[dict(case=k,return_code=r['return_code'],records=native_il_records(base64.b64decode(r['output_base64']),encoding='cp932')) for k,r in zip(keys,decoded)])


if __name__=='__main__':main()
