"""Check current native xrefs against raw label tokens and FB-call controls."""
from collections import Counter
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'research')]
from gxw.lossless import inspect_project, sha256
from gxw.declarations import parse_declarations
from gxw.token_pou import frame_token_pou
from replay_gxw_workspace import run

P = Path(__file__).resolve().parent
OUT = P / 'native-reference-controls'
OUT.mkdir(exist_ok=False)
cases = {'simple': P/'samples/project2.gxw', 'renamed': P/'project2-signed-wide-rename/renamed.gxw',
         'array': P/'project2-declared-array-mutations/two_dimensional/changed.gxw',
         'two': P/'scpi-two-callers/native/native-saved.gxw',
         'same': P/'scpi-instance-binding-controls/same-instance/native/native-saved.gxw'}
for case, source in cases.items():
    image = inspect_project(source.read_bytes())
    queries, expected = [], []
    if case in ['simple','renamed','array']:
        program = next(s for s in image.streams if s.logical_name=='MAIN.Program.pou')
        raw_counts = Counter(t.raw[2:-1].decode('cp949') for t in frame_token_pou(program.raw).tokens if t.raw[1] == 0xdf)
        for stream in image.streams:
            if not (stream.logical_name or '').endswith(('.Labels.lh','.gh')):continue
            doc = parse_declarations(stream.raw,logical_name=stream.logical_name)
            for row in doc.rows:
                query = dict(name=str(len(queries)),keys=[],symbol=row.name,scope=doc.owner_name or '',declared=0,plural=0)
                queries.append(query)
                expected.append(dict(query=query,raw_reference_count=raw_counts[row.name]))
        if case=='array':
            for symbol in ['PB4[2,3]','X82','PB4[1,4]','X81']:
                queries.append(dict(name=symbol,keys=[],symbol=symbol,scope='',declared=0,plural=0))
        queries.append(dict(name='empty',keys=[],symbol='',scope='',declared=0,plural=0))
    else:
        for symbol,scope in [('SCPI_1','SCPI_CALL'),('SCPI_2','SCPI_CALL'),('SCPI_1.iEn','SCPI_CALL'),
                             ('iEn','SCPI_CALL.SCPI_1'),('iEn','SCPI'),('tOutCnt','SCPI_CALL.SCPI_1'),
                             ('tOutCnt','SCPI_CALL.SCPI_2'),('X1F',''),('X2F',''),('M50',''),('M51','')]:
            queries.append(dict(name=symbol+'@'+scope,keys=[],symbol=symbol,scope=scope,declared=0,plural=0))
    native = run(source,OUT/case,compile=True,export_project=True,project_alias='XREFCTRL',analysis_queries=queries,analysis_version=3)
    row = dict(case=case,source_sha256=sha256(source.read_bytes()),
               native={k:native[k] for k in ['returncode','compile_completed','compiler_rejected','diagnostics']})
    path=OUT/case/'native-program-analysis.json'
    if path.exists():
        analysis=json.loads(path.read_text(encoding='utf-8-sig'))
        row['counts']=[dict(query=x['query']['name'],symbol=x['query']['symbol'],scope=x['query']['scope'],count=x['count']) for x in analysis['queries']]
        row['raw_comparison']=[dict(e,native_count=a['count'],equal=e['raw_reference_count']==a['count']) for e,a in zip(expected,analysis['queries'])]
        row['count_mismatches']=sum(not e['equal'] for e in row['raw_comparison'])
    (OUT/case/'comparison.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in row.items() if k not in ['raw_comparison','counts']}),flush=True)
