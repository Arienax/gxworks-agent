"""Bind template ordinals through actual CGTable ports, retaining opaque operands."""
import base64,json,re,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from gxw.compiler_tables import parse_compiler_tables
from gxw.compiler_assignment import parse_compiler_assignment
from gxw.lossless import sha256
from probe_gxw_operand_bindings import resolve_operand,split_operands
from probe_gxw_library_sources import snapshot_library_pous,observed_builtin_template,observed_library_declarations
case=sys.argv[1] if len(sys.argv)>1 else 'positional-enable'
P=Path(case) if Path(case).is_absolute() else Path(__file__).resolve().parent/'builtin-template-call-controls'/case
read=json.loads((P/'correlation/compiled-references.json').read_text())
for resource in read['resources']:
 assert sha256((P/'trace'/resource['file']).read_bytes())==resource['sha256']
symbols=(P/'captured-symbols.bin').read_bytes();tables=parse_compiler_tables(symbols)
dump_dir=next(P/n for n in ('native-constant-reader','native-table-reader','native-symbol-dump') if (P/n).exists())
dump=(dump_dir/'native-table-dump.txt').read_text(encoding='cp1252')
assert json.loads((dump_dir/'comparison.json').read_text())['input_sha256']==sha256(symbols)
debug_positions={int(m[1]):dict(line=int(m[2]),network=int(m[3]),pou=int(m[4])) for m in re.finditer(r'^Index +(\d+) , Line +(-?\d+) , NW +(-?\d+) , POUIdx +(\d+)',dump,re.M)}
snapshot=json.loads((P/'native/frontend-snapshot.json').read_text(encoding='utf-8-sig'))
pous=snapshot_library_pous(snapshot)
post_candidates=[]
root_event=None
for line in (P/'trace/events.jsonl').read_text().splitlines():
 event=json.loads(line).get('payload',{})
 if event.get('event')!='enter' or event.get('name')!='Compile':continue
 buffers={v['label']:v for v in event['buffers']}
 if buffers.get('symbolic_data',{}).get('bytes') and bytes.fromhex(buffers['symbolic_data']['bytes'])==symbols:root_event=event['id']
 if root_event is None or event['id']<=root_event:continue
 if any(k.startswith('name_') and v.get('bytes') and bytes.fromhex(v['bytes']).split(b'\0')[0]==b'Task_01' for k,v in buffers.items()):
  post_candidates.append((event['id'],bytes.fromhex(buffers['symbolic_data']['bytes'])))
assert len(post_candidates)==1
post_event,post_raw=post_candidates[0];allocated_tables=parse_compiler_tables(post_raw)
def resolve(token):
 result=resolve_operand(token,tables,allocated_tables,cpu='Q03UDV')
 if 'component' in result:result['allocation_trace_event']=post_event
 return result

results=[]
for line in (P/'trace/events.jsonl').read_text().splitlines():
 e=json.loads(line).get('payload',{})
 if e.get('event')!='enter' or e.get('name')!='Compile':continue
 b={v['label']:v for v in e['buffers']}
 for k,v in b.items():
  if not k.startswith('name_') or not v.get('bytes') or bytes.fromhex(v['bytes']).split(b'\0')[0]!=b'POU_01':continue
  assert bytes.fromhex(b['symbolic_data']['bytes'])==symbols
  source=bytes.fromhex(b[k.replace('name_','source_')]['bytes']).decode()
  for match in re.finditer(r'^F([0-9]+)\(([^()\r\n]*)\) D([0-9]+)',source,re.M):
   function=tables.pou_at(int(match[1]));name=function.name_bytes.decode()
   if name not in ('MOV_M','FMOV_M','PLS_M','SCMP_MD','SCMP_P_MD','MC_M','MCR_M','ZCOM_U_M','ZCOM_J_M','DOUT_MD','DSET_MD','DRST_MD','DSET_P_MD','DRST_P_MD','UDCNT1_M','DMOV_M','EMOV_M'):continue
   candidates=[p for p in pous if p['library']=='@MELSEC' and p['name']==name];assert len(candidates)==1
   p=candidates[0];template=observed_builtin_template(base64.b64decode(p['program_raw_base64']))
   ports=tables.components(function);actual=split_operands(match[2])
   source_ports=[(i+1,c) for i,c in enumerate(ports) if c.name_bytes!=b'ENO'];assert len(actual)==len(source_ports)
   bindings={i:dict(port=c.name_bytes.decode(),scope=c.scope_code,**resolve(arg)) for (i,c),arg in zip(source_ports,actual)}
   predicted=[]
   for instruction in template['instructions']:
    operands=[]
    for operand in instruction['operands']:
     if operand['placeholder_id'] is not None:value=bindings.get(operand['placeholder_id'],{}).get('operand')
     elif re.fullmatch(r'SM[0-9]+',operand['raw'].strip()):value=operand['raw'].strip()
     elif re.fullmatch(r'D@[0-9]+',operand['raw'].strip()):
      binding=bindings.get(int(operand['raw'].strip()[2:]),{})
      value='D'+binding['operand'] if binding.get('base',{}).get('family')=='Y' and binding.get('operand') is not None else None
     elif re.fullmatch(r'[NUJ]@[0-9]+',operand['raw'].strip()):
      binding=bindings.get(int(operand['raw'].strip()[2:]),{})
      prefix=operand['raw'].strip()[0]
      number=binding.get('constant',{}).get('literal_integer')
      value=None
      if number is not None and number>=0:
       digits=format(number,'X') if prefix=='U' else str(number)
       if prefix=='U' and digits[0] in 'ABCDEF':digits='0'+digits
       value=prefix+digits
     else:value=None
     operands.append(value)
    predicted.append(dict(kind='instruction',op=instruction['opcode'],args=operands))
   debug=debug_positions[int(match[3])]
   assert tables.pou_at(debug['pou']).name_bytes==b'POU_01'
   source_matches=[o for expansion in read['expansions'] for o in expansion['occurrences'] if o.get('source_line',{}).get('text','').startswith(name+'(') and o['source_line']['line_index']==debug['line']]
   assert len(source_matches)==1
   observed=[r for g in source_matches[0]['compiled_records'] for r in read['decoded_fragments'][g['decode_request']].get('records',[])]
   exact=observed==[dict(kind='instruction',op='LD',args=[bindings[1]['operand']])]+predicted
   results.append(dict(name=name,generated_call=match[0],source_line=source_matches[0]['source_line'],debug_reference=debug,function_record_raw_base64=base64.b64encode(function.record.raw).decode(),
    raw_declarations=observed_library_declarations(base64.b64decode(p['declaration_raw_base64'])),
    template=template,compiler_port_order=[c.name_bytes.decode() for c in ports],bindings=bindings,
    predicted_template_records=predicted,observed_native_records=observed,template_sequence_equal=observed[-len(predicted):]==predicted,observed_prefix=observed[:-len(predicted)],enable_prefix='LD of explicit EN argument in these observed calls',exact=exact,gaps=['unresolved template operand'] if any(v is None for r in predicted for v in r['args']) else []))
output=dict(symbols_sha256=sha256(symbols),post_allocation_symbols_sha256=sha256(post_raw),pcode_binding='byte-identical to independent native decoder input',calls=results,summary=dict(calls=len(results),exact_with_LD_enable_prefix=sum(r['exact'] for r in results),exact_template_sequences=sum(r['template_sequence_equal'] for r in results)))
(P/'template-binding-comparison.json').write_text(json.dumps(output,indent=2))
print(json.dumps(output['summary']))
