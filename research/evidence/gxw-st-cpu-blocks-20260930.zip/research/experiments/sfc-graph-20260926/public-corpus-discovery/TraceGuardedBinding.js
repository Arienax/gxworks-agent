// Read-only entry/exit probes, avoiding instruction-interior instrumentation.
'use strict';
let serial=0, active=null;
function hex(p,n){try{return Array.from(new Uint8Array(p.readByteArray(n)),x=>x.toString(16).padStart(2,'0')).join('');}catch(_){return null;}}
function cstr(p){try{let a=[];for(let i=0;i<128;i++){let b=p.add(i).readU8();if(!b)break;a.push(b);}return String.fromCharCode(...a);}catch(_){return null;}}
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='eccompiler_iec.dll')return;
 const attached=new Set();
 Interceptor.attach(m.base.add(0x57d00),{onEnter(args){
  if(!active)return;this.id=active.id;this.count=args[1];this.parts=args[2];
  send({event:'index_parse_enter',id:this.id,text:cstr(args[0])});
 },onLeave(result){
  if(!this.id)return;
  const parts=[];let count=null;
  if(result.toInt32()===0){
   count=this.count.readS32();const base=this.parts.readPointer();
   if(count>=0&&count<=32)for(let i=0;i<count;i++){
    const p=base.add(i*32),rank=p.add(4).readS32();
    parts.push({name:cstr(p.readPointer()),rank,raw:hex(p,32),
     indices:[8,16,24].slice(0,Math.max(0,Math.min(3,rank))).map(o=>p.add(o).readS64().toString())});
   }
  }
  send({event:'index_parse_leave',id:this.id,result:result.toString(),count,parts});
 }});
 Interceptor.attach(m.base.add(0x4fdf0),{onEnter(args){
  if(!active)return;this.id=active.id;this.kind=args[2];
  send({event:'index_classify_enter',id:this.id,text:cstr(args[0])});
 },onLeave(result){if(this.id)send({event:'index_classify_leave',id:this.id,result:result.toString(),kind:hex(this.kind,4)});}});
 Interceptor.attach(m.base.add(0x5f7e0),{onEnter(args){
  if(!active)return;this.id=active.id;this.saved=[args[3],args[4]];
  send({event:'address_resolve_enter',id:this.id,text:cstr(args[0]),scope:cstr(args[1]),mode:args[2].toInt32()});
 },onLeave(result){if(this.id)send({event:'address_resolve_leave',id:this.id,result:result.toString(),outputs:this.saved.map(p=>hex(p,32))});}});
 function observeLower(self){
  const backend=self.add(4).readPointer(),target=backend.readPointer().add(0x118).readPointer(),key=target.toString();
  const resolve=backend.readPointer().add(0x174).readPointer(),resolveKey=resolve.toString();
  if(!attached.has(resolveKey)){
   attached.add(resolveKey);const owner=Process.findModuleByAddress(resolve);
   send({event:'symbol_target',module:owner.name,rva:resolve.sub(owner.base).toString(),bytes:hex(resolve,32)});
   Interceptor.attach(resolve,{onEnter(args){
    if(!active)return;this.id=active.id;this.saved=[args[2],args[3],args[4],args[5]];
    send({event:'symbol_resolve_enter',id:this.id,name:cstr(args[0]),mode:args[1].toInt32()});
   },onLeave(result){if(this.id)send({event:'symbol_resolve_leave',id:this.id,result:result.toString(),
    outputs:this.saved.map((p,i)=>hex(p,[24,297,4,4][i]))});}});
  }
  if(attached.has(key))return;attached.add(key);
  const owner=Process.findModuleByAddress(target);
  send({event:'label_lower_target',module:owner.name,rva:target.sub(owner.base).toString(),bytes:hex(target,32)});
  Interceptor.attach(target,{onEnter(args){
   if(!active)return;this.id=active.id;this.output=args[2];this.length=args[3];
   send({event:'label_lower_enter',id:this.id,source:hex(args[0],args[0].readU8()),mode:args[1].toInt32()});
  },onLeave(result){
   if(!this.id)return;const n=this.length.readS32();
   send({event:'label_lower_leave',id:this.id,result:result.toString(),length:n,output:n>=0&&n<=256?hex(this.output,n):null});
  }});
 }
 function observeLabel(self){
  const target=self.readPointer().add(0x14).readPointer(),key=target.toString();
  if(attached.has(key))return;attached.add(key);
  const owner=Process.findModuleByAddress(target);
  send({event:'label_target',module:owner.name,rva:target.sub(owner.base).toString(),bytes:hex(target,32)});
  Interceptor.attach(target,{onEnter(args){
   if(!active)return;this.id=active.id;this.output=args[1];this.length=args[2];
   observeLower(this.context.ecx);
   send({event:'label_resolve_enter',id:this.id,source:hex(args[0],args[0].readU8()),following:hex(args[0],96)});
  },onLeave(result){
   if(!this.id)return;const n=this.length.readS32();
   send({event:'label_resolve_leave',id:this.id,result:result.toString(),length:n,output:n>=0&&n<=256?hex(this.output,n):null});
  }});
 }
 function observeWrite(self){
  const manager=self.add(0x58).readPointer().add(0x10).readPointer();
  const target=manager.readPointer().add(0xf8).readPointer(),key=target.toString();
  if(attached.has(key))return;attached.add(key);
  const owner=Process.findModuleByAddress(target);
  send({event:'assignment_target',module:owner.name,rva:target.sub(owner.base).toString(),bytes:hex(target,32)});
  Interceptor.attach(target,{onEnter(args){
   if(!active)return;this.id=active.id;
   send({event:'assignment_write',id:this.id,kind:args[0].toInt32(),reference:hex(args[1],4),assignment:hex(args[2],26)});
  },onLeave(result){if(this.id)send({event:'assignment_write_return',id:this.id,result:result.toString()});}});
 }
 Interceptor.attach(m.base.add(0xe9620),{onEnter(args){
  this.old=active;active={id:++serial};this.id=active.id;
  observeLabel(this.context.ecx);
  const prev=this.context.ecx.add(0x38).readPointer();
  send({event:'value_enter',id:this.id,source:hex(args[0],64),previous:hex(prev,32)});
 },onLeave(result){send({event:'value_leave',id:this.id,result:result.toString()});active=this.old;}});
 for(const [rva,name] of [[0xdf760,'formal_lookup'],[0xdf6c0,'operand_text'],[0xe3790,'bind_reference'],[0x4b6b0,'parse_device'],[0x4d240,'parse_index_constant']]){
  Interceptor.attach(m.base.add(rva),{onEnter(args){
   if(!active)return;this.id=active.id;this.saved=[args[0],args[1],args[2]];
   if(name==='bind_reference')observeWrite(this.context.ecx);
   send({event:name+'_enter',id:this.id,args:this.saved.map(p=>({value:p.toString(),bytes:hex(p,32),cstring:cstr(p)}))});
  },onLeave(result){
   if(!this.id)return;
   send({event:name+'_leave',id:this.id,result:result.toString(),args:this.saved.map(p=>({value:p.toString(),bytes:hex(p,32),indirect:(()=>{try{return cstr(p.readPointer());}catch(_){return null;}})()}))});
  }});
 }
}});
