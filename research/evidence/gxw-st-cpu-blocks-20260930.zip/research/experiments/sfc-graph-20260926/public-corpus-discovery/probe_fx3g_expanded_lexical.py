from pathlib import Path
import json,sys,base64,itertools
ROOT=Path.cwd();sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from native_gxw_tokens import native_batch,native_il_projection
P=ROOT/'research/experiments/sfc-graph-20260926/public-corpus-discovery';OUT=P/'fx3g-expanded-lexical';OUT.mkdir(exist_ok=False)
legacy=json.loads((P/'fx-cpu-lexical-controls/predictions.json').read_text(encoding='utf-8'))
rows=native_batch(legacy,OUT/'legacy-cpu-521',cpu_code=521)
reference=[json.loads(l) for l in (P/'fx-cpu-lexical-controls/cpu-520/native-stdout.jsonl').read_text(encoding='utf-8').splitlines()]
keys=('return_code','consumed_bytes','output_base64');differences=[i for i,(a,b) in enumerate(zip(rows,reference,strict=True)) if any(a[k]!=b[k] for k in keys)]
controls=[]
for code,width,value,mod in itertools.product((0xaf,0xd1),(1,2,3),(0,1,255,256,750,32767,65535),(b'',bytes.fromhex('04f00004'),bytes.fromhex('04f00704'),bytes.fromhex('04f40004'),bytes.fromhex('04f40704'),bytes.fromhex('04f20004'))):
 if value>=256**width:continue
 operand=bytes([width+3,code])+value.to_bytes(width,'little')+bytes([width+3])
 body=(bytes.fromhex('054c05000504e80104')+mod+operand if code==0xaf else bytes.fromhex('033c03')+mod+operand)
 controls.append(dict(mode='decode',body_hex=body.hex(),code=code,width=width,value=value,modifier=mod.hex(),input_base64=base64.b64encode(body+b'\0').decode()))
for hex_ in ('031203','031303'):controls.append(dict(mode='decode',body_hex=hex_,input_base64=base64.b64encode(bytes.fromhex(hex_)+b'\0').decode()))
result={}
for cpu in (521,520,518):
 native=native_batch(controls,OUT/f'cpu-{cpu}',cpu_code=cpu)
 result[str(cpu)]=native
cases=[]
for i,c in enumerate(controls):
 case={k:v for k,v in c.items() if k not in ('mode','input_base64')};case['native']={cpu:rows[i] for cpu,rows in result.items()}
 r=result['521'][i]
 case['records']=native_il_projection(base64.b64decode(r['output_base64']),encoding='cp1252')['records'] if r['return_code']=='0x00000000' else None
 cases.append(case)
report=dict(legacy_count=len(legacy),legacy_differences=differences,cases=cases)
(OUT/'comparison.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(dict(legacy_count=len(legacy),legacy_differences=differences,controls=len(cases),cpu_differences=[i for i,c in enumerate(cases) if any(c['native']['521'][k]!=c['native']['520'][k] or c['native']['521'][k]!=c['native']['518'][k] for k in keys)],examples=[dict(body=c['body_hex'],native=c['records'],status=c['native']['521']['return_code']) for c in cases if (c.get('value') in (0,750,65535) and c.get('modifier') in ('','04f00704','04f40704','04f20004')) or 'value' not in c]),ensure_ascii=True))
