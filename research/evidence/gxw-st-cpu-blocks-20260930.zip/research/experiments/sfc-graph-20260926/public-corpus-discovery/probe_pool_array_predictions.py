"""Predict cross-bank contiguous allocations before fresh native compilation."""
from dataclasses import replace
from pathlib import Path
import json
import struct
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'research')]
from gxw.lossless import inspect_project, sha256
from gxw.declarations import parse_declarations, serialize_declarations, edit_declarations
from probe_gxw_parameters import project_allocation_ranges
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import prepare, trace_prepared
from probe_gxw_program_check_resources import SCRIPT, inspect_run
from source_q_direct_projection import project_projection
from probe_retain_class10_holdouts import patch_pool_metadata

P = Path(__file__).resolve().parent
OUT = P / 'pool-array-predictions-20260930'


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def main():
    OUT.mkdir(exist_ok=False)
    for name in [Path(__file__).name, 'source_q_direct_declarations.py', 'source_q_direct_projection.py', 'source_q_label_binding.py']:
        (OUT / name).write_bytes((P / name).read_bytes())
    observer = (P / 'native-allocation-bitmap-v2/observer.js').read_text(encoding='utf-8')
    script = OUT / 'trace.js'
    script.write_text('(()=>{' + observer + '\n})();\n(()=>{' + SCRIPT + '\n})();', encoding='utf-8')
    original = (P / 'noeul-native-batch/case-08/input.gxw').read_bytes()
    streams = {s.logical_name: s.raw for s in inspect_project(original).streams if s.logical_name}
    metadata = next(n for n in streams if n.endswith('.prj'))
    labels = next(n for n, raw in streams.items() if n.endswith('.Labels.lh') and
        any(r.name == 'EMSTP' for r in parse_declarations(raw, logical_name=n).rows))
    old = parse_declarations(streams[labels], logical_name=labels)
    unset = (0xffffffff, 0xffffffff)
    cases = [
        ('ordinary-D-W-R-with-ZR', 'ordinary-array', dict(D=(7000, 7001), W=(256, 256), R=(1000, 1007), ZR=(2000, 2007))),
        ('ordinary-D-W-ZR', 'ordinary-array', dict(D=(7000, 7001), W=(256, 256), R=unset, ZR=(2000, 2007))),
        ('retain-bool-arrays-small-L', 'retain-bool', dict(latch_L2=(1000, 1002), latch_B2=(256, 263))),
        ('retain-int-array-small-D', 'retain-int', dict(latch_D1=(6000, 6001), latch_W2=(512, 515))),
    ]
    prepared = []
    # Persist every input and complete PCode prediction before the first run.
    for case, kind, pools in cases:
        directory = OUT / case
        directory.mkdir()
        doc = old
        if kind == 'retain-bool':
            doc = replace(doc, rows=tuple(replace(r, class_code=10) if r.record_id in (9, 10, 11) else r for r in doc.rows))
        else:
            doc = edit_declarations(doc, upserts=[dict(name='RESERVE_ARRAY', data_type='ARRAY [0..2] OF INT')])
            doc = replace(doc, rows=tuple(replace(r, record_id=1 if r.name=='RESERVE_ARRAY' else r.record_id+1,
                class_code=10 if kind=='retain-int' and r.name in ('RESERVE_ARRAY','STATE','EMSTP') else r.class_code) for r in doc.rows))
        new_labels = serialize_declarations(doc)
        source, receipt = patch_raw(original, labels, streams[labels], new_labels)
        ranges = {r['name']: r for r in project_allocation_ranges(streams[metadata])['ranges']}
        new = bytearray(streams[metadata])
        for name, pair in pools.items():
            struct.pack_into('<II', new, ranges[name]['offset'], *pair)
        source, pool_receipt = patch_pool_metadata(source, metadata, streams[metadata], bytes(new), pools)
        assert {s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name} == dict(streams, **{labels:new_labels, metadata:bytes(new)})
        path = directory / 'input.gxw'
        path.write_bytes(source)
        predictions = project_projection(source)
        for row in predictions:
            (directory / f'predicted-{row["resource_index"]}.bin').write_bytes(row['output'])
        save(directory / 'prediction-before-native.json', dict(input_sha256=sha256(source), pools=pools, receipts=[receipt,pool_receipt],
            outputs=[{k:v for k,v in r.items() if k!='output'} for r in predictions],
            hypothesis='Pools are selected during initialization. A failed contiguous search consumes no smaller bank; later scalars may use it.'))
        prepared.append((case, directory, path, predictions))
    results = []
    for case, directory, path, predictions in prepared:
        for attempt in range(1, 5):
            native = directory / f'native-{attempt}'
            prepare(path, native, compile=True, program_check=True, export_project=True, snapshot_frontend=True, project_alias='ARRAYPOOLS')
            process = trace_prepared(native, script)
            events = [json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
            if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):
                break
        observed = inspect_run(native)
        messages = [json.loads(l) for l in (native/'events.jsonl').read_text().splitlines()]
        emitted = [m['payload'] for m in messages if m.get('type')=='send']
        errors = [m for m in messages if m.get('type')=='error' or 'error' in m.get('payload',{}).get('event','') or 'observation_error' in m.get('payload',{})]
        comparisons = []
        for predicted in predictions:
            actual = (native/f'pcode-{predicted["resource_index"]}-0.bin').read_bytes()
            comparisons.append(dict(index=predicted['resource_index'],identical=actual==predicted['output'],
                predicted_sha256=predicted['sha256'],native_sha256=sha256(actual)))
        typed = [r for r in emitted if r.get('event')=='typed-allocation']
        row = dict(case=case,native_directory=str(native),process=process,check=observed['check'],diagnostics=observed['diagnostics'],
            trace_errors=errors,comparisons=comparisons,typed=typed,pools=[r for r in emitted if r.get('event')=='pool-allocation'])
        results.append(row)
        save(OUT/'comparison.json',results)
        print(json.dumps(dict(case=case,comparisons=comparisons,check=row['check'],errors=[dict(code=hex(r['code']),arguments=r['arguments']) for r in row['diagnostics'] if r['kind']==2],
            allocations=[{k:r[k] for k in ('type','category','result','after')} for r in typed],trace_errors=errors)),flush=True)
        if process['timed_out'] or errors:
            raise RuntimeError('Incomplete observation; evidence retained')


if __name__=='__main__':
    main()
