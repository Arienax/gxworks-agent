"""Counterfactual: keep edited PLS body/ports and change only called name."""
from pathlib import Path
import base64,json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from gxw.lossless import inspect_project,sha256
from probe_gxw_library_archive import decode_library_archive,encode_library_literals,frame_library_text,observed_source_body
from probe_gxw_library_sources import snapshot_library_pous
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_st_sources import replace_observed_st
from probe_gxw_compiled_references import inspect
from replay_gxw_workspace import run
P=Path(__file__).resolve().parent/'array-operand-controls';baseline=P/'word-bit-template-body-edit';out=P/'word-bit-template-alias';out.mkdir(exist_ok=False)
source=(baseline/'changed.gxw').read_bytes();before={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
lib='MELSECFunction.lif';raw=before[lib];plain=decode_library_archive(raw[20:]).decoded;alias='LIB_ALIAS_PLS'
selected=[d for d in frame_library_text(plain)['definitions'] if d['name']=='PLS_M' and 'Q03UDV' in (d['sections'] or [])]
assert len(selected)==1;definition=selected[0];assert observed_source_body(definition)==b'#PLF1##@3\r\n'
header=b'FUNCTION PLS_M';assert definition['raw'].count(header)==1
appended=b'\r\n(*$SECTION:Q03UDV*)\r\n'+definition['raw'].replace(header,b'FUNCTION '+alias.encode(),1)
packed=raw[:20]+encode_library_literals(plain+appended);assert decode_library_archive(packed[20:]).decoded==plain+appended
name='POU_01.Program.pou';_,st=replace_observed_st(before[name],'');assert st.count('PLS_M(')==4
program,_=replace_observed_st(before[name],st.replace('PLS_M(',alias+'('))
changed=source;receipts=[]
for name,body in [(lib,packed),(name,program)]:changed,receipt=patch_raw(changed,name,before[name],body);receipts.append(receipt)
after={s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}
assert all(after[n]==b for n,b in before.items() if n not in (lib,'POU_01.Program.pou'))
(out/'changed.gxw').write_bytes(changed)
(out/'mutation.json').write_text(json.dumps(dict(source_sha256=sha256(source),changed_sha256=sha256(changed),
 library_prefix='byte-identical after decompression',appended_base64=base64.b64encode(appended).decode(),
 original_name='PLS_M',alias=alias,source_edit='four call names only',unrelated_payloads='byte-identical',receipts=receipts),indent=2))
native=run(out/'changed.gxw',out/'native',compile=True,export_project=True,snapshot_frontend=True)
result=dict(native=native);(out/'comparison.json').write_text(json.dumps(result,indent=2))
print(json.dumps({k:native.get(k) for k in ['compile_completed','compiler_rejected','diagnostics']}),flush=True)
if native.get('native_export') and not native.get('compiler_rejected'):
 library=snapshot_library_pous(json.loads((out/'native/frontend-snapshot.json').read_text(encoding='utf-8-sig')))
 original=next(r for r in library if (r['library'],r['name'])==('@MELSEC','PLS_M'))
 copy=next(r for r in library if (r['library'],r['name'])==('@MELSEC',alias))
 result['same_native_body']=original['program_raw_base64']==copy['program_raw_base64']
 result['same_native_declarations']=original['declaration_raw_base64']==copy['declaration_raw_base64']
 read=inspect(out/'native',out/'correlation');decoded=read['decoded_fragments'];prior=json.loads((baseline/'comparison.json').read_text())
 expected={r['source'].replace('PLS_M(',alias+'('):r['after'] for r in prior['call_differences']};rows=[]
 for e in read['expansions']:
  for occurrence in e.get('occurrences',[]):
   text=occurrence.get('source_line',{}).get('text','')
   if text not in expected:continue
   records=[r for g in occurrence['compiled_records'] for r in decoded[g['decode_request']].get('records',[])]
   old=expected[text];edits=[dict(position=i,before=a,after=b) for i,(a,b) in enumerate(zip(old,records)) if a!=b] if len(old)==len(records) else None
   rows.append(dict(source=text,before=old,after=records,edits=edits))
 result['calls']=rows;result['summary']=dict(calls=len(rows),unchanged_calls=sum(r['before']==r['after'] for r in rows),changed_calls=sum(r['before']!=r['after'] for r in rows))
 (out/'comparison.json').write_text(json.dumps(result,indent=2))
 print(json.dumps(dict(**result['summary'],same_native_body=result['same_native_body'],same_native_declarations=result['same_native_declarations'],changes=[dict(source=r['source'],edits=r['edits']) for r in rows])),flush=True)
