"""Preserve ST dynamic-reference source points and decode their compiled regions."""
import base64
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from gxw.lossless import inspect_project,sha256
from gxw.compiler_debug import parse_compiler_debug
from gxw.token_pou import parse_token_fragment
from probe_gxw_compiled_references import stored_records
from probe_gxw_st_sources import replace_observed_st
from native_gxw_tokens import native_batch,native_il_projection,Q_DLL
P=Path(__file__).resolve().parent
native=P/'native-reference-real-corpus/case-00/native'
OUT=P/'ST-dynamic-reference-lowering';OUT.mkdir(exist_ok=False)
streams={s.logical_name:s.raw for s in inspect_project((native/'native-saved.gxw').read_bytes()).streams if s.logical_name}
debug=parse_compiler_debug(streams['DebugInformation2.dat'])
compiled=(native/'pcode-0-0.bin').read_bytes()
groups,total=stored_records(parse_token_fragment(compiled,0,len(compiled)),encoding='cp1252')
refs=json.loads((native/'native-program-analysis.json').read_text(encoding='utf-8-sig'))['queries'][0]['rows']
requests=[];results=[]
for ref in refs:
    if ref['address'] or '[' not in ref['name']:continue
    _,text=replace_observed_st(streams[ref['source']+'.Program.pou'],'')
    for index,e in enumerate(debug.elements):
        if e.names[2].decode('cp1252')!=ref['source']:continue
        selected=[r for r in debug.offset_tables[e.offset_table_index].rows if r[0]+e.fields[0]==ref['top']]
        output=[g for r in selected for g in groups if e.linked_step_start+r[1]<=g['stored_step']<=e.linked_step_start+r[2]]
        row=dict(reference=ref,source_line=text.splitlines()[ref['top']],element_index=index,
            debug_rows=selected,compiled_groups=[dict(offset=g['offset'],stored_step=g['stored_step'],raw_hex=g['raw'].hex()) for g in output])
        for g,target in zip(output,row['compiled_groups']):
            target['request']=len(requests);requests.append(dict(mode='decode',input_base64=base64.b64encode(g['raw']+b'\0').decode()))
        results.append(row)
answers=native_batch(requests,OUT/'native-decode',dll=Q_DLL,cpu_code=209)
for row in results:
    for g in row['compiled_groups']:
        answer=answers[g['request']]
        g.update(native_return_code=answer['return_code'],native_consumed_bytes=answer['consumed_bytes'])
        if answer['return_code']=='0x00000000' and answer['consumed_bytes']==len(bytes.fromhex(g['raw_hex'])):
            g['native_records']=native_il_projection(base64.b64decode(answer['output_base64']),encoding='cp1252')['records']
(OUT/'lowering.json').write_text(json.dumps(dict(export_sha256=sha256((native/'native-saved.gxw').read_bytes()),
    compiled_sha256=sha256(compiled),rows=results),indent=2),encoding='utf-8')
print(json.dumps([dict(source_line=r['source_line'],name=r['reference']['name'],native_reference_address=r['reference']['address'],
    compiled=[g.get('native_records') for g in r['compiled_groups']]) for r in results]))
