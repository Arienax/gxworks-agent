"""Distinguish stateful cursor references from same-named scratch variables."""
from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from gxw.lossless import inspect_project,sha256
from gxw.declarations import parse_declarations,edit_declarations,serialize_declarations
from probe_gxw_st_sources import replace_observed_st
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_compiled_references import inspect
from probe_gxw_library_lowering import inspect as lower
from replay_gxw_workspace import run,prepare,trace_prepared
P=Path(__file__).resolve().parent
out=P/'timer-parameter-controls/two-high-timers';out.mkdir(parents=True,exist_ok=False)
source=(P/'timer-parameter-controls/high-150/changed.gxw').read_bytes()
before={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
program='POU_01.Program.pou';labels='POU_01.Labels.lh'
_,original=replace_observed_st(before[program],'')
call='TimerProbe2(EN := TRUE, IN := TRUE, PT := T#1s);'
updated,_=replace_observed_st(before[program],original+'\r\n'+call+'\r\n')
declarations=parse_declarations(before[labels],logical_name=labels)
new_labels=serialize_declarations(edit_declarations(declarations,upserts=[dict(name='TimerProbe2',data_type='TOF_HIGH_E',kind='function_block')]))
changed=source;receipts=[]
for name,body in [(program,updated),(labels,new_labels)]:
 changed,receipt=patch_raw(changed,name,before[name],body);receipts.append(receipt)
after={s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}
assert all(after[k]==v for k,v in before.items() if k not in (program,labels))
(out/'changed.gxw').write_bytes(changed)
(out/'mutation.json').write_text(json.dumps(dict(source_sha256=sha256(source),changed_sha256=sha256(changed),call=call,unrelated_payloads='byte-identical',receipts=receipts),indent=2))
native=run(out/'changed.gxw',out/'native',compile=True,export_project=True)
print(json.dumps(native),flush=True)
if not native.get('native_export') or native.get('compiler_rejected'):raise RuntimeError('native dual timer build failed; evidence retained')
read=inspect(out/'native',out/'correlation')
prepare(out/'changed.gxw',out/'trace',compile=True,export_project=True)
script=out/'trace/TraceComponentsAndCompiler.js'
script.write_text((P/'TraceComponentCursor.js').read_text()+'\n'+(ROOT/'research/native/CompilerTrace.js').read_text())
trace=trace_prepared(out/'trace',script,timeout=45)
comparison=lower(out/'trace',out/'correlation/compiled-references.json',out/'lowering-comparison.json')
messages=[json.loads(l) for l in (out/'trace/events.jsonl').read_text().splitlines()]
negative=[m['payload'] for m in messages if m.get('payload',{}).get('event')=='component-cursor-read' and m['payload']['requested']==-1]
summary=dict(native=native,trace=trace,lowering=comparison['summary'],negative_reads=negative)
(out/'comparison.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({k:v for k,v in summary.items() if k!='native'}),flush=True)
