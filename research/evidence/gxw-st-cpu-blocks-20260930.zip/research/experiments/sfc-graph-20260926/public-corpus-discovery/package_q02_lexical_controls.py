"""Package bounded native lexical controls; exclude third-party project bytes."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[4]
P=Path(__file__).resolve().parent


def main():
    files={}
    for group in ['q02-lexical-controls/native','q-float-bitpattern-holdouts/native','q-float-bitpattern-holdouts/native-q03udv']:
        for name in ['requests.json','native-stdout.jsonl','native-stderr.bin','process.json','TokenOracle.cs']:
            files[f'controls/{group}/{name}']=(P/group/name).read_bytes()
    for cpu in [34,209]:
        for name in ['requests.json','native-stdout.jsonl','native-stderr.bin','process.json','QueryInstructionCatalog.cs']:
            files[f'descriptors/{cpu}/{name}']=(P/f'q02-descriptor-crosscheck/{cpu}'/name).read_bytes()
    for name in ['operand-catalog.json','comparison.json']:
        files['descriptors/'+name]=(P/'q02-descriptor-crosscheck'/name).read_bytes()
    for name in ['probe_q_cpu_catalogs.py','probe_q02_lexical_controls.py','probe_q_float_holdouts.py','source_q_float_display.py',Path(__file__).name]:
        files['scripts/'+name]=(P/name).read_bytes()
    configuration=json.loads((P/'q02-native-configuration/comparison.json').read_text(encoding='utf-8'))
    initialization=dict(project_sha256=configuration['source_sha256'],traced_untraced_pcode_identical=configuration['byte_identical'],
        project_attributes=configuration['outcome']['project_attributes'],project_codepage=configuration['outcome']['project_codepage'],
        observations=configuration['observations'],source_blob='79ecebe12cdb88e045279a599f1c67bdbf18f558',
        source_repository='https://github.com/rjsxo943-gif/gxworks2-plc-practice',
        scope='Initialization observations only; original project and derived PCode remain local.')
    files['initialization.json']=(json.dumps(initialization,indent=2)+'\n').encode()
    manifest=dict(schema=1,dll_sha256='2e5c47b0a0d0b59eb26dbab149862a05983a1fa9519a75e446bc680e7cc16f73',
        scope='Synthetic raw token/native lexical controls and descriptor facts. No vendor executable or third-party GXW source. Not instruction availability, execution or writer validation.',
        controls=[dict(path='q02-lexical-controls/native',profile='q02',accepted=2597,rejected=3),
            dict(path='q-float-bitpattern-holdouts/native',profile='q02',accepted=5606,rejected=3004),
            dict(path='q-float-bitpattern-holdouts/native-q03udv',profile='q03udv',accepted=5606,rejected=3004)],
        files=[dict(path=n,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()) for n,b in sorted(files.items())])
    files['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
    target=ROOT/'research/evidence/gxw-q02-lexical-20260927.zip'
    with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,raw in sorted(files.items()):z.writestr(name,raw)
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None
        for row in manifest['files']:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
    print(json.dumps(dict(path=str(target),sha256=hashlib.sha256(target.read_bytes()).hexdigest(),bytes=target.stat().st_size,files=len(files))))


if __name__=='__main__':main()
