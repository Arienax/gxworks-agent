"""Offline counterexamples for final-allocation versus per-call BOOL aliases."""
from pathlib import Path
import base64,json,struct,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from probe_gxw_simple_fb import frame_source,observe_calls
from probe_gxw_parameters import device_allocation_record
from probe_gxw_sfc_graph import patch_raw
from native_gxw_tokens import native_batch,Q_DLL
from replay_gxw_workspace import run
P=Path(__file__).resolve().parent
out=P/'scpi-repeated-complex-enable';out.mkdir(exist_ok=False)
source=(P/'scpi-instance-binding-controls/same-instance/native/native-saved.gxw').read_bytes()
streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
name='MAIN.Program.pou';frame=frame_source(streams[name]);calls=observe_calls(frame)['calls']
assert len(calls)==2 and all(c['instance']=='SCPI_1' and not c['gaps'] for c in calls)
texts=[f"LD X{x}F\0AND X0\0OUT '_iEn\0LD '_TRUE\0MOV K{x} '_iUnitNo" for x in [1,2]]
encoded=native_batch([dict(mode='encode',text=t,input_base64=base64.b64encode(t.encode()+b'\0\0').decode()) for t in texts],
 out/'native-encode',dll=Q_DLL,cpu_code=209,native_versions=(25,),device_context=device_allocation_record(streams['Param.wpa']).raw)
for ordinal,case in enumerate(['first','last']):
 answer=encoded[ordinal];assert answer['return_code']=='0x00000000'
 replacement=base64.b64decode(answer['output_base64']);span=calls[ordinal]['input_fragment']
 a,b=span['offset'],span['offset']+span['length'];program=bytearray(frame.raw[:a]+replacement+frame.raw[b:])
 delta=len(program)-len(frame.raw)
 for offset in [55,59]:struct.pack_into('<I',program,offset,struct.unpack_from('<I',frame.raw,offset)[0]+delta)
 assert len(observe_calls(frame_source(bytes(program)))['calls'])==2
 changed,receipt=patch_raw(source,name,frame.raw,bytes(program))
 after={s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}
 assert all(after[k]==v for k,v in streams.items() if k!=name)
 directory=out/case;directory.mkdir();path=directory/'changed.gxw';path.write_bytes(changed)
 (directory/'mutation.json').write_text(json.dumps(dict(source_sha256=sha256(source),changed_sha256=sha256(changed),
  modified_call=ordinal,input_fragment=span,replacement_base64=base64.b64encode(replacement).decode(),
  receipt=receipt,unrelated_payloads='byte-identical'),indent=2))
 for attempt in range(1,9):
  target=directory/('native' if attempt==1 else 'native-v'+str(attempt))
  result=run(path,target,compile=True,export_project=True,project_alias='SCPIMIXED')
  events=[json.loads(l) for l in (target/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
  if (target/'pcode-0-0.bin').exists():break
  if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
 row=dict(case=case,native_directory=str(target.relative_to(P)),
  native={k:result[k] for k in ['returncode','compile_completed','compiler_rejected','diagnostics','outputs']})
 (directory/'comparison.json').write_text(json.dumps(row,indent=2));print(json.dumps(row),flush=True)
