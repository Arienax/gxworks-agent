"""Inspect ProjectOperation's own language names; avoid guessing from filenames."""
import json
import os
from pathlib import Path
import subprocess
import sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from replay_gxw_workspace import prepare,digest
P=Path(__file__).resolve().parent
out=P/'native-language-catalog'
exe=prepare(P/'structured-graph-location-controls/library_fb/source.gxw',out,project_alias='CATALOG')
code=r'''
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int ProjectTypesFn(IntPtr self,ref int count,IntPtr rows,out int code);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int LanguageTypesFn(IntPtr self,int project,int plc,ref int count,IntPtr rows,out int code);
    static void ReadLanguageCatalog(IntPtr operations,string root) {
        int count=0,code;
        int hr=Slot<ProjectTypesFn>(operations,320)(operations,ref count,IntPtr.Zero,out code);
        Check("ProjectTypes.Count",hr,code);
        if(count<1||count>32)throw new Exception("Project-type count outside bound");
        var projectTypes=new List<object>();var ids=new List<int>();
        IntPtr rows=Marshal.AllocCoTaskMem(count*8);
        try {
            Marshal.Copy(new byte[count*8],0,rows,count*8);int capacity=count;
            Check("ProjectTypes.Read",Slot<ProjectTypesFn>(operations,320)(operations,ref count,rows,out code),code);
            if(count>capacity)throw new Exception("Project-type count changed");
            for(int i=0;i<count;i++) {
                IntPtr row=IntPtr.Add(rows,i*8),name=Marshal.ReadIntPtr(row,4);int id=Marshal.ReadInt32(row);
                projectTypes.Add(new {id=id,name=ReadBStr(name)});ids.Add(id);
                if(name!=IntPtr.Zero)Marshal.FreeBSTR(name);
            }
        } finally {Marshal.FreeCoTaskMem(rows);}
        // The inspected method also has an internal case 3, not in the public
        // project list. Preserve that distinction in the resulting artifact.
        var languages=new List<object>();ids.Add(3);
        foreach(int projectType in ids) {
            int n=0;hr=Slot<LanguageTypesFn>(operations,324)(operations,projectType,0x208,ref n,IntPtr.Zero,out code);
            Check("LanguageTypes.Count",hr,code);
            if(n<0||n>32)throw new Exception("Language-type count outside bound");
            IntPtr values=Marshal.AllocCoTaskMem(n*5);
            try {
                Marshal.Copy(new byte[n*5],0,values,n*5);int capacity=n;
                hr=Slot<LanguageTypesFn>(operations,324)(operations,projectType,0x208,ref n,values,out code);
                Check("LanguageTypes.Read",hr,code);
                if(n>capacity)throw new Exception("Language-type count changed");
                var items=new List<object>();
                for(int i=0;i<n;i++) {
                    IntPtr row=IntPtr.Add(values,i*5),name=Marshal.ReadIntPtr(row,1);
                    items.Add(new {kind=Marshal.ReadByte(row),name=ReadBStr(name)});
                    if(name!=IntPtr.Zero)Marshal.FreeBSTR(name);
                }
                languages.Add(new {project_type=projectType,public_project_type=projectType!=3,plc_type=0x208,hresult=hr,code=code,rows=items});
            } finally {Marshal.FreeCoTaskMem(values);}
        }
        File.WriteAllText(Path.Combine(root,"native-language-catalog.json"),json.Serialize(new {projects=projectTypes,languages=languages}));
    }
'''
source=out/'WorkspaceReplayOracle.cs'
s=source.read_text(encoding='utf-8-sig')
anchor='    static JavaScriptSerializer json='
call='            IntPtr home=BStr((string)plan["workspace_home"])'
assert s.count(anchor)==s.count(call)==1
source.write_text(s.replace(anchor,code+'\n'+anchor).replace(call,'            ReadLanguageCatalog(operations,root);\n'+call),encoding='utf-8')
request=json.loads((out/'request.json').read_text());request['source_sha256']=digest(source)
(out/'request.json').write_text(json.dumps(request,indent=2))
csc=Path(os.environ['WINDIR'])/'Microsoft.NET/Framework/v4.0.30319/csc.exe'
build=subprocess.run([str(csc),'/nologo','/platform:x86','/r:System.Web.Extensions.dll','/r:System.Windows.Forms.dll','/out:'+str(exe)]+
    [str(out/n) for n in ['WorkspaceReplayOracle.cs','NativeFrontendSnapshot.cs','NativeSfcGraphOracle.cs','NativeWorkspaceCopyOracle.cs']],capture_output=True,timeout=20)
(out/'catalog-build.stdout').write_bytes(build.stdout);(out/'catalog-build.stderr').write_bytes(build.stderr);build.check_returncode()
with (out/'process.stdout').open('wb') as stdout,(out/'process.stderr').open('wb') as stderr:
    for attempt in range(5):
        result=subprocess.run([str(exe),str(out/'plan.json')],cwd=out,stdout=stdout,stderr=stderr,timeout=50)
        if result.returncode!=5:break
        (out/'native-events.jsonl').rename(out/f'startup-collision-{attempt}.jsonl')
print('returncode',result.returncode)
result.check_returncode()
print(json.dumps(json.loads((out/'native-language-catalog.json').read_text(encoding='utf-8-sig')),ensure_ascii=True,indent=2))
