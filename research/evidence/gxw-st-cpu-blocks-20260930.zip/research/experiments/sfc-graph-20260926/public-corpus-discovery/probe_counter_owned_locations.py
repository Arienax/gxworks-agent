import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from replay_gxw_workspace import run
from gxw.lossless import inspect_project,sha256
from gxw.compiler_debug import parse_compiler_debug
from probe_gxw_debug_locations import lookup
P=Path(__file__).resolve().parent
for kind in ['CTUD','CTU','CTD']:
 out=P/'standard-counter-owned-locations'/kind
 result=run(P/'ST-standard-counter-controls'/kind/'native/native-saved.gxw',out,compile=True,export_project=True,pcode_location_queries=[dict(resource='MAIN',start_step=i,step_count=1,timestamp=0) for i in range(310)])
 debug=parse_compiler_debug(next(s.raw for s in inspect_project((out/'native-saved.gxw').read_bytes()).streams if s.logical_name=='DebugInformation2.dat'))
 rows=json.loads((out/'native-pcode-locations.json').read_text(encoding='utf-8-sig'))
 items=[dict(native=q,reader=lookup(debug,'MAIN',q['query']['start_step'],encoding='cp1252')) for q in rows]
 bad=[x for x in items if x['native']['location']!=x['reader']['location']]
 summary=dict(total=len(rows),exact=len(rows)-len(bad),debug_sha256=sha256(debug.raw),queries=items)
 (out/'same-build-comparison.json').write_text(json.dumps(summary,indent=2))
 print(json.dumps(dict(kind=kind,exact=summary['exact'],bad=bad[:2])),flush=True)
