"""Check source-only Q projection against prior complete native source decodes."""
from pathlib import Path
import argparse,base64,collections,json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.token_pou import frame_token_pou
from probe_gxw_native_listing import project_text_context
from probe_gxw_compiled_references import stored_records
from probe_q_token_lexical import group_record
from native_gxw_tokens import native_il_projection
P=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output-name',default='q-real-program-comparison')
args=parser.parse_args()
out=P/args.output_name;out.mkdir(exist_ok=False)
sources={sha256(f.read_bytes()):f for root in ['samples','noeul-public-corpus'] for f in (P/root).rglob('*.gxw')}
cases=[];totals=collections.Counter();unique_bodies=set();projects=set()
for folder in sorted((P/'native-listing-own-context').glob('case-*')):
 listing=json.loads((folder/'listing.json').read_text(encoding='utf-8'))
 if listing['context']['cpu']!='Q03UDV':continue
 file=sources[listing['source_sha256']];source=file.read_bytes()
 streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
 context=project_text_context(next(raw for n,raw in streams.items() if n.endswith('.prj')))
 assert all(context[k]==listing['context'][k] for k in context)
 if not (folder/'native/requests.json').exists():continue
 requests=json.loads((folder/'native/requests.json').read_text(encoding='utf-8'))['requests']
 answers=[json.loads(s) for s in (folder/'native/native-stdout.jsonl').read_text(encoding='utf-8').splitlines()]
 assert len(requests)==len(answers)
 for request,answer in zip(requests,answers):
  name=request['program'];raw=streams[name];frame=frame_token_pou(raw)
  assert sha256(raw)==request['source_sha256'] and frame.body+b'\0'==base64.b64decode(request['input_base64'])
  assert answer['return_code']=='0x00000000' and answer['consumed_bytes']==len(frame.body)
  native=native_il_projection(base64.b64decode(answer['output_base64']),encoding=context['text_encoding'])
  groups,_=stored_records(frame,encoding=context['text_encoding'])
  assert b''.join(g['raw'] for g in groups)==frame.body and frame.reconstruct()==raw
  ours=[group_record(g['raw'],encoding=context['text_encoding']) for g in groups]
  actual=native['records'];differences=[]
  for i in range(max(len(ours),len(actual))):
   a,b=ours[i] if i<len(ours) else None,actual[i] if i<len(actual) else None
   if a!=b:differences.append(dict(index=i,offset=groups[i]['offset'] if i<len(groups) else None,
                                  raw_hex=groups[i]['raw'].hex() if i<len(groups) else None,ours=a,native=b))
  exact=not differences and not native['text_gaps']
  totals['programs']+=1;totals['exact_programs']+=exact;totals['records']+=len(actual);totals['differing_records']+=len(differences)
  projects.add(listing['source_sha256']);unique_bodies.add(sha256(frame.body))
  cases.append(dict(file=str(file.relative_to(P)),source_sha256=sha256(source),program=name,program_sha256=sha256(raw),
                    body_sha256=sha256(frame.body),encoding=context['text_encoding'],records=len(actual),
                    exact=exact,differences=differences,native_text_gaps=native['text_gaps'],reconstruction='byte-identical'))
result=dict(summary=dict(totals,projects=len(projects),unique_bodies=len(unique_bodies)),cases=cases,
            scope='Portable source token projection vs native source text; excludes structured programs, runtime semantics and writing')
with (out/'comparison.json').open('x') as f:json.dump(result,f,indent=2)
print(json.dumps(dict(summary=result['summary'],gaps=[c for c in cases if not c['exact']])))
