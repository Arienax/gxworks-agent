"""Extract instruction-aligned direct name checks sharing the EN-validation branch."""
import hashlib,json,re,struct,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[4]
sys.path.insert(0,str(ROOT/'research/experiments/re-tools'))
import capstone,pefile
path=Path('D:/GXWORKS2/Easysocket/Compiler/ECCompiler_IEC.dll')
assert hashlib.sha256(path.read_bytes()).hexdigest()=='f58e7c70b855526bf2f943399a14089f771a43109b13ee9af34c88fb065cf4d7'
pe=pefile.PE(str(path));im=pe.get_memory_mapped_image();base=pe.OPTIONAL_HEADER.ImageBase
md=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32)
target=0x81da8;rows=[]
for r in range(0x80000,target):
 size=6 if im[r:r+2]==b'\x0f\x85' else 2 if im[r]==0x75 else 0
 if not size:continue
 displacement=struct.unpack_from('<i' if size==6 else '<b',im,r+size-(4 if size==6 else 1))[0]
 if r+size+displacement!=target:continue
 for a in range(r-5,max(0x80000,r-64),-1):
  if im[a]!=0x68:continue
  value=struct.unpack_from('<I',im,a+1)[0]-base
  if not 0x110000<=value<len(im):continue
  raw=im[value:im.find(b'\0',value)]
  if len(raw)>80 or re.fullmatch(rb'[A-Z0-9_$<>=.]+',raw) is None:continue
  instructions=list(md.disasm(im[a:r+size],base+a))
  if not instructions or instructions[-1].address!=base+r or instructions[-1].mnemonic!='jne':continue
  calls=[i for i in instructions if i.mnemonic=='call']
  if len(calls)!=1 or calls[0].op_str not in [hex(base+0x24f10),hex(base+0x4f90)]:continue
  if any(i.mnemonic.startswith('j') for i in instructions[:-1]):continue
  rows.append(dict(name=raw.decode(),string_rva=hex(value),comparison_rva=hex(a),branch_rva=hex(r),comparison_helper_rva=hex(int(calls[0].op_str,16)-base),instructions=[dict(rva=hex(i.address-base),mnemonic=i.mnemonic,operands=i.op_str) for i in instructions]));break
out=dict(dll_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),error_code='0x050c9019',search_range=['0x80000','0x81da8'],restriction_target=hex(target),names=rows,meaning='direct name checks to one native validation branch; semantic restrictions still require native controls',exhaustive_semantic_classification=False)
(Path(__file__).resolve().parent/'native-enable-restriction-list-v4.json').write_text(json.dumps(out,indent=2))
print(len(rows),[r['name'] for r in rows])
