"""Core SFC ownership and child bodies versus independent native ABI snapshots."""
from pathlib import Path
import base64
import json
import struct
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'research')]
from gxw.lossless import inspect_project, inspect_program, sha256
from gxw.sfc_pou import parse_sfc_pou
from gxw_corpus import project_token_context, program_report
from probe_gxw_task_graph import inspect_task_graph
from probe_gxw_st_sources import child
from source_fx_sfc_projection import project_projection

P = Path(__file__).resolve().parent
B = P.parent
OUT = P / 'sfc-core-source-crosscheck'


def native_rows(snapshot, encoding):
    def raw(blob):
        return base64.b64decode(blob['raw'])
    def name(blob, offset):
        return raw(child(blob, offset))[:-1].decode(encoding)
    pool = child(snapshot['build'], 44)
    owners = {}
    for offset in range(0, len(raw(pool)), 56):
        owner = name(pool, offset + 8)
        children, actions = [], []
        for field, stride, body_at, kind in ((48, 12, 4, 'zoom'), (40, 16, 8, 'transition')):
            sub = child(pool, offset + field)
            data = raw(sub)
            for at in range(0, len(data), stride):
                children.append(dict(kind=kind, name=name(sub, at),
                    number=struct.unpack_from('<I', data, at + 4)[0] if kind == 'transition' else None,
                    token_hex=raw(child(sub, at + body_at))[84:].hex()))
        sub = child(pool, offset + 32)
        data = raw(sub)
        for at in range(0, len(data), 16):
            registrations = child(sub, at + 8)
            registry = raw(registrations)
            actions.append(dict(name=name(sub, at), number=struct.unpack_from('<I', data, at + 4)[0],
                registrations=[dict(qualifier=struct.unpack_from('<I', registry, pos)[0], zoom=name(registrations, pos + 4))
                               for pos in range(0, len(registry), 8)]))
        owners[owner] = dict(children=children, actions=actions)
    return owners


def canonical(rows):
    return sorted(rows, key=lambda row: json.dumps(row, sort_keys=True))


def main():
    OUT.mkdir(exist_ok=False)
    (OUT / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    paths = list(B.glob('*/input.gxw')) + list(B.glob('*/native/input.gxw'))
    paths += list((ROOT / 'research/experiments/structured-compiler-20260920/sfc-source-growth').glob('*/native/input.gxw'))
    paths += list((P / 'real-sfc-source-expansion').glob('*/native-*/input.gxw'))
    paths += list((P / 'real-sfc-source-authority').glob('*/native-*/input.gxw'))
    paths.append(P / 'additional-native-baselines/case-03/native-1/input.gxw')
    rows, fixtures, seen = [], [], set()
    for path in sorted(set(paths)):
        snapshot_path = path.parent / 'frontend-snapshot.json'
        if not snapshot_path.exists():
            continue
        source = path.read_bytes()
        if sha256(source) in seen:
            continue
        seen.add(sha256(source))
        image = inspect_project(source)
        programs = [s for s in image.streams if (s.logical_name or '').endswith('.pou') and s.raw[54:58] == b'\xf0\0\0\0']
        if not programs:
            continue
        request = json.loads((path.parent / 'request.json').read_text(encoding='utf-8'))
        assert request['input_sha256'] == sha256(source)
        context = project_token_context(image)
        graph = inspect_task_graph(source)
        owners = {v['source_program']: k for k, v in graph['programs'].items()}
        native = native_rows(json.loads(snapshot_path.read_text(encoding='utf-8')), context['text_encoding'])
        for stream in programs:
            source_image = parse_sfc_pou(stream.raw)
            source_children = [{k: c[k] for k in ('kind', 'name', 'number', 'token_hex')} for c in source_image.layout['children']]
            source_actions = [{k: a[k] for k in ('name', 'number', 'registrations')} for a in source_image.layout['actions']]
            expected = native[owners[stream.logical_name]]
            inspected = inspect_program(stream.raw, token_profile=context['token_profile'], text_encoding=context['text_encoding'])
            report = program_report(stream.raw, stream.logical_name, [], token_profile=context['token_profile'], text_encoding=context['text_encoding'])
            row = dict(source=str(path), project_sha256=sha256(source), program=stream.logical_name,
                program_sha256=sha256(stream.raw), context=context,
                native_snapshot_sha256=sha256(snapshot_path.read_bytes()),
                native_children_agree=canonical(source_children) == canonical(expected['children']),
                native_actions_agree=canonical(source_actions) == canonical(expected['actions']),
                raw_preserved=inspected.reconstruct() == stream.raw, layout=inspected.layout,
                children=len(source_children), actions=len(source_actions),
                reference_gaps=list(source_image.diagnostics), decoded_instructions=report['decoded_instructions'])
            rows.append(row)
            # The real cmz project's code is local-only. Generated native
            # controls outside public-corpus-discovery are redistributable.
            if P not in path.parents and len(fixtures) < 12:
                fixtures.append(dict(row, program_base64=base64.b64encode(stream.raw).decode(),
                    native_children=expected['children'], native_actions=expected['actions'],
                    native_binaries=request['native']))
        try:
            predicted, detail = project_projection(source)
            actual = (path.parent / 'pcode-0-0.bin').read_bytes()
            for row in rows[-len(programs):]:
                row['source_expansion_matches_native_pcode'] = predicted == actual
        except (ValueError, FileNotFoundError) as exc:
            for row in rows[-len(programs):]:
                row['source_expansion_gap'] = str(exc)
    (OUT / 'comparison.json').write_text(json.dumps(rows, indent=2), encoding='utf-8')
    fixture = ROOT / 'tests/fixtures/gxw_sfc_source_native.json'
    assert not fixture.exists()
    fixture.write_text(json.dumps(dict(scope='Generated native SFC sources and independent frontend ownership; graph cache/execution semantics unclaimed.', cases=fixtures), indent=2) + '\n', encoding='utf-8')
    print(json.dumps(dict(programs=len(rows), children=sum(r['children'] for r in rows), actions=sum(r['actions'] for r in rows),
        children_agree=all(r['native_children_agree'] for r in rows), actions_agree=all(r['native_actions_agree'] for r in rows),
        raw_preserved=all(r['raw_preserved'] for r in rows),
        expansion_matches=sum(r.get('source_expansion_matches_native_pcode') is True for r in rows),
        fixture_programs=len(fixtures),
        differences=[r for r in rows if not r['native_children_agree'] or not r['native_actions_agree']]), ensure_ascii=True))


if __name__ == '__main__':
    main()
