"""Independent native decoding of successful pending-source edit outputs."""
from pathlib import Path
import base64,difflib,json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from native_gxw_tokens import native_batch,native_il_projection,Q_DLL
from gxw.lossless import sha256
P=Path(__file__).resolve().parent
out=P/'compile-pending-pcode-crosscheck';out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
paths=[P/'q-cache-source-binding/baseline-cached/pcode-0-0.bin',P/'compile-pending-source-edits/q-fresh/pcode-0-0.bin',
       P/'ST-nested-FB-controls/single/native/pcode-0-0.bin',P/'compile-pending-st-source-edit-v3/st-fresh/pcode-0-0.bin']
requests=[dict(mode='decode',input_base64=base64.b64encode(p.read_bytes()+b'\0').decode()) for p in paths]
answers=native_batch(requests,out/'native',dll=Q_DLL,cpu_code=209)
decoded=[]
for p,request,answer in zip(paths,requests,answers,strict=True):
    assert answer['return_code']=='0x00000000' and answer['consumed_bytes']==p.stat().st_size
    r=native_il_projection(base64.b64decode(answer['output_base64']),encoding='cp1252');assert not r['text_gaps']
    decoded.append(r['records'])
rows=[]
for label,i in [('Q-inverted-contact',0),('ST-word-assignment',2)]:
    before,after=decoded[i],decoded[i+1];matcher=difflib.SequenceMatcher(a=[json.dumps(r,sort_keys=True) for r in before],b=[json.dumps(r,sort_keys=True) for r in after],autojunk=False)
    changes=[dict(kind=kind,before_index=a,after_index=c,before=before[a:b],after=after[c:d]) for kind,a,b,c,d in matcher.get_opcodes() if kind!='equal']
    row=dict(case=label,before_path=str(paths[i].relative_to(P)),after_path=str(paths[i+1].relative_to(P)),before_sha256=sha256(paths[i].read_bytes()),after_sha256=sha256(paths[i+1].read_bytes()),changes=changes)
    rows.append(row);print(json.dumps(row),flush=True)
assert len(rows[0]['changes'])==2
assert all(c['kind']=='replace' and len(c['before'])==len(c['after'])==1 and c['before'][0]['op']=='LD' and c['after'][0]==dict(c['before'][0],op='LDI') for c in rows[0]['changes'])
(out/'comparison.json').write_text(json.dumps(dict(cases=rows,decoded=decoded),indent=2))
