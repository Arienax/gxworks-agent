"""Keep constant pool, compiler descriptor, CRT text and token value separate."""
from pathlib import Path
import base64,decimal,json,re,struct,subprocess,sys
ROOT=Path(__file__).resolve().parents[4];sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from gxw.compiler_tables import parse_compiler_tables
from gxw.lossless import sha256
from probe_gxw_compiler_constants import constant_record
P=Path(__file__).resolve().parent;case=P/'array-operand-controls/real-literal-rounding-valid';oracle=P/'real-rounding-runtime-controls'
raw=(case/'captured-symbols.bin').read_bytes();tables=parse_compiler_tables(raw)
constants={r.table_offset:constant_record(r) for r in tables.tables[5].records}
base=json.loads((case/'comparison.json').read_text());trace=case/base['trace_attempts'][-1]['directory'];generated=None
for l in (trace/'events.jsonl').read_text().splitlines():
 e=json.loads(l).get('payload',{})
 if e.get('event')!='enter' or e.get('name')!='Compile':continue
 b={x['label']:x for x in e['buffers']}
 for k,x in b.items():
  if k.startswith('name_') and x.get('bytes') and bytes.fromhex(x['bytes']).split(b'\0')[0]==b'POU_01':
   assert raw==bytes.fromhex(b['symbolic_data']['bytes']);generated=bytes.fromhex(b[k.replace('name_','source_')]['bytes']).decode()
assert generated is not None
dump=(case/'native-table-reader/native-table-dump.txt').read_text(encoding='cp1252')
positions={int(m[1]):int(m[2]) for m in re.finditer(r'^Index +(\d+) , Line +(-?\d+) , NW +(-?\d+) , POUIdx +(\d+)',dump,re.M)}
lines={r['line']['line_index']:r['line'] for r in base['calls']};candidates=[]
for line in generated.splitlines():
 m=re.fullmatch(r'K\d+ :=\s+(-\s*)?C(\d+); D(\d+)',line)
 if not m or positions[int(m[3])] not in lines:continue
 constant=constants[int(m[2])];assert constant['kind']==10
 value=constant['stored_real']*(-1 if m[1] else 1)
 candidates.append(dict(generated=line,source=lines[positions[int(m[3])]],constant=constant,input_binary64_hex=struct.pack('<d',value).hex()))
assert len(candidates)==13
inputs=oracle/'project-inputs.txt';output=oracle/'project-native.json';assert not output.exists()
inputs.write_text('\n'.join(r['input_binary64_hex'] for r in candidates)+'\n')
subprocess.run([str(oracle/'LegacyRealOracle.exe'),'C:/Windows/SysWOW64/MSVCR71.dll',str(inputs),str(output)],check=True)
native=json.loads(output.read_text());assert len(native['rows'])==len(candidates)
live=json.loads((case/'real-conversion-trace-v2/comparison.json').read_text());assert live['pcode_equal'] and not live['errors']
read=json.loads((case/'correlation/compiled-references.json').read_text());decoded=read['decoded_fragments'];occurrences={}
for e in read['expansions']:
 for o in e.get('occurrences',[]):
  if o.get('source_line',{}).get('line_index') in lines:occurrences[o['source_line']['line_index']]=o
rows=[]
for candidate,answer in zip(candidates,native['rows']):
 assert candidate['input_binary64_hex']==answer['input_binary64_hex']
 o=occurrences[candidate['source']['line_index']]
 groups=[g for g in o['compiled_records'] if decoded[g['decode_request']].get('records',[{}])[0].get('op')=='EMOV'];assert len(groups)==1
 token=base64.b64decode(groups[0]['raw_base64']);assert token[:6]==bytes.fromhex('054c03020507') and token[6] in (236,237) and token[11]==7
 final=token[7:11];x=struct.unpack('<d',bytes.fromhex(candidate['input_binary64_hex']))[0]
 formats=[r for r in live['rows'] if r['event']=='real-sprintf' and r['format']=='%+7.6E' and r['input_binary64_hex']==answer['backend_input_binary64_hex']]
 descriptors=[r for r in live['rows'] if r['event']=='real-constant-descriptor' and r['reference']==candidate['constant']['table_offset']]
 pool_hex=struct.pack('<d',candidate['constant']['stored_real']).hex()
 rows.append(dict(**candidate,native_runtime=answer,compiled_record=groups[0],compiled_binary32_hex=final.hex(),real_token_kind=token[6],
  descriptor_preserves_pool_binary64=bool(descriptors) and all(r['raw_hex'][16:32]==pool_hex for r in descriptors),
  live_formatter_exact=bool(formats) and all(r['output']==answer['sprintf7'] for r in formats),runtime_binary32_exact=final.hex()==answer['binary32_hex'],
  python_format_binary32_exact=final==struct.pack('<f',float(format(x,'.6e'))),direct_binary32_exact=final==struct.pack('<f',x)))
result=dict(symbols_sha256=sha256(raw),runtime_dll=native['dll'],runtime_dll_sha256=native['dll_sha256'],rows=rows,
 summary=dict(cases=len(rows),pool_to_descriptor_exact=sum(r['descriptor_preserves_pool_binary64'] for r in rows),
 live_formatter_exact=sum(r['live_formatter_exact'] for r in rows),runtime_to_token_exact=sum(r['runtime_binary32_exact'] for r in rows),
 python_format_exact=sum(r['python_format_binary32_exact'] for r in rows),direct_cast_exact=sum(r['direct_binary32_exact'] for r in rows)))
(case/'real-lowering-comparison.json').write_text(json.dumps(result,indent=2));print(json.dumps(result['summary']))
# Preserve counterexamples to a proposed portable first-stage conversion.
all_rows=json.loads((oracle/'native.json').read_text())['rows'];counterexamples=[]
for row in all_rows:
 x=struct.unpack('<d',bytes.fromhex(row['input_binary64_hex']))[0]
 with decimal.localcontext() as c:
  c.prec=15;c.rounding=decimal.ROUND_HALF_UP;value=+decimal.Decimal.from_float(x)
 if value!=decimal.Decimal(row['gcvt15']):counterexamples.append(dict(native=row,candidate_decimal15_half_up=str(value)))
(oracle/'gcvt15-counterexamples.json').write_text(json.dumps(dict(candidate='exact binary64 to 15 decimal significant digits, ROUND_HALF_UP',cases=len(all_rows),mismatches=len(counterexamples),counterexamples=counterexamples),indent=2))
print(json.dumps(dict(runtime_cases=len(all_rows),gcvt15_counterexamples=len(counterexamples))))
