"""Predict temporary bank priority and exhaustion before native runs."""
from pathlib import Path
import json,struct,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from probe_gxw_parameters import project_allocation_ranges
from probe_st_temporary_banks import patch_observed_renamed_metadata
from probe_minimal_conditional_port_writes import streams,observe,save
from probe_gxw_program_check_resources import SCRIPT
from source_q_st_expressions import predict
P=Path(__file__).resolve().parent
OUT=P/'st-temporary-bank-holdouts-20260930'


def main():
    OUT.mkdir(exist_ok=False)
    for name in (Path(__file__).name,'source_q_st_expressions.py','source_q_direct_declarations.py'):(OUT/name).write_bytes((P/name).read_bytes())
    trace=OUT/'trace.js';trace.write_text('(()=>{'+(P/'native-allocation-bitmap-v2/observer.js').read_text()+'\n'+(P/'observe_expression_temporaries.js').read_text()+'\n})();\n(()=>{'+SCRIPT+'\n})();',encoding='utf-8')
    plans=[('W-exhaustion',dict(D=(7000,7031),W=(256,257))),
           ('R-priority',dict(D=(7000,7031),W=(256,263),R=(1000,1007))),
           ('ZR-priority',dict(D=(7000,7031),W=(256,263),ZR=(2000,2007))),
           ('R-and-ZR-conflict',dict(D=(7000,7031),W=(256,263),R=(1000,1007),ZR=(2000,2007)))]
    ready=[]
    for case,pools in plans:
        d=OUT/case;d.mkdir();source=(P/'st-temp-predictions-20260930/balanced-eight/input.gxw').read_bytes();before=streams(source)
        name=next(n for n in before if n.endswith('.prj'));ranges={r['name']:r for r in project_allocation_ranges(before[name])['ranges']}
        raw=bytearray(before[name])
        for key,pair in pools.items():struct.pack_into('<II',raw,ranges[key]['offset'],*pair)
        source,receipt=patch_observed_renamed_metadata(source,name,before[name],bytes(raw),pools)
        assert streams(source)==dict(before,**{name:bytes(raw)})
        path=d/'input.gxw';path.write_bytes(source);code=None
        try:
            prediction=predict(source);code=prediction.pop('output');(d/'predicted-0.bin').write_bytes(code)
        except ValueError as exc:prediction=dict(predicted_rejection=str(exc))
        save(d/'before-native.json',dict(case=case,input_sha256=sha256(source),pools=pools,receipt=receipt,prediction=prediction,
             hypothesis='Temporary default priority ZR > R > W > D; fixed selected descriptor does not fall back. Ordinary initialization suppresses ZR when R is set, so selecting ZR then fails.'))
        ready.append((case,d,path,code,prediction))
    rows=[]
    for case,d,path,predicted,prediction in ready:
        native,checked,process=observe(path,d,trace);code=(native/'pcode-0-0.bin').read_bytes()
        messages=[json.loads(l) for l in (native/'events.jsonl').read_text().splitlines()]
        events=[m['payload'] for m in messages if m.get('type')=='send']
        errors=[m for m in messages if m.get('type')=='error' or 'error' in m.get('payload',{}).get('event','') or m.get('payload',{}).get('observation_error')]
        row=dict(case=case,native_directory=str(native),process=process,check=checked['check'],diagnostics=checked['diagnostics'],trace_errors=errors,
            bytes=len(code),prediction=prediction,byte_identical=None if predicted is None else code==predicted,
            pools=[e for e in events if e.get('event')=='pool-allocation'],temporary_events=[e for e in events if e.get('event','').startswith('temporary-')])
        if checked['exported_sha256']:
            rd=d/'reopen';rd.mkdir();rn,rc,rp=observe(native/'native-saved.gxw',rd,trace)
            row['reopen']=dict(native_directory=str(rn),check=rc['check'],diagnostics=rc['diagnostics'],identical=code==(rn/'pcode-0-0.bin').read_bytes())
        rows.append(row);save(OUT/'comparison.json',rows)
        print(json.dumps(dict(case=case,check=row['check'],byte_identical=row['byte_identical'],bytes=len(code),reopen=row.get('reopen',{}).get('identical'),
            diagnostics=sorted(set(hex(e['code']) for e in row['diagnostics'] if e['kind']==2)),errors=errors,
            defaults=[{k:e[k] for k in ('word','word_variant','bit')} for e in row['temporary_events'] if e['event']=='temporary-default-families'],
            temporary_allocations=[{k:e[k] for k in ('kind','count','selector','result','after')} for e in row['pools'] if e['allocation_id'] is None])),flush=True)
        if errors:raise RuntimeError('trace incomplete')


if __name__=='__main__':main()
