from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from replay_gxw_workspace import prepare,trace_prepared
P=Path(__file__).resolve().parent
case=sys.argv[1] if len(sys.argv)>1 else 'dynamic-layout'
parent=P/'array-operand-controls'/case
for attempt in range(1,9):
 out=parent/('binding-trace' if attempt==1 else f'binding-trace-v{attempt}')
 if out.exists():continue
 prepare(parent/'changed.gxw',out,compile=True,export_project=True)
 result=trace_prepared(out,P/'TraceArrayBindings.js',timeout=55)
 native=[json.loads(l) for l in (out/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
 if (out/'pcode-0-0.bin').exists():break
 if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in native):raise RuntimeError('Unexpected trace failure retained')
else:raise RuntimeError('Fresh process collision bound reached')
rows=[json.loads(l) for l in (out/'events.jsonl').read_text().splitlines()]
result.update(pcode_equal=(out/'pcode-0-0.bin').read_bytes()==(parent/'native/pcode-0-0.bin').read_bytes(),
              rows=[r['payload'] for r in rows if r.get('payload',{}).get('event') in ('component-descriptor','indexed-AST-descriptor-write','index-register-selection','array-extent-or-stride','array-lower-bound')],
              errors=[r for r in rows if r.get('type')=='error'])
(out/'comparison.json').write_text(json.dumps(result,indent=2))
print(json.dumps(dict(output=str(out),pcode_equal=result['pcode_equal'],rows=len(result['rows']),errors=result['errors'])))
