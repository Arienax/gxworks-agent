"""Fresh trace/control builds to expose unified typed allocation and bitmap search."""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from replay_gxw_workspace import prepare,run,trace_prepared
P=Path(__file__).resolve().parent
OUT=P/'native-allocation-bitmap-v2';OUT.mkdir(exist_ok=False)
(OUT/'probe.py').write_bytes(Path(__file__).read_bytes())
hook=OUT/'observer.js';hook.write_text((P/'TraceInstructionSink.js').read_text()+'\n'+(P/'allocation_observer_v2_tail.js').read_text())
assert sha256(Path('D:/GXWORKS2/Easysocket/Compiler/ECCompiler_IEC.dll').read_bytes())=='f58e7c70b855526bf2f943399a14089f771a43109b13ee9af34c88fb065cf4d7'
plans=[('real-instruction-sink','case-00'),('real-binary-public-check','case-02'),('scpi-binary-alias-decisions','same')]
rows=[]
for folder,case in plans:
 prior=json.loads((P/folder/case/'comparison.json').read_text(encoding='utf-8'));source=Path(prior['source']);directory=OUT/case;directory.mkdir()
 for attempt in range(1,5):
  baseline_dir=directory/f'untraced-{attempt}';baseline=run(source,baseline_dir,compile=True,export_project=True,snapshot_frontend=True,project_alias='ALLOCBITMAP')
  ne=[json.loads(l) for l in (baseline_dir/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
  if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in ne):break
 assert baseline['returncode']==0 and baseline['compile_completed'] and not baseline['compiler_rejected']
 for attempt in range(1,5):
  traced=directory/f'trace-{attempt}';prepare(source,traced,compile=True,export_project=True,snapshot_frontend=True,project_alias='ALLOCBITMAP');process=trace_prepared(traced,hook)
  ne=[json.loads(l) for l in (traced/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
  if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in ne):break
 raw=[json.loads(l) for l in (traced/'events.jsonl').read_text().splitlines()];events=[e['payload'] for e in raw if e.get('type')=='send']
 def errors_in(obj):
  if isinstance(obj,dict):return any(k.endswith('error') for k in obj) or str(obj.get('event','')).endswith('-error') or any(errors_in(v) for v in obj.values())
  if isinstance(obj,list):return any(errors_in(v) for v in obj)
  return False
 errors=[e for e in raw if e.get('type')=='error' or errors_in(e.get('payload'))]
 codes={f.name:f.read_bytes() for f in baseline_dir.glob('pcode-*.bin')};assert codes
 exact={n:(traced/n).exists() and (traced/n).read_bytes()==b for n,b in codes.items()}
 allocations=[e for e in events if e['event']=='typed-allocation'];pools=[e for e in events if e['event']=='pool-allocation']
 row=dict(case=case,source=str(source),source_sha256=sha256(source.read_bytes()),context=prior['context'],baseline_directory=str(baseline_dir),trace_directory=str(traced),baseline=baseline,process=process,errors=errors,exact_pcode=exact,allocation_count=len(allocations),pool_count=len(pools),allocations=allocations,pools=pools)
 (directory/'comparison.json').write_text(json.dumps(row,indent=2));rows.append(row);(OUT/'comparison.json').write_text(json.dumps(rows,indent=2))
 print(json.dumps({k:row[k] for k in ['case','errors','exact_pcode','allocation_count','pool_count']}),flush=True)
 if errors or not all(exact.values()):break
