from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from replay_gxw_workspace import prepare,trace_prepared
P=Path(__file__).resolve().parent
out=P/'timer-generator-resolved-imports'
prepare(P/'ST-standard-timer-controls/TON_E_true/changed.gxw',out,compile=True,export_project=True)
script=out/'TraceResolvedImports.js'
script.write_text('const IAT_SPECS='+ (P/'compiler-iec-import-targets.json').read_text()+';\n'+(P/'TraceResolvedImports.js').read_text())
print(json.dumps(trace_prepared(out,script,timeout=45)),flush=True)
events=[json.loads(s) for s in (out/'events.jsonl').read_text().splitlines()]
snap=next(e['payload'] for e in events if e.get('payload',{}).get('event')=='resolved-iat-snapshot')
(out/'resolved-imports.json').write_text(json.dumps(snap,indent=2))
print(json.dumps(snap['rows'][:2]),flush=True)
print(json.dumps(dict(rows=len(snap['rows']),bases=sorted(set((r['target_dll'],r.get('inferred_base')) for r in snap['rows'])),errors=[e for e in events if e.get('type')=='error'])))
