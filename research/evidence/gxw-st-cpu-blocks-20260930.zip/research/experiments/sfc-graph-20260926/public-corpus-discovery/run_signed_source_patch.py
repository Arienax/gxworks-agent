"""Native oracle control for a one-byte source edit under project integrity."""
import base64
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'research')]
from gxw.lossless import inspect_project
from gxw.token_pou import frame_token_pou
from native_gxw_tokens import native_batch, native_il_records, Q_DLL
from probe_gxw_parameters import device_allocation_record
from probe_gxw_integrity import inspect, refresh_after_same_size_patch, stage_same_size_source_patch
from replay_gxw_workspace import run

P = Path(__file__).resolve().parent
OUT = P / 'project2-signed-source-patch-3'
OUT.mkdir(exist_ok=False)
source = (P / 'samples/project2.gxw').read_bytes()
assert inspect(source)['valid'] is True
streams = {s.logical_name: s.raw for s in inspect_project(source).streams if s.logical_name}
program = frame_token_pou(streams['MAIN.Program.pou'])
before = "OUT 't_물품없음 K10"
after = "OUT 't_물품없음 K11"
rows = native_batch([dict(mode='encode', instruction=text,
    input_base64=base64.b64encode(text.encode('cp949') + b'\0\0').decode())
    for text in [before, after]], OUT / 'native-encode', dll=Q_DLL, cpu_code=209,
    native_versions=(25,), device_context=device_allocation_record(streams['Param.wpa']).raw)
assert all(row['return_code'] == '0x00000000' for row in rows)
old, new = [base64.b64decode(row['output_base64']) for row in rows]
assert len(old) == len(new) and program.body.count(old) == 1
offset = program.body_offset + program.body.index(old)
boundaries = {token.offset for token in program.tokens} | {program.body_end}
assert offset in boundaries and offset + len(old) in boundaries
changed = program.raw[:offset] + new + program.raw[offset + len(old):]
assert sum(a != b for a, b in zip(program.raw, changed)) == 1
stale, mutation = stage_same_size_source_patch(source, 'MAIN.Program.pou', program.raw, changed)
refreshed, refresh = refresh_after_same_size_patch(source, stale)
for name, raw in [('stale', stale), ('refreshed', refreshed)]:
    (OUT / (name + '.gxw')).write_bytes(raw)
    (OUT / (name + '-integrity.json')).write_text(json.dumps(inspect(raw), indent=2))
(OUT / 'mutation.json').write_text(json.dumps(dict(instruction_before=before, instruction_after=after,
    source_offset=offset, old_hex=old.hex(), new_hex=new.hex(), mutation=mutation, refresh=refresh,
    scope='isolated synthetic timer constant edit; never loaded to a device'), ensure_ascii=False, indent=2), encoding='utf-8')
for name in ['stale', 'refreshed']:
    outcome = run(OUT / (name + '.gxw'), OUT / (name + '-native'), compile=True,
                  export_project=True, project_alias='SIGNEDPATCH')
    print(name, json.dumps({key: outcome[key] for key in ['returncode', 'open_succeeded',
        'compile_completed', 'compiler_rejected', 'last_event', 'diagnostics']}), flush=True)
    if name == 'refreshed' and outcome.get('native_export'):
        reopened = run(OUT / 'refreshed-native/native-saved.gxw', OUT / 'reopened-native',
                       compile=True, export_project=True)
        print('reopen', reopened['returncode'], reopened['compile_completed'],
              'pcode_identical', outcome['outputs'] == reopened['outputs'], flush=True)
