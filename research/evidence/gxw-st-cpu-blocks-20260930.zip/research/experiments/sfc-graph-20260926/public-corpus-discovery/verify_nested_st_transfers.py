"""Verify saved nested FB byte predictions, native slot lifetimes and witnesses.

This uses saved native decoding and saved native compiler observations. Finite
initialized instruction evaluation is an offline witness, not PLC execution or
a general ST semantic oracle. Rejected native checks remain rejected.
"""
from pathlib import Path
import json,re,sys
P=Path(__file__).resolve().parent
ROOT=P.parents[3];sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from witness_st_conditional_transfers import decode,evaluate
from verify_temporary_check_correspondence import verify
from probe_minimal_conditional_port_writes import save
from source_q_st_calls import predict

INITIAL={
    'outer-inout-inner-indexed':[11,21,128,1,100,107],
    'outer-inout-inner-forwarded':[11,28,56,1,100,200],
    'outer-output-inner-indexed':[77,22,129,1,100,107],
    'outer-output-inner-forwarded':[84,22,168,1,100,200],
}


def slot_events(events,model):
    result=[];selections=[];releases=[]
    for e in events:
        if e.get('event')!='temporary-slots':continue
        if e['name']=='select':
            assert all(s['state'] in (1,2) and s['flag29']==0 for s in e['before'])
            used={s['index']:s for s in e['before']};typ,count=e['args']
            expected=next(i for i in range(200) if i not in used or
                used[i]['state']==2 and used[i]['type']==typ and used[i]['count']>=count)
            assert expected==e['result']
            selections.append(dict(id=e['id'],compile_id=e['compile_id'],type=typ,count=count,
                chosen=expected,live=[s['index'] for s in e['before'] if s['state']==1],before=e['before']))
        elif e['name']=='request' and e['args'][1:3]==[-1,-1]:
            chosen=[s for s in e['after'] if s['operand'][0]==e['result'] and s['type']==e['args'][0]]
            assert len(chosen)==1
            s=chosen[0];old=next((x for x in e['before'] if x['index']==s['index']),None)
            result.append(dict(action='reuse' if old else 'create',slot=s['index'],number=s['operand'][0],width=e['args'][3]))
        elif e['name']=='release-tail':
            after={s['index']:s for s in e['after']}
            for s in e['before']:
                if s['state']==1 and after[s['index']]['state']==2:
                    result.append(dict(action='release',slot=s['index']))
            releases.append(dict(id=e['id'],compile_id=e['compile_id'],threshold=e['args'][0],
                states_after={s['index']:s['state'] for s in e['after']}))
    predicted=[{k:v for k,v in e.items() if k!='capacity'} for e in model['temporary_events']]
    assert result==predicted,(result,predicted)
    return dict(events=result,selections=selections,release_boundaries=releases,model_event_sequence_identical=True)


def bindings(allocations,names):
    result={}
    for name in names:
        m=re.fullmatch(r'(\w+)(?:\[([0-9]+)\])?',name);assert m
        owner='POU_01.Keypad_1' if m[1]=='localArray' else 'POU_01'
        row=next(a for a in allocations if a['owner']==owner and a['name']==m[1])
        index=int(m[2] or 0)
        assert not m[2] or index<row['elements']
        result[name]=dict(address=row['allocated_family']+str(row['number']+index*row['stride']),type=row['data_type'].split(' OF ')[-1])
    return result


def main():
    groups=sys.argv[1:] or ['nested-st-transfers-20260930','nested-st-string-holdouts-20260930','nested-st-string-rung-controls-20260930']
    rows=[]
    for group in groups:
        out=P/group;plans={c['case']:c for c in json.loads((out/'experiment-plan.json').read_text())['cases']}
        listings={c['case']:c['records'] for c in json.loads((out/'native-listings.json').read_text()) if c['index']==0}
        for case in json.loads((out/'comparison.json').read_text()):
            name=case['case'];d=out/name;n=Path(case['native_directory'])
            before=json.loads((d/'before-native.json').read_text());code=(n/'pcode-0-0.bin').read_bytes()
            assert sha256((n/'input.gxw').read_bytes())==before['input_sha256']
            predicted=(d/'predicted-0.bin').read_bytes()
            assert sha256(predicted)==before['prediction']['sha256']
            identical=code==predicted
            retrospective=predict((n/'input.gxw').read_bytes(),definitions=('Wrapper','Keypad'),max_call_depth=2)
            assert retrospective['output']==code
            if not identical:
                save(d/'retrospective-prediction-verification.json',dict(original_sha256=sha256(predicted),native_sha256=sha256(code),
                    retrospective_sha256=retrospective['sha256'],model_sha256=sha256((P/'source_q_st_calls.py').read_bytes()),
                    handling='retrospective-fit; not a before-native prediction',cause='Unused always-on LD between END_IF and the immediately following scalar IF.'))
            records=decode(code)
            assert [{k:v for k,v in r.items() if k not in ('offset','raw')} for r in records]==listings[name]
            expected=plans[name].get('expected')
            if expected is None:expected=dict(zip(['probeR0','probeR1','probeR2','probeIndex','localArray[0]','localArray[1]'],INITIAL[name],strict=True))
            located=bindings(before['prediction']['declarations'],expected)
            finite=evaluate(records,located)
            assert finite['observations']==expected,(name,finite['observations'],expected)
            messages=[json.loads(l) for l in (n/'events.jsonl').read_text().splitlines()]
            assert not [m for m in messages if m.get('type')=='error']
            events=[m['payload'] for m in messages if m.get('type')=='send']
            slots=slot_events(events,before['prediction'])
            result=dict(group=group,case=name,input_sha256=before['input_sha256'],pcode_sha256=sha256(code),
                check=case['check'],backend_rejected=case['backend_rejected'],reopened=bool(case.get('reopen')),
                before_native_prediction_identical=identical,retrospective_prediction_identical=True,native_core_decoding_identical=True,slots=slots,
                bindings=located,expected=expected,finite_witness=finite)
            rows.append(result)
            print(json.dumps(dict(group=group,case=name,observations=finite['observations'],slots=len(slots['events']),check=case['check'])))
    correspondence=verify(groups)
    summary=dict(cases=len(rows),before_native_predictions_equal=sum(r['before_native_prediction_identical'] for r in rows),
        before_native_predictions_differ=sum(not r['before_native_prediction_identical'] for r in rows),retrospective_predictions_equal=len(rows),native_core_decodes_equal=len(rows),
        native_slot_event_sequences_equal=len(rows),finite_witnesses_equal=len(rows),
        public_checks_accepted=sum(bool(r['check']) and not r['check']['rejected'] for r in rows),
        backend_rejected=sum(r['backend_rejected'] is True for r in rows),
        incomplete_public_checks=sum(r['check'] is None for r in rows),reopened=sum(r['reopened'] for r in rows),
        selections=sum(len(r['slots']['selections']) for r in rows),
        selections_with_live_outer=sum(bool(s['live']) for r in rows for s in r['slots']['selections']))
    out=P/groups[-1]
    save(out/'nested-transfer-verification.json',dict(scope=__doc__,summary=summary,cases=rows))
    save(out/'current-check-export-correspondence.json',correspondence)
    (out/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    print(json.dumps(summary))


if __name__=='__main__':main()
