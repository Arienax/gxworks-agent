"""Read-only instrumentation in one newly owned offline compilation process."""
from collections import Counter
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from replay_gxw_workspace import prepare,trace_prepared
P=Path(__file__).resolve().parent
for case,source in [('TON',P/'structured-graph-location-controls/library_fb/native/native-saved.gxw'),
                    ('TOF',P/'graph-library-call-controls/TOF/native/native-saved.gxw'),
                    ('TP',P/'graph-library-call-controls/TP/native/native-saved.gxw')]:
    out=P/'standard-FB-kind-traces'/case
    prepare(source,out,compile=True,export_project=True,project_alias='STANDARDKIND')
    result=trace_prepared(out,P/'TraceStandardFBKind.js',timeout=45)
    messages=[json.loads(line) for line in (out/'events.jsonl').read_text(encoding='utf-8').splitlines()]
    rows=[m['payload'] for m in messages if m.get('type')=='send' and m['payload'].get('event')=='standard-FB-kind']
    summary=dict(trace=result,errors=[m for m in messages if m.get('type')=='error'],
        calls=[dict(input=k[0],kind=k[1],caller=k[2],count=v) for k,v in Counter((r['input'],r['kind'],json.dumps(r['caller'])) for r in rows).items()])
    (out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(dict(case=case,summary=summary)),flush=True)
