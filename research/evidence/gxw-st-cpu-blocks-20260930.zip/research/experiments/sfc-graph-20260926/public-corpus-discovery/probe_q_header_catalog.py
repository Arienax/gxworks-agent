"""Cross-check bounded Q descriptor spellings against native text conversion.

These are lexical probes, not accepted instructions or valid stored widths.
The descriptor's arity bounds every input; no project or device is opened.
"""
from pathlib import Path
import base64, json, sys

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'research')]
from native_gxw_tokens import native_batch, native_il_projection, Q_DLL
from probe_q_token_lexical import LOOKUP, group_record

P = Path(__file__).resolve().parent
out = P / 'q-header-catalog-controls'
out.mkdir(exist_ok=False)
(out / 'probe.py').write_bytes(Path(__file__).read_bytes())
plans = []
for (family, variant), row in sorted(LOOKUP.items()):
    if family in (0x3c, 0x3f):
        continue
    named = len(row['name']) > 1 and row['name'][1] == '.'
    for modifier in ((0x0a, 2) if named else (0xff, 2, 0x10, 0x11, 0x12)):
        header = bytes([family, 2, variant, modifier]) + (b'TEST' if named else b'')
        header = bytes([len(header) + 2]) + header + bytes([len(header) + 2])
        body = header + bytes.fromhex('04a80004') * row['fields'][0]
        plans.append(dict(case=f'{family:02x}-{variant:02x}-{modifier:02x}',
                          body_hex=body.hex(), expected=group_record(body, encoding='cp949')))
requests = [dict(mode='decode', input_base64=base64.b64encode(bytes.fromhex(p['body_hex']) + b'\0').decode()) for p in plans]
answers = native_batch(requests, out / 'native-decode', dll=Q_DLL, cpu_code=209)
rows = []
for plan, answer in zip(plans, answers):
    actual = native_il_projection(base64.b64decode(answer['output_base64']), encoding='cp949') if answer['return_code'] == '0x00000000' else None
    exact = actual is not None and not actual['text_gaps'] and actual['records'] == [plan['expected']]
    rows.append(dict(plan, native=actual, return_code=answer['return_code'], consumed_bytes=answer.get('consumed_bytes'), exact=exact))
result = dict(summary=dict(cases=len(rows), exact=sum(r['exact'] for r in rows)), rows=rows, scope=__doc__)
with (out / 'comparison.json').open('x') as f:
    json.dump(result, f, indent=2)
print(json.dumps(dict(summary=result['summary'], differences=[r for r in rows if not r['exact']][:20])))
