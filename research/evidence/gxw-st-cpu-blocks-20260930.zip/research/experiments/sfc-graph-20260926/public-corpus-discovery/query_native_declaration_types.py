"""Compare a native type parser with real declaration spellings and boundaries."""
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.declarations import parse_declarations
from replay_gxw_workspace import run
P=Path(__file__).resolve().parent
OUT=P/'native-declaration-type-parser';OUT.mkdir(exist_ok=True)
observations={};gaps=[]
for case in [json.loads(s) for s in (P/'native-reference-real-corpus/results.jsonl').read_text(encoding='utf-8').splitlines()]:
    if not case.get('source'):continue
    source=Path(case['source']).read_bytes()
    for stream in inspect_project(source).streams:
        if not stream.logical_name or not stream.logical_name.endswith(('.gh','.Labels.lh')):continue
        try:doc=parse_declarations(stream.raw,logical_name=stream.logical_name)
        except ValueError as exc:gaps.append(dict(case=case['case'],stream=stream.logical_name,error=str(exc)));continue
        for row in doc.rows:
            observation=dict(case=case['case'],project_sha256=sha256(source),stream=stream.logical_name,name=row.name,
                type_code=row.type_code,array_marker=row.array_marker,type_reference=row.type_reference)
            observations.setdefault(row.data_type,[]).append(observation)
controls=['STRING','STRING[0]','STRING[1]','STRING[2]','STRING[3]','STRING[4]','STRING[255]',
          'STRING[256]','STRING[257]','STRING[32767]','STRING[32768]','STRING[-1]',
          'STRING[1..20]','STRING[]','STRING [20]','string[20]','WSTRING[20]',
          'ARRAY [0..19] OF STRING[4]','ARRAY [-2..1,3..7] OF STRING[4]',
          'ARRAY [1..2,1..2,1..2] OF INT','ARRAY [1..2,1..2,1..2,1..2] OF INT',
          'ARRAY [1..0] OF INT','ARRAY [0..0] OF INT','ARRAY [0..65535] OF INT',
          'ARRAY [0..1] OF ARRAY [0..1] OF INT','ARRAY [0..1] OF Keypad','Keypad','NOT_DECLARED_TYPE']
queries=list(dict.fromkeys(list(observations)+controls))
(OUT/'source-type-observations.json').write_text(json.dumps(dict(observations=observations,gaps=gaps,controls=controls),indent=2),encoding='utf-8')
result=run(P/'samples/boxid.gxw',OUT/'native',compile=True,export_project=True,project_alias='TYPEPARSE',type_queries=queries)
print(json.dumps(dict(returncode=result['returncode'],queries=len(queries),real_type_spellings=len(observations))),flush=True)
if (OUT/'native/native-data-types.json').exists():
    rows=json.loads((OUT/'native/native-data-types.json').read_text(encoding='utf-8-sig'))
    for row in rows:
        if row['query'] in controls:
            print(json.dumps(dict(query=row['query'],code=hex(row['code']),result=row['result'])),flush=True)
