"""Test whether empty-task conversion returns existing cached resource code."""
from pathlib import Path
import json
import struct
import sys
ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'research')]
from gxw.lossless import inspect_project, sha256
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import run

P = Path(__file__).resolve().parent
OUT = P/'real-sfc-empty-task-cache'


def main():
    OUT.mkdir(exist_ok=False)
    (OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    empty = (P/'real-sfc-source-authority/no-task-entries/source.gxw').read_bytes()
    poison = (P/'real-sfc-source-authority/compiled-resource-device-poison/source.gxw').read_bytes()
    inv = lambda data: {s.logical_name: s.raw for s in inspect_project(data).streams if s.logical_name}
    before, other = inv(empty), inv(poison)
    candidate, receipt = patch_raw(empty, 'MAIN.res', before['MAIN.res'], other['MAIN.res'])
    raw = other['MAIN.res']; size = struct.unpack_from('<I', raw, 54)[0]; cached = raw[58:58 + size]
    (OUT/'source.gxw').write_bytes(candidate); (OUT/'cached-prediction.bin').write_bytes(cached)
    (OUT/'prediction-before-native.json').write_text(json.dumps(dict(receipt=receipt,
        source_sha256=sha256(candidate), poisoned_cache_sha256=sha256(cached),
        hypothesis='empty task skips SFC reconstruction; GetPCode returns the old resource body'), indent=2), encoding='utf-8')
    for attempt in range(1, 5):
        native = OUT/f'native-{attempt}'
        outcome = run(OUT/'source.gxw', native, compile=True, change_sfc=True,
            export_project=True, snapshot_frontend=True, project_alias='SFCEMPTY')
        events = [json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
        if not any(e.get('operation') == 'NativeTemporaryDirectoryCollision' for e in events):
            break
    file = native/'pcode-0-0.bin'; actual = file.read_bytes() if file.exists() else None
    result = dict(outcome=outcome, native_directory=str(native), returned_poisoned_cache=actual == cached,
        actual_sha256=sha256(actual) if actual is not None else None)
    (OUT/'comparison.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps({k: v for k, v in result.items() if k != 'outcome'}), flush=True)


if __name__ == '__main__':
    main()
