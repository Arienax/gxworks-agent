"""Inspect newly framed search maps over existing real sources and native saves."""
from collections import Counter
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.compiler_debug import parse_compiler_debug
from probe_gxw_native_listing import project_text_context
from probe_gxw_debug_locations import search_maps,expanded_simple_rows
P=Path(__file__).resolve().parent
rows=[]
for item in [json.loads(s) for s in (P/'native-reference-real-corpus/results.jsonl').read_text().splitlines()]:
    if item['case'] in ('two','same'):continue
    for variant,path in [('original',Path(item['source'])),('native',P/'native-reference-real-corpus'/item['case']/'native/native-saved.gxw')]:
        if not path.exists():continue
        row=dict(case=item['case'],variant=variant,source_sha256=sha256(path.read_bytes()))
        try:
            streams={s.logical_name:s.raw for s in inspect_project(path.read_bytes()).streams if s.logical_name}
            context=project_text_context(next(r for n,r in streams.items() if n.endswith('.prj')))
            debug=parse_compiler_debug(streams['DebugInformation2.dat'])
            maps=search_maps(debug,encoding=context['text_encoding'])
            row.update(handling='framed',debug_sha256=sha256(debug.raw),maps=maps,
                elements=[dict(index=i,resource=e.resource_bytes.decode(context['text_encoding']),kind=e.kind_code,
                    names=[n.decode(context['text_encoding']) for n in e.names],fields=e.fields,table=e.offset_table_index) for i,e in enumerate(debug.elements)],
                offset_kinds=dict(Counter(t.kind_code for t in debug.offset_tables)),
                row_kinds=dict(Counter(r[4] for t in debug.offset_tables for r in t.rows)),
                simple_expansion_sizes=[len(expanded_simple_rows(t)) for t in debug.offset_tables if t.kind_code==1])
        except (ValueError,KeyError) as exc:row.update(handling='opaque-preserved',diagnostic=str(exc))
        rows.append(row)
out=P/'debug-source-map-inventory.json'
out.write_text(json.dumps(rows,indent=2),encoding='utf-8')
print(json.dumps(dict(cases=len(rows),handling=Counter(r['handling'] for r in rows),
    elements=sum(len(r.get('elements',[])) for r in rows),offset_kinds=Counter(k for r in rows for k in r.get('offset_kinds',{})),
    non_simple=[dict(case=r['case'],variant=r['variant'],elements=r['elements']) for r in rows if r['variant']=='native' and any(e['kind']!=1 for e in r.get('elements',[]))],
    gaps=[r for r in rows if r['handling']!='framed'])) )
