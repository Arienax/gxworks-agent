"""Native controls distinguishing numeric index syntax, rank, and runtime indexing.

Only owned offline copies are compiled. Source uses the MIT SCPI project;
the FB body is unchanged. Output creation is exclusive and failed runs remain.
"""
from pathlib import Path
import base64,json,struct,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.declarations import parse_declarations,edit_declarations,serialize_declarations
from probe_gxw_simple_fb import frame_source,observe_calls
from probe_gxw_parameters import device_allocation_record
from probe_gxw_sfc_graph import patch_raw
from native_gxw_tokens import native_batch,Q_DLL
from replay_gxw_workspace import run
P=Path(__file__).resolve().parent
out=P/'scpi-index-grammar';out.mkdir(exist_ok=False)
source=(P/'scpi-instance-binding-controls/same-instance/native/native-saved.gxw').read_bytes()
streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
name='MAIN.Program.pou';frame=frame_source(streams[name]);call=observe_calls(frame)['calls'][0]
plans=[dict(case=c,index=i,data_type='ARRAY [-2..2] OF INT') for c,i in [
 ('decimal-plus','+1'),('k-decimal','K1'),('h-hex','H1'),('d-device','D1'),
 ('z-device','Z1'),('iec-hex','16#1'),('expression','0+1'),('out-of-bounds','3')]]
plans += [dict(case=c,index=i,data_type='ARRAY [-2..0,1..3,4..5] OF INT') for c,i in [
 ('rank-three','-1,2,5'),('rank-three-axis','-2,2,4'),('rank-extra','-1,2,5,1')]]
requests=[]
for plan in plans:
 plan['value']="'InputWords["+plan['index']+"]"
 text=f"LD X1F\0OUT '_iEn\0LD '_TRUE\0MOV {plan['value']} '_iUnitNo"
 requests.append(dict(mode='encode',text=text,input_base64=base64.b64encode(text.encode()+b'\0\0').decode()))
answers=native_batch(requests,out/'native-encode',dll=Q_DLL,cpu_code=209,native_versions=(25,),device_context=device_allocation_record(streams['Param.wpa']).raw)
summary=[]
for plan,answer in zip(plans,answers):
 directory=out/plan['case'];directory.mkdir()
 if answer['return_code']!='0x00000000':
  result=dict(plan,encode_failure=answer);summary.append(result)
  (directory/'comparison.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True);continue
 span=call['input_fragment'];a,b=span['offset'],span['offset']+span['length']
 replacement=base64.b64decode(answer['output_base64']);program=bytearray(frame.raw[:a]+replacement+frame.raw[b:])
 delta=len(program)-len(frame.raw)
 for offset in [55,59]:struct.pack_into('<I',program,offset,struct.unpack_from('<I',frame.raw,offset)[0]+delta)
 changed,receipt=patch_raw(source,name,frame.raw,bytes(program));receipts=[receipt]
 labels='Global1.gh';document=parse_declarations(streams[labels],logical_name=labels)
 new=serialize_declarations(edit_declarations(document,upserts=[dict(name='InputWords',data_type=plan['data_type'],device='D200',iec_address='%MW0.200')]))
 changed,receipt=patch_raw(changed,labels,streams[labels],new);receipts.append(receipt)
 after={s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}
 assert all(after[k]==v for k,v in streams.items() if k not in [name,labels])
 path=directory/'changed.gxw';path.write_bytes(changed)
 (directory/'mutation.json').write_text(json.dumps(dict(plan,source_sha256=sha256(source),changed_sha256=sha256(changed),replacement_base64=base64.b64encode(replacement).decode(),receipts=receipts,unrelated_payloads='byte-identical'),indent=2))
 queries=[dict(name='InputWords',keys=[dict(category=1,value='InputWords')])]
 for attempt in range(1,9):
  target=directory/('native' if attempt==1 else 'native-v'+str(attempt))
  result=run(path,target,compile=True,export_project=True,project_alias='SCPIINDEXGRAMMAR',assignment_queries=queries)
  events=[json.loads(s) for s in (target/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
  if (target/'pcode-0-0.bin').exists() or not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
 row=dict(plan,native_directory=str(target.relative_to(P)),native={k:result[k] for k in ['returncode','compile_completed','compiler_rejected','diagnostics','outputs']})
 (directory/'comparison.json').write_text(json.dumps(row,indent=2));summary.append(row)
 print(json.dumps(dict(case=plan['case'],native={k:row['native'][k] for k in ['returncode','compile_completed','compiler_rejected','diagnostics']})),flush=True)
(out/'summary.json').write_text(json.dumps(summary,indent=2))
