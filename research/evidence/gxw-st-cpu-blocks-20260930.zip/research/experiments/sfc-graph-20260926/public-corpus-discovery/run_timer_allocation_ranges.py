"""Isolate the two observed project allocation-range copies; offline only."""
import base64
import hashlib
import json
from pathlib import Path
import struct
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'research')]
from gxw.container_writer import validate_cfb_streams, replace_project_stream
from gxw.project_metadata import logical_mapping, synchronize_history
from probe_gxw_integrity import inspect, observed_digest, FILES, TABLE_BYTES
from probe_gxw_native_listing import project_text_context
from replay_gxw_workspace import run

P = Path(__file__).resolve().parent
OUT = P / 'project2-timer-range-isolation'
OUT.mkdir(exist_ok=False)
source = (P / 'project2-t-st-parameter-transfer/changed.gxw').read_bytes()
assert inspect(source)['valid'] is True
outer = validate_cfb_streams(source)
body = outer['_hdb'][:-TABLE_BYTES]
nested = validate_cfb_streams(body)
mapping = logical_mapping(outer['projectdatalist.xml'])
logical, physical = next((n, p) for n, p in mapping.items() if n.endswith('.prj'))
old = nested[physical]
context = project_text_context(old)
assert context['cpu'] == 'Q03UDV'
start = context['codepage_offset'] + 4
assert old[start:start + 88] == old[start + 186:start + 274]
assert struct.unpack_from('<2I', old, start + 24) == (64, 2047)
rows = []
for case, offsets in [('first', [start + 28]), ('second', [start + 214]),
                      ('both', [start + 28, start + 214])]:
    directory = OUT / case
    directory.mkdir()
    new = bytearray(old)
    for offset in offsets:
        assert struct.unpack_from('<I', old, offset)[0] == 2047
        struct.pack_into('<I', new, offset, 1023)
    new = bytes(new)
    changed_body, method = replace_project_stream(body, physical, new)
    assert validate_cfb_streams(changed_body) == dict(nested, **{physical: new})
    history, changes, preserved = synchronize_history(outer['history.xml'], {logical: (physical, old, new)})
    metadata = dict(outer, **{'history.xml': history})
    hdb = changed_body + b''.join(observed_digest(changed_body if n == '_hdb' else metadata[n]) for n in FILES)
    result, _ = replace_project_stream(source, '_hdb', hdb)
    result, _ = replace_project_stream(result, 'history.xml', history)
    result, _ = replace_project_stream(result, 'Project.gd2', observed_digest(hdb))
    assert inspect(result)['valid'] is True
    assert validate_cfb_streams(result) == dict(metadata, _hdb=hdb, **{'Project.gd2': observed_digest(hdb)})
    changed = directory / 'changed.gxw'
    changed.write_bytes(result)
    mutation = dict(source_sha256=hashlib.sha256(source).hexdigest(), object=logical,
        offsets=offsets, old=2047, new=1023, allocation_method=method, history_changes=changes,
        other_project_bytes='byte-identical', other_logical_payloads='byte-identical',
        scope='explicit allocation-range record experiment; no device writes')
    (directory / 'mutation.json').write_text(json.dumps(mutation, indent=2), encoding='utf-8')
    first = run(changed, directory / 'native', compile=True, snapshot_frontend=True,
                export_project=True, project_alias='TIMER' + case.upper())
    snap = directory / 'native/frontend-snapshot.json'
    words = struct.unpack('<22I', base64.b64decode(json.loads(snap.read_text())['parameter']['raw'])[8:]) if snap.exists() else None
    row = dict(case=case, words=words, **{k: first[k] for k in ['returncode', 'open_succeeded',
        'compile_completed', 'compiler_rejected', 'diagnostics', 'outputs']})
    if first.get('native_export'):
        second = run(directory / 'native/native-saved.gxw', directory / 'reopen', compile=True,
                     snapshot_frontend=True, export_project=True)
        row['reopen'] = {k: second[k] for k in ['returncode', 'open_succeeded', 'compile_completed', 'compiler_rejected', 'diagnostics']}
        row['compiled_identical_after_reopen'] = first['outputs'] == second['outputs']
    rows.append(row)
    (OUT / 'results.json').write_text(json.dumps(rows, indent=2), encoding='utf-8')
    print(json.dumps(row), flush=True)
