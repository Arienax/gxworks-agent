"""Trace the observed simple-ladder MOV connection classifier, read-only."""
from pathlib import Path
import argparse,hashlib,json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from replay_gxw_workspace import prepare,trace_prepared
P=Path(__file__).resolve().parent
assert hashlib.sha256(Path('D:/GXWORKS2/Easysocket/Compiler/ECCompiler_IEC.dll').read_bytes()).hexdigest()=='f58e7c70b855526bf2f943399a14089f771a43109b13ee9af34c88fb065cf4d7'
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('cases',nargs='*')
parser.add_argument('--cases-root',type=Path,default=P/'scpi-guarded-inputs')
args=parser.parse_args()
for case in args.cases or ['int-literal','int-device']:
 parent=args.cases_root/case
 for attempt in range(1,9):
  out=parent/('lowering-trace' if attempt==1 else 'lowering-trace-v'+str(attempt))
  if out.exists():continue
  prepare(parent/'changed.gxw',out,compile=True,export_project=True)
  result=trace_prepared(out,P/'TraceGuardedBinding.js',timeout=55)
  native=[json.loads(s) for s in (out/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
  if (out/'pcode-0-0.bin').exists():break
  if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in native):raise RuntimeError('Unexpected failure retained')
 else:raise RuntimeError('Fresh helper collision bound reached')
 events=[json.loads(s) for s in (out/'events.jsonl').read_text().splitlines()]
 rows=[e['payload'] for e in events if e.get('type')=='send']
 diagnostics={}
 for event in native:
  for row in event.get('reports',[]):
   if row['kind'] in (2,3):
    portable={k:v for k,v in row.items() if k!='raw_base64'}
    diagnostics[json.dumps(portable,sort_keys=True)]=portable
 actual={f.name:f.read_bytes() for f in out.glob('pcode-*.bin')}
 baseline={f.name:f.read_bytes() for f in (parent/'native').glob('pcode-*.bin')}
 result.update(pcode_equal=bool(actual) and actual==baseline,pcode_files=len(actual),
               compile_completed=any(e.get('operation')=='Progress' and e.get('percent')==100 for e in native),
               compiler_rejected=any(d['kind']==2 for d in diagnostics.values()),diagnostics=list(diagnostics.values()),
               errors=[e for e in events if e.get('type')=='error'],observations=rows)
 (out/'comparison.json').write_text(json.dumps(result,indent=2))
 print(json.dumps(dict(case=case,pcode_equal=result['pcode_equal'],compiler_rejected=result['compiler_rejected'],errors=result['errors'],events=len(rows),directory=str(out))),flush=True)
