"""Grow a real hashed project's source across the MiniStream cutoff."""
import base64
from collections import Counter
import hashlib
import json
from pathlib import Path
import struct
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'research')]
from gxw.container_writer import validate_cfb_streams, replace_project_stream
from gxw.declarations import parse_declarations, edit_declarations, serialize_declarations
from gxw.project_metadata import logical_mapping, synchronize_history
from gxw.token_pou import frame_token_pou, parse_token_fragment
from native_gxw_tokens import native_batch, Q_DLL
from probe_gxw_integrity import inspect, observed_digest, FILES, TABLE_BYTES
from probe_gxw_parameters import device_allocation_record
from replay_gxw_workspace import run

P = Path(__file__).resolve().parent
OUT = P / 'project2-signed-wide-rename'
OUT.mkdir(exist_ok=False)
source = (P / 'samples/project2.gxw').read_bytes()
assert inspect(source)['valid'] is True
outer = validate_cfb_streams(source)
body = outer['_hdb'][:-TABLE_BYTES]
nested = validate_cfb_streams(body)
mapping = logical_mapping(outer['projectdatalist.xml'])
streams = {name: nested[physical] for name, physical in mapping.items() if physical in nested}
assert [name for name in streams if name.endswith('.Program.pou')] == ['MAIN.Program.pou']
program = frame_token_pou(streams['MAIN.Program.pou'])
references = Counter(t.raw[2:-1].decode('cp949') for t in program.tokens if t.raw[1] == 0xdf)
documents = {name: parse_declarations(streams[name], logical_name=name)
             for name in ['MAIN.Labels.lh', 'Global1.gh']}
declared = Counter(row.name for doc in documents.values() for row in doc.rows)
assert all(declared[name] == 1 for name in references)
renames = {name: ('IntegrityRename_' + f'{index:03d}').ljust(30, 'X')
           for index, name in enumerate(references)}
assert not any(name in declared for name in renames.values())
requests = []
for old, new in renames.items():
    for name in [old, new]:
        requests.append(dict(mode='encode', label=name,
            input_base64=base64.b64encode(("LD '" + name).encode('cp949') + b'\0\0').decode()))
rows = native_batch(requests, OUT / 'native-encode', dll=Q_DLL, cpu_code=209,
    native_versions=(25,), device_context=device_allocation_record(streams['Param.wpa']).raw)
assert all(row['return_code'] == '0x00000000' for row in rows)
encoded_labels = []
for row in rows:
    raw = base64.b64decode(row['output_base64'])
    tokens = [token.raw for token in parse_token_fragment(raw, 0, len(raw)).tokens if token.raw[1] == 0xdf]
    assert len(tokens) == 1
    encoded_labels.append(tokens[0])
token_map = {}
for index, (old, new) in enumerate(renames.items()):
    a, b = encoded_labels[index * 2:index * 2 + 2]
    assert a[2:-1] == old.encode('cp949') and b[2:-1] == new.encode('cp949')
    assert sum(t.raw == a for t in program.tokens) == references[old]
    token_map[a] = b
new_body = b''.join(token_map.get(t.raw, t.raw) for t in program.tokens)
header = bytearray(program.raw[:program.body_offset])
struct.pack_into('<II', header, 55, len(new_body) + 20, len(new_body) + 20)
new_program = bytes(header) + new_body + program.raw[program.body_end:]
assert len(program.raw) < 4096 <= len(new_program)
new_frame = frame_token_pou(new_program)
assert len(program.tokens) == len(new_frame.tokens)
assert all(b.raw == token_map.get(a.raw, a.raw) for a, b in zip(program.tokens, new_frame.tokens))
mutations = {'MAIN.Program.pou': new_program}
for name, doc in documents.items():
    names = {row.name for row in doc.rows}
    mutations[name] = serialize_declarations(edit_declarations(doc,
        renames={old: new for old, new in renames.items() if old in names}))
history, history_changes, preserved = synchronize_history(outer['history.xml'],
    {name: (mapping[name], streams[name], raw) for name, raw in mutations.items()})
receipts = []
for name, raw in mutations.items():
    body, method = replace_project_stream(body, mapping[name], raw)
    receipts.append(dict(name=name, before=len(streams[name]), after=len(raw), method=method))
assert validate_cfb_streams(body) == dict(nested, **{mapping[name]: raw for name, raw in mutations.items()})
modified_outer = dict(outer, **{'history.xml': history})
table = b''.join(observed_digest(body if name == '_hdb' else modified_outer[name]) for name in FILES)
hdb = body + table
result, hdb_method = replace_project_stream(source, '_hdb', hdb)
result, _ = replace_project_stream(result, 'history.xml', history)
result, _ = replace_project_stream(result, 'Project.gd2', observed_digest(hdb))
assert validate_cfb_streams(result) == dict(modified_outer, _hdb=hdb, **{'Project.gd2': observed_digest(hdb)})
assert inspect(result)['valid'] is True
(OUT / 'renamed.gxw').write_bytes(result)
(OUT / 'mutation.json').write_text(json.dumps(dict(renames=renames, reference_counts=references,
    native_encoded_label_pairs=len(renames), source_tokens_changed=sum(references.values()),
    receipts=receipts, outer_hdb_method=hdb_method, history_changes=history_changes,
    original_hdb_bytes=len(outer['_hdb']), new_hdb_bytes=len(hdb),
    input_sha256=hashlib.sha256(source).hexdigest(), output_sha256=hashlib.sha256(result).hexdigest(),
    unrelated_nested_and_outer_payloads='byte-identical'), ensure_ascii=False, indent=2), encoding='utf-8')
first = run(OUT / 'renamed.gxw', OUT / 'native', compile=True, export_project=True, project_alias='WIDERENAME')
print('native', first['returncode'], first['compile_completed'], first['diagnostics'], flush=True)
if first.get('native_export'):
    second = run(OUT / 'native/native-saved.gxw', OUT / 'reopen', compile=True, export_project=True)
    baseline = json.loads((P / 'project2-export-native-hash/outcome.json').read_text())
    comparison = dict(baseline_equal=first['outputs'] == baseline['outputs'],
        reopen_equal=first['outputs'] == second['outputs'], reopen_returncode=second['returncode'],
        reopen_completed=second['compile_completed'], diagnostics=second['diagnostics'])
    (OUT / 'compiled-comparison.json').write_text(json.dumps(comparison, indent=2))
    print(json.dumps(comparison), flush=True)
