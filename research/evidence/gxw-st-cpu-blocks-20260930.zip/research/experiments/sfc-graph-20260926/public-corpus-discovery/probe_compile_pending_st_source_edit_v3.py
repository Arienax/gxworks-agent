"""Contrast imported compiler cache with fresh compile after one source edit."""
from pathlib import Path
import json,os,subprocess,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_simple_fb import frame_source
from replay_gxw_workspace import prepare
P=Path(__file__).resolve().parent
out=P/'compile-pending-st-source-edit-v3';out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
from probe_gxw_st_sources import replace_observed_st
from gxw.token_listing import decode_token_listing
from gxw.project_metadata import mark_observed_source_compile_pending
st_source=P/'ST-nested-FB-controls/single/native/native-saved.gxw'
st=st_source.read_bytes();streams={s.logical_name:s.raw for s in inspect_project(st).streams if s.logical_name}
logical='Wrapper.Program.pou';raw=streams[logical];_,text=replace_observed_st(raw,'')
assert text.count('number:=number')==1
new,_=replace_observed_st(raw,'in_out_character := 7;\r\n'+text)
new=mark_observed_source_compile_pending(new,logical_name=logical)
st_changed,receipt=patch_raw(st,logical,raw,new)
assert {s.logical_name:s.raw for s in inspect_project(st_changed).streams if s.logical_name}==dict(streams,**{logical:new})
(out/'st-pending.gxw').write_bytes(st_changed)
st_mutation=dict(source=str(st_source),source_sha256=sha256(st),changed_sha256=sha256(st_changed),logical=logical,edit='assign 7 to the existing WORD IN_OUT variable before the nested call and mark pending',receipt=receipt,unrelated_payloads='byte-identical')
(out/'mutations.json').write_text(json.dumps([st_mutation],indent=2))
(out/'project_metadata.py').write_bytes((ROOT/'src/gxw/project_metadata.py').read_bytes())
rows=[]
for case,filename,fresh in [('st-cached','st-pending.gxw',False),('st-fresh','st-pending.gxw',True)]:
    target=out/case;exe=prepare(out/filename,target,compile=True,export_project=True,project_alias='QCACHEBIND')
    plan=json.loads((target/'plan.json').read_text());plan.update(reset_compiler=fresh,fresh_compiler_state=fresh)
    (target/'plan.json').write_text(json.dumps(plan,indent=2))
    code=(target/'WorkspaceReplayOracle.cs').read_text()
    old='            if(!Convert.ToBoolean(plan["compile"]))return;'
    assert code.count(old)==1
    code=code.replace(old,'            CompileStatusSnapshot(workspace,id,"before-build");\n'+old)
    old='            bool compilerRejected=WaitReports(compiler,changeSfc?168:40,"Progress");'
    assert code.count(old)==1
    code=code.replace(old,old+'\n            CompileStatusSnapshot(workspace,id,"after-build");')
    (target/'WorkspaceReplayOracle.cs').write_text(code)
    (target/'NativeCompileStatusSnapshotV2.cs').write_bytes((P/'NativeCompileStatusSnapshotV2.cs').read_bytes())
    csc=Path(os.environ['WINDIR'])/'Microsoft.NET/Framework/v4.0.30319/csc.exe'
    build=subprocess.run([str(csc),'/nologo','/platform:x86','/r:System.Web.Extensions.dll','/r:System.Windows.Forms.dll','/out:'+str(exe),
        *[str(target/n) for n in ['WorkspaceReplayOracle.cs','NativeFrontendSnapshot.cs','NativeSfcGraphOracle.cs','NativeWorkspaceCopyOracle.cs','NativeCompileStatusSnapshotV2.cs']]],
        capture_output=True,timeout=20,creationflags=subprocess.CREATE_NO_WINDOW)
    (target/'status-build.stdout.bin').write_bytes(build.stdout);(target/'status-build.stderr.bin').write_bytes(build.stderr);build.check_returncode()
    request=json.loads((target/'request.json').read_text());request.update(actual_helper_sha256=sha256((target/'WorkspaceReplayOracle.cs').read_bytes()),status_snapshot_sha256=sha256((target/'NativeCompileStatusSnapshotV2.cs').read_bytes()))
    (target/'request.json').write_text(json.dumps(request,indent=2))
    process=subprocess.run([str(exe),str(target/'plan.json')],cwd=target,capture_output=True,timeout=50,creationflags=subprocess.CREATE_NO_WINDOW)
    (target/'process.stdout.bin').write_bytes(process.stdout);(target/'process.stderr.bin').write_bytes(process.stderr)
    events=[json.loads(s) for s in (target/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    snapshots={};phase=None
    for e in events:
        if e['operation']=='CompileStatusSnapshotBegin':phase=e['phase'];snapshots[phase]=[]
        elif e['operation'] in ('CompileStatusSnapshotNode','CompileAllAfterSnapshot','LabelModeSnapshot'):snapshots[phase].append(e)
    diagnostics={json.dumps({k:v for k,v in r.items() if k!='raw_base64'},sort_keys=True) for e in events for r in e.get('reports',[]) if r['kind'] in (2,3)}
    row=dict(case=case,input_sha256=sha256((out/filename).read_bytes()),fresh_backend=fresh,returncode=process.returncode,
        compile_completed=any(e['operation']=='Progress' and e.get('percent')==100 for e in events),
        diagnostics=[json.loads(r) for r in sorted(diagnostics)],snapshots=snapshots,
        outputs={f.name:dict(bytes=f.stat().st_size,sha256=sha256(f.read_bytes())) for f in target.glob('pcode-*.bin')},
        exported=(target/'native-saved.gxw').exists(),last_event=events[-1])
    rows.append(row);(target/'comparison.json').write_text(json.dumps(row,indent=2));print(json.dumps({k:v for k,v in row.items() if k not in ("snapshots","last_event")}),flush=True)
(out/'comparison.json').write_text(json.dumps(dict(cases=rows),indent=2))

for prefix,logical in [('st','Wrapper.Program.pou')]:
    pair=[r for r in rows if r['case'].startswith(prefix+'-')]
    assert len(pair)==2 and all(r['returncode']==0 and r['compile_completed'] and r['exported'] and not any(d['kind']==2 for d in r['diagnostics']) for r in pair)
    assert pair[0]['outputs']==pair[1]['outputs']
    for r in pair:
        statuses=r['snapshots']['before-build']
        assert next(v['status'] for v in statuses if v.get('path')=='project')==1
        assert any(v.get('name')==logical.removesuffix('.Program.pou') and v.get('path','').startswith('25/') and v.get('status')==1 for v in statuses)
        saved={s.logical_name:s.raw for s in inspect_project((out/r['case']/'native-saved.gxw').read_bytes()).streams if s.logical_name}
        assert int.from_bytes(saved[logical][50:54],'little')==0
print(json.dumps(dict(native_cases=len(rows),cached_fresh_pcode_exact=True,pending_detected_before_build=True,cleared_after_native_full_build_save=True)),flush=True)
