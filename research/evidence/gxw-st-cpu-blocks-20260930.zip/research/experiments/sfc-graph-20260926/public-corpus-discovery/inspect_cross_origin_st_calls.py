"""Audit saved predictions, independent lexical decoding and initialized witnesses."""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[4];sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from probe_minimal_conditional_port_writes import save
from witness_st_conditional_transfers import decode,evaluate
from verify_temporary_check_correspondence import verify
P=Path(__file__).resolve().parent
GROUPS=['cross-origin-st-calls-v2-20260930','cross-origin-st-calls-v3-20260930','cross-origin-st-lines-20260930','cross-origin-st-pointer-pools-v2-20260930']


def main():
    rows=[]
    for group in GROUPS:
        out=P/group;plan=json.loads((out/'experiment-plan.json').read_text());plans={p['case']:p for p in plan['cases']}
        listings={r['case']:r['records'] for r in json.loads((out/'native-listings.json').read_text())}
        for case in json.loads((out/'comparison.json').read_text()):
            d=out/case['case'];before=json.loads((d/'before-native.json').read_text());n=Path(case['native_directory'])
            source=(d/'input.gxw').read_bytes();assert sha256(source)==before['input_sha256']==sha256((n/'input.gxw').read_bytes())
            row=dict(group=group,case=case['case'],input_sha256=before['input_sha256'],accepted=bool(case['check'] and not case['check']['rejected']),
                diagnostic_codes=sorted(set(hex(e['code']) for e in case['diagnostics'] if e['kind']==2)),prediction=before['prediction'].get('unsupported','generated-by-research-model'))
            if row['accepted']:
                raw=(n/'pcode-0-0.bin').read_bytes();assert raw==(d/'predicted-0.bin').read_bytes()
                assert case['reopen']['check'] and not case['reopen']['check']['rejected'] and case['reopen']['identical']
                records=decode(raw);assert [{k:v for k,v in r.items() if k not in ('offset','raw')} for r in records]==listings[case['case']]
                allocations=before['prediction']['declarations'];observations={}
                for name in ('probeR0','probeR1','probeR2'):
                    a=next(x for x in allocations if x['owner']=='MAIN' and x['name']==name)
                    observations[name]=dict(address=a['allocated_family']+str(a['number']),type=a['data_type'])
                witness=evaluate(records,observations);assert list(witness['observations'].values())==plans[case['case']]['expected']
                row.update(pcode_sha256=sha256(raw),predicted_bytes_equal=True,independent_lexical_equal=True,observations=observations,witness=witness,
                    pointer_labels=[r['text'] for r in records if r['kind']=='label'])
            rows.append(row)
    result=dict(groups=GROUPS,cases=rows,accepted=sum(r['accepted'] for r in rows),rejected=sum(not r['accepted'] for r in rows),
        scope='Controlled ST substitutions on independent SCPI project metadata/container, not original ST lineage or PLC execution.',
        findings=['Configured P pointer lower/upper bounds constrain generated IF branches; unavailable/exhausted ranges reject at frontend with 0x500c9004.',
            'Second is rejected as a declaration name with 0x500c5054; rename-only ProbeB control succeeds for branchless cases. Full identifier validity remains outside predictor.',
            'Per-instance persistent INT/STRING locals, dynamic INPUT captures, fixed-index aliases and independent omitted IN_OUT storage match before-native predictions.',
            'Line separator changes did not fix missing pointer ranges. Failed inputs and original model predictions are retained.'])
    out=P/GROUPS[-1];save(out/'cross-origin-call-analysis.json',result);save(out/'aggregate-check-correspondence.json',verify(GROUPS))
    (out/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    print(json.dumps(dict(accepted=result['accepted'],rejected=result['rejected'],observations=[dict(case=r['case'],values=r['witness']['observations'],labels=r['pointer_labels']) for r in rows if r['accepted']])))


if __name__=='__main__':main()
