from pathlib import Path
from collections import Counter,defaultdict
import json
P=Path('research/experiments/sfc-graph-20260926/public-corpus-discovery/scpi-binary-public-check');summary=[]
for case in json.loads((P/'comparison.json').read_text(encoding='utf-8')):
 d=P/case['case'];ev=[x['payload'] for l in (d/case['trace_directory']/'events.jsonl').read_text(encoding='utf-8').splitlines() if (x:=json.loads(l)).get('type')=='send'];bs=[e for e in ev if e['event']=='label-binding'];groups=defaultdict(list)
 for b in bs:groups[(b['lookup']['scope']['hex'],b['lookup']['name']['hex'])].append(b)
 varying=[]
 for (scope,name),items in groups.items():
  vals={b['output'] for b in items}
  if len(vals)>1:varying.append(dict(scope_hex=scope,name_hex=name,name=bytes.fromhex(name).decode('ascii'),outputs=sorted(vals),occurrences=[dict(binding_id=b['binding_id'],sequence=b['sequence'],input=b['input'],output=b['output'],device=b.get('resolved_device')) for b in items]))
 row=dict(case=case['case'],bindings=len(bs),qualified_names=len(groups),varying_names=varying,check_calls=sum(e['event']=='check-instruction-code2' for e in ev),errors=[e for e in ev if any('error' in k for k in e)],full_native_pcode_exact=all(case['exact_pcode'].values()),native_record_counts={r['name']:len(r.get('listing',{}).get('records',[])) for r in case['decoded']});summary.append(row)
 print(json.dumps({k:v for k,v in row.items() if k!='varying_names'}|dict(varying_names=[v['name'] for v in varying])))
(P/'binding-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
