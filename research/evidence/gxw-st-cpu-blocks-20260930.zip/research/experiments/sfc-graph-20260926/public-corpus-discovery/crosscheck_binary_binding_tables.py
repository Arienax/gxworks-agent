from pathlib import Path
import json,sys
sys.path[:0]=['src','research','research/experiments/re-tools']
import pefile,capstone
from gxw.lossless import inspect_project
from gxw.compiler_tables import parse_compiler_tables
from gxw.compiler_assignment import parse_compiler_assignment
from probe_gxw_operand_bindings import observed_q_address,format_bound_device
P=Path('research/experiments/sfc-graph-20260926/public-corpus-discovery');rows=json.loads((P/'real-binary-label-binding/source-crosscheck.json').read_text(encoding='utf-8'));outs=[]
for row in rows:
 folder='real-binary-label-binding' if row['case']=='case-05' else 'real-binary-label-binding-multi';d=P/folder/row['case'];case=json.loads((d/'comparison.json').read_text(encoding='utf-8'));o=case['baseline'];ex=(d/'untraced'/o['native_export']['file']).read_bytes();tables=parse_compiler_tables(next(s.raw for s in inspect_project(ex).streams if s.logical_name=='CGTable.dat'));encoding=case['context']['text_encoding'];pous=[tables.pou_at(r.table_offset) for r in tables.tables[1].records];results=[]
 for binding in row['bindings_detail']:
  name=binding['name'].encode(encoding);scope=binding['scope'].encode(encoding);found=[]
  for pou in pous:
   if pou.name_bytes not in [b'@GLOBALS',scope]:continue
   for c in tables.components(pou):
    if c.name_bytes.lower()!=name.lower():continue
    a=parse_compiler_assignment(c.user_info);ao=tables.component_address_offset(c);ar=tables.address_at(ao) if ao>=0 else None;addr=observed_q_address(ar.iec_address_bytes) if ar else None
    operand=a.fx_operand if a.status=='decoded' else format_bound_device(addr) if addr and addr['handling']!='opaque' else None
    found.append(dict(owner=pou.name_bytes.decode(encoding),component_offset=c.record.table_offset,assignment_raw=c.user_info.hex(),declared_address=None if ar is None else ar.iec_address_bytes.decode('ascii'),operand=operand))
  results.append(dict(name=binding['name'],source_offset=binding['source_offset'],expected=binding['portable_output'],candidates=found,agrees=bool(found) and all([f['operand']]==binding['portable_output'] for f in found)))
 out=dict(case=row['case'],source=row['source_name'],bindings=len(results),matched=sum(r['agrees'] for r in results),details=results);outs.append(out);print(json.dumps({k:v for k,v in out.items() if k!='details'}));print(json.dumps([r for r in results if not r['agrees']][:3]))
(P/'real-binary-label-binding/table-binding-crosscheck.json').write_text(json.dumps(outs,indent=2),encoding='utf-8')
pe=pefile.PE('D:/GXWORKS2/Easysocket/CodeGenerator/ECCodeGenerator2.dll');print(json.dumps([e.name.decode() for e in pe.DIRECTORY_ENTRY_EXPORT.symbols if e.name and any(t in e.name.lower() for t in [b'step',b'size',b'width'])]))
pe=pefile.PE('D:/GXWORKS2/Easysocket/Compiler/ECCompiler_IEC.dll');im=pe.get_memory_mapped_image();base=pe.OPTIONAL_HEADER.ImageBase;md=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32);s='\n'.join(f'{i.address-base:08x} {i.mnemonic:8} {i.op_str}' for i in md.disasm(im[0xdcc90:0xdce40],base+0xdcc90));(P/'binary-width-caller.txt').write_text(s);print(s)
