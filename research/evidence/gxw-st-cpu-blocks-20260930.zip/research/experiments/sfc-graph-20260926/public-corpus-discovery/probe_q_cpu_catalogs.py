"""Compare all bounded Q02/Q03 descriptor slots without assuming shared tables."""
from pathlib import Path
import hashlib,json,subprocess,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path.insert(0,str(ROOT/'research/experiments/re-tools'))
import pefile,capstone
P=Path(__file__).resolve().parent
OUT=P/'q02-descriptor-crosscheck'


def main():
    OUT.mkdir(exist_ok=False);(OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    dll=Path('D:/GXWORKS2/Easysocket/CodeGenerator/ECCodeGenerator2.dll')
    assert hashlib.sha256(dll.read_bytes()).hexdigest()=='2e5c47b0a0d0b59eb26dbab149862a05983a1fa9519a75e446bc680e7cc16f73'
    # The static descriptor prefix vectors have 123 elements. Never query
    # families beyond those 122 bounded ranges, or the byte-increment wrap at 255.
    queries=[[f,v] for f in range(122) for v in range(255)]
    protocol=''.join(f'{f}\t{v}\n' for f,v in queries).encode()
    source=(P/'QueryInstructionCatalog.cs').read_text(encoding='utf-8')
    assert source.count('open(h,209,0)')==1
    results={}
    for cpu in [34,209]:
        target=OUT/str(cpu);target.mkdir()
        cs=target/'QueryInstructionCatalog.cs';cs.write_text(source.replace('open(h,209,0)',f'open(h,{cpu},0)'),encoding='utf-8')
        exe=target/'QueryInstructionCatalog.exe'
        (target/'requests.json').write_text(json.dumps(dict(cpu=cpu,queries=queries)),encoding='utf-8')
        build=subprocess.run(['C:/Windows/Microsoft.NET/Framework/v4.0.30319/csc.exe','/nologo','/platform:x86','/out:'+str(exe),str(cs)],capture_output=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
        (target/'build.stdout.txt').write_bytes(build.stdout);(target/'build.stderr.txt').write_bytes(build.stderr)
        build.check_returncode()
        run=subprocess.run([str(exe),str(dll)],input=protocol,capture_output=True,timeout=45,creationflags=subprocess.CREATE_NO_WINDOW)
        (target/'native-stdout.jsonl').write_bytes(run.stdout);(target/'native-stderr.bin').write_bytes(run.stderr)
        (target/'process.json').write_text(json.dumps(dict(returncode=run.returncode,source_sha256=hashlib.sha256(cs.read_bytes()).hexdigest(),exe_sha256=hashlib.sha256(exe.read_bytes()).hexdigest())),encoding='utf-8')
        run.check_returncode()
        rows=[json.loads(s) for s in run.stdout.splitlines()];assert len(rows)==len(queries)
        results[cpu]=rows
    differences=[];same=0
    for a,b in zip(results[34],results[209]):
        # ASLR changes absolute name pointers. Compare return/name and six
        # descriptor bytes; keep the untouched native outputs separately.
        left=(a['result'],a['name'],a['descriptor_hex'][8:])
        right=(b['result'],b['name'],b['descriptor_hex'][8:])
        if left!=right:differences.append(dict(family=a['family'],variant=a['variant'],q02=a,q03=b))
        else:same+=1
    result=dict(queries_per_cpu=len(queries),identical=same,differences=differences,
        accepted={str(c):sum(r['result']=='0x00000000' for r in rows) for c,rows in results.items()},
        active_cpu_words={str(c):sorted({r['active_cpu_word'] for r in rows}) for c,rows in results.items()})
    (OUT/'comparison.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    pe=pefile.PE(str(dll));im=pe.get_memory_mapped_image();base=pe.OPTIONAL_HEADER.ImageBase
    md=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32)
    for address,size in [(0x3dfe2,0x2a1),(0x3ecc9,0x500)]:
        (OUT/f'{address:x}.txt').write_text('\n'.join(f'{i.address-base:08x}: {i.mnemonic} {i.op_str}' for i in md.disasm(im[address:address+size],base+address)),encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='differences'}|dict(differences=len(differences),examples=differences[:12])),flush=True)


if __name__=='__main__':main()
