from pathlib import Path
import sys,json
from collections import Counter
ROOT=Path(__file__).resolve().parents[4];sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from replay_gxw_workspace import run
from gxw.lossless import sha256
from gxw.token_pou import parse_token_region
from gxw.token_listing import decode_token_program
from gxw.compiler_debug import parse_compiler_debug
import probe_gxw_debug_locations as reader
P=Path(__file__).resolve().parent;OUT=P/'fx3g-library-debug-holdout';OUT.mkdir(exist_ok=False);(OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
previous=P/'fx3g-without-modbus-task/compile-1';source=P/'fx3g-without-modbus-task/candidate.gxw';code=(previous/'pcode-0-0.bin').read_bytes();listing=decode_token_program(parse_token_region(code,0,len(code)),profile='fx3g',text_encoding='cp1252')
end=max(r.step for r in listing.records if getattr(r,'step',None) is not None);old=json.loads((previous/'outcome.json').read_text(encoding='utf-8'))
steps=sorted(set(range(0,end+3,3))|{r['step'] for r in old['diagnostics'] if r['kind']==2}|{end-1,end,end+1,end+2});assert len(steps)<=4096
queries=[dict(resource='MAIN',start_step=s,step_count=1,timestamp=0) for s in steps];(OUT/'queries-before-native.json').write_text(json.dumps(dict(input_sha256=sha256(source.read_bytes()),pcode_sha256=sha256(code),queries=queries),indent=2),encoding='utf-8')
for attempt in range(1,5):
 native=OUT/f'native-{attempt}';outcome=run(source,native,compile=True,export_project=True,snapshot_compiler_cache=True,program_check=True,pcode_location_queries=queries,project_alias='FX3GHOLD')
 events=[json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
 if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
raw=(native/'compiler_DZComp/DebugInformation2.dat').read_bytes();debug=parse_compiler_debug(raw);maps=reader.search_maps(debug,encoding='cp1252');reader.search_maps=lambda d,encoding:maps
answers=json.loads((native/'native-pcode-locations.json').read_text(encoding='utf-8-sig'));rows=[]
for a in answers:
 ours=reader.lookup(debug,'MAIN',a['query']['start_step'],encoding='cp1252');comparable=ours['handling'].startswith('native-compatible') or ours['handling'] in ('no-stored-element','native-terminal-step')
 expected_code=0 if ours.get('location') is not None else ours.get('expected_native_code',0x50020014)
 rows.append(dict(step=a['query']['start_step'],ours=ours,native=a['location'],native_code=a['code'],equal=ours.get('location')==a['location'] and a['code']==expected_code if comparable else None))
(OUT/'comparisons.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
summary=dict(queries=len(rows),native_success=sum(a['code']==0 for a in answers),debug_elements=len(debug.elements),handling=dict(Counter(r['ours']['handling'] for r in rows)),differences=sum(r['equal'] is False for r in rows),comparable=sum(r['equal'] is not None for r in rows),pcode_unchanged=(native/'pcode-0-0.bin').read_bytes()==code,returncode=outcome['returncode'],fresh_check=outcome['program_check_target'],errors=[r for r in outcome['diagnostics'] if r['kind']==2]);(OUT/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in summary.items() if k!='errors'},ensure_ascii=True))
