"""Audit native CONCAT lowering, storage selection and bounded offline witnesses."""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[4];sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from gxw.token_q import q_operand_text
from source_q_label_binding import scalar
from source_q_st_calls import predict
from witness_st_conditional_transfers import decode,evaluate
from probe_minimal_conditional_port_writes import save,streams
from verify_temporary_check_correspondence import verify
P=Path(__file__).resolve().parent
GROUPS=['st-concat-discovery-20260930','st-concat-forward-20260930','st-concat-storage-holdouts-20260930',
        'st-dynamic-string-store-forward-20260930','st-concat-slot-exhaustion-20260930']
DISCOVERY_EXPECTED={'separate-target':['ABCD','AB','CD'],'left-overlap':['ABCD','CD','ABCD'],
                    'constant-fold':['AB','AB','AB'],'two-dynamic-inputs':['ABCD','AB','CD'],'inout-concat-copyback':['ABQ','AB','ABQ']}


def main():
    rows=[]
    for group in GROUPS:
        out=P/group;config=json.loads((out/'experiment-plan.json').read_text());plans={p['case']:p for p in config['cases']}
        listings={r['case']:r['records'] for r in json.loads((out/'native-listings.json').read_text())}
        for c in json.loads((out/'comparison.json').read_text()):
            d=out/c['case'];n=Path(c['native_directory']);before=json.loads((d/'before-native.json').read_text());source=(d/'input.gxw').read_bytes()
            assert sha256(source)==before['input_sha256']==sha256((n/'input.gxw').read_bytes())
            content=streams(source);assert all(sha256(content[k])==v for k,v in before['unchanged_streams'].items())
            try:model=predict(source,('SCPI',),owner='MAIN',allow_inputs=True,allow_omitted=True,allow_members=True,allow_concat=True,allow_alternate_banks=True,allow_dynamic_stores=True)
            except ValueError as exc:model=dict(output=None,unsupported=str(exc))
            row=dict(group=group,case=c['case'],input_sha256=sha256(source),accepted=bool(c['check'] and not c['check']['rejected']),
                before_native_prediction_equal=c['predicted_equal'],before_native_unsupported=before['prediction'].get('unsupported'),
                unchanged_payloads=len(before['unchanged_streams']),diagnostic_codes=sorted(set(hex(e['code']) for e in c['diagnostics'] if e['kind']==2)))
            messages=[json.loads(l) for l in (n/'events.jsonl').read_text().splitlines()];assert not any(m.get('type')=='error' for m in messages)
            events=[m['payload'] for m in messages if m.get('type')=='send'];assert not any('error' in r.get('event','') or r.get('observation_error') for r in events)
            temps=[r for r in events if r.get('event')=='temporary-create'];selections=[r for r in events if r.get('event')=='temporary-slots' and r['name']=='select']
            row['temporary_requests']=[{k:r[k] for k in ('type','count','caller','result','output')} for r in temps]
            row['slot_selections']=[dict(args=r['args'],slot=r['result']) for r in selections]
            if row['accepted']:
                code=(n/'pcode-0-0.bin').read_bytes();assert code==model['output'],(group,c['case'],'current prediction differs')
                saved_prediction=d/'predicted-0.bin'
                if saved_prediction.exists():assert (saved_prediction.read_bytes()==code)==c['predicted_equal']
                else:assert c['predicted_equal'] is None and 'unsupported' in before['prediction']
                assert c['reopen']['check'] and not c['reopen']['check']['rejected'] and c['reopen']['identical']
                records=decode(code);assert [{k:v for k,v in r.items() if k not in ('raw','offset')} for r in records]==listings[c['case']]
                names=['probeR0','probeR1','probeR2'];capacity=c['case'].startswith('concat-target-capacity-')
                if capacity:names+=['probeIndex','probeArray']
                obs={}
                for name in names:
                    a=next(a for a in model['declarations'] if a['owner']=='MAIN' and a['name']==name)
                    obs[name]=dict(address=q_operand_text(scalar(a['allocated_family'],a['number']),text_encoding='cp932'),type=a['data_type'].split(' OF ')[-1])
                witness=evaluate(records,obs);expected=plans[c['case']].get('expected',DISCOVERY_EXPECTED.get(c['case']))
                assert list(witness['observations'].values())[:3]==expected,(c['case'],witness['observations'],expected)
                if capacity:
                    small=c['case'].endswith('-9')
                    assert witness['observations']['probeIndex']==(19531 if small else 77)
                    assert witness['observations']['probeArray']==('' if small else 'ABCDEFGH')
                    row['capacity_witness']='12-character result overwrites adjacent initialized index and array word in the finite memory model' if small else '12-character result stays within the wider declaration allocation'
                typed=[r for r in events if r.get('event')=='typed-allocation' and r['result']==1]
                assert len(typed)==len(model['declarations'])
                for a,b in zip(typed,model['declarations'],strict=True):assert bytes.fromhex(a['after'])==bytes.fromhex(b['raw'])
                actual=[]
                for t in temps:
                    assert t['result']==0
                    raw=bytes.fromhex(t['output']);tag=int.from_bytes(raw[20:24],'little');physical_type=tag&255;wide=physical_type in (100,114,119)
                    family='ZR' if tag&0x8000 else {68:'D',87:'W',82:'R'}[physical_type-(32 if wide else 0)]
                    actual.append((t['type'],family,int.from_bytes(raw[8:12],'little'),t['count']*(2 if wide else 1),t['caller']['rva']))
                expected_creates=[({'D':68,'W':87,'R':82,'ZR':82}[r['family']],r['family'],r['number'],r['width'],'0xca1cf')for r in model['input_buffers']]
                expected_creates += [(r['creation_request_type'],r['family'],r['number'],r['width'],'0x6d632')for r in model['slots']]
                assert sorted(actual)==sorted(expected_creates),(c['case'],actual,expected_creates)
                selected_slots=[e['slot'] for e in model['temporary_events'] if e['action'] in ('create','reuse')]
                assert selected_slots==[r['result'] for r in selections],(c['case'],selected_slots,row['slot_selections'])
                row.update(pcode_sha256=sha256(code),corrected_prediction_equal=True,native_core_lexical_equal=True,bindings=obs,witness=witness,
                    typed_allocations_verified=len(typed),temporary_creates_verified=len(temps),slot_selections_verified=len(selections),
                    model_slots=model['slots'],model_temporary_events=model['temporary_events'])
            else:
                assert model['output'] is None,(c['case'],'model still predicts rejected input')
                assert set(row['diagnostic_codes'])-{'0x50010000'} <= {'0x50f0196','0x50c9066','0x50f1218'}
                row['corrected_model_rejection']=model['unsupported']
            rows.append(row)
    result=dict(groups=GROUPS,cases=rows,accepted=sum(r['accepted'] for r in rows),rejected=sum(not r['accepted'] for r in rows),
        before_native_matches=sum(r['accepted'] and r['before_native_prediction_equal'] is True for r in rows),
        corrected_source_matches=sum(r.get('corrected_prediction_equal',False) for r in rows),
        typed_allocations_verified=sum(r.get('typed_allocations_verified',0) for r in rows),temporary_creates_verified=sum(r.get('temporary_creates_verified',0) for r in rows),
        slot_selections_verified=sum(r.get('slot_selections_verified',0) for r in rows),
        scope='SCPI-derived Q03UDV controlled ST, selected from real Keypad CONCAT/dynamic-store usage. Native compile/check/reopen plus independent native lexical decode; finite initialized ASCII word-memory witnesses, no PLC execution.',
        findings=['CONCAT emits left copy (elided for a direct left alias) then two-operand $+; a directly overlapping right operand is rejected.',
            'Dynamic STRING CONCAT operands are captured before result writes. An overlapping INPUT alias rejects the right-overlap body, while a dynamic INPUT copy permits it.',
            'CONCAT indexed-string captures request native D type68; W/R/ZR physically store another type. Reuse compares requested type with stored type, so subsequent captures allocate new slots while ordinary arithmetic can reuse released physical-family slots.',
            'Observed inline CONCAT INPUT actual, nested CONCAT and direct dynamic CONCAT destination are rejected. Typed scalar intermediates compile in the controls.',
            'Dynamic STRING assignment evaluates source index in Z16 first; destination uses a double temporary followed by Z18, with ZZ forms for ZR.',
            'Native acceptance and PCode do not enforce source STRING destination capacity in these CONCAT controls. The finite witness for a nine-character destination changes adjacent probeIndex77 to19531; a twelve-character destination retains77.'])
    out=P/GROUPS[-1];save(out/'concat-storage-analysis.json',result);save(out/'aggregate-check-correspondence.json',verify(GROUPS))
    for name in (Path(__file__).name,'source_q_st_calls.py','source_q_width.py','witness_st_conditional_transfers.py'):(out/('verified-'+name)).write_bytes((P/name).read_bytes())
    print(json.dumps({k:v for k,v in result.items() if k not in ('groups','cases','scope','findings')}))


if __name__=='__main__':main()
