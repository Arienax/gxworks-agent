"""Recover the descriptor graph selected by the observed Q03UDV native context.

The native lookup selects CPU word 0x71, prefixes at 0x15f090, uint16 indices
at 0x15f188, then 10-byte rows at 0x15da18. This extracts data, not vendor code.
"""
from pathlib import Path
import hashlib,json,struct,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path.insert(0,str(ROOT/'research/experiments/re-tools'))
import pefile
P=Path(__file__).resolve().parent
out=P/'q-token-catalog-v2';out.mkdir(exist_ok=False)
dll=Path('D:/GXWORKS2/Easysocket/CodeGenerator/ECCodeGenerator2.dll');digest=hashlib.sha256(dll.read_bytes()).hexdigest()
assert digest=='2e5c47b0a0d0b59eb26dbab149862a05983a1fa9519a75e446bc680e7cc16f73'
pe=pefile.PE(str(dll));im=pe.get_memory_mapped_image();base=pe.OPTIONAL_HEADER.ImageBase
descriptors,prefixes,indices=0x15da18,0x15f090,0x15f188
count=(prefixes-descriptors)//10
assert im[descriptors+count*10:prefixes]==b'\0\0'
prefix=list(struct.unpack_from('<123H',im,prefixes));assert prefix[0]==0 and prefix==sorted(prefix)
assert im[prefixes+246:indices]==b'\0\0'
lookup=list(struct.unpack_from(f'<{prefix[-1]}H',im,indices))
rows=[]
for index in range(count):
 rva=descriptors+index*10;raw=im[rva:rva+10];name_rva=struct.unpack_from('<I',raw)[0]-base
 end=im.find(b'\0',name_rva,name_rva+64);assert 0<=name_rva<end<len(im)
 name=im[name_rva:end].decode('ascii');assert all(32<=ord(c)<=126 for c in name)
 rows.append(dict(index=index,rva=rva,name_rva=name_rva,name=name,raw_hex=raw.hex(),fields=list(raw[4:])))
queries=[];edges=[]
for family,(a,b) in enumerate(zip(prefix,prefix[1:])):
 assert 0<=b-a<=255
 for variant,number in enumerate(lookup[a:b]):
  assert number==0xffff or number<count
  queries.append([family,variant]);edges.append(dict(family=family,variant=variant,index=None if number==0xffff else number))
result=dict(dll_sha256=digest,adapter_cpu=209,observed_active_cpu_word=0x71,
            descriptor_rva=descriptors,prefix_rva=prefixes,index_rva=indices,
            rows=rows,prefixes=prefix,edges=edges,scope=__doc__)
with (out/'catalog.json').open('x') as f:json.dump(result,f,indent=2)
with (out/'queries.json').open('x') as f:json.dump(queries,f)
print(json.dumps(dict(descriptors=count,families=len(prefix)-1,edges=len(edges),holes=sum(e['index'] is None for e in edges),
                     operand_count_values=sorted({r['fields'][0] for r in rows}),row_type_values=sorted({r['fields'][3] for r in rows}))))
