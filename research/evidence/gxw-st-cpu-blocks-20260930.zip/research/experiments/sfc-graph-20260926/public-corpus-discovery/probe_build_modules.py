from pathlib import Path
import sys,json,hashlib
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from replay_gxw_workspace import prepare,trace_prepared
P=Path(__file__).resolve().parent
out=P/'timer-generator-modules'
prepare(P/'ST-standard-timer-controls/TON_E_true/changed.gxw',out,compile=True,export_project=True)
print(json.dumps(trace_prepared(out,P/'TraceBuildModules.js',timeout=45)),flush=True)
events=[json.loads(s) for s in (out/'events.jsonl').read_text().splitlines()]
snapshot=next(e['payload'] for e in events if e.get('payload',{}).get('event')=='compile-module-snapshot')
for module in snapshot['modules']:
 path=Path(module['path'])
 if 'windows' in path.parts[1].lower():continue
 raw=path.read_bytes();module['sha256']=hashlib.sha256(raw).hexdigest()
 hits={s:[raw.find(s.encode()),raw.find(s.encode('utf-16le'))] for s in ['FOREIGN_NET','CG LABEL','TIMER_LOW_FB_M','TON_E']}
 module['hits']={s:pos for s,pos in hits.items() if any(n>=0 for n in pos)}
 if module['hits']:print(json.dumps(module),flush=True)
(out/'module-snapshot.json').write_text(json.dumps(snapshot,indent=2))
print(json.dumps(dict(stack=snapshot['stack'],errors=[e for e in events if e.get('type')=='error'])),flush=True)
