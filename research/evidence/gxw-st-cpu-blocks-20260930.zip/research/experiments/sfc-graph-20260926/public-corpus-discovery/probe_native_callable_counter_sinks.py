"""Exercise native formal binding using an original, isolated library FB."""
from pathlib import Path
from dataclasses import replace
import sys, json, base64, zipfile
ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'research')]
from gxw.lossless import inspect_project, sha256
from gxw.structured_pou import parse_structured_pou
from gxw.structured_pou_writer import serialize_structured_pou
from gxw.declarations import parse_declarations, edit_declarations, serialize_declarations
from gxw.project_metadata import mark_observed_source_compile_pending
from probe_gxw_library_archive import decode_library_archive, encode_library_literals
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import prepare, trace_prepared
from native_gxw_tokens import native_batch, native_il_projection, DEFAULT_DLL

P = Path(__file__).resolve().parent
out = P / 'native-callable-counter-sink-controls'
out.mkdir(exist_ok=False)
(out / 'probe.py').write_bytes(Path(__file__).read_bytes())
with zipfile.ZipFile(ROOT / 'research/evidence/gxw-generation-20260910.zip') as archive:
    source = archive.read('fresh_fbd_compile.gxw')
streams = {s.logical_name: s.raw for s in inspect_project(source).streams if s.logical_name}
logical = '1.Program.pou'
program = parse_structured_pou(streams[logical], logical_name=logical)
fixtures = {}
for file in (ROOT / 'tests/fixtures').glob('gxw_structured*.json'):
    fixtures.update(json.loads(file.read_text()))
rows = []
for case in ['75', '77']:
    directory = out / case
    directory.mkdir()
    f = fixtures[case]
    raw = base64.b64decode(f['program_pou_base64'])
    if 'program_pou_sha256' in f:
        assert sha256(raw) == f['program_pou_sha256']
    program = parse_structured_pou(raw, logical_name=logical)
    program = replace(program, nodes=tuple(replace(n, symbol='Y1') if n.symbol == 'T1' else n for n in program.nodes))
    raw = serialize_structured_pou(program)
    replacements = {logical: mark_observed_source_compile_pending(raw, logical_name=logical)}
    for name, r in f.get('related_files', {}).items():
        if not name.endswith(('.Labels.lh', '.gh')):
            continue
        value = base64.b64decode(r['base64'])
        assert sha256(value) == r['sha256']
        if name not in streams:
            raise ValueError('seed lacks related declaration stream ' + name)
        replacements[name] = mark_observed_source_compile_pending(value, logical_name=name)
    blocks = [n for n in program.nodes if n.kind_code == 2]
    if blocks:
        labels = '1.Labels.lh'
        d = parse_declarations(replacements.get(labels, streams[labels]), logical_name=labels)
        replacements[labels] = mark_observed_source_compile_pending(serialize_declarations(edit_declarations(d,
            upserts=[dict(name=n.symbol, data_type=n.type_name, kind='function_block') for n in blocks])), logical_name=labels)
    changed = source
    receipts = []
    for name, raw in replacements.items():
        changed, receipt = patch_raw(changed, name, streams[name], raw)
        receipts.append(receipt)
    after = {s.logical_name: s.raw for s in inspect_project(changed).streams if s.logical_name}
    assert after == dict(streams, **replacements)
    path = directory / 'source.gxw'
    path.write_bytes(changed)
    (directory / 'mutation.json').write_text(json.dumps(dict(source_sha256=sha256(source), changed_sha256=sha256(changed),
        changed_streams=list(replacements), fixture_case=case,
        unrelated_payloads='byte-identical', receipts=receipts), indent=2))
    for attempt in range(3):
        native = directory / ('native' if not attempt else f'native-attempt-{attempt}')
        prepare(path, native, compile=True, export_project=True, snapshot_frontend=True, project_alias='GRAPHINOUT')
        process = trace_prepared(native, P / 'TraceCallableFormals.js')
        native_events = [json.loads(s) for s in (native / 'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
        if native_events[-1]['operation'] != 'NativeTemporaryDirectoryCollision':
            break
    events = [json.loads(s) for s in (native / 'events.jsonl').read_text().splitlines()]
    sources = []
    for e in events:
        p = e.get('payload', {})
        if p.get('event') == 'enter' and p.get('name') == 'Compile':
            buffers = {b['label']: b for b in p['buffers']}
            for k, b in buffers.items():
                if k.startswith('source_') and b['bytes']:
                    i = k.removeprefix('source_')
                    value = bytes.fromhex(b['bytes'])
                    assert len(value) == b['requested_size']
                    name = bytes.fromhex(buffers['name_' + i]['bytes']).split(b'\0')[0].decode('ascii', errors='backslashreplace')
                    filename = f'compile-{p["id"]}-{i}.sic'
                    (directory / filename).write_bytes(value)
                    sources.append(dict(name=name, file=filename, text=value.decode('ascii', errors='backslashreplace')))
    diagnostics = {json.dumps({k:v for k,v in d.items() if k != 'raw_base64'},sort_keys=True)
                   for e in native_events for d in e.get('reports', []) if d['kind'] in [2, 3]}
    row = dict(case=case, process=process, native_directory=str(native.relative_to(out)),
        native_exported=(native / 'native-saved.gxw').exists(), diagnostics=[json.loads(d) for d in sorted(diagnostics)],
        crt_checks=[e for e in native_events if e['operation'] == 'NativeCrtCharacterCase'], sources=sources,
        trace_errors=[e for e in events if e.get('type') == 'error' or e.get('payload', {}).get('event', '').endswith(('error', 'failed'))],
        formals=[e['payload'] for e in events if e.get('payload', {}).get('event') == 'native-callable-formals'],
        port_sort=[e['payload'] for e in events if e.get('payload', {}).get('event') == 'native-callable-sort'])
    code = native / 'pcode-0-0.bin'
    if row['native_exported'] and code.exists():
        answer, = native_batch([dict(mode='decode', input_base64=base64.b64encode(code.read_bytes()+b'\0').decode())], directory / 'decode', dll=DEFAULT_DLL, cpu_code=0x208)
        assert answer['return_code'] == '0x00000000' and answer['consumed_bytes'] == code.stat().st_size
        row['listing'] = native_il_projection(base64.b64decode(answer['output_base64']), encoding='gb18030')
        row['pcode_sha256'] = sha256(code.read_bytes())
    rows.append(row)
    (out / 'comparison.json').write_text(json.dumps(rows, indent=2))
    (directory / 'comparison.json').write_text(json.dumps(row, indent=2))
    print(json.dumps(dict(case=case, exported=row['native_exported'], diagnostics=row['diagnostics'], source=[s['text'] for s in sources if s['name']=='1'])), flush=True)
