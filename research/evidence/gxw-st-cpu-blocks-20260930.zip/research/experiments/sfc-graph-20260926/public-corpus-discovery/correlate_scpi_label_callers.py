"""Cross-check source declarations and CG allocation against native FB inputs."""
from pathlib import Path
import copy,json,re,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256,inspect_project
from gxw.declarations import parse_declarations
from gxw.compiler_tables import parse_compiler_tables
from probe_gxw_simple_fb import frame_source
from probe_gxw_simple_fb_connections import inspect as inspect_connections
from probe_gxw_compiled_references import stored_records
from probe_gxw_callsite_inputs import compare_callsite_inputs
from probe_gxw_operand_bindings import resolve_operand,format_bound_device
P=Path(__file__).resolve().parent
for case in sys.argv[1:] or ['local-auto','global-address','global-constant','local-array-static','global-array-static']:
 parent=P/'scpi-label-inputs'/case
 outcome=json.loads((parent/'native/outcome.json').read_text());assert outcome['compile_completed'] and not outcome['compiler_rejected']
 source=(parent/'native/native-saved.gxw').read_bytes()
 connection_file=parent/'source-connections/connections.json'
 if connection_file.parent.exists() and not connection_file.exists():connection_file=parent/'source-connections-v2/connections.json'
 connections=json.loads(connection_file.read_text(encoding='utf-8')) if connection_file.exists() else inspect_connections(source,connection_file.parent)
 baseline=json.loads((P/'scpi-label-input-bindings'/('label-'+case)/'comparison.json').read_text())
 assert sha256(source)==baseline['export_sha256']==connections['source_sha256']
 streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
 tables=parse_compiler_tables((parent/'native/compiler_DZComp/CGTable.dat').read_bytes())
 declarations=[(n,parse_declarations(raw,logical_name=n)) for n,raw in streams.items() if n=='MAIN.Labels.lh' or n.endswith('.gh')]
 oracle=json.loads((parent/'native/native-device-assignments.json').read_text(encoding='utf-8-sig'))
 resolutions=[];results=[]
 for original in baseline['expansions']:
  e=copy.deepcopy(original);name=e['parent']+'.Program.pou'
  groups,_=stored_records(frame_source(streams[name]),encoding='cp932')
  offsets=[g['offset'] for g in groups if g['stored_step']==e['parent_source_step']];assert len(offsets)==1
  calls=[c for p in connections['programs'] if p['name']==name for c in p['calls'] if c['offset']==offsets[0]];assert len(calls)==1
  call=calls[0];assert not call['gaps'] and call['instance']==e['instance']
  inputs=call['connection_fragments']['input'];assert not inputs['text_gaps']
  resolved=copy.deepcopy(inputs['records'])
  for instruction in resolved:
   if instruction['op']!='MOV':continue
   token=instruction['args'][0]
   if not token.startswith("'"):continue
   match=re.fullmatch(r"'([A-Za-z_][A-Za-z_0-9]*)(?:\[(-?[0-9]+)\])?",token);assert match
   candidates=[(n,r) for n,d in declarations for r in d.rows if r.name.lower()==match[1].lower()]
   assert len(candidates)==1 # No inferred shadowing/namespace precedence.
   declaration_name,declaration=candidates[0];scope='MAIN' if declaration_name=='MAIN.Labels.lh' else '@GLOBALS'
   owners=[tables.pou_at(r.table_offset) for r in tables.tables[1].records if tables.pou_at(r.table_offset).name_bytes==scope.encode()];assert len(owners)==1
   components=[c for c in tables.components(owners[0]) if c.name_bytes.lower()==match[1].encode().lower()];assert len(components)==1
   component=components[0];binding=resolve_operand('K'+str(component.record.table_offset),tables,tables,cpu='Q03UDV')
   if declaration.class_code==9:
    assert declaration.data_type=='INT' and match[2] is None and re.fullmatch(r'-?[0-9]+',declaration.initial_value)
    number=int(declaration.initial_value);assert -32768<=number<=32767
    operand='K'+str(number);reason='source INT global-constant declaration'
   else:
    assert not binding['gaps'];operand=binding['operand'];reason='declared scope plus compiler component allocation'
    if match[2] is not None:
     dims=binding['array']['dimensions'];assert len(dims)==1
     relative=int(match[2])-dims[0]['lower'];assert 0<=relative<dims[0]['extent']
     operand=format_bound_device(binding['base'],relative*binding['layout']['stride'])
   native=[r for q in oracle for r in q['assignments'] if r['name'].lower()==token[1:].lower()];assert len(native)==1
   assert operand==native[0]['address']
   resolutions.append(dict(source_operand=token,resolved_operand=operand,rule=reason,declaration_stream=declaration_name,
                           declaration_raw_sha256=sha256(declaration.raw),component_binding=binding,native_assignment=native[0]))
   instruction['args'][0]=operand
  lowering=compare_callsite_inputs(resolved,call['ports'],e['parent_compiled_records']);assert not lowering['gaps']
  overlay={b['port'].lower():b['operand'] for b in lowering['bindings']}
  output=call['connection_fragments']['output'];assert not output['text_gaps'] and not output['uninterpreted_groups']
  for b in output['bindings']:overlay[b['port'].lower()]=b['operand']
  exact=corrected=0;differences=[]
  for row in e['rows']:
   expected=copy.deepcopy(row['expected_records'])
   token_map={b['token']:overlay[b['component'].lower()] for b in row['bindings'] if b.get('component','').lower() in overlay}
   for s,t in zip(row['source_records'],expected):
    if s['kind']=='instruction':t['args']=[token_map.get(a,b) for a,b in zip(s['args'],t['args'])]
   matched=not row['gaps'] and expected==row['compiled_records']
   row.update(label_expected_records=expected,label_binding_exact=matched)
   exact+=matched;corrected+=matched and row['handling']=='lowering-difference'
   if not matched:differences.append(row)
  e.update(callsite=call,resolved_input_records=resolved,input_lowering=lowering,
           label_binding_summary=dict(groups=len(e['rows']),exact=exact,corrected=corrected),differences=differences)
  results.append(e)
 result=dict(case=case,export_sha256=sha256(source),label_resolutions=resolutions,expansions=results,
             scope='unambiguous ASCII source labels, observed INT/global-constant and single-dimensional literal-index cases; source and native compile bound')
 with (parent/'label-binding-comparison.json').open('x') as f:json.dump(result,f,indent=2)
 print(json.dumps(dict(case=case,resolutions=[dict(source=r['source_operand'],resolved=r['resolved_operand']) for r in resolutions],expansions=[e['label_binding_summary'] for e in results])),flush=True)
