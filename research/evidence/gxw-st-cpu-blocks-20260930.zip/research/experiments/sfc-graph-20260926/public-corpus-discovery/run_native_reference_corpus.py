"""Discover native references across the existing real corpus and FB controls."""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'research')]
from probe_gxw_native_references import inspect

P = Path(__file__).resolve().parent
OUT = P / 'native-reference-real-corpus'
OUT.mkdir(exist_ok=False)
sources = [dict(case='case-'+str(r['case']).zfill(2),source=r['source']) for r in
           [json.loads(line) for line in (P/'native-allocation-inventory/results.jsonl').read_text().splitlines()]]
sources += [dict(case=name,source=str(P/path)) for name,path in [
    ('two','scpi-two-callers/native/native-saved.gxw'),
    ('same','scpi-instance-binding-controls/same-instance/native/native-saved.gxw')]]
for source in sources:
    row = dict(source)
    try:
        result = inspect(Path(source['source']),OUT/source['case'])
        row.update(handling=result['handling'],summary=[q['summary'] for q in result['queries']],
                   native=result['native'])
    except Exception as exc:
        row['error'] = str(exc)
    with (OUT/'results.jsonl').open('a',encoding='utf-8') as output:output.write(json.dumps(row)+'\n')
    print(json.dumps({k:v for k,v in row.items() if k not in ['native','source']}),flush=True)
