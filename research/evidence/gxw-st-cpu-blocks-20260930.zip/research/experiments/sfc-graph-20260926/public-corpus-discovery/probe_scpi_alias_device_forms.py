"""Offline native controls for general FB alias eligibility, preserving failures."""
from pathlib import Path
import base64, json, struct, sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project, sha256
from probe_gxw_simple_fb import frame_source, observe_calls
from probe_gxw_parameters import device_allocation_record
from probe_gxw_sfc_graph import patch_raw
from native_gxw_tokens import native_batch, native_il_projection, Q_DLL
from replay_gxw_workspace import prepare, run, trace_prepared
P=Path(__file__).resolve().parent
OUT=P/'scpi-alias-device-forms';OUT.mkdir(exist_ok=False)
(OUT/'probe.py').write_bytes(Path(__file__).read_bytes())
compiler=Path('D:/GXWORKS2/Easysocket/Compiler/ECCompiler_IEC.dll')
assert sha256(compiler.read_bytes())=='f58e7c70b855526bf2f943399a14089f771a43109b13ee9af34c88fb065cf4d7'
observer=(P/'TraceBinaryAliasDecisions.js').read_text(encoding='utf-8')
observer+='''
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='eccompiler_iec.dll')return;
 for(const [rva,guard] of [[0xe97be,'8b442418'],[0xe78be,'8a442439']]){
  if(hex(m.base.add(rva),4)!==guard){emit({event:'alias-token-guard-error',rva});continue;}
  Interceptor.attach(m.base.add(rva),{onEnter(){const d=aliasDecisions.get(this.threadId);if(!d)return;
   try{const s=this.context.esp,n=s.add(0x1c).readS32();if(n<2||n>256)throw new Error('resolved token size');
    d.eligibility={category:s.add(0x18).readS32(),resolved:hex(s.add(0x38),n),formatted:string(s.add(0x14).readPointer(),4096),site:loc(this.context.eip)};
   }catch(e){d.observation_error=String(e);}
  }});
 }
}});
'''
hook=OUT/'observer.js';hook.write_text(observer,encoding='utf-8')
source=(P/'scpi-instance-binding-controls/same-instance/native/native-saved.gxw').read_bytes()
streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
name='MAIN.Program.pou';frame=frame_source(streams[name]);calls=observe_calls(frame)['calls'];assert len(calls)==2
# Each row is scalar input/output and BOOL input/output. No PLC execution.
specs={
 'banks':[('W120','W140','B20','B30'),('R200','R240','L20','L30')],
 'registers':[('Z1','Z2','SM400','SM402'),('SD200','SD220','F20','F30')],
 'groups':[('K4M200','K4M240','M20','M30'),('K4X20','K4Y40','X20','Y40')],
 'modifiers':[('D200Z0','D240Z1','D200.3','D240.4'),('@D200','@D240','M200Z0','Y20Z1')],
 'buffers':[('U0\\G200','U0\\G240','B20','B30'),('W120Z0','W140Z1','W200.3','W240.4')],
 'immediates':[('K123','D100','X1F','M50'),('H7B','D101','X2F','M51')],
}
plans=[];requests=[]
for case,values in specs.items():
 plan=dict(case=case,values=values,requests=[])
 for value,target,enable,done in values:
  texts=[f"LD {enable}\0OUT '_iEn\0LD '_TRUE\0MOV {value} '_iUnitNo",
         f"LD '_oRecvCmdDone\0OUT {done}\0LD '_TRUE\0MOV '_oRecvCmdNum {target}"]
  plan['requests'].append([len(requests),len(requests)+1])
  requests.extend(dict(mode='encode',text=t,input_base64=base64.b64encode(t.encode()+b'\0\0').decode()) for t in texts)
 plans.append(plan)
answers=native_batch(requests,OUT/'native-encode',dll=Q_DLL,cpu_code=209,native_versions=(25,),device_context=device_allocation_record(streams['Param.wpa']).raw)
results=[]
def save(row,directory):
 (directory/'comparison.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
 results.append(row);(OUT/'comparison.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
 print(json.dumps({k:v for k,v in row.items() if k not in ['decisions','stores','decoded','baseline']}),flush=True)
for plan in plans:
 directory=OUT/plan['case'];directory.mkdir()
 failed=[answers[i] for pair in plan['requests'] for i in pair if answers[i]['return_code']!='0x00000000']
 if failed:save(dict(plan,encode_failures=failed),directory);continue
 replacements=[]
 for call,pair in zip(calls,plan['requests']):
  for direction,index in zip(['input','output'],pair):
   span=call[direction+'_fragment'];replacements.append((span['offset'],span['offset']+span['length'],base64.b64decode(answers[index]['output_base64'])))
 program=frame.raw
 for a,b,replacement in sorted(replacements,reverse=True):program=program[:a]+replacement+program[b:]
 program=bytearray(program);delta=len(program)-len(frame.raw)
 for offset in [55,59]:struct.pack_into('<I',program,offset,struct.unpack_from('<I',frame.raw,offset)[0]+delta)
 assert len(observe_calls(frame_source(bytes(program)))['calls'])==2
 changed,receipt=patch_raw(source,name,frame.raw,bytes(program));path=directory/'changed.gxw';path.write_bytes(changed)
 after={s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}
 assert after.keys()==streams.keys() and all(after[k]==v for k,v in streams.items() if k!=name)
 (directory/'mutation.json').write_text(json.dumps(dict(plan,source_sha256=sha256(source),changed_sha256=sha256(changed),receipt=receipt,unrelated_payloads='byte-identical'),indent=2))
 for attempt in range(1,5):
  baseline_dir=directory/f'untraced-{attempt}'
  baseline=run(path,baseline_dir,compile=True,export_project=True,snapshot_frontend=True,project_alias='ALIASFORMS')
  ne=[json.loads(l) for l in (baseline_dir/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
  if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in ne):break
 for attempt in range(1,5):
  traced=directory/f'trace-{attempt}'
  prepare(path,traced,compile=True,export_project=True,snapshot_frontend=True,project_alias='ALIASFORMS')
  process=trace_prepared(traced,hook)
  ne=[json.loads(l) for l in (traced/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
  if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in ne):break
 raw=[json.loads(l) for l in (traced/'events.jsonl').read_text(encoding='utf-8').splitlines()]
 events=[e['payload'] for e in raw if e.get('type')=='send']
 errors=[e for e in raw if e.get('type')=='error' or any(k.endswith('error') for k in e.get('payload',{})) or e.get('payload',{}).get('event','').endswith('-error')]
 codes={f.name:f.read_bytes() for f in baseline_dir.glob('pcode-*.bin')}
 exact={n:(traced/n).exists() and (traced/n).read_bytes()==b for n,b in codes.items()}
 selected=[(n,b) for n,b in codes.items() if b];decoded=[]
 if selected:
  aa=native_batch([dict(mode='decode',name=n,input_base64=base64.b64encode(b+b'\0').decode()) for n,b in selected],directory/'decode',dll=Q_DLL,cpu_code=209)
  for (n,b),a in zip(selected,aa):
   item=dict(name=n,return_code=a['return_code'],consumed_bytes=a['consumed_bytes'],bytes=len(b))
   if a['return_code']=='0x00000000' and a['consumed_bytes']==len(b):item['listing']=native_il_projection(base64.b64decode(a['output_base64']),encoding='cp932')
   decoded.append(item)
 decisions=[e for e in events if e['event']=='alias-decision'];stores=[e for e in events if e['event']=='alias-store-request']
 row=dict(plan,baseline=baseline,baseline_directory=baseline_dir.name,trace_directory=traced.name,process=process,errors=errors,exact_pcode=exact,decisions=decisions,stores=stores,decoded=decoded,decision_count=len(decisions),alias_count=len(stores),native=dict(returncode=baseline['returncode'],compile_completed=baseline['compile_completed'],compiler_rejected=baseline['compiler_rejected'],diagnostics=baseline['diagnostics']))
 save(row,directory)
(OUT/'manifest.json').write_text(json.dumps(dict(source_sha256=sha256(source),compiler_sha256=sha256(compiler.read_bytes()),observer_sha256=sha256(hook.read_bytes()),scope='Owned x86 helper, offline compile/export; no PLC or simulator; synthetic connection controls in real SCPI project.'),indent=2))
