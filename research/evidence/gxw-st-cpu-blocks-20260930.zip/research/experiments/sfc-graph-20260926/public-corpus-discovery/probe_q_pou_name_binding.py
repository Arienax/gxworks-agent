"""Isolate logical names from embedded label owners and folder associations."""
from pathlib import Path
import base64,json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.container_writer import validate_cfb_streams,replace_stream_within_allocation
from gxw.project_metadata import current_rows,logical_mapping
from replay_gxw_workspace import run
from native_gxw_tokens import native_batch,native_il_projection,Q_DLL
P=Path(__file__).resolve().parent
out=P/'q-pou-name-binding';out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
source=(P/'q-label-owner-binding-v2/baseline/input.gxw').read_bytes()
outer=validate_cfb_streams(source);assert not outer.get('Project.gd2')
xml=outer['projectdatalist.xml'];xml_rows,encoding=current_rows(xml,'DSPROJECTDATA','D_Projectdata')
fields={r.fields()['szName'].text:r.fields() for r in xml_rows if r.fields().get('szName') and r.fields().get('bScrapFlag').text=='false'}
A,B='기본동작','응용동작1'
plans=[('baseline',None),('label-logical-name-swap','.Labels.lh'),('source-logical-name-swap','.Program.pou')]
rows=[];requests=[];files={}
for case,suffix in plans:
    directory=out/case;directory.mkdir();changed=source;edits=[]
    if suffix:
        modifications=[]
        for name,other in [(A,B),(B,A)]:
            node=fields[name+suffix]['szName'];new=(other+suffix).encode(encoding)
            assert xml[node.content_start:node.content_end]==(name+suffix).encode(encoding)
            modifications.append((node.content_start,node.content_end,new))
            edits.append(dict(physical_stream=fields[name+suffix]['iID'].text,old=name+suffix,new=other+suffix))
        modified=xml
        for start,end,raw in sorted(modifications,reverse=True):modified=modified[:start]+raw+modified[end:]
        assert len(modified)==len(xml)
        expected=logical_mapping(xml)
        expected[A+suffix],expected[B+suffix]=expected[B+suffix],expected[A+suffix]
        assert logical_mapping(modified)==expected
        changed=replace_stream_within_allocation(source,'projectdatalist.xml',modified)
        assert validate_cfb_streams(changed)==dict(outer,**{'projectdatalist.xml':modified})
    path=directory/'input.gxw';path.write_bytes(changed)
    (directory/'mutation.json').write_text(json.dumps(dict(source_sha256=sha256(source),changed_sha256=sha256(changed),edits=edits,
        preservation='Only two current projectdatalist szName values exchanged. IDs, folder values, all nested bytes and all other outer streams are unchanged; history retains original names.'),indent=2),encoding='utf-8')
    for attempt in range(1,9):
        native=directory/('native' if attempt==1 else 'native-v'+str(attempt))
        result=run(path,native,compile=True,snapshot_frontend=True,export_project=True,project_alias='QPOUNAME')
        events=[json.loads(s) for s in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
        if (native/'pcode-0-0.bin').exists() or not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
    row=dict(case=case,native_directory=str(native.relative_to(out)),native={k:result[k] for k in ('returncode','open_succeeded','compile_completed','compiler_rejected','diagnostics')})
    snapshot=native/'frontend-snapshot.json'
    if snapshot.exists():
        pool=next(r['data'] for r in json.loads(snapshot.read_text(encoding='utf-8-sig'))['build']['relocations'] if r['offset']==44)
        records=[]
        for offset in range(0,len(base64.b64decode(pool['raw'])),56):
            record={}
            for field,label in [(8,'pou'),(16,'declarations'),(24,'source')]:
                blob=next(r['data'] for r in pool['relocations'] if r['offset']==offset+field)
                data=base64.b64decode(blob['raw']);record[label]=data.rstrip(b'\0').decode('cp949') if field==8 else dict(bytes=len(data),sha256=sha256(data),base64=blob['raw'])
            records.append(record)
        row['frontend_pous']=records
    if row['native']['returncode']==0 and row['native']['compile_completed'] and not row['native']['compiler_rejected']:
        files[case]={}
        for f in sorted(native.glob('pcode-*.bin')):
            raw=f.read_bytes();files[case][f.name]=len(requests)
            requests.append(dict(mode='decode',input_base64=base64.b64encode(raw+b'\0').decode()))
    rows.append(row);(directory/'comparison.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in row.items() if k!='frontend_pous'}),flush=True)
answers=native_batch(requests,out/'native-pcode-decode',dll=Q_DLL,cpu_code=209)
decoded=[]
for request,answer in zip(requests,answers,strict=True):
    assert answer['return_code']=='0x00000000' and answer['consumed_bytes']==len(base64.b64decode(request['input_base64']))-1
    projection=native_il_projection(base64.b64decode(answer['output_base64']),encoding='cp949');assert not projection['text_gaps'];decoded.append(projection['records'])
result=dict(cases=rows,files=files,decoded=decoded,scope=__doc__)
(out/'comparison.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(main_pcode={case:decoded[names['pcode-0-0.bin']] for case,names in files.items()})),flush=True)
