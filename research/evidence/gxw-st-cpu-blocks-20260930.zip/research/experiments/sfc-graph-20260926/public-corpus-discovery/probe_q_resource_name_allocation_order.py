"""Discriminate declaration, resource XML, folder and task allocation order."""
from pathlib import Path
import json, sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.compiler_tables import parse_compiler_tables
from gxw.container_writer import validate_cfb_streams,replace_stream_within_allocation
from gxw.project_metadata import current_rows,read_project_text_context
from probe_gxw_task_graph import inspect_task_graph
from replay_gxw_workspace import run,prepare,trace_prepared
from source_q_allocation import predict

P=Path(__file__).resolve().parent
OUT=P/'q-resource-name-allocation-order-v2';OUT.mkdir(exist_ok=False)
(OUT/'probe.py').write_bytes(Path(__file__).read_bytes())
(OUT/'source_q_allocation.py').write_bytes((P/'source_q_allocation.py').read_bytes())
hook=OUT/'observer.js';hook.write_bytes((P/'native-allocation-bitmap-v2/observer.js').read_bytes())
prior=json.loads((P/'real-binary-public-check-multi/case-09/comparison.json').read_text())
source=Path(prior['source']).read_bytes();streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
outer=validate_cfb_streams(source);xml=outer['projectdatalist.xml'];graph=inspect_task_graph(source);assert not graph['gaps']
resources=graph['resources'];assert len(resources)==3
xml_rows,encoding=current_rows(xml,'DSPROJECTDATA','D_Projectdata')
byname={r.fields()['szName'].text:r for r in xml_rows if r.fields()['bScrapFlag'].text=='false'}
changed=bytearray(xml);edits=[]
for resource,other in [(resources[1],resources[2]),(resources[2],resources[1])]:
 field=byname[resource['resource']].fields()['szName'];new=other['resource']
 assert len(field.text)==len(new)
 changed[field.content_start:field.content_end]=new.encode(encoding)
 edits.append(dict(old=field.text,new=new,offset=field.content_start))
variants={'resource-names-swapped':replace_stream_within_allocation(source,'projectdatalist.xml',bytes(changed))}
mutations={'resource-names-swapped':edits}
summary=[]
for case,raw in variants.items():
 directory=OUT/case;directory.mkdir();path=directory/'input.gxw';path.write_bytes(raw)
 after={s.logical_name:s.raw for s in inspect_project(raw).streams if s.logical_name};expected=dict(streams);expected[resources[1]['resource']]=streams[resources[2]['resource']];expected[resources[2]['resource']]=streams[resources[1]['resource']];assert after==expected
 outstreams=validate_cfb_streams(raw);assert all(outstreams[k]==v for k,v in outer.items() if k!='projectdatalist.xml')
 g=inspect_task_graph(raw);assert not g['gaps'];tables=parse_compiler_tables(after['CGTable.dat']);context=read_project_text_context(next(v for k,v in after.items() if k.endswith('.prj')));cp=context['text_encoding']
 def roots(resource_list):
  names=[]
  for r in resource_list:
   task=g['tasks'][r['task']];assert len(task['entries'])==1
   names.append(task['entries'][0]['program_reference'])
  return names
 candidates={'resource-xml':roots(g['resources']),
             'resource-folder':roots(sorted(g['resources'],key=lambda r:int(r['folder_group'][2]))),
             'resource-name':roots(sorted(g['resources'],key=lambda r:r['resource']))}
 active=set(candidates['resource-xml'])
 candidates['source-declaration']=[tables.pou_at(r.table_offset).name_bytes.decode(cp) for r in tables.tables[1].records if tables.pou_at(r.table_offset).name_bytes.decode(cp) in active]
 predictions={}
 def assignments(table,allocs):
  values={}
  for r in table.tables[1].records:
   pou=table.pou_at(r.table_offset)
   for c in table.components(pou):
    if c.record.table_offset in allocs:values[pou.name_bytes.hex()+':'+c.name_bytes.hex()]=allocs[c.record.table_offset]
  return values
 for hypothesis,names in candidates.items():
  predicted=predict(after,root=names[-1].encode(cp),prior_roots=[n.encode(cp) for n in names[:-1]])
  predictions[hypothesis]=dict(order=names,assignments=assignments(tables,{a['component_offset']:a['raw'] for a in predicted['allocations']}))
 before=dict(source_sha256=sha256(raw),mutation=mutations.get(case),all_physical_nested_payloads='byte-identical; resource logical names exchanged',other_outer_streams='byte-identical',predictions=predictions)
 (directory/'prediction-before-native.json').write_text(json.dumps(before,indent=2))
 for attempt in range(1,5):
  baseline_dir=directory/f'untraced-{attempt}';baseline=run(path,baseline_dir,compile=True,export_project=True,snapshot_frontend=True,project_alias='ROOTALLOC')
  ne=[json.loads(l) for l in (baseline_dir/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
  if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in ne):break
 assert baseline['returncode']==0 and baseline['compile_completed'] and not baseline['compiler_rejected']
 for attempt in range(1,5):
  traced=directory/f'trace-{attempt}';prepare(path,traced,compile=True,export_project=True,snapshot_frontend=True,project_alias='ROOTALLOC');process=trace_prepared(traced,hook)
  te=[json.loads(l) for l in (traced/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
  if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in te):break
 events=[json.loads(l) for l in (traced/'events.jsonl').read_text().splitlines()]
 def has_error(obj):
  if isinstance(obj,dict):return any(k.endswith('error') for k in obj) or str(obj.get('event','')).endswith('-error') or any(has_error(v) for v in obj.values())
  if isinstance(obj,list):return any(has_error(v) for v in obj)
  return False
 errors=[e for e in events if e.get('type')=='error' or has_error(e.get('payload'))]
 payload=[e['payload'] for e in events if e.get('type')=='send'];exact={p.name:(traced/p.name).read_bytes()==p.read_bytes() for p in baseline_dir.glob('pcode-*.bin')}
 native_tables=parse_compiler_tables(next(s.raw for s in inspect_project((baseline_dir/'native-saved.gxw').read_bytes()).streams if s.logical_name=='CGTable.dat'))
 actual=assignments(native_tables,{r.table_offset:native_tables.component_at(r.table_offset).user_info.hex() for r in native_tables.tables[2].records if any(native_tables.component_at(r.table_offset).user_info)})
 results={h:p['assignments']==actual for h,p in predictions.items()}
 compiles=[dict(compile_id=e['compile_id'],names=e['names']) for e in payload if e['event']=='sink-compile']
 pools=[e for e in payload if e['event']=='pool-allocation']
 row=dict(case=case,source=str(path),source_sha256=sha256(raw),baseline_directory=str(baseline_dir),trace_directory=str(traced),baseline=baseline,process=process,errors=errors,exact_pcode=exact,predictions=predictions,native_assignments=actual,hypotheses_match=results,compiles=compiles,pools=pools,native_resources=[e for e in ne if e.get('operation')=='Resource'])
 (directory/'comparison.json').write_text(json.dumps(row,indent=2));summary.append(row);(OUT/'comparison.json').write_text(json.dumps(summary,indent=2))
 print(json.dumps(dict(case=case,errors=errors,exact_pcode=exact,hypotheses_match=results,pool_count=len(pools))),flush=True)
 if errors or not all(exact.values()):raise ValueError('observer affected native output; preserve failure')
