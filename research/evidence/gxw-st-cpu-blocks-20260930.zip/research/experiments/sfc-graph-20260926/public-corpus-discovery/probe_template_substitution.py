from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from replay_gxw_workspace import prepare,trace_prepared
from gxw.lossless import sha256
P=Path(__file__).resolve().parent
for case in (sys.argv[1:] or ['prefixed-radix-constants','prefixed-direct-output-global-flat']):
 out=P/'builtin-template-call-controls'/case/'substitution-trace'
 prepare(out.parent/'changed.gxw',out,compile=True,export_project=True)
 result=trace_prepared(out,P/'TraceTemplateSubstitution.js',timeout=45)
 events=[json.loads(l) for l in (out/'events.jsonl').read_text().splitlines()]
 rows=[e['payload'] for e in events if e.get('payload',{}).get('event')=='template-substitution']
 result.update(rows=rows,errors=[e for e in events if e.get('type')=='error'],pcode_equal=(out/'pcode-0-0.bin').read_bytes()==(out.parent/'native/pcode-0-0.bin').read_bytes(),dll_sha256=sha256(Path('D:/GXWORKS2/Easysocket/Compiler/ECCompiler_IEC.dll').read_bytes()))
 (out/'comparison.json').write_text(json.dumps(result,indent=2))
 print(json.dumps(dict(case=case,**result)),flush=True)
