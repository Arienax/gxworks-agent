"""Portable projection for direct Q03UDV token programs in source task graphs."""
from gxw.lossless import inspect_project,sha256
from gxw.project_metadata import read_project_text_context
from probe_gxw_task_graph import inspect_task_graph
from probe_gxw_simple_fb import frame_source
from source_q_allocation import predict,groups
from source_q_label_binding import binder
from source_q_width import rewrite

def project_projection(source):
    streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
    context=read_project_text_context(next(v for k,v in streams.items() if k.endswith('.prj')))
    if context['cpu']!='Q03UDV':raise ValueError('outside Q03UDV projection')
    encoding=context['text_encoding'];graph=inspect_task_graph(source)
    if graph['gaps']:raise ValueError('task graph gaps')
    previous=[];results=[]
    for index,resource in enumerate(sorted(graph['resources'],key=lambda r:r['resource'].encode(encoding))):
        entries=graph['tasks'][resource['task']]['entries']
        if len(entries)!=1:raise ValueError('multiple task programs not handled')
        entry=entries[0];root=entry['program_reference'].encode(encoding)
        allocated=predict(streams,root=root,prior_roots=previous,program_stream=entry['source_program'])
        if allocated['calls']:raise ValueError('FB call projection requires separate profile')
        bind=binder(streams,allocated['tables'],allocated['allocations'],root,encoding)
        body=frame_source(streams[entry['source_program']]).body;parts=[];bindings=[]
        for record,g in enumerate(groups(body)):
            changed=[];count=0
            for t in g:
                if t[1]!=0xdf:changed.append(t);continue
                replacement=bind(t[2:-1]);changed.append(replacement);count+=1
                bindings.append(dict(record=record,label_hex=t[2:-1].hex(),operand=replacement.hex()))
            raw=b''.join(changed);parts.append(rewrite(raw) if count else raw)
        output=b''.join(parts)
        identities={}
        for row in allocated['tables'].tables[1].records:
            pou=allocated['tables'].pou_at(row.table_offset)
            for c in allocated['tables'].components(pou):identities[c.record.table_offset]=(pou.name_bytes.hex(),c.name_bytes.hex())
        assignments={':'.join(identities[a['component_offset']]):a['raw'] for a in allocated['allocations']}
        results.append(dict(resource_index=index,resource=resource['resource'],program=entry['program_reference'],output=output,sha256=sha256(output),records=len(parts),bindings=bindings,allocations=allocated['allocations'],assignments=assignments))
        previous.append(root)
    return results
