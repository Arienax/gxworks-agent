'use strict';
let seen=0;
send({event:'ready',pid:Process.id,arch:Process.arch});
function address(p) {
  const m=Process.findModuleByAddress(p);
  return m ? {module:m.name,rva:p.sub(m.base).toString()} : {address:p.toString()};
}
Process.attachModuleObserver({onAdded(module) {
  if(/DataManager|Compiler|Converter/i.test(module.name))send({event:'module',name:module.name,path:module.path});
  if(module.name.toLowerCase()==='dzdataabs_compiler_iec.dll')
    send({event:'resolved-compiler-imports',rows:module.enumerateImports().filter(i=>/DataManager|SICConverter/i.test(i.module||'')).map(i=>({name:i.name,import_module:i.module,target:i.address?address(i.address):null}))});
  if(module.name.toLowerCase()==='eccompiler_iec.dll') {
    const target=module.findExportByName('Compile');let logged=false;
    if(target)Interceptor.attach(target,{onEnter(){
      if(logged)return;logged=true;
      send({event:'compile-modules',rows:Process.enumerateModules().map(m=>({name:m.name,path:m.path,base:m.base.toString(),size:m.size}))});
    }});
  }
  if(module.name.toLowerCase()!=='dzdataabs_datamanager_iec.dll')return;
  const fn=module.enumerateExports().find(e=>e.name.startsWith('?GetStandardFBKind@CDZDataABS_POUDataManager@@'));
  if(!fn)throw new Error('Missing inspected standard-FB export');
  send({event:'hook',name:fn.name,rva:fn.address.sub(module.base).toString()});
  Interceptor.attach(fn.address,{
    onEnter(args) {
      this.input=null;
      try {this.input=args[0].readCString(512);} catch(error){this.error=String(error);}
      this.caller=address(this.returnAddress);
      this.stack=Thread.backtrace(this.context,Backtracer.ACCURATE).slice(0,12).map(address);
    },
    onLeave(value) {
      if(seen++>=10000)return;
      send({event:'standard-FB-kind',input:this.input,error:this.error||null,kind:value.toInt32(),caller:this.caller,stack:this.stack});
    }
  });
}});
