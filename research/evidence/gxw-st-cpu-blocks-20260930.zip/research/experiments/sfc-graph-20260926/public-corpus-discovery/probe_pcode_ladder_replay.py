"""Replay native failing ladder-conversion blocks and independently encoded controls."""
from pathlib import Path
import base64
import hashlib
import json
import os
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from native_gxw_tokens import native_batch

P=Path(__file__).resolve().parent
DLL=Path('D:/GXWORKS2/Easysocket/CodeGenerator/ECCodeGeneratorFX2.dll')
DLL_SHA='a700da129ede89869a00a5614d08b43dc64e94c240494fc753fe09104c5b9399'

def replay(requests, out):
    assert hashlib.sha256(DLL.read_bytes()).hexdigest()==DLL_SHA
    out.mkdir(exist_ok=False,parents=True)
    source=out/'LadderByteOracle.cs';source.write_bytes((P/source.name).read_bytes())
    (out/'requests.json').write_text(json.dumps(dict(dll_sha256=DLL_SHA,requests=requests,
        scope='offline owned byte buffers; no project validation or device execution'),indent=2),encoding='utf-8')
    exe=out/'LadderByteOracle.exe'
    build=subprocess.run([str(Path(os.environ['WINDIR'])/'Microsoft.NET/Framework/v4.0.30319/csc.exe'),
        '/nologo','/platform:x86','/r:System.Web.Extensions.dll','/out:'+str(exe),str(source)],
        capture_output=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
    (out/'build.stdout.bin').write_bytes(build.stdout);(out/'build.stderr.bin').write_bytes(build.stderr)
    if build.returncode:raise RuntimeError('Helper build failed; retained')
    protocol=''.join(json.dumps(dict(r,id=i))+'\n' for i,r in enumerate(requests))
    try:
        proc=subprocess.run([str(exe),str(DLL),str(out),'isolated'],input=protocol.encode('ascii'),
            capture_output=True,timeout=45,creationflags=subprocess.CREATE_NO_WINDOW)
        stdout,stderr,status=proc.stdout,proc.stderr,proc.returncode
    except subprocess.TimeoutExpired as e:
        stdout,stderr,status=e.stdout or b'',e.stderr or b'','timeout'
    (out/'native-stdout.jsonl').write_bytes(stdout);(out/'native-stderr.bin').write_bytes(stderr)
    rows=[json.loads(line) for line in stdout.splitlines()]
    (out/'process.json').write_text(json.dumps(dict(returncode=status,completed=len(rows),requested=len(requests),
        source_sha256=hashlib.sha256(source.read_bytes()).hexdigest()),indent=2),encoding='utf-8')
    if status or len(rows)!=len(requests):raise RuntimeError('Native replay incomplete; retained')
    assert all(r['guards_intact'] and r['pointers_unchanged'] for r in rows)
    return rows

def main():
    out=P/'pcode-ladder-replay';out.mkdir(exist_ok=False)
    (out/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    trace=json.loads((P/'fx3g-check-blocks-v3/summary.json').read_text())
    blocks=[r for r in trace['payloads'] if r['event']=='pcode-to-ld']
    requests=[dict(case=f'captured-{i}',cpu=521,input_base64=base64.b64encode(bytes.fromhex(r['raw_hex'])).decode(),
        expected_error=r['error'],expected_metadata=[int(r['descriptor_after'][o*2:o*2+2],16) for o in (0,1,6)]) for i,r in enumerate(blocks)]
    controls=[]
    for op in ('OUT','MOV'):
        for n in (1,2,22,23,24,25,30,48):
            lines=['LD M8000']+[f'OUT M{i}' if op=='OUT' else f'MOV K{i} D{i}' for i in range(n)]
            controls.append(dict(case=f'{op.lower()}-parallel-{n}',lines=lines,outputs=n,split=False))
            lines=[line for i in range(n) for line in ('LD M8000',f'OUT M{i}' if op=='OUT' else f'MOV K{i} D{i}')]
            controls.append(dict(case=f'{op.lower()}-separate-{n}',lines=lines,outputs=n,split=True))
    encoded=native_batch([dict(mode='encode',input_base64=base64.b64encode(('\0'.join(r['lines'])+'\0\0').encode('ascii')).decode())
                          for r in controls],out/'encoded',cpu_code=521)
    for c,e in zip(controls,encoded,strict=True):
        assert e['return_code']=='0x00000000'
        requests.append(dict(c,cpu=521,input_base64=base64.b64encode(base64.b64decode(e['output_base64'])+b'\0').decode()))
    native=replay(requests,out/'native')
    rows=[dict(request=r,native=n) for r,n in zip(requests,native,strict=True)]
    (out/'comparison.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
    print(json.dumps([dict(case=r['request']['case'],**r['native']) for r in rows]))

if __name__=='__main__':main()
