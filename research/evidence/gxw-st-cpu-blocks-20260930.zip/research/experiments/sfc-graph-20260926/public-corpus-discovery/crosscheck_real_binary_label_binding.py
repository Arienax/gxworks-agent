from pathlib import Path
import json,sys
ROOT=Path.cwd();sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.token_pou import parse_token_fragment
from gxw.token_listing import decode_token_program,TokenInstruction,TokenLabel,TokenText
from gxw.token_q import q_operand_groups
from gxw.lossless import sha256,inspect_project
P=ROOT/'research/experiments/sfc-graph-20260926/public-corpus-discovery'
def project(l):
 out=[]
 for r in l.records:
  if isinstance(r,TokenInstruction):out.append(dict(kind='instruction',op=r.mnemonic,args=list(r.args)))
  elif isinstance(r,TokenLabel):out.append(dict(kind='label',text=r.text))
  elif isinstance(r,TokenText):out.append(dict(kind=r.role,text=r.text))
  else:out.append(dict(kind='gap',reason=r.reason))
 return out
rows=[]
for folder in ['real-binary-label-binding','real-binary-label-binding-multi']:
 for case in json.loads((P/folder/'comparison.json').read_text(encoding='utf-8')):
  path=P/folder/case['case']; ev=[j['payload'] for l in (path/case['trace_directory']/'events.jsonl').read_text(encoding='utf-8').splitlines() if (j:=json.loads(l)).get('type')=='send'];encoding=case['context']['text_encoding'];streams=inspect_project(Path(case['source']).read_bytes()).streams
  for c in [e for e in ev if e['event']=='sink-compile']:
   bs=[e for e in ev if e['event']=='label-binding' and e['compile_id']==c['compile_id']]
   if not bs:continue
   ss=[s for s in c['sources'] if s['raw'].startswith('0c00000000000000ffffffff')]
   row=dict(case=case['case'],compile_id=c['compile_id'],bindings=len(bs),source_count=len(ss),errors=[b for b in bs if any('error' in k for k in b)],binding_results=sorted({b['result'] for b in bs}));rows.append(row)
   if len(ss)!=1:continue
   source=bytes.fromhex(ss[0]['raw']);tokens=parse_token_fragment(source,12,len(source)-12).tokens;labels=[t for t in tokens if len(t.raw)>1 and t.raw[1]==0xdf]
   row.update(source_sha256=sha256(source),source_name=bytes.fromhex(ss[0]['name']['hex']).decode(encoding),labels=len(labels),label_inputs_exact=len(bs)==len(labels) and all(bytes.fromhex(b['input'])==t.raw for b,t in zip(bs,labels)),input_pointer_base_count=len({int(b['input_address'],16)-t.offset for b,t in zip(bs,labels)}))
   if not row['label_inputs_exact']:continue
   row['bindings_detail']=[]
   for b,t in zip(bs,labels):
    output=bytes.fromhex(b['output']);devs=q_operand_groups(parse_token_fragment(output,0,len(output)).tokens,text_encoding=encoding)
    row['bindings_detail'].append(dict(source_offset=t.offset,input=t.raw.hex(),output=output.hex(),name=bytes.fromhex(b['lookup']['name']['hex']).decode(encoding),scope=bytes.fromhex(b['lookup']['scope']['hex']).decode(encoding),native_device=b.get('resolved_device',{}).get('latin1'),portable_output=[g[1] for g in devs],native_result=b['result']))
   byoff={t.offset:bytes.fromhex(b['output']) for b,t in zip(bs,labels)};rebuilt=b''.join(byoff.get(t.offset,t.raw) for t in tokens);listing=decode_token_program(parse_token_fragment(rebuilt,0,len(rebuilt)),text_encoding=encoding,profile='q03udv');proj=project(listing)
   row.update(projected_records=len(proj),gaps=[g.reason for g in listing.gaps],native_matches=[d['name'] for d in case['decoded'] if proj==d.get('listing',{}).get('records')],binding_device_agrees=all(b['portable_output']==[b['native_device']] for b in row['bindings_detail']))
   body=source[12:];row['original_source_body_matches']=[dict(name=s.logical_name,offset=s.raw.find(body)) for s in streams if s.raw.count(body)==1]
   row['native_detail']=[]
   for name in row['native_matches']:
    raw=(path/'untraced'/name).read_bytes();final=decode_token_program(parse_token_fragment(raw,0,len(raw)),text_encoding=encoding,profile='q03udv');changes=[dict(ordinal=i,op=a.mnemonic,before=a.step_width,after=b.step_width,before_raw=a.tokens[0].raw.hex(),after_raw=b.tokens[0].raw.hex()) for i,(a,b) in enumerate(zip(listing.records,final.records)) if isinstance(a,TokenInstruction) and isinstance(b,TokenInstruction) and a.tokens[0].raw!=b.tokens[0].raw]
    row['native_detail'].append(dict(name=name,byte_identical=rebuilt==raw,source_substituted_bytes=len(rebuilt),final_bytes=len(raw),changed_headers=changes,operand_tokens_byte_identical=all([t.raw for o in a.operands for t in o.tokens]==[t.raw for o in b.operands for t in o.tokens] for a,b in zip(listing.records,final.records) if isinstance(a,TokenInstruction) and isinstance(b,TokenInstruction))))
   print(json.dumps({k:v for k,v in row.items() if k not in ['bindings_detail','native_detail']}))
(P/'real-binary-label-binding/source-crosscheck.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
