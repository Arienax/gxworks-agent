"""Test name-driven standard lowering against unchanged library FB source."""
from pathlib import Path
import sys,json,base64
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from gxw.lossless import inspect_project,sha256
from gxw.declarations import parse_declarations,edit_declarations,serialize_declarations
from probe_gxw_library_archive import decode_library_archive,encode_library_literals,frame_library_text
from probe_gxw_library_sources import snapshot_library_pous
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import run,prepare,trace_prepared
from probe_gxw_compiled_references import inspect
P=Path(__file__).resolve().parent
cases=[('CTU',P/'ST-standard-counter-controls/CTU','LibraryProbe'),('TON_E',P/'ST-standard-timer-controls/TON_E_true','TimerProbe')]
for kind,baseline,instance in cases:
 out=P/'library-fb-alias-controls'/kind;out.mkdir(parents=True,exist_ok=False)
 source=(baseline/'changed.gxw').read_bytes();before={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
 lib='IECFunction.lif';raw=before[lib];plain=decode_library_archive(raw[20:]).decoded
 selected=[d for d in frame_library_text(plain)['definitions'] if d['name']==kind and (d['sections'] is None or 'Q03UDV' in d['sections'])]
 assert len(selected)==1
 alias='LIB_ALIAS_'+kind
 definition=selected[0];header=b'FUNCTION_BLOCK '+kind.encode();assert definition['raw'].count(header)==1
 alias_body=definition['raw'].replace(header,b'FUNCTION_BLOCK '+alias.encode(),1)
 appended=b'\r\n(*$SECTION:Q03UDV*)\r\n'+alias_body
 library=raw[:20]+encode_library_literals(plain+appended)
 labels='POU_01.Labels.lh';declarations=parse_declarations(before[labels],logical_name=labels)
 replacements={lib:library,labels:serialize_declarations(edit_declarations(declarations,upserts=[dict(name=instance,data_type=alias,kind='function_block')]))}
 changed=source;receipts=[]
 for name,body in replacements.items():changed,receipt=patch_raw(changed,name,before[name],body);receipts.append(receipt)
 after={s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}
 assert all(after[n]==b for n,b in before.items() if n not in replacements)
 (out/'changed.gxw').write_bytes(changed)
 (out/'mutation.json').write_text(json.dumps(dict(kind=kind,alias=alias,source_sha256=sha256(source),changed_sha256=sha256(changed),original_library_prefix='byte-identical after decompression',alias_definition='only FUNCTION_BLOCK name differs',unrelated_payloads='byte-identical',appended_base64=base64.b64encode(appended).decode(),receipts=receipts),indent=2))
 result=run(out/'changed.gxw',out/'native',compile=True,export_project=True,snapshot_frontend=True)
 print(json.dumps(dict(kind=kind,native=result)),flush=True)
 comparison={}
 if (out/'native/frontend-snapshot.json').exists():
  native=snapshot_library_pous(json.loads((out/'native/frontend-snapshot.json').read_text(encoding='utf-8-sig')))
  original=next(x for x in native if (x['library'],x['name'])==('@IEC',kind));copy=next(x for x in native if (x['library'],x['name'])==('@IEC',alias))
  comparison['native_program_buffers_exact']=original['program_raw_base64']==copy['program_raw_base64']
  comparison['native_declaration_buffers_exact']=original['declaration_raw_base64']==copy['declaration_raw_base64']
 if result.get('native_export'):
  comparison['pcode_equal_to_baseline']=all((baseline/'native'/f).read_bytes()==(out/'native'/f).read_bytes() for f in result['outputs'])
  comparison['reader']=inspect(out/'native',out/'correlation')['summary']
  prepare(out/'changed.gxw',out/'trace',compile=True,export_project=True)
  comparison['trace']=trace_prepared(out/'trace',ROOT/'research/native/CompilerTrace.js',timeout=45)
 (out/'comparison.json').write_text(json.dumps(comparison,indent=2));print(json.dumps(dict(kind=kind,comparison=comparison)),flush=True)
