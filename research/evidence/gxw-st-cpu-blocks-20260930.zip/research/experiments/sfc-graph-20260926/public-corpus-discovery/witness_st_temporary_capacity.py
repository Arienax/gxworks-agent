"""Finite arithmetic witness for capacity probes and their guarded controls."""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from gxw.project_metadata import read_project_text_context
from probe_minimal_conditional_port_writes import streams,save
from source_q_direct_declarations import DirectDeclarations
from source_q_st_calls import predict
from witness_st_conditional_transfers import decode,evaluate
P=Path(__file__).resolve().parent


def main():
    groups=['st-temporary-capacity-holdouts-20260930','st-temporary-capacity-rung-controls-20260930','st-temporary-capacity-forward-20260930']
    rows=[]
    for group in groups:
        listings={r['case']:r for r in json.loads((P/group/'native-listings.json').read_text())}
        for case in json.loads((P/group/'comparison.json').read_text()):
            if case['case'].startswith('plain-'):continue
            n=Path(case['native_directory']);source=(n/'input.gxw').read_bytes();raw=(n/'pcode-0-0.bin').read_bytes()
            records=decode(raw)
            assert listings[case['case']]['return_code']=='0x00000000'
            assert [{k:v for k,v in r.items() if k not in ('offset','raw')} for r in records]==listings[case['case']]['records']
            assert predict(source)['output']==raw
            content={k:v for k,v in streams(source).items() if k!='CGTable.dat'}
            context=read_project_text_context(next(v for k,v in content.items() if k.endswith('.prj')))
            d=DirectDeclarations(content,context['text_encoding'],local_fb_definitions=('Wrapper',),allow_string_arrays=True);d.add_owner('POU_01')
            result=d.bound['POU_01']['prober0'];binding=dict(address=result['family']+str(result['number']),type='INT')
            witness=evaluate(records,{'arithmetic':binding})
            # Each source initializes A,B,C,D to 1,2,3,4. The final observed
            # expression is (A+B)-(C+D); guard index is initialized to zero.
            assert witness['observations']['arithmetic']==(1+2)-(3+4)
            rows.append(dict(group=group,case=case['case'],input_sha256=sha256(source),pcode_sha256=sha256(raw),
                native_core_decode_equal=True,current_model_bytes_equal=True,binding=binding,
                check_completed=case['check'] is not None,original_prediction_identical=case['prediction_identical'],**witness))
    out=P/groups[-1]
    save(out/'offline-capacity-witnesses.json',dict(scope='Initialized finite INT/ASCII word-memory evaluation; all ten arithmetic results are -4. It checks these observations across unguarded and runtime-true guarded controls, not general ST equivalence or physical PLC behavior.',cases=rows))
    (out/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    print(json.dumps(dict(cases=len(rows),all_arithmetic_results=-4)))


if __name__=='__main__':main()
