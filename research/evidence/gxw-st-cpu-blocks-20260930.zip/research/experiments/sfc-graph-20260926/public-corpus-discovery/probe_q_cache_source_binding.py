"""Contrast imported compiler cache with fresh compile after one source edit."""
from pathlib import Path
import json,os,subprocess,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_simple_fb import frame_source
from replay_gxw_workspace import prepare
P=Path(__file__).resolve().parent
out=P/'q-cache-source-binding';out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
source=P/'q-global-fb-calls/valid-global-call/native/native-saved.gxw'
original=source.read_bytes();streams={s.logical_name:s.raw for s in inspect_project(original).streams if s.logical_name}
logical='SCPI.Program.pou';raw=streams[logical];framed=frame_source(raw)
assert framed.body.count(b'iEn')==1
body=framed.body.replace(b'iEn',b'iXn');new=raw[:framed.body_offset]+body+raw[framed.body_end:]
changed,receipt=patch_raw(original,logical,raw,new)
assert {s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}==dict(streams,**{logical:new})
(out/'baseline.gxw').write_bytes(original);(out/'undefined-label.gxw').write_bytes(changed)
(out/'mutation.json').write_text(json.dumps(dict(source=str(source),source_sha256=sha256(original),changed_sha256=sha256(changed),
    logical=logical,edit='iEn -> iXn (undeclared)',receipt=receipt,unrelated_payloads='byte-identical'),indent=2))
rows=[]
for case,filename,fresh in [('baseline-cached','baseline.gxw',False),('changed-cached','undefined-label.gxw',False),
                            ('baseline-fresh','baseline.gxw',True),('changed-fresh','undefined-label.gxw',True)]:
    target=out/case;exe=prepare(out/filename,target,compile=True,export_project=True,project_alias='QCACHEBIND')
    plan=json.loads((target/'plan.json').read_text());plan.update(reset_compiler=fresh,fresh_compiler_state=fresh)
    (target/'plan.json').write_text(json.dumps(plan,indent=2))
    code=(target/'WorkspaceReplayOracle.cs').read_text()
    old='            if(!Convert.ToBoolean(plan["compile"]))return;'
    assert code.count(old)==1
    code=code.replace(old,'            CompileStatusSnapshot(workspace,id,"before-build");\n'+old)
    old='            bool compilerRejected=WaitReports(compiler,changeSfc?168:40,"Progress");'
    assert code.count(old)==1
    code=code.replace(old,old+'\n            CompileStatusSnapshot(workspace,id,"after-build");')
    (target/'WorkspaceReplayOracle.cs').write_text(code)
    (target/'NativeCompileStatusSnapshot.cs').write_bytes((P/'NativeCompileStatusSnapshot.cs').read_bytes())
    csc=Path(os.environ['WINDIR'])/'Microsoft.NET/Framework/v4.0.30319/csc.exe'
    build=subprocess.run([str(csc),'/nologo','/platform:x86','/r:System.Web.Extensions.dll','/r:System.Windows.Forms.dll','/out:'+str(exe),
        *[str(target/n) for n in ['WorkspaceReplayOracle.cs','NativeFrontendSnapshot.cs','NativeSfcGraphOracle.cs','NativeWorkspaceCopyOracle.cs','NativeCompileStatusSnapshot.cs']]],
        capture_output=True,timeout=20,creationflags=subprocess.CREATE_NO_WINDOW)
    (target/'status-build.stdout.bin').write_bytes(build.stdout);(target/'status-build.stderr.bin').write_bytes(build.stderr);build.check_returncode()
    request=json.loads((target/'request.json').read_text());request.update(actual_helper_sha256=sha256((target/'WorkspaceReplayOracle.cs').read_bytes()),status_snapshot_sha256=sha256((target/'NativeCompileStatusSnapshot.cs').read_bytes()))
    (target/'request.json').write_text(json.dumps(request,indent=2))
    process=subprocess.run([str(exe),str(target/'plan.json')],cwd=target,capture_output=True,timeout=50,creationflags=subprocess.CREATE_NO_WINDOW)
    (target/'process.stdout.bin').write_bytes(process.stdout);(target/'process.stderr.bin').write_bytes(process.stderr)
    events=[json.loads(s) for s in (target/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    snapshots={};phase=None
    for e in events:
        if e['operation']=='CompileStatusSnapshotBegin':phase=e['phase'];snapshots[phase]=[]
        elif e['operation'] in ('CompileStatusSnapshotNode','CompileAllAfterSnapshot'):snapshots[phase].append(e)
    diagnostics={json.dumps({k:v for k,v in r.items() if k!='raw_base64'},sort_keys=True) for e in events for r in e.get('reports',[]) if r['kind'] in (2,3)}
    row=dict(case=case,input_sha256=sha256((out/filename).read_bytes()),fresh_backend=fresh,returncode=process.returncode,
        compile_completed=any(e['operation']=='Progress' and e.get('percent')==100 for e in events),
        diagnostics=[json.loads(r) for r in sorted(diagnostics)],snapshots=snapshots,
        outputs={f.name:dict(bytes=f.stat().st_size,sha256=sha256(f.read_bytes())) for f in target.glob('pcode-*.bin')},
        exported=(target/'native-saved.gxw').exists(),last_event=events[-1])
    rows.append(row);(target/'comparison.json').write_text(json.dumps(row,indent=2));print(json.dumps(row),flush=True)
(out/'comparison.json').write_text(json.dumps(dict(cases=rows),indent=2))
