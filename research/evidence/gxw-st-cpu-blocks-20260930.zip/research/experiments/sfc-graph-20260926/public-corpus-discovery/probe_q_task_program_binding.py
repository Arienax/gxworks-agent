"""Distinguish task membership from a present but unused Q source POU.

Only the counted program-reference string in one observed .tsk is replaced;
the task's logical name and remaining bytes stay unchanged. Owned offline
copies are compiled, and full native PCode is independently decoded.
"""
from pathlib import Path
import base64, json, struct, sys

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'research')]
from gxw.lossless import inspect_project, sha256
from gxw.container_writer import validate_cfb_streams
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import run
from native_gxw_tokens import native_batch, native_il_projection, Q_DLL

P = Path(__file__).resolve().parent
out = P/'q-task-program-binding'; out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
base = P/'q-source-constant-edits'
plans = [('original-target', base/'baseline-0/source.gxw', '기본동작'),
         ('changed-target', base/'comparison/changed.gxw', '기본동작'),
         ('missing-target', base/'baseline-0/source.gxw', 'MISSING')]
results=[]
for case,path,target_name in plans:
    source=path.read_bytes(); assert not validate_cfb_streams(source).get('Project.gd2')
    streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
    task='응용동작1.tsk'; old=streams[task]
    assert old[76:88]==bytes.fromhex('1f0000000000000001000000')
    old_name='응용동작1'; encoded=(old_name+'\0').encode('utf-16le')
    assert struct.unpack_from('<I',old,88)[0]==len(encoded)//2 and old[92:92+len(encoded)]==encoded
    name=(target_name+'\0').encode('utf-16le')
    new=old[:88]+struct.pack('<I',len(name)//2)+name+old[92+len(encoded):]
    changed,receipt=patch_raw(source,task,old,new)
    after={s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}
    assert after==dict(streams,**{task:new})
    directory=out/case;directory.mkdir();input_path=directory/'changed.gxw';input_path.write_bytes(changed)
    mutation=dict(source_sha256=sha256(source),changed_sha256=sha256(changed),task=task,
                  counted_string_offset=88,old_reference=old_name,new_reference=target_name,
                  changed_task_hex=new.hex(),original_task_hex=old.hex(),container=receipt,
                  source_pou_payloads='byte-identical to input')
    (directory/'mutation.json').write_text(json.dumps(mutation,indent=2),encoding='utf-8')
    for attempt in range(1,9):
        native=directory/('native' if attempt==1 else 'native-v'+str(attempt))
        result=run(input_path,native,compile=True,export_project=True,project_alias='QTASKBIND')
        events=[json.loads(s) for s in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
        if (native/'pcode-0-0.bin').exists() or not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
    row=dict(case=case,target=target_name,native_directory=str(native.relative_to(out)),
             native={k:result[k] for k in ('returncode','open_succeeded','compile_completed','compiler_rejected','diagnostics')})
    results.append(row)
    (directory/'comparison.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
    print(json.dumps(row),flush=True)

requests=[];files={}
for row in results:
    if not row['native']['compile_completed'] or row['native']['compiler_rejected']:continue
    files[row['case']]={}
    for f in sorted((out/row['native_directory']).glob('pcode-*.bin')):
        raw=f.read_bytes();files[row['case']][f.name]=len(requests)
        requests.append(dict(mode='decode',input_base64=base64.b64encode(raw+b'\0').decode()))
answers=native_batch(requests,out/'native-pcode-decode',dll=Q_DLL,cpu_code=209)
decoded=[]
for request,answer in zip(requests,answers,strict=True):
    assert answer['return_code']=='0x00000000' and answer['consumed_bytes']==len(base64.b64decode(request['input_base64']))-1
    records=native_il_projection(base64.b64decode(answer['output_base64']),encoding='cp949')
    assert not records['text_gaps'];decoded.append(records['records'])
diff=[]
a,b=files['original-target'],files['changed-target'];assert a.keys()==b.keys()
for name in a:
    x,y=decoded[a[name]],decoded[b[name]];assert len(x)==len(y)
    diff += [dict(file=name,record=i,before=u,after=v) for i,(u,v) in enumerate(zip(x,y,strict=True)) if u!=v]
report=dict(cases=results,files=files,decoded=decoded,changes=diff,scope=__doc__)
with (out/'comparison.json').open('x',encoding='utf-8') as f:json.dump(report,f,indent=2,ensure_ascii=False)
print(json.dumps(dict(changes=diff)),flush=True)
