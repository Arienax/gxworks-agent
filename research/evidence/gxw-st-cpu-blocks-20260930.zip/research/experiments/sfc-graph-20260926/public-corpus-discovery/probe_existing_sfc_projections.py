"""Apply real-source SFC expansion to earlier native topology experiments."""
from pathlib import Path
import json
import sys
ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'research')]
from gxw.lossless import inspect_project, sha256
from gxw.project_metadata import read_project_text_context
from probe_gxw_sfc_sources import framing
from probe_gxw_sfc_graph import compiled_graph
from source_fx_sfc_projection import project_projection, expand_block, groups

P = Path(__file__).resolve().parent
OUT = P/'existing-sfc-projections'


def main():
    OUT.mkdir(exist_ok=False)
    for f in [Path(__file__), P/'source_fx_sfc_projection.py']:
        (OUT/f.name).write_bytes(f.read_bytes())
    base = P.parent
    paths = list(base.glob('*.gxw'))
    for directory in base.iterdir():
        if not directory.is_dir() or directory == P:
            continue
        paths += list(directory.glob('*.gxw'))
        paths += list((directory/'native').glob('*.gxw'))
    by_hash = {}
    for path in sorted(paths):
        data = path.read_bytes(); key = sha256(data)
        if key in by_hash:
            by_hash[key]['source_paths'].append(str(path))
            continue
        image = inspect_project(data)
        streams = {s.logical_name: s.raw for s in image.streams if s.logical_name}
        sources = {n: b for n, b in streams.items() if n.endswith('.pou') and b[54:58] == b'\xf0\0\0\0'}
        if not sources:
            continue
        context = read_project_text_context(next(b for n, b in streams.items() if n.endswith('.prj')))
        row = dict(source_sha256=key, source_paths=[str(path)], context=context, blocks=[])
        by_hash[key] = row
        for name, raw in sources.items():
            block = dict(name=name, sha256=sha256(raw))
            row['blocks'].append(block)
            try:
                frame = framing(raw); graph = compiled_graph(raw)
                block.update(graph_opcodes=[g[0].hex() for g in groups(raw[graph['code_offset']:graph['code_offset'] + graph['code_size']])],
                    actions=[dict(number=a['number'], registrations=a['registrations']) for a in frame['actions']],
                    children=len(frame['children']), cache_bytes=graph['cache_size'])
                expanded, detail = expand_block(raw)
                block['expanded_sha256'] = sha256(expanded)
            except ValueError as exc:
                block['gap'] = str(exc)
        try:
            candidate, evidence = project_projection(data)
            filename = key+'.bin'; (OUT/filename).write_bytes(candidate)
            row.update(candidate=filename, candidate_sha256=sha256(candidate), projection=evidence)
        except ValueError as exc:
            row['projection_gap'] = str(exc)
    rows = list(by_hash.values())
    (OUT/'predictions-before-comparison.json').write_text(json.dumps(rows, indent=2), encoding='utf-8')
    for row in rows:
        row['native_comparisons'] = []
        for source in row['source_paths']:
            path = Path(source)
            # Only compare outputs adjacent to the actual imported or saved
            # native project. Other standalone fixtures need a separate run.
            if path.name not in ('input.gxw', 'native-saved.gxw'):
                continue
            target = path.parent/'pcode-0-0.bin'
            if not target.exists():
                continue
            raw = target.read_bytes()
            events_path = path.parent/'native-events.jsonl'
            events = [json.loads(l) for l in events_path.read_text(encoding='utf-8-sig').splitlines()] if events_path.exists() else []
            diagnostics = [dict(phase=e.get('operation'), report=r) for e in events for r in e.get('reports', []) if r.get('kind') == 2]
            row['native_comparisons'].append(dict(path=str(target), bytes=len(raw), sha256=sha256(raw),
                identical=raw == (OUT/row['candidate']).read_bytes() if 'candidate' in row else None,
                diagnostics=diagnostics))
    (OUT/'comparison.json').write_text(json.dumps(rows, indent=2), encoding='utf-8')
    print(json.dumps([dict(paths=[str(Path(p).relative_to(base)) for p in row['source_paths']], cpu=row['context']['cpu'],
        gap=row.get('projection_gap'), blocks=[dict(name=b['name'], gap=b.get('gap'), opcodes=sorted(set(b.get('graph_opcodes', [])))) for b in row['blocks']],
        native=[dict(identical=c['identical'], diagnostics=len(c['diagnostics'])) for c in row['native_comparisons']]) for row in rows], ensure_ascii=True), flush=True)


if __name__ == '__main__':
    main()
