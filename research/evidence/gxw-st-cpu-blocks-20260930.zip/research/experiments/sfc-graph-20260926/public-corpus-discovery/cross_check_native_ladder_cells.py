"""Check native cell/source-step bindings against original token instructions.

Comparisons use raw predicted payloads, not a second textual roundtrip.
Connection operators absent from the grid remain on the original byte stream.
"""
from pathlib import Path
import collections
import json
import struct
import sys

ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.token_pou import parse_token_fragment
from gxw.token_listing import decode_token_program,TokenInstruction,TokenLabel,TokenText

P=Path(__file__).resolve().parent

def native_objects(cells,tokens,metadata):
    width,height,size=metadata
    if width!=23 or not 0<=height<=24 or size!=8 or len(cells)!=0x2288:
        raise ValueError('unobserved native cell envelope')
    records=[]
    for i in range(width*height+1):
        raw=cells[i*8:i*8+8]
        flags,kind,offset,index,step=struct.unpack('<BBHHH',raw)
        if any(raw) and index!=i:raise ValueError('unobserved native index')
        records.append(dict(index=i,flags=flags,kind=kind,offset=offset,step=step,raw_hex=raw.hex()))
    objects=[]
    for i,r in enumerate(records):
        kind=r['kind']
        if kind in (0,0x80,0x22,0x23,0x4a,0x4b):continue
        group=[r]
        if kind==0x21:
            group=records[i:i+3]
            if [v['kind'] for v in group]!=[0x21,0x22,0x23]:raise ValueError('unobserved comparison group')
        elif kind==0x49:
            j=i+1
            while j<len(records) and records[j]['kind']==0x4a:j+=1
            if j==len(records) or records[j]['kind']!=0x4b:raise ValueError('unterminated application cells')
            group=records[i:j+1]
        spans=[]
        if kind not in (0x14,0x18,0x1c):
            end_index=i+len(group)
            if end_index>=len(records):raise ValueError('missing native token end cell')
            ends=[v['offset'] for v in group[1:]]+[records[end_index]['offset']]
            for v,end in zip(group,ends):
                start=v['offset']
                if not 0<=start<=end<=len(tokens):raise ValueError('unbounded native token span')
                spans.append(tokens[start:end])
        objects.append(dict(r,cell_indexes=[v['index'] for v in group],payload_hex=b''.join(spans).hex(),
            spans=[dict(offset=v['offset'],raw_hex=s.hex()) for v,s in zip(group,spans)]))
    return objects

CONTACTS={4:('LD','AND','OR'),8:('LDI','ANI','ORI'),12:('LDP','ANDP','ORP'),16:('LDF','ANDF','ORF')}
SYSTEM={0x14:'INV',0x18:'MEP',0x1c:'MEF'}

def compare(input_bytes,cells,tokens,metadata):
    assert input_bytes[-1:]==b'\0'
    raw=input_bytes[:-1]
    listing=decode_token_program(parse_token_fragment(raw,0,len(raw)),profile='fx3g',text_encoding='cp1252')
    if listing.gaps:raise ValueError('original token listing has lexical gaps')
    objects=native_objects(cells,tokens,metadata)
    first=next((r for r in listing.records if isinstance(r,TokenInstruction)),None)
    base=first.step if first else 0
    steps={r.step:r for r in listing.records if isinstance(r,TokenInstruction)}
    results=[]
    for obj in objects:
        kind=obj['kind'];target=steps.get(base+obj['step']);expected=None;reason=None
        if kind==0x84:
            labels=[r for r in listing.records if isinstance(r,TokenLabel)]
            if len(labels)==1:expected=b''.join(t.raw for t in labels[0].tokens[1:])
            else:reason='label count not one'
        elif target is None:reason='no instruction at native step'
        elif kind in CONTACTS:
            if target.mnemonic not in CONTACTS[kind]:reason='contact family differs'
            else:expected=b''.join(t.raw for t in target.tokens[1:])
        elif kind in SYSTEM:
            if target.mnemonic!=SYSTEM[kind]:reason='system gate differs'
            else:expected=b''
        elif kind==0x40:
            if target.mnemonic!='OUT' or len(target.operands) not in (1,2):reason='coil instruction differs'
            else:expected=b''.join(t.raw for t in target.tokens[1:])
        elif kind==0x21:
            header=target.tokens[0].raw
            if len(header)!=6 or header[1]!=0x40 or header[4] not in (0x10,0x11,0x12):reason='unobserved comparison header'
            else:expected=bytes([5])+header[1:4]+bytes([5])+b''.join(t.raw for t in target.tokens[1:])
        elif kind in (0x48,0x49):expected=b''.join(t.raw for t in target.tokens)
        else:reason='unobserved head kind'
        actual=bytes.fromhex(obj['payload_hex'])
        results.append(dict(cell=obj,source_step=base+obj['step'],source_instruction=None if target is None else
            dict(op=target.mnemonic,args=target.args,raw_hex=b''.join(t.raw for t in target.tokens).hex()),
            status='unsupported' if reason else 'equal' if expected==actual else 'different',reason=reason,
            expected_payload_hex=None if expected is None else expected.hex()))
    return dict(prefix_steps=base,objects=results)

def main():
    out=P/'native-ladder-cell-bindings-v2';out.mkdir(exist_ok=False)
    (out/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    parent=P/'fx3g-ladder-call-corpus';calls=json.loads((parent/'calls.json').read_text());native=parent/'reusable-oracle'
    rows=[]
    for r in calls:
        if r['return_code']:continue
        i=r['id'];raw=bytes.fromhex(r['input_hex'])
        try:
            comparison=compare(raw,(native/f'{i:04}.cells.bin').read_bytes(),(native/f'{i:04}.tokens.bin').read_bytes(),r['metadata'])
            row=dict(id=i,**comparison)
        except ValueError as e:row=dict(id=i,status='unsupported',reason=str(e))
        rows.append(row)
    (out/'comparison.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
    statuses=collections.Counter(o['status'] for r in rows for o in r.get('objects',[]))
    gaps=[dict(id=r['id'],**o) for r in rows for o in r.get('objects',[]) if o['status']!='equal']
    print(json.dumps(dict(blocks=len(rows),objects=sum(statuses.values()),statuses=dict(statuses),
        unsupported_blocks=[r for r in rows if 'reason' in r],gaps=gaps[:20]),ensure_ascii=True))

if __name__=='__main__':main()
