// Owned helper only, read-only ECCompiler_IEC 15.50 instruction sink.
'use strict';
const contexts = new Map();
let sequence = 0, nextCompile = 0;
function hex(p, n) { if(n===0)return ''; if(p.isNull())throw new Error('null buffer with nonzero length'); return Array.from(new Uint8Array(p.readByteArray(n)), b => b.toString(16).padStart(2, '0')).join(''); }
function string(p, bound) {
  const bytes=[];
  for(let i=0;i<bound;i++) {const b=p.add(i).readU8();if(!b)return {hex:bytes.map(x=>x.toString(16).padStart(2,'0')).join(''),latin1:String.fromCharCode(...bytes),terminated:true};bytes.push(b);}
  return {hex:bytes.map(x=>x.toString(16).padStart(2,'0')).join(''),terminated:false};
}
function loc(p){const m=Process.findModuleByAddress(p);return m?{module:m.name,rva:p.sub(m.base).toString()}:null;}
function emit(e){if(sequence<100000)send({...e,sequence:++sequence});else if(sequence===100000){sequence++;send({event:'sink-limit-error'});}}
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='eccompiler_iec.dll')return;
 try {
  if(Process.arch!=='ia32')throw new Error('x86 required');
  const b='6aff6806040f1064a100000000506489'.match(/../g).map(x=>parseInt(x,16)),v=m.base.add(0xf0406).toUInt32();
  for(let i=0;i<4;i++)b[3+i]=(v>>>(8*i))&255;
  if(hex(m.base.add(0xaed60),16)!==b.map(x=>x.toString(16).padStart(2,'0')).join(''))throw new Error('record-sink guard');
  emit({event:'sink-module',path:m.path,base:m.base.toString()});
  Interceptor.attach(m.findExportByName('Compile'),{
   onEnter(a){
    this.prior=contexts.get(this.threadId);this.id=++nextCompile;
    const count=a[1].toInt32(),names=[],sources=[];
    try {
     if(count<0||count>4096)throw new Error('compile count bound');
     for(let i=0;i<count;i++){
      const d=a[2].add(i*28),n=d.readS32(),name=string(d.add(8).readPointer(),1024);names.push(name);
      if(n<0||n>0x200000)throw new Error('source length bound');
      sources.push({index:i,name,descriptor:hex(d,28),raw:hex(d.add(4).readPointer(),n)});
     }
     contexts.set(this.threadId,{compile_id:this.id,names});
     const symbolsSize=a[3].toInt32();
     if(symbolsSize<0||symbolsSize>0x1000000)throw new Error('symbol length bound');
     emit({event:'sink-compile',compile_id:this.id,names,sources,symbolic_data:hex(a[4],symbolsSize)});
    }catch(e){contexts.set(this.threadId,null);emit({event:'sink-compile-error',compile_id:this.id,error:String(e)});}
   },onLeave(r){emit({event:'sink-compile-result',compile_id:this.id,result:r.toInt32()});contexts.set(this.threadId,this.prior);}
  });
  Interceptor.attach(m.base.add(0xaed60),{onEnter(a){
   const context=contexts.get(this.threadId);if(!context)return;
   try {
    const r=a[0],count=r.add(12).readU8();if(count>9)throw new Error('operand count bound');
    const operands=[];
    for(let i=0;i<count;i++){
     const p=r.add(13+i*25),operand={raw:hex(p,25)};
     if((p.add(24).readU8()&1)&&!p.readPointer().isNull())operand.string=string(p.readPointer(),4096);
     operands.push(operand);
    }
    emit({event:'sink-record',compile_id:context.compile_id,name:string(r.readPointer(),128),opcode:r.add(4).readS32(),source:r.add(8).readS32(),count,mode:a[1].toInt32(),operands,raw:hex(r,238),caller:loc(this.returnAddress)});
   }catch(e){emit({event:'sink-record-error',compile_id:context.compile_id,error:String(e)});}
  }});
 }catch(e){emit({event:'sink-guard-error',error:String(e)});}
}});

Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='eccodegenerator2.dll')return;
 emit({event:'codegen-module',path:m.path});
 for(const name of ['ChangePToILcode','ChangeILToPcode','ChangePToILcodeDev','ChangePToDevcode','ChangeDevToPcode','ChangePToEdevcode','ChangeEdevToPcode','ChangePToMcode']){
  const target=m.findExportByName(name);if(!target)continue;
  Interceptor.attach(target,{onEnter(a){const c=contexts.get(this.threadId);if(!c)return;this.row={event:'codegen-call',name,compile_id:c.compile_id,args:Array.from({length:6},(_,i)=>a[i].toString()),caller:loc(this.returnAddress),stack:Thread.backtrace(this.context,Backtracer.ACCURATE).slice(0,12).map(loc)};try{
   if(name==='ChangeILToPcode'){const n=a[2].toInt32();if(n>=0&&n<=0x100000){this.row.input=hex(a[1],n);this.out=a[5];this.length=a[6];}}
   if(name==='ChangePToILcode'){const n=a[2].readS32();if(n>=0&&n<=0x100000){this.row.input=hex(a[1],n);this.out=a[3];this.length=a[4];}}
  }catch(e){this.row.observation_error=String(e);}emit(this.row);},onLeave(r){if(!this.row)return;try{let output=null,n=null;if(this.length){n=this.length.readS32();if(r.toInt32()===0&&n>=0&&n<=0x100000&&!this.out.isNull())output=hex(this.out,n);}emit({event:'codegen-result',name,compile_id:this.row.compile_id,result:r.toInt32(),length:n,output});}catch(e){emit({event:'codegen-observation-error',name,error:String(e)});}}});
 }
}});

const bindingContexts = new Map(); let bindingId=0;
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='eccompiler_iec.dll')return;
 try{
  if(hex(m.base.add(0xe4350),8)!=='558bec83e4f86aff')throw new Error('label binding entry guard');
  Interceptor.attach(m.base.add(0xe4350),{
   onEnter(a){const c=contexts.get(this.threadId);if(!c)return;
    this.prior=bindingContexts.get(this.threadId);this.id=++bindingId;
    this.row={event:'label-binding',binding_id:this.id,compile_id:c.compile_id,mode:a[1].toInt32(),caller:loc(this.returnAddress)};
    bindingContexts.set(this.threadId,this.row);
    try{this.row.input_address=a[0].toString();this.row.input=hex(a[0],a[0].readU8());this.output=a[2];this.length=a[3];}
    catch(e){this.row.observation_error=String(e);}
   },onLeave(r){if(!this.row)return;
    try{this.row.result=r.toInt32();this.row.length=this.length.readS32();
     if(r.toInt32()===0&&this.row.length>=0&&this.row.length<=4096)this.row.output=hex(this.output,this.row.length);
    }catch(e){this.row.observation_error=String(e);}
    emit(this.row);bindingContexts.set(this.threadId,this.prior);
   }
  });
  Interceptor.attach(m.base.add(0x5f7e0),{onEnter(a){const b=bindingContexts.get(this.threadId);if(!b)return;
   try{b.lookup={name:string(a[0],4096),scope:string(a[1],4096),mode:a[2].toInt32()};}catch(e){b.lookup_error=String(e);}
  }});
  Interceptor.attach(m.base.add(0xe47bf),{onEnter(a){const b=bindingContexts.get(this.threadId);if(!b)return;
   try{const obj=this.context.esp.add(0x18).readPointer();b.resolved_device=obj.isNull()?null:string(obj.add(4).readPointer(),4096);}catch(e){b.device_error=String(e);}
  }});
 }catch(e){emit({event:'binding-guard-error',error:String(e)});}
}});

Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='eccompiler_iec.dll')return;
 if(hex(m.base.add(0xe2600),8)!=='558bec83e4f86aff'){emit({event:'width-guard-error'});return;}
 Interceptor.attach(m.base.add(0xe2600),{onEnter(a){const c=contexts.get(this.threadId);if(!c)return;
  this.row={event:'binary-step-adjust',compile_id:c.compile_id};try{
   this.p=a[0];this.n=a[1];const n=this.n.readS32();if(n<0||n>4096)throw new Error('width length bound');
   this.row.before=hex(this.p,n);const o=this.context.ecx.add(0x4c).readPointer();this.row.backend=loc(o.readPointer());this.row.callee=loc(o.readPointer().add(0x28).readPointer());
  }catch(e){this.row.observation_error=String(e);}
 },onLeave(r){if(!this.row)return;try{this.row.result=r.toInt32();const n=this.n.readS32();if(n<0||n>4096)throw new Error('width output length bound');this.row.after=hex(this.p,n);}catch(e){this.row.observation_error=String(e);}emit(this.row);}});
}});

Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='eccodegenerator2.dll')return;
 Interceptor.attach(m.findExportByName('CheckInstructionCode2'),{onEnter(a){const c=contexts.get(this.threadId);if(!c)return;
  this.row={event:'check-instruction-code2',compile_id:c.compile_id,args:Array.from({length:5},(_,i)=>a[i].toString())};try{
   this.b=a[1];this.status=a[4];this.row.buffer_before=hex(this.b,24);this.row.mode=a[2].toInt32();
   const n=this.b.add(4).readS32();if(n<0||n>4096)throw new Error('check input bound');this.p=this.b.add(8).readPointer();this.row.before=hex(this.p,n);
   if(!a[3].isNull()){const size=a[3].readU16();if(size<6||size>4096)throw new Error('check device context bound');this.row.device_context=hex(a[3],size);}
   this.row.input_struct_size=n;
  }catch(e){this.row.observation_error=String(e);}
 },onLeave(r){if(!this.row)return;try{
   this.row.result=r.toInt32();this.row.status=this.status.readS16();this.row.buffer_after=hex(this.b,24);const n=this.b.add(4).readS32();if(n<0||n>4096)throw new Error('check output bound');this.row.after=hex(this.p,n);
  }catch(e){this.row.observation_error=String(e);}emit(this.row);}});
}});
