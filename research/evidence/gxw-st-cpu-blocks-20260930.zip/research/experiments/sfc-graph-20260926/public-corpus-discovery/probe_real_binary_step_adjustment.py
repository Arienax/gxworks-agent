from pathlib import Path
from collections import Counter
import json,sys,base64
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256,inspect_project
from gxw.project_metadata import read_project_text_context
from replay_gxw_workspace import prepare,run,trace_prepared
from native_gxw_tokens import native_batch,native_il_projection,Q_DLL
P=Path(__file__).resolve().parent
out=P/'real-binary-step-adjustment';out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
assert sha256(Path('D:/GXWORKS2/Easysocket/Compiler/ECCompiler_IEC.dll').read_bytes())=='f58e7c70b855526bf2f943399a14089f771a43109b13ee9af34c88fb065cf4d7'
prior={r['case']:r for r in map(json.loads,(P/'native-reference-real-corpus/results.jsonl').read_text(encoding='utf-8').splitlines())}
results=[]
for case in ['case-02']:
 source=Path(prior[case]['source']);directory=out/case;directory.mkdir()
 context=read_project_text_context(next(s.raw for s in inspect_project(source.read_bytes()).streams if s.logical_name and s.logical_name.endswith('.prj')))
 assert context['cpu']=='Q03UDV'
 baseline=run(source,directory/'untraced',compile=True,export_project=True,snapshot_frontend=True,project_alias='RECORDSINK')
 assert baseline['returncode']==0 and baseline['compile_completed'] and not baseline['compiler_rejected']
 for attempt in range(3):
  traced=directory/f'trace-{attempt+1}'
  prepare(source,traced,compile=True,export_project=True,snapshot_frontend=True,project_alias='RECORDSINK')
  process=trace_prepared(traced,P/'TraceBinaryStepAdjustment.js')
  ne=[json.loads(l) for l in (traced/'native-events.jsonl').read_text(encoding='utf-8').splitlines()]
  if not ne or ne[-1].get('operation')!='NativeTemporaryDirectoryCollision':break
 raw=[json.loads(l) for l in (traced/'events.jsonl').read_text(encoding='utf-8').splitlines()]
 events=[e['payload'] for e in raw if e.get('type')=='send']
 errors=[e for e in raw if e.get('type')=='error' or e.get('payload',{}).get('event','').endswith('-error')]
 codes={f.name:f.read_bytes() for f in (directory/'untraced').glob('pcode-*.bin')}
 exact={n:(traced/n).exists() and (traced/n).read_bytes()==b for n,b in codes.items()}
 selected=[(n,b) for n,b in codes.items() if b]
 requests=[dict(mode='decode',name=n,input_base64=base64.b64encode(b+b'\0').decode()) for n,b in selected]
 answers=native_batch(requests,directory/'decode',dll=Q_DLL,cpu_code=209)
 decoded=[]
 for (name,blob),answer in zip(selected,answers):
  item=dict(name=name,return_code=answer['return_code'],consumed_bytes=answer['consumed_bytes'],bytes=len(blob))
  if answer['return_code']=='0x00000000' and answer['consumed_bytes']==len(blob):item['listing']=native_il_projection(base64.b64decode(answer['output_base64']),encoding=context['text_encoding'])
  decoded.append(item)
 row=dict(case=case,source=str(source),source_sha256=sha256(source.read_bytes()),context=context,baseline=baseline,trace_directory=traced.name,process=process,errors=errors,exact_pcode=exact,decoded=decoded,record_count=sum(e['event']=='sink-record' for e in events),opcodes=dict(Counter(e['name'].get('latin1',e['name']['hex']) for e in events if e['event']=='sink-record')))
 results.append(row);(directory/'comparison.json').write_text(json.dumps(row,indent=2));(out/'comparison.json').write_text(json.dumps(results,indent=2))
 print(json.dumps({k:row[k] for k in ['case','errors','exact_pcode','record_count','opcodes']}),flush=True)
