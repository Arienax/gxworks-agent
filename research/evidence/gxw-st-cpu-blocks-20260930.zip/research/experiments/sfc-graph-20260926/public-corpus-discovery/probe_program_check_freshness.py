"""Detect false acceptance when native ProgramCheck reads an older resource."""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import run
from probe_fx3g_library_roundtrip import st_envelope

P = Path(__file__).resolve().parent
OUT = P/'program-check-freshness'


def main():
    OUT.mkdir(exist_ok=False)
    (OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    source = (P/'fx3g-library-source-roundtrip-v6/true-source-only/compile-1/native-saved.gxw').read_bytes()
    stream, = [s for s in inspect_project(source).streams if s.logical_name=='MAIN.Program.pou']
    updated = st_envelope(stream.raw,'Y0 := X0;\r\nY0 := X1;\r\n')
    candidate,receipt = patch_raw(source,stream.logical_name,stream.raw,updated)
    path = OUT/'known-invalid-duplicate-coils.gxw'
    path.write_bytes(candidate)
    (OUT/'prediction-before-native.json').write_text(json.dumps(dict(source_sha256=sha256(source),
        candidate_sha256=sha256(candidate),receipt=receipt,
        intent='Generated duplicate-coil counterexample. A successful legacy check is a false acceptance, not a valid writer result.'),indent=2),encoding='utf-8')
    results=[]
    for name,refresh in [('legacy-cache',False),('fresh-pcode',True)]:
        for attempt in range(1,5):
            native = OUT/f'{name}-{attempt}'
            outcome = run(path,native,compile=True,snapshot_frontend=True,program_check=True,
                          export_project=True,project_alias='CHECKAGE',refresh_program_check=refresh)
            events=[json.loads(line) for line in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
            if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
        pcode=(native/'pcode-0-0.bin').read_bytes()
        row=dict(case=name,refresh=refresh,native_directory=str(native),outcome=outcome,
                 pcode_sha256=sha256(pcode),pcode_bytes=len(pcode),
                 native_errors=[r for r in outcome['diagnostics'] if r['kind']==2])
        results.append(row)
        (OUT/'comparison.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
        print(json.dumps(dict(case=name,rejected=outcome['compiler_rejected'],check=outcome['program_check_completed'],
            pcode_sha256=row['pcode_sha256'],pcode_bytes=len(pcode),errors=row['native_errors'])),flush=True)
    assert results[0]['pcode_sha256']==results[1]['pcode_sha256']
    assert not results[0]['outcome']['compiler_rejected'] and results[1]['outcome']['compiler_rejected']
    assert any('Y000' in r['arguments'] and r['phase']=='ProgramCheckProgress' for r in results[1]['native_errors'])


if __name__=='__main__':
    main()
