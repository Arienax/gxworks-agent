"""Offline constant-to-U/J template projection; no device actions."""
from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from gxw.lossless import inspect_project,sha256
from gxw.declarations import parse_declarations,edit_declarations,serialize_declarations
from probe_gxw_st_sources import replace_observed_st
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_compiled_references import inspect
from replay_gxw_workspace import run,prepare,trace_prepared
from native_gxw_compiler import native_table_dump
P=Path(__file__).resolve().parent
source=(P/'samples/boxid.gxw').read_bytes()
before={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
name='POU_01.Program.pou';_,original=replace_observed_st(before[name],'')
case=sys.argv[1] if len(sys.argv)>1 else 'prefixed-unit-network'
calls={
 'prefixed-unit-network':['ZCOM_U_M(TRUE, 10);','ZCOM_U_M(TRUE, 16);','ZCOM_J_M(TRUE, 10);','ZCOM_J_M(TRUE, 16);'],
 'prefixed-typed-constants':['ZCOM_U_M(TRUE, 16#A);','ZCOM_U_M(TRUE, 16#10);','ZCOM_U_M(TRUE, WORD#16#00FF);','ZCOM_U_M(TRUE, INT#256);','ZCOM_J_M(TRUE, 16#A);','ZCOM_J_M(TRUE, 16#10);','ZCOM_J_M(TRUE, WORD#16#0063);','ZCOM_J_M(TRUE, INT#99);'],
 'prefixed-radix-constants':['ZCOM_U_M(TRUE, 16#A);','ZCOM_U_M(TRUE, 16#10);','ZCOM_U_M(TRUE, 16#00FF);','ZCOM_U_M(TRUE, 256);','ZCOM_J_M(TRUE, 16#A);','ZCOM_J_M(TRUE, 16#10);','ZCOM_J_M(TRUE, 16#0063);','ZCOM_J_M(TRUE, 99);'],
 'prefixed-direct-output':['DOUT_MD(TRUE, %QX0.0);','DSET_MD(TRUE, %QX0.1);','DRST_MD(TRUE, %QX0.2);','DSET_P_MD(TRUE, %QX0.3);','DRST_P_MD(TRUE, %QX0.4);'],
 'prefixed-direct-output-label':['DOUT_MD(TRUE, DirectY);','DSET_MD(TRUE, DirectY);','DRST_MD(TRUE, DirectY);','DSET_P_MD(TRUE, DirectY);','DRST_P_MD(TRUE, DirectY);'],
 'prefixed-direct-output-global':['DOUT_MD(TRUE, DirectY);','DSET_MD(TRUE, DirectY);','DRST_MD(TRUE, DirectY);','DSET_P_MD(TRUE, DirectY);','DRST_P_MD(TRUE, DirectY);'],
 'prefixed-direct-output-global-flat':['DOUT_MD(TRUE, DirectY);','DSET_MD(TRUE, DirectY);','DRST_MD(TRUE, DirectY);','DSET_P_MD(TRUE, DirectY);','DRST_P_MD(TRUE, DirectY);'],
 'bare-radix-constants':['MOV_M(TRUE, 16#10, LiteralWord);','MOV_M(TRUE, 16, LiteralWord);','MOV_M(TRUE, 2#1010, LiteralWord);','MOV_M(TRUE, 8#12, LiteralWord);','MOV_M(TRUE, 16#FFFF, LiteralWord);','MOV_M(TRUE, -1, LiteralWord);'],
 'typed-real-time':['LiteralReal := 1.25;','LiteralReal := 1.23456789;','LiteralTime := T#1d2h3m4s5ms;','LiteralTime := T#0.5s;'],
 'fixed-input-counter':['UDCNT1_M(TRUE, CountX, 10, CounterC);'],
}[case]
program,_=replace_observed_st(before[name],original+'\r\n'+'\r\n'.join(calls)+'\r\n')
changed,receipt=patch_raw(source,name,before[name],program)
changed_names={name}
if case.startswith('prefixed-direct-output-'):
 labels='Control.gh' if '-global' in case else 'POU_01.Labels.lh'
 document=parse_declarations(before[labels],logical_name=labels)
 edited=serialize_declarations(edit_declarations(document,upserts=[dict(name='DirectY',data_type='BOOL',device='Y0',iec_address='%QX0' if case.endswith('-flat') else '%QX0.0')]))
 changed,label_receipt=patch_raw(changed,labels,before[labels],edited)
 receipt=[receipt,label_receipt];changed_names.add(labels)
if case in ('bare-radix-constants','typed-real-time'):
 labels='POU_01.Labels.lh';document=parse_declarations(before[labels],logical_name=labels)
 upserts=[dict(name='LiteralWord',data_type='WORD')] if case=='bare-radix-constants' else [dict(name='LiteralReal',data_type='REAL'),dict(name='LiteralTime',data_type='TIME')]
 edited=serialize_declarations(edit_declarations(document,upserts=upserts))
 changed,label_receipt=patch_raw(changed,labels,before[labels],edited)
 receipt=[receipt,label_receipt];changed_names.add(labels)
if case=='fixed-input-counter':
 labels='Control.gh';document=parse_declarations(before[labels],logical_name=labels)
 edited=serialize_declarations(edit_declarations(document,upserts=[dict(name='CountX',data_type='ARRAY[1..2] OF BOOL',device='X0',iec_address='%IX0'),dict(name='CounterC',data_type='INT',device='C0',iec_address='%MW4.0')]))
 changed,label_receipt=patch_raw(changed,labels,before[labels],edited)
 receipt=[receipt,label_receipt];changed_names.add(labels)
after={s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}
assert all(after[k]==v for k,v in before.items() if k not in changed_names)
out=P/'builtin-template-call-controls'/case;out.mkdir(parents=True,exist_ok=False)
(out/'changed.gxw').write_bytes(changed)
(out/'mutation.json').write_text(json.dumps(dict(source_sha256=sha256(source),changed_sha256=sha256(changed),calls=calls,unrelated_payloads='byte-identical',receipt=receipt),indent=2))
native=run(out/'changed.gxw',out/'native',compile=True,export_project=True,snapshot_frontend=True)
print(json.dumps(native),flush=True)
result=dict(native=native)
if native.get('native_export') and not native.get('compiler_rejected'):
 read=inspect(out/'native',out/'correlation');decoded=read['decoded_fragments']
 names=tuple(c.split('(')[0]+'(' if '(' in c else c.split(':=')[0].strip()+' :=' for c in calls)
 result['calls']=[dict(line=o['source_line'],records=[r for g in o['compiled_records'] for r in decoded[g['decode_request']].get('records',[])]) for e in read['expansions'] for o in e.get('occurrences',[]) if o.get('source_line',{}).get('text','').startswith(names)]
 prepare(out/'changed.gxw',out/'trace',compile=True,export_project=True)
 result['trace']=trace_prepared(out/'trace',ROOT/'research/native/CompilerTrace.js',timeout=45)
 result['trace_pcode_equal']=all((out/'trace'/f).read_bytes()==(out/'native'/f).read_bytes() for f in native['outputs'])
 captured=[]
 for line in (out/'trace/events.jsonl').read_text().splitlines():
  event=json.loads(line).get('payload',{})
  if event.get('event')!='enter' or event.get('name')!='Compile':continue
  buffers={v['label']:v for v in event['buffers']}
  if any(k.startswith('name_') and v.get('bytes') and bytes.fromhex(v['bytes']).split(b'\0')[0]==b'POU_01' for k,v in buffers.items()):
   captured.append(bytes.fromhex(buffers['symbolic_data']['bytes']))
 assert len(captured)==1
 (out/'captured-symbols.bin').write_bytes(captured[0])
 result['constant_reader']=native_table_dump(captured[0],out/'native-constant-reader',read_constants=True)
(out/'comparison.json').write_text(json.dumps(result,indent=2))
print(json.dumps({k:v for k,v in result.items() if k!='native'}),flush=True)
