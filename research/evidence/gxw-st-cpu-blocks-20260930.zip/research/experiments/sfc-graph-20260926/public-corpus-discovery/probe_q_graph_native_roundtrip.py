"""Reopen native-normalized name/group controls and compare full PCode.

The structural projection is limited to these bounded ST controls, task entry
records, exact declaration rows and the still-opaque declaration header block.
No scheduling or arbitrary ST semantics are inferred.
"""
from pathlib import Path
import json,struct,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.declarations import parse_declarations
from probe_gxw_task_graph import inspect_task_graph
from replay_gxw_workspace import run
P=Path(__file__).resolve().parent
out=P/'q-graph-native-roundtrip';out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
def projection(source):
    graph=inspect_task_graph(source);assert not graph['gaps']
    streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
    programs={}
    for name,pou in graph['programs'].items():
        raw=streams[pou['source_program']]
        assert raw[54]==0xc1 and struct.unpack_from('<I',raw,63)[0]==1
        count=struct.unpack_from('<I',raw,67)[0];end=71+count*2
        assert 1<=count<=8192 and end<=len(raw) and raw[end-2:end]==b'\0\0'
        declarations=parse_declarations(streams[pou['declarations']],logical_name=pou['declarations'])
        programs[name]=dict(st_text=raw[71:end-2].decode('utf-16le'),
            declaration_rows=[r.raw.hex() for r in declarations.rows],opaque_label_header=declarations.header[-24:-4].hex())
    tasks={name:[dict(program_reference=e['program_reference'],stored_order=e['stored_order'],secondary_text=e['secondary_text']) for e in task['entries']] for name,task in graph['tasks'].items()}
    return dict(programs=programs,tasks=tasks,resources=[dict(resource=r['resource'],task=r['task']) for r in graph['resources']]),graph
plans=[('q-label-owner-binding-v2','folder-swap'),('q-pou-name-binding','label-logical-name-swap'),('q-pou-name-binding','source-logical-name-swap')]
rows=[]
for experiment,case in plans:
    original=P/experiment/case;directory=out/case;directory.mkdir()
    previous=json.loads((original/'comparison.json').read_text(encoding='utf-8'))
    native=P/experiment/previous['native_directory'];saved=native/'native-saved.gxw'
    before,before_graph=projection((original/'input.gxw').read_bytes())
    normalized,after_graph=projection(saved.read_bytes())
    assert before==normalized
    for attempt in range(1,9):
        target=directory/('native-reopened' if attempt==1 else 'native-reopened-v'+str(attempt))
        result=run(saved,target,compile=True,snapshot_frontend=True,export_project=True,project_alias='QGRAPHREOPEN')
        events=[json.loads(s) for s in (target/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
        if (target/'pcode-0-0.bin').exists() or not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
    accepted=result['returncode']==0 and result['open_succeeded'] and result['compile_completed'] and not result['compiler_rejected']
    row=dict(experiment=experiment,case=case,input_sha256=sha256((original/'input.gxw').read_bytes()),saved_sha256=sha256(saved.read_bytes()),
        native={k:result[k] for k in ('returncode','open_succeeded','compile_completed','compiler_rejected','diagnostics')},
        graph_before=before_graph['programs'],graph_saved=after_graph['programs'],structural_projection=before,structure_preserved=True)
    if accepted:
        first={f.name:f.read_bytes() for f in native.glob('pcode-*.bin')}
        second={f.name:f.read_bytes() for f in target.glob('pcode-*.bin')}
        row['pcode_byte_identical']=first==second
        row['pcode_sha256']={name:sha256(raw) for name,raw in second.items()}
        final,final_graph=projection((target/'native-saved.gxw').read_bytes())
        row['reopened_structure_preserved']=final==before
        assert row['pcode_byte_identical'] and row['reopened_structure_preserved']
    rows.append(row);(directory/'comparison.json').write_text(json.dumps(row,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in row.items() if k in ['case','native','structure_preserved','pcode_byte_identical','reopened_structure_preserved']}),flush=True)
    assert accepted
(out/'comparison.json').write_text(json.dumps(dict(cases=rows,scope=__doc__),ensure_ascii=False,indent=2),encoding='utf-8')
