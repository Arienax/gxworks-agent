"""Independent BOOL holdouts and word-pool exhaustion for source VAR_RETAIN."""
from dataclasses import replace
from pathlib import Path
import json
import struct
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'research')]
from gxw.lossless import inspect_project, sha256
from gxw.declarations import parse_declarations, serialize_declarations
from probe_gxw_parameters import project_allocation_ranges
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import prepare, trace_prepared
from probe_gxw_program_check_resources import SCRIPT, inspect_run

P = Path(__file__).resolve().parent
OUT = P / 'pool-subselection-20260930'


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def patch_pool_metadata(source, logical, old, new, names):
    """Same-size observed allocation pairs only; retain the integrity envelope."""
    from gxw.container_writer import validate_cfb_streams, replace_stream_within_allocation
    from gxw.project_metadata import logical_mapping, synchronize_history
    from probe_gxw_integrity import inspect, TABLE_BYTES, FILES, _validate_hdb_body, observed_digest
    ranges = {r['name']: r for r in project_allocation_ranges(old)['ranges']}
    allowed = {i for name in names for i in range(ranges[name]['offset'], ranges[name]['offset'] + 8)}
    if not logical.endswith('.prj') or len(old) != len(new) or any(a != b and i not in allowed for i, (a, b) in enumerate(zip(old, new))):
        raise ValueError('outside same-size allocation pair experiment')
    if old == new:
        return source, dict(changes='none')
    outer = validate_cfb_streams(source)
    if not outer.get('Project.gd2'):
        return patch_raw(source, logical, old, new)
    if inspect(source)['valid'] is not True:
        raise ValueError('original integrity envelope must verify')
    body, table = outer['_hdb'][:-TABLE_BYTES], outer['_hdb'][-TABLE_BYTES:]
    nested, suffix = _validate_hdb_body(body)
    physical = logical_mapping(outer['projectdatalist.xml'])[logical]
    assert nested[physical] == old
    changed_body = replace_stream_within_allocation(body, physical, new)
    assert _validate_hdb_body(changed_body) == (dict(nested, **{physical: new}), suffix)
    history, changes, preserved = synchronize_history(outer['history.xml'], {logical: (physical, old, new)})
    assert len(history) == len(outer['history.xml'])
    candidate = replace_stream_within_allocation(source, '_hdb', changed_body + table)
    candidate = replace_stream_within_allocation(candidate, 'history.xml', history)
    assert validate_cfb_streams(candidate) == dict(outer, _hdb=changed_body + table, **{'history.xml': history})
    updated = dict(outer, **{'history.xml': history})
    new_table = b''.join(observed_digest(changed_body if name == '_hdb' else updated[name]) for name in FILES)
    refreshed_hdb = changed_body + new_table
    result = replace_stream_within_allocation(candidate, '_hdb', refreshed_hdb)
    result = replace_stream_within_allocation(result, 'Project.gd2', observed_digest(refreshed_hdb))
    assert validate_cfb_streams(result) == dict(updated, _hdb=refreshed_hdb, **{'Project.gd2': observed_digest(refreshed_hdb)})
    assert inspect(result)['valid'] is True
    receipt = dict(input_sha256=sha256(source), output_sha256=sha256(result), original_table_sha256=sha256(table),
        refreshed_table_sha256=sha256(new_table), opaque_suffix=suffix, unrelated_payloads='byte-identical',
        integrity='verified observed metadata table; not native compilation or authorization')
    return result, dict(scope='observed same-size allocation pairs only', fields=list(names),
        metadata_changes=changes, preserved_metadata=preserved, integrity_refresh=receipt)


def main():
    OUT.mkdir(exist_ok=False)
    (OUT / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    observer = (P / 'native-allocation-bitmap-v2/observer.js').read_text(encoding='utf-8')
    script = OUT / 'trace.js'
    from trace_allocation_pool_queries import QUERY_SCRIPT
    extra = (P / 'observe_retain_pair_getter.js').read_text(encoding='utf-8')
    script.write_text('(()=>{' + observer + '\n})();\n(()=>{' + SCRIPT + '\n})();\n(()=>{' + QUERY_SCRIPT + '\n})();\n(()=>{' + extra + '\n})();', encoding='utf-8')
    project2 = P / 'samples/project2.gxw'
    noeul = P / 'noeul-native-batch/case-08/input.gxw'
    cases = [
        ('W1-W2-two-ints', noeul, [5, 6], dict(latch_W1=(512, 512), latch_W2=(768, 775)), False),
        ('W2-two-ints', noeul, [5, 6], dict(latch_W2=(768, 775)), False),
        ('B1-B2-two-bools', project2, [2, 3], dict(latch_B1=(256, 256), latch_B2=(512, 519)), False),
        ('B2-two-bools', project2, [2, 3], dict(latch_B2=(512, 519)), True),
    ]
    results = []
    for case, original_path, ids, pools, reopen in cases:
        directory = OUT / case
        directory.mkdir()
        original = original_path.read_bytes()
        streams = {s.logical_name: s.raw for s in inspect_project(original).streams if s.logical_name}
        metadata = next(n for n in streams if n.endswith('.prj'))
        labels = 'MAIN.Labels.lh' if original_path == project2 else next(n for n, raw in streams.items()
            if n.endswith('.Labels.lh') and any(r.name == 'EMSTP' for r in parse_declarations(raw, logical_name=n).rows))
        doc = parse_declarations(streams[labels], logical_name=labels)
        selected = [r for r in doc.rows if r.record_id in ids]
        assert len(selected) == len(ids) and all(r.class_code == 1 for r in selected)
        changed = serialize_declarations(replace(doc, rows=tuple(replace(r, class_code=10) if r in selected else r for r in doc.rows)))
        source, receipt = patch_raw(original, labels, streams[labels], changed)
        ranges = {r['name']: r for r in project_allocation_ranges(streams[metadata])['ranges']}
        new = bytearray(streams[metadata])
        for name, pair in pools.items():
            struct.pack_into('<II', new, ranges[name]['offset'], *pair)
        source, metadata_receipt = patch_pool_metadata(source, metadata, streams[metadata], bytes(new), pools)
        expected = dict(streams, **{labels: changed, metadata: bytes(new)})
        assert expected == {s.logical_name: s.raw for s in inspect_project(source).streams if s.logical_name}
        path = directory / 'input.gxw'
        path.write_bytes(source)
        save(directory / 'before-native.json', dict(original_path=str(original_path), original_sha256=sha256(original),
            input_sha256=sha256(source), source_class=10, labels=[dict(id=r.record_id, name=r.name, type=r.data_type) for r in selected],
            pools=pools, receipts=[receipt, metadata_receipt], unaffected_payloads='byte-identical',
            hypothesis='Source class 10 maps to compiler category 6. Retain allocation uses dedicated pools, no ordinary fallback.'))
        previous = None
        for phase in ('compile', 'reopen') if reopen else ('compile',):
            for attempt in range(1, 5):
                native = directory / f'{phase}-{attempt}'
                prepare(path, native, compile=True, program_check=True, export_project=True,
                    snapshot_frontend=True, project_alias='RETAINHOLDOUT')
                process = trace_prepared(native, script)
                events = [json.loads(line) for line in (native / 'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
                if not any(e.get('operation') == 'NativeTemporaryDirectoryCollision' for e in events):
                    break
            observed = inspect_run(native)
            messages = [json.loads(line) for line in (native / 'events.jsonl').read_text(encoding='utf-8').splitlines()]
            emitted = [m['payload'] for m in messages if m.get('type') == 'send']
            typed = [r for r in emitted if r.get('event') == 'typed-allocation']
            allocations = [r for r in emitted if r.get('event') == 'pool-allocation']
            errors = [m for m in messages if m.get('type') == 'error' or 'error' in m.get('payload', {}).get('event', '')
                or 'observation_error' in m.get('payload', {})]
            checked = [r for r in observed['resource_reads'] if r['phase'] == 'check' and r['target'] == r['check_target']]
            buffers = [b for r in checked for b in r['buffers'] if b['sha256'] is not None and b['size']]
            row = dict(case=case, phase=phase, native_directory=str(native), process=process, trace_errors=errors,
                queries=[r for r in emitted if r.get('event') in ('allocation-range-query','retain-pair-query','retain-pair-provider')],
                check=observed['check'], checked_current=bool(buffers) and all(b['matches_current'] for b in buffers),
                diagnostics=observed['diagnostics'], generated=observed['generated'], typed=typed, pools=allocations,
                exported_sha256=observed['exported_sha256'], reopen_code_equal=None if previous is None else previous == observed['generated'])
            results.append(row)
            save(OUT / 'comparison.json', results)
            print(json.dumps(dict(case=case, phase=phase, check=row['check'], checked_current=row['checked_current'],
                retain=[{k: a[k] for k in ('type', 'category', 'result', 'after')} for a in typed if a['category'] == 6],
                errors=[dict(code=hex(d['code']), arguments=d['arguments']) for d in row['diagnostics'] if d['kind'] == 2],
                reopen_code_equal=row['reopen_code_equal'], trace_errors=errors)), flush=True)
            if process['timed_out'] or errors:
                raise RuntimeError('Incomplete observation; all raw results retained')
            path = native / 'native-saved.gxw'
            if not path.exists():
                break
            previous = observed['generated']


if __name__ == '__main__':
    main()
