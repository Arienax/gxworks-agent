"""Check intrinsic lowering against native bytes, allocations and fresh checks.

This does not execute PLC instructions or infer conversion output characters.
Native-generated but ProgramCheck-rejected PCode is retained and decoded too.
"""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[4];sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from source_q_st_calls import predict
from witness_st_conditional_transfers import decode,evaluate
from probe_minimal_conditional_port_writes import save,streams
from verify_temporary_check_correspondence import verify
P=Path(__file__).resolve().parent
GROUPS=['st-string-conversion-discovery-20260930','st-string-intrinsic-connections-20260930',
        'st-keypad-conversion-forward-20260930','st-string-intrinsic-index-controls-20260930',
        'st-string-intrinsic-forward-20260930']
INDEXED_EXPECTED={
    'indexed-enable-only':{'probeR1':123},'indexed-enable-destination':{'probeR1':123},
    'indexed-enable-source':{'probeR1':678},'indexed-enable-expression':{'probeR1':123},
    'B-indexed-enable':{'probeR1':123},'B-gate-16':{'probeR0':123,'probeR1':456},
    'B-gate-1':{'probeR0':123,'probeR1':456},'B-input-16':{'probeR0':123,'probeR1':123},
    'fb-enable-dynamic-output':{'probeR0':20,'probeR1':123},
    'fb-enable-literal-output':{'probeR0':123,'probeR1':30},
    'fb-false-enable-index-side-effect':{'probeR0':20,'probeR1':456},
    'fb-input-enable-snapshot':{'probeR0':123,'probeR1':30},
    'M-array-B-snapshot':{'probeR1':123},'B-array-B-snapshot':{'probeR1':123},
    'B-bits-W-words':{'probeR0':456,'probeR1':123},
    'bool-inout-index-change':{'probeR0':True,'probeR1':False,'probeR2':True},
    'bool-inout-write-false':{'probeR0':False,'probeR1':True,'probeR2':False},
    'bool-output-index-clobber':{'probeR1':False,'probeR2':True},
    'bool-inout-B':{'probeR0':True,'probeR1':False,'probeR2':True},
    'bool-inout-enable-reuse':{'probeR0':False,'probeR2':11},
    'bool-inout-member-reused':{'probeR0':True,'probeR2':11},
    'B-enable-B-reuse':{'probeR0':123,'probeR1':456},
    'M-input-B-requests':{'probeR0':123,'probeR1':123},
    'BOOL-inout-B-exact-reuse':{'probeR0':False,'probeR1':False},
    'B-NOT-M-two-bits':{'probeR1':11,'probeR2':12},
    'B-NOT-B-one-cache':{'probeR1':11,'probeR2':12},
    'BOOL-B-member-two-bits':{'probeR0':False,'probeR2':11},
    'BOOL-B-member-B-source':{'probeR0':True,'probeR2':11},
    'NOT-indexed-enable-direct':{'probeR1':123},
    'NOT-indexed-enable-B-capture':{'probeR1':123},
    'NOT-indexed-BOOL-input':{'probeR0':123},
    'conditional-enable-tail-0':{'probeR2':9},
    'conditional-enable-tail-1':{'probeR2':11},
    'OR-indexed-pair':{'probeR1':123},'AND-indexed-pair':{'probeR1':9},
    'NOT-input-alias-M':{'probeR1':11},'NOT-input-alias-B':{'probeR1':11},
    'NOT-inout-alias-B':{'probeR1':11},
    'NOT-member-alias-B':{'probeR0':11,'probeR1':11,'probeR2':True},
    'OR-M-B-two-bits':{'probeR2':12},'AND-M-B-two-bits':{'probeR2':12},
    'OR-B-B-one-cache':{'probeR2':12},
    'OR-mixed-M-left':{'probeR2':12},'OR-mixed-B-left':{'probeR2':12},
    'OR-right-index':{'probeR1':123},'OR-left-index':{'probeR1':123},
    'OR-pair-data-B2':{'probeR1':123},'AND-pair-data-B2':{'probeR1':9},
    'OR-pair-input-B2':{'probeR0':123},
    'BOOL-output-binary-index-alias':{'probeR0':False,'probeR1':True,'probeR2':False},
    'BOOL-output-binary-literal':{'probeR0':True,'probeR1':True,'probeR2':False},
    'BOOL-output-binary-scalar':{'probeR0':True,'probeR1':False,'probeR2':False},
    'BOOL-inout-binary-B':{'probeR0':True,'probeR1':True,'probeR2':False},
    'BOOL-store-scalar-true':{'probeR1':True,'probeR2':False},
    'BOOL-store-scalar-false':{'probeR1':False,'probeR2':False},
    'BOOL-store-indexed-true':{'probeR1':True,'probeR2':True},
    'BOOL-store-indexed-false':{'probeR1':False,'probeR2':False},
    'BOOL-store-indexed-both-arithmetic':{'probeR1':True,'probeR2':True},
    'BOOL-store-binary-B2':{'probeR1':True,'probeR2':True},
    'BOOL-store-conditional-false':{'probeR1':False,'probeR2':False},
    'BOOL-store-indexed-B':{'probeR1':True,'probeR2':True},
    'BOOL-store-indexed-B-repeat':{'probeR1':True,'probeR2':True},
    'BOOL-store-scalar-NOT-B':{'probeR2':True},'BOOL-store-scalar-OR-B':{'probeR2':True},
    'BOOL-store-binary-B2-repeat':{'probeR1':True,'probeR2':True},
    'BOOL-store-M-source-B-destination':{'probeR0':True,'probeR1':True},
    'BOOL-store-same-index':{'probeR1':True,'probeR2':False},
    'BOOL-store-comparison-1-B':{'probeR1':True,'probeR2':False},
    'BOOL-store-comparison-0-B':{'probeR1':False,'probeR2':False},
    'BOOL-store-NOT-indexed-B':{'probeR1':True,'probeR2':False},
    'BOOL-store-scalar-AND-B':{'probeR2':False},
    'BOOL-store-before-enable-B2':{'probeR0':123,'probeR1':True},
    'BOOL-enable-before-store-B1':{'probeR0':123,'probeR1':True},
    'BOOL-nested-OR-AND':{'probeR0':True},'BOOL-nested-mixed-compare':{'probeR0':True},
    'BOOL-nested-XOR-OR':{'probeR0':True},
    'BOOL-recursive-left-chain-B2':{'probeR0':True},
    'BOOL-recursive-left-stable-capture':{'probeR0':False},
    'BOOL-recursive-right-stable-block':{'probeR0':True},
    'BOOL-recursive-ORI':{'probeR0':True},'BOOL-recursive-indexed-comparison':{'probeR0':True},
    'BOOL-XOR-scalar':{'probeR0':True},'BOOL-XOR-left-index':{'probeR0':True},
    'BOOL-XOR-right-index':{'probeR0':True},'BOOL-XOR-NOT-scalar':{'probeR0':False},
    'BOOL-XOR-comparison':{'probeR0':True},'BOOL-XOR-right-NOT':{'probeR0':False},
    'BOOL-XOR-comparison-index':{'probeR0':False},'BOOL-XOR-pair-B2':{'probeR0':True},
    'BOOL-XOR-right-comparison':{'probeR0':True},'BOOL-XOR-enable-B2':{'probeR0':123},
    'BOOL-XOR-dynamic-store-B2':{'probeR0':False},'BOOL-XOR-input-corrected-B2':{'probeR0':123},
    'BOOL-right-tree-left-index-B2':{'probeR0':True},'BOOL-right-tree-both-B3':{'probeR0':True},
    'BOOL-right-tree-left-scalar-B1':{'probeR0':True},'BOOL-right-tree-AND-OR-B3':{'probeR0':False},
    'BOOL-right-tree-scalar-OR-B1':{'probeR0':True},'BOOL-right-tree-XOR-B2':{'probeR0':True},
    'BOOL-right-tree-OR-AND-B2':{'probeR0':True},
    'IF-BOOL-scalar':{'probeR0':123},'IF-BOOL-recursive-indexed':{'probeR0':123},
    'IF-Keypad-WORD-guard-49':{'probeR1':123,'probeR2':0},'IF-Keypad-WORD-guard-67':{'probeR1':9,'probeR2':67},
    'IF-forward-BOOL-false':{'probeR0':9},'IF-forward-NOT-scalar':{'probeR0':123},
    'IF-forward-INT-less-equal':{'probeR0':123},'IF-forward-WORD-equal':{'probeR0':123},
    'IF-forward-mixed-OR':{'probeR0':9},'IF-forward-two-labels-P2':{'probeR0':123},
    'bool-conditional-skipped':{'probeR0':True,'probeR1':True,'probeR2':True},
    'bool-conditional-taken':{'probeR0':False,'probeR1':True,'probeR2':False}}


def main():
    groups=sys.argv[1:] or GROUPS;rows=[]
    enabled=all(json.loads((P/g/'experiment-plan.json').read_text()).get('prediction_options',{}).get('allow_enabled_instructions') for g in groups)
    indexed_banks=all(g.startswith(('st-indexed-enable-','st-bool-port-')) for g in groups)
    direct_stores=all(g.startswith('st-bool-port-direct-store-') for g in groups)
    recursive=all(g.startswith('st-bool-expression-') or json.loads((P/g/'experiment-plan.json').read_text()).get('prediction_options',{}).get('allow_recursive_booleans') for g in groups)
    general=all(g.startswith('st-condition-branch-') for g in groups)
    for group in groups:
        out=P/group
        listings={r['case']:r['records'] for r in json.loads((out/'native-listings.json').read_text())}
        for c in json.loads((out/'comparison.json').read_text()):
            d=out/c['case'];n=Path(c['native_directory']);before=json.loads((d/'before-native.json').read_text())
            source=(d/'input.gxw').read_bytes();assert sha256(source)==before['input_sha256']==sha256((n/'input.gxw').read_bytes())
            content=streams(source);assert all(sha256(content[k])==v for k,v in before['unchanged_streams'].items())
            code=(n/'pcode-0-0.bin').read_bytes()
            row=dict(group=group,case=c['case'],input_sha256=sha256(source),accepted=bool(c['check'] and not c['check']['rejected']),
                check=c['check'],backend_rejected=c['backend_rejected'],before_native_prediction_equal=c['predicted_equal'],
                unchanged_payloads=len(before['unchanged_streams']),pcode_bytes=len(code),pcode_sha256=sha256(code),
                diagnostic_codes=sorted(set(hex(e['code']) for e in c['diagnostics'] if e['kind']==2)))
            if code:
                records=decode(code)
                assert [{k:v for k,v in r.items() if k not in ('raw','offset')} for r in records]==listings[c['case']]
                row['native_core_lexical_equal']=True
                row['intrinsics']=[dict(op=r['op'],args=r['args']) for r in records if r.get('op') in ('BINHA','BINDA','RIGHT')]
                if c['case']=='right-fb-output-index-clobber':
                    stop=next(i for i,r in enumerate(records) if r.get('op')=='RIGHT')
                    prefix=evaluate(records[:stop]+[dict(kind='instruction',op='FEND',args=[])],{'index_register':dict(address='Z16',type='INT')})
                    assert prefix['observations']['index_register']==3
                    assert records[stop]['args']==['D13300Z16','D13272Z16','K1']
                    row['preinstruction_address_witness']=dict(prefix=prefix,requested_destination='D13276',actual_destination='D13275',
                        basis='Source index 1 times caller STRING[6] stride 4 was replaced by callee STRING[4] stride 3. Only the initialized instruction prefix is evaluated; RIGHT itself is not executed.')
                if c['check'] and c['check']['rejected']:
                    # Stored Q step widths map the backend diagnostic to its
                    # generated rung; this is localization, not error semantics.
                    step=0;positions=[]
                    for r in records:
                        raw=bytes.fromhex(r['raw']);width=1 if raw[0]<=3 else raw[2]
                        positions.append(dict(step=step,width=width,op=r.get('op'),args=r.get('args')));step+=width
                    row['native_step_map']=positions
                    row['backend_error_steps']=[d['step'] for d in c['backend_diagnostics'] if d['kind']==2]
            if row['accepted']:
                assert c['reopen']['check'] and not c['reopen']['check']['rejected'] and c['reopen']['identical']
            if (d/'predicted-0.bin').exists():assert ((d/'predicted-0.bin').read_bytes()==code)==c['predicted_equal']
            else:assert c['predicted_equal'] is None and 'unsupported' in before['prediction']
            messages=[json.loads(l) for l in (n/'events.jsonl').read_text().splitlines()]
            assert not any(m.get('type')=='error' for m in messages)
            events=[m['payload'] for m in messages if m.get('type')=='send']
            assert not any('error' in r.get('event','') or r.get('observation_error') for r in events)
            if json.loads((out/'experiment-plan.json').read_text()).get('extra_observer')=='observe_bit_request_stacks.js':
                assert any(e.get('event')=='bit-request-stack-observer-installed' for e in events)
                stacks=[e for e in events if e.get('event')=='bit-request-stack']
                requests=[e for e in events if e.get('event')=='temporary-slots' and e.get('name')=='request']
                assert sorted((e['type'],*e['address'],e['count'],e['caller']['rva']) for e in stacks)==sorted((*e['args'][:4],e['caller']['rva']) for e in requests)
                row.update(request_stack_observations=stacks,request_stack_scope='Hook installation and request identity are verified. Frames may contain instrumentation entries or be incomplete; fuzzy frames are caller candidates. Static callsite checks are required for ancestor claims.')
            if enabled:
                index_events=[e for e in events if e.get('event')=='index-register-lifetime']
                row['enabled_index_consumptions']=sum(e['phase']=='consume-enter' and e.get('caller',{}).get('rva')=='0x86579' for e in index_events)
                row['deferred_z18_selections']=sum(e['phase']=='select-register' and e['slot']==1 and e['result']==18 and e.get('caller',{}).get('rva')=='0xcaec0' for e in index_events)
            temps=[r for r in events if r.get('event')=='temporary-create']
            selected=[r for r in events if r.get('event')=='temporary-slots' and r['name']=='select']
            row['temporary_requests']=[{k:r[k] for k in ('type','count','caller','result','output')} for r in temps]
            if c['case'] in ('M-enable-B-unmatchable','BOOL-B-member-reused','B-NOT-M-one-bit','OR-M-B-repeat','AND-M-B-repeat','OR-pair-data-B1','OR-pair-input-B1','BOOL-store-binary-B1'):
                row['slot_selection_failure_trace']=[{k:r[k] for k in ('args','result','before','after')} for r in selected]
            try:model=predict(source,('SCPI',),owner='MAIN',allow_inputs=True,allow_omitted=True,allow_members=True,
                              allow_concat=True,allow_dynamic_stores=True,allow_alternate_banks=True,allow_string_intrinsics=True,allow_enabled_instructions=enabled,allow_recursive_booleans=recursive,allow_general_conditions=general)
            except ValueError as exc:row.update(handling='unsupported',model_reason=str(exc));rows.append(row);continue
            row.update(handling='compiler-output-reproduced',corrected_prediction_equal=model['output']==code)
            assert model['output']==code,(c['case'],'current source prediction differs')
            typed=[r for r in events if r.get('event')=='typed-allocation' and r['result']==1]
            assert len(typed)==len(model['declarations'])
            for a,b in zip(typed,model['declarations'],strict=True):assert bytes.fromhex(a['after'])==bytes.fromhex(b['raw'])
            actual=[]
            for t in temps:
                assert t['result']==0
                raw=bytes.fromhex(t['output']);tag=int.from_bytes(raw[20:24],'little');physical_type=tag&255;wide=physical_type in (100,114,119)
                family='ZR' if tag&0x8000 else {77:'M',66:'B',68:'D',87:'W',82:'R'}[physical_type-(32 if wide else 0)]
                actual.append((t['type'],family,int.from_bytes(raw[8:12],'little'),t['count']*(2 if wide else 1),t['caller']['rva']))
            expected=[({'M':77,'B':66,'D':68,'W':87,'R':82,'ZR':82}[r['family']],r['family'],r['number'],r['width'],'0xca1cf') for r in model['input_buffers']]
            expected += [(r['creation_request_type'],r['family'],r['number'],r['width'],'0x6d632') for r in model['slots']]
            assert sorted(actual)==sorted(expected),(c['case'],actual,expected)
            original=before['prediction']
            if 'slots' in original:
                original_requests=[({'M':77,'B':66,'D':68,'W':87,'R':82,'ZR':82}[r['family']],r['family'],r['number'],r['width'],'0xca1cf') for r in original['input_buffers']]
                original_requests += [(r['creation_request_type'],r['family'],r['number'],r['width'],'0x6d632') for r in original['slots']]
                row['before_native_temporary_requests_equal']=sorted(actual)==sorted(original_requests)
                if not row['before_native_temporary_requests_equal']:row['before_native_temporary_request_prediction']=original_requests
            assert [e['slot'] for e in model['temporary_events'] if e['action'] in ('create','reuse')]==[r['result'] for r in selected]
            if direct_stores or recursive:
                references=[e for e in events if e.get('event')=='temporary-slots' and e.get('name')=='request' and e.get('caller',{}).get('rva')=='0xccdfa']
                predicted_references=[e for e in model['temporary_events'] if e['action']=='reacquire-operand']
                assert len(references)==len(predicted_references)
                for a,b in zip(references,predicted_references,strict=True):
                    assert a['args'][:4]==[b['type'],b['number'],0,b['width']] and a['result']==b['number']
                    old=next(s for s in a['before'] if s['index']==b['slot']);new=next(s for s in a['after'] if s['index']==b['slot'])
                    assert old['type']==new['type']==b['type'] and old['operand']==new['operand']==[b['number'],0]
                    assert old['state']==2 and new['state']==1
                row.update(operand_reacquisitions_verified=len(references),operand_reacquisitions=references)
            row.update(typed_allocations_verified=len(typed),temporary_creates_verified=len(temps),slot_selections_verified=len(selected),
                       model_slots=model['slots'],model_temporary_events=model['temporary_events'])
            if c['case'] in ('bool-direct-alias','bool-double-not-capture','bool-input-or-snapshot','or-input-repeat'):
                names=['probeR0','probeR1'] if c['case']=='or-input-repeat' else ['probeR0']
                obs={}
                for name in names:
                    declaration=next(a for a in model['declarations'] if a['owner']=='MAIN' and a['name']==name)
                    assert declaration['allocated_family']=='D'
                    obs[name]=dict(address='D'+str(declaration['number']),type='INT')
                result=evaluate(records,obs,allow_boolean=True)
                expected_result=9 if c['case'] in ('bool-direct-alias','bool-double-not-capture') else 123
                assert all(v==expected_result for v in result['observations'].values())
                row['finite_bool_word_witness']=result
            if c['case']=='right-disabled-index-side-effect':
                stop=next(i for i,r in enumerate(records) if r.get('op')=='RIGHT')
                prefix=evaluate(records[:stop],{'index':dict(address='Z16',type='INT')},allow_boolean=True)
                assert prefix['final_condition'] is False and prefix['observations']['index']==3
                assert records[stop]['args']==['D13300Z16','D13272Z16','K1']
                assert records[stop+1]['op']=='LD' and records[stop+1]['args']==['SM400']
                assert records[stop+2]['op']=='$MOV' and records[stop+2]['args']==['"Q"','D13272Z16']
                row['disabled_prefix_witness']=dict(prefix=prefix,requested_destination='D13276',subsequent_assignment_destination='D13275',
                    note='Stops before RIGHT. Its enable is false after index preparation has replaced Z16=4 with Z16=3. The next independent $MOV uses that unchanged index; RIGHT is never evaluated by this witness.')
            if c['case'] in INDEXED_EXPECTED:
                obs={}
                for name in INDEXED_EXPECTED[c['case']]:
                    a=next(a for a in model['declarations'] if a['owner']=='MAIN' and a['name']==name);family=a['allocated_family']
                    obs[name]=dict(address=family+(format(a['number'],'X') if family in ('B','W') else str(a['number'])),type=a['data_type'])
                witness=evaluate(records,obs,allow_boolean=True)
                assert witness['observations']==INDEXED_EXPECTED[c['case']],(c['case'],witness['observations'])
                if c['case'] in ('bool-inout-member-reused','BOOL-B-member-two-bits','BOOL-B-member-B-source','NOT-member-alias-B'):
                    a=next(a for a in model['declarations'] if a['owner']=='MAIN' and a['name']=='probeArray');family=a['allocated_family']
                    actual=dict(address=family+(format(a['number']+1,'X') if family=='B' else str(a['number']+1)),type='BOOL')
                    check=evaluate(records,{'actual_array_bit':actual},allow_boolean=True)
                    assert check['observations']['actual_array_bit'] is False
                    member_result='probeR2' if c['case']=='NOT-member-alias-B' else 'probeR0'
                    row['member_alias_counterexample']=dict(member_read=witness['observations'][member_result],actual_array_bit=False,actual_binding=actual,
                        reason='Last static port binding points to a released IN_OUT bit slot. An M slot or same-type B slot is reused for a true enable capture; a separate M-derived capture in B leaves that old slot false.')
                row['finite_bool_word_witness']=dict(bindings=obs,**witness)
                if c['case']=='BOOL-output-binary-index-alias':
                    a=next(a for a in model['declarations'] if a['owner']=='MAIN' and a['name']=='probeArray')
                    assert a['allocated_family']=='M'
                    operand='M'+str(a['number'])+'Z16'
                    stop=next(i for i,r in enumerate(records) if r.get('op')=='LD' and r.get('args')==[operand])
                    prefix=evaluate(records[:stop],{
                        'index':dict(address='Z16',type='INT'),
                        'caller_element':dict(address='M'+str(a['number']+1),type='BOOL'),
                        'reread_element':dict(address='M'+str(a['number']+2),type='BOOL')},allow_boolean=True)
                    assert prefix['observations']==dict(index=2,caller_element=True,reread_element=False)
                    row['output_reference_reread']=dict(native_operand=operand,requested_address='M'+str(a['number']+1),
                        reread_address='M'+str(a['number']+2),prefix=prefix,
                        basis='The scalar OUTPUT formal still contains the first caller Z16 binding. Preparing the right local array changes Z16 before LD of that formal. This is an initialized offline address/value witness, not PLC execution.')
            rows.append(row)
    result=dict(groups=groups,cases=rows,accepted=sum(r['accepted'] for r in rows),rejected=sum(not r['accepted'] for r in rows),
                before_native_matches=sum(r['accepted'] and r['before_native_prediction_equal'] is True for r in rows),
                corrected_source_matches=sum(r.get('corrected_prediction_equal',False) for r in rows),
                typed_allocations_verified=sum(r.get('typed_allocations_verified',0) for r in rows),
                temporary_creates_verified=sum(r.get('temporary_creates_verified',0) for r in rows),
                slot_selections_verified=sum(r.get('slot_selections_verified',0) for r in rows),
                operand_reacquisitions_verified=sum(r.get('operand_reacquisitions_verified',0) for r in rows),
                scope='Q03UDV controlled SCPI-derived ST, including a typed slice of the original Keypad FB. Source-only output prediction versus native compiler, independent native decoder, fresh ProgramCheck, export and reopen. One finite initialized prefix witness stops before RIGHT and only resolves the output address. No PLC/simulator execution or conversion string-format claims.',
                findings=[
                    'WORD_TO_STR emits BINHA, INT_TO_STR emits BINDA, without an explicit target STRING capacity operand. Capacity 1, 4/6 and 12 controls pass native checking; no runtime output-format or memory-write claim follows from that alone.',
                    'INT conversion accepts a direct positive/negative literal and arithmetic materialization. Dynamic INT/WORD array arguments are copied to a reusable word slot before conversion; the request type is D68 even with a W pool, which prevents reuse of stored W87 slots.',
                    'RIGHT emits a separate enable rung, then source/destination/count operands; it restores an always-on rung if subsequent statements need it. The first-statement and consecutive-call counterexample corrected the initial redundant-LD prediction.',
                    'Direct dynamic conversion assignment is rejected before ProgramCheck with 0x050c9066. Four RIGHT cases with two dynamic array arguments generate PCode but fresh ProgramCheck rejects 0x050c9322, including same-index, constant-count and disabled-enable controls. Rejection localizes to the initial LD of a generated LD/LD/DMOV/ANB/RIGHT sequence; its underlying checker rule is not recovered.',
                    'A scalar intermediate, a dynamic INPUT capture, or an IN_OUT copy allows the measured RIGHT array-source/array-destination operation to pass checking. These controls do not establish a general safe rewrite.',
                    'An indexed OUTPUT alias inside a FB can instead pass checking while an internal RIGHT source index overwrites Z16. The finite prefix witness resolves D13275, one word before the caller-requested D13276.',
                    'The original Keypad WORD conversion, RIGHT and input-clear slice is reproduced for scalar and dynamic WORD IN_OUT bindings, including recomputed-index copy-back. The whole original FB is outside this experiment.'])
    if enabled:
        result['scope']='Q03UDV controlled SCPI-derived ST. Native compile, independent native lexical decode, fresh backend checks, export and reopen. Finite initialized BOOL/INT witnesses for MOV gating and one prefix-only address witness; no PLC execution, no general Boolean compiler or safe-generation claim.'
        result['findings']=[
            'LEFT and integer MOV reproduce the two-dynamic-index ProgramCheck rejection 0x050c9322. Their Z18 restoration follows the same enabled-operand consumer as RIGHT: callsite 0x86574 -> forwarder 0x99a40 -> virtual slot 0x28 -> observed implementation 0xcab70. Native trace selects Z18 at return RVA0xcaec0.',
            'Enabled instructions accept scalar BOOL, NOT and the measured INT>literal condition; an INT variable alone rejects before ProgramCheck with 0x500c8029.',
            'A complex enable with later array/arithmetic preparation is captured into a reusable M bit slot before that preparation. Without such preparation, the measured enable remains a direct LD/LDI/comparison rung. Two initial forward predictions missed these captures and remain preserved.',
            'BOOL INPUT NOT, comparison, OR and dynamic-array expressions allocate fresh physical M buffers (caller0xca1cf), bypassing slot selection. The measured slots use M77; unrelated word arithmetic uses D68.',
            'A one-bit M pool supports two sequential gated indexed MOV instructions by reusing the released bit slot. Two static BOOL INPUT captures with that one-bit pool reject 0x050f1217, not the word-pool code0x050f1218.',
            'Double NOT is simplified to the direct BOOL alias. In the finite initialized witness, clearing its overlapping IN_OUT suppresses MOV and leaves result9; OR with a second variable captures the earlier true value and produces result123.',
            'Disabled RIGHT still has unconditional index preparation. The prefix witness reaches false enable with Z16=3 rather than the caller output offset4; the following independent assignment uses the displaced address.',
            'The first OR implementation mistakenly used token0x08 (ORP), making both OR forward byte predictions fail. Independent native lexical decoding exposed the spelling error; the corrected model uses the catalog/native token0x06. Original incorrect predictions are preserved.',
            'The initial static caller-boundary search found no triple-INT3 marker and incorrectly chose RVA0x2; it is retained explicitly as FAILED. Corrected instruction-aligned callsite and forwarding-function disassembly are the static evidence.']
    if indexed_banks:
        result['scope']='Q03UDV controlled SCPI-derived ST, native compiler and independent native decoder, fresh backend checks/export/reopen, finite initialized M/B bit and D/W word-memory witnesses. No PLC execution or general safe-generation claim.'
        result['findings']=[
            'An indexed BOOL enable is read directly if no later data-argument preparation is needed. If a subsequent input/output argument needs arithmetic or indexing, the enable is captured in a bit slot before that preparation. Its index arithmetic may release a word slot that later data indexing reuses.',
            'B configuration overrides M for physical bit temporaries and fresh BOOL INPUT buffers; exhaustion does not fall back to available M. Ordinary BOOL declarations still search M then B. Native allocator initialization sets default77 at0x311d2 and overrides it with66 at0x3121d after the B range check.',
            'B bit slots can be reused while W word slots independently hold index arithmetic. A one-bit B range supports sequential gates but rejects two static INPUT captures with0x050f1217.',
            'A cached indexed BOOL enable and scalar NOT retain their source operand bank type: M requests77 while physical allocation into B stores66. The original single indexed capture forward PCode prediction was exact but its requested-type metadata was wrong; native hooks exposed this independently. Released B slots cannot satisfy later77 requests, and a one-bit B range rejects repeated M-array enables and the measured BOOL IN_OUT followed by NOT of an M result. B-array enable and BOOL IN_OUT controls request66 and reuse that bit.',
            'A FB OUTPUT already bound to Z16 is not restored when its body indexes a BOOL enable. The finite witness leaves array[1]=20 and writes123 to array[2]. Literal output and caller-side INPUT capture controls instead write123 to array[1].',
            'A false indexed enable still changes Z16. The following independent assignment consequently writes456 to array[2], leaving the caller-requested array[1]=20.',
            'Capturing the indexed enable does not repair the separate two-dynamic-data-operand lowering: fresh ProgramCheck still rejects its generated Z18 restore rung with0x050c9322.',
            'Dynamic BOOL IN_OUT copies use LD/OUT and recompute the index for copy-back. OUT writes false explicitly; conditional body skip/take controls preserve or clear the copied bit before writing to the newly selected element. Both original branch predictions inserted an extra LD SM400 before the label; those failed byte predictions are preserved.',
            'A BOOL member read retains the static IN_OUT temporary binding after release. Reusing the measured M slot for a true enable makes the member read true while the actual array bit remains false. The initial one-bit B control instead rejects because NOT of an M result requests77 and cannot reuse the stored66 slot. With two B bits it compiles and the member remains false; moving the source operand to B permits reuse and the member becomes true again.',
            'NOT of an indexed BOOL uses LDI directly when no later preparation is needed. A reusable enable capture retains the array M77 type even while stored in B66; a BOOL INPUT capture instead requests configured B66 and bypasses slot selection. Two new conditional enabled-tail controls confirm removal of the unused rung before the closing label.',
            'NOT of a connected BOOL formal and a qualified member follows the translated operand bank, including a fresh B INPUT buffer or B IN_OUT slot. A later member-derived NOT capture can reuse the released B IN_OUT slot and change that member while its actual array bit remains false.',
            'Two-leaf OR/AND result captures retain the original left operand type, not a universal configured BOOL type. Mixed M/B OR controls change77 versus66 requests when source order is reversed; measured BOOL results remain identical. Original scalar M OR predictions incorrectly reused B slots and remain preserved, including a one-bit precheck rejection.',
            'Two dynamic BOOL leaves reserve a configured-bank left capture before reserving the full enable or fresh INPUT buffer. Their index instructions are emitted later. The full OR/AND result still requests the original M left type; it does not reuse the intermediate B slot. A one-bit B pool rejects both the extra data-preparation and INPUT forms, while two-bit controls pass.',
            'A scalar left leaf remains directly addressable while the right index is prepared, so that form needs no bit capture. A dynamic left leaf followed by a scalar right leaf likewise needs no internal capture. The finite initialized witnesses distinguish OR true from AND false without PLC execution.',
            'A scalar BOOL OUTPUT formal can hide an indexed caller address. It remains uncaptured when the right binary leaf prepares a new index, and the subsequent formal read then selects array[2] instead of the caller array[1]. The native byte prediction is exact; the initialized offline result is false while literal/scalar OUTPUT and copied IN_OUT controls give true. All four fresh-check/export/reopen controls pass.']
    if direct_stores:
        result['scope']='Q03UDV controlled SCPI-derived direct BOOL stores. Source predictions versus native bytes, independent lexical decoding, allocation and existing-address reacquisition hooks, fresh checks/export/reopen, finite initialized BOOL/INT witnesses. No PLC execution or general compiler/generation claim.'
        result['findings']=[
            'A stable scalar, scalar NOT or the measured INT>literal comparison is loaded after destination index preparation; NOT/comparison use direct LDI/LD> without a bit capture. Indexed/NOT-indexed sources and measured binary OR/AND use configured M/B bit captures before destination preparation. FALSE is explicitly written by OUT. Both original comparison forward byte predictions inserted an unnecessary capture and remain preserved.',
            'Unlike the measured instruction-enable context, direct BOOL stores request configured B66 even from M arrays. Two M-derived stores reuse a single B bit. The original forward byte prediction could be exact while its requested-type metadata was wrong; the repeated-store prediction instead reported unsupported. Those original results remain preserved.',
            'The two-index binary expression reserves an internal left capture and a separate assignment result capture. One B bit rejects0x050f1217; two bits pass and both slots can be reused by a subsequent store. M-source/B-destination and equal-index controls pass; equal dynamic syntax still emits both index preparations and a bit capture.',
            'The captured assignment result is released before destination preparation, then reacquired at the existing address without fresh slot selection. Native caller0xccdfa requests configured bit type and the saved address; each saved table trace changes released state2 to active state1. Final consumption releases it again.']
    if recursive:
        result['scope']='Q03UDV controlled SCPI-derived recursive OR/AND and leaf/comparison XOR slice. Byte predictions, independent native lexical decoding, typed/temporary allocation observations, fresh checks/export/reopen and finite initialized offline witnesses. Compound XOR operands and compound NOT remain unsupported by the source model.'
        result['findings']=[
            'Nested OR/AND can combine a stable right expression with ORB/ANB without another bit capture. A composite left expression is captured before preparing a later indexed right leaf, even when its own leaves are scalar.',
            'Nested left captures are reserved before emitted index arithmetic. A three-index left chain passes with two B bits and rejects0x050f1217 with one B bit. All five accepted forward cases match their saved before-native bytes.',
            'Indexed right subtrees reserve their own captures before the parent left-result capture, after any left-child captures. Their emitted condition is combined with the saved left result or a stable left leaf using AND/OR. A both-indexed-tree control needs three B bits and rejects with two; it cannot release/reuse a child slot before the whole-tree reservation pass.',
            'Measured scalar NOT leaves append with ANI/ORI. Indexed INT>literal comparisons combine directly with Boolean conditions; an OR> right leaf and an indexed LD> left condition are reproduced.',
            'XOR expands into two AND branches joined by ORB. A left index with stable right scalar has no capture; an indexed right operand is captured. Two indexed operands need two configured-bank captures. NOT and comparison operands use opposite LD/LDI or comparison variants for the second branch.',
            'XOR context composition retains configured-bank internal captures, left-bank requested type for a whole instruction enable, configured whole direct-store capture and a distinct fresh INPUT buffer. The first INPUT experiment used invalid named-output spelling => and remains an explicitly classified source-design failure, not an XOR or pool limit.']
    if general:
        result['scope']='Controlled Q03UDV IF conditions and typed INT/WORD relations. The real Keypad seven-WORD-comparison guard is transplanted from FX3U source with an explicit port rename; no original-project or cross-CPU equivalence claim. Native bytes, independent decoding, allocations, fresh checks/export/reopen and initialized offline branch witnesses.'
        result['findings']=[
            'A direct BOOL leaf or comparison is complemented before CJ. Compound logical conditions use the normal condition followed by INV and CJ. Closing labels omit an unused always-on rung; following statements restore it when needed.',
            'The real Keypad guard uses LD<> then six AND<> instructions, INV and CJ. Its WORD comparison literals are K0 for zero and H for the measured nonzero values. Accepted49 clears the IN_OUT word and writes123; excluded67 skips the body and preserves67/result9 in the finite witness.',
            'P labels are reserved sequentially. Without a configured automatic P range the source-identical discovery cases reject0x500c9004; two IF sites with one P label also reject. The paired project-range control preserves every other logical payload.',
            'Six new accepted forward conditions, including scalar NOT, INT<=, WORD equality, mixed OR and two consecutive IF sites, match saved before-native bytes. WORD relation constants are limited to0..32767; ELSE, compound NOT and nested IF remain outside this measured profile.']
    out=P/groups[-1];save(out/('condition-branch-analysis.json' if general else 'recursive-bool-analysis.json' if recursive else 'bool-store-analysis.json' if direct_stores else 'indexed-enable-analysis.json' if indexed_banks else 'enabled-instruction-analysis.json' if enabled else 'string-intrinsic-analysis.json'),result);save(out/'aggregate-check-correspondence.json',verify(groups))
    for name in (Path(__file__).name,'source_q_st_calls.py','source_q_direct_declarations.py','probe_cross_origin_st_calls.py','witness_st_conditional_transfers.py'):(out/('verified-'+name)).write_bytes((P/name).read_bytes())
    print(json.dumps({k:v for k,v in result.items() if k not in ('groups','cases','scope','findings')}))


if __name__=='__main__':main()
