"""Compare cache-free predictions with preserved native baselines."""
from pathlib import Path
import json
import sys
import traceback
ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'research')]
from gxw.lossless import inspect_project, sha256
from gxw.compiler_tables import parse_compiler_tables
from source_q_direct_projection import project_projection

P = Path(__file__).resolve().parent


def compare_native(predictions, directory, native):
    tables = parse_compiler_tables(next(s.raw for s in inspect_project((native/'native-saved.gxw').read_bytes()).streams if s.logical_name == 'CGTable.dat'))
    assignments = {}
    for record in tables.tables[1].records:
        pou = tables.pou_at(record.table_offset)
        for c in tables.components(pou):
            assignments[pou.name_bytes.hex()+':'+c.name_bytes.hex()] = c.user_info.hex()
    results = []
    for pred in predictions:
        index = pred['resource_index']; actual = (native/f'pcode-{index}-0.bin').read_bytes()
        ours = (directory/f'predicted-{index}.bin').read_bytes()
        diffs = [dict(identity=k, predicted=v, native=assignments.get(k)) for k, v in pred['assignments'].items() if assignments.get(k) != v]
        results.append(dict(index=index, program=pred['program'], records=pred['records'],
            byte_identical=ours == actual, predicted_sha256=sha256(ours), native_sha256=sha256(actual), allocation_differences=diffs))
    return results


def main():
    out = P/'q-direct-declarations-without-cache-v2'; out.mkdir(exist_ok=False)
    for name in ['compare_q_direct_projection.py', 'source_q_direct_projection.py', 'source_q_direct_declarations.py', 'source_q_call_connections.py', 'source_q_label_binding.py', 'source_q_allocation.py', 'source_q_width.py', 'q-width-static-tables.json']:
        (out/name).write_bytes((P/name).read_bytes())
    plans = [dict(case='real-'+f.parent.name, source=f, native=f.parent)
             for f in sorted((P/'noeul-native-batch').glob('case-*/input.gxw'))]
    for row in json.loads((P/'q-declaration-cache-authority/comparison.json').read_text(encoding='utf-8')):
        plans.append(dict(case='changed-'+row['case'], source=P/'q-declaration-cache-authority'/row['case']/'input.gxw', native=Path(row['native_directory'])))
    # Store every prediction before opening native outputs in this run.
    predictions = {}; results = []
    for plan in plans:
        directory = out/plan['case']; directory.mkdir()
        try:
            rows = project_projection(plan['source'].read_bytes())
            for row in rows:
                (directory/f'predicted-{row["resource_index"]}.bin').write_bytes(row.pop('output'))
            predictions[plan['case']] = rows
            (directory/'prediction.json').write_text(json.dumps(rows, indent=2), encoding='utf-8')
        except Exception as exc:
            predictions[plan['case']] = dict(error=type(exc).__name__+': '+str(exc), traceback=traceback.format_exc())
            (directory/'prediction-error.json').write_text(json.dumps(predictions[plan['case']], indent=2), encoding='utf-8')
    for plan in plans:
        directory = out/plan['case']; rows = predictions[plan['case']]
        outcome = json.loads((plan['native']/'outcome.json').read_text(encoding='utf-8'))
        row = dict(case=plan['case'], source=str(plan['source']), native=str(plan['native']))
        if outcome['compiler_rejected']:
            row.update(handling='not-checkable-native-rejected', prediction=rows if isinstance(rows, dict) else 'available', diagnostics=outcome['diagnostics'])
        elif isinstance(rows, dict):
            row.update(rows)
        elif not rows:
            row.update(handling='no-task-bound-programs')
        else:
            row.update(programs=compare_native(rows, directory, plan['native']))
        results.append(row)
        (directory/'comparison.json').write_text(json.dumps(row, indent=2), encoding='utf-8')
    (out/'comparison.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
    programs = [p for r in results for p in r.get('programs', [])]
    print(json.dumps(dict(projects=len(results), programs=len(programs), exact=sum(p['byte_identical'] for p in programs),
        records=sum(p['records'] for p in programs), exceptions=[r for r in results if 'programs' not in r],
        failures=[r for r in results if any(not p['byte_identical'] or p['allocation_differences'] for p in r.get('programs', []))])))


if __name__ == '__main__':
    main()
