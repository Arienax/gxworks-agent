"""Exercise native formal binding using an original, isolated library FB."""
from pathlib import Path
from dataclasses import replace
import sys, json, base64, zipfile
ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'research')]
from gxw.lossless import inspect_project, sha256
from gxw.structured_pou import parse_structured_pou
from gxw.structured_pou_writer import serialize_structured_pou
from gxw.declarations import parse_declarations, edit_declarations, serialize_declarations
from gxw.project_metadata import mark_observed_source_compile_pending
from probe_gxw_library_archive import decode_library_archive, encode_library_literals
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import prepare, trace_prepared
from native_gxw_tokens import native_batch, native_il_projection, DEFAULT_DLL

P = Path(__file__).resolve().parent
out = P / 'native-graph-inout-array-type-trace'
out.mkdir(exist_ok=False)
(out / 'probe.py').write_bytes(Path(__file__).read_bytes())
with zipfile.ZipFile(ROOT / 'research/evidence/gxw-generation-20260910.zip') as archive:
    source = archive.read('fresh_fbd_compile.gxw')
streams = {s.logical_name: s.raw for s in inspect_project(source).streams if s.logical_name}
logical = '1.Program.pou'
program = parse_structured_pou(streams[logical], logical_name=logical)
alias = 'FLOW_ARRAY'
groups = {
    'in': 'VAR_INPUT\r\n SIGNAL: BOOL:=FALSE;[FALSE, 1, ];\r\nEND_VAR\r\n',
    'out': 'VAR_OUTPUT\r\n RESULT: BOOL:=FALSE;[FALSE, 1, ];\r\nEND_VAR\r\n',
    'inout': 'VAR_IN_OUT\r\n STATE: ARRAY[0..1] OF INT:=[2(0)];[FALSE, 2, ];\r\nEND_VAR\r\n',
}
body = """'IL'
BODY
 WORKSPACE
 END_WORKSPACE
 NET_WORK
  NETWORK_TYPE := NWTYPEIL ;
  NETWORK_BODY
TABINFO   6, 12
LD STATE[0]
ADD 1
ST STATE[1]
LD SIGNAL
ST RESULT
  END_NETWORK_BODY
 END_NET_WORK
END_BODY
END_FUNCTION_BLOCK
""".replace('\n', '\r\n')
library_raw = streams['IECFunction.lif']
plain = decode_library_archive(library_raw[20:]).decoded
cases = [('matched', 'ARRAY[0..1] OF INT'), ('shifted', 'ARRAY[3..4] OF INT'), ('negative', 'ARRAY[-2..-1] OF INT')]
rows = []
for case, actual_type in cases:
    order=('in','out','inout'); reverse=False; gap=False
    directory = out / case
    directory.mkdir()
    appended = ('\r\n(*$SECTION:FX3U*)\r\nFUNCTION_BLOCK ' + alias + '\r\n' + ''.join(groups[k] for k in order) + body).encode('ascii')
    (directory / 'original-fb-source.txt').write_bytes(appended)
    nodes = []
    for n in program.nodes:
        if n.kind_code == 2:
            ports = tuple(replace(p, local_y=4) if gap and p.local_y == 3 else p for p in n.ports)
            n = replace(n, type_name=alias, ports=tuple(reversed(ports)) if reverse else ports,
                        bbox=replace(n.bbox, bottom=n.bbox.bottom + 1) if gap else n.bbox)
        elif n.symbol in ['T#1s', 'T#2s']:
            n = replace(n, symbol=('D10' if n.symbol == 'T#1s' else 'D20') if actual_type is None else ('BufferA' if n.symbol == 'T#1s' else 'BufferB'),
                        bbox=replace(n.bbox, top=n.bbox.top + 1, bottom=n.bbox.bottom + 1) if gap else n.bbox)
        nodes.append(n)
    labels = '1.Labels.lh'
    declarations = parse_declarations(streams[labels], logical_name=labels)
    replacements = {
        logical: mark_observed_source_compile_pending(serialize_structured_pou(replace(program, nodes=tuple(nodes))), logical_name=logical),
        labels: mark_observed_source_compile_pending(serialize_declarations(edit_declarations(declarations,
            upserts=[dict(name=n.symbol, data_type=alias, kind='function_block') for n in nodes if n.kind_code == 2])), logical_name=labels),
        'IECFunction.lif': library_raw[:20] + encode_library_literals(plain + appended),
    }
    if actual_type is not None:
        globals_name='Global1.gh'
        globals_doc=parse_declarations(streams[globals_name],logical_name=globals_name)
        replacements[globals_name]=mark_observed_source_compile_pending(serialize_declarations(edit_declarations(globals_doc,
            upserts=[dict(name='BufferA',data_type=actual_type,device='D10',iec_address='%MW0.10'),
                     dict(name='BufferB',data_type=actual_type,device='D20',iec_address='%MW0.20')])),logical_name=globals_name)
    changed = source
    receipts = []
    for name, raw in replacements.items():
        changed, receipt = patch_raw(changed, name, streams[name], raw)
        receipts.append(receipt)
    after = {s.logical_name: s.raw for s in inspect_project(changed).streams if s.logical_name}
    assert after == dict(streams, **replacements)
    path = directory / 'source.gxw'
    path.write_bytes(changed)
    (directory / 'mutation.json').write_text(json.dumps(dict(source_sha256=sha256(source), changed_sha256=sha256(changed),
        changed_streams=list(replacements), original_library_prefix='byte-identical after decompression',
        unrelated_payloads='byte-identical', receipts=receipts), indent=2))
    for attempt in range(3):
        native = directory / ('native' if not attempt else f'native-attempt-{attempt}')
        prepare(path, native, compile=True, export_project=True, snapshot_frontend=True, project_alias='ARRAYINOUT', analysis_version=3, analysis_queries=[dict(name='all',keys=[],symbol='',scope='',declared=0,plural=0)])
        process = trace_prepared(native, P / 'TraceArrayCompatibility.js')
        native_events = [json.loads(s) for s in (native / 'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
        if native_events[-1]['operation'] != 'NativeTemporaryDirectoryCollision':
            break
    events = [json.loads(s) for s in (native / 'events.jsonl').read_text().splitlines()]
    sources = []
    for e in events:
        p = e.get('payload', {})
        if p.get('event') == 'enter' and p.get('name') == 'Compile':
            buffers = {b['label']: b for b in p['buffers']}
            for k, b in buffers.items():
                if k.startswith('source_') and b['bytes']:
                    i = k.removeprefix('source_')
                    value = bytes.fromhex(b['bytes'])
                    assert len(value) == b['requested_size']
                    name = bytes.fromhex(buffers['name_' + i]['bytes']).split(b'\0')[0].decode('ascii', errors='backslashreplace')
                    filename = f'compile-{p["id"]}-{i}.sic'
                    (directory / filename).write_bytes(value)
                    sources.append(dict(name=name, file=filename, text=value.decode('ascii', errors='backslashreplace')))
    diagnostics = {json.dumps({k:v for k,v in d.items() if k != 'raw_base64'},sort_keys=True)
                   for e in native_events for d in e.get('reports', []) if d['kind'] in [2, 3]}
    row = dict(case=case, process=process, native_directory=str(native.relative_to(out)),
        native_exported=(native / 'native-saved.gxw').exists(), diagnostics=[json.loads(d) for d in sorted(diagnostics)],
        crt_checks=[e for e in native_events if e['operation'] == 'NativeCrtCharacterCase'], sources=sources,
        trace_errors=[e for e in events if e.get('type') == 'error' or e.get('payload', {}).get('event', '').endswith(('error', 'failed'))],
        formals=[e['payload'] for e in events if e.get('payload', {}).get('event') == 'native-callable-formals'],
        port_sort=[e['payload'] for e in events if e.get('payload', {}).get('event') == 'native-callable-sort'])
    code = native / 'pcode-0-0.bin'
    if row['native_exported'] and code.exists():
        answer, = native_batch([dict(mode='decode', input_base64=base64.b64encode(code.read_bytes()+b'\0').decode())], directory / 'decode', dll=DEFAULT_DLL, cpu_code=0x208)
        assert answer['return_code'] == '0x00000000' and answer['consumed_bytes'] == code.stat().st_size
        row['listing'] = native_il_projection(base64.b64decode(answer['output_base64']), encoding='gb18030')
        row['pcode_sha256'] = sha256(code.read_bytes())
    rows.append(row)
    (out / 'comparison.json').write_text(json.dumps(rows, indent=2))
    (directory / 'comparison.json').write_text(json.dumps(row, indent=2))
    print(json.dumps(dict(case=case, exported=row['native_exported'], diagnostics=row['diagnostics'], source=[s['text'] for s in sources if s['name']=='1'], listing=row.get('listing'))), flush=True)
