"""Research-only native grid graph against independently stated Boolean controls.

No PLC execution or stateful edge simulation. Raw cells remain intact, and
unobserved cell kinds are rejected. This does not change application semantics.
"""
from pathlib import Path
import itertools
import json
import struct
import sys

ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.token_pou import LadderToken
from gxw.token_listing import fx_operand_text

P=Path(__file__).resolve().parent

def graph(cells, tokens, metadata):
    width,height,size=metadata
    if width!=23 or not 1<=height<=24 or size!=8 or len(cells)!=0x2288:
        raise ValueError('unobserved cell envelope')
    nodes={}
    for y in range(height):
        for x in range(width):
            index=1+y*width+x
            raw=cells[index*8:index*8+8]
            flags,kind,offset,stored_index,step=struct.unpack('<BBHHH',raw)
            if any(raw) and stored_index!=index:raise ValueError('unexpected cell index')
            if flags&~15:raise ValueError('unobserved connection bits')
            if kind not in (0,0x80,4,8,0x14,0x40):raise ValueError(f'unsupported cell kind {kind:#x}')
            node=dict(x=x,y=y,index=index,flags=flags,kind=kind,offset=offset,step=step,raw_hex=raw.hex())
            if kind in (4,8,0x40):
                if offset>=len(tokens):raise ValueError('operand outside buffer')
                n=tokens[offset];operand=tokens[offset:offset+n]
                if n<4 or len(operand)!=n or operand[-1]!=n:raise ValueError('operand framing')
                node['device']=fx_operand_text(LadderToken(offset,operand))
            nodes[x,y]=node
    # Vertical flags connect the left junction of a cell. Horizontal elements
    # transfer a Boolean value from that junction to the next column.
    groups={}
    for x in range(width):
        group=0
        for y in range(height):
            if y:
                above=bool(nodes[x,y-1]['flags']&4)
                below=bool(nodes[x,y]['flags']&8)
                if above!=below:raise ValueError('unmatched internal vertical connection')
                if not above:group+=1
            groups[x,y]=(x,group)
    return dict(width=width,height=height,nodes=nodes,groups=groups)

def evaluate(g, values):
    incoming={};outputs={}
    for x in range(g['width']):
        for y in range(g['height']):
            node=g['nodes'][x,y];group=g['groups'][x,y]
            value=incoming.get(group,False)
            if x==0 and node['flags']&12:value=True
            if node['kind']==0x40:outputs[node['device']]=value
            if not node['flags']&1:continue
            kind=node['kind']
            if kind==4:value=value and values[node['device']]
            elif kind==8:value=value and not values[node['device']]
            elif kind==0x14:value=not value
            if x+1>=g['width']:raise ValueError('horizontal connection beyond buffer')
            dest=g['groups'][x+1,y]
            incoming[dest]=incoming.get(dest,False) or value
    return outputs

def main():
    out=P/'native-ladder-boolean-graph';out.mkdir(exist_ok=False)
    (out/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    # Expected formulae are specified from the control's intended graph,
    # independently of the vendor's output cell order and branch coordinates.
    expected={
        'contact':{'Y0':'X0'},'series':{'Y0':'X0 and X1'},'parallel':{'Y0':'X0 or X1'},
        'series-of-parallel':{'Y0':'(X0 or X1) and (X2 or X3)'},
        'parallel-of-series':{'Y0':'(X0 and X1) or (X2 and X3)'},
        'series-after-parallel':{'Y0':'(X0 or X1) and X2'},
        'parallel-after-series':{'Y0':'(X0 and X1) or X2'},
        'nested-block':{'Y0':'X0 or (X1 and X2 and (X3 or X4))'},
        'two-coils':{'Y0':'X0','Y1':'X0'},
        'branch-two':{'Y0':'X0 and X1','Y1':'X0 and X2'},
        'branch-three':{'Y0':'X0 and X1','Y1':'X0 and X2','Y2':'X0 and X3'},
        'nested-stack':{'Y0':'X0 and X1 and X2','Y1':'X0 and X1 and X3','Y2':'X0 and X4'},
        'after-coil-contact':{'Y0':'X0','Y1':'X0 and X1'},
        'ldi':{'Y0':'not X0'},'ani':{'Y0':'X0 and not X1'},'ori':{'Y0':'X0 or not X1'},
        'inv':{'Y0':'not X0'},
    }
    source=P/'native-ladder-topology';rows=json.loads((source/'comparison.json').read_text())
    results=[]
    for i,row in enumerate(rows):
        if row['case'] not in expected:continue
        n=row['native'];assert n['return_code']=='0x00000000'
        g=graph((source/'ladder'/f'{i:04}.cells.bin').read_bytes(),(source/'ladder'/f'{i:04}.tokens.bin').read_bytes(),n['metadata'])
        names=sorted({r['device'] for r in g['nodes'].values() if r['kind'] in (4,8)})
        differences=[]
        for bits in itertools.product((False,True),repeat=len(names)):
            values=dict(zip(names,bits));actual=evaluate(g,values)
            wanted={device:eval(formula,{'__builtins__':{}},values) for device,formula in expected[row['case']].items()}
            if actual!=wanted:differences.append(dict(inputs=values,actual=actual,expected=wanted))
        result=dict(case=row['case'],assignments=2**len(names),differences=differences,
            meaningful_cells=[r for r in g['nodes'].values() if r['kind'] not in (0,0x80)])
        results.append(result)
        print(json.dumps({k:v for k,v in result.items() if k!='meaningful_cells'}),flush=True)
    (out/'comparison.json').write_text(json.dumps(results,indent=2),encoding='utf-8')

if __name__=='__main__':main()
