"""Compare native stored body identities with native scalar instance links."""
from pathlib import Path
from collections import Counter
import json,struct,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.compiler_debug import parse_compiler_debug
from gxw.project_metadata import read_project_text_context
from probe_gxw_compiled_dependencies import inspect_compiled_dependencies
P=Path(__file__).resolve().parent
out=P/'compiled-body-dependency-comparison';out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
(out/'probe_gxw_compiled_dependencies.py').write_bytes((ROOT/'research/probe_gxw_compiled_dependencies.py').read_bytes())
directories=[]
for experiment in ['q-compile-root-validation','q-fb-compile-dependencies','q-declaration-compile-dependencies','q-global-compile-dependencies','q-global-fb-calls']:
    cases=json.loads((P/experiment/'comparison.json').read_text(encoding='utf-8'))['cases']
    directories += [P/experiment/c['native_directory'] for c in cases if c['native']['returncode']==0 and c['native']['compile_completed'] and not c['native']['compiler_rejected']]
reference=json.loads((P/'q-task-reference-corpus-v2/comparison.json').read_text(encoding='utf-8'))
directories += [P/c['native_task_inventory']['directory'] for c in reference['projects'] if c['native_task_inventory'] and c['native_task_inventory']['complete']]
for group in ['ST-nested-FB-controls','ST-repeated-FB-controls','structured-graph-location-controls','graph-library-call-controls']:
    directories += sorted(d/'native' for d in (P/group).iterdir() if d.is_dir() and (d/'native/native-saved.gxw').exists())
rows=[];handling=Counter();negative_source=None
for directory in directories:
    identity=str(directory.relative_to(P));native=json.loads((directory/'outcome.json').read_text(encoding='utf-8'))
    if native['returncode']!=0 or not native['compile_completed'] or native['compiler_rejected']:
        rows.append(dict(directory=identity,status='native compile not accepted'));continue
    saved=directory/'native-saved.gxw'
    if not saved.exists():rows.append(dict(directory=identity,status='no exported debug snapshot'));continue
    image=saved.read_bytes();streams={s.logical_name:s.raw for s in inspect_project(image).streams if s.logical_name}
    context=read_project_text_context(next(v for k,v in streams.items() if k.endswith('.prj')))
    assert context['text_encoding'] is not None
    table=(directory/'compiler_DZComp/CGTable.dat').read_bytes();debug=streams['DebugInformation2.dat']
    result=inspect_compiled_dependencies(table,debug,encoding=context['text_encoding'])
    result['native_provenance']=dict(directory=identity,input_sha256=sha256((directory/'input.gxw').read_bytes()),export_sha256=sha256(image),
        outcome_sha256=sha256((directory/'outcome.json').read_bytes()),project_context=context)
    index=len(rows);(out/f'comparison-{index:02d}.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    gaps=[e for e in result['elements'] if e['handling'] not in ('explicit-reference-agrees','external-library-body')]
    rows.append(dict(directory=identity,status='checked',summary=result['summary'],gaps=len(gaps)))
    handling.update(result['summary']['handling'])
    if gaps:print(json.dumps(dict(directory=identity,gaps=gaps)),flush=True)
    if directory==P/'q-global-fb-calls/valid-global-call/native':negative_source=(table,debug)
summary=dict(project_snapshots=len(rows),checked=sum(r['status']=='checked' for r in rows),body_elements=sum(handling.values()),handling=dict(handling),gaps=sum(r.get('gaps',0) for r in rows))
(out/'comparison.json').write_text(json.dumps(dict(summary=summary,cases=rows),indent=2),encoding='utf-8')
print(json.dumps(summary),flush=True)
assert summary['gaps']==0
assert negative_source
table,debug=negative_source;parsed=parse_compiler_debug(debug);element=parsed.elements[1]
def encode(names):
    def text(value):return struct.pack('<I',len(value)+1)+value+b'\0'
    return text(element.resource_bytes)+struct.pack('<6i',*element.fields)+b''.join(text(n) for n in names)+struct.pack('<i',element.kind_code)+text(element.extra_name)+struct.pack('<i',element.offset_table_index)
assert encode(element.names)==element.raw
negatives=[]
for label,field,value,expected in [('missing-owner',3,b'NoSuchOwner','unresolved-owner'),
        ('missing-instance',4,b'NoSuchInstance','unresolved-instance-path'),
        ('wrong-definition',2,b'MAIN','instance-definition-mismatch'),
        ('array-syntax',4,b'GlobalInstance[0]','unsupported-instance-path'),
        ('unproved-case-fold',4,b'globalinstance','unresolved-instance-path')]:
    names=list(element.names);names[field]=value;replacement=encode(names)
    altered=debug[:element.offset]+replacement+debug[element.offset+len(element.raw):]
    result=inspect_compiled_dependencies(table,altered,encoding='cp1252');actual=result['elements'][1]['handling']
    assert actual==expected
    (out/(label+'-debug.bin')).write_bytes(altered)
    negatives.append(dict(case=label,handling=actual,expected=expected,debug_sha256=sha256(altered)))
(out/'negative-controls.json').write_text(json.dumps(dict(source_table_sha256=sha256(table),source_debug_sha256=sha256(debug),cases=negatives),indent=2))
print(json.dumps(dict(negative_controls=len(negatives),exact=True)),flush=True)
