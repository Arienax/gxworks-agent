"""Keep source layout hypotheses separate from captured native declarations."""
from pathlib import Path
import base64
import json
import struct
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'research')]
from gxw.declarations import _Reader
from gxw.source_header import source_payload_offset
from gxw.lossless import inspect_project, sha256
from probe_gxw_library_sources import snapshot_library_pous, observed_library_declarations

P = Path(__file__).resolve().parent
SOURCE = P / 'cross-family-source-holdouts/case-00/input.gxw'
NATIVE = P / 'fx3g-library-native-baseline/native-1'


def source_rows(raw, local):
    r = _Reader(raw, source_payload_offset(raw))
    owner, return_type = None, None
    if local:
        owner = r.string()
        flags = r.take(8)
        unknown = r.string()
        return_type = r.string()
    count = r.uint()
    if count > (len(raw) - r.offset) // 68:
        raise ValueError('unbounded source declaration count')
    rows = []
    for _ in range(count):
        start = r.offset
        row = dict(name=r.string(), data_type=r.string(), class_code=r.uint(),
                   device=r.string(), iec_address=r.string(), mode=r.uint())
        extension_start = r.offset
        slots = []
        if row['mode'] == 1:
            n = r.uint()
            if n > (len(raw) - r.offset) // 12:
                raise ValueError('unbounded structure member count')
            slots = [(r.string(), r.string()) for _ in range(n)]
        elif row['mode'] == 2:
            slots = [r.string(), r.string(), r.uint(), r.string(), r.string()]
        elif row['mode'] != 0:
            raise ValueError('unobserved source value mode')
        row.update(extension_hex=raw[extension_start:r.offset].hex(), extension_slots=slots,
                   initial_value=r.string(), unknown_text=r.string(), record_id=r.uint(),
                   comment=r.string(), array_marker=r.uint(), type_code=r.uint(), type_reference=r.string())
        row.update(offset=start, size=r.offset-start)
        rows.append(row)
    return dict(owner=owner, return_type=return_type, rows=rows, trailer_hex=raw[r.offset:].hex())


def native_global_rows(raw, *, structure=False):
    # Independent ANSI frontend ABI: size, two opaque DWORDs, count; each row
    # has ID/name/type/class and device/IEC/initial/comment strings.
    if raw[:4] != b'@\0"\x01' or struct.unpack_from('<I',raw,64)[0] != len(raw)-64:
        raise ValueError('unobserved native table envelope')
    cursor = 76
    def integer():
        nonlocal cursor
        value, = struct.unpack_from('<I', raw, cursor)
        cursor += 4
        return value
    def string():
        nonlocal cursor
        size = integer()
        data = raw[cursor:cursor+size]
        if size < 1 or len(data) != size or data[-1:] != b'\0' or b'\0' in data[:-1]:
            raise ValueError('invalid native global declaration text')
        cursor += size
        return data[:-1].decode('cp1252')
    count = integer()
    if count > (len(raw)-cursor)//(24 if structure else 40):
        raise ValueError('unbounded native global count')
    rows = []
    for _ in range(count):
        row = dict(record_id=integer(), name=string(), data_type=string())
        if not structure:
            row.update(class_code=integer(), device=string(), iec_address=string())
        row.update(initial_value=string(), comment=string())
        rows.append(row)
    if cursor != len(raw):
        raise ValueError('unframed native global tail')
    return rows


def main():
    snapshot = json.loads((NATIVE / 'frontend-snapshot.json').read_text(encoding='utf-8'))
    native_pous = {(r['library'], r['name']): r for r in snapshot_library_pous(snapshot)}
    results = []
    for s in inspect_project(SOURCE.read_bytes()).streams:
        name = s.logical_name or ''
        if not name.endswith(('.lnl', '.lng', '.gh', '.lh')):
            continue
        row = dict(logical_name=name, sha256=sha256(s.raw))
        try:
            d = source_rows(s.raw, name.endswith(('.lnl', '.lh')))
            row.update(source=d)
            if name.endswith('.lnl'):
                lib = name.rsplit('\\', 1)[1][:-4]
                native = observed_library_declarations(base64.b64decode(native_pous[(lib, d['owner'])]['declaration_raw_base64']))
                fields = ('record_id', 'name', 'data_type', 'class_code', 'initial_value', 'comment')
                a = [{k:r[k] for k in fields} for r in d['rows']]
                b = [{k:r[k] for k in fields} for r in native['rows'] if r['record_id'] != 0xffffffff]
                returns = [r for r in native['rows'] if r['record_id'] == 0xffffffff]
                return_match = (len(returns) == 1 and returns[0]['name'] == d['owner']
                    and returns[0]['data_type'] == d['return_type'] and returns[0]['class_code'] == 4) if d['return_type'] else not returns
                row.update(native_rows=native['rows'], native_fully_framed=native['fully_framed'],
                           return_type_match=return_match, native_match=a == b and return_match)
            elif name == 'Global1.gh':
                native = native_global_rows((NATIVE / 'global-0-frontend.bin').read_bytes())
                fields = ('record_id', 'name', 'data_type', 'class_code', 'initial_value', 'comment')
                row.update(native_rows=native, native_match=[{k:r[k] for k in fields} for r in d['rows']] ==
                           [{k:r[k] for k in fields} for r in native])
        except (ValueError, KeyError) as e:
            row['gap'] = str(e)
        results.append(row)
    out = P / 'fx3g-declaration-framing-hypothesis-v3.json'
    if out.exists():
        raise FileExistsError(out)
    out.write_text(json.dumps(results, indent=2), encoding='utf-8')
    print(json.dumps(dict(tables=len(results), rows=sum(len(r.get('source',{}).get('rows',[])) for r in results),
        compared=sum('native_match' in r for r in results), matches=sum(r.get('native_match') is True for r in results),
        problems=[dict(name=r['logical_name'], gap=r.get('gap'), match=r.get('native_match')) for r in results
                  if 'gap' in r or r.get('native_match') is False])))


if __name__ == '__main__':
    main()
