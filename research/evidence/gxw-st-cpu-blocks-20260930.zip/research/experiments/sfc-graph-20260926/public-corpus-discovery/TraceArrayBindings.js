// Observe component conversion and its caller; never replace or invoke code.
(()=>{
'use strict';const active=new Map();let seq=0;
function hex(p,n){return Array.from(new Uint8Array(p.readByteArray(n)),x=>x.toString(16).padStart(2,'0')).join('');}
function str(p,n){try{let s='';for(let i=0;i<n;i++){const c=p.add(i).readU8();if(c===0)return s;if(c>127)return null;s+=String.fromCharCode(c);}}catch(_){}return null;}
function loc(p){const m=Process.findModuleByAddress(p);return m?{module:m.name,rva:p.sub(m.base).toString()}:null;}
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='eccompiler_iec.dll')return;
 send({event:'array-observer-module',name:m.name,base:m.base.toString()});
 Interceptor.attach(m.findExportByName('Compile'),{onEnter(a){
  this.old=active.get(this.threadId);const names=[];const count=a[1].toInt32();
  if(count>=0&&count<=1024)for(let i=0;i<count;i++)names.push(str(a[2].add(i*28+8).readPointer(),512));
  active.set(this.threadId,names.includes('POU_01'));
  send({event:'array-observer-compile',names});
 },onLeave(){active.set(this.threadId,this.old);}});
 Interceptor.attach(m.base.add(0xa5650),{onEnter(a){
  if(!active.get(this.threadId))return;
  this.out=a[2];this.typ=a[3];this.row={event:'component-descriptor',sequence:++seq,kind:a[0].toInt32(),component_offset:a[1].toInt32(),
   caller:loc(this.returnAddress),stack:Thread.backtrace(this.context,Backtracer.ACCURATE).slice(0,10).map(loc)};
 },onLeave(r){if(!this.row)return;this.row.result=r.toInt32();this.row.raw_hex=hex(this.out,25);this.row.type=this.typ.readS32();send(this.row);}});
 Interceptor.attach(m.base.add(0x6db60),{onEnter(a){
  if(!active.get(this.threadId)||!(a[1].add(24).readU8()&0x10))return;
  send({event:'indexed-AST-descriptor-write',sequence:++seq,node:a[0].toInt32(),raw_hex:hex(a[1],25),caller:loc(this.returnAddress),
   stack:Thread.backtrace(this.context,Backtracer.ACCURATE).slice(0,10).map(loc)});
 }});
 Interceptor.attach(m.base.add(0x321b0),{onEnter(a){
  if(!active.get(this.threadId))return;
  this.row={event:'index-register-selection',sequence:++seq,requested:a[0].toInt32(),cpu_code:this.context.ecx.add(0x782).readU16(),caller:loc(this.returnAddress)};
 },onLeave(r){if(this.row){this.row.selected=r.toInt32();send(this.row);}}});
 for(const [name,rva] of [['array-extent-or-stride',0xa0b70],['array-lower-bound',0xa0c70]]){
  Interceptor.attach(m.base.add(rva),{onEnter(a){
   if(!active.get(this.threadId))return;
   const manager=this.context.ecx.add(0x86).readPointer().add(0x30).readPointer();
   const index=a[0].toInt32();if(index<0||index>1000000)return;
   const node=manager.add(0x40).readPointer().add(index*0x49);
   this.row={event:name,sequence:++seq,node:index,axis:a[1].toInt32(),node_kind:node.add(4).readU32(),reference:node.add(0x20).readU32(),node_raw_hex:hex(node,0x49),caller:loc(this.returnAddress)};
  },onLeave(r){if(this.row){this.row.result=r.toInt32();send(this.row);}}});
 }
}});
})();
