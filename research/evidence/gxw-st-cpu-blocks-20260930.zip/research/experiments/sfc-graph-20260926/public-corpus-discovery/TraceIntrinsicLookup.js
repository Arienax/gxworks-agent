(()=>{
"use strict";
const seen=new Set();
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=="eccompiler_iec.dll")return;
 Interceptor.attach(m.base.add(0xa0d70),{onEnter(a){this.name=null;try{let s="";for(let i=0;i<256;i++){const v=a[1].add(i).readU8();if(v===0){this.name=s;break;}if(v>127)break;s+=String.fromCharCode(v);}}catch(e){}this.caller=this.returnAddress.sub(m.base).toString();},onLeave(r){
  if(this.name===null)return;
  const id=r.toInt32(),key=this.name+"/"+id+"/"+this.caller;
  if(seen.has(key))return;seen.add(key);
  send({event:"intrinsic-name-lookup",name:this.name,result:id,caller_rva:this.caller});
 }});
}});
})();
