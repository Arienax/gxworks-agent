// Read-only observations of the pinned IEC compiler's Boolean call branch.
(()=>{
'use strict';const active=new Map();let seq=0;
function str(p,n){try{let s='';for(let i=0;i<n;i++){const c=p.add(i).readU8();if(!c)return s;if(c>127)return null;s+=String.fromCharCode(c);}}catch(_){}return null;}
function hex(p,n){return Array.from(new Uint8Array(p.readByteArray(n)),v=>v.toString(16).padStart(2,'0')).join('');}
function loc(p){const m=Process.findModuleByAddress(p);return m?{module:m.name,rva:p.sub(m.base).toString()}:null;}
function graph(manager,id){const rows=[],seen=new Set();const base=manager.add(0x40).readPointer();function visit(i,depth){if(i<=0||i>100000||seen.has(i)||depth>6)return;seen.add(i);const p=base.add(i*0x49);const links=[12,16,20].map(o=>p.add(o).readS32());rows.push({id:i,kind:p.add(4).readU32(),reference:p.add(32).readU32(),links,raw_hex:hex(p,73)});for(const link of links)visit(link,depth+1);}visit(id,0);return rows;}
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='eccompiler_iec.dll')return;
 Interceptor.attach(m.findExportByName('Compile'),{onEnter(a){this.prior=active.get(this.threadId);const names=[];const n=a[1].toInt32();if(n>=0&&n<=1024)for(let i=0;i<n;i++)names.push(str(a[2].add(i*28+8).readPointer(),512));active.set(this.threadId,names.includes('POU_01'));},onLeave(){active.set(this.threadId,this.prior);}});
 Interceptor.attach(m.base.add(0x808c0),{onEnter(a){
  if(!active.get(this.threadId))return;this.manager=this.context.ecx;this.id=a[0].toInt32();
  this.row={event:'call-specialized-generator',sequence:++seq,node:this.id,before_nodes:graph(this.manager,this.id)};
 },onLeave(){if(this.row){this.row.after_nodes=graph(this.manager,this.id);send(this.row);}}});
 Interceptor.attach(m.base.add(0x6b9b0),{onEnter(a){
  if(!active.get(this.threadId))return;this.out=a[2];this.row={event:'call-specialized-temporary-allocation',sequence:++seq,device_code:a[0].toInt32(),count:a[1].toInt32(),caller:loc(this.returnAddress),stack:Thread.backtrace(this.context,Backtracer.ACCURATE).slice(0,8).map(loc)};
 },onLeave(r){if(this.row){this.row.descriptor_hex=hex(this.out,25);this.row.result=r.toInt32();send(this.row);}}});
 Interceptor.attach(m.base.add(0xb1e00),{onEnter(a){
  if(!active.get(this.threadId))return;
  this.manager=this.context.ecx.add(0x86).readPointer().add(0x30).readPointer();this.id=a[0].toInt32();this.arg=a[1].toInt32();
  this.row={event:'call-specialized-argument-rewrite',sequence:++seq,node:this.id,argument_node:this.arg,options:[a[2].toInt32(),a[3].toInt32()],caller:loc(this.returnAddress),before_nodes:graph(this.manager,this.id)};
 },onLeave(r){if(this.row){this.row.after_nodes=graph(this.manager,this.id);this.row.result=r.toInt32();send(this.row);}}});
 Interceptor.attach(m.base.add(0x6dae0),{onEnter(a){
  if(!active.get(this.threadId)||a[1].toInt32()!==0x11f)return;
  this.manager=this.context.ecx;this.id=a[0].toInt32();this.row={event:'call-specialized-input-temporary',sequence:++seq,node:this.id,kind:a[1].toInt32(),caller:loc(this.returnAddress),before_nodes:graph(this.manager,this.id)};
 },onLeave(){if(this.row){this.row.after_nodes=graph(this.manager,this.id);send(this.row);}}});
 for(const [name,rva] of [['call-specialized-entry',0x82eff],['call-specialized-descriptor',0x82f7d]])Interceptor.attach(m.base.add(rva),{onEnter(){
  if(!active.get(this.threadId))return;const c=this.context,sp=c.esp,id=sp.add(0x270).readS32();
  send({event:name,sequence:++seq,name:str(sp.add(0x14).readPointer(),128),node:id,mode:sp.add(0x6c).readS32(),descriptor_hex:name==='call-specialized-descriptor'?hex(sp.add(0x94),25):null,nodes:graph(c.ebp,id)});
 }});
 Interceptor.attach(m.base.add(0x99f60),{onEnter(a){
  if(!active.get(this.threadId))return;
  const caller=loc(this.returnAddress);if(!caller||caller.rva!=='0x830a8')return;
  send({event:'call-specialized-emission',sequence:++seq,opcode:a[0].toInt32(),descriptor_hex:hex(a[1],25),caller});
 }});
}});
})();
