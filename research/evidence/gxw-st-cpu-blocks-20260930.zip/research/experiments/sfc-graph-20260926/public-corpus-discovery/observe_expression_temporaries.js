// Append inside the same scope as the allocation observer. Read-only hooks.
function temporarySlots(object) {
  const base=object.add(8).readPointer(),rows=[];
  if(base.isNull())return rows;
  for(let i=0;i<200;i++){
    const p=base.add(i*33),state=p.add(24).readU8();
    if(state===0)continue;
    rows.push({index:i,raw:hex(p,33),type:p.add(8).readU32(),
      operand:[p.add(12).readU32(),p.add(16).readU32()],count:p.add(20).readU32(),
      state,flag25:p.add(25).readU32(),flag29:p.add(29).readU32()});
  }
  return rows;
}
let tempSerial=0;
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='eccompiler_iec.dll')return;
 const specs=[
   [0x6d4c0,'request',7,'8b442408'],[0x6cc40,'select',2,'53555657'],
   [0x6ca00,'release-tail',1,'8b442404'],[0x6ca70,'transition-4-to-9',0,'5333d233'],
   [0x6cb60,'release-operand',3,'8b442404'],[0x6d000,'set-state',2,'518b4424'],
   [0x6d090,'transition-2-to-12',1,'83ec0853'],[0x6d1e0,'set-flag29',1,'8b442404'],
   [0x6d340,'clear-flag29',1,'83ec0853'],[0x6ce30,'reset-slots',0,'33d233c0']
 ];
 for(const [rva,name,n,guard] of specs){
  if(hex(m.base.add(rva),guard.length/2)!==guard){emit({event:'temporary-guard-error',rva,name});continue;}
  Interceptor.attach(m.base.add(rva),{
   onEnter(a){const c=contexts.get(this.threadId);if(!c)return;
    this.p=this.context.ecx;
    try{this.row={event:'temporary-slots',id:++tempSerial,compile_id:c.compile_id,name,rva,
      manager:this.p.toString(),caller:loc(this.returnAddress),args:Array.from({length:n},(_,i)=>a[i].toInt32()),
      before:name==='reset-slots'?null:temporarySlots(this.p)};}catch(e){emit({event:'temporary-observation-error',name,error:String(e)});}
   },
   onLeave(r){if(!this.row)return;try{this.row.result=r.toInt32();this.row.result_high=this.context.edx.toString();
     this.row.after=temporarySlots(this.p);if(name==='request'||name==='select'||JSON.stringify(this.row.before)!==JSON.stringify(this.row.after))emit(this.row);
    }catch(e){emit({event:'temporary-observation-error',name,error:String(e)});}}
  });
 }
 Interceptor.attach(m.base.add(0x6b9b0),{
  onEnter(a){const c=contexts.get(this.threadId);if(!c)return;this.p=this.context.ecx;
   try{this.output=a[2];this.row={event:'temporary-create',id:++tempSerial,compile_id:c.compile_id,
    manager:this.p.toString(),type:a[0].toInt32(),count:a[1].toInt32(),caller:loc(this.returnAddress),
    before_counters:[8,12,16].map(n=>this.p.add(n).readU32())};}
   catch(e){emit({event:'temporary-create-error',error:String(e)});}
  },onLeave(r){if(!this.row)return;try{this.row.result=r.toInt32();this.row.output=hex(this.output,25);
    this.row.after_counters=[8,12,16].map(n=>this.p.add(n).readU32());emit(this.row);
   }catch(e){emit({event:'temporary-create-error',error:String(e)});}}
 });
 emit({event:'temporary-state-tables',tables:[0x13d150,0x13d160,0x13d170].map(rva=>({rva,raw:hex(m.base.add(rva),13)}))});
 Interceptor.attach(m.base.add(0x310c0),{
  onEnter(){this.p=this.context.ecx;this.caller=loc(this.returnAddress);},
  onLeave(r){try{emit({event:'temporary-default-families',object:this.p.toString(),caller:this.caller,result:r.toInt32(),
    word:this.p.add(0x8d6).readU32(),word_variant:this.p.add(0x8da).readU32(),bit:this.p.add(0x8e8).readU32()});
   }catch(e){emit({event:'temporary-default-error',error:String(e)});}}
 });
 Interceptor.attach(m.base.add(0x49fd0),{
  onEnter(a){this.p=this.context.ecx;this.out=a[0];this.caller=loc(this.returnAddress);},
  onLeave(r){try{const context=this.p.add(0x3a2).readPointer();emit({event:'temporary-default-selector',caller:this.caller,result:r.toInt32(),
    selector:this.out.isNull()?null:this.out.readU32(),word:context.add(0x8d6).readU32(),word_variant:context.add(0x8da).readU32()});
   }catch(e){emit({event:'temporary-default-error',error:String(e)});}}
 });
}});
