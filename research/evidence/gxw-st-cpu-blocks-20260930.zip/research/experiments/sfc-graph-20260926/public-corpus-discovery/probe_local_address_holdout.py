"""Independent project/BOOL holdout for discarded local address fields."""
from dataclasses import replace
from pathlib import Path
import base64,json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.declarations import parse_declarations,serialize_declarations
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_st_sources import child
from replay_gxw_workspace import prepare,trace_prepared
from probe_gxw_program_check_resources import SCRIPT,inspect_run
P=Path(__file__).resolve().parent
OUT=P/'local-address-holdout-20260930'

def frontend_declarations(path):
    snapshot=json.loads(path.read_text(encoding='utf-8-sig'));pool=child(snapshot['build'],44);raw=base64.b64decode(pool['raw'])
    return {base64.b64decode(child(pool,i+8)['raw']).hex():sha256(base64.b64decode(child(pool,i+16)['raw'])) for i in range(0,len(raw),56)}

def main():
    OUT.mkdir(exist_ok=False);(OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    source=(P/'samples/project2.gxw').read_bytes();streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
    logical='MAIN.Labels.lh';d=parse_declarations(streams[logical],logical_name=logical)
    row=next(r for r in d.rows if r.class_code==1 and r.data_type=='BOOL' and not r.device)
    changed=serialize_declarations(replace(d,rows=tuple(replace(r,device='M100',iec_address='%MX0.100') if r==row else r for r in d.rows)))
    variant,receipt=patch_raw(source,logical,streams[logical],changed)
    (OUT/'mutation.json').write_text(json.dumps(dict(source_sha256=sha256(source),candidate_sha256=sha256(variant),
        source=logical,label=row.name,receipt=receipt,hypothesis='Local address fields are absent from native frontend declarations; PCode remains identical.'),indent=2),encoding='utf-8')
    results=[]
    for name,data in [('baseline',source),('local-bool-address',variant)]:
        directory=OUT/name;directory.mkdir();path=directory/'input.gxw';path.write_bytes(data)
        script=directory/'trace.js';script.write_text(SCRIPT,encoding='utf-8')
        for attempt in range(1,5):
            native=directory/f'native-{attempt}';prepare(path,native,compile=True,program_check=True,export_project=True,snapshot_frontend=True,project_alias='LOCALADDR')
            process=trace_prepared(native,script)
            events=[json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
            if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
        observed=inspect_run(native)
        result=dict(case=name,native_directory=str(native),process=process,check=observed['check'],
            frontend=frontend_declarations(native/'frontend-snapshot.json'),generated=observed['generated'],diagnostics=observed['diagnostics'])
        if results:result.update(frontend_equal=result['frontend']==results[0]['frontend'],pcode_equal=result['generated']==results[0]['generated'])
        results.append(result);(OUT/'comparison.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
        print(json.dumps({k:v for k,v in result.items() if k not in ['frontend','generated','diagnostics']},ensure_ascii=True),flush=True)

if __name__=='__main__':main()
