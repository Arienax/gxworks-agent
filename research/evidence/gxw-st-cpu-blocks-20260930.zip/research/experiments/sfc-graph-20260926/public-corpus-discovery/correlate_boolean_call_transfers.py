"""Link native argument rewrites to raw CGTables and independent PCode reads."""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from gxw.compiler_tables import parse_compiler_tables
from gxw.lossless import sha256
from probe_gxw_call_transfers import observed_boolean_output_rewrite,compare_observed_boolean_output
P=Path(__file__).resolve().parent/'array-operand-controls'
for case in sys.argv[1:] or ['word-bit-call-q']:
 parent=P/case;comparison=json.loads((parent/'comparison.json').read_text())
 raw=(parent/'captured-symbols.bin').read_bytes();tables=parse_compiler_tables(raw)
 source_trace=parent/comparison['trace_attempts'][-1]['directory'];allocated=None;root_id=None
 for line in (source_trace/'events.jsonl').read_text().splitlines():
  e=json.loads(line).get('payload',{})
  if e.get('event')!='enter' or e.get('name')!='Compile':continue
  b={r['label']:r for r in e['buffers']}
  names=[bytes.fromhex(v['bytes']).split(b'\0')[0] for k,v in b.items() if k.startswith('name_') and v.get('bytes')]
  if b'POU_01' in names:
   assert raw==bytes.fromhex(b['symbolic_data']['bytes']);root_id=e['id']
  if b'Task_01' in names and root_id is not None and e['id']>root_id:
   assert allocated is None;allocated=parse_compiler_tables(bytes.fromhex(b['symbolic_data']['bytes']))
 assert allocated is not None
 traces=sorted(parent.glob('boolean-call-trace*/comparison.json'),key=lambda p:p.stat().st_mtime_ns)
 native_trace=traces[-1].parent;events=json.loads(traces[-1].read_text())
 assert events['pcode_equal'] and not events['errors']
 outputs=list(native_trace.glob('pcode-*.bin'));assert outputs
 assert all(p.read_bytes()==(parent/'native'/p.name).read_bytes() for p in outputs)
 rewrites=[r for r in events['rows'] if r['event']=='call-specialized-argument-rewrite'];rows=[];used=set()
 for event in rewrites:
  projected=observed_boolean_output_rewrite(event,tables,allocated)
  if projected.get('call'):
   candidates=[(i,r) for i,r in enumerate(comparison['calls']) if i not in used and r['line']['text'].startswith(projected['call']+'(')]
  else:candidates=[]
  if candidates:
   i,source=candidates[0];used.add(i)
   checked=compare_observed_boolean_output(projected,source['records'],tables,allocated)
  else:source=None;checked=dict(exact=False,gaps=['no unique remaining native source occurrence'])
  rows.append(dict(rewrite=projected,source=source,comparison=checked))
 result=dict(case=case,source_symbols_sha256=sha256(raw),allocated_symbols_sha256=sha256(allocated.raw),
  native_trace=str(native_trace.relative_to(parent)),decoded_pcode_sha256=[sha256(p.read_bytes()) for p in outputs],
  original_diagnostics=comparison['native']['diagnostics'],rows=rows,
  summary=dict(rewrites=len(rows),projected=sum(r['rewrite']['handling']!='opaque-preserved' for r in rows),exact=sum(r['comparison']['exact'] for r in rows)))
 (parent/'call-transfer-comparison.json').write_text(json.dumps(result,indent=2))
 print(json.dumps(dict(case=case,**result['summary'],gaps=[r['rewrite']['gaps']+r['comparison']['gaps'] for r in rows])))
