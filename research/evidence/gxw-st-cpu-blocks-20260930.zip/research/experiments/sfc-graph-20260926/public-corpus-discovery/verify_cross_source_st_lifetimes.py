"""Saved-evidence verification: predictions, decoder agreement, and slot scope."""
from pathlib import Path
import json,struct,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from probe_minimal_conditional_port_writes import save,streams
from model_q_st_program_lifetimes import predict
from witness_st_conditional_transfers import decode,evaluate
from verify_temporary_check_correspondence import verify
P=Path(__file__).resolve().parent
GROUPS=['cross-source-st-lifetimes-20260930','cross-source-st-lifetime-holdouts-20260930','cross-source-st-ladder-controls-20260930']


def main():
    rows=[]
    for group in GROUPS:
        out=P/group;plans={r['case']:r for r in json.loads((out/'experiment-plan.json').read_text())['cases']}
        listings={(r['case'],r['resource']):r['records'] for r in json.loads((out/'native-listings.json').read_text())}
        for case in json.loads((out/'comparison.json').read_text()):
            n=Path(case['native_directory']);source=(n/'input.gxw').read_bytes()
            prior=json.loads((out/case['case']/'before-native.json').read_text())
            assert sha256(source)==prior['input_sha256']
            content=streams(source)
            assert all(sha256(content[k])==v for k,v in prior['unchanged_streams'].items())
            outputs,model=predict(source,'program','program');witnesses=[]
            for g,output in zip(case['generated'],outputs,strict=True):
                raw=(n/f'pcode-{g["index"]}-0.bin').read_bytes();assert raw==output['output']
                records=decode(raw)
                assert [{k:v for k,v in r.items() if k not in ('offset','raw')} for r in records]==listings[case['case'],g['name']]
                observations={}
                for owner in output['programs']:
                    if owner not in prior['source_texts']:continue
                    a=next(a for a in model['allocations'] if a['owner']==owner and a['name']=='probeResult')
                    observations[owner]=dict(address=a['allocated_family']+str(a['number']),type='INT')
                if observations:
                    result=evaluate(records,observations)
                    expected=1 if 'expression' in plans[case['case']] else -4
                    assert result['observations']==dict.fromkeys(observations,expected)
                    witnesses.append(dict(resource=g['name'],bindings=observations,expected=expected,**result))
            messages=[json.loads(l) for l in (n/'events.jsonl').read_text().splitlines()]
            assert not any(m.get('type')=='error' for m in messages)
            events=[m['payload'] for m in messages if m.get('type')=='send']
            assert not any('error' in e.get('event','') or e.get('observation_error') for e in events)
            compiles={e['compile_id']:[bytes.fromhex(v['hex']).decode('cp949') for v in e['names']] for e in events if e.get('event')=='sink-compile'}
            native_creates=[];resets={}
            for e in events:
                if e.get('event')=='temporary-slots' and e['name']=='reset-slots':
                    assert not e['after'];resets[e['compile_id']]=e
                if e.get('event')=='temporary-create':
                    reset=resets[e['compile_id']]
                    assert reset['sequence']<e['sequence']
                    assert e['type']==68 and e['count']==1
                    number=struct.unpack_from('<I',bytes.fromhex(e['output']),8)[0]
                    assert len(compiles[e['compile_id']])==1
                    native_creates.append(dict(owner=compiles[e['compile_id']][0],number=number,compile_id=e['compile_id'],reset_caller=reset['caller'],manager=e['manager']))
            expected_creates=[dict(owner=e['owner'],number=e['number']) for e in model['temporary_events'] if e['action']=='create']
            assert [{k:e[k] for k in ('owner','number')} for e in native_creates]==expected_creates
            rows.append(dict(group=group,case=case['case'],input_sha256=sha256(source),unchanged_payloads_verified=len(prior['unchanged_streams']),
                resources=len(outputs),original_prediction_matches=case['hypothesis_matches']['program-program'],current_model_matches=True,
                native_core_decoders_agree=True,native_creations=native_creates,witnesses=witnesses,check=case['check'],last_event=case['last_event']))
    original=next(r for r in rows if r['case']=='original-two-ladder-resources')
    mixed=next(r for r in rows if r['case']=='original-ladder-and-new-st')
    assert original['input_sha256']==sha256((P/'native-allocation-inventory/case-10/input.gxw').read_bytes())
    assert original['last_event']==mixed['last_event']
    baseline=P/GROUPS[2]/original['case']/'native-1'
    mixed_native=P/GROUPS[1]/mixed['case']/'native-1'
    assert (baseline/'pcode-0-0.bin').read_bytes()==(mixed_native/'pcode-0-0.bin').read_bytes()
    correspondence=verify(GROUPS);out=P/GROUPS[-1]
    save(out/'current-check-export-correspondence.json',correspondence)
    save(out/'verified-interpretation.json',dict(cases=rows,
        claims=[
            'For measured Q03UDV Noeul probes, declarations are allocated per program in task order; its arithmetic temporary slots are reset before the next source program, including within one resource.',
            'The physical D allocations remain reserved across these program and resource boundaries. Fresh per-program slots use new D addresses.',
            'Read-only native reset and creation events agree with source-only allocation predictions; no trace or compiler cache is input to the predictor.',
            'Original ladder plus controlled ST compiles and decodes but checking remains incomplete. The byte-identical original project fails at the same operation/code; its first generated resource is unchanged. Minimal ladder plus ST passes checking/export/reopen.',
        ],limits=[
            'Controlled ST replacements in four Noeul ladder projects (cases 05,06,09,10), not independent real-world ST lineage or a general ST generator.',
            'INT arithmetic only; no claims about nested FB instances, recursion, interrupt task overlap, runtime memory safety, or other CPUs/versions.',
            'The original mixed-project prediction mistakenly appended ST terminators to an already terminated ladder body. Original failed predictions are preserved; corrected results for that case are retrospective fits. The subsequent baseline and minimal-ladder controls had corrected predictions saved before native runs.',
            '0x2d010025 is an observed incomplete-check code; these controls do not establish its underlying cause or identify every invalid source shape.',
            'Finite initialized arithmetic evaluation is an offline witness, not PLC execution or general source semantic equivalence.',
        ],summary=dict(projects=len(rows),accepted=sum(bool(r['check']) and not r['check']['rejected'] for r in rows),
            incomplete=sum(r['check'] is None for r in rows),resources=sum(r['resources'] for r in rows),native_temporary_creations=sum(len(r['native_creations']) for r in rows),
            finite_st_observations=sum(len(w['bindings']) for r in rows for w in r['witnesses']))))
    (out/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    print(json.dumps(dict(projects=len(rows),accepted=6,incomplete=2,resources=sum(r['resources'] for r in rows),
        check_summary={k:v for k,v in correspondence.items() if k not in ('phases','notes')})))


if __name__=='__main__':main()
