"""Distinguish Q SFC end symbol (14) from a jump (15) to numeric target 999."""
from pathlib import Path
import json
import sys
ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'research')]
from gxw.lossless import sha256
from probe_gxw_sfc_graph import patch_raw
from probe_pending_sfc_source_chars import source_chars
from probe_sfc_source_mutations import program
from replay_gxw_workspace import run

P = Path(__file__).resolve().parent
OUT = P/'pending-q-end-kind'


def main():
    OUT.mkdir(exist_ok=False); (OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    prior = P/'sfc-source-targeted-mutations/pending-Q-add-end'
    source = (prior/'source.gxw').read_bytes(); stream = program(source); chars, layout = source_chars(stream.raw)
    updated = bytearray(stream.raw); offset = layout['source_offset'] + 98
    assert updated[offset:offset + 3] == bytes.fromhex('6fe703')
    updated[offset] = 0x6e
    changed, receipt = patch_raw(source, stream.logical_name, stream.raw, bytes(updated))
    (OUT/'source.gxw').write_bytes(changed); (OUT/'source-chars.bin').write_bytes(source_chars(bytes(updated))[0])
    for file in ['candidate.bin', 'predicted-graph.bin']:
        (OUT/file).write_bytes((prior/file).read_bytes())
    (OUT/'prediction-before-native.json').write_text(json.dumps(dict(source_sha256=sha256(source), changed_sha256=sha256(changed),
        offset=offset, old_kind=15, new_kind=14, number=999, receipt=receipt,
        hypothesis='Q end and jump have distinct source symbol kinds even when target text is 999'), indent=2), encoding='utf-8')
    results = []; path = OUT/'source.gxw'
    for phase in ['convert', 'reload']:
        for attempt in range(1, 5):
            native = OUT/f'{phase}-{attempt}'
            outcome = run(path, native, compile=True, change_sfc=True, program_check=True, snapshot_frontend=True,
                export_project=True, project_alias='SFCQEND', sfc_graph_chars=OUT/'source-chars.bin' if phase == 'convert' else None)
            events = [json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
            if not any(e.get('operation') == 'NativeTemporaryDirectoryCollision' for e in events):
                break
        pcode = native/'pcode-0-0.bin'; encoded = native/'sfc-encoded-tokens.bin'
        row = dict(phase=phase, native_directory=str(native), outcome=outcome,
            full_pcode_identical=pcode.exists() and pcode.read_bytes() == (OUT/'candidate.bin').read_bytes(),
            graph_prediction_identical=encoded.read_bytes() == (OUT/'predicted-graph.bin').read_bytes() if encoded.exists() else None)
        results.append(row); (OUT/'comparison.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
        print(json.dumps(dict(**{k: v for k, v in row.items() if k != 'outcome'}, compiler_rejected=outcome['compiler_rejected'],
            program_check_completed=outcome['program_check_completed'], diagnostics=outcome['diagnostics'])), flush=True)
        path = native/'native-saved.gxw'
        if not path.exists():
            break


if __name__ == '__main__':
    main()
