from pathlib import Path
import json,sys,hashlib
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from replay_gxw_workspace import prepare,trace_prepared
P=Path(__file__).resolve().parent
case=sys.argv[1] if len(sys.argv)>1 else 'case-00'
out=P/'library-native-text'/case
prepare(P/'native-allocation-inventory'/case/'input.gxw',out,snapshot_frontend=True)
script=out/'CaptureLibrary.js'
script.write_text('globalThis.CAPTURE_DIRECTORY='+json.dumps(str(out.resolve()).replace('\\','/'))+';\n'+(P/'TraceLibraryIO.js').read_text(encoding='utf-8'),encoding='utf-8')
print(json.dumps(trace_prepared(out,script,timeout=45)))
for f in out.glob('*.capture'):
 raw=f.read_bytes();print(f.name,len(raw),hashlib.sha256(raw).hexdigest(),repr(raw[:96]))
