"""Selected source/check/export correspondence matrix, not a historical rerun."""
from pathlib import Path
import base64
import json
import struct
import sys
P=Path(__file__).resolve().parent
ROOT=P.parents[3]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.text_pou import parse_st_pou
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_st_sources import snapshot_body
from probe_gxw_library_sources import snapshot_library_pous
from probe_fx3g_library_roundtrip import st_envelope
from replay_gxw_workspace import prepare,trace_prepared
from trace_fresh_program_resources import SCRIPT,inspect_run

OUT=P/'fresh-check-matrix-20260930'

def payloads(raw):return {s.logical_name:s.raw for s in inspect_project(raw).streams if s.logical_name and s.raw is not None}

def source_binding(native,case):
    source=(native/'input.gxw').read_bytes();streams=payloads(source)
    snapshot=json.loads((native/'frontend-snapshot.json').read_text(encoding='utf-8-sig'))
    result=dict(project_sha256=sha256(source),frontend_sha256=sha256((native/'frontend-snapshot.json').read_bytes()),
        touched_sources=[dict(name=n,sha256=sha256(streams[n]),bytes=len(streams[n])) for n in case['sources']],text=[])
    for name in case.get('st_sources',[]):
        text=parse_st_pou(streams[name]).text
        if name.endswith('.lnb'):
            pou,library=name.split('.Program\\');library=library.removesuffix('.lnb')
            found,=[r for r in snapshot_library_pous(snapshot) if (r['library'],r['name'])==(library,pou)]
            body=base64.b64decode(found['program_raw_base64'])
        else:body=snapshot_body(snapshot,name.removesuffix('.Program.pou'))
        n=struct.unpack_from('<I',body,72)[0];native_text=body[76:76+n]
        result['text'].append(dict(source=name,text=text,native_text=native_text.decode('cp1252'),
            native_envelope='length includes one terminal NUL',
            byte_identical=native_text==text.encode('cp1252')+b'\0'))
    return result

def phase_summary(native,case):
    r=inspect_run(native);r['source_binding']=source_binding(native,case)
    generated={x['name']:x for x in r['generated']};reads=[]
    for start in r['check_starts']:
        matching=[v for v in r['resource_reads'] if v['phase']=='check' and v['check_index']==start['check_index']
            and v['target']==start['target'] and v['buffers'][0]['sha256'] is not None]
        reads.append(dict(target=start['target'],names=sorted({v['resource_name'] for v in matching if v['resource_name']}),
            read_count=len(matching),all_current=bool(matching) and all(b['matches_current'] for v in matching for b in v['buffers'] if b['sha256'] is not None)))
    exports=[]
    for res in r['exported_resources'] or []:
        name=res['name'].removesuffix('.res');g=generated.get(name)
        regions=res.get('regions',[]);nonempty=[v for v in regions if v['size']]
        exports.append(dict(resource=name,regions=regions,empty_region_count=sum(v['size']==0 for v in regions),
            all_current=bool(g) and bool(nonempty) and all(v['sha256']==g['channels'][0]['sha256'] for v in nonempty)))
    predicted=case.get('predicted');prediction=None
    if predicted:
        raw=Path(predicted).read_bytes();actual=(native/'pcode-0-0.bin').read_bytes()
        prediction=dict(path=str(predicted),sha256=sha256(raw),byte_identical=raw==actual)
    row=dict(native_directory=str(native),input_sha256=r['input_sha256'],source_binding=r['source_binding'],
        check=r['check'],check_resources=reads,current_code=r['generated'],exported_resources=exports,
        export_sha256=r['exported_sha256'],source_prediction=prediction,diagnostics=r['diagnostics'],trace_errors=r['trace_errors'])
    (native/'matrix-phase.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
    return row

def native_phase(source,out,case,phase):
    script=out/'trace.js';out.mkdir();script.write_text(SCRIPT,encoding='utf-8')
    for attempt in range(1,5):
        native=out/f'native-{attempt}'
        prepare(source,native,compile=True,export_project=True,program_check=True,snapshot_frontend=True,
            change_sfc=case.get('sfc',False),sfc_graph_chars=case.get('chars') if phase=='compile' else None,
            project_alias='CHECKMATRIX',refresh_program_check=not case.get('legacy',False))
        trace=trace_prepared(native,script)
        events=[json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
        if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
    row=phase_summary(native,case);row['trace']=trace
    return native,row

def main():
    OUT.mkdir(exist_ok=False)
    for name in ['run_fresh_check_matrix.py','trace_fresh_program_resources.py']:(OUT/name).write_bytes((P/name).read_bytes())
    base=P/'fx3g-library-source-roundtrip-v6/true-source-only/compile-1/native-saved.gxw'
    raw=base.read_bytes();streams=payloads(raw);logical='MAIN.Program.pou'
    text='Y0 := X1;\r\n'
    replaced,receipt=patch_raw(raw,logical,streams[logical],st_envelope(streams[logical],text))
    replacement=OUT/'source-replacement.gxw';replacement.write_bytes(replaced)
    (OUT/'source-replacement-receipt.json').write_text(json.dumps(dict(base=str(base),receipt=receipt,text=text),indent=2),encoding='utf-8')
    lnb='F_DISBON.Program\\UtilsV5.lnb'
    cases=[
        dict(name='library-false',input=P/'fx3g-library-source-roundtrip-v6/false-source-only/candidate.gxw',sources=[logical,lnb],st_sources=[logical,lnb],
            existing=P/'fresh-check-matrix-20260930-library-false-v2/native-1'),
        dict(name='library-true',input=P/'fx3g-library-source-roundtrip-v6/true-source-only/candidate.gxw',sources=[logical,lnb],st_sources=[logical,lnb]),
        dict(name='sfc-transition-swap',input=P/'sfc-source-targeted-mutations/parallel-swap-transition-references/source.gxw',sources=['MAIN.Program.pou'],sfc=True,
            predicted=P/'sfc-source-targeted-mutations/parallel-swap-transition-references/candidate.bin'),
        dict(name='sfc-pending-action30',input=P/'sfc-source-targeted-mutations/pending-FX-action30/source.gxw',sources=['MAIN.Program.pou'],sfc=True,
            chars=P/'sfc-source-targeted-mutations/pending-FX-action30/source-chars.bin',predicted=P/'sfc-source-targeted-mutations/pending-FX-action30/candidate.bin'),
        dict(name='repeated-int-ABA',input=P/'q-repeated-materialization-lifetimes/int-ABA/input.gxw',sources=[logical],
            predicted=P/'q-repeated-materialization-lifetimes/int-ABA/predicted-0.bin'),
        dict(name='repeated-string-BABA',input=P/'q-repeated-materialization-lifetimes/string-BABA/input.gxw',sources=[logical],
            predicted=P/'q-repeated-materialization-lifetimes/string-BABA/predicted-0.bin'),
        dict(name='source-replacement',input=replacement,sources=[logical],st_sources=[logical]),
        dict(name='duplicate-coil-legacy',input=P/'program-check-freshness/known-invalid-duplicate-coils.gxw',sources=[logical],st_sources=[logical],legacy=True),
        dict(name='duplicate-coil-fresh',input=P/'program-check-freshness/known-invalid-duplicate-coils.gxw',sources=[logical],st_sources=[logical]),
    ]
    # Some simple SFC seeds use a different program name. Derive it from input,
    # never infer association from the resource cache's suffix.
    for case in cases:
        if case.get('sfc'):case['sources']=[n for n in payloads(case['input'].read_bytes()) if n.endswith('.Program.pou')]
    (OUT/'selection-before-native.json').write_text(json.dumps(cases,indent=2,default=str),encoding='utf-8')
    rows=[]
    for case in cases:
        directory=OUT/case['name'];directory.mkdir();row=dict(case=case['name'],phases=[]);rows.append(row)
        path=case['input']
        for phase in ('compile','reopen'):
            if phase=='compile' and case.get('existing'):
                native=case['existing'];result=phase_summary(native,case)
            else:native,result=native_phase(path,directory/phase,case,phase)
            result['phase']=phase;row['phases'].append(result)
            if phase=='reopen':
                result['reopen_code_identical']=result['current_code']==row['phases'][0]['current_code']
            (OUT/'matrix.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
            print(json.dumps(dict(case=case['name'],phase=phase,check=result['check'],checked_current=[r['all_current'] for r in result['check_resources']],
                export_current=[r['all_current'] for r in result['exported_resources']],prediction=result['source_prediction'],
                frontend_text_match=[r['byte_identical'] for r in result['source_binding']['text']],reopen_same=result.get('reopen_code_identical'),
                errors=[{k:v for k,v in r.items() if k!='raw_base64'} for r in result['diagnostics'] if r['kind']==2])),flush=True)
            path=native/'native-saved.gxw'
            if case.get('legacy') or not path.exists() or not result['check'] or result['check']['rejected']:break

if __name__=='__main__':main()
