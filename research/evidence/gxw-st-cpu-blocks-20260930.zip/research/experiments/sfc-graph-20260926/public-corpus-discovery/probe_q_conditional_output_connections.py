"""Native discrimination for output gates and value-copy alias conditions."""
from pathlib import Path
import json
import struct
import sys
ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'research')]
from gxw.lossless import inspect_project, sha256
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_simple_fb import frame_source, observe_calls
from replay_gxw_workspace import run
from source_q_direct_projection import project_projection
from source_q_allocation import groups

P = Path(__file__).resolve().parent
OUT = P/'q-conditional-output-connections'


def payloads(raw):
    return {s.logical_name: s.raw for s in inspect_project(raw).streams if s.logical_name}


def label(name):
    body = name.encode('ascii'); length = len(body)+3
    return bytes([length, 0xdf])+body+bytes([length])


def main():
    OUT.mkdir(exist_ok=False)
    for name in ['probe_q_conditional_output_connections.py', 'source_q_direct_projection.py', 'source_q_direct_declarations.py', 'source_q_call_connections.py', 'source_q_label_binding.py', 'source_q_allocation.py', 'source_q_width.py', 'q-width-static-tables.json']:
        (OUT/name).write_bytes((P/name).read_bytes())
    source = (P/'scpi-instance-binding-controls/same-instance/native/native-saved.gxw').read_bytes()
    before = payloads(source); logical = 'MAIN.Program.pou'; frame = frame_source(before[logical]); calls = observe_calls(frame)['calls']
    ready = []; results = []
    for case, ordinal in [('bool-first', 0), ('bool-last', 1), ('word-first', 0), ('string-first', 0)]:
        directory = OUT/case; directory.mkdir()
        span = calls[ordinal]['output_fragment']; original = frame.raw[span['offset']:span['offset']+span['length']]
        rows = groups(original); assert len(rows) == 4 and rows[2][1:] == [label('_TRUE')]
        if case.startswith('bool'):
            rows[1:1] = [[bytes.fromhex('030c03'), bytes.fromhex('049c2f04')]]
        else:
            rows[2:3] = [[bytes.fromhex('030003'), bytes.fromhex('049c2f04')],
                         [bytes.fromhex('030d03'), bytes.fromhex('049c3f04')]]
            if case.startswith('string'):
                rows[-1] = [bytes.fromhex('054c050305'), label('_oRecvData'), bytes.fromhex('04a8dc04')]
        replacement = b''.join(t for g in rows for t in g)
        program = bytearray(frame.raw[:span['offset']]+replacement+frame.raw[span['offset']+span['length']:])
        for offset in [55, 59]:
            struct.pack_into('<I', program, offset, struct.unpack_from('<I', frame.raw, offset)[0]+len(replacement)-len(original))
        changed, receipt = patch_raw(source, logical, before[logical], bytes(program))
        assert payloads(changed) == dict(before, **{logical: bytes(program)})
        path = directory/'input.gxw'; path.write_bytes(changed)
        predictions = project_projection(changed, allow_scpi=True, resource_limit=1)
        for row in predictions:
            (directory/f'predicted-{row["resource_index"]}.bin').write_bytes(row.pop('output'))
        (directory/'prediction-before-native.json').write_text(json.dumps(dict(source_sha256=sha256(source),
            receipt=receipt, modified_call=ordinal, predictions=predictions), indent=2), encoding='utf-8')
        ready.append((case, directory, path))
    for case, directory, path in ready:
        for attempt in range(1, 5):
            native = directory/f'native-{attempt}'
            outcome = run(path, native, compile=True, export_project=True, project_alias='QCONDOUTPUT')
            events = [json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
            if not any(e.get('operation') == 'NativeTemporaryDirectoryCollision' for e in events):
                break
        accepted = outcome['returncode'] == 0 and outcome['compile_completed'] and not outcome['compiler_rejected'] and (native/'native-saved.gxw').exists()
        row = dict(case=case, native_directory=str(native), native_accepted=accepted, outcome=outcome)
        if accepted:
            ours = (directory/'predicted-0.bin').read_bytes(); actual = (native/'pcode-0-0.bin').read_bytes()
            pg = [b''.join(g) for g in groups(ours)]; ng = [b''.join(g) for g in groups(actual)]
            diffs = [dict(record=i, predicted=a.hex(), native=b.hex()) for i, (a, b) in enumerate(zip(pg, ng)) if a != b]
            row.update(byte_identical=ours == actual, predicted_sha256=sha256(ours), native_sha256=sha256(actual),
                predicted_records=len(pg), native_records=len(ng), different_records=diffs)
        (directory/'comparison.json').write_text(json.dumps(row, indent=2), encoding='utf-8')
        results.append(row); (OUT/'comparison.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
        print(json.dumps(dict(case=case, native_accepted=accepted, byte_identical=row.get('byte_identical'),
            predicted_records=row.get('predicted_records'), native_records=row.get('native_records'),
            different_records=len(row.get('different_records', [])), examples=row.get('different_records', [])[:3], diagnostics=outcome['diagnostics'])), flush=True)


if __name__ == '__main__':
    main()
