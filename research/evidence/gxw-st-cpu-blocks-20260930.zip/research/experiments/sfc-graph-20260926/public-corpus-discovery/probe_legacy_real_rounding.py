"""Isolate the observed x86 CRT rounding independently from GX compilation."""
from pathlib import Path
import sys,math,struct,subprocess,json,decimal
ROOT=Path(__file__).resolve().parents[4];P=Path(__file__).resolve().parent
out=P/'real-rounding-runtime-controls';out.mkdir(exist_ok=False)
seeds=[1.23456789,1.2345675,1.2345685,9.9999985,9999998.5,0.12345685,1.23456785e-8,50000.05,1.0000000596046448,1.0000001192092896,16777217.0,3.4028234e38]
values=[0.0,-0.0]
for x in seeds:
 values.extend([x,-x])
 for direction in [-math.inf,math.inf]:
  neighbor=x
  for i in range(24):neighbor=math.nextafter(neighbor,direction);values.extend([neighbor,-neighbor])
hexes=list(dict.fromkeys(struct.pack('<d',v).hex() for v in values));(out/'inputs.txt').write_text('\n'.join(hexes)+'\n')
exe=out/'LegacyRealOracle.exe';source=ROOT/'research/native/LegacyRealOracle.cs'
subprocess.run(['C:/Windows/Microsoft.NET/Framework/v4.0.30319/csc.exe','/nologo','/platform:x86','/reference:System.Web.Extensions.dll','/out:'+str(exe),str(source)],check=True)
subprocess.run([str(exe),'C:/Windows/SysWOW64/MSVCR71.dll',str(out/'inputs.txt'),str(out/'native.json')],check=True)
native=json.loads((out/'native.json').read_text());D=decimal.Decimal
def significant(value,precision,rounding):
 with decimal.localcontext() as context:
  context.prec=precision;context.rounding=rounding;return +value
rows=[]
for r in native['rows']:
 x=struct.unpack('<d',bytes.fromhex(r['input_binary64_hex']))[0];backend=struct.unpack('<d',bytes.fromhex(r['backend_input_binary64_hex']))[0]
 # Candidates are hypotheses. All counterexamples stay in the comparison.
 exact=significant(D.from_float(backend),7,decimal.ROUND_HALF_UP)
 dec15=significant(significant(D.from_float(backend),15,decimal.ROUND_HALF_UP),7,decimal.ROUND_HALF_UP)
 canonical=significant(D(str(backend)),7,decimal.ROUND_HALF_UP)
 observed=D(r['sprintf7']);candidate=dict(exact_binary_half_up=exact==observed,decimal15_then_half_up=dec15==observed,
                                        shortest_decimal_half_up=canonical==observed,python_format=D(format(backend,'.6e'))==observed)
 rows.append(dict(native=r,candidate_matches=candidate))
result=dict(native_dll=native['dll'],native_dll_sha256=native['dll_sha256'],rows=rows,
 summary=dict(cases=len(rows),matches={k:sum(r['candidate_matches'][k] for r in rows) for k in rows[0]['candidate_matches']}))
(out/'comparison.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result['summary']))
print(json.dumps([r for r in rows if not r['candidate_matches']['decimal15_then_half_up']][:5]))
