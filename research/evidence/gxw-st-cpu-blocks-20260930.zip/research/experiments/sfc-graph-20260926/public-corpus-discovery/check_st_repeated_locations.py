"""Cross-check all ST compiled positions after real FB repeat-call mutations."""
import json
import argparse
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from gxw.lossless import inspect_project
from gxw.compiler_debug import parse_compiler_debug
from probe_gxw_debug_locations import search_maps,native_simple_row
from replay_gxw_workspace import run
P=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--nested',action='store_true');args=parser.parse_args()
OUT=P/('ST-nested-location-controls' if args.nested else 'ST-repeated-location-controls')
for case in (['single','repeated'] if args.nested else ['same','separate']):
    source=P/('ST-nested-FB-controls' if args.nested else 'ST-repeated-FB-controls')/case/'native/native-saved.gxw'
    out=OUT/case
    raw=next(s.raw for s in inspect_project(source.read_bytes()).streams if s.logical_name=='DebugInformation2.dat')
    debug=parse_compiler_debug(raw);maps=search_maps(debug,encoding='cp1252')['maps']
    resource=maps[1][0]
    queries=[dict(resource='MAIN',start_step=step,step_count=1,timestamp=0) for step in range(resource['fields'][0]+2)]
    forwards=[]
    for path in [m['key']['text'] for m in maps[0] if 'KEYPAD' in m['key']['text']]:
        for line in [1,4,7,8,9,19,26]:
            for suffix in ['', '\t/PC-1']:
                forwards.append(dict(mode='basic',resource='MAIN',library='',pou=path+suffix,program_kind=193,
                    network=-1,start_step=line,step_count=1,element_id=-1))
    result=run(source,out/'native',compile=True,export_project=True,project_alias='STLOC',
        pcode_location_queries=queries,pcode_range_queries=forwards)
    actual=json.loads((out/'native/native-pcode-locations.json').read_text(encoding='utf-8-sig'))
    compared=[]
    for got in actual:
        step=got['query']['start_step'];want=None;selected=None
        candidates=[i for i in resource['groups'][0] if debug.elements[i].linked_step_start<=step<=debug.elements[i].linked_step_end]
        if candidates and step not in [resource['fields'][1],resource['fields'][3]]:
            selected=candidates[-1];e=debug.elements[selected]
            table=debug.offset_tables[e.offset_table_index]
            rindex=native_simple_row(table.rows,step-e.linked_step_start)
            if rindex is not None:
                r=table.rows[rindex]
                want=dict(library=e.names[0].decode(),pou=e.names[2].decode(),program_kind=e.kind_code,network=r[3],
                    start_step=e.fields[0]+r[0],step_count=-1,element_id=-1,action_transition_present=False)
        compared.append(dict(step=step,candidates=candidates,selected=selected,expected=want,
            native=got['location'],native_code=got['code'],equal=want==got['location']))
    summary=dict(total=len(compared),exact=sum(r['equal'] for r in compared),native_locations=sum(r['native'] is not None for r in compared))
    (out/'comparison.json').write_text(json.dumps(dict(summary=summary,rows=compared),indent=2),encoding='utf-8')
    print(json.dumps(dict(case=case,summary=summary,mismatches=[r for r in compared if not r['equal']][:12])),flush=True)
