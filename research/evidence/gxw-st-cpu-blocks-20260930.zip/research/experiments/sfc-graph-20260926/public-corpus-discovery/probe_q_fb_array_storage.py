"""Test native declaration/storage forms for uncalled user-FB arrays."""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.declarations import parse_declarations,edit_declarations,serialize_declarations
from gxw.compiler_tables import parse_compiler_tables
from gxw.compiler_assignment import parse_compiler_assignment
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import run
from native_gxw_compiler import native_table_dump
P=Path(__file__).resolve().parent
out=P/'q-fb-array-storage';out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
source=(P/'q-fb-compile-dependencies/bad-uncalled-undeclared/input.gxw').read_bytes()
streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
plans=[('local-empty-initial','MAIN.Labels.lh',''),('global-empty-initial','Global1.gh',''),('global-array-initial','Global1.gh','[2()]')]
rows=[]
for case,logical,initial in plans:
    directory=out/case;directory.mkdir()
    doc=parse_declarations(streams[logical],logical_name=logical)
    upsert=dict(name='BlockArray',data_type='ARRAY [0..1] OF SCPI',kind='function_block',initial_value=initial)
    if logical.endswith('.gh'):upsert['class_name']='VAR_GLOBAL'
    new=serialize_declarations(edit_declarations(doc,upserts=[upsert]));changed,receipt=patch_raw(source,logical,streams[logical],new)
    assert {s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}==dict(streams,**{logical:new})
    path=directory/'input.gxw';path.write_bytes(changed)
    (directory/'mutation.json').write_text(json.dumps(dict(source_sha256=sha256(source),changed_sha256=sha256(changed),declaration=upsert,logical_name=logical,receipt=receipt,unrelated_payloads='byte-identical'),indent=2),encoding='utf-8')
    for attempt in range(1,9):
        native=directory/('native' if attempt==1 else 'native-v'+str(attempt))
        result=run(path,native,compile=True,snapshot_frontend=True,export_project=True,project_alias='QFBARRAY')
        events=[json.loads(s) for s in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
        if (native/'pcode-0-0.bin').exists() or not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
    row=dict(case=case,native_directory=str(native.relative_to(out)),native={k:result[k] for k in ('returncode','open_succeeded','compile_completed','compiler_rejected','diagnostics')})
    if row['native']['returncode']==0 and row['native']['compile_completed'] and not row['native']['compiler_rejected']:
        raw=(native/'compiler_DZComp/CGTable.dat').read_bytes();tables=parse_compiler_tables(raw)
        row['pous']=[];row['arrays']=[];row['blocks']=[]
        for record in tables.tables[1].records:
            pou=tables.pou_at(record.table_offset)
            row['pous'].append(dict(name=pou.name_bytes.decode('ascii'),offset=record.table_offset,components=pou.component_count))
            for c in tables.components(pou):
                if c.name_bytes==b'BlockArray':
                    row['blocks'].append(dict(owner=pou.name_bytes.decode('ascii'),offset=c.record.table_offset,type_code=tables.component_type(c),
                        array_offset=tables.component_array_offset(c),fields_hex=c.fields_raw.hex(),global_offset=c.global_offset,
                        assignment=vars(parse_compiler_assignment(c.user_info))))
        for record in tables.tables[13].records:
            array=tables.array_at(record.table_offset)
            row['arrays'].append(dict(offset=record.table_offset,element_type=array.element_type,parameter=array.element_parameter,
                total=array.total_count,dimensions=[dict(lower=d.lower,extent=d.extent) for d in array.dimensions],raw_hex=record.raw.hex()))
        row['native_table_comparison']=native_table_dump(raw,directory/'native-table-read',read_arrays=True)
    rows.append(row);(directory/'comparison.json').write_text(json.dumps(row,indent=2,default=lambda v:v.hex() if isinstance(v,bytes) else str(v)),encoding='utf-8')
    print(json.dumps({k:v for k,v in row.items() if k!='native_table_comparison'},default=lambda v:v.hex() if isinstance(v,bytes) else str(v)),flush=True)
(out/'comparison.json').write_text(json.dumps(dict(cases=rows,scope=__doc__),ensure_ascii=False,indent=2,default=lambda v:v.hex() if isinstance(v,bytes) else str(v)),encoding='utf-8')
