"""Audit saved bank/array experiments without executing the native compiler.

Before-native predictions remain immutable. Corrected source-model matches are
reported separately, including accepted inputs the earlier model rejected.
"""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[4];sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from gxw.token_q import q_operand_text
from source_q_label_binding import scalar
from source_q_st_calls import predict
from probe_minimal_conditional_port_writes import save,streams
from witness_st_conditional_transfers import decode,evaluate
from verify_temporary_check_correspondence import verify
P=Path(__file__).resolve().parent
GROUPS=['st-call-storage-banks-20260930','st-call-bank-index-holdouts-v2-20260930','st-call-array-size-discovery-20260930',
        'st-call-array-bound-holdouts-20260930','st-call-array-bound-forward-20260930','st-call-maximum-array-forward-20260930']


def main():
    rows=[]
    for group in GROUPS:
        out=P/group;config=json.loads((out/'experiment-plan.json').read_text());plans={p['case']:p for p in config['cases']}
        listings={r['case']:r['records'] for r in json.loads((out/'native-listings.json').read_text())}
        for case in json.loads((out/'comparison.json').read_text()):
            plan=plans[case['case']];d=out/case['case'];n=Path(case['native_directory']);before=json.loads((d/'before-native.json').read_text())
            source=(d/'input.gxw').read_bytes();assert sha256(source)==before['input_sha256']==sha256((n/'input.gxw').read_bytes())
            content=streams(source);assert all(sha256(content[name])==digest for name,digest in before['unchanged_streams'].items())
            options=config.get('prediction_options',{})|plan.get('prediction_options',{})
            try:model=predict(source,('SCPI',),allow_inputs=True,allow_omitted=True,allow_members=True,owner='MAIN',**options)
            except ValueError as exc:model=dict(output=None,unsupported=str(exc))
            row=dict(group=group,case=case['case'],input_sha256=sha256(source),accepted=bool(case['check'] and not case['check']['rejected']),
                before_native_prediction_equal=case['predicted_equal'],before_native_unsupported=before['prediction'].get('unsupported'),
                untouched_payloads=len(before['unchanged_streams']),diagnostic_codes=sorted(set(hex(e['code']) for e in case['diagnostics'] if e['kind']==2)))
            messages=[json.loads(line) for line in (n/'events.jsonl').read_text().splitlines()]
            assert not any(m.get('type')=='error' for m in messages)
            events=[m['payload'] for m in messages if m.get('type')=='send']
            assert not any('error' in r.get('event','') or r.get('observation_error') for r in events)
            temps=[r for r in events if r.get('event')=='temporary-create']
            row['native_temporary_requests']=[{k:r[k] for k in ('type','count','caller','result','output')} for r in temps]
            if row['accepted']:
                assert case['reopen']['check'] and not case['reopen']['check']['rejected'] and case['reopen']['identical']
                code=(n/'pcode-0-0.bin').read_bytes();assert model['output']==code,(group,case['case'],'corrected model differs')
                records=decode(code);assert [{k:v for k,v in r.items() if k not in ('raw','offset')} for r in records]==listings[case['case']]
                obs={}
                for name in ('probeR0','probeR1','probeR2'):
                    a=next(a for a in model['declarations'] if a['owner']=='MAIN' and a['name']==name)
                    obs[name]=dict(address=q_operand_text(scalar(a['allocated_family'],a['number']),text_encoding='cp932'),type=a['data_type'])
                witness=evaluate(records,obs);observed=list(witness['observations'].values());expected=plan['expected']
                row['handwritten_expectation_equal']=observed==expected
                if observed!=expected:
                    assert case['case'] in ('deferred-output-W','ZR-deferred-output','int-maximum-deferred-output') and observed==[11,33,1] and expected==[0,33,1]
                    row['expectation_correction']='The handwritten expected 0 omitted the first direct OUTPUT write of 11 to element 0, before the deferred second OUTPUT restores index 1. Saved source-only bytes and native bytes both contain that write.'
                typed=[r for r in events if r.get('event')=='typed-allocation' and r['result']==1]
                assert len(typed)==len(model['declarations'])
                for a,b in zip(typed,model['declarations'],strict=True):assert bytes.fromhex(a['after'])==bytes.fromhex(b['raw'])
                observed_temps=[]
                for r in temps:
                    assert r['result']==0
                    raw=bytes.fromhex(r['output']);tag=int.from_bytes(raw[20:24],'little');wide=r['type'] in (100,114,119)
                    family='ZR' if tag&0x8000 else {68:'D',87:'W',82:'R'}[r['type']-(32 if wide else 0)]
                    observed_temps.append((family,int.from_bytes(raw[8:12],'little'),r['count']*(2 if wide else 1),'double' if wide else 'word',r['caller']['rva']))
                expected_temps=[(r['family'],r['number'],r['width'],'word','0xca1cf') for r in model['input_buffers']]
                expected_temps += [(r['family'],r['number'],r['width'],r['kind'],'0x6d632') for r in model['slots']]
                assert sorted(observed_temps)==sorted(expected_temps),(case['case'],observed_temps,expected_temps)
                alternatives={a['key']:None if 'unsupported' in a else code==(d/f'predicted-{a["key"]}.bin').read_bytes() for a in before.get('alternatives',[])}
                row.update(pcode_sha256=sha256(code),corrected_source_prediction_equal=True,independent_lexical_equal=True,bindings=obs,witness=witness,
                    alternative_predictions_equal=alternatives,typed_allocations_verified=len(typed),temporary_allocations_verified=len(temps),
                    double_index_operands=[a for r in records for a in r.get('args',[]) if 'ZZ' in a],
                    base_compensations=[r for r in records if r.get('op')=='D+' and r.get('args',[None])[0]=='K-32768'])
            else:
                assert model['output'] is None,(case['case'],'corrected model still accepts native rejection')
                row['corrected_model_rejection']=model['unsupported']
                assert '0x500c5066' in row['diagnostic_codes'] or '0x50f1218' in row['diagnostic_codes']
            rows.append(row)
    result=dict(groups=GROUPS,cases=rows,accepted=sum(r['accepted'] for r in rows),rejected=sum(not r['accepted'] for r in rows),
        before_native_byte_matches=sum(r['accepted'] and r['before_native_prediction_equal'] is True for r in rows),
        corrected_source_byte_matches=sum(r.get('corrected_source_prediction_equal',False) for r in rows),
        typed_allocations_verified=sum(r.get('typed_allocations_verified',0) for r in rows),temporary_allocations_verified=sum(r.get('temporary_allocations_verified',0) for r in rows),
        scope='Q03UDV, independent SCPI container with controlled ST; native compile/check/export/reopen and offline initialized word-memory witnesses. No PLC execution.',
        findings=['INPUT buffers use the selected temporary family although they bypass reusable slots; exhaustion has no ordinary-D fallback.',
            'R+ZR conflict rejects capture but direct INPUT aliases compile without using the unavailable temporary bank.',
            'Omitted port storage remains ordinary persistent storage; R STRING copybacks and W/ZR double index slots reproduce native code.',
            'Dynamic ZR arrays use ZZ rather than Z. W/R arrays retain Z in the observed controls.',
            'INT/STRING array capacity is 32768 aligned words inclusive; STRING[8]/[9] both use five words per element.',
            'At exactly 32768 words, the observed ZR dynamic base is allocation+32768 and the offset receives D+ K-32768. This applies to INPUT, IN_OUT copyback and deferred OUTPUT.',
            'Attempts to create a valid STRING-array element offset above 32767 were rejected at declaration checking; such runtime behavior was not established.'])
    out=P/GROUPS[-1];save(out/'storage-bank-array-analysis.json',result);save(out/'aggregate-check-correspondence.json',verify(GROUPS))
    for name in (Path(__file__).name,'source_q_st_calls.py','source_q_width.py','witness_st_conditional_transfers.py'):(out/('verified-'+name)).write_bytes((P/name).read_bytes())
    print(json.dumps({k:v for k,v in result.items() if k not in ('groups','cases','scope','findings')}))


if __name__=='__main__':main()
