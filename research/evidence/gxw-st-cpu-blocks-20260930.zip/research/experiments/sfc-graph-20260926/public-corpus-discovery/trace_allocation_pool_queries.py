"""Observe the initializer's actual virtual range queries; owned offline helper."""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'research')]
from replay_gxw_workspace import prepare, trace_prepared
from probe_gxw_program_check_resources import SCRIPT, inspect_run

P = Path(__file__).resolve().parent
OUT = P / 'allocation-pool-queries-20260930-v4'
QUERY_SCRIPT = r'''
const hooks=new Set();
function loc(p){const m=Process.findModuleByAddress(p);return m?{module:m.name,rva:p.sub(m.base).toString()}:null;}
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='eccompiler_iec.dll')return;
 if(Process.arch!=='ia32'||m.base.add(0x4d7f0).readU8()!==0x55)throw new Error('initializer version guard');
 Interceptor.attach(m.base.add(0x47180),{onEnter(a){try{
  const context=this.context.ecx.add(0x3a2).readPointer();
  send({event:'allocation-initializer',phase:'already-allocated',context:context.toString(),query_function:loc(context.readPointer().add(0x30).readPointer()),caller:loc(this.returnAddress)});
 }catch(e){send({event:'initializer-error',error:String(e)});}}});
 Interceptor.attach(m.base.add(0x4d7f0),{onEnter(a){try{
  const context=a[0],target=context.readPointer().add(0x30).readPointer();
  send({event:'allocation-initializer',context:context.toString(),query_function:loc(target),caller:loc(this.returnAddress)});
  if(hooks.has(target.toString()))return;hooks.add(target.toString());
  Interceptor.attach(target,{onEnter(a){
   this.row={event:'allocation-range-query',selector:a[0].toInt32(),caller:loc(this.returnAddress),context:this.context.ecx.toString()};
   this.lower=a[1];this.upper=a[2];
  },onLeave(r){try{
   this.row.result=r.toInt32();this.row.lower=this.lower.readS32();this.row.upper=this.upper.readS32();send(this.row);
  }catch(e){send({event:'range-query-error',error:String(e)});}}});
 }catch(e){send({event:'initializer-error',error:String(e)});}}});
}});
'''


def main():
    OUT.mkdir(exist_ok=False)
    (OUT / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    script = OUT / 'trace.js'
    script.write_text('(()=>{' + QUERY_SCRIPT + '\n})();\n(()=>{' + SCRIPT + '\n})();', encoding='utf-8')
    rows = []
    for name, source in [('ordinary-R-and-ZR', P / 'extended-allocation-pools-20260930/all-banks/input.gxw'),
                         ('retain-D1-and-D2', P / 'retain-source-class10-20260930/local10-both/input.gxw')]:
        for attempt in range(1, 5):
            native = OUT / f'{name}-{attempt}'
            prepare(source, native, compile=True, program_check=True, export_project=True, snapshot_frontend=True, project_alias='POOLQUERY')
            process = trace_prepared(native, script)
            events = [json.loads(line) for line in (native / 'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
            if not any(e.get('operation') == 'NativeTemporaryDirectoryCollision' for e in events):
                break
        result = inspect_run(native)
        messages = [json.loads(line) for line in (native / 'events.jsonl').read_text(encoding='utf-8').splitlines()]
        errors = [m for m in messages if m.get('type') == 'error' or 'error' in m.get('payload', {}).get('event', '')]
        queries = [m['payload'] for m in messages if m.get('type') == 'send' and m['payload']['event'] in ('allocation-initializer', 'allocation-range-query', 'module-seen')]
        rows.append(dict(case=name, native_directory=str(native), process=process, check=result['check'], errors=errors, queries=queries))
        (OUT / 'comparison.json').write_text(json.dumps(rows, indent=2) + '\n', encoding='utf-8')
        unique = {json.dumps({k:v for k,v in q.items() if k!='context'}, sort_keys=True) for q in queries}
        print(json.dumps(dict(case=name, process=process, errors=errors, distinct_queries=[json.loads(s) for s in sorted(unique)])), flush=True)
        if process['timed_out'] or errors or not any(q['event'] == 'allocation-range-query' for q in queries):
            raise RuntimeError('Incomplete read-only observation')


if __name__ == '__main__':
    main()
