// Read-only discovery of the public-to-internal location adapter.
Process.attachModuleObserver({onAdded(m) {
  if(m.name.toLowerCase()!=='dzdataabs_compileradapter.dll')return;
  const seen=new Set();
  Interceptor.attach(m.base.add(0x13a2a),{onEnter(){this.active=this.returnAddress.equals(m.base.add(0x1464f));},onLeave(ret){
    if(!this.active)return;
    const self=ret.readPointer(),target=self.readPointer().add(32).readPointer(),mod=Process.findModuleByAddress(target);
    if(seen.has(target.toString()))return;seen.add(target.toString());
    send({event:'location_target',module:mod?mod.name:null,rva:mod?target.sub(mod.base).toString():null});
    const dm=Process.getModuleByName('DZDataABS_DataManager_IEC.dll');
    Interceptor.attach(dm.base.add(0x66421),{onEnter(args){this.step=args[2].toInt32();send({event:'GetPOULocation',step:this.step});},onLeave(ret){send({event:'GetPOULocationReturn',step:this.step,result:ret.toString()});}});
    const arrays=new Set();
    Interceptor.attach(dm.base.add(0x6370d),{onEnter(args){
      this.result=args[3];const array=args[1],count=array.add(8).readS32();
      send({event:'FindOffset',kind:args[0].toInt32(),step:args[2].toInt32(),count:count});
      if(!arrays.has(array.toString())&&count>=0&&count<10000){
        arrays.add(array.toString());const data=array.add(4).readPointer(),rows=[];
        for(let i=0;i<count;i++){const row=[];for(let j=0;j<6;j++)row.push(data.add(i*24+j*4).readS32());rows.push(row);}
        send({event:'OffsetArray',kind:args[0].toInt32(),rows:rows});
      }
    },onLeave(ret){send({event:'FindOffsetReturn',result:ret.toString(),index:this.result.readS32()});}});
  }});
}});
