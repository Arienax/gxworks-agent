"""Distinguish raw-preserving compilation from lossy display/re-encoding."""
from pathlib import Path
import json,struct,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.token_pou import frame_token_pou
from gxw.token_listing import decode_token_listing
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import run
P=Path(__file__).resolve().parent
OUT=P/'q02-float-source-edits'


def main():
    OUT.mkdir(exist_ok=False);(OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    source=P/'new-source-holdouts/case-14/input.gxw';raw=source.read_bytes()
    stream=next(s for s in inspect_project(raw).streams if (s.logical_name or '').endswith('.pou'))
    token=next(t for t in frame_token_pou(stream.raw).tokens if t.raw==bytes.fromhex('07eccdcc8c3f07'))
    plans=[('decimal-1-2',0xec,struct.pack('<f',1.2),struct.pack('<f',1.2)),
        ('decimal-halfway',0xec,struct.pack('<f',1234500.5),struct.pack('<f',1234501.)),
        ('scientific-negative-zero',0xed,bytes.fromhex('00000080'),bytes(4)),
        ('decimal-negative-zero',0xec,bytes.fromhex('00000080'),None)]
    ready=[]
    for tag,code,value,display_value in plans:
        target=OUT/tag;target.mkdir()
        updated=bytearray(stream.raw);updated[token.offset+1]=code;updated[token.offset+2:token.offset+6]=value
        changed,receipt=patch_raw(raw,stream.logical_name,stream.raw,bytes(updated))
        before={(s.layer,s.name):s.raw for s in inspect_project(raw).streams};after={(s.layer,s.name):s.raw for s in inspect_project(changed).streams}
        changed_streams=[list(k) for k in before.keys()|after.keys() if before.get(k)!=after.get(k)]
        assert [s for s in changed_streams if s[0]=='nested']==[['nested',stream.name]]
        (target/'source.gxw').write_bytes(changed)
        body=frame_token_pou(bytes(updated)).body;(target/'raw-candidate.bin').write_bytes(body)
        if display_value is not None:
            display=bytearray(updated);display[token.offset+2:token.offset+6]=display_value
            (target/'display-candidate.bin').write_bytes(frame_token_pou(bytes(display)).body)
        listing=decode_token_listing(bytes(updated),profile='q02',text_encoding='cp949')
        prediction=dict(original_sha256=sha256(raw),patched_sha256=sha256(changed),offset=token.offset,
            before=token.raw.hex(),after=bytes(updated[token.offset:token.offset+7]).hex(),receipt=receipt,
            changed_streams=changed_streams,unrelated_nested_preserved=True,parse_gaps=[g.reason for g in listing.gaps],
            hypothesis='Native source compilation may retain raw floating bits or re-encode lossy display text; both outputs predicted before execution.')
        (target/'prediction-before-native.json').write_text(json.dumps(prediction,indent=2),encoding='utf-8');ready.append((tag,target))
    results=[]
    for tag,target in ready:
        path=target/'source.gxw';phases=[]
        for phase in ['compile','reopen']:
            for attempt in range(1,5):
                native=target/f'{phase}-{attempt}'
                outcome=run(path,native,compile=True,program_check=True,export_project=True,snapshot_frontend=True,project_alias='QFLOATEDIT')
                events=[json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
                if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
            actual=native/'pcode-0-0.bin';display=target/'display-candidate.bin'
            row=dict(phase=phase,native_directory=str(native),outcome=outcome,
                raw_prediction_exact=actual.exists() and actual.read_bytes()==(target/'raw-candidate.bin').read_bytes(),
                display_prediction_exact=actual.exists() and display.exists() and actual.read_bytes()==display.read_bytes())
            phases.append(row);path=native/'native-saved.gxw'
            print(json.dumps(dict(case=tag,phase=phase,rejected=outcome['compiler_rejected'],full_check=outcome['program_check_completed'],
                raw_exact=row['raw_prediction_exact'],display_exact=row['display_prediction_exact'],diagnostics=outcome['diagnostics'])),flush=True)
            if not path.exists() or outcome['compiler_rejected']:break
        results.append(dict(case=tag,phases=phases));(OUT/'comparison.json').write_text(json.dumps(results,indent=2),encoding='utf-8')


if __name__=='__main__':main()
