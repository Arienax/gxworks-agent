"""Library source edits in an isolated, deliberately simplified project copy."""
from pathlib import Path
from dataclasses import replace
import base64
import json
import struct
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.text_pou import parse_st_pou
from gxw.declarations import parse_declarations, serialize_declarations
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_library_sources import snapshot_library_pous
from replay_gxw_workspace import run
from probe_gxw_task_graph import _text

P = Path(__file__).resolve().parent
OUT = P/'fx3g-library-source-roundtrip-v6'
LNB = 'F_DISBON.Program\\UtilsV5.lnb'
LBO = 'F_DISBON.Program\\UtilsV5.lbo'


def st_envelope(raw,text):
    source = parse_st_pou(raw)
    start = source.text_offset-17
    payload = text.encode('utf-16le')+b'\0\0'
    result = bytearray(raw[:source.text_offset]+payload+raw[-28:])
    struct.pack_into('<II',result,start+1,len(result)-start-29,len(result)-start-29)
    struct.pack_into('<I',result,start+13,len(payload)//2)
    assert parse_st_pou(result).text == text
    return bytes(result)


def companion_envelope(raw,text):
    assert raw[:10] == bytes.fromhex('03000000530054000000')
    count, = struct.unpack_from('<I',raw,18)
    assert 22 + 2*count + 4 == len(raw)
    payload = text.encode('utf-16le')+b'\0\0'
    return raw[:18]+struct.pack('<I',len(payload)//2)+payload+raw[-4:]


def main():
    OUT.mkdir(exist_ok=False)
    (OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    original = (P/'cross-family-source-holdouts/case-00/input.gxw').read_bytes()
    streams = {s.logical_name:s.raw for s in inspect_project(original).streams if s.logical_name}
    entry = 'MAIN.Program.pou'
    # v1's D0 argument and v2's IEC typed literal were rejected. Reuse the
    # exact call spelling independently compiled in the original MAIN source.
    main_text = 'Y0 := F_DISBON(16#00000004, 2);\r\n'
    baseline,entry_receipt = patch_raw(original,entry,streams[entry],st_envelope(streams[entry],main_text))
    labels = 'MAIN.Labels.lh'
    document = parse_declarations(streams[labels],logical_name=labels)
    # v3 still emitted 40,973 bytes and reported the original MAIN errors.
    # Remove the unused instance declarations as a separate, recorded control.
    baseline,label_receipt = patch_raw(baseline,labels,streams[labels],serialize_declarations(replace(document,rows=())))
    # Four additional tasks directly reference library PRGs. Their FALSE
    # configuration text does not remove their code from native compilation.
    # Clear those entry lists only in this isolated single-call control.
    task_receipts = []
    emptied_tasks = set()
    for task in ('AM.tsk','TCO.tsk','TCO_TEST.tsk','MB.tsk'):
        raw = streams[task]
        _,offset = _text(raw,54)
        _,offset = _text(raw,offset)
        assert raw[offset:offset+8] in (bytes.fromhex('1f00000000000000'),bytes.fromhex('1a00000000000000'))
        offset += 8
        baseline,receipt = patch_raw(baseline,task,raw,raw[:offset]+bytes(4))
        task_receipts.append(receipt)
        emptied_tasks.add(task)
    cases = [('original-library',None,False),('true-source-only','F_DISBON := TRUE;\r\n',False),
             ('false-source-only','F_DISBON := FALSE;\r\n',False),('true-both-copies','F_DISBON := TRUE;\r\n',True)]
    results=[]
    for name,text,both in cases:
        directory = OUT/name
        directory.mkdir()
        source = baseline
        receipts = [entry_receipt,label_receipt,*task_receipts]
        if text is not None:
            source,receipt = patch_raw(source,LNB,streams[LNB],st_envelope(streams[LNB],text))
            receipts.append(receipt)
        if both:
            source,receipt = patch_raw(source,LBO,streams[LBO],companion_envelope(streams[LBO],text))
            receipts.append(receipt)
        changed = {s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
        touched = [k for k in streams if streams[k] != changed[k]]
        assert set(touched) == {entry,labels} | emptied_tasks | ({LNB} if text is not None else set()) | ({LBO} if both else set())
        path = directory/'candidate.gxw'
        path.write_bytes(source)
        (directory/'prediction-before-native.json').write_text(json.dumps(dict(
            original_sha256=sha256(original),candidate_sha256=sha256(source),touched=touched,
            main_text=main_text,library_text=text,receipts=receipts,other_nested_payloads_byte_identical=True),indent=2),encoding='utf-8')
        row = dict(case=name,phases=[])
        for phase in ('compile','reopen'):
            for attempt in range(1,5):
                native = directory/f'{phase}-{attempt}'
                outcome=run(path,native,compile=True,program_check=True,export_project=True,
                            snapshot_frontend=True,project_alias='LIBSAVE',refresh_program_check=True)
                events=[json.loads(line) for line in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
                if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):
                    break
            result=dict(phase=phase,native_directory=str(native),outcome=outcome)
            pcode=native/'pcode-0-0.bin'
            if pcode.exists():
                result['pcode_sha256']=sha256(pcode.read_bytes())
                result['pcode_bytes']=len(pcode.read_bytes())
            if (native/'frontend-snapshot.json').exists():
                snapshot=json.loads((native/'frontend-snapshot.json').read_text(encoding='utf-8'))
                r,=[r for r in snapshot_library_pous(snapshot) if (r['library'],r['name'])==('UtilsV5','F_DISBON')]
                body=base64.b64decode(r['program_raw_base64'])
                count,=struct.unpack_from('<I',body,72)
                result['frontend_text']=body[76:76+count].decode('cp1252')
            path=native/'native-saved.gxw'
            if path.exists():
                saved={s.logical_name:s.raw for s in inspect_project(path.read_bytes()).streams if s.logical_name}
                result.update(saved_lnb_text=parse_st_pou(saved[LNB]).text,
                    saved_lbo_matches_candidate=saved[LBO]==changed[LBO],saved_lnb_matches_candidate=saved[LNB]==changed[LNB],
                    changed_nested_payloads_from_candidate=[k for k in saved.keys() | changed.keys() if saved.get(k)!=changed.get(k)])
            row['phases'].append(result)
            (directory/'comparison.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
            print(json.dumps(dict(case=name,phase=phase,open=outcome['open_succeeded'],rejected=outcome['compiler_rejected'],
                program_check=outcome['program_check_completed'],saved=path.exists(),pcode=result.get('pcode_sha256'),
                lnb_preserved=result.get('saved_lnb_matches_candidate'),lbo_preserved=result.get('saved_lbo_matches_candidate'))),flush=True)
            if not path.exists() or outcome['compiler_rejected']:
                break
        results.append(row)
        (OUT/'comparison.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
        if name == 'original-library' and (not path.exists() or outcome['compiler_rejected']):
            break


if __name__=='__main__':
    main()
