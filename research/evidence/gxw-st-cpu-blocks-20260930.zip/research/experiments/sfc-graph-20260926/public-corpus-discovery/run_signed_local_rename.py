"""Grow two known payloads while preserving an original verified hash envelope."""
import base64
import hashlib
import json
from pathlib import Path
import struct
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'research')]
from gxw.container_writer import validate_cfb_streams, replace_project_stream
from gxw.declarations import parse_declarations, edit_declarations, serialize_declarations
from gxw.project_metadata import logical_mapping, synchronize_history
from gxw.token_pou import frame_token_pou, parse_token_fragment
from native_gxw_tokens import native_batch, Q_DLL
from probe_gxw_integrity import inspect, observed_digest, FILES, TABLE_BYTES
from probe_gxw_parameters import device_allocation_record
from replay_gxw_workspace import run

P = Path(__file__).resolve().parent
OUT = P / 'project2-signed-local-rename-2'
OUT.mkdir(exist_ok=False)
source = (P / 'samples/project2.gxw').read_bytes()
assert inspect(source)['valid'] is True
outer = validate_cfb_streams(source)
hdb_body, old_table = outer['_hdb'][:-TABLE_BYTES], outer['_hdb'][-TABLE_BYTES:]
nested = validate_cfb_streams(hdb_body)
mapping = logical_mapping(outer['projectdatalist.xml'])
streams = {name: nested[physical] for name, physical in mapping.items() if physical in nested}
old_name, new_name = 't_물품없음', 'NoItemTimerNativeIntegrityProbe'
labels = parse_declarations(streams['MAIN.Labels.lh'], logical_name='MAIN.Labels.lh')
assert sum(row.name == old_name for row in labels.rows) == 1
assert not any(row.name == new_name for row in labels.rows)
new_labels = serialize_declarations(edit_declarations(labels, renames={old_name: new_name}))
program = frame_token_pou(streams['MAIN.Program.pou'])
texts = [f"OUT '{name} K10" for name in [old_name, new_name]] + [f"LD '{name}" for name in [old_name, new_name]]
rows = native_batch([dict(mode='encode', text=text,
    input_base64=base64.b64encode(text.encode('cp949') + b'\0\0').decode()) for text in texts],
    OUT / 'native-encode', dll=Q_DLL, cpu_code=209, native_versions=(25,),
    device_context=device_allocation_record(streams['Param.wpa']).raw)
assert all(row['return_code'] == '0x00000000' for row in rows)
encoded = [base64.b64decode(row['output_base64']) for row in rows]
native_old = [t.raw for t in parse_token_fragment(encoded[0], 0, len(encoded[0])).tokens if t.raw[1] == 0xdf]
native_new = [t.raw for t in parse_token_fragment(encoded[1], 0, len(encoded[1])).tokens if t.raw[1] == 0xdf]
assert len(native_old) == len(native_new) == 1
assert native_old[0][2:-1] == old_name.encode('cp949')
assert native_new[0][2:-1] == new_name.encode('cp949')
changed_tokens = sum(token.raw == native_old[0] for token in program.tokens)
assert 1 <= changed_tokens <= 16
new_body = b''.join(native_new[0] if token.raw == native_old[0] else token.raw for token in program.tokens)
new_program = program.raw[:program.body_offset] + new_body + program.raw[program.body_end:]
header = bytearray(new_program)
growth = len(new_program) - len(program.raw)
struct.pack_into('<II', header, 55, len(program.body) + growth + 20, len(program.body) + growth + 20)
new_program = bytes(header)
framed = frame_token_pou(new_program)
assert len(framed.tokens) == len(program.tokens)
assert sum(a.raw != b.raw for a, b in zip(program.tokens, framed.tokens)) == changed_tokens
mutations = {'MAIN.Program.pou': new_program, 'MAIN.Labels.lh': new_labels}
history, changes, preserved = synchronize_history(outer['history.xml'],
    {name: (mapping[name], streams[name], raw) for name, raw in mutations.items()})
new_body, allocation = hdb_body, []
for name, raw in mutations.items():
    new_body, receipt = replace_project_stream(new_body, mapping[name], raw)
    allocation.append(dict(name=name, old_bytes=len(streams[name]), new_bytes=len(raw), receipt=str(receipt)))
assert validate_cfb_streams(new_body) == dict(nested, **{mapping[name]: raw for name, raw in mutations.items()})
new_outer = dict(outer, **{'history.xml': history})
new_table = b''.join(observed_digest(new_body if name == '_hdb' else new_outer[name]) for name in FILES)
new_hdb = new_body + new_table
result, _ = replace_project_stream(source, '_hdb', new_hdb)
result, _ = replace_project_stream(result, 'history.xml', history)
result, _ = replace_project_stream(result, 'Project.gd2', observed_digest(new_hdb))
assert validate_cfb_streams(result) == dict(new_outer, _hdb=new_hdb, **{'Project.gd2': observed_digest(new_hdb)})
assert inspect(result)['valid'] is True
(OUT / 'renamed.gxw').write_bytes(result)
(OUT / 'mutation.json').write_text(json.dumps(dict(old_name=old_name, new_name=new_name,
    allocation=allocation, history_changes=changes, preserved_metadata=preserved,
    original_sha256=hashlib.sha256(source).hexdigest(), output_sha256=hashlib.sha256(result).hexdigest(),
    original_hdb_body_bytes=len(hdb_body), new_hdb_body_bytes=len(new_body),
    unchanged_nested_payloads='byte-identical', changed_source_tokens=changed_tokens,
    scope='experimental rename of one local timer and its exact label tokens'), ensure_ascii=False, indent=2), encoding='utf-8')
first = run(OUT / 'renamed.gxw', OUT / 'native', compile=True, export_project=True, project_alias='GROWPATCH')
print('native', first['returncode'], first['compile_completed'], first['diagnostics'], flush=True)
if first.get('native_export'):
    second = run(OUT / 'native/native-saved.gxw', OUT / 'reopen', compile=True, export_project=True)
    baseline = json.loads((P / 'project2-export-native-hash/outcome.json').read_text())
    comparison = dict(baseline_equal=first['outputs'] == baseline['outputs'],
        reopen_equal=first['outputs'] == second['outputs'], reopen_returncode=second['returncode'],
        reopen_completed=second['compile_completed'], diagnostics=second['diagnostics'])
    (OUT / 'compiled-comparison.json').write_text(json.dumps(comparison, indent=2))
    print(json.dumps(comparison), flush=True)
