"""Resolve simple-FB marker calls through a global instance declaration."""
from pathlib import Path
import json,struct,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.declarations import parse_declarations,edit_declarations,serialize_declarations
from gxw.compiler_tables import parse_compiler_tables
from probe_gxw_simple_fb import frame_source,observe_calls,marker
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import run
P=Path(__file__).resolve().parent
out=P/'q-global-fb-calls';out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
rows=[]
for case,baseline in [('valid-global-call','valid-called'),('bad-global-body','bad-called')]:
    source=(P/'q-fb-compile-dependencies'/baseline/'input.gxw').read_bytes()
    streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
    frame=frame_source(streams['MAIN.Program.pou']);tokens=[];edits=[]
    for token in frame.tokens:
        text=marker(token)
        if text in [';FB BLK START SCPI(SCPI_1)',';INSTANCE_NAME SCPI_1']:
            updated=text.replace('SCPI_1','GlobalInstance').encode('ascii');length=len(updated)+4
            assert length<256
            tokens.append(bytes([length,0x80,1])+updated+bytes([length]))
        else:tokens.append(token.raw)
    body=b''.join(tokens);new=bytearray(frame.raw[:frame.body_offset]+body+frame.raw[frame.body_end:])
    for offset in (55,59):struct.pack_into('<I',new,offset,struct.unpack_from('<I',frame.raw,offset)[0]+len(new)-len(frame.raw))
    calls=observe_calls(frame_source(bytes(new)));assert len(calls['calls'])==2 and not calls['gaps']
    assert all(c['instance']=='GlobalInstance' and not c['gaps'] for c in calls['calls'])
    replacements={'MAIN.Program.pou':bytes(new)}
    logical='MAIN.Labels.lh';doc=parse_declarations(streams[logical],logical_name=logical)
    replacements[logical]=serialize_declarations(edit_declarations(doc,remove=['SCPI_1','SCPI_2']))
    logical='Global1.gh';doc=parse_declarations(streams[logical],logical_name=logical)
    replacements[logical]=serialize_declarations(edit_declarations(doc,upserts=[dict(name='GlobalInstance',data_type='SCPI',kind='function_block',class_name='VAR_GLOBAL')]))
    changed=source
    for logical,new in replacements.items():
        changed,receipt=patch_raw(changed,logical,streams[logical],new);edits.append(receipt)
    assert {s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}==dict(streams,**replacements)
    directory=out/case;directory.mkdir();path=directory/'input.gxw';path.write_bytes(changed)
    (directory/'mutation.json').write_text(json.dumps(dict(source_sha256=sha256(source),changed_sha256=sha256(changed),edits=edits,unrelated_payloads='byte-identical'),indent=2),encoding='utf-8')
    for attempt in range(1,9):
        native=directory/('native' if attempt==1 else 'native-v'+str(attempt))
        result=run(path,native,compile=True,snapshot_frontend=True,export_project=True,project_alias='QGLOBALCALL')
        events=[json.loads(s) for s in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
        if (native/'pcode-0-0.bin').exists() or not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
    row=dict(case=case,native_directory=str(native.relative_to(out)),native={k:result[k] for k in ('returncode','open_succeeded','compile_completed','compiler_rejected','diagnostics')})
    if row['native']['returncode']==0 and row['native']['compile_completed'] and not row['native']['compiler_rejected']:
        tables=parse_compiler_tables((native/'compiler_DZComp/CGTable.dat').read_bytes());row['instance_references']=[]
        for record in tables.tables[2].records:
            component=tables.component_at(record.table_offset);reference=tables.component_instance_pou_offset(component)
            if reference is not None:row['instance_references'].append(dict(name=component.name_bytes.decode('ascii'),component_offset=record.table_offset,
                global_reference=component.global_offset,instance_reference=reference,pou_name=tables.pou_at(reference).name_bytes.decode('ascii')))
        row['pcode_sha256']={f.name:sha256(f.read_bytes()) for f in native.glob('pcode-*.bin')}
        row['matches_single_local_instance']={f.name:f.read_bytes()==(P/'q-declaration-compile-dependencies/remove-uncalled-instance/native'/f.name).read_bytes() for f in native.glob('pcode-*.bin')}
    rows.append(row);(directory/'comparison.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
    print(json.dumps(row),flush=True)
(out/'comparison.json').write_text(json.dumps(dict(cases=rows,scope=__doc__),ensure_ascii=False,indent=2),encoding='utf-8')
