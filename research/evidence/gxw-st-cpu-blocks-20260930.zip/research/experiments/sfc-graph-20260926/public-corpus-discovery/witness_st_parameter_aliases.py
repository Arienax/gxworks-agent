"""Compare saved multi-parameter alias experiments without executing vendor code."""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from gxw.project_metadata import read_project_text_context
from probe_minimal_conditional_port_writes import streams,save
from source_q_direct_declarations import DirectDeclarations
from witness_st_conditional_transfers import decode,evaluate
from verify_temporary_check_correspondence import verify
P=Path(__file__).resolve().parent


def main():
    groups=sys.argv[1:] or ['st-fb-parameter-aliases-20260930','st-fb-parameter-alias-holdouts-20260930']
    results=[]
    for group in groups:
        directory=P/group;plan=json.loads((directory/'experiment-plan.json').read_text())
        native={r['case']:r for r in json.loads((directory/'native-listings.json').read_text())}
        for case in json.loads((directory/'comparison.json').read_text()):
            n=Path(case['native_directory']);source=(n/'input.gxw').read_bytes();raw=(n/'pcode-0-0.bin').read_bytes();records=decode(raw)
            assert native[case['case']]['return_code']=='0x00000000'
            assert [{k:v for k,v in r.items() if k not in ('raw','offset')} for r in records]==native[case['case']]['records']
            content={k:v for k,v in streams(source).items() if k!='CGTable.dat'}
            context=read_project_text_context(next(v for k,v in content.items() if k.endswith('.prj')))
            d=DirectDeclarations(content,context['text_encoding'],local_fb_definitions=('Wrapper',),allow_string_arrays=True);d.add_owner('POU_01')
            bindings={}
            for key,name in [('array0','prober0'),('array1','prober1'),('array2','prober2'),('result','proberesult')]:
                item=d.bound['POU_01'][name];bindings[key]=dict(address=item['family']+str(item['number']),type=item['row'].data_type)
            witness=evaluate(records,bindings)
            expected=plan.get('expected_observations',{}).get(case['case'])
            if expected:assert all(witness['observations'][k]==v for k,v in expected.items())
            predicted=directory/case['case']/'predicted-0.bin'
            rows=dict(group=group,case=case['case'],input_sha256=sha256(source),pcode_sha256=sha256(raw),
                native_core_decode_equal=True,bindings=bindings,**witness)
            if predicted.exists():
                pred=predicted.read_bytes();rows['before_native_prediction']=dict(sha256=sha256(pred),byte_identical=pred==raw,
                    observations=evaluate(decode(pred),bindings)['observations'])
            results.append(rows)
            print(json.dumps(dict(group=group,case=case['case'],observations=witness['observations'])))
    out=P/groups[-1]
    save(out/'offline-parameter-witnesses.json',dict(scope='Finite initialized INT/ASCII-string word-memory witnesses. Independent native/Core lexical cross-check; no PLC execution or general source semantic oracle.',cases=results))
    save(out/'current-check-export-correspondence.json',verify(groups))
    (out/Path(__file__).name).write_bytes(Path(__file__).read_bytes())


if __name__=='__main__':main()
