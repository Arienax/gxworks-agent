function where(a){try{const m=Process.findModuleByAddress(a);return m?{module:m.name,rva:a.sub(m.base).toString()}:a.toString();}catch(_){return null;}}
let samples=0;
const timer=setInterval(function(){
 if(++samples>5){clearInterval(timer);return;}
 const rows=[];
 for(const t of Process.enumerateThreads()){
  try{rows.push({id:t.id,state:t.state,pc:where(t.context.pc),stack:Thread.backtrace(t.context,Backtracer.ACCURATE).slice(0,24).map(where)});}catch(e){rows.push({id:t.id,error:String(e)});}
 }
 send({event:'offline_open_stacks',sample:samples,threads:rows});
},4000);
