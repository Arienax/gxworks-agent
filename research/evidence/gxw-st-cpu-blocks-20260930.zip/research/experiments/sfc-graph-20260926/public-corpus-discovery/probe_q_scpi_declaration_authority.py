"""Predict SCPI declaration changes before fresh isolated native compilation."""
from dataclasses import replace
from pathlib import Path
import json
import sys
ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'research')]
from gxw.lossless import inspect_project, sha256
from gxw.declarations import parse_declarations, serialize_declarations, edit_declarations
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import run
from source_q_direct_projection import project_projection
from compare_q_scpi_source_without_cache import native_assignments

P = Path(__file__).resolve().parent
OUT = P/'q-scpi-declaration-authority'


def payloads(raw):
    return {s.logical_name: s.raw for s in inspect_project(raw).streams if s.logical_name}


def main():
    OUT.mkdir(exist_ok=False)
    for name in ['probe_q_scpi_declaration_authority.py', 'compare_q_scpi_source_without_cache.py', 'source_q_direct_projection.py', 'source_q_direct_declarations.py', 'source_q_call_connections.py', 'source_q_label_binding.py', 'source_q_allocation.py', 'source_q_width.py', 'q-width-static-tables.json']:
        (OUT/name).write_bytes((P/name).read_bytes())
    plan = next(p for p in json.loads((P/'scpi-alias-device-methods/comparison.json').read_text()) if p['case'] == 'immediates')
    source = Path(plan['source']).read_bytes(); before = payloads(source)
    logical = 'SCPI.Labels.lh'; doc = parse_declarations(before[logical], logical_name=logical)
    ids = sorted(r.record_id for r in doc.rows); reversed_ids = dict(zip(ids, reversed(ids)))
    expanded = edit_declarations(doc, upserts=[dict(name='unused_text_matrix', data_type='ARRAY [-1..1] OF STRING[5]', initial_value="[3('')]")])
    expanded = replace(expanded, rows=tuple(replace(r, record_id=1 if r.name == 'unused_text_matrix' else r.record_id+1) for r in expanded.rows))
    plans = [
        ('record-ids-reversed', replace(doc, rows=tuple(replace(r, record_id=reversed_ids[r.record_id]) for r in doc.rows))),
        ('member-array-grown-shifted', edit_declarations(doc, upserts=[dict(name='rBuf', data_type='ARRAY [-3..52] OF INT', initial_value='[56(0)]')])),
        ('port-strings-smaller', edit_declarations(doc, upserts=[dict(name=n, data_type='STRING[7]', initial_value="''") for n in ['iResStr', 'oRecvData']])),
        ('new-text-array-oldest-id', expanded),
    ]
    ready = []; results = []
    for case, document in plans:
        directory = OUT/case; directory.mkdir()
        labels = serialize_declarations(document)
        changed, receipt = patch_raw(source, logical, before[logical], labels)
        assert payloads(changed) == dict(before, **{logical: labels})
        path = directory/'input.gxw'; path.write_bytes(changed)
        predictions = project_projection(changed, allow_scpi=True, resource_limit=1)
        for row in predictions:
            (directory/f'predicted-{row["resource_index"]}.bin').write_bytes(row.pop('output'))
        (directory/'prediction-before-native.json').write_text(json.dumps(dict(source_sha256=sha256(source), changed_sha256=sha256(changed),
            mutation=case, receipt=receipt, compiler_cache='byte-identical, excluded from prediction', predictions=predictions,
            scope='First MAIN resource only; auxiliary ST resource is not projected.'), indent=2), encoding='utf-8')
        ready.append((case, directory, path, predictions))
    for case, directory, path, predictions in ready:
        for attempt in range(1, 5):
            native = directory/f'native-{attempt}'
            outcome = run(path, native, compile=True, export_project=True, project_alias='QFBDECL')
            events = [json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
            if not any(e.get('operation') == 'NativeTemporaryDirectoryCollision' for e in events):
                break
        accepted = outcome['returncode'] == 0 and outcome['compile_completed'] and not outcome['compiler_rejected'] and (native/'native-saved.gxw').exists()
        programs = []
        if accepted:
            actual = native_assignments((native/'native-saved.gxw').read_bytes(), ['MAIN'], 'cp932')
            for pred in predictions:
                i = pred['resource_index']; theirs = (native/f'pcode-{i}-0.bin').read_bytes(); ours = (directory/f'predicted-{i}.bin').read_bytes()
                diffs = [dict(identity=k, predicted=v, native=actual.get(k)) for k, v in pred['assignments'].items() if actual.get(k) != v]
                programs.append(dict(program=pred['program'], records=pred['records'], byte_identical=ours == theirs,
                    predicted_sha256=sha256(ours), native_sha256=sha256(theirs), allocations=len(pred['allocations']), allocation_differences=diffs))
        row = dict(case=case, native_directory=str(native), native_accepted=accepted, outcome=outcome, programs=programs)
        (directory/'comparison.json').write_text(json.dumps(row, indent=2), encoding='utf-8')
        results.append(row)
        (OUT/'comparison.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
        print(json.dumps(dict(case=case, native_accepted=accepted, programs=programs, diagnostics=outcome['diagnostics'])), flush=True)


if __name__ == '__main__':
    main()
