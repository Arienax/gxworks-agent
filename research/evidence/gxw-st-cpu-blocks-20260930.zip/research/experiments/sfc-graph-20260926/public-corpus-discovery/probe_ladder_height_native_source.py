"""Native source control for the independently observed 24-row conversion boundary."""
from pathlib import Path
import json
import sys

ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from probe_gxw_integrity import patch_verified_payloads
from replay_gxw_workspace import run
from probe_fx3g_library_roundtrip import st_envelope

P=Path(__file__).resolve().parent
OUT=P/'ladder-height-native-source'
BASE=P/'fx3g-library-source-roundtrip-v6/true-source-only/compile-1/native-saved.gxw'

def main():
    OUT.mkdir(exist_ok=False)
    (OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    original=BASE.read_bytes()
    streams={s.logical_name:s.raw for s in inspect_project(original).streams if s.logical_name}
    rows=[]
    for n in (24,25):
        out=OUT/f'assignments-{n}';out.mkdir()
        text='\r\n'.join(f'D{i} := {i};' for i in range(n))+'\r\n'
        changed=st_envelope(streams['MAIN.Program.pou'],text)
        candidate,receipt=patch_verified_payloads(original,{'MAIN.Program.pou':(streams['MAIN.Program.pou'],changed)})
        path=out/'candidate.gxw';path.write_bytes(candidate)
        after={s.logical_name:s.raw for s in inspect_project(candidate).streams if s.logical_name}
        assert [k for k in streams if streams[k]!=after[k]]==['MAIN.Program.pou']
        (out/'prediction-before-native.json').write_text(json.dumps(dict(source_sha256=sha256(original),
            candidate_sha256=sha256(candidate),receipt=receipt,text=text,
            hypothesis='If the compiler groups these assignments under one LD, 24 should pass and 25 should produce 0x050c9521. Grouping is not assumed.'),indent=2),encoding='utf-8')
        for attempt in range(1,5):
            native=out/f'native-{attempt}'
            outcome=run(path,native,compile=True,export_project=True,program_check=True,project_alias='HEIGHT')
            events=[json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
            if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
        errors=[r for r in outcome['diagnostics'] if r['kind']==2]
        row=dict(assignments=n,native_directory=str(native),outcome=outcome,errors=errors)
        rows.append(row);(OUT/'comparison.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
        print(json.dumps(dict(assignments=n,check_completed=outcome['program_check_completed'],
            rejected=outcome['compiler_rejected'],errors=errors,exported=(native/'native-saved.gxw').exists())),flush=True)

if __name__=='__main__':main()
