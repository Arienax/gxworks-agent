"""Match exact-instance member paths to native allocation queries and code."""
from pathlib import Path
import json,re,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from gxw.compiler_tables import parse_compiler_tables
from gxw.lossless import sha256
from probe_gxw_operand_bindings import resolve_operand
P=Path(__file__).resolve().parent/'array-operand-controls'
for case in sys.argv[1:] or ['word-bit-fb-members','word-bit-fb-two-instances']:
 parent=P/case;comparison=json.loads((parent/'comparison.json').read_text())
 raw=(parent/'captured-symbols.bin').read_bytes();tables=parse_compiler_tables(raw)
 trace=parent/comparison['trace_attempts'][-1]['directory'];allocated=None;root_id=None;generated=None
 for line in (trace/'events.jsonl').read_text().splitlines():
  e=json.loads(line).get('payload',{})
  if e.get('event')!='enter' or e.get('name')!='Compile':continue
  b={r['label']:r for r in e['buffers']}
  names={k:bytes.fromhex(v['bytes']).split(b'\0')[0] for k,v in b.items() if k.startswith('name_') and v.get('bytes')}
  for k,name in names.items():
   if name==b'POU_01':
    assert raw==bytes.fromhex(b['symbolic_data']['bytes']);root_id=e['id'];generated=bytes.fromhex(b[k.replace('name_','source_')]['bytes']).decode()
  if b'Task_01' in names.values() and root_id is not None and e['id']>root_id:
   assert allocated is None;allocated=parse_compiler_tables(bytes.fromhex(b['symbolic_data']['bytes']))
 assert allocated is not None and generated is not None
 outputs=list(trace.glob('pcode-*.bin'));assert outputs
 assert all(p.read_bytes()==(parent/'native'/p.name).read_bytes() for p in outputs)
 queries=json.loads((parent/'native/native-device-assignments.json').read_text(encoding='utf-8-sig'))
 queried={a['name']:a for q in queries if q['hresult']==q['code']==0 for a in q['assignments']}
 instances=[tables.component_at(r.table_offset) for r in tables.tables[2].records]
 instances=[c for c in instances if c.instance_pou_offset is not None and c.name_bytes in (b'EdgeProbe',b'EdgeProbe2',b'LatchProbe')]
 rows=[]
 for c in instances:
  for member in tables.components(tables.pou_at(c.instance_pou_offset)):
   token=f'K{c.record.table_offset}.K{member.record.table_offset}'
   bound=resolve_operand(token,tables,allocated,cpu='Q03UDV');native=queried.get(bound['qualified_component'])
   rows.append(dict(token=token,binding=bound,native_query=native,exact=bool(native) and bound['operand']==native['address']))
 accesses=[]
 dump=(parent/'native-table-reader/native-table-dump.txt').read_text(encoding='cp1252')
 positions={int(m[1]):int(m[2]) for m in re.finditer(r'^Index +(\d+) , Line +(-?\d+) , NW +(-?\d+) , POUIdx +(\d+)',dump,re.M)}
 source_rows={r['line']['line_index']:r for r in comparison['calls']}
 for line in generated.splitlines():
  m=re.search(r':= (K\d+\.K\d+); D(\d+)$',line)
  if not m or positions[int(m[2])] not in source_rows:continue
  bound=resolve_operand(m[1],tables,allocated,cpu='Q03UDV');source=source_rows[positions[int(m[2])]]
  reads=[r for r in source['records'] if r['op'] in ('LD','LDI') and r['args']==[bound['operand']]]
  accesses.append(dict(generated=line,binding=bound,source=source,observed_member_reads=reads,exact=[r['op'] for r in reads]==['LD','LDI']))
 rejected=[]
 for instance in instances:
  for other in instances:
   if other is instance:continue
   member=next(c for c in tables.components(tables.pou_at(other.instance_pou_offset)) if c.scope_code==4)
   token=f'K{instance.record.table_offset}.K{member.record.table_offset}'
   bound=resolve_operand(token,tables,allocated,cpu='Q03UDV')
   rejected.append(dict(token=token,binding=bound,correctly_opaque=bound['operand'] is None and bound['gaps']==['member does not belong to the referenced instance POU']))
 result=dict(case=case,source_symbols_sha256=sha256(raw),allocated_symbols_sha256=sha256(allocated.raw),
  members=rows,source_accesses=accesses,cross_instance_negative_controls=rejected,
  summary=dict(member_bindings=len(rows),query_exact=sum(r['exact'] for r in rows),source_accesses=len(accesses),source_exact=sum(r['exact'] for r in accesses),wrong_instance_paths=len(rejected),wrong_instance_paths_opaque=sum(r['correctly_opaque'] for r in rejected)))
 (parent/'instance-member-comparison.json').write_text(json.dumps(result,indent=2))
 print(json.dumps(dict(case=case,**result['summary'])))
