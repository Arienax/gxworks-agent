"""Does the native pending marker invalidate a known stale structured cache?"""
from pathlib import Path
import base64, json, os, subprocess, sys, zipfile
ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'research')]
from gxw.lossless import inspect_project, sha256
from gxw.project_metadata import mark_observed_source_compile_pending
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import prepare
from native_gxw_tokens import native_batch, native_il_projection, DEFAULT_DLL
P = Path(__file__).resolve().parent


def run_status(path, target, *, fresh, compile=True, plan_overrides=None):
    exe = prepare(path, target, compile=compile, export_project=compile, project_alias='STATUSCACHE')
    plan = json.loads((target/'plan.json').read_text())
    plan.update(reset_compiler=fresh, fresh_compiler_state=fresh)
    plan.update(plan_overrides or {})
    (target/'plan.json').write_text(json.dumps(plan, indent=2))
    helper = (target/'WorkspaceReplayOracle.cs').read_text()
    marker = '            if(!Convert.ToBoolean(plan["compile"]))return;'
    assert helper.count(marker) == 1
    helper = helper.replace(marker, '            CompileStatusSnapshot(workspace,id,"before-build");\n'+marker)
    marker = '            bool compilerRejected=WaitReports(compiler,changeSfc?168:40,"Progress");'
    assert helper.count(marker) == 1
    helper = helper.replace(marker, marker+'\n            CompileStatusSnapshot(workspace,id,"after-build");')
    (target/'WorkspaceReplayOracle.cs').write_text(helper)
    (target/'NativeCompileStatusSnapshotV2.cs').write_bytes((P/'NativeCompileStatusSnapshotV2.cs').read_bytes())
    files = ['WorkspaceReplayOracle.cs','NativeFrontendSnapshot.cs','NativeSfcGraphOracle.cs',
             'NativeWorkspaceCopyOracle.cs','NativeCompileStatusSnapshotV2.cs']
    csc = Path(os.environ['WINDIR'])/'Microsoft.NET/Framework/v4.0.30319/csc.exe'
    build = subprocess.run([str(csc),'/nologo','/platform:x86','/r:System.Web.Extensions.dll',
        '/r:System.Windows.Forms.dll','/out:'+str(exe), *[str(target/f) for f in files]],
        capture_output=True, timeout=20, creationflags=subprocess.CREATE_NO_WINDOW)
    (target/'status-build.stdout.bin').write_bytes(build.stdout)
    (target/'status-build.stderr.bin').write_bytes(build.stderr)
    build.check_returncode()
    request = json.loads((target/'request.json').read_text())
    request.update(actual_helper_sha256=sha256((target/'WorkspaceReplayOracle.cs').read_bytes()),
                   status_snapshot_sha256=sha256((target/'NativeCompileStatusSnapshotV2.cs').read_bytes()),
                   actual_plan_sha256=sha256((target/'plan.json').read_bytes()))
    (target/'request.json').write_text(json.dumps(request, indent=2))
    process = subprocess.run([str(exe),str(target/'plan.json')], cwd=target, capture_output=True,
                             timeout=50, creationflags=subprocess.CREATE_NO_WINDOW)
    (target/'process.stdout.bin').write_bytes(process.stdout)
    (target/'process.stderr.bin').write_bytes(process.stderr)
    events = [json.loads(s) for s in (target/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    snapshots = {}; phase = None
    for event in events:
        if event['operation'] == 'CompileStatusSnapshotBegin':
            phase = event['phase']; snapshots[phase] = []
        elif event['operation'] in ('CompileStatusSnapshotNode','CompileAllAfterSnapshot','LabelModeSnapshot'):
            snapshots[phase].append(event)
    diagnostics = {json.dumps({k:v for k,v in r.items() if k != 'raw_base64'}, sort_keys=True)
                   for e in events for r in e.get('reports',[]) if r['kind'] in (2,3)}
    result = dict(case=target.name, input_sha256=sha256(path.read_bytes()), fresh_backend=fresh,
        returncode=process.returncode, snapshots=snapshots, diagnostics=[json.loads(s) for s in sorted(diagnostics)],
        compile_completed=any(e['operation']=='Progress' and e.get('percent')==100 for e in events),
        exported=(target/'native-saved.gxw').exists(), last_event=events[-1],
        outputs={f.name:dict(bytes=f.stat().st_size,sha256=sha256(f.read_bytes())) for f in target.glob('pcode-*.bin')})
    (target/'comparison.json').write_text(json.dumps(result, indent=2))
    print(json.dumps({k:v for k,v in result.items() if k not in ('snapshots','last_event')}), flush=True)
    return result


if __name__ == '__main__':
    out = P/'compile-pending-stale-cache'; out.mkdir(exist_ok=False)
    (out/'probe.py').write_bytes(Path(__file__).read_bytes())
    archive = ROOT/'research/evidence/gxw-block-generation-20260913.zip'
    with zipfile.ZipFile(archive) as z: source = z.read('samples/R.gxw')
    (out/'baseline.gxw').write_bytes(source)
    streams = {s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
    logical = '1.Program.pou'; raw = streams[logical]
    updated = mark_observed_source_compile_pending(raw, logical_name=logical)
    pending, receipt = patch_raw(source, logical, raw, updated)
    assert {s.logical_name:s.raw for s in inspect_project(pending).streams if s.logical_name} == dict(streams, **{logical:updated})
    (out/'pending.gxw').write_bytes(pending)
    (out/'mutation.json').write_text(json.dumps(dict(source_archive=str(archive.relative_to(ROOT)),
        archive_sha256=sha256(archive.read_bytes()), member='samples/R.gxw', source_sha256=sha256(source),
        pending_sha256=sha256(pending), receipt=receipt, semantic_source='unchanged',
        unrelated_payloads='byte-identical'), indent=2))
    rows = []
    for case, filename, fresh in [('baseline-cached','baseline.gxw',False),('baseline-fresh','baseline.gxw',True),
                                  ('pending-cached','pending.gxw',False),('pending-fresh','pending.gxw',True)]:
        rows.append(run_status(out/filename, out/case, fresh=fresh))
        (out/'comparison.json').write_text(json.dumps(dict(cases=rows), indent=2))
    requests = []
    for row in rows:
        path = out/row['case']/'pcode-0-0.bin'
        requests.append(dict(mode='decode',input_base64=base64.b64encode(path.read_bytes()+b'\0').decode()))
    answers = native_batch(requests,out/'decode-native',dll=DEFAULT_DLL,cpu_code=0x208)
    decoded = []
    for row, answer in zip(rows, answers, strict=True):
        path = out/row['case']/'pcode-0-0.bin'
        assert answer['return_code']=='0x00000000' and answer['consumed_bytes']==path.stat().st_size
        projection = native_il_projection(base64.b64decode(answer['output_base64']),encoding='gb18030')
        assert not projection['text_gaps']
        decoded.append(dict(case=row['case'],records=projection['records']))
    (out/'native-decoded.json').write_text(json.dumps(decoded, indent=2))
    print(json.dumps(decoded), flush=True)
