"""Bounded source-only INT/DINT/REAL arithmetic with cached temporary slots.

Only variable operands, +/-, parentheses and assignments are accepted. This
models emitted bytes, not general ST validity, overflow policy or execution.
The measured slot profile uses native states 1 (live) and 2 (reusable). Other
states, control flow, calls and implicit type conversion are excluded. REAL
operands are variables only; this does not implement REAL literal round trips.
"""
import re
from gxw.lossless import sha256
from gxw.project_metadata import read_project_text_context
from probe_gxw_st_sources import replace_observed_st
from probe_minimal_conditional_port_writes import streams
from source_q_direct_declarations import DirectDeclarations
from source_q_label_binding import scalar
from source_q_width import rewrite


def expression(text,*,allow_qualified=False):
    identifier=r'[A-Za-z_][A-Za-z_0-9]*(?:\.[A-Za-z_][A-Za-z_0-9]*)?' if allow_qualified else r'[A-Za-z_][A-Za-z_0-9]*'
    tokens=re.findall(identifier+r'|[0-9]+|[()[\]+-]',text)
    if ''.join(tokens)!=re.sub(r'\s','',text):raise ValueError('unsupported ST expression token')
    cursor=0
    def atom():
        nonlocal cursor
        if cursor>=len(tokens):raise ValueError('missing operand')
        token=tokens[cursor];cursor+=1
        if token.isdigit():return int(token)
        if token=='-' and cursor<len(tokens) and tokens[cursor].isdigit():
            value=-int(tokens[cursor]);cursor+=1;return value
        if token=='(':
            value=chain()
            if cursor>=len(tokens) or tokens[cursor]!=')':raise ValueError('missing parenthesis')
            cursor+=1;return value
        if not re.fullmatch(identifier,token):raise ValueError('unsupported unary operand')
        if cursor<len(tokens) and tokens[cursor]=='[':
            cursor+=1;index=chain()
            if cursor>=len(tokens) or tokens[cursor]!=']':raise ValueError('unsupported array index shape')
            cursor+=1;return ('index',token,index)
        return token
    def chain():
        nonlocal cursor
        value=atom()
        while cursor<len(tokens) and tokens[cursor] in ('+','-'):
            op=tokens[cursor];cursor+=1;value=(op,value,atom())
        return value
    value=chain()
    if cursor!=len(tokens):raise ValueError('unconsumed expression')
    return value


def predict(source):
    content={k:v for k,v in streams(source).items() if k!='CGTable.dat'}
    context=read_project_text_context(next(v for k,v in content.items() if k.endswith('.prj')))
    if context['cpu']!='Q03UDV':raise ValueError('unmeasured ST CPU')
    owner='POU_01';decl=DirectDeclarations(content,context['text_encoding']);decl.add_owner(owner)
    # ECCompiler_IEC 0x310c0 overwrites the default in D,W,R,ZR order.
    # The temporary allocator then uses one fixed descriptor (0x49fd0),
    # unlike declaration selector 4, which searches across ordinary banks.
    temporary_family='D'
    for family in ('D','W','R','ZR'):
        if decl.ranges[family]['handling']=='range':temporary_family=family
    _,text=replace_observed_st(content[owner+'.Program.pou'],'')
    statements=[]
    for part in text.split(';'):
        if not part.strip():continue
        match=re.fullmatch(r'\s*([A-Za-z_][A-Za-z_0-9]*)\s*:=\s*(.*?)\s*',part,re.S)
        if not match:raise ValueError('outside assignment-only ST profile')
        node=expression(match[2])
        if isinstance(node,str):raise ValueError('plain move not included')
        statements.append((match[1],node))
    slots=[];events=[];records=[]
    def variable(name):
        item=decl.bound[owner].get(name.casefold())
        if item is None or item['row'].data_type not in ('INT','DINT','REAL') or item['row'].class_code!=1:
            raise ValueError('outside local scalar INT/DINT/REAL operands')
        return dict(raw=decl.bind(owner,name.encode(context['text_encoding'])),slot=None,data_type=item['row'].data_type)
    def acquire(data_type):
        width=1 if data_type=='INT' else 2
        if width==2 and temporary_family!='D':raise ValueError('wide temporaries outside measured D family')
        for i,s in enumerate(slots):
            if s['state']==2 and s['width']==width:
                s['state']=1;events.append(dict(action='reuse',slot=i,number=s['number']))
                return dict(raw=s['raw'],slot=i,data_type=data_type)
        # A temporary is physically reserved once. Logical release changes
        # the slot state; it never returns these bits to the declaration pool.
        # The native type encodes word/doubleword (D/d), while count is one
        # element in both cases. DINT and REAL share d slots; INT cannot.
        family,number,_=decl.allocate('D',width,fixed_pool=temporary_family)
        slots.append(dict(state=1,family=family,number=number,width=width,raw=scalar(family,number)))
        i=len(slots)-1;events.append(dict(action='create',slot=i,number=number))
        return dict(raw=slots[i]['raw'],slot=i,data_type=data_type)
    def release(value):
        if value['slot'] is not None:
            i=value['slot'];assert slots[i]['state']==1;slots[i]['state']=2
            events.append(dict(action='release',slot=i,number=slots[i]['number']))
    def lower(node,destination=None):
        if isinstance(node,str):return variable(node)
        if isinstance(node,int) or node[0]=='index':raise ValueError('literal/index outside arithmetic-only profile')
        op,left,right=node;lhs=lower(left);rhs=lower(right)
        if lhs['data_type']!=rhs['data_type']:raise ValueError('implicit arithmetic conversion not modeled')
        # Destination acquisition occurs before consuming/releasing operands.
        target=destination if destination is not None else acquire(lhs['data_type'])
        if target['data_type']!=lhs['data_type']:raise ValueError('assignment conversion not modeled')
        variant={'INT':(1,3),'DINT':(5,7),'REAL':(0x1d,0x1f)}[lhs['data_type']][op=='-']
        header=bytes([5,0x49,3,variant,5])
        records.append(rewrite(header+lhs['raw']+rhs['raw']+target['raw']))
        release(lhs);release(rhs);return target
    for target,node in statements:lower(node,variable(target))
    code=bytes.fromhex('0300030591900105')+b''.join(records)+bytes.fromhex('033303020204340204')
    return dict(output=code,sha256=sha256(code),allocations=decl.allocations,temporary_family=temporary_family,temporary_events=events,
        slots=[{k:v for k,v in s.items() if k!='raw'} for s in slots],source_text=text)
