(()=>{
'use strict';
const installed=new Set();let hits=0;
function loc(p){const m=Process.findModuleByAddress(p);return m?{module:m.name,rva:p.sub(m.base).toString()}:{address:p.toString()};}
function cstring(p){try{let s='';for(let i=0;i<512;i++){const c=p.add(i).readU8();if(c===0)return s;if(c>127)return null;s+=String.fromCharCode(c);}}catch(e){}return null;}
function install(phase){
 const compiler=Process.findModuleByName('DZDataABS_Compiler_IEC.dll');if(!compiler)return;
 for(const spec of TARGET_SPECS){
  try{
   const target=compiler.base.add(spec.iat_rva).readPointer(),base=target.sub(spec.target_rva),address=base.add(spec.hook_rva),key=address.toString();
   if(installed.has(key)||!Process.findRangeByAddress(address))continue;
   Interceptor.attach(address,{onEnter(args){this.input=cstring(args[0]);this.caller=loc(this.returnAddress);this.stack=Thread.backtrace(this.context,Backtracer.ACCURATE).slice(0,14).map(loc);},onLeave(value){if(hits++<8192)send({event:'actual-standard-fb-kind',input:this.input,result:value.toInt32(),caller:this.caller,stack:this.stack});}});
   installed.add(key);send({event:'installed-via-resolved-iat',phase,dll:spec.target_dll,base:base.toString(),hook_rva:spec.hook_rva,target:loc(address)});
  }catch(e){send({event:'install-failed',phase,error:String(e)});}
 }
}
Process.attachModuleObserver({onAdded(m){
 const name=m.name.toLowerCase();let target=null;
 if(name==='dzdataabs_compiler_iec.dll')target=m.findExportByName('DllGetClassObject');
 if(name==='dzdataabs_compileradapter.dll')target=m.base.add(0x13cc0);
 if(name==='eccompiler_iec.dll')target=m.findExportByName('ObjectNew');
 if(target)Interceptor.attach(target,{onEnter(){install(name);}});
}});
})();
