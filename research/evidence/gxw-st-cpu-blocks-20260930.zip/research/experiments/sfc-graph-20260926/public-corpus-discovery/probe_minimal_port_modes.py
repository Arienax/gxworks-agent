"""Separate VAR_INPUT read-only enforcement from VAR_IN_OUT binding."""
from dataclasses import replace
from pathlib import Path
import base64
import json
import sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from gxw.declarations import parse_declarations, serialize_declarations
from probe_gxw_simple_fb import frame_source
from probe_gxw_sfc_graph import patch_raw
from source_q_allocation import groups
from source_q_direct_projection import project_projection
from native_gxw_tokens import native_batch,Q_DLL,native_il_records
from probe_gxw_program_check_resources import SCRIPT
from probe_minimal_conditional_port_writes import streams,splice,observe,save
P=Path(__file__).resolve().parent
OUT=P/'minimal-port-modes-20260930'


def main():
    OUT.mkdir(exist_ok=False)
    (OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    trace=OUT/'trace.js';trace.write_text(SCRIPT,encoding='utf-8')
    ready=[]
    for mode in ('input-read', 'inout-write'):
      for kind in ('int','string'):
       for value in ('device','literal'):
        case=f'{mode}-{kind}-{value}';d=OUT/case;d.mkdir()
        source=(P/f'minimal-conditional-port-writes-20260930/{kind}-{value}/input.gxw').read_bytes()
        before=streams(source)
        if mode=='input-read':
            name='SCPI.Program.pou';f=frame_source(before[name]);rows=groups(f.body)
            assert len(rows)==3
            new=splice(f.raw,f.body_offset,f.body_end,b''.join(t for g in (rows[0],rows[2]) for t in g))
        else:
            name='SCPI.Labels.lh';doc=parse_declarations(before[name],logical_name=name)
            port='iUnitNo' if kind=='int' else 'iResStr'
            assert sum(r.name==port and r.class_code==3 for r in doc.rows)==1
            new=serialize_declarations(replace(doc,rows=tuple(replace(r,class_code=5) if r.name==port else r for r in doc.rows)))
        source,receipt=patch_raw(source,name,before[name],new)
        assert streams(source)==dict(before,**{name:new})
        path=d/'input.gxw';path.write_bytes(source)
        predicted=None
        try:
            prediction=project_projection(source,allow_scpi=True,resource_limit=1)[0]
            predicted=prediction.pop('output');(d/'predicted-0.bin').write_bytes(predicted)
        except ValueError as exc:
            prediction=dict(unsupported=str(exc))
        save(d/'before-native.json',dict(case=case,input_sha256=sha256(source),receipt=receipt,prediction=prediction,
             hypothesis='Read-only VAR_INPUT direct devices alias without value copies; class-5 declarations test whether the existing call marker can bind a writable input.'))
        ready.append((case,d,path,predicted))
    result=[];decodes=[];keys=[]
    for case,d,path,predicted in ready:
        native,observed,process=observe(path,d,trace)
        code=(native/'pcode-0-0.bin').read_bytes()
        row=dict(case=case,native_directory=str(native),process=process,check=observed['check'],diagnostics=observed['diagnostics'],
                 bytes=len(code),predicted_equal=None if predicted is None else predicted==code,exported=bool(observed['exported_sha256']),reads=observed['resource_reads'])
        if row['exported']:
            rd=d/'reopen';rd.mkdir();rn,ro,rp=observe(native/'native-saved.gxw',rd,trace)
            row['reopen']=dict(native_directory=str(rn),check=ro['check'],diagnostics=ro['diagnostics'],
                               byte_identical=code==(rn/'pcode-0-0.bin').read_bytes(),reads=ro['resource_reads'])
        if code:
            decodes.append(dict(mode='decode',input_base64=base64.b64encode(code+b'\0').decode(),case=case));keys.append(case)
        result.append(row);save(OUT/'comparison.json',result)
        print(json.dumps(dict(case=case,bytes=len(code),predicted_equal=row['predicted_equal'],check=row['check'],exported=row['exported'],
             errors=sorted(set(hex(e['code']) for e in row['diagnostics'] if e['kind']==2)),reopen=row.get('reopen',{}).get('byte_identical'))),flush=True)
    if decodes:
        decoded=native_batch(decodes,OUT/'native-decode',dll=Q_DLL,cpu_code=209,native_versions=(25,))
        save(OUT/'native-listings.json',[dict(case=k,return_code=r['return_code'],records=native_il_records(base64.b64decode(r['output_base64']),encoding='cp932')) for k,r in zip(keys,decoded)])


if __name__=='__main__':main()
