"""Separate imported backend state, reset, reinitialize and prepare-build."""
from pathlib import Path
import base64, json, sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from probe_compile_pending_stale_cache import run_status
from probe_gxw_sfc_graph import patch_raw
from native_gxw_tokens import native_batch,native_il_projection,DEFAULT_DLL
P=Path(__file__).resolve().parent
out=P/'structured-cache-reload';out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
(out/'status-harness.py').write_bytes((P/'probe_compile_pending_stale_cache.py').read_bytes())
base=P/'compile-pending-stale-cache'
source=base/'baseline.gxw';native=base/'baseline-fresh/native-saved.gxw'
plans=[('fresh-saved-cached',native,{}),('reset-only',source,dict(reset_compiler=True)),
       ('reinitialize-only',source,dict(fresh_compiler_state=True)),
       ('prepare-build-only',source,dict(prepare_build_data=True))]
old={s.logical_name:s.raw for s in inspect_project(source.read_bytes()).streams if s.logical_name}
new={s.logical_name:s.raw for s in inspect_project(native.read_bytes()).streams if s.logical_name}
for logical in ['ESCompiler.stg','CallTree.dat']:
    patched,receipt=patch_raw(source.read_bytes(),logical,old[logical],new[logical])
    assert {s.logical_name:s.raw for s in inspect_project(patched).streams if s.logical_name}==dict(old,**{logical:new[logical]})
    path=out/(logical+'.gxw');path.write_bytes(patched)
    (out/(logical+'-mutation.json')).write_text(json.dumps(dict(source_sha256=sha256(source.read_bytes()),
        donor_sha256=sha256(native.read_bytes()),receipt=receipt,unrelated_payloads='byte-identical'),indent=2))
    plans.append((logical+'-transplant',path,{}))
rows=[]
for case,path,options in plans:
    row=run_status(path,out/case,fresh=False,plan_overrides=options)
    row['options']=options;rows.append(row)
    (out/'comparison.json').write_text(json.dumps(dict(cases=rows),indent=2))
paths=[out/r['case']/'pcode-0-0.bin' for r in rows if (out/r['case']/'pcode-0-0.bin').exists()]
answers=native_batch([dict(mode='decode',input_base64=base64.b64encode(p.read_bytes()+b'\0').decode()) for p in paths],out/'decode-native',dll=DEFAULT_DLL,cpu_code=0x208)
decoded=[]
for p,answer in zip(paths,answers,strict=True):
    assert answer['return_code']=='0x00000000' and answer['consumed_bytes']==p.stat().st_size
    result=native_il_projection(base64.b64decode(answer['output_base64']),encoding='gb18030');assert not result['text_gaps']
    decoded.append(dict(case=p.parent.name,records=result['records']))
(out/'native-decoded.json').write_text(json.dumps(decoded,indent=2))
print(json.dumps([dict(case=r['case'],x2=[v for v in r['records'] if v.get('args')==['X002']]) for r in decoded]),flush=True)
