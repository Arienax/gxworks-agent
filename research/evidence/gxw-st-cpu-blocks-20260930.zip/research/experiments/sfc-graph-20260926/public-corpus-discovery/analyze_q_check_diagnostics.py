"""Bind recovered native diagnostics to unchanged current instruction bytes."""
from pathlib import Path
import base64,json,sys
ROOT=Path(__file__).resolve().parents[4];sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from native_gxw_tokens import native_batch,Q_DLL
from probe_minimal_conditional_port_writes import save
from witness_st_conditional_transfers import decode
from verify_temporary_check_correspondence import verify
P=Path(__file__).resolve().parent


def main():
    out=P/'fresh-check-diagnostic-capture-20260930'
    shared=json.loads((out/'comparison.json').read_text())
    aligned=P/'q-check-resource-name-alignment-20260930'
    aligned_rows=json.loads((aligned/'comparison.json').read_text())
    native=Path(aligned_rows[0]['native_directory'])
    events=[json.loads(l)for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    resources={e['name']:e['index']for e in events if e.get('operation')=='Resource'}
    locations=[];requests=[]
    for d in aligned_rows[0]['diagnostics']:
        assert d['phase']=='ProgramCheckProgress' and d['kind']==2 and d['code']==0x050c9300
        index=resources[d['name']];raw=(native/f'pcode-{index}-0.bin').read_bytes();step=0;match=None
        for instruction in decode(raw):
            if step==d['step']:match=instruction;break
            token=bytes.fromhex(instruction['raw']);step+=1 if token[0]<=3 else token[2]
        assert match and match['op']=='SET' and match['args']==d['arguments']
        # Independent native stored-width summation of the prefix, before the
        # instruction singled out by the native checker. No source generator.
        prefix=raw[:match['offset']]
        requests.append(dict(mode='stored-steps',input_base64=base64.b64encode(prefix).decode()))
        locations.append(dict(resource=d['name'],pcode_sha256=sha256(raw),diagnostic_code=d['code'],step=d['step'],arguments=d['arguments'],instruction=match))
    answers=native_batch(requests,out/'native-diagnostic-prefix-steps',dll=Q_DLL,cpu_code=209,native_versions=(25,))
    for r,a in zip(locations,answers,strict=True):
        assert a['return_code']=='0x00000000' and a['native_value']==r['step']
        r['native_prefix_steps']=a['native_value']
    save(out/'diagnostic-pcode-locations.json',locations)
    chain=json.loads((P/'q-fresh-check-failure-chain-20260930/comparison.json').read_text())
    failure=next(r for r in chain if r['case']=='st-25-moves')
    conversions=[e for e in failure['events'] if e['event']=='q-pcode-to-ladder' and e['result']]
    assert len(conversions)==1 and conversions[0]['result']==0x04031004
    assert conversions[0]['metadata_after'][1]==24
    assert any(e['event']=='iec-report-error' and e['code']==0x050c9521 for e in failure['events'])
    for case in aligned_rows:
        assert case['same_resource_bytes'] and all(case['same_resource_bytes'].values())
        assert case['check']['rejected']==(case['case']!='st-24-moves')
    projection=json.loads((P/'q-fresh-check-report-conversion-20260930/comparison.json').read_text())
    for case in projection[:2]:
        bad=[e for e in case['events'] if e['event']=='report-object-lookup' and e['result']<0]
        assert len(bad)==1 and bad[0]['kind']==32 and bad[0]['name']=='MAIN' and bad[0]['code']==0x2d010025
    correspondence=verify([out.name,aligned.name]);save(out/'current-check-export-correspondence.json',correspondence)
    save(out/'interpretation.json',dict(
        verified=[
            'Q 25-move control: ChangePToLDcode returns 0x04031004, IEC checker emits kind-2 0x050c9521 at step 0, backend GetProgress reaches 100%, then public diagnostic projection fails with 0x2d010025.',
            'Original Noeul case-10: backend emits kind-2 0x050c9300 for Y25 at steps 12 and 51. The adapter converts instance-kind 6 into Workspace.GetObjectID data type 32 with resource name MAIN; that lookup fails.',
            'Read-only public lookups find source POU names under type 32, while MAIN/MAIN.res are absent there. The failing lookup refers to a source object using a resource name.',
            'Renaming only isolated-copy resource names to the corresponding POU names preserves all current PCode bytes. Normal ProgramCheck completes and rejects both original resources, reporting Y25 at 12/51 and Y21 at 133/140. Native GetStepSize independently maps all four positions to the repeated SET instructions.',
            'The same name-alignment control keeps the 25-move rejection and 24-move acceptance. It changes diagnostic visibility, not the checked instructions or rejection policy.',
            'Shared check probe now captures bounded 68-byte backend diagnostics before projection, retaining raw text, arguments, target/check index, progress and projection failures. No native API return or project content is changed by this capture.',
        ],limitations=[
            'All checks use the existing full check-kind mask 0x7fffffff. A duplicate-coil diagnostic is a rejection under those requested checks, not proof that every such control program is invalid under every configuration.',
            'An observed backend rejection does not make an incomplete public/project check complete. The original failure stopped before the second resource; its second-resource errors were observed only in the separate name-alignment experiment.',
            'Renaming resources is a diagnostic control only, not a generic safe-edit workaround. No production rename capability is promoted.',
            'A separate source-POU rename attempt failed before checking because task references were not updated (0x500c5045); those failed inputs, helper and logs are preserved. An earlier lookup helper build failed from a local variable collision and never ran natively.',
            'Backend observation is explicitly limited to the inspected Compiler_IEC GetProgress target; unsupported backend targets are reported without assuming diagnostic coverage.',
        ],evidence=dict(shared_probe_verification='verification.json',locations='diagnostic-pcode-locations.json',correspondence='current-check-export-correspondence.json',
            source_name_failures='../q-check-source-name-alignment-20260930/comparison.json',
            object_lookup='../q-check-object-lookup-v2-20260930/summary.json',
            name_alignment='../q-check-resource-name-alignment-20260930/comparison.json'),
        counts=dict(native_shared_probe_cases=len(shared),native_location_crosschecks=len(locations),public_projection_failure_cases=2,
            backend_rejection_cases=3,normal_public_checks_with_capture=3)))
    (out/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    print(json.dumps(dict(locations=len(locations),shared_cases=len(shared),correspondence={k:v for k,v in correspondence.items() if k not in ('phases','notes')})))


if __name__=='__main__':main()
