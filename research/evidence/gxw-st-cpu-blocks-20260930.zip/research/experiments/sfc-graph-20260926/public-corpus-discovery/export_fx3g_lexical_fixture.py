from pathlib import Path
import json,sys
ROOT=Path.cwd();sys.path[:0]=[str(ROOT/'src')]
from gxw.lossless import sha256
P=ROOT/'research/experiments/sfc-graph-20260926/public-corpus-discovery'
expanded=json.loads((P/'fx3g-expanded-lexical/comparison.json').read_text(encoding='utf-8'))
config=json.loads((P/'fx3g-native-configuration/comparison.json').read_text(encoding='utf-8'))
after=json.loads((P/'fx3g-real-pcode-lexical/comparison-after.json').read_text(encoding='utf-8'))
before=json.loads((P/'fx3g-real-pcode-lexical/comparison-before.json').read_text(encoding='utf-8'))
events=[r['payload'] for r in config['observations'] if r.get('type')=='send']
fixture=dict(schema_version=1,scope='Generated offline lexical controls on observed CPU adapters; no CPU device-range, instruction-availability or project-validity claim',dll_sha256='a700da129ede89869a00a5614d08b43dc64e94c240494fc753fe09104c5b9399',adapter_cpu_codes={'fx3g':521,'fx3u':520,'fx1s':518})
fixture['cpu_trace']=dict(source_sha256=config['source_sha256'],trace_sha256=sha256((P/'fx3g-native-configuration/trace-1/events.jsonl').read_bytes()),byte_identical=config['byte_identical'],observed_open=sorted({(r['cpu'],r['mode']) for r in events if r['event']=='Open'}))
fixture['legacy_controls']=dict(count=expanded['legacy_count'],differences=expanded['legacy_differences'])
fixture['real_compiled_output']=dict(after,gaps_before=before['gaps_before'],chunks=before['chunks'],consumed=before['consumed'],source_project_sha256='3283514cae3cfaa3cb2849c37e8b3cae1e26a34f656e8aa60b8df006e1b61bfe',project_validation='historical baseline full program check rejected; decoding does not validate program correctness')
fresh_directory=P/'fx3g-original-fresh-check/native-1'
fresh=json.loads((fresh_directory/'outcome.json').read_text(encoding='utf-8'))
fixture['real_compiled_output']['project_validation']='Full program check of freshly published output rejected with 22 errors; emitted PCode is byte-identical to the historical baseline'
fixture['real_compiled_output']['fresh_program_check']=dict(input_sha256=fresh['source_output_context']['source_sha256'],target=fresh['program_check_target'],errors=[r for r in fresh['diagnostics'] if r['kind']==2],outcome_sha256=sha256((fresh_directory/'outcome.json').read_bytes()))
fixture['cases']=expanded['cases']
(ROOT/'tests/fixtures/gxw_fx3g_lexical_native.json').write_text(json.dumps(fixture,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(cases=len(fixture['cases']),fixture_bytes=(ROOT/'tests/fixtures/gxw_fx3g_lexical_native.json').stat().st_size,compiled=after)))
