(()=>{
'use strict';
const seen=new Set();let captured=false;
function loc(p){const m=Process.findModuleByAddress(p);return m?{module:m.name,path:m.path,rva:p.sub(m.base).toString()}:{address:p.toString()};}
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='eccompiler_iec.dll'||seen.has(m.base.toString()))return;
 seen.add(m.base.toString());
 const target=m.findExportByName('Compile');if(!target)return;
 Interceptor.attach(target,{onEnter(a){
  if(captured)return;captured=true;
  const modules=Process.enumerateModules().map(x=>({name:x.name,path:x.path,base:x.base.toString(),size:x.size}));
  const imports=Process.enumerateModules().filter(x=>/Compiler|SIC|DataManager/i.test(x.name)).map(x=>({name:x.name,imports:x.enumerateImports().filter(i=>/DataManager|SIC|Easy/i.test(i.module||'')).map(i=>({name:i.name,module:i.module,target:i.address?loc(i.address):null}))}));
  send({event:'compile-module-snapshot',pid:Process.id,modules,imports,stack:Thread.backtrace(this.context,Backtracer.ACCURATE).map(loc)});
 }});
}});
})();
