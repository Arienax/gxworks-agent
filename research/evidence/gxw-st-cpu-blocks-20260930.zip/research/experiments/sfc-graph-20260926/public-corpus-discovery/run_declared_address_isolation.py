"""Distinguish the two stored global address fields using actual compilation."""
import base64
from dataclasses import replace
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'research')]
from gxw.lossless import inspect_project, sha256
from gxw.declarations import parse_declarations, serialize_declarations
from native_gxw_tokens import native_batch, native_il_records, Q_DLL
from probe_gxw_integrity import patch_verified_payloads
from replay_gxw_workspace import run

P = Path(__file__).resolve().parent
OUT = P / 'project2-declared-address-isolation'
OUT.mkdir(exist_ok=False)
source = (P / 'samples/project2.gxw').read_bytes()
streams = {s.logical_name: s.raw for s in inspect_project(source).streams if s.logical_name}
name = 'Global1.gh'
document = parse_declarations(streams[name], logical_name=name)
original = next(r for r in document.rows if r.name == 'PB4')
assert (original.device, original.iec_address) == ('X2D', '%IX45')
baseline = (P / 'native-assignment-real-corpus/case-02/native/pcode-0-0.bin').read_bytes()
results = []
for case, edits in [('melsec_only', dict(device='X2E')), ('iec_only', dict(iec_address='%IX46')),
                    ('both', dict(device='X2E', iec_address='%IX46'))]:
    directory = OUT / case
    directory.mkdir()
    rows = tuple(replace(r, **edits) if r.name == 'PB4' else r for r in document.rows)
    new = serialize_declarations(replace(document, rows=rows))
    changed, receipt = patch_verified_payloads(source, {name: (streams[name], new)})
    path = directory / 'changed.gxw'
    path.write_bytes(changed)
    (directory / 'mutation.json').write_text(json.dumps(dict(source_sha256=sha256(source),
        label='PB4', before=dict(device=original.device, iec_address=original.iec_address),
        edits=edits, receipt=receipt), indent=2), encoding='utf-8')
    query = [dict(name='PB4', keys=[dict(category=1, value='PB4')])]
    native = run(path, directory / 'native', compile=True, snapshot_frontend=True, export_project=True,
                 project_alias='ADDR' + case.upper(), assignment_queries=query)
    row = dict(case=case, **{k: native[k] for k in ['returncode', 'open_succeeded', 'compile_completed',
        'compiler_rejected', 'diagnostics']})
    if (directory / 'native/native-device-assignments.json').exists():
        row['assignments'] = json.loads((directory / 'native/native-device-assignments.json').read_text(encoding='utf-8'))
    if native.get('native_export'):
        saved = (directory / 'native/native-saved.gxw').read_bytes()
        saved_global = next(s.raw for s in inspect_project(saved).streams if s.logical_name == name)
        after = next(r for r in parse_declarations(saved_global, logical_name=name).rows if r.name == 'PB4')
        row['saved_fields'] = dict(device=after.device, iec_address=after.iec_address)
        reopened = run(directory / 'native/native-saved.gxw', directory / 'reopen', compile=True,
                       export_project=True, assignment_queries=query)
        row['reopen'] = {k: reopened[k] for k in ['returncode', 'compile_completed', 'compiler_rejected', 'diagnostics']}
        row['compiled_equal_after_reopen'] = native['outputs'] == reopened['outputs']
        code = (directory / 'native/pcode-0-0.bin').read_bytes()
        answers = native_batch([dict(mode='decode', input_base64=base64.b64encode(b + b'\0').decode())
            for b in [baseline, code]], directory / 'compiled-decode', dll=Q_DLL, cpu_code=209)
        assert all(a['return_code'] == '0x00000000' for a in answers)
        before, after = [native_il_records(base64.b64decode(a['output_base64']), encoding='cp949') for a in answers]
        assert len(before) == len(after)
        row['compiled_differences'] = [dict(index=i, before=a, after=b) for i, (a, b) in enumerate(zip(before, after)) if a != b]
    results.append(row)
    (OUT / 'results.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
    print(json.dumps(row), flush=True)
