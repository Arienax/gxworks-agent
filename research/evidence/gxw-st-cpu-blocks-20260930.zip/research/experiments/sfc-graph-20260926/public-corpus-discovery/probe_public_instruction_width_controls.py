from pathlib import Path
import json,sys,base64,subprocess
sys.path[:0]=['src','research']
from gxw.token_pou import parse_token_fragment
from gxw.token_listing import decode_token_program,TokenInstruction
P=Path('research/experiments/sfc-graph-20260926/public-corpus-discovery');base=P/'q-public-check-replay';out=P/'q-public-check-width-controls';out.mkdir(exist_ok=False);prior=json.loads((base/'requests.json').read_text(encoding='utf-8'));req=[]
for i,r in enumerate(prior['requests']):
 raw=bytes.fromhex(r['expected_hex']);fr=parse_token_fragment(raw,0,len(raw));h=fr.tokens[0].raw
 if len(h)==3 or len(h)==4:
  for width in [0,1,7,127]:
   body=bytes([4,h[1],width,4])+raw[len(h):];req.append(dict(origin='observed-label-instruction',index=i,width=width,input_base64=base64.b64encode(body).decode(),expected_hex=r['expected_hex']))
cdir=P/'real-binary-public-check/case-02';native=(cdir/'untraced/pcode-0-0.bin').read_bytes();listing=decode_token_program(parse_token_fragment(native,0,len(native)),text_encoding='cp936',profile='q03udv')
for i,r in enumerate(listing.records):
 raw=b''.join(t.raw for t in r.tokens);req.append(dict(origin='final-native-instruction',index=i,op=r.mnemonic if isinstance(r,TokenInstruction) else type(r).__name__,input_base64=base64.b64encode(raw).decode(),expected_hex=raw.hex()))
(out/'requests.json').write_text(json.dumps(dict(context_from=str(base/'requests.json'),requests=req),indent=2),encoding='utf-8');protocol=''.join(f"check-instruction\t{i}\t{r['input_base64']}\n" for i,r in enumerate(req));run=subprocess.run([str((base/'PublicCheckOracle.exe').resolve()),'D:/GXWORKS2/Easysocket/CodeGenerator/ECCodeGenerator2.dll','209','1','q','',str((base/'device-context.bin').resolve())],input=protocol.encode('ascii'),capture_output=True,timeout=45,creationflags=subprocess.CREATE_NO_WINDOW);(out/'stdout.jsonl').write_bytes(run.stdout);(out/'stderr.bin').write_bytes(run.stderr);answers=[json.loads(l) for l in run.stdout.splitlines()];diff=[dict(request=r,answer=a) for r,a in zip(req,answers) if a['return_code']!='0x00000000' or base64.b64decode(a['output_base64']).hex()!=r['expected_hex']];comparison=dict(returncode=run.returncode,requested=len(req),received=len(answers),differences=diff);(out/'comparison.json').write_text(json.dumps(comparison,indent=2));print(json.dumps(dict(returncode=run.returncode,requested=len(req),received=len(answers),differences=len(diff))));print(json.dumps(diff[:8]))
