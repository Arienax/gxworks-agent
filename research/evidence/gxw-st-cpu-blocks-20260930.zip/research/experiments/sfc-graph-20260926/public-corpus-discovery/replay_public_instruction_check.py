from pathlib import Path
import json,subprocess,base64,hashlib
P=Path('research/experiments/sfc-graph-20260926/public-corpus-discovery');out=P/'q-public-check-replay';out.mkdir(exist_ok=False)
cdir=P/'real-binary-public-check/case-02';case=json.loads((cdir/'comparison.json').read_text(encoding='utf-8'));events=[x['payload'] for l in (cdir/case['trace_directory']/'events.jsonl').read_text(encoding='utf-8').splitlines() if (x:=json.loads(l)).get('type')=='send'];checks=[x for x in events if x['event']=='check-instruction-code2'];assert len({x['device_context'] for x in checks})==1
context=bytes.fromhex(checks[0]['device_context']);(out/'device-context.bin').write_bytes(context)
s=Path('research/native/TokenOracle.cs').read_text(encoding='utf-8');s=s.replace('    public static int Main(string[] args) {','''    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int CheckInstruction(IntPtr h,
        ref CodeBuffers buffers, int mode, IntPtr deviceContext, out short nativeStatus);
    public static int Main(string[] args) {''')
s=s.replace('fields[0] != "stored-steps")','fields[0] != "stored-steps" && fields[0] != "check-instruction")')
s=s.replace('                else if (fields[0] == "stored-steps") {','''                else if (fields[0] == "check-instruction") {
                    if (profile != "q" || inputSize > 4096) throw new Exception("Outside observed check profile");
                    Array.Copy(input, output, inputSize);
                    GCHandle pin = GCHandle.Alloc(output, GCHandleType.Pinned);
                    try {
                        CodeBuffers buffers = new CodeBuffers();
                        buffers.input = pin.AddrOfPinnedObject(); buffers.remaining = inputSize;
                        short nativeStatus;
                        result = Export<CheckInstruction>(module, "CheckInstructionCode2")(
                            handle, ref buffers, 0, deviceContext, out nativeStatus);
                        if (buffers.input != pin.AddrOfPinnedObject() || buffers.output != IntPtr.Zero ||
                            buffers.deviceOffsets != IntPtr.Zero || buffers.reserved16 != 0 || buffers.reserved20 != 0)
                            throw new Exception("Unexpected check buffer mutation");
                        nativeValue = nativeStatus; outputSize = buffers.remaining;
                    } finally { pin.Free(); }
                }
                else if (fields[0] == "stored-steps") {''')
source=out/'PublicCheckOracle.cs';source.write_text(s,encoding='utf-8');exe=out/'PublicCheckOracle.exe';build=subprocess.run(['C:/Windows/Microsoft.NET/Framework/v4.0.30319/csc.exe','/nologo','/platform:x86','/out:'+str(exe),str(source)],capture_output=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW);(out/'build.log').write_bytes(build.stdout+build.stderr);assert build.returncode==0
req=[dict(mode='check-instruction',input_base64=base64.b64encode(bytes.fromhex(x['before'])).decode(),expected_hex=x['after'],status=x['status'],trace_sequence=x['sequence']) for x in checks];(out/'requests.json').write_text(json.dumps(dict(dll_sha256=hashlib.sha256(Path('D:/GXWORKS2/Easysocket/CodeGenerator/ECCodeGenerator2.dll').read_bytes()).hexdigest(),cpu=209,native_versions=[],device_context_sha256=hashlib.sha256(context).hexdigest(),requests=req),indent=2),encoding='utf-8')
assert hashlib.sha256(Path('D:/GXWORKS2/Easysocket/CodeGenerator/ECCodeGenerator2.dll').read_bytes()).hexdigest()=='2e5c47b0a0d0b59eb26dbab149862a05983a1fa9519a75e446bc680e7cc16f73'
protocol=''.join(f"check-instruction\t{i}\t{r['input_base64']}\n" for i,r in enumerate(req));run=subprocess.run([str(exe.resolve()),'D:/GXWORKS2/Easysocket/CodeGenerator/ECCodeGenerator2.dll','209','1','q','',str((out/'device-context.bin').resolve())],input=protocol.encode('ascii'),capture_output=True,timeout=45,creationflags=subprocess.CREATE_NO_WINDOW);(out/'stdout.jsonl').write_bytes(run.stdout);(out/'stderr.bin').write_bytes(run.stderr);answers=[json.loads(l) for l in run.stdout.splitlines()];comparison=dict(returncode=run.returncode,requested=len(req),received=len(answers),differences=[dict(index=i,request=r,answer=a) for i,(r,a) in enumerate(zip(req,answers)) if a['return_code']!='0x00000000' or a['native_value']!=r['status'] or base64.b64decode(a['output_base64']).hex()!=r['expected_hex']]);(out/'comparison.json').write_text(json.dumps(comparison,indent=2));print(json.dumps(comparison))
