"""Independent raw-cell reader versus source-grid and generated native symbols."""
from pathlib import Path
import json
import sys
ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'research')]
from gxw.lossless import sha256
from source_sfc_grid import read_grid, symbol_projection

P = Path(__file__).resolve().parent
OUT = P/'sfc-grid-cell-crosscheck'


def main():
    OUT.mkdir(exist_ok=False)
    for file in [Path(__file__), P/'source_sfc_grid.py']:
        (OUT/file.name).write_bytes(file.read_bytes())
    base = P.parent
    paths = list(base.glob('*/sfc-native-graph.json'))
    for root in ['q00j-attributes', 'step-attributes']:
        paths += list((base/root).glob('*/graph/sfc-native-graph.json'))
    for root in ['pending-sfc-source-chars-v3', 'sfc-source-targeted-mutations', 'pending-q-end-kind']:
        paths += list((P/root).glob('*/native-*/sfc-native-graph.json')) + list((P/root).glob('convert-*/sfc-native-graph.json'))
    rows = []
    for path in paths:
        buffer = path.parent/'sfc-buffer-0.bin'
        if not buffer.exists():
            continue
        raw = buffer.read_bytes()[:21512]; grid = read_grid(raw)
        assert grid.reconstruction() == raw
        row = dict(path=str(path), source_sha256=sha256(raw), source=grid.inventory())
        rows.append(row)
    (OUT/'predictions-before-comparison.json').write_text(json.dumps(rows, indent=2), encoding='utf-8')
    for row in rows:
        graph = json.loads(Path(row['path']).read_text())
        ours = [symbol_projection(s) for s in row['source']['symbols']]
        native = [symbol_projection(s) for s in graph['symbols'] if s['result'] != 0]
        row.update(native_symbols=len(native), symbols_agree=ours == native,
            dimensions_agree=(graph['width'], graph['height']) == (row['source']['width'], row['source']['height']))
        row['differences'] = [dict(index=i, ours=ours[i] if i < len(ours) else None, native=native[i] if i < len(native) else None)
            for i in range(max(len(ours), len(native))) if (ours[i] if i < len(ours) else None) != (native[i] if i < len(native) else None)]
    (OUT/'comparison.json').write_text(json.dumps(rows, indent=2), encoding='utf-8')
    print(json.dumps(dict(cases=len(rows), symbols=sum(r['native_symbols'] for r in rows),
        all_symbols_agree=all(r['symbols_agree'] for r in rows), all_dimensions_agree=all(r['dimensions_agree'] for r in rows),
        gaps=sum(len(r['source']['gaps']) for r in rows), failures=[dict(path=r['path'], differences=r['differences']) for r in rows if not r['symbols_agree']])), flush=True)


if __name__ == '__main__':
    main()
