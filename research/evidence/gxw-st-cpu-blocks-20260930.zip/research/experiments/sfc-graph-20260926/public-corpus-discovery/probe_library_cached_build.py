"""Observe the project-owned build without resetting its imported cache."""
from pathlib import Path
import sys,json,hashlib
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from replay_gxw_workspace import prepare,trace_prepared
P=Path(__file__).resolve().parent
cases=[('baseline',P/'ST-standard-counter-controls/CTU/native/native-saved.gxw'),('semantic-edit',P/'library-repack-controls/CTU-semantic-edit-v2/changed.gxw')]
old=(P/'ST-standard-counter-controls/CTU/native/pcode-0-0.bin').read_bytes()
new=(P/'library-repack-controls/CTU-semantic-edit-v2/native/pcode-0-0.bin').read_bytes()
results=[]
for name,source in cases:
 out=P/'library-cache-controls'/name
 prepare(source,out,compile=True,export_project=True,snapshot_frontend=False)
 plan=json.loads((out/'plan.json').read_text())
 plan.update(reset_compiler=False,fresh_compiler_state=False)
 (out/'plan.json').write_text(json.dumps(plan,indent=2))
 result=trace_prepared(out,ROOT/'research/native/CompilerTrace.js',timeout=45)
 events=[json.loads(line) for line in (out/'native-events.jsonl').read_text(encoding='utf-8').splitlines()]
 emitted=(out/'pcode-0-0.bin').read_bytes() if (out/'pcode-0-0.bin').is_file() else None
 row=dict(case=name,trace=result,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),native_export=(out/'native-saved.gxw').exists(),pcode_bytes=len(emitted) if emitted is not None else None,pcode_sha256=hashlib.sha256(emitted).hexdigest() if emitted is not None else None,pcode_equals_old=emitted==old,pcode_equals_mutation=emitted==new,diagnostics=[r for e in events for r in e.get('reports',[])],last_event=events[-1] if events else None)
 (out/'comparison.json').write_text(json.dumps(row,indent=2));results.append(row)
 print(json.dumps({k:v for k,v in row.items() if k!='diagnostics'}),flush=True)
(P/'library-cache-controls/comparison.json').write_text(json.dumps(results,indent=2))
