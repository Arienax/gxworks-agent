"""Numeric holdouts beyond the device shapes used to recover the model."""
import base64
import collections
import hashlib
import json
from pathlib import Path
import subprocess
import source_q_width as q
from probe_q_width_holdouts import token

P=Path(__file__).resolve().parent
OUT=P/'q-width-numeric-boundaries'

def main():
    OUT.mkdir(exist_ok=False)
    for name in ['source_q_width.py','q-width-static-tables.json','probe_q_width_numeric_boundaries.py']:
        (OUT/name).write_bytes((P/name).read_bytes())
    seeds=json.loads((P/'q-operand-rule-table-trace/generated-results.json').read_text())
    seen=set();rows=[]
    candidates=[(f'Z{v}',token(0xcc,v)) for v in [15,16,17,18,19,20]]
    candidates += [(f'{c:02x}-{v}',token(c,v)) for c in [0xe8,0xe9,0xea,0xeb] for v in [0,1,32767,32768,65535]]
    candidates += [('E9negative',token(0xe9,0xffffffff)),('E3real64',bytes.fromhex('0be3000000000000f03f0b')),('ECreal32',bytes.fromhex('07ec0000803f07'))]
    for seed in seeds:
        if seed['outcome']!='byte-identical' or seed['profile']!='plain':continue
        header,groups=q.decode_operands(bytes.fromhex(seed['raw']))
        for index in range(len(groups)):
            for label,value in candidates:
                new=groups.copy();new[index]=value;raw=header+b''.join(new)
                if raw in seen:continue
                seen.add(raw)
                row=dict(key=seed['key'],name=seed['name'],label=label,index=index,raw=raw.hex())
                try:row['prediction']=q.rewrite(raw).hex();row['operand_status']=q.operand_checks(raw)
                except ValueError as e:row['unsupported']=str(e)
                rows.append(row)
    (OUT/'predictions-before-native.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
    protocol=''.join(f"check-instruction\t{i}\t{base64.b64encode(bytes.fromhex(r['raw'])).decode()}\n" for i,r in enumerate(rows))
    dll=Path('D:/GXWORKS2/Easysocket/CodeGenerator/ECCodeGenerator2.dll');assert hashlib.sha256(dll.read_bytes()).hexdigest()==q.TABLES['dll_sha256']
    args=[str(P/'q-public-check-replay/PublicCheckOracle.exe'),str(dll),'209','1','q','1',str(P/'q-width-corpus-trace/device-context.bin')]
    run=subprocess.run(args,input=protocol.encode(),capture_output=True,timeout=50,creationflags=subprocess.CREATE_NO_WINDOW)
    (OUT/'stdout.jsonl').write_bytes(run.stdout);(OUT/'stderr.bin').write_bytes(run.stderr)
    answers=[json.loads(l) for l in run.stdout.splitlines()];assert run.returncode==0 and len(answers)==len(rows)
    counts=collections.Counter();differences=[];check_gaps=[]
    for r,a in zip(rows,answers):
        native=a['return_code']=='0x00000000';expected=base64.b64decode(a['output_base64']).hex()
        if native:
            if r.get('prediction')==expected:counts['byte-identical']+=1
            else:counts['different']+=1;differences.append(dict(row=r,native=a))
        else:counts['native-rejected']+=1
        if native!=(r.get('operand_status')==0):check_gaps.append(dict(row=r,native=a))
    result=dict(total=len(rows),counts=dict(counts),differences=differences,operand_check_gaps=check_gaps)
    (OUT/'comparison.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(dict(total=len(rows),counts=counts,first=differences[:6],operand_check_gaps=len(check_gaps),first_gaps=check_gaps[:6])))

if __name__=='__main__':main()
