"""Saved native evidence for omitted ports and static FB member bindings.

An uninitialized witness means no assignment on this finite executed path; it
does not predict startup/retained PLC memory. Native-check success is separate.
"""
from pathlib import Path
import json,sys
P=Path(__file__).resolve().parent
ROOT=P.parents[3];sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from source_q_st_calls import predict
from witness_st_conditional_transfers import decode,evaluate
from probe_minimal_conditional_port_writes import save
from verify_temporary_check_correspondence import verify

EXPECTED={
    'qualified-value-read-only':[11,11,1], 'qualified-result-read-only':[11,11,1],
    'value-member-after-temporary-reuse':[11,7,11],
    'idx-member-after-temporary-reuse':[2,5,12],
}
UNINITIALIZED={'omitted-input','declared-default-input','omitted-inout','skipped-second-capture'}


def main():
    groups=sys.argv[1:] or ['st-omitted-ports-discovery-20260930','st-omitted-port-storage-20260930',
        'st-omitted-allocation-order-20260930','st-qualified-member-bindings-20260930','st-omitted-member-forward-20260930','st-omitted-member-string-control-20260930']
    rows=[]
    for group in groups:
        d=P/group;plans={p['case']:p for p in json.loads((d/'experiment-plan.json').read_text())['cases']}
        listings={p['case']:p['records'] for p in json.loads((d/'native-listings.json').read_text()) if p['index']==0}
        for case in json.loads((d/'comparison.json').read_text()):
            name=case['case'];n=Path(case['native_directory']);source=(n/'input.gxw').read_bytes()
            before=json.loads((d/name/'before-native.json').read_text());assert sha256(source)==before['input_sha256']
            row=dict(group=group,case=name,input_sha256=sha256(source),check=case['check'])
            try:model=predict(source,definitions=('Wrapper','Keypad'),max_call_depth=2,allow_inputs=True,allow_omitted=True,allow_members=True)
            except ValueError as exc:
                report=json.loads((n/'resource-correspondence.json').read_text())
                assert case['check'] is None and not report['check_starts']
                row.update(model_rejected=str(exc),diagnostics=sorted(set(hex(e['code']) for e in case['diagnostics'] if e['kind']==2)))
                assert row['diagnostics'];rows.append(row);print(json.dumps(row));continue
            if not case['check']:
                report=json.loads((n/'resource-correspondence.json').read_text())
                assert not report['check_starts']
                row.update(model_emitted_but_native_rejected=True,diagnostics=sorted(set(hex(e['code']) for e in case['diagnostics'] if e['kind']==2)),
                    before_native_prediction_saved=(d/name/'predicted-0.bin').exists(),
                    limitation='The bounded resource predictor does not validate unused FB definitions; native rejects the invalid unused STRING arithmetic body.')
                assert name=='string-inout-member-after-word-reuse' and '0x500c8030' in row['diagnostics']
                rows.append(row);print(json.dumps(row));continue
            assert not case['check']['rejected']
            raw=(n/'pcode-0-0.bin').read_bytes();records=decode(raw)
            lexical=[{k:v for k,v in r.items() if k not in ('offset','raw')} for r in records]
            assert lexical==listings[name]
            row.update(pcode_sha256=sha256(raw),native_core_lexical_equal=True,retrospective_bytes_equal=raw==model['output'],
                omitted_ports=model['omitted_ports'],input_buffers=model['input_buffers'],member_reads=model['member_reads'])
            predicted=d/name/'predicted-0.bin'
            if predicted.exists():
                assert sha256(predicted.read_bytes())==before['prediction']['sha256']
                row['before_native_bytes_equal']=predicted.read_bytes()==raw
            else:row['before_native_bytes_equal']=None
            observations={}
            for key in ('probeR0','probeR1','probeR2'):
                a=next(a for a in model['declarations'] if a['owner']=='POU_01' and a['name']==key)
                observations[key]=dict(address=a['allocated_family']+str(a['number']),type=a['data_type'])
            expected_error=plans[name].get('expected_witness_error') or ('uninitialized word' if name in UNINITIALIZED else None)
            try:finite=evaluate(records,observations)
            except ValueError as exc:
                assert expected_error and str(exc).startswith(expected_error),(name,str(exc))
                row['finite_witness']=dict(handling='not-defined-by-this-executed-path',error=str(exc))
            else:
                assert not expected_error
                expected=plans[name].get('expected') or dict(zip(observations,EXPECTED[name],strict=True))
                assert finite['observations']==expected,(name,finite['observations'],expected)
                row['finite_witness']=dict(handling='initialized-witness-matches',bindings=observations,expected=expected,**finite)
            messages=[json.loads(l) for l in (n/'events.jsonl').read_text().splitlines()]
            assert not [m for m in messages if m.get('type')=='error']
            events=[m['payload'] for m in messages if m.get('type')=='send']
            allocations=[]
            for e in events:
                if e.get('event')=='typed-allocation' and e['category'] in (2,4,5):
                    b=bytes.fromhex(e['after'])
                    allocations.append(dict(category=e['category'],number=int.from_bytes(b[2:5],'little'),width=int.from_bytes(b[6:10],'little'),sequence=e['sequence'],type=e['type']))
            predicted_allocations=[dict(category={3:2,4:4,5:5}[x['class_code']],number=x['number'],width=x['width']) for x in model['omitted_ports']]
            actual=[{k:x[k] for k in ('category','number','width')} for x in allocations]
            assert actual==predicted_allocations,(name,actual,predicted_allocations)
            row['native_omitted_allocations']=allocations
            row['temporary_trace']=[e for e in events if e.get('event') in ('temporary-create','temporary-slots') and e.get('name')!='reset-slots']
            rows.append(row)
            print(json.dumps(dict(group=group,case=name,before_native_equal=row['before_native_bytes_equal'],retrospective_equal=row['retrospective_bytes_equal'],witness=row['finite_witness']['handling'])))
    summary=dict(cases=len(rows),accepted=sum(bool(r['check']) for r in rows),precheck_rejections=sum(not bool(r['check']) for r in rows),
        native_rejected_despite_prediction=sum(r.get('model_emitted_but_native_rejected',False) for r in rows),
        before_native_predictions=sum(r.get('before_native_bytes_equal') is not None for r in rows),
        before_native_predictions_equal=sum(r.get('before_native_bytes_equal') is True for r in rows),
        retrospective_predictions_equal=sum(r.get('retrospective_bytes_equal') is True for r in rows),
        initialized_witnesses=sum(r.get('finite_witness',{}).get('handling')=='initialized-witness-matches' for r in rows),
        path_uninitialized_witnesses=sum(r.get('finite_witness',{}).get('handling')=='not-defined-by-this-executed-path' for r in rows))
    out=P/groups[-1]
    save(out/'member-binding-analysis.json',dict(scope=__doc__,groups=groups,summary=summary,cases=rows,
        limitations=['One Q03UDV source lineage with controlled local ST calls; no PLC execution.',
            'Declared defaults can affect initialization outside the observed resource code. Equal PCode does not establish equal startup memory.',
            'Original failed source hypotheses and qualified-assignment rejections remain intact. Omitted-port state and last static binding are distinct.',
            'The model is a bounded compiler-behavior reproduction. These alias/capture/reuse counterexamples must not be promoted as semantic-safety guarantees.']))
    save(out/'current-check-export-correspondence.json',verify(groups))
    (out/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    print(json.dumps(summary))


if __name__=='__main__':main()
