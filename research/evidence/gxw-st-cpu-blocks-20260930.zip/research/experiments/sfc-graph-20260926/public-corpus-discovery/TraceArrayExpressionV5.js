// Read-only, bounded ECCompiler observations. Never invoke or replace targets.
'use strict';
let serial = 0;
const seen = new Set();
function location(p) {
  const m = Process.findModuleByAddress(p);
  return m ? {module: m.name, rva: p.sub(m.base).toString()} : null;
}
function bytes(p, count) {
  try {
    const r = Process.findRangeByAddress(p);
    if (!r || r.protection.indexOf('r') < 0) return null;
    const n = Math.min(count, r.base.add(r.size).sub(p).toUInt32());
    return Array.from(new Uint8Array(p.readByteArray(n)), v => v.toString(16).padStart(2, '0')).join('');
  } catch (_) { return null; }
}
const specs = {
  ObjectNew: 1, ObjectDelete: 1, ChangeInit: 4,
  CompileStart: 28, Compile: 7, CompileEnd: 1, Link: 6,
  Load: 2, Save: 2, LoadFromProjectDB: 4, SaveToProjectDB: 4,
  InitializeAddressConverter: 25, SetSymbolicData: 4,
  GetSymbolicData: 4, SetSystemVariables: 3, Commit: 2,
  GetPCode: 7, GetPCodeInfo: 5, GetUnLinkedPCodeInfo: 5
};
const observer = Process.attachModuleObserver({onAdded(m) {
  if (!['eccompiler.dll', 'eccompiler_iec.dll'].includes(m.name.toLowerCase()) || seen.has(m.base.toString())) return;
  seen.add(m.base.toString());
  send({event: 'module', name: m.name, path: m.path, base: m.base.toString(), size: m.size, arch: Process.arch});
  for (const [name, count] of Object.entries(specs)) {
    const address = m.findExportByName(name);
    if (address === null) continue;
    Interceptor.attach(address, {
      onEnter(args) {
        this.id = ++serial;
        this.saved = [];
        for (let i = 0; i < count; ++i) this.saved.push(args[i]);
        const values = this.saved.map((p, i) => ({index: i, value: p.toString(), location: location(p), bytes: bytes(p, 256)}));
        const buffers = [];
        const bounded = (label, p, size) => {
          if (size >= 0 && size <= 0x1000000) buffers.push({label, address:p.toString(), requested_size:size, bytes:bytes(p,size)});
        };
        if (name === 'SetSystemVariables') bounded('system_variables', args[2], args[1].toInt32());
        if (name === 'InitializeAddressConverter') bounded('parameter_block', args[2], args[1].toInt32());
        if (name === 'CompileStart') bounded('parameter_block', args[3], args[2].toInt32());
        if (name === 'Compile') {
          bounded('symbolic_data', args[4], args[3].toInt32());
          const n = args[1].toInt32();
          if (n >= 0 && n <= 1024) {
            bounded('compile_descriptors', args[2], n * 28);
            for (let i=0; i<n; ++i) {
              const d = args[2].add(i*28);
              try {
                bounded('source_' + i, d.add(4).readPointer(), d.readS32());
                buffers.push({label:'name_' + i, bytes:bytes(d.add(8).readPointer(),256)});
              } catch (_) {}
            }
          }
        }
        let callStack = null;
        if (['Compile', 'CompileStart', 'LoadFromProjectDB'].includes(name)) {
          try { callStack = Thread.backtrace(this.context, Backtracer.ACCURATE).map(location); }
          catch (error) { callStack = {error:String(error)}; }
        }
        send({event:'enter', id:this.id, name, module:m.name, thread:this.threadId, caller:location(this.returnAddress),
              call_stack:callStack, args:values, buffers});
      },
      onLeave(result) {
        send({event:'leave', id:this.id, name, module:m.name, result:result.toString(),
          result_bytes: name === 'ObjectNew' ? bytes(result, m.name.toLowerCase().includes('_iec') ? 0x198 : 0x194) : null,
          args:this.saved.map((p, i) => ({index:i, value:p.toString(), bytes:bytes(p, 256)}))});
      }
    });
  }
}});
send({event:'ready', process_id:Process.id, arch:Process.arch});

// Pin the AST accessor ABI and observe only compilation of the isolated main.
(()=>{'use strict';const active=new Map();let seq=0;
const guards={"449248": {"raw": "8b5424048b4424086bd2493d1c010000", "relocations": []}, "449376": {"raw": "8b4424048b49406bc049568b74240c57", "relocations": []}, "440752": {"raw": "6aff6828fc0e1064a100000000506489", "relocations": [3]}, "677456": {"raw": "558bec83e4f86aff6827020f1064a100", "relocations": [9]}, "449216": {"raw": "8b4424048b49406bc0498b440804c204", "relocations": []}, "626208": {"raw": "81ec30010000568bf18b86860000008b", "relocations": []}, "658288": {"raw": "83ec10538b5c24185657538bf9e85e84", "relocations": []}, "627536": {"raw": "8b44240481ec2c0100003d0f01000075", "relocations": []}, "683344": {"raw": "83ec64538b5c246c5556578be98b8586", "relocations": []}, "746672": {"raw": "5355568bf18b86860000008b4830578b", "relocations": []}, "655984": {"raw": "81ec80000000535556578bf98d742410", "relocations": []}, "567072": {"raw": "83ec4053568b74245085f68bd9750a5e", "relocations": []}, "702336": {"raw": "81ec240100005355568bf18b86860000", "relocations": []}, "694592": {"raw": "81ec380100005355568bf18b8e860000", "relocations": []}, "631232": {"raw": "83ec0c8b81860000005355568b703089", "relocations": []}};
function hex(p,n){return Array.from(new Uint8Array(p.readByteArray(n)),v=>v.toString(16).padStart(2,'0')).join('');}
function loc(p){const m=Process.findModuleByAddress(p);return m?{module:m.name,rva:p.sub(m.base).toString()}:null;}
function str(p){try{let s='';for(let i=0;i<256;i++){let c=p.add(i).readU8();if(!c)return s;if(c>127)return null;s+=String.fromCharCode(c);}}catch(_){}return null;}
function nodes(manager,id){const rows=[],seen=new Set(),base=manager.add(0x40).readPointer();function visit(i,depth){if(i<=0||i>10000||depth>4||seen.has(i))return;seen.add(i);const p=base.add(i*73),links=[12,16,20].map(o=>p.add(o).readS32());rows.push({id:i,kind:p.add(4).readU32(),reference:p.add(32).readS32(),type:p.add(24).readS32(),links,raw:hex(p,73)});for(const n of links)visit(n,depth+1);}visit(id,0);return rows;}
Process.attachModuleObserver({onAdded(m){if(m.name.toLowerCase()!=='eccompiler_iec.dll')return;
for(const [r,g] of Object.entries(guards)){const b=g.raw.match(/../g).map(x=>parseInt(x,16));for(const o of g.relocations){if(o+4>b.length)throw new Error('partial relocation guard');let v=(b[o]|b[o+1]<<8|b[o+2]<<16|b[o+3]<<24)>>>0;v=(v+m.base.sub(ptr('0x10000000')).toUInt32())>>>0;for(let j=0;j<4;j++)b[o+j]=(v>>>(8*j))&255;}if(hex(m.base.add(+r),16)!==b.map(x=>x.toString(16).padStart(2,'0')).join('')){send({event:'ast-guard-failed',rva:r,actual:hex(m.base.add(+r),16)});return;}}
Interceptor.attach(m.findExportByName('Compile'),{onEnter(a){this.prior=active.get(this.threadId);const n=a[1].toInt32(),names=[];if(n>=0&&n<=1024)for(let i=0;i<n;i++)names.push(str(a[2].add(i*28+8).readPointer()));active.set(this.threadId,names.includes('1'));send({event:'ast-observed-compile',names});},onLeave(){active.set(this.threadId,this.prior);}});
for(const [event,rva] of [['ast-kind',0x6dae0],['ast-descriptor',0x6db60]])Interceptor.attach(m.base.add(rva),{onEnter(a){if(!active.get(this.threadId))return;try{this.manager=this.context.ecx;this.id=a[0].toInt32();this.row={event,sequence:++seq,node:this.id,value:event==='ast-kind'?a[1].toInt32():hex(a[1],25),before:nodes(this.manager,this.id),caller:loc(this.returnAddress),stack:Thread.backtrace(this.context,Backtracer.ACCURATE).slice(0,10).map(loc)};}catch(e){send({event:'ast-observation-error',error:String(e)});}},onLeave(){if(this.row){try{this.row.after=nodes(this.manager,this.id);send(this.row);}catch(e){send({event:'ast-observation-error',error:String(e)});}}}});
Interceptor.attach(m.base.add(0x6b9b0),{onEnter(a){if(!active.get(this.threadId))return;this.out=a[2];this.row={event:'ast-temporary',sequence:++seq,device_code:a[0].toInt32(),count:a[1].toInt32(),caller:loc(this.returnAddress)};},onLeave(r){if(this.row){try{send({...this.row,result:r.toInt32(),raw:hex(this.out,25)});}catch(e){send({event:'ast-observation-error',error:String(e)});}}}});
Interceptor.attach(m.base.add(0xa5650),{onEnter(a){if(!active.get(this.threadId))return;this.out=a[2];this.typ=a[3];this.row={event:'ast-component',sequence:++seq,kind:a[0].toInt32(),component_offset:a[1].toInt32(),caller:loc(this.returnAddress)};},onLeave(r){if(this.row){try{send({...this.row,result:r.toInt32(),raw:hex(this.out,25),type:this.typ.readS32()});}catch(e){send({event:'ast-observation-error',error:String(e)});}}}});

Interceptor.attach(m.base.add(0x6dac0),{onEnter(a){if(!active.get(this.threadId))return;try{const id=a[0].toInt32();if(id<=0||id>10000)return;const ns=nodes(this.context.ecx,id);if(ns[0].kind!==0x16c)return;send({event:'not-node-use',node:id,nodes:ns,caller:loc(this.returnAddress),stack:Thread.backtrace(this.context,Backtracer.ACCURATE).slice(0,9).map(loc)});}catch(e){send({event:'ast-observation-error',error:String(e)});}}});
for(const [name,rva] of [['array-size',0x98e20],['array-axis',0xa0b70]])Interceptor.attach(m.base.add(rva),{onEnter(a){if(!active.get(this.threadId))return;try{const manager=this.context.ecx.add(0x86).readPointer().add(0x30).readPointer();this.row={event:name,node:a[0].toInt32(),axis:name==='array-axis'?a[1].toInt32():null,nodes:nodes(manager,a[0].toInt32()),caller:loc(this.returnAddress)};}catch(e){send({event:'ast-observation-error',error:String(e)});}},onLeave(r){if(this.row)send({...this.row,result:r.toInt32()});}});

Interceptor.attach(m.base.add(0x99350),{onEnter(a){if(!active.get(this.threadId))return;this.out=a[2];this.row={event:'array-classification',kind:a[0].toInt32(),reference:a[1].toInt32(),caller:loc(this.returnAddress)};},onLeave(r){if(this.row)send({...this.row,result:r.toInt32(),extent:r.toInt32()?this.out.readS32():null});}});
for(const [event,rva,count] of [['array-copy',0xa6d50,2],['expression-output',0xb64b0,1],['emit-operation',0xa0270,1],['construct-assignment',0x8a720,2]])Interceptor.attach(m.base.add(rva),{onEnter(a){if(!active.get(this.threadId))return;try{const manager=event==='construct-assignment'?this.context.ecx:this.context.ecx.add(0x86).readPointer().add(0x30).readPointer();const args=[];for(let i=0;i<count;i++)args.push({id:a[i].toInt32(),nodes:nodes(manager,a[i].toInt32())});send({event,args,count:event==='array-copy'?a[2].toInt32():null,mode:event==='array-copy'?a[3].toInt32():null,caller:loc(this.returnAddress),stack:Thread.backtrace(this.context,Backtracer.ACCURATE).slice(0,8).map(loc)});}catch(e){send({event:'ast-observation-error',at:event,error:String(e)});}}});

for(const [event,rva,count] of [['assignment-transfer',0xab780,2],['expression-size',0xa9940,1],['temporary-array-size',0x9a1c0,1]])Interceptor.attach(m.base.add(rva),{onEnter(a){if(!active.get(this.threadId))return;try{this.manager=this.context.ecx.add(0x86).readPointer().add(0x30).readPointer();this.ids=[];for(let i=0;i<count;i++)this.ids.push(a[i].toInt32());this.row={event,sequence:++seq,args:this.ids.map(id=>({id,nodes:nodes(this.manager,id)})),mode:count===2?a[2].toInt32():null,caller:loc(this.returnAddress),stack:Thread.backtrace(this.context,Backtracer.ACCURATE).slice(0,8).map(loc)};send({...this.row,phase:'enter'});}catch(e){send({event:'ast-observation-error',at:event,error:String(e)});}},onLeave(r){if(this.row){try{send({...this.row,phase:'leave',result:r.toInt32(),after:this.ids.map(id=>({id,nodes:nodes(this.manager,id)}))});}catch(e){send({event:'ast-observation-error',at:event,error:String(e)});}}}});
}});})();
