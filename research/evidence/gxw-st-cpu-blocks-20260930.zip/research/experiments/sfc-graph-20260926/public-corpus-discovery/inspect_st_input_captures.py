"""Inspect INPUT storage and aliasing using saved native observations.

Discovery cases are retrospective fits. Only a saved non-opaque prediction
made before native compilation counts as a forward byte prediction. Evaluation
is a finite initialized instruction witness, not PLC execution.
"""
from pathlib import Path
import json,sys
P=Path(__file__).resolve().parent
ROOT=P.parents[3];sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from gxw.project_metadata import read_project_text_context
from source_q_st_calls import predict
from source_q_direct_declarations import DirectDeclarations
from probe_minimal_conditional_port_writes import streams,save
from witness_st_conditional_transfers import decode,evaluate
from verify_temporary_check_correspondence import verify

INITIAL={
    'scalar-overlap':[11,12,12], 'literal-array-overlap':[12,0,12],
    'literal-input':[11,12,11], 'expression-input':[11,12,18],
    'dynamic-input-clobber':[11,1,11], 'input-forwarded-to-inout':[18,1,18],
}


def main():
    groups=sys.argv[1:] or ['st-input-capture-discovery-20260930','st-input-capture-lifetime-20260930','st-input-order-discovery-20260930','st-input-forward-20260930']
    rows=[]
    for group in groups:
        out=P/group
        plans={x['case']:x for x in json.loads((out/'experiment-plan.json').read_text())['cases']}
        listings={x['case']:x['records'] for x in json.loads((out/'native-listings.json').read_text()) if x['index']==0}
        for c in json.loads((out/'comparison.json').read_text()):
            name=c['case'];n=Path(c['native_directory']);source=(n/'input.gxw').read_bytes()
            before=json.loads((out/name/'before-native.json').read_text());assert before['input_sha256']==sha256(source)
            report=json.loads((n/'resource-correspondence.json').read_text())
            row=dict(group=group,case=name,input_sha256=sha256(source),check=c['check'],
                diagnostics=sorted(set(hex(d['code']) for d in c['diagnostics'] if d['kind']==2)))
            try:model=predict(source,definitions=('Wrapper','Keypad'),max_call_depth=2,allow_inputs=True)
            except ValueError as exc:
                row['model_rejected']=str(exc)
                assert c['check'] is None and not report['check_starts'] and row['diagnostics']
                rows.append(row);print(json.dumps(row));continue
            assert c['check'] and not c['check']['rejected']
            code=(n/'pcode-0-0.bin').read_bytes();row['retrospective_bytes_equal']=model['output']==code
            if (out/name/'predicted-0.bin').exists():
                old=(out/name/'predicted-0.bin').read_bytes();assert sha256(old)==before['prediction']['sha256']
                row['before_native_bytes_equal']=old==code
            else:row['before_native_bytes_equal']=None
            records=decode(code)
            assert [{k:v for k,v in r.items() if k not in ('raw','offset')} for r in records]==listings[name]
            row['native_core_lexical_equal']=True
            content={k:v for k,v in streams(source).items() if k!='CGTable.dat'}
            context=read_project_text_context(next(v for k,v in content.items() if k.endswith('.prj')))
            declarations=DirectDeclarations(content,context['text_encoding'],local_fb_definitions=('Wrapper','Keypad'),allow_string_arrays=True,max_local_fb_depth=2)
            declarations.add_owner('POU_01')
            observations={}
            for key in ('probeR0','probeR1','probeR2'):
                item=declarations.bound['POU_01'][key.casefold()]
                observations[key]=dict(address=item['family']+str(item['number']),type=item['row'].data_type)
            finite=evaluate(records,observations)
            expected=plans[name].get('expected') or dict(zip(observations,INITIAL[name],strict=True))
            assert finite['observations']==expected,(group,name,finite['observations'],expected)
            messages=[json.loads(l) for l in (n/'events.jsonl').read_text().splitlines()]
            assert not [m for m in messages if m.get('type')=='error']
            es=[m['payload'] for m in messages if m.get('type')=='send']
            creations=[]
            for e in es:
                if e.get('event')!='temporary-create':continue
                raw=bytes.fromhex(e['output']);assert len(raw)==25
                creations.append(dict(sequence=e['sequence'],compile_id=e['compile_id'],caller=e['caller']['rva'],
                    type=e['type'],width=e['count'],number=int.from_bytes(raw[8:12],'little'),
                    preceding_instruction_emissions=sum(x.get('event')=='sink-record' and x['compile_id']==e['compile_id'] and x['sequence']<e['sequence'] for x in es)))
            actual=[{k:e[k] for k in ('number','width')} for e in creations if e['caller']=='0xca1cf']
            expected_buffers=[{k:e[k] for k in ('number','width')} for e in model['input_buffers']]
            assert actual==expected_buffers,(group,name,actual,expected_buffers)
            reusable=[s for e in es if e.get('event')=='temporary-slots' for s in (e.get('after') or [])]
            assert not {x['number'] for x in actual}&{s['operand'][0] for s in reusable}
            row.update(pcode_sha256=sha256(code),bindings=observations,expected=expected,finite_witness=finite,
                input_buffer_allocations_equal=True,input_buffers_absent_from_reusable_slots=True,creations=creations,
                input_buffers=model['input_buffers'],slot_requests=[e for e in es if e.get('event')=='temporary-slots' and e['name']=='request'])
            rows.append(row)
            print(json.dumps({k:v for k,v in row.items() if k in ('group','case','retrospective_bytes_equal','before_native_bytes_equal','expected')}))
    summary=dict(cases=len(rows),accepted=sum(bool(r['check']) for r in rows),precheck_rejections=sum('model_rejected' in r for r in rows),
        before_native_predictions=sum(r.get('before_native_bytes_equal') is not None for r in rows),
        before_native_predictions_equal=sum(r.get('before_native_bytes_equal') is True for r in rows),
        retrospective_predictions_equal=sum(r.get('retrospective_bytes_equal') is True for r in rows),
        native_core_decodes_equal=sum(r.get('native_core_lexical_equal',False) for r in rows),
        input_buffer_allocations=sum(len(r.get('input_buffers',[])) for r in rows))
    out=P/groups[-1]
    save(out/'input-capture-analysis.json',dict(scope=__doc__,summary=summary,cases=rows))
    save(out/'current-check-export-correspondence.json',verify(groups))
    (out/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    print(json.dumps(summary))


if __name__=='__main__':main()
