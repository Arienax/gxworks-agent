"""Observe eligibility method calls at function boundaries, reuse clean baselines."""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from replay_gxw_workspace import prepare,trace_prepared
P=Path(__file__).resolve().parent
OUT=P/'scpi-alias-device-methods';OUT.mkdir(exist_ok=False)
(OUT/'probe.py').write_bytes(Path(__file__).read_bytes())
hook=OUT/'observer.js';hook.write_bytes((P/'TraceBinaryAliasMethods.js').read_bytes())
assert sha256(Path('D:/GXWORKS2/Easysocket/Compiler/ECCompiler_IEC.dll').read_bytes())=='f58e7c70b855526bf2f943399a14089f771a43109b13ee9af34c88fb065cf4d7'
rows=[]
for prior in json.loads((P/'scpi-alias-device-forms/comparison.json').read_text()):
 case=prior['case'];parent=P/'scpi-alias-device-forms'/case;source=parent/'changed.gxw';directory=OUT/case;directory.mkdir()
 for attempt in range(1,5):
  traced=directory/f'trace-{attempt}'
  prepare(source,traced,compile=True,export_project=True,snapshot_frontend=True,project_alias='ALIASFORMS')
  process=trace_prepared(traced,hook)
  ne=[json.loads(l) for l in (traced/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
  if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in ne):break
 raw=[json.loads(l) for l in (traced/'events.jsonl').read_text().splitlines()]
 events=[e['payload'] for e in raw if e.get('type')=='send']
 errors=[e for e in raw if e.get('type')=='error' or any(k.endswith('error') for k in e.get('payload',{})) or e.get('payload',{}).get('event','').endswith('-error')]
 decisions=[e for e in events if e['event']=='alias-decision']
 errors.extend(dict(event='nested-method-error',decision_id=d['decision_id'],method=m) for d in decisions for m in d.get('methods',[]) if 'observation_error' in m)
 baseline_dir=parent/prior['baseline_directory'];codes={f.name:f.read_bytes() for f in baseline_dir.glob('pcode-*.bin')};assert codes
 exact={n:(traced/n).exists() and (traced/n).read_bytes()==b for n,b in codes.items()}
 row=dict(case=case,source=str(source),source_sha256=sha256(source.read_bytes()),baseline_directory=str(baseline_dir),trace_directory=str(traced),observer_sha256=sha256(hook.read_bytes()),process=process,errors=errors,exact_pcode=exact,decisions=decisions,stores=[e for e in events if e['event']=='alias-store-request'],methods=[e for e in events if e['event']=='alias-method'])
 (directory/'comparison.json').write_text(json.dumps(row,indent=2));rows.append(row);(OUT/'comparison.json').write_text(json.dumps(rows,indent=2))
 print(json.dumps(dict(case=case,errors=errors,exact=exact,decisions=len(decisions),methods=row['methods'])),flush=True)
 if errors or not all(exact.values()):break
