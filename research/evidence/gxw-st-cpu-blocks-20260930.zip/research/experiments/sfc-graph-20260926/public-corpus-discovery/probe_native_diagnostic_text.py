from pathlib import Path
import subprocess,json,hashlib,os
P=Path('research/experiments/sfc-graph-20260926/public-corpus-discovery');OUT=P/'native-diagnostic-text-probe-v2';OUT.mkdir(exist_ok=False)
cs=r'''using System;using System.IO;using System.Runtime.InteropServices;using System.Web.Script.Serialization;using System.Collections.Generic;
class ErrorMessageOracle {
[DllImport("ole32")] static extern int CoCreateInstance(ref Guid clsid,IntPtr outer,uint context,ref Guid iid,out IntPtr instance);
[DllImport("ole32")] static extern int CoInitializeEx(IntPtr reserved,uint mode);
[DllImport("kernel32")] static extern uint SetErrorMode(uint mode);
[UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate void Self(IntPtr self);
[UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate void Message(IntPtr self,uint code,ref IntPtr text,out uint result);
static T Slot<T>(IntPtr self,int offset){return (T)(object)Marshal.GetDelegateForFunctionPointer(Marshal.ReadIntPtr(Marshal.ReadIntPtr(self),offset),typeof(T));}
[STAThread] static int Main(string[] args){SetErrorMode(3);CoInitializeEx(IntPtr.Zero,2);
Guid clsid=new Guid("0bf65a7e-5f7d-4c34-927a-a24ef88a7c8a"),iid=new Guid("00020400-0000-0000-c000-000000000046");IntPtr instance;
int hr=CoCreateInstance(ref clsid,IntPtr.Zero,1,ref iid,out instance);if(hr<0)return hr;
var rows=new List<object>();
try {Slot<Self>(instance,28)(instance);foreach(string s in args){uint code=uint.Parse(s);IntPtr message=IntPtr.Zero;uint result;
Slot<Message>(instance,200)(instance,code,ref message,out result);try{int length=message==IntPtr.Zero?0:Marshal.ReadInt32(message,-4);if(length<0||length>65536||(length&1)!=0)throw new Exception("Unbounded BSTR");byte[] bytes=new byte[length];if(length>0)Marshal.Copy(message,bytes,0,length);rows.Add(new{code=code,result=result,raw_base64=Convert.ToBase64String(bytes)});}finally{if(message!=IntPtr.Zero)Marshal.FreeBSTR(message);}
}Console.WriteLine(new JavaScriptSerializer().Serialize(rows));}finally{Slot<Self>(instance,32)(instance);Marshal.Release(instance);}return 0;}}
'''
source=OUT/'ErrorMessageOracle.cs';source.write_text(cs,encoding='utf-8');dll=Path('D:/GXWORKS2/DNaviZero/DZDataNavigatorServer/DZDataNavigatorServer.dll');assert hashlib.sha256(dll.read_bytes()).hexdigest()=='c8b073657846d8841ffc99f32f1598fc3c1046c451f88d2deef2503f3e5e6a68'
exe=OUT/'ErrorMessageOracle.exe';build=subprocess.run([os.environ['WINDIR']+'/Microsoft.NET/Framework/v4.0.30319/csc.exe','/nologo','/platform:x86','/r:System.Web.Extensions.dll','/out:'+str(exe),str(source)],capture_output=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW);(OUT/'build.txt').write_bytes(build.stdout+build.stderr);assert build.returncode==0
codes=[84710689,84710178,84710144,0x50030004,0x2d010010];(OUT/'request.json').write_text(json.dumps(dict(codes=codes,scope='owned metadata-only COM helper; no project import or device APIs',dll_sha256=hashlib.sha256(dll.read_bytes()).hexdigest(),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest()),indent=2),encoding='utf-8')
r=subprocess.run([str(exe.resolve()),*[str(c) for c in codes]],capture_output=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW);(OUT/'stdout.json').write_bytes(r.stdout);(OUT/'stderr.bin').write_bytes(r.stderr);print('exit',r.returncode)
if r.returncode==0:
 import base64
 rows=json.loads(r.stdout);print(json.dumps([dict(x,text=base64.b64decode(x['raw_base64']).decode('utf-16le')) for x in rows],ensure_ascii=True))
