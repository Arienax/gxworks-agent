"""Challenge a CPU-specific descriptor projection with independent text decoding."""
from pathlib import Path
import base64,json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from native_gxw_tokens import native_batch,native_il_projection,Q_DLL
P=Path(__file__).resolve().parent
OUT=P/'q02-lexical-controls'


def main():
    OUT.mkdir(exist_ok=False);(OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    descriptors=[json.loads(s) for s in (P/'q02-descriptor-crosscheck/34/native-stdout.jsonl').read_text().splitlines()]
    plans=[]
    for row in descriptors:
        if row['result']!='0x00000000' or row['family'] in [0x3c,0x3f]:continue
        name=row['name'];family=row['family'];variant=row['variant'];arity=bytes.fromhex(row['descriptor_hex'])[4]
        named=len(name)>1 and name[1]=='.'
        for modifier in ([0x0a,2] if named else [0xff,2,0x10,0x11,0x12]):
            header=bytes([family,2,variant,modifier])+(b'TEST' if named else b'')
            header=bytes([len(header)+2])+header+bytes([len(header)+2])
            mnemonic=name+('TEST' if named else '')
            if modifier==2:
                if named:mnemonic=mnemonic[0]+'P'+mnemonic[1:]
                elif family!=0x65 or variant not in (5,6,7,0x22,0x23,0x48,0x49):mnemonic+='P'
            elif modifier in (0x10,0x11,0x12):mnemonic={0x10:'LD',0x11:'AND',0x12:'OR'}[modifier]+mnemonic
            else:mnemonic=mnemonic.removeprefix(',')
            body=header+bytes.fromhex('04a80004')*arity
            plans.append(dict(kind='header',family=family,variant=variant,body=body.hex(),expected=[dict(kind='instruction',op=mnemonic,args=['D0']*arity)]))
    # Repeat the already independently checked operand controls under CPU 34.
    prior=json.loads((P/'q-operand-catalog-controls/comparison.json').read_text())['rows']
    for row in prior:
        body=bytes.fromhex('054c020005'+row['raw_hex']+'04a80004')
        plans.append(dict(kind='operand',case=row['case'],body=body.hex(),expected=[row['expected']]))
    (OUT/'predictions-before-native.json').write_text(json.dumps(plans,indent=2),encoding='utf-8')
    requests=[dict(mode='decode',input_base64=base64.b64encode(bytes.fromhex(p['body'])+b'\0').decode()) for p in plans]
    actual=native_batch(requests,OUT/'native',dll=Q_DLL,cpu_code=34,native_versions=())
    rows=[]
    for plan,native in zip(plans,actual):
        row=dict(plan,result=native['return_code'],consumed_bytes=native['consumed_bytes'])
        if native['return_code']=='0x00000000':
            row['native']=native_il_projection(base64.b64decode(native['output_base64']),encoding='cp949')['records']
            row['exact']=row['native']==row['expected'] and row['consumed_bytes']==len(bytes.fromhex(row['body']))
        rows.append(row)
    (OUT/'comparison.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
    print(json.dumps(dict(cases=len(rows),accepted=sum(r['result']=='0x00000000' for r in rows),exact=sum(r.get('exact',False) for r in rows),
        differences=[r for r in rows if not r.get('exact',False)][:50])),flush=True)


if __name__=='__main__':main()
