"""Check static operand schemas at original native function boundaries."""
import base64
import collections
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
import source_q_width as q
from probe_q_width_holdouts import token

P=Path(__file__).resolve().parent
OUT=P/'q-operand-rule-table-trace'
sys.path.insert(0,str(q.ROOT/'research/experiments/re-tools'))
import frida

def main():
    OUT.mkdir(exist_ok=False)
    for name in ['source_q_width.py','q-width-static-tables.json','probe_q_operand_rule_tables.py','TraceQOperandRules.js']:
        (OUT/name).write_bytes((P/name).read_bytes())
    catalog=json.loads((q.ROOT/'src/gxw/templates/q03udv-token-grammar.json').read_text())['headers']
    rows=[];generation_gaps=[];seen=set()
    for key,(name,arity) in catalog.items():
        f,v=map(lambda s:int(s,16),key.split(':'))
        if f>=0x70 or f in (4,5,10,11,21,22,0x3c,0x3f):continue
        h=bytes([4,f,127,4]) if f<0x40 else bytes([5,f,127,v,5])
        for profile in ['plain','indexed','indirect','group4']:
            operands=[]
            try:
                for i in range(arity):
                    candidates=[]
                    for dev in [0xa8,0x90,0x98,0xdc,0xd8,0xd9,0xd2,0xe8,0xe9,0xee,0xc2,0xc5,0x9c,0x9d,0xcc,0xa0,0xa1,0xb4]+list(range(0x90,0xf0)):
                        raw=token(dev,i+1)
                        if dev==0xee:raw=bytes([5,dev,0x41,0,5])
                        if profile=='indexed':raw=token(0xf0,1)+raw
                        elif profile=='indirect':raw=token(0xf3,0)+raw
                        elif profile=='group4':raw=token(0xf1,4)+raw
                        try:
                            d,_=q.operand(raw);d=q.validate_descriptor(d)
                            if q.operand_rule_status(f,v,i,d)==0:candidates.append(raw);break
                        except ValueError:continue
                    if not candidates:raise q.Unsupported(f'no {profile} operand {i}')
                    operands.append(candidates[0])
                raw=h+b''.join(operands)
                if raw in seen:continue
                seen.add(raw)
                row=dict(origin='static-schema-generator',key=key,name=name,profile=profile,raw=raw.hex())
                try:row['prediction']=q.rewrite(raw).hex()
                except ValueError as e:row['unsupported']=str(e)
                rows.append(row)
            except ValueError as e:generation_gaps.append(dict(key=key,profile=profile,error=str(e)))
    # Retain representative invalid as well as valid inputs from the larger set.
    prior=P/'q-width-all-application-holdouts'
    prior_rows=json.loads((prior/'predictions-before-native.json').read_text())
    answers=[json.loads(s) for s in (prior/'stdout.jsonl').read_text().splitlines()]
    covered=set()
    for row,a in zip(prior_rows,answers,strict=True):
        key=(row['family'],row['variant'],a['return_code'],row['label'].split('@')[0],row['pulse'])
        if key in covered:continue
        covered.add(key)
        raw=bytes.fromhex(row['raw'])
        if raw in seen:continue
        seen.add(raw)
        # Sample one type at each result per family/variant; cap breadth per type.
        if row['label'].split('@')[0] not in ('default','D.bit','M17','K7','K65536','K4M16','U0G','Z2'):continue
        rows.append(dict(**row,origin='prior-width-holdout'))
    (OUT/'requests.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
    (OUT/'generation-gaps.json').write_text(json.dumps(generation_gaps,indent=2),encoding='utf-8')
    protocol=''.join(f"check-instruction\t{i}\t{base64.b64encode(bytes.fromhex(r['raw'])).decode()}\n" for i,r in enumerate(rows))
    (OUT/'input.txt').write_text(protocol,encoding='ascii')
    dll=Path('D:/GXWORKS2/Easysocket/CodeGenerator/ECCodeGenerator2.dll')
    assert hashlib.sha256(dll.read_bytes()).hexdigest()==q.TABLES['dll_sha256']
    args=[str(P/'q-width-corpus-trace/WidthOracle.exe'),str(dll),'209','1','q','1',str(P/'q-width-corpus-trace/device-context.bin'),str(OUT/'input.txt')]
    normal=subprocess.run(args,capture_output=True,timeout=50,creationflags=subprocess.CREATE_NO_WINDOW)
    (OUT/'baseline-stdout.jsonl').write_bytes(normal.stdout);(OUT/'baseline-stderr.bin').write_bytes(normal.stderr)
    assert normal.returncode==0
    device=frida.get_local_device();output={1:bytearray(),2:bytearray()};ended=[]
    pid=device.spawn(args,cwd=str(OUT),stdio='pipe')
    def receive(pid_,fd,data):
        if pid_==pid and fd in output:output[fd].extend(data)
    device.on('output',receive)
    try:
        session=device.attach(pid);session.on('detached',lambda *a:ended.append(str(a)))
        with (OUT/'events.jsonl').open('w') as log:
            agent=session.create_script((OUT/'TraceQOperandRules.js').read_text())
            def message(row,data):log.write(json.dumps(row)+'\n');log.flush()
            agent.on('message',message);agent.load();device.resume(pid)
            deadline=time.monotonic()+50
            while not ended and time.monotonic()<deadline:time.sleep(.1)
            if not ended:device.kill(pid)
    finally:
        if not ended:
            try:device.kill(pid)
            except frida.ProcessNotFoundError:pass
    (OUT/'trace-stdout.jsonl').write_bytes(output[1]);(OUT/'trace-stderr.bin').write_bytes(output[2])
    counts=collections.Counter();failures=[]
    for line in (OUT/'events.jsonl').read_text().splitlines():
        packet=json.loads(line)
        if packet.get('type')!='send':failures.append(packet);continue
        e=packet['payload']
        if e['event']=='operand-rule':
            actual=q.operand_rule_status(e['family'],e['variant'],e['index'],bytes.fromhex(e['descriptor']))
            counts['operand-rule']+=1
            if actual!=e['result']:failures.append(dict(native=e,predicted=actual))
        elif e['result']==0:
            try:actual=q.validate_descriptor(bytes.fromhex(e['before'])).hex()
            except ValueError as exc:actual=str(exc)
            counts['operand-modifiers']+=1
            if actual!=e['after']:failures.append(dict(native=e,predicted=actual))
    native=[json.loads(l) for l in normal.stdout.splitlines()]
    generated=[]
    for row,a in zip(rows,native,strict=True):
        if row['origin']!='static-schema-generator':continue
        result=base64.b64decode(a['output_base64']).hex()
        outcome='native-rejected' if a['return_code']!='0x00000000' else ('byte-identical' if result==row.get('prediction') else 'different')
        generated.append(dict(**row,outcome=outcome,native=a))
    summary=dict(requests=len(rows),pid=pid,detached=ended,stdout_equal=normal.stdout==output[1],counts=dict(counts),failures=failures,generator_counts=dict(collections.Counter(r['outcome'] for r in generated)),generator_differences=[r for r in generated if r['outcome']=='different'])
    (OUT/'comparison.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    (OUT/'generated-results.json').write_text(json.dumps(generated,indent=2),encoding='utf-8')
    print(json.dumps({k:(v[:8] if isinstance(v,list) else v) for k,v in summary.items()}))

if __name__=='__main__':main()
