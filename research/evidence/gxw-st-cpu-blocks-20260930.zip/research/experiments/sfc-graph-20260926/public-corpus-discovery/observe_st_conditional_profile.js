// Read-only: constructor and callees established by aligned static windows.
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='eccompiler_iec.dll')return;
 function loc(p){const o=Process.findModuleByAddress(p);return o?{module:o.name,rva:p.sub(o.base).toString()}:{address:p.toString()};}
 function bytes(p,n){return Array.from(new Uint8Array(p.readByteArray(n)),b=>b.toString(16).padStart(2,'0')).join('');}
 function failure(name,e){send({event:'conditional-profile-observation-error',name:name,observation_error:String(e)});}
 const hooked=new Set(),cpuInitializations=new Map(),targetBytes=new Map();
 Interceptor.attach(m.base.add(0x31280),{
  onEnter(a){try{
   this.compiler=this.context.ecx;this.prior=cpuInitializations.get(this.threadId);
   this.row={event:'conditional-profile-initialize',caller:loc(this.returnAddress),selector_before:this.compiler.add(0x784).readU32(),arg0:a[0].toUInt32(),arg1:a[1].toUInt32(),predicates:[]};
   cpuInitializations.set(this.threadId,this.row);
  }catch(e){failure('initialize-enter',e);}},
  onLeave(r){if(!this.row)return;try{
   this.row.result=r.toInt32();this.row.selector_after=this.compiler.add(0x784).readU32();send(this.row);
  }catch(e){failure('initialize-leave',e);}cpuInitializations.set(this.threadId,this.prior);}
 });
 Interceptor.attach(m.base.add(0x214e0),{
  onEnter(a){this.initialization=cpuInitializations.get(this.threadId);},
  onLeave(r){if(!this.initialization||r.isNull())return;try{
   const table=r.readPointer();this.initialization.cpu_vtable=loc(table);
   this.initialization.virtual_targets=[];
   for(const slot of [8,12,16,20,32]){
    const target=table.add(slot).readPointer(),key=target.toString();
    if(!targetBytes.has(key))targetBytes.set(key,bytes(target,16));
    const raw=targetBytes.get(key),item={slot:slot,target:loc(target),entry_hex:raw};
    this.initialization.virtual_targets.push(item);
    // Short constant-return functions cannot always be intercepted safely.
    // Identify their complete machine sequence rather than moving the hook.
    if(raw.startsWith('33c0c3')||raw.startsWith('31c0c3')){item.constant_return=0;item.handling='static-constant-return';continue;}
    if(raw.startsWith('b8')&&raw.slice(10,12)==='c3'){
     item.constant_return=parseInt(raw.slice(8,10)+raw.slice(6,8)+raw.slice(4,6)+raw.slice(2,4),16);
     item.handling='static-constant-return';continue;
    }
    if(hooked.has(key))continue;hooked.add(key);
    Interceptor.attach(target,{
     onEnter(a){this.initialization=cpuInitializations.get(this.threadId);if(!this.initialization)return;
      this.caller=loc(this.returnAddress);this.target=loc(target);
     },
     onLeave(value){if(!this.initialization||!this.caller.module||this.caller.module.toLowerCase()!=='eccompiler_iec.dll')return;
      const slots={'0x31512':8,'0x31528':12,'0x3153a':16,'0x31550':20,'0x31568':32};
      if(slots[this.caller.rva]===undefined)return;
      this.initialization.predicates.push({slot:slots[this.caller.rva],caller:this.caller,target:this.target,result:value.toInt32()});
     }
    });
   }
  }catch(e){failure('cpu-factory-leave',e);}}
 });
 Interceptor.attach(m.base.add(0xd7050),{
  onEnter(a){try{
   this.object=this.context.ecx;this.compiler=a[0].add(4).readPointer();
   const selector=this.compiler.add(0x784).readU32();
   this.row={event:'conditional-profile-constructor',caller:loc(this.returnAddress),selector:selector,selector_offset:'0x784',context_offset:4,dispatch_table_hex:bytes(m.base.add(0xd71d0),20)};
   if(selector<=4)this.row.selected_branch=loc(m.base.add(0xd71d0).add(selector*4).readPointer());
  }catch(e){failure('constructor-enter',e);}},
  onLeave(r){if(!this.row)return;try{
   const delegate=this.object.add(4).readPointer();this.row.delegate_null=delegate.isNull();
   if(!delegate.isNull()){
    const v=delegate.readPointer();this.row.vtable=loc(v);this.row.virtual_method=loc(v.add(4).readPointer());
   }
   send(this.row);
  }catch(e){failure('constructor-leave',e);}}
 });
 for(const rva of [0x803e0,0x6fd20])Interceptor.attach(m.base.add(rva),{
  onEnter(a){try{
   this.object=this.context.ecx;this.row={event:'conditional-profile-helper',entry:loc(m.base.add(rva)),caller:loc(this.returnAddress),mode:this.object.add(0x1c).readU32(),node:this.object.add(0x18).readU32()};
  }catch(e){failure('helper-enter',e);}},
  onLeave(r){if(!this.row)return;try{
   this.row.mode_after=this.object.add(0x1c).readU32();this.row.node_after=this.object.add(0x18).readU32();this.row.result=r.toInt32();send(this.row);
  }catch(e){failure('helper-leave',e);}}
 });
 send({event:'conditional-profile-observer-installed',module:m.name,entries:['0x31280','0x214e0','0xd7050','0x803e0','0x6fd20']});
}});
