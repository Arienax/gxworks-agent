"""Causal control: runtime code page versus source/cache content and reset."""
from pathlib import Path
import base64,json,os,subprocess,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import sha256
from replay_gxw_workspace import prepare
from native_gxw_tokens import native_batch,native_il_projection,DEFAULT_DLL
P=Path(__file__).resolve().parent
out=P/'native-crt-codepage-control';out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
source=P/'compile-pending-stale-cache/baseline-fresh/native-saved.gxw'
crt=Path('C:/Windows/SysWOW64/msvcr71.dll')
assert sha256(crt.read_bytes())=='dca0e5faf6c94b6adff4d90d40795d5a91ba3a3059ea408e992a0f039a494d46'
rows=[]
for case,fresh,codepage in [('cached-observe',False,None),('cached-cp936',False,936),('fresh-cp54936',True,54936)]:
    target=out/case;exe=prepare(source,target,compile=True,export_project=True,project_alias='CRTPAGE')
    plan=json.loads((target/'plan.json').read_text());plan.update(reset_compiler=fresh,fresh_compiler_state=fresh)
    (target/'plan.json').write_text(json.dumps(plan,indent=2))
    helper=(target/'WorkspaceReplayOracle.cs').read_text()
    marker='            bool changeSfc=plan.ContainsKey("change_sfc")&&Convert.ToBoolean(plan["change_sfc"]);'
    assert helper.count(marker)==1
    insertion='            CrtCodePageSnapshot("before-control");\n'
    if codepage is not None:insertion+=f'            CrtCodePageControl({codepage});\n            CrtCodePageSnapshot("after-control");\n'
    helper=helper.replace(marker,insertion+marker)
    marker='            bool compilerRejected=WaitReports(compiler,changeSfc?168:40,"Progress");'
    assert helper.count(marker)==1
    helper=helper.replace(marker,marker+'\n            CrtCodePageSnapshot("after-build");')
    (target/'WorkspaceReplayOracle.cs').write_text(helper)
    (target/'NativeCrtCodePageControl.cs').write_bytes((P/'NativeCrtCodePageControl.cs').read_bytes())
    files=['WorkspaceReplayOracle.cs','NativeFrontendSnapshot.cs','NativeSfcGraphOracle.cs','NativeWorkspaceCopyOracle.cs','NativeCrtCodePageControl.cs']
    csc=Path(os.environ['WINDIR'])/'Microsoft.NET/Framework/v4.0.30319/csc.exe'
    build=subprocess.run([str(csc),'/nologo','/platform:x86','/r:System.Web.Extensions.dll','/r:System.Windows.Forms.dll',
        '/out:'+str(exe),*[str(target/f) for f in files]],capture_output=True,timeout=20,creationflags=subprocess.CREATE_NO_WINDOW)
    (target/'build.stdout.bin').write_bytes(build.stdout);(target/'build.stderr.bin').write_bytes(build.stderr);build.check_returncode()
    request=json.loads((target/'request.json').read_text());request.update(actual_plan_sha256=sha256((target/'plan.json').read_bytes()),
        helper_sources={f:sha256((target/f).read_bytes()) for f in files},crt_path=str(crt),crt_sha256=sha256(crt.read_bytes()))
    (target/'request.json').write_text(json.dumps(request,indent=2))
    process=subprocess.run([str(exe),str(target/'plan.json')],cwd=target,capture_output=True,timeout=50,creationflags=subprocess.CREATE_NO_WINDOW)
    (target/'process.stdout.bin').write_bytes(process.stdout);(target/'process.stderr.bin').write_bytes(process.stderr)
    events=[json.loads(s) for s in (target/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    row=dict(case=case,fresh=fresh,codepage_control=codepage,input_sha256=sha256(source.read_bytes()),returncode=process.returncode,
        diagnostics=[r for e in events for r in e.get('reports',[]) if r['kind'] in (2,3)],
        compile_completed=any(e['operation']=='Progress' and e.get('percent')==100 for e in events),
        crt_events=[e for e in events if e['operation'].startswith('Crt')],last_event=events[-1],
        outputs={p.name:sha256(p.read_bytes()) for p in target.glob('pcode-*.bin')})
    rows.append(row);(target/'comparison.json').write_text(json.dumps(row,indent=2))
    (out/'comparison.json').write_text(json.dumps(dict(cases=rows),indent=2));print(json.dumps(row),flush=True)
paths=[out/r['case']/'pcode-0-0.bin' for r in rows if (out/r['case']/'pcode-0-0.bin').exists()]
answers=native_batch([dict(mode='decode',input_base64=base64.b64encode(p.read_bytes()+b'\0').decode()) for p in paths],out/'native-decode',dll=DEFAULT_DLL,cpu_code=0x208)
decoded=[]
for p,a in zip(paths,answers,strict=True):
    assert a['return_code']=='0x00000000' and a['consumed_bytes']==p.stat().st_size
    result=native_il_projection(base64.b64decode(a['output_base64']),encoding='gb18030');assert not result['text_gaps']
    decoded.append(dict(case=p.parent.name,records=result['records']))
(out/'decoded.json').write_text(json.dumps(decoded,indent=2))
print(json.dumps([dict(case=r['case'],x2=[v for v in r['records'] if v.get('args')==['X002']]) for r in decoded]),flush=True)
