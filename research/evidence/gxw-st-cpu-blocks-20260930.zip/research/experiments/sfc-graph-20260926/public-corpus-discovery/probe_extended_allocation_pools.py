"""Trace native selection among ordinary/retain word pools on owned copies."""
from pathlib import Path
import json,struct,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from probe_gxw_parameters import project_allocation_ranges
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import prepare,trace_prepared
from probe_gxw_program_check_resources import SCRIPT,inspect_run
P=Path(__file__).resolve().parent
OUT=P/'extended-allocation-pools-20260930'

def main():
    OUT.mkdir(exist_ok=False);(OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    original=(P/'noeul-native-batch/case-08/input.gxw').read_bytes()
    streams={s.logical_name:s.raw for s in inspect_project(original).streams if s.logical_name}
    name=next(n for n in streams if n.endswith('.prj'));old=streams[name]
    ranges={r['name']:r for r in project_allocation_ranges(old)['ranges']}
    unset=(0xffffffff,0xffffffff)
    specs=[('all-banks',dict(D=(7000,7000),W=(256,256),R=(1000,1000),ZR=(2000,2005))),
           ('R-only',dict(D=unset,W=unset,R=(1000,1007),ZR=unset)),
           ('ZR-only',dict(D=unset,W=unset,R=unset,ZR=(2000,2007)))]
    results=[]
    script=OUT/'trace.js';allocation=(P/'native-allocation-bitmap-v2/observer.js').read_text(encoding='utf-8')
    script.write_text('(()=>{'+allocation+'\n})();\n(()=>{'+SCRIPT+'\n})();',encoding='utf-8')
    for case,changes in specs:
        directory=OUT/case;directory.mkdir();new=bytearray(old)
        for bank,pair in changes.items():struct.pack_into('<II',new,ranges[bank]['offset'],*pair)
        source,receipt=patch_raw(original,name,old,bytes(new));path=directory/'input.gxw';path.write_bytes(source)
        after={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
        assert after==dict(streams,**{name:bytes(new)})
        (directory/'prediction-before-native.json').write_text(json.dumps(dict(input_sha256=sha256(source),receipt=receipt,
            changed_pools=changes,ordinary_search_hypothesis='Native 0x47180 searches descriptors 24,25,26,27 in order; map R/ZR using isolated pools.',
            untouched_payloads='byte-identical',parameter_capacity='retained from real input, native outcome decides validity'),indent=2),encoding='utf-8')
        for attempt in range(1,5):
            native=directory/f'native-{attempt}';prepare(path,native,compile=True,program_check=True,export_project=True,
                snapshot_frontend=True,project_alias='POOLBANK')
            trace=trace_prepared(native,script)
            events=[json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
            if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
        observed=inspect_run(native)
        messages=[json.loads(l) for l in (native/'events.jsonl').read_text(encoding='utf-8').splitlines()]
        emitted=[r['payload'] for r in messages if r.get('type')=='send'];typed=[r for r in emitted if r.get('event')=='typed-allocation']
        pools=[r for r in emitted if r.get('event')=='pool-allocation'];writes=[r for r in emitted if r.get('event')=='component-userinfo-write']
        errors=[r for r in messages if r.get('type')=='error' or 'error' in r.get('payload',{}).get('event','') or 'observation_error' in r.get('payload',{})]
        row=dict(case=case,native_directory=str(native),trace=trace,check=observed['check'],diagnostics=observed['diagnostics'],
            generated=observed['generated'],trace_errors=errors,typed=typed,pools=pools,component_writes=writes)
        results.append(row);(OUT/'comparison.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
        print(json.dumps(dict(case=case,check=row['check'],trace_errors=errors,allocations=[dict(type=r['type'],category=r['category'],raw=r.get('after'),result=r['result']) for r in typed],
            active_word_descriptors=[{k:v for k,v in d.items() if k!='bitmap'} for d in pools[0]['descriptors'] if 24<=d['index']<=30] if pools else [],
            errors=[{k:v for k,v in r.items() if k!='raw_base64'} for r in row['diagnostics'] if r['kind']==2]),ensure_ascii=True),flush=True)

if __name__=='__main__':main()
