from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[4];sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from probe_gxw_integrity import patch_verified_payloads
from probe_gxw_task_graph import _text
from replay_gxw_workspace import run
P=Path(__file__).resolve().parent;OUT=P/'fx3g-without-modbus-task';OUT.mkdir(exist_ok=False)
(OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
original=(P/'cross-family-source-holdouts/case-00/input.gxw').read_bytes();before={s.logical_name:s.raw for s in inspect_project(original).streams if s.logical_name}
task=before['MB.tsk'];_,i=_text(task,54);_,i=_text(task,i);assert task[i:i+8]==bytes.fromhex('1f00000000000000');i+=8
candidate,receipt=patch_verified_payloads(original,{'MB.tsk':(task,task[:i]+bytes(4))})
after={s.logical_name:s.raw for s in inspect_project(candidate).streams if s.logical_name};assert [k for k in before if before[k]!=after[k]]==['MB.tsk']
path=OUT/'candidate.gxw';path.write_bytes(candidate)
(OUT/'prediction-before-native.json').write_text(json.dumps(dict(source_sha256=sha256(original),candidate_sha256=sha256(candidate),touched=['MB.tsk'],all_programs_and_declarations_byte_identical=True,receipt=receipt,hypothesis='All 22 fresh ProgramCheck errors resolve to Modbus; remove only its task root to distinguish selected output errors from source validation'),indent=2),encoding='utf-8')
results=[]
for phase in ('compile','reopen'):
 for attempt in range(1,5):
  native=OUT/f'{phase}-{attempt}';outcome=run(path,native,compile=True,program_check=True,export_project=True,snapshot_frontend=True,project_alias='NOMBTASK')
  events=[json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
  if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
 path=native/'native-saved.gxw';code=native/'pcode-0-0.bin';result=dict(phase=phase,native_directory=str(native),outcome=outcome,pcode_sha256=sha256(code.read_bytes()) if code.exists() else None,pcode_bytes=code.stat().st_size if code.exists() else None,saved=path.exists())
 results.append(result);(OUT/'comparison.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
 print(json.dumps(dict(phase=phase,open=outcome['open_succeeded'],rejected=outcome['compiler_rejected'],saved=result['saved'],pcode_bytes=result['pcode_bytes'],pcode_sha256=result['pcode_sha256'],errors=[r for r in outcome['diagnostics'] if r['kind']==2]),ensure_ascii=True),flush=True)
 if not path.exists() or outcome['compiler_rejected']:break
