"""Distinguish program-language restrictions from task ordering.

Synthetic ST envelopes use the previously native-validated C1 UTF-16 framing,
retaining each original source header and local/global declarations. Every
replacement is compiled in an owned copy of the MIT project; this is not a
general language-conversion API. No BoxID bytes or code are used here.
"""
from pathlib import Path
import base64, json, struct, sys
ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'research')]
from gxw.lossless import inspect_project, sha256
from gxw.container_writer import validate_cfb_streams
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import run
from native_gxw_tokens import native_batch, native_il_projection, Q_DLL

P = Path(__file__).resolve().parent
out = P/'q-task-st-order'; out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
source = (P/'q-source-constant-edits/baseline-0/source.gxw').read_bytes()
assert not validate_cfb_streams(source).get('Project.gd2')
streams = {s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
task = '응용동작1.tsk'; old = streams[task]
A, B = '기본동작', '응용동작1'
def strings(values):
    result=struct.pack('<I',len(values))
    for value in values:
        text=(value+'\0').encode('utf-16le')
        result+=struct.pack('<I',len(text)//2)+text
    return result
assert old==old[:84]+strings([B])+strings([''])
plans=[('single-ST',[B],[1],[''],[B]),('two-ST',[A,B],[1,2],['',''],[A,B]),
       ('two-ST-reverse',[A,B],[2,1],['',''],[A,B]),('two-ST-shuffle',[B,A],[2,1],['',''],[A,B]),
       ('mixed-ST-LD',[A,B],[1,2],['',''],[A]),('mixed-LD-ST',[A,B],[1,2],['',''],[B])]
def st_source(raw,text):
    encoded=(text+'\0').encode('utf-16le')
    new=bytearray(raw[:54]+b'\xc1'+bytes(8)+struct.pack('<II',1,len(encoded)//2)+encoded+bytes(28))
    struct.pack_into('<II',new,55,len(new)-83,len(new)-83)
    return bytes(new)

rows=[];requests=[];files={}
for case,names,flags,extra,st_names in plans:
    directory=out/case;directory.mkdir()
    new=old[:84]+struct.pack('<I',len(names))+b''.join(strings([name])[4:]+struct.pack('<I',flag)+strings([note])[4:] for name,flag,note in zip(names,flags,extra,strict=True))
    changed,receipt=(source,{'unchanged':True}) if new==old else patch_raw(source,task,old,new)
    expected=dict(streams,**{task:new});source_edits=[]
    for name in st_names:
        logical=name+'.Program.pou';text='STATE := '+('101' if name==A else '202')+';\r\n'
        pou=st_source(streams[logical],text)
        changed,edit=patch_raw(changed,logical,streams[logical],pou)
        expected[logical]=pou;source_edits.append(dict(program=logical,text=text,receipt=edit))
    payloads={s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}
    assert payloads==expected
    path=directory/'changed.gxw';path.write_bytes(changed)
    mutation=dict(task=task,source_sha256=sha256(source),changed_sha256=sha256(changed),
                  names=names,flags=flags,extra=extra,source_edits=source_edits,original_task_hex=old.hex(),changed_task_hex=new.hex(),container=receipt)
    (directory/'mutation.json').write_text(json.dumps(mutation,indent=2),encoding='utf-8')
    for attempt in range(1,9):
        native=directory/('native' if attempt==1 else 'native-v'+str(attempt))
        result=run(path,native,compile=True,snapshot_frontend=True,export_project=True,project_alias='QTASKSEQUENCE')
        events=[json.loads(s) for s in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
        if (native/'pcode-0-0.bin').exists() or not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
    row=dict(case=case,names=names,flags=flags,extra=extra,native_directory=str(native.relative_to(out)),
             native={k:result[k] for k in ('returncode','open_succeeded','compile_completed','compiler_rejected','diagnostics')})
    snapshot=native/'frontend-snapshot.json'
    if snapshot.exists():
        build=json.loads(snapshot.read_text(encoding='utf-8-sig'))['build']
        row['native_task_buffer']=next(r['data'] for r in build['relocations'] if r['offset']==36)
    if row['native']['compile_completed'] and not row['native']['compiler_rejected']:
        files[case]={}
        for f in sorted(native.glob('pcode-*.bin')):
            raw=f.read_bytes();files[case][f.name]=len(requests)
            requests.append(dict(mode='decode',input_base64=base64.b64encode(raw+b'\0').decode()))
    rows.append(row)
    (directory/'comparison.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in row.items() if k!='native_task_buffer'}),flush=True)
answers=native_batch(requests,out/'native-pcode-decode',dll=Q_DLL,cpu_code=209)
decoded=[]
for request,answer in zip(requests,answers,strict=True):
    assert answer['return_code']=='0x00000000' and answer['consumed_bytes']==len(base64.b64decode(request['input_base64']))-1
    projection=native_il_projection(base64.b64decode(answer['output_base64']),encoding='cp949')
    assert not projection['text_gaps'];decoded.append(projection['records'])
result=dict(cases=rows,files=files,decoded=decoded,scope=__doc__)
with (out/'comparison.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2,ensure_ascii=False)
print(json.dumps(dict(record_counts={case:{name:len(decoded[index]) for name,index in units.items()} for case,units in files.items()})),flush=True)
