// Read-only observation of the native completion state; no return overrides.
Process.attachModuleObserver({onAdded(m) {
  if(/DataManager|Compiler/i.test(m.name))send({event:'module',name:m.name});
  if(m.name.toLowerCase()==='dzdataabs_compileradapter.dll') {
    const targets=new Set();
    Interceptor.attach(m.base.add(0x9674),{onEnter(){
      const self=this.context.ecx.add(0x14).readPointer(),target=self.readPointer().add(44).readPointer(),mod=Process.findModuleByAddress(target);
      if(targets.has(target.toString()))return;targets.add(target.toString());
      send({event:'backend_progress',target:target.toString(),module:mod?mod.name:null,rva:mod?target.sub(mod.base).toString():null});
    }});
    Interceptor.attach(m.base.add(0x13a2a),{onEnter(){this.active=this.returnAddress.equals(m.base.add(0x13e75));},onLeave(ret){
      if(!this.active)return;
      const self=ret.readPointer(),target=self.readPointer().add(4).readPointer(),mod=Process.findModuleByAddress(target);
      if(targets.has(target.toString()))return;targets.add(target.toString());
      send({event:'progress_target',target:target.toString(),module:mod?mod.name:null,rva:mod?target.sub(mod.base).toString():null,
        modules:Process.enumerateModules().filter(x=>/data|compiler/i.test(x.name)).map(x=>x.name)});
    }});
  }
  if(m.name.toLowerCase() !== 'dzdataabs_compiler_iec.dll') return;
  const report=m.base.add(0x10084).readPointer();send({event:'report_target',address:report.toString()});
  Interceptor.attach(report, {onEnter(args) {
    this.obj=this.context.ecx;this.output=args[0];
    this.before={progress:this.obj.add(0x28).readS32(),state:this.obj.add(0x2c).readS32()};
  },onLeave(ret) {
    send({event:'GetProgress',before:this.before,returned:ret.toString(),output:this.output.readS32(),
      after:{progress:this.obj.add(0x28).readS32(),state:this.obj.add(0x2c).readS32()}});
  }});
  Interceptor.attach(report.sub(0x2dd4).add(0x20ab), {onEnter(args) {
    send({event:'SetStatus',value:args[0].toInt32(),stack:Thread.backtrace(this.context,Backtracer.ACCURATE).slice(0,5).map(a=>{
      const mod=Process.findModuleByAddress(a);return mod?mod.name+'+'+a.sub(mod.base).toString():a.toString();})});
  }});
}});
