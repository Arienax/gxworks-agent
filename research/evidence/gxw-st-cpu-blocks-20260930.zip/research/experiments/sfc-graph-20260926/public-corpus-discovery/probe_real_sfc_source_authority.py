"""Separate source task membership from stored compiled-resource contents."""
from pathlib import Path
import json
import struct
import sys
ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'research')]
from gxw.lossless import inspect_project, sha256
from gxw.token_pou import parse_token_fragment
from probe_gxw_task_graph import inspect_task_graph, task_records
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import run
from source_fx_sfc_projection import project_projection

P = Path(__file__).resolve().parent
OUT = P/'real-sfc-source-authority'


def main():
    OUT.mkdir(exist_ok=False)
    for f in [Path(__file__), P/'source_fx_sfc_projection.py']:
        (OUT/f.name).write_bytes(f.read_bytes())
    source = (P/'additional-real-projects/case-03/input.gxw').read_bytes()
    streams = {s.logical_name: s.raw for s in inspect_project(source).streams if s.logical_name}
    graph = inspect_task_graph(source); task_name = graph['resources'][0]['task']; resource = graph['resources'][0]['resource']
    task = task_records(streams[task_name]); entries = task['entries']
    prefix = bytearray(streams[task_name][:entries[0]['offset']])
    plans = []
    for tag, indices in [('only-block0', [0]), ('only-block1', [1]), ('no-task-entries', [])]:
        pre = bytearray(prefix); struct.pack_into('<I', pre, len(pre) - 4, len(indices))
        updated = bytes(pre) + b''.join(bytes.fromhex(entries[i]['raw_hex']) for i in indices)
        plans.append((tag, task_name, updated, dict(task_indices=indices)))
    raw = streams[resource]; updated = bytearray(raw); cursor = 54; offsets = []
    for _ in range(2):
        size = struct.unpack_from('<I', raw, cursor)[0]; start = cursor + 4; end = start + size
        assert raw[end:end + 8] == b'\0' * 8
        for token in parse_token_fragment(raw, start, size).tokens:
            if token.raw == bytes.fromhex('049d0204'):
                updated[token.offset + 2] = 6; offsets.append(token.offset + 2)
        cursor = end + 8
    assert offsets
    plans.append(('compiled-resource-device-poison', resource, bytes(updated), dict(poison_offsets=offsets)))
    ready = []
    for tag, logical, updated, details in plans:
        directory = OUT/tag; directory.mkdir()
        patched, receipt = patch_raw(source, logical, streams[logical], updated)
        (directory/'source.gxw').write_bytes(patched)
        candidate, prediction = project_projection(patched); (directory/'candidate.bin').write_bytes(candidate)
        (directory/'prediction-before-native.json').write_text(json.dumps(dict(source_sha256=sha256(source),
            changed_sha256=sha256(patched), receipt=receipt, candidate_sha256=sha256(candidate), prediction=prediction,
            scope='SFC conversion/export only; baseline full-program-check failure retained separately', **details), indent=2), encoding='utf-8')
        ready.append((tag, directory, candidate))
    results = []
    for tag, directory, candidate in ready:
        for attempt in range(1, 5):
            native = directory/f'native-{attempt}'
            outcome = run(directory/'source.gxw', native, compile=True, change_sfc=True,
                export_project=True, snapshot_frontend=True, project_alias='SFCAUTH')
            events = [json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
            if not any(e.get('operation') == 'NativeTemporaryDirectoryCollision' for e in events):
                break
        file = native/'pcode-0-0.bin'; actual = file.read_bytes() if file.exists() else None
        row = dict(case=tag, native_directory=str(native), outcome=outcome,
            full_pcode_identical=actual == candidate,
            actual_sha256=sha256(actual) if actual is not None else None,
            actual_bytes=len(actual) if actual is not None else None)
        (directory/'comparison.json').write_text(json.dumps(row, indent=2), encoding='utf-8')
        results.append(row); (OUT/'comparison.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
        print(json.dumps(dict(**{k: v for k, v in row.items() if k != 'outcome'},
            compile_completed=outcome['compile_completed'], compiler_rejected=outcome['compiler_rejected'])), flush=True)


if __name__ == '__main__':
    main()
