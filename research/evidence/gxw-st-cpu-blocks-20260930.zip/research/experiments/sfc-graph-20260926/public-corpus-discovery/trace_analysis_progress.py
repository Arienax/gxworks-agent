import json
from pathlib import Path
import sys
import threading

ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research'),str(ROOT/'research/experiments/re-tools')]
import frida
from replay_gxw_workspace import prepare

P=Path(__file__).resolve().parent
out=P/'fx1s-reference-progress-trace-7'
q=[dict(name='references',keys=[],symbol='',scope='',declared=0,plural=0)]
exe=prepare(P/'samples/stepper-2-1.gxw',out,compile=True,export_project=True,project_alias='FX1SREF',analysis_queries=q,analysis_version=3)
device=frida.get_local_device()
pid=device.spawn([str(exe),str(out/'plan.json')],cwd=str(out),stdio='pipe')
session=device.attach(pid)
finished=threading.Event()
session.on('detached',lambda *args: finished.set())
with (out/'trace.jsonl').open('w',encoding='utf-8') as log:
 script=session.create_script((P/'TraceAnalysisProgress.js').read_text(encoding='utf-8'))
 def message(msg,data):
  log.write(json.dumps(msg)+'\n');log.flush()
 script.on('message',message)
 script.load();device.resume(pid)
 if not finished.wait(50):
  device.kill(pid)
  raise TimeoutError('owned native helper exceeded bound')
print(str(out))
