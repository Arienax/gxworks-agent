"""Check type-entry instrumentation against fresh uninstrumented compilations."""
from pathlib import Path
import hashlib,json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research'),str(ROOT/'research/experiments/re-tools')]
from replay_gxw_workspace import run
import capstone,pefile
P=Path(__file__).resolve().parent
out=P/'q-fb-array-type-crosscheck';out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
def diagnostic_rows(path):
    events=[json.loads(s) for s in path.read_text(encoding='utf-8-sig').splitlines()]
    return sorted({json.dumps({k:v for k,v in r.items() if k!='raw_base64'},sort_keys=True) for e in events for r in e.get('reports',[]) if r['kind']==2})
rows=[]
for case in ['local-fb-array','local-int-array','local-fb-scalar','global-fb-array']:
    observed=P/'q-fb-array-type-trace-v5'/case
    for attempt in range(1,9):
        native=out/(case if attempt==1 else case+'-v'+str(attempt))
        result=run(observed/'input.gxw',native,compile=True,snapshot_frontend=True,export_project=True,project_alias='QFBARRAYTRACE')
        if result['open_succeeded']:break
        events=[json.loads(s) for s in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
        if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
    expected=diagnostic_rows(native/'native-events.jsonl');actual=diagnostic_rows(observed/'native/native-events.jsonl')
    def outputs(d):return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in d.glob('pcode-*.bin')}
    row=dict(case=case,native_directory=native.name,observed_directory=str(observed.relative_to(P)),
        native={k:result[k] for k in ('returncode','open_succeeded','compile_completed','compiler_rejected')},
        diagnostic_projection_exact=expected==actual,diagnostics=[json.loads(r) for r in expected],
        pcode_files_exact=outputs(native)==outputs(observed/'native'),pcode_files=outputs(native))
    assert row['native']['returncode']==0 and row['native']['compile_completed']
    assert row['diagnostic_projection_exact'] and row['pcode_files_exact']
    rows.append(row);print(json.dumps(row),flush=True)
dll=Path('D:/GXWORKS2/DNaviZero/DataAbsorber/DZDataABS_SICConverter_IEC.dll');pe=pefile.PE(str(dll))
md=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32)
disassembly='\n'.join(f'{i.address:08x} {i.bytes.hex()} {i.mnemonic} {i.op_str}' for i in md.disasm(pe.get_data(0x9afe2,0x24b),0x9afe2))+'\n'
(out/'type-resolver-disassembly.txt').write_text(disassembly)
imports=[dict(dll=d.dll.decode(),address=hex(i.address),name=i.name.decode()) for d in pe.DIRECTORY_ENTRY_IMPORT for i in d.imports if i.address in (0x668ee0c4,0x668ee05c)]
summary=dict(cases=rows,dll=str(dll),dll_sha256=hashlib.sha256(dll.read_bytes()).hexdigest(),type_resolver_rva='0x9afe2',manager_imports=imports,
    observations=dict(array_user_name='type 10 / parameter 100 / SCPI / error 0x5002000b at validation caller',
        scalar_user_fb='type 15 / parameter 0 / SCPI / error 0',array_int='type 10 / parameter 2 / empty reference / error 0'),
    static_flow='Array (10,100) consults SDT manager only. Scalar type 100 consults SDT, then POU manager and requires kind 1 before producing type 15.',
    failed_instrumentation=['v1 module observer did not find the dependency','v2 checked 15 bytes against a 16-byte signature',
        'v3 included an incorrectly aligned immediate site; later retries encountered already patched sites',
        'v4 interior-instruction hooks changed final rejection to 0x500c5150; cannot serve as behavioral oracle'],
    scope='This native pipeline and these four derived offline projects. No universal claim for every project mode or vendor release.')
(out/'comparison.json').write_text(json.dumps(summary,indent=2))
