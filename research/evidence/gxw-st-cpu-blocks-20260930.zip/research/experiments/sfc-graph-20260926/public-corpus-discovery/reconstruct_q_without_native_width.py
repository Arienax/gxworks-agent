"""Rerun source binders with Python widths; read native baseline only afterwards."""
import contextlib
import hashlib
import io
import json
from pathlib import Path
import re
import sys

P=Path(__file__).resolve().parent
OUT=P/'q-source-without-native-width-v2'

def main():
    OUT.mkdir(exist_ok=False)
    for name in ['source_q_width.py','source_q_allocation.py','q-width-static-tables.json']:
        (OUT/name).write_bytes((P/name).read_bytes())
    results=[]
    for suffix in ['', '_ranges','_fragmented','_real_multi','_order']:
        path=P/f'reconstruct_q_source_allocated{suffix}.py'
        code=path.read_text(encoding='utf-8')
        start=code.index(" protocol=''.join(")
        end=code.index(" output=b''.join(parts)",start)
        code=code[:start]+" from source_q_width import rewrite\n for req in requests:parts[req['index']]=rewrite(bytes.fromhex(req['raw']))\n"+code[end:]
        target=OUT/(suffix.lstrip('_') or 'original')
        code,n=re.subn(r"OUT=P/'[^']+';OUT.mkdir\(exist_ok=False\)",lambda _:f'OUT=Path({target.as_posix()!r});OUT.mkdir(exist_ok=False)',code,count=1)
        assert n==1 and 'subprocess.run' not in code and 'PublicCheckOracle.exe' not in code
        code=code.replace('Public native Q instruction-width check still used.','Python-only Q71 width calculation; no vendor DLL loaded during prediction. Unbound instructions remain raw-preserved.')
        generated=OUT/(path.stem+'_python_width.py');generated.write_text(code,encoding='utf-8')
        output=io.StringIO()
        with contextlib.redirect_stdout(output):
            # Original __file__ keeps source-only corpus roots stable.
            exec(compile(code,str(generated),'exec'),dict(__file__=str(path),__name__='__main__'))
        (target/'run.jsonl').write_text(output.getvalue(),encoding='utf-8')
        rows=json.loads((target/'comparison.json').read_text())
        results.extend(rows)
        print(json.dumps(dict(profile=suffix or 'original',programs=len(rows),exact=sum(r['byte_identical'] for r in rows))))
    summary=dict(programs=len(results),byte_identical=sum(r['byte_identical'] for r in results),records=sum(r['records'] for r in results),bindings=sum(r['bindings'] for r in results),native_width_execution=False,results=results)
    (OUT/'comparison.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in summary.items() if k!='results'}))

if __name__=='__main__':main()
