"""Change only source declarations while retaining old compiler cache bytes."""
from pathlib import Path
import json
import struct
import sys

ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.declarations import parse_declarations,edit_declarations,serialize_declarations
from gxw.compiler_tables import parse_compiler_tables
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import run
from source_q_project_projection import project_projection

P=Path(__file__).resolve().parent
OUT=P/'q-declaration-cache-authority'

def payloads(raw):return {s.logical_name:s.raw for s in inspect_project(raw).streams if s.logical_name}

def main():
    OUT.mkdir(exist_ok=False)
    for name in ['probe_q_declaration_cache_authority.py','source_q_project_projection.py','source_q_label_binding.py','source_q_allocation.py','source_q_width.py','q-width-static-tables.json']:
        (OUT/name).write_bytes((P/name).read_bytes())
    source=(P/'noeul-native-batch/case-11/input.gxw').read_bytes();before=payloads(source)
    logical=next(n for n in before if n.endswith('.Labels.lh') and any(r.name=='blink1' for r in parse_declarations(before[n],logical_name=n).rows))
    doc=parse_declarations(before[logical],logical_name=logical)
    constants=[r for r in doc.rows if r.class_code==2 and r.initial_value=='0'];assert len(constants)==1
    constant=constants[0]
    cases=[('constant-nine',dict(name=constant.name,data_type='INT',initial_value='9')),('constant-negative',dict(name=constant.name,data_type='INT',initial_value='-1')),('array-grow',dict(name='blink1',data_type='ARRAY [0..7] OF BOOL',initial_value='[8(FALSE)]')),('array-shift',dict(name='blink1',data_type='ARRAY [1..4] OF BOOL',initial_value='[4(FALSE)]')),('array-negative-lower',dict(name='blink1',data_type='ARRAY [-2..3] OF BOOL',initial_value='[6(FALSE)]'))]
    results=[]
    for name,edit in cases:
        directory=OUT/name;directory.mkdir()
        changed_labels=serialize_declarations(edit_declarations(doc,upserts=[edit]))
        changed,receipt=patch_raw(source,logical,before[logical],changed_labels)
        after=payloads(changed)
        assert after==dict(before,**{logical:changed_labels})
        path=directory/'input.gxw';path.write_bytes(changed)
        predictions=project_projection(changed)
        for row in predictions:(directory/f'predicted-{row["resource_index"]}.bin').write_bytes(row.pop('output'))
        (directory/'prediction-before-native.json').write_text(json.dumps(dict(mutation=edit,receipt=receipt,source_sha256=sha256(source),changed_sha256=sha256(changed),compiler_cache_unchanged=after['CGTable.dat']==before['CGTable.dat'],predictions=predictions),indent=2),encoding='utf-8')
        for attempt in range(1,5):
            native=directory/f'native-{attempt}'
            outcome=run(path,native,compile=True,export_project=True,project_alias='QDECLCACHE')
            events=[json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
            if not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
        native_accepted=outcome['returncode']==0 and outcome['compile_completed'] and not outcome['compiler_rejected'] and (native/'native-saved.gxw').exists()
        row=dict(case=name,native_directory=str(native),native_accepted=native_accepted,outcome=outcome,programs=[])
        if native_accepted:
            nt=parse_compiler_tables(payloads((native/'native-saved.gxw').read_bytes())['CGTable.dat']);assignments={}
            for record in nt.tables[1].records:
                pou=nt.pou_at(record.table_offset)
                for c in nt.components(pou):assignments[pou.name_bytes.hex()+':'+c.name_bytes.hex()]=c.user_info.hex()
            for pred in predictions:
                i=pred['resource_index'];actual=(native/f'pcode-{i}-0.bin').read_bytes();ours=(directory/f'predicted-{i}.bin').read_bytes()
                diffs=[dict(identity=k,predicted=v,native=assignments.get(k)) for k,v in pred['assignments'].items() if assignments.get(k)!=v]
                row['programs'].append(dict(index=i,program=pred['program'],byte_identical=ours==actual,predicted_sha256=sha256(ours),native_sha256=sha256(actual),allocation_differences=diffs))
        (directory/'comparison.json').write_text(json.dumps(row,indent=2),encoding='utf-8');results.append(row)
        (OUT/'comparison.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
        print(json.dumps(dict(case=name,native_accepted=native_accepted,programs=row['programs'],diagnostics=outcome['diagnostics'])),flush=True)

if __name__=='__main__':main()
