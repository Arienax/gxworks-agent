"""Native-grounded array mutations in the real signed project2 source."""
import base64
import json
from pathlib import Path
import struct
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'research')]
from gxw.lossless import inspect_project, sha256
from gxw.declarations import parse_declarations, edit_declarations, serialize_declarations
from gxw.token_pou import frame_token_pou, parse_token_fragment
from native_gxw_tokens import native_batch, native_il_records, Q_DLL
from probe_gxw_parameters import device_allocation_record
from probe_gxw_integrity import patch_verified_payloads
from replay_gxw_workspace import run

P = Path(__file__).resolve().parent
OUT = P / 'project2-declared-array-mutations'
OUT.mkdir(exist_ok=False)
source = (P / 'samples/project2.gxw').read_bytes()
streams = {s.logical_name: s.raw for s in inspect_project(source).streams if s.logical_name}
document = parse_declarations(streams['Global1.gh'], logical_name='Global1.gh')
frame = frame_token_pou(streams['MAIN.Program.pou'])
old = next(t.raw for t in frame.tokens if t.raw[1] == 0xdf and t.raw[2:-1] == b'PB4')
assert sum(t.raw == old for t in frame.tokens) == 1
cases = [('one_dimensional', 'ARRAY [0..3] OF BOOL', 'PB4[2]'),
         ('negative_lower', 'ARRAY [-2..1] OF BOOL', 'PB4[0]'),
         ('two_dimensional', 'ARRAY [1..2,3..4] OF BOOL', 'PB4[2,3]'),
         ('out_of_bounds', 'ARRAY [0..3] OF BOOL', 'PB4[4]'),
         ('missing_index', 'ARRAY [0..3] OF BOOL', 'PB4')]
requests = [dict(mode='encode', input_base64=base64.b64encode(("LD '" + ref).encode('cp949') + b'\0\0').decode()) for _,_,ref in cases]
encoded = native_batch(requests, OUT / 'source-native-encode', dll=Q_DLL, cpu_code=209,
                       native_versions=(25,), device_context=device_allocation_record(streams['Param.wpa']).raw)
baseline = (P / 'native-assignment-real-corpus/case-02/native/pcode-0-0.bin').read_bytes()
results = []
for (case, datatype, reference), encoding in zip(cases, encoded):
    directory = OUT / case
    directory.mkdir()
    row = dict(case=case, datatype=datatype, reference=reference, encoding_code=encoding['return_code'])
    if encoding['return_code'] != '0x00000000':
        results.append(row)
        continue
    raw = base64.b64decode(encoding['output_base64'])
    tokens = [t.raw for t in parse_token_fragment(raw, 0, len(raw)).tokens if t.raw[1] == 0xdf]
    assert len(tokens) == 1 and tokens[0][2:-1] == reference.encode('cp949')
    new_body = b''.join(tokens[0] if t.raw == old else t.raw for t in frame.tokens)
    header = bytearray(frame.raw[:frame.body_offset])
    struct.pack_into('<II', header, 55, len(new_body) + 20, len(new_body) + 20)
    new_program = bytes(header) + new_body + frame.raw[frame.body_end:]
    new_document = edit_declarations(document, upserts=[dict(name='PB4', data_type=datatype, device='X80', iec_address='%IX128')])
    new_labels = serialize_declarations(new_document)
    changed, receipt = patch_verified_payloads(source, {'MAIN.Program.pou': (frame.raw, new_program),
                                                        'Global1.gh': (streams['Global1.gh'], new_labels)})
    path = directory / 'changed.gxw'
    path.write_bytes(changed)
    (directory / 'mutation.json').write_text(json.dumps(dict(source_sha256=sha256(source), label='PB4',
        datatype=datatype, reference=reference, receipt=receipt), indent=2), encoding='utf-8')
    query = [dict(name=name, keys=[dict(category=1, value=name)]) for name in dict.fromkeys(['PB4',reference])]
    native = run(path, directory / 'native', compile=True, export_project=True, project_alias='ARRAYPROBE', assignment_queries=query)
    row['native'] = {k:native[k] for k in ['returncode','open_succeeded','compile_completed','compiler_rejected','diagnostics']}
    answers = directory / 'native/native-device-assignments.json'
    if answers.exists():row['assignments'] = json.loads(answers.read_text(encoding='utf-8-sig'))
    if native.get('native_export'):
        reopened = run(directory / 'native/native-saved.gxw', directory / 'reopen', compile=True, export_project=True, assignment_queries=query)
        row['reopen'] = {k:reopened[k] for k in ['returncode','compile_completed','compiler_rejected','diagnostics']}
        row['compiled_equal_after_reopen'] = native['outputs'] == reopened['outputs']
        code = (directory / 'native/pcode-0-0.bin').read_bytes()
        decoded = native_batch([dict(mode='decode',input_base64=base64.b64encode(b+b'\0').decode()) for b in [baseline,code]],
                               directory / 'compiled-native-decode', dll=Q_DLL, cpu_code=209)
        assert all(d['return_code']=='0x00000000' for d in decoded)
        before, after = [native_il_records(base64.b64decode(d['output_base64']),encoding='cp949') for d in decoded]
        assert len(before) == len(after)
        row['compiled_differences'] = [dict(index=i,before=a,after=b) for i,(a,b) in enumerate(zip(before,after)) if a != b]
    results.append(row)
    (OUT / 'results.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
    print(json.dumps(row),flush=True)
