"""Read-only function-boundary trace of a fresh memory-only Q check helper."""
from pathlib import Path
import sys,json,subprocess,base64,time,hashlib
ROOT=Path(__file__).resolve().parents[4]
sys.path.insert(0,str(ROOT/'research/experiments/re-tools'))
import frida
P=Path(__file__).resolve().parent
OUT=P/'q-width-corpus-trace';OUT.mkdir(exist_ok=False)
(OUT/'probe.py').write_bytes(Path(__file__).read_bytes())
(OUT/'Trace.js').write_bytes((P/'TraceQWidth.js').read_bytes())
original=(P/'q-public-check-replay/PublicCheckOracle.cs').read_text()
helper=original.replace('args.Length > 6','args.Length > 7').replace('if (args.Length == 6)', 'if (args.Length >= 6)').replace('string line;\n            while ((line = Console.ReadLine()) != null)', 'foreach (string line in File.ReadAllLines(args[6]))')
assert helper!=original and 'while ((line = Console.ReadLine())' not in helper
(OUT/'WidthOracle.cs').write_text(helper)
compiler='C:/Windows/Microsoft.NET/Framework/v4.0.30319/csc.exe'
build=subprocess.run([compiler,'/nologo','/target:exe','/platform:x86',f'/out:{OUT/"WidthOracle.exe"}',str(OUT/'WidthOracle.cs')],capture_output=True)
(OUT/'build.txt').write_bytes(build.stdout+build.stderr);assert build.returncode==0
dll=Path('D:/GXWORKS2/Easysocket/CodeGenerator/ECCodeGenerator2.dll')
assert hashlib.sha256(dll.read_bytes()).hexdigest()=='2e5c47b0a0d0b59eb26dbab149862a05983a1fa9519a75e446bc680e7cc16f73'
seen={}
for folder in ['q-source-allocated-reconstruction','q-source-allocated-range-reconstruction','q-source-allocated-fragmented-reconstruction','q-source-allocated-real-multi-reconstruction']:
 for path in sorted((P/folder).glob('*/requests.json')):
  data=json.loads(path.read_text())
  for req in data['requests']:
   if req['raw'] not in seen:seen[req['raw']]=dict(raw=req['raw'],input_base64=req['input_base64'],origins=[])
   seen[req['raw']]['origins'].append(dict(path=str(path.relative_to(P)),index=req['index']))
requests=list(seen.values())
(OUT/'requests.json').write_text(json.dumps(requests,indent=2))
(OUT/'input.txt').write_text(''.join(f"check-instruction\t{i}\t{r['input_base64']}\n" for i,r in enumerate(requests)))
(OUT/'device-context.bin').write_bytes((P/'q-source-allocated-reconstruction/banks/device-context.bin').read_bytes())
args=[str((OUT/'WidthOracle.exe').resolve()),str(dll),'209','1','q','1',str((OUT/'device-context.bin').resolve()),str((OUT/'input.txt').resolve())]
normal=subprocess.run(args,capture_output=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
(OUT/'baseline-stdout.jsonl').write_bytes(normal.stdout);(OUT/'baseline-stderr.bin').write_bytes(normal.stderr)
assert normal.returncode==0
device=frida.get_local_device();output={1:bytearray(),2:bytearray()};ended=[]
pid=device.spawn(args,cwd=str(OUT.resolve()),stdio='pipe')
def receive(pid_,fd,data):
 if pid_==pid and fd in output:output[fd].extend(data)
device.on('output',receive)
try:
 session=device.attach(pid);session.on('detached',lambda *a:ended.append(str(a)))
 with (OUT/'events.jsonl').open('w') as log:
  agent=session.create_script((OUT/'Trace.js').read_text())
  def message(row,data):log.write(json.dumps(row)+'\n');log.flush()
  agent.on('message',message);agent.load();device.resume(pid)
  deadline=time.monotonic()+30
  while not ended and time.monotonic()<deadline:time.sleep(.1)
  if not ended:device.kill(pid)
finally:
 if not ended:
  try:device.kill(pid)
  except frida.ProcessNotFoundError:pass
(OUT/'trace-stdout.jsonl').write_bytes(output[1]);(OUT/'trace-stderr.bin').write_bytes(output[2])
events=[json.loads(l) for l in (OUT/'events.jsonl').read_text().splitlines()]
row=dict(pid=pid,detached=ended,stdout_equal=normal.stdout==output[1],baseline_returncode=normal.returncode,event_count=len(events))
(OUT/'comparison.json').write_text(json.dumps(row,indent=2));print(json.dumps(row))
