from pathlib import Path
import sys,json,re,base64
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'research'),str(ROOT/'src')]
from gxw.compiler_tables import parse_compiler_tables
from gxw.lossless import sha256
from probe_gxw_operand_bindings import split_operands
from probe_gxw_index_arithmetic import source_array_reference,decoded_index_arithmetic,affine,add
from probe_gxw_library_sources import snapshot_library_pous,observed_builtin_template
P=Path(__file__).resolve().parent/'array-operand-controls'
for case in (sys.argv[1:] or ['dynamic-layout','dynamic-index-shapes']):
 out=P/case;result=json.loads((out/'comparison.json').read_text());trace=out/result['trace_attempts'][-1]['directory']
 raw=(out/'captured-symbols.bin').read_bytes();tables=parse_compiler_tables(raw)
 generated=None;allocated=None;root_id=None
 for line in (trace/'events.jsonl').read_text().splitlines():
  e=json.loads(line).get('payload',{})
  if e.get('event')!='enter' or e.get('name')!='Compile':continue
  b={v['label']:v for v in e['buffers']}
  for k,v in b.items():
   if not k.startswith('name_') or not v.get('bytes'):continue
   name=bytes.fromhex(v['bytes']).split(b'\0')[0]
   if name==b'POU_01':
    assert raw==bytes.fromhex(b['symbolic_data']['bytes']);root_id=e['id'];generated=bytes.fromhex(b[k.replace('name_','source_')]['bytes']).decode()
   if root_id is not None and e['id']>root_id and name==b'Task_01':
    assert allocated is None;allocated=parse_compiler_tables(bytes.fromhex(b['symbolic_data']['bytes']))
 assert generated is not None and allocated is not None
 assert result['trace_pcode_equal']
 dump=(out/'native-table-reader/native-table-dump.txt').read_text(encoding='cp1252')
 positions={int(m[1]):int(m[2]) for m in re.finditer(r'^Index +(\d+) , Line +(-?\d+) , NW +(-?\d+) , POUIdx +(\d+)',dump,re.M)}
 originals={c['line']['line_index']:c for c in result['calls']}
 library=snapshot_library_pous(json.loads((out/'native/frontend-snapshot.json').read_text(encoding='utf-8-sig')))
 rows=[]
 for line in generated.splitlines():
  point=re.search(r' D([0-9]+)$',line)
  if not point or positions[int(point[1])] not in originals:continue
  source=originals[positions[int(point[1])]];body=line[:point.start()];function=re.fullmatch(r'F([0-9]+)\((.*)\)',body)
  targets=[]
  if function:
   definition=tables.pou_at(int(function[1]));ports=tables.components(definition);actual=split_operands(function[2])
   ordinal_map={i+1:a for (i,c),a in zip([(i,c) for i,c in enumerate(ports) if c.name_bytes!=b'ENO'],actual)}
   definitions=[p for p in library if p['library']=='@MELSEC' and p['name']==definition.name_bytes.decode()];assert len(definitions)==1
   template=observed_builtin_template(base64.b64decode(definitions[0]['program_raw_base64']))
   assert len(template['instructions'])==1
   instruction=template['instructions'][0];expected_opcode=instruction['opcode']
   for i,operand in enumerate(instruction['operands']):
    arg=ordinal_map[operand['placeholder_id']]
    if '[' in arg:targets.append((i,arg))
  else:
   assignment=re.fullmatch(r'(K[0-9]+(?:\[.*\])?) := (K[0-9]+\[.*\]);',body);assert assignment,body
   expected_opcode='$MOV'
   targets=[(0,assignment[2])]+([(1,assignment[1])] if '[' in assignment[1] else [])
  final=source['records'][-1];assert final['op']==expected_opcode
  arithmetic=decoded_index_arithmetic(source['records'][:-1]);references=[]
  for index,token in targets:
   expected=source_array_reference(token,tables,allocated)
   observed=final['args'][index];m=re.fullmatch(r'([DM])([0-9]+)(?:Z([0-9]+))?',observed)
   observed_expression=None if not m else affine() if m[3] is None else arithmetic['state'].get('Z'+m[3])
   base=expected['binding']['base']
   expected_address=add(affine(base['number']),expected['relative_device_units'])
   observed_address=add(affine(int(m[2])),observed_expression) if m and observed_expression is not None else None
   references.append(dict(expected=expected,observed_operand=observed,observed_relative_device_units=observed_expression,
                          base_equal=bool(m) and m[1]==base['family'] and int(m[2])==base['number'],
                          affine_equal=observed_expression==expected['relative_device_units'] and not arithmetic['gaps'],
                          expected_complete_address=expected_address,observed_complete_address=observed_address,
                          complete_address_equal=bool(m) and m[1]==base['family'] and observed_address==expected_address and not arithmetic['gaps']))
  rows.append(dict(source=source['line'],generated=line,arithmetic=arithmetic,references=references))
 comparison=dict(case=case,symbols_sha256=sha256(raw),allocated_symbols_sha256=sha256(allocated.raw),
                 rows=rows,summary=dict(statements=len(rows),references=sum(len(r['references']) for r in rows),
                 exact=sum(x['complete_address_equal'] for r in rows for x in r['references']),
                 arithmetic_gaps=sum(bool(r['arithmetic']['gaps']) for r in rows)))
 (out/'dynamic-index-comparison.json').write_text(json.dumps(comparison,indent=2))
 print(json.dumps(dict(case=case,**comparison['summary'])),flush=True)
