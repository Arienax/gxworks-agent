from pathlib import Path
import sys,json,zipfile,base64
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from replay_gxw_workspace import run
from native_gxw_tokens import native_batch,native_il_projection,DEFAULT_DLL
from gxw.lossless import inspect_project,sha256
from gxw.structured_pou import parse_structured_pou
P=Path(__file__).resolve().parent
out=P/'native-existing-set-rst';out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
rows=[]
with zipfile.ZipFile(ROOT/'research/evidence/gxw-abi-checkpoint-20260919.zip') as z:
 for name in ['frozen/base_spaced.gxw','frozen/set_direct.gxw','frozen/set_direct_compile.gxw','frozen/set_spaced.gxw','frozen/set_spaced_compile.gxw','pending/rst_direct_recovered.gxw']:
  d=out/Path(name).stem;d.mkdir();source=z.read(name);path=d/'source.gxw';path.write_bytes(source)
  result=run(path,d/'native',compile=True,export_project=True,project_alias='GRAPHORIGINAL')
  nodes=[]
  for s in inspect_project(source).streams:
   if s.logical_name and s.logical_name.endswith('.Program.pou'):
    p=parse_structured_pou(s.raw);nodes=[dict(kind=n.kind_code,symbol=n.symbol,ports=[v.port_kind_code for v in n.ports]) for n in p.nodes]
  row=dict(case=Path(name).stem,archive_member=name,source_sha256=sha256(source),nodes=nodes,result=result)
  if (d/'native/pcode-0-0.bin').exists():
   b=(d/'native/pcode-0-0.bin').read_bytes();a=native_batch([dict(mode='decode',input_base64=base64.b64encode(b+b'\0').decode())],d/'decode',dll=DEFAULT_DLL,cpu_code=0x208)[0]
   assert a['return_code']=='0x00000000' and a['consumed_bytes']==len(b)
   row['native_listing']=native_il_projection(base64.b64decode(a['output_base64']),encoding='gb18030')
  rows.append(row);(out/'comparison.json').write_text(json.dumps(rows,indent=2));print(json.dumps(dict(case=row['case'],completed=result['compile_completed'],rejected=result['compiler_rejected'],listing=row.get('native_listing'))),flush=True)
