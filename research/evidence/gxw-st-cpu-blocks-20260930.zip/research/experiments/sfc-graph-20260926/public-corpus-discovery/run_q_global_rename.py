import base64
from dataclasses import asdict
import json
from pathlib import Path
import struct
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(ROOT / 'research'))
sys.path.insert(0, str(ROOT / 'src'))
from gxw.lossless import inspect_project, sha256
from gxw.declarations import parse_declarations, edit_declarations, serialize_declarations
from probe_gxw_parameters import device_allocation_record
from probe_gxw_simple_fb import frame_source
from probe_gxw_sfc_graph import patch_raw
from native_gxw_tokens import native_batch, native_il_records, Q_DLL
from replay_gxw_workspace import run

P = Path(__file__).resolve().parent
OUT = P / 'q-global-rename-native'
OUT.mkdir(exist_ok=False)
source = (P / 'noeul-largest-ascii-alias/input.gxw').read_bytes()
streams = {s.logical_name: s.raw for s in inspect_project(source).streams if s.logical_name}
old, new = '가공', 'ProcessActive'
ctx = device_allocation_record(streams['Param.wpa']).raw
programs = {n: frame_source(raw) for n, raw in streams.items() if n.endswith('.Program.pou')}
declarations = {n: parse_declarations(raw, logical_name=n) for n, raw in streams.items()
                if n.endswith(('.Labels.lh', '.gh'))}
assert [n for n, d in declarations.items() if any(r.name == old for r in d.rows)] == ['Global1.gh']
assert not any(r.name == new for d in declarations.values() for r in d.rows)
assert all(not any(r.name.casefold() in (old.casefold(), new.casefold()) for r in d.rows)
           for n, d in declarations.items() if n != 'Global1.gh')

def native(requests, output, encode=False):
    kwargs = dict(dll=Q_DLL, cpu_code=209, native_versions=(25,))
    if encode:
        kwargs['device_context'] = ctx
    rows = native_batch(requests, OUT / output, **kwargs)
    assert all(r['return_code'] == '0x00000000' for r in rows)
    return rows

def encode_request(record):
    assert record['kind'] == 'instruction'
    text = ' '.join([record['op']] + record['args'])
    return dict(mode='encode', record=record,
                input_base64=base64.b64encode(text.encode('cp949') + b'\0\0').decode())

decoded = native([dict(mode='decode', program=n, input_base64=base64.b64encode(p.body + b'\0').decode())
                  for n, p in programs.items()], 'before-native-decode')
records = {}
all_records = []
for (name, program), row in zip(programs.items(), decoded):
    assert row['consumed_bytes'] == len(program.body)
    records[name] = native_il_records(base64.b64decode(row['output_base64']), encoding='cp949')
    all_records.extend(records[name])
encoded = native([encode_request(r) for r in all_records], 'instruction-native-encode', True)
encoded_bytes = iter(base64.b64decode(row['output_base64']) for row in encoded)
alignment = []
modified_records = []
for name, program in programs.items():
    offset = program.body_offset
    for index, record in enumerate(records[name]):
        raw = next(encoded_bytes)
        assert program.raw[offset:offset + len(raw)] == raw
        alignment.append(dict(program=name, record=index, offset=offset, length=len(raw),
                              sha256=sha256(raw), native=record))
        if "'" + old in record['args']:
            changed = dict(record, args=["'" + new if a == "'" + old else a for a in record['args']])
            modified_records.append(dict(alignment_index=len(alignment)-1, record=changed))
        offset += len(raw)
    assert offset == program.body_end
assert len(modified_records) == 14
changed_native = native([encode_request(r['record']) for r in modified_records], 'replacement-native-encode', True)
replacements = {}
for item, row in zip(modified_records, changed_native):
    a = alignment[item['alignment_index']]
    replacements[(a['program'], a['record'])] = base64.b64decode(row['output_base64'])

new_global = serialize_declarations(edit_declarations(declarations['Global1.gh'], renames={old: new}))
declared, declaration_mutation = patch_raw(source, 'Global1.gh', streams['Global1.gh'], new_global)
(OUT / 'declaration-only.gxw').write_bytes(declared)
patched = declared
changes = []
for name, program in programs.items():
    body = b''.join(replacements.get((name, a['record']), program.raw[a['offset']:a['offset'] + a['length']])
                    for a in alignment if a['program'] == name)
    header = bytearray(program.raw[:program.body_offset])
    struct.pack_into('<II', header, 55, len(body)+20, len(body)+20)
    raw = bytes(header) + body + program.raw[program.body_end:]
    observed = frame_source(raw)
    assert len(observed.tokens) == len(program.tokens)
    targets = 0
    for before, after in zip(program.tokens, observed.tokens):
        if before.raw[1] == 0xdf and before.raw[2:-1] == old.encode('cp949'):
            assert after.raw[1] == 0xdf and after.raw[2:-1] == new.encode('cp949')
            targets += 1
        else:
            assert before.raw == after.raw
    assert targets > 0
    patched, evidence = patch_raw(patched, name, program.raw, raw)
    changes.append(dict(program=name, targets=targets, before_sha256=sha256(program.raw),
                        after_sha256=sha256(raw), opaque_tokens='byte-identical', **evidence))
(OUT / 'renamed.gxw').write_bytes(patched)
after_streams = {s.logical_name: s.raw for s in inspect_project(patched).streams if s.logical_name}
after_decoded = native([dict(mode='decode', program=n,
    input_base64=base64.b64encode(frame_source(after_streams[n]).body+b'\0').decode()) for n in programs], 'after-native-decode')
for name, row in zip(programs, after_decoded):
    expected = [dict(r, args=["'"+new if a=="'"+old else a for a in r['args']]) for r in records[name]]
    assert native_il_records(base64.b64decode(row['output_base64']), encoding='cp949') == expected
    assert row['consumed_bytes'] == len(frame_source(after_streams[name]).body)

evidence = dict(original_sha256=sha256(source), modified_sha256=sha256(patched),
                rename={old:new}, declaration_mutation=declaration_mutation, programs=changes,
                instructions_aligned=len(alignment), alignment=alignment,
                device_context_sha256=sha256(ctx), text_encoding='cp949',
                unmodified_logical_streams='byte-identical', complete_dependency_proof=False)
assert all(raw == after_streams[name] for name, raw in streams.items()
           if name not in programs and name != 'Global1.gh')
(OUT / 'mutation.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for case in ('declaration-only','renamed'):
    outcome = run(OUT / (case+'.gxw'), OUT / (case+'-native'), compile=True,
                  export_project=True, snapshot_frontend=True, project_alias='NATIVE01')
    print(case, json.dumps(dict(open=outcome['open_succeeded'], compiled=outcome['compile_completed'],
        rejected=outcome['compiler_rejected'], diagnostics=outcome['diagnostics']),ensure_ascii=True), flush=True)
    if case == 'renamed':
        assert outcome['compile_completed'] and not outcome['compiler_rejected']
        baseline = P/'noeul-largest-ascii-alias'
        checks = [dict(name=f.name, byte_identical=f.read_bytes()==(baseline/f.name).read_bytes())
                  for f in (OUT/(case+'-native')).glob('pcode-*.bin')]
        assert checks and all(r['byte_identical'] for r in checks)
        (OUT/'compiled-comparison.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8')
        print('Compiled resources byte-identical:', len(checks), flush=True)
