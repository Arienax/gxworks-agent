"""Research-only padding normalization before existing product declaration edits."""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from gxw.container import CompoundFile
from gxw.container_writer import replace_project_stream,validate_cfb_streams
from gxw.declarations import parse_declarations,edit_declarations
from gxw.project_writer import build_gxw_project,binary_diff
from replay_gxw_workspace import run
P=Path(__file__).resolve().parent
out=P/'partial-sector-label-edits';out.mkdir(exist_ok=False)
base=P/'scpi-label-inputs/global-constant/native'
source=(base/'native-saved.gxw').read_bytes();outer=CompoundFile(source);nested=outer.read_stream('_hdb')
cfb=CompoundFile(nested);padding=(-len(nested))%cfb.sector_size
assert padding==401
original={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
assert all(v is not None for v in original.values())
padded_nested=nested+bytes(padding)
assert validate_cfb_streams(padded_nested)=={e.name:cfb.read_entry(e) for e in cfb.iter_streams()}
normalized,normalization_report=replace_project_stream(source,'_hdb',padded_nested)
assert {s.logical_name:s.raw for s in inspect_project(normalized).streams if s.logical_name}==original
plans=[dict(case='padding-only'),dict(case='constant-value',initial_value='124'),dict(case='comment-growth',comment='Q'*3000)]
for plan in plans:
 directory=out/plan['case'];directory.mkdir()
 if plan['case']=='padding-only':changed=normalized;edit_report=None
 else:
  name='Global1.gh';doc=parse_declarations(original[name],logical_name=name)
  edited=edit_declarations(doc,upserts=[dict(name='InputValue',**{k:v for k,v in plan.items() if k!='case'})])
  result=build_gxw_project(normalized,declarations={name:edited});changed=result.data;edit_report=result.report
 after=inspect_project(changed);assert not after.diagnostics and not any(s.error for s in after.streams)
 payloads={s.logical_name:s.raw for s in after.streams if s.logical_name}
 touched=[name for name in original if original[name]!=payloads[name]]
 assert touched==([] if plan['case']=='padding-only' else ['Global1.gh'])
 path=directory/'changed.gxw';path.write_bytes(changed)
 receipt=dict(case=plan['case'],source_sha256=sha256(source),normalized_sha256=sha256(normalized),changed_sha256=sha256(changed),
              missing_padding_bytes=padding,normalization_diff=binary_diff(source,normalized),normalization_report=normalization_report,
              touched_logical_streams=touched,unrelated_logical_streams='byte-identical',edit_report=edit_report)
 (directory/'mutation.json').write_text(json.dumps(receipt,indent=2))
 for attempt in range(1,9):
  target=directory/('native' if attempt==1 else 'native-v'+str(attempt))
  native=run(path,target,compile=True,export_project=True,project_alias='PARTIALTAIL')
  events=[json.loads(s) for s in (target/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
  if (target/'pcode-0-0.bin').exists() or not any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):break
 row=dict(case=plan['case'],native_directory=str(target.relative_to(P)),native={k:native[k] for k in ['returncode','open_succeeded','compile_completed','compiler_rejected','diagnostics','outputs']})
 row['native_pcode_equal_to_baseline']={f.name:f.read_bytes() for f in target.glob('pcode-*.bin')}=={f.name:f.read_bytes() for f in base.glob('pcode-*.bin')}
 if (target/'native-saved.gxw').exists():
  saved=inspect_project((target/'native-saved.gxw').read_bytes());row['native_export_errors']=[dict(name=s.logical_name,error=s.error) for s in saved.streams if s.error]
  stream=next(s.raw for s in saved.streams if s.logical_name=='Global1.gh');decl=parse_declarations(stream,logical_name='Global1.gh').rows[0]
  row['exported_label']=dict(name=decl.name,initial_value=decl.initial_value,comment_length=len(decl.comment))
 (directory/'comparison.json').write_text(json.dumps(row,indent=2))
 print(json.dumps(dict(case=plan['case'],pcode_equal=row['native_pcode_equal_to_baseline'],native={k:row['native'][k] for k in ['returncode','open_succeeded','compile_completed','compiler_rejected','diagnostics']},exported_label=row.get('exported_label'))),flush=True)
