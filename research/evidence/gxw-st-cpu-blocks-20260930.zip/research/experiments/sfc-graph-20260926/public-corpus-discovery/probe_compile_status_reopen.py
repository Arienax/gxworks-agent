"""Read native persisted compile status and isolate paired payload status words."""
from pathlib import Path
import json,os,struct,subprocess,sys
ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from gxw.lossless import inspect_project,sha256
from probe_gxw_sfc_graph import patch_raw
from replay_gxw_workspace import prepare
P=Path(__file__).resolve().parent
out=P/'q-compile-status-reopen';out.mkdir(exist_ok=False)
(out/'probe.py').write_bytes(Path(__file__).read_bytes())
base=P/'q-native-compile-invalidation';source=(base/'control/native-saved.gxw').read_bytes()
streams={s.logical_name:s.raw for s in inspect_project(source).streams if s.logical_name}
plans=[('native-'+case,base/case/'native-saved.gxw') for case in ['control','fb-dirty','caller-dirty','global-dirty']]
for case,changes in [('source-only',{'SCPI.Program.pou':1}),('labels-only',{'SCPI.Labels.lh':1}),
        ('both',{'SCPI.Program.pou':1,'SCPI.Labels.lh':1}),('global-only',{'Global1.gh':1}),
        ('source-and-labels-different',{'SCPI.Program.pou':1,'SCPI.Labels.lh':2})]:
    changed=source;receipts=[];replacements={}
    for logical,value in changes.items():
        raw=streams[logical];assert len(raw)>=54 and struct.unpack_from('<I',raw,50)[0]==0
        assert raw[:34]==bytes.fromhex('01000000000001000000000001000a00000000000200000001000000010000000000')
        new=raw[:50]+struct.pack('<I',value)+raw[54:]
        changed,receipt=patch_raw(changed,logical,raw,new);receipts.append(receipt);replacements[logical]=new
    assert {s.logical_name:s.raw for s in inspect_project(changed).streams if s.logical_name}==dict(streams,**replacements)
    path=out/(case+'.gxw');path.write_bytes(changed)
    (out/(case+'-mutation.json')).write_text(json.dumps(dict(source_sha256=sha256(source),changed_sha256=sha256(changed),changes=changes,receipts=receipts,unrelated_payloads='byte-identical'),indent=2))
    plans.append((case,path))
rows=[]
for case,path in plans:
    target=out/case;exe=prepare(path,target,compile=False,project_alias='QSTATUSREAD')
    helper=(target/'WorkspaceReplayOracle.cs').read_text();marker='            if(!Convert.ToBoolean(plan["compile"]))return;'
    assert helper.count(marker)==1
    helper=helper.replace(marker,'            CompileStatusSnapshot(workspace,id,"reopened");\n'+marker)
    (target/'WorkspaceReplayOracle.cs').write_text(helper)
    (target/'NativeCompileStatusSnapshotV2.cs').write_bytes((P/'NativeCompileStatusSnapshotV2.cs').read_bytes())
    csc=Path(os.environ['WINDIR'])/'Microsoft.NET/Framework/v4.0.30319/csc.exe'
    build=subprocess.run([str(csc),'/nologo','/platform:x86','/r:System.Web.Extensions.dll','/r:System.Windows.Forms.dll','/out:'+str(exe),
        *[str(target/n) for n in ['WorkspaceReplayOracle.cs','NativeFrontendSnapshot.cs','NativeSfcGraphOracle.cs','NativeWorkspaceCopyOracle.cs','NativeCompileStatusSnapshotV2.cs']]],
        capture_output=True,timeout=20,creationflags=subprocess.CREATE_NO_WINDOW)
    (target/'status-build.stdout.bin').write_bytes(build.stdout);(target/'status-build.stderr.bin').write_bytes(build.stderr);build.check_returncode()
    request=json.loads((target/'request.json').read_text());request.update(actual_helper_sha256=sha256((target/'WorkspaceReplayOracle.cs').read_bytes()),status_snapshot_sha256=sha256((target/'NativeCompileStatusSnapshotV2.cs').read_bytes()))
    (target/'request.json').write_text(json.dumps(request,indent=2))
    process=subprocess.run([str(exe),str(target/'plan.json')],cwd=target,capture_output=True,timeout=40,creationflags=subprocess.CREATE_NO_WINDOW)
    (target/'process.stdout.bin').write_bytes(process.stdout);(target/'process.stderr.bin').write_bytes(process.stderr)
    events=[json.loads(s) for s in (target/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    statuses=[e for e in events if e['operation'] in ('CompileStatusSnapshotNode','CompileAllAfterSnapshot','LabelModeSnapshot')]
    row=dict(case=case,input_sha256=sha256(path.read_bytes()),returncode=process.returncode,statuses=statuses,last_event=events[-1])
    rows.append(row);(target/'comparison.json').write_text(json.dumps(row,indent=2))
    print(json.dumps(dict(case=case,returncode=process.returncode,statuses=[{k:e[k] for k in ['operation','path','name','status','value','code'] if k in e} for e in statuses])),flush=True)
(out/'comparison.json').write_text(json.dumps(dict(cases=rows),indent=2))
