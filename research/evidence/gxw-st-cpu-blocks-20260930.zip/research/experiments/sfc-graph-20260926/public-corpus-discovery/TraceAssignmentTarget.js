Process.attachModuleObserver({onAdded(m) {
  if(m.name.toLowerCase() === 'dzdataabs_compiler_iec.dll') {
    Interceptor.attach(m.base.add(0x77e7), {onEnter(args) {
      const table=args[0].add(0x28).readPointer().readPointer();
      for(const slot of [56,60]) {
        const target=table.add(slot).readPointer(), module=Process.findModuleByAddress(target);
        send({event:'assignment_data_target',slot,module:module.name,rva:target.sub(module.base).toString()});
      }
    }});
  }
  if(m.name.toLowerCase() !== 'dzdataabs_compileradapter.dll') return;
  for (const [name, rva, slot] of [['assignment',0x50f4,60],['binary',0x52be,64]]) {
    Interceptor.attach(m.base.add(rva), {onEnter() {
      const table=this.context.ecx.add(0x14).readPointer().readPointer();
      const target=table.add(slot).readPointer();
      const module=Process.findModuleByAddress(target);
      send({event:'assignment_target',name,target:target.toString(),table:table.toString(),
            module:module.name,rva:target.sub(module.base).toString()});
    }});
  }
}});
