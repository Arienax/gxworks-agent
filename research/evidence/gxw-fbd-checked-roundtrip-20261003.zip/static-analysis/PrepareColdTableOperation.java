import ghidra.app.script.GhidraScript;
import ghidra.app.cmd.disassemble.DisassembleCommand;
import ghidra.program.model.data.LongDataType;
import ghidra.program.model.symbol.SourceType;

public class PrepareColdTableOperation extends GhidraScript {
    @Override public void run() throws Exception {
        if (!currentProgram.getImageBase().toString().equals("66720000"))
            throw new IllegalStateException("Expected observed DataManager_IEC");
        String[] entries = getScriptArgs();
        if (entries.length == 0) entries = new String[]{"6679aa80","66737bfd","6676b297","66736acd","6675eb10","6675eb38","6676505f","6675798d"};
        for (String value:entries) {
            var entry=toAddr(value);
            new DisassembleCommand(entry,null,true).applyTo(currentProgram,monitor);
            var fn=getFunctionAt(entry);
            if (fn==null) fn=createFunction(entry,"OwnedColdTable_"+value);
            if (value.equals("6679aa80")) fn.setCallFixup("EH_prolog");
            // The original exported C++ signature is UAEJ (signed long return).
            if (value.equals("66737bfd")) fn.setReturnType(LongDataType.dataType,SourceType.USER_DEFINED);
            println("entry="+entry+" name="+fn.getName());
        }
    }
}
