import ghidra.app.script.GhidraScript;
import ghidra.app.cmd.disassemble.DisassembleCommand;

public class PrepareCompilerBuild extends GhidraScript {
    @Override public void run() throws Exception {
        if (!currentProgram.getImageBase().toString().equals("666f0000"))
            throw new IllegalStateException("Expected observed Compiler_IEC");
        String[] entries = getScriptArgs();
        if (entries.length == 0) entries = new String[]{"666f6daf", "666f6ae6", "666f6d24"};
        for (String value : entries) {
            var entry = toAddr(value);
            new DisassembleCommand(entry, null, true).applyTo(currentProgram, monitor);
            var fn = getFunctionAt(entry);
            if (fn == null) fn = createFunction(entry, "OwnedBuildPreparation_" + value);
            println("entry=" + entry + " name=" + fn.getName());
        }
    }
}
