import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.listing.Function;

public class InspectIecSourceCheck extends GhidraScript {
    @Override
    public void run() throws Exception {
        Address helperEntry = toAddr("668a8660");
        disassemble(helperEntry);
        Function helper = getFunctionAt(helperEntry);
        if (helper == null) helper = createFunction(helperEntry, "OwnedIec_EH_prolog");
        if (helper == null) throw new IllegalStateException("No verified EH helper");
        helper.setCallFixup("EH_prolog");
        for (String value : getScriptArgs()) {
            Address entry = toAddr(value);
            disassemble(entry);
            Function function = getFunctionAt(entry);
            if (function == null) function = createFunction(entry, "OwnedIec_" + value);
            if (function == null) throw new IllegalStateException("No method at " + value);
            println("entry=" + entry + " function=" + function.getName());
        }
    }
}
