import ghidra.app.script.GhidraScript;
import ghidra.app.cmd.disassemble.DisassembleCommand;

public class PrepareAdapterBuild extends GhidraScript {
    @Override public void run() throws Exception {
        if (!currentProgram.getImageBase().toString().equals("60cd0000"))
            throw new IllegalStateException("Expected observed CompilerAdapter");
        String[] entries = getScriptArgs();
        if (entries.length == 0) entries = new String[]{"60ce3cc0", "60ce4704", "60ce49dc", "60cd8655", "60cd184e"};
        for (String value : entries) {
            var entry = toAddr(value);
            new DisassembleCommand(entry, null, true).applyTo(currentProgram, monitor);
            var fn = getFunctionAt(entry);
            if (fn == null) fn = createFunction(entry, "OwnedBuildPreparation_" + value);
            println("entry=" + entry + " name=" + fn.getName());
        }
    }
}
