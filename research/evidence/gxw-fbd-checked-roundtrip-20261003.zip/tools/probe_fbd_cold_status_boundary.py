"""Complete the four-flag cold-reopen domain and locate the native error path."""
from pathlib import Path
import json
import sys

P=Path(__file__).resolve().parent
sys.path.insert(0,str(P))
import probe_fbd_cold_source_status as status

SOURCES=['FBD_MATRIX.Labels.lh','FBD_MATRIX.Program.pou','MODULE_FB.Labels.lh','MODULE_FB.Program.pou']
status.OUT=P/'fbd-cold-source-status-20261003-v5'
# Eight combinations have independent retained oracles from the preceding
# single-factor controls. Complete only the missing half of the finite domain.
status.CASES=[(f'pending-mask-{mask:02d}',[name for bit,name in enumerate(SOURCES) if mask&(1<<bit)])
              for mask in [6,7,8,9,11,12,13,14]]
status.EXTRA_OBSERVER=r'''
const ownedColdErrorModules=new Set();
const ownedColdTableTargets=new Set();
const ownedColdDeclarationTargets=new Set();
const ownedColdInsertScopes=new Map();
const ownedColdInnerTargets=new Set();
function ownedAttachColdSourceErrors(m){
 if(!m||m.name.toLowerCase()!=='dzdataabs_sicconverter_iec.dll'||ownedColdErrorModules.has(m.base.toString()))return;
 ownedColdErrorModules.add(m.base.toString());
 const sites=[[0x82a52,1],[0x85cee,1],[0x8b135,1],[0x8b147,3],[0x8d919,1],
              [0x8f9ea,1],[0x8fa01,3],[0x9144c,3],[0x92428,1]];
 for(const [rva,back] of sites){
  const data=m.base.add(rva),address=data.sub(back);
  if(data.readU32()!==0x5003000b){send({event:'observation-error',phase:'cold-error-site',rva});continue;}
  const instruction=Instruction.parse(address);
  if(instruction.next.compare(data.add(4))!==0){send({event:'observation-error',phase:'cold-error-instruction',rva});continue;}
  send({event:'owned-cold-source-error-hook',site:loc(address)});
  Interceptor.attach(address,{onEnter(){try{
   send({event:'owned-cold-source-error-site',site:loc(address),instruction:instruction.toString(),
    frame_return:loc(this.context.ebp.add(4).readPointer()),
    trace:Thread.backtrace(this.context,Backtracer.ACCURATE).slice(0,12).map(loc)});
  }catch(e){send({event:'observation-error',phase:'cold-error-path',error:String(e)});}}});
 }
 if(hex(m.base.add(0x8b0ec),3)!=='ff5378')throw new Error('Observed cold-source table call differs');
 Interceptor.attach(m.base.add(0x8ae58),{onEnter(){try{
  const worker=this.context.ecx,workerVtable=worker.readPointer(),declaration=workerVtable.add(0x84).readPointer();
  if(!ownedColdDeclarationTargets.has(declaration.toString())){
   ownedColdDeclarationTargets.add(declaration.toString());
   send({event:'owned-cold-declaration-hook',target:loc(declaration),worker_vtable:loc(workerVtable)});
   Interceptor.attach(declaration,{
    onEnter(){this.owned=this.returnAddress.equals(m.base.add(0x8b055));if(this.owned)this.owner=this.context.ecx;},
    onLeave(r){if(this.owned)send({event:'owned-cold-declaration-return',target:loc(declaration),
     original_result:r.toInt32(),record_root_at_110:this.owner.add(0x110).readPointer().toString()});}
   });
  }
  const owner=worker.add(0xc).readPointer(),vtable=owner.readPointer(),target=vtable.add(0x78).readPointer();
  const dataModule=Process.findModuleByAddress(target);
  for(const rva of [0x4b297,0x49eac,0x4505f,0x49fd4,0x49348,0x16acd,0x15465,0x47dd3]){
   const inner=dataModule.base.add(rva);
   if(ownedColdInnerTargets.has(inner.toString()))continue;
   ownedColdInnerTargets.add(inner.toString());
   Interceptor.attach(inner,{
    onEnter(a){this.ownerName=ownedColdInsertScopes.get(this.threadId);if(this.ownerName===undefined)return;
     this.callsite=loc(this.returnAddress);this.argument0=a[0].toString();
     this.mergeName=rva===0x16acd?a[0].readCString():null;this.argument1=a[1].toInt32();},
    onLeave(r){if(this.ownerName!==undefined)send({event:'owned-cold-insert-inner-return',
     owner_name:this.ownerName,target:loc(inner),caller:this.callsite,argument0:this.argument0,
     merge_name:this.mergeName,argument1:this.argument1,original_result:r.toInt32()});}
   });
  }
  for(const slot of [0xec,0xe0,0x158,0x11c]){
   const lookup=vtable.add(slot).readPointer();
   if(ownedColdInnerTargets.has(lookup.toString()))continue;
   ownedColdInnerTargets.add(lookup.toString());
   Interceptor.attach(lookup,{
    onEnter(a){this.ownerName=ownedColdInsertScopes.get(this.threadId);if(this.ownerName===undefined)return;
     this.callsite=loc(this.returnAddress);this.selectedName=slot===0x158?a[0].readCString():null;
     this.arguments=[a[0].toString(),a[1].toString(),a[2].toString()];},
    onLeave(r){if(this.ownerName!==undefined)send({event:'owned-cold-component-lookup-return',
     owner_name:this.ownerName,slot,target:loc(lookup),caller:this.callsite,name:this.selectedName,
     arguments:this.arguments,original_result:r.toInt32()});}
   });
  }
  if(ownedColdTableTargets.has(target.toString()))return;
  ownedColdTableTargets.add(target.toString());
  send({event:'owned-cold-table-hook',target:loc(target),vtable:loc(vtable)});
  Interceptor.attach(target,{
   onEnter(a){this.owned=this.returnAddress.equals(m.base.add(0x8b0ef));if(!this.owned)return;try{
    this.name=a[0].readCString();this.previous=ownedColdInsertScopes.get(this.threadId);
    ownedColdInsertScopes.set(this.threadId,this.name);send({event:'owned-cold-table-call',target:loc(target),
     owner:this.context.ecx.toString(),name:this.name,record_hex:hex(a[1],24),argument_2:a[2].toUInt32(),
     second_header_pointer:a[1].add(4).readPointer().toString(),
     second_header_first_pointer:a[1].add(4).readPointer().readPointer().toString()});
   }catch(e){send({event:'observation-error',phase:'cold-table-call',error:String(e)});}},
   onLeave(r){if(this.owned){send({event:'owned-cold-table-return',target:loc(target),name:this.name,original_result:r.toInt32()});
    if(this.previous===undefined)ownedColdInsertScopes.delete(this.threadId);else ownedColdInsertScopes.set(this.threadId,this.previous);}}
  });
 }catch(e){send({event:'observation-error',phase:'cold-table-bind',error:String(e)});}}});
}
Process.attachModuleObserver({onAdded(m){
 ownedAttachColdSourceErrors(m);
 if(m.name.toLowerCase()==='dzdataabs_compiler_iec.dll')Interceptor.attach(m.base.add(0x6f2c),{
  onEnter(){ownedAttachColdSourceErrors(Process.findModuleByAddress(m.base.add(0x10120).readPointer()));}
 });
}});
'''

if __name__=='__main__':
    status.main()
    (status.OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
