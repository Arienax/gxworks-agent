"""Finish owned native target checks while retaining every projection failure.

The only changed behavior is the owned caller's polling and target enumeration.
No vendor return, project source/name, check mask, or diagnostic is replaced.
Public diagnostic conversion remains failed even after later native progress.
"""
from pathlib import Path
import json
import os
import shutil
import sys

P = Path(__file__).resolve().parent
ROOT = P.parents[3]
sys.path[:0] = [str(P), str(ROOT / 'src'), str(ROOT / 'research')]
import probe_application_check_resources as trace
from probe_diagnostic_callsite_module import link_witness
from program_check_evidence import analyze_directory

OUT = P / 'native-check-drain-20261002-v3'
GATE = 'GXW_OWNED_DIAGNOSTIC_DRAIN_READY'
SOURCE = 'NativeDiagnosticLocationQueries.cs'
OBSERVER = r'''
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='kernelbase.dll')return;
 const target=m.findExportByName('OutputDebugStringW');
 if(!target)throw new Error('Owned drain gate export unavailable');
 Interceptor.attach(target,{onEnter(a){
  if(a[0].isNull())return;
  if(a[0].readUtf16String(32)==='GXW_OWNED_DIAGNOSTIC_DRAIN_READY')
   send({event:'owned-diagnostic-drain-ready'});
 }});
}});
'''


def adapt_helper(path):
    text = path.read_text(encoding='utf-8')
    # Keep the character classification check; this owned trial does not retain
    # the older, unrelated CRT digest record.
    start = text.index('        string digest;')
    end = text.index('        var mismatches=', start)
    text = text[:start] + text[end:]
    text = text.replace('sha256=digest,', '')
    anchor = '    static List<IntPtr> strings=new List<IntPtr>();'
    if text.count(anchor) != 1:
        raise ValueError('Owned helper string storage differs')
    text = text.replace(anchor, anchor + '''
    static int programCheckProjectionFailures=0;
    static ObjectId currentProgramCheckTarget;
    [DllImport("kernel32",EntryPoint="OutputDebugStringW",CharSet=CharSet.Unicode)]
    static extern void OwnedDrainGate(string text);
''')
    anchor = 'var watch=Stopwatch.StartNew();int last=-1;bool rejected=false;'
    if text.count(anchor) != 1:
        raise ValueError('Owned wait state differs')
    text = text.replace(anchor, anchor + 'bool projectionFailed=false;int poll=0;')
    anchor = '            if(hr<0||code!=0)Check(operation+".GetProgress",hr,code);'
    if text.count(anchor) != 1:
        raise ValueError('Owned native failure site differs')
    text = text.replace(anchor, '''            poll++;
            if((hr<0||code!=0)&&operation=="ProgramCheckProgress"&&
               hr==unchecked((int)0x80004005)&&code==0x2d010025) {
                Record(new {operation=operation+".GetProgress",hresult=hr,code=code,
                    code_hex="0x"+code.ToString("x8"),percent=percent,count=count,poll=poll,
                    target=currentProgramCheckTarget.words,
                    public_check_status="incomplete",diagnostic_projection="failed"});
                projectionFailed=true;programCheckProjectionFailures++;
                if(percent==100) {
                    Record(new {operation="NativeProgramCheckTargetFinished",target=currentProgramCheckTarget.words,
                        native_progress=percent,polls=poll,public_diagnostic_projection="failed",
                        public_check_promoted=false});
                    return true;
                }
                last=percent;Thread.Sleep(10);continue;
            }
''' + anchor)
    anchor = '            if(percent==100) {\n                if(sfcConversion)'
    if text.count(anchor) != 1:
        raise ValueError('Owned completion site differs')
    text = text.replace(anchor, '''            if(percent==100) {
                if(operation=="ProgramCheckProgress")Record(new {
                    operation="NativeProgramCheckTargetFinished",target=currentProgramCheckTarget.words,
                    native_progress=percent,polls=poll,
                    public_diagnostic_projection=projectionFailed?"failed":"completed",
                    public_check_promoted=false});
                if(sfcConversion)''')
    anchor = '                return rejected;\n            }\n            Thread.Sleep(10);'
    if text.count(anchor) != 1:
        raise ValueError('Owned wait return differs')
    text = text.replace(anchor, '                return rejected||projectionFailed;\n            }\n            Thread.Sleep(10);')
    anchor = '                    Record(new {operation="ProgramCheckTarget",id=target.words});'
    if text.count(anchor) != 1:
        raise ValueError('Owned target site differs')
    text = text.replace(anchor, '                    currentProgramCheckTarget=target;\n' + anchor)
    anchor = '                Record(new {operation="ProgramCheckCompleted",targets=targets.Count,rejected=compilerRejected});'
    if text.count(anchor) != 1:
        raise ValueError('Owned public completion site differs')
    text = text.replace(anchor, '''                Record(new {operation="NativeProgramCheckEnumerationFinished",targets=targets.Count,
                    public_projection_failures=programCheckProjectionFailures,
                    public_check_status=programCheckProjectionFailures>0?"incomplete":"completed"});
                if(programCheckProjectionFailures==0) {
                    Record(new {operation="ProgramCheckCompleted",targets=targets.Count,rejected=compilerRejected});
                } else {
                    OwnedDrainGate("GXW_OWNED_DIAGNOSTIC_DRAIN_READY");
                    QueryLocationsAfterNativeFailure(compiler);
                    Environment.ExitCode=2;
                }''')
    if 'SHA256' in text or 'CheckProjectHash' in text:
        raise ValueError('Owned helper still contains digest work')
    path.write_text(text, encoding='utf-8')


def run(directory, frozen, raw, *, snapshot=False):
    script = trace.prepare(directory, frozen) + OBSERVER
    (directory / 'observer.js').write_text(script, encoding='utf-8')
    (directory / 'input.gxw').write_bytes(raw)
    shutil.copyfile(P / SOURCE, directory / SOURCE)
    query_source = directory / SOURCE
    query_text = query_source.read_text(encoding='utf-8')
    query_text = query_text.replace('File.Exists(input)', 'File.Exists(input+".ready")')
    query_text = query_text.replace('File.ReadAllText(input)', 'ReadOwnedDrainInput(input)')
    query_text = query_text.replace('    static void QueryLocationsAfterNativeFailure', '''    static string ReadOwnedDrainInput(string input) {
        for(int attempt=0;attempt<100;attempt++) {
            try {
                using(var stream=new FileStream(input,FileMode.Open,FileAccess.Read,
                    FileShare.ReadWrite|FileShare.Delete))
                using(var reader=new StreamReader(stream))return reader.ReadToEnd();
            } catch(IOException) {
                if(attempt==99)throw;
                Thread.Sleep(10);
            }
        }
        throw new IOException("Owned diagnostic query handoff failed");
    }
    static void QueryLocationsAfterNativeFailure''')
    query_source.write_text(query_text, encoding='utf-8')
    adapt_helper(directory / 'WorkspaceReplayOracle.cs')
    plan = json.loads((directory / 'plan.json').read_text())
    plan.update(export_project=False, snapshot_compiler_cache=snapshot,
        analysis_version=3, analysis_queries=[
        dict(name='all-references', keys=[], symbol='', scope='', declared=0, plural=0)])
    trace.save(directory / 'plan.json', plan)
    original_errors = []
    gate_seen = False

    def message(value, data):
        nonlocal gate_seen
        row = value.get('payload', {})
        if row.get('event') == 'backend-check-progress':
            original_errors.extend(dict(report, check_index=row['check_index'])
                for report in row.get('reports', []) if report.get('kind') in (2, 3))
        if row.get('event') != 'owned-diagnostic-drain-ready' or gate_seen:
            return
        gate_seen = True
        queries = []
        seen = set()
        for report in original_errors:
            if report['instance_kind'] != 6 or report['program_kind'] != 1 or report['step'] < 0:
                continue
            resource = bytes.fromhex(report['instance_hex']).decode('cp949')
            key = (resource, report['step'])
            if key in seen:
                continue
            seen.add(key)
            queries.append(dict(resource=resource, start_step=report['step'],
                original_code=report['code'], original_kind=report['kind']))
        temp = directory / 'diagnostic-query-input.tmp'
        trace.save(temp, dict(queries=queries, source='original native batches after all targets',
            public_check_status='incomplete'))
        os.replace(temp, directory / 'diagnostic-query-input.json')
        (directory / 'diagnostic-query-input.json.ready').write_text('closed-input', encoding='utf-8')

    previous = trace.CS
    trace.CS = previous + (SOURCE,)
    try:
        returncode, messages = trace.run(directory, script, on_message=message)
    finally:
        trace.CS = previous
    result = trace.summarize(directory, returncode, messages)
    events = [json.loads(line) for line in (directory / 'native-events.jsonl').read_text(
        encoding='utf-8-sig').splitlines()]
    result.update(original_native_diagnostics=original_errors, query_gate_seen=gate_seen,
        native_target_results=[e for e in events if e.get('operation')=='NativeProgramCheckTargetFinished'],
        enumeration=[e for e in events if e.get('operation')=='NativeProgramCheckEnumerationFinished'],
        phases=analyze_directory(directory))
    result['link_witness'] = link_witness(directory)
    for name, field in [('diagnostic-pcode-locations.json', 'diagnostic_locations'),
                        ('native-program-analysis.json', 'source_references')]:
        file = directory / name
        result[field] = json.loads(file.read_text(encoding='utf-8-sig')) if file.exists() else None
    trace.save(directory / 'result-with-drain.json', result)
    return result


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    OUT.mkdir(exist_ok=False)
    shutil.copyfile(Path(__file__), OUT / Path(__file__).name)
    earlier = json.loads((P / 'diag-cpu-20261002-v1/results.json').read_text())
    applications = json.loads((trace.A / 'native-results.json').read_text())
    positive = trace.A / 'full-FX3U-FX3UC/native-compile'
    cases = [('FX3U/FX3UC-positive', positive, positive)]
    for cpu in ['FX3U/FX3UC', 'Q06PH', 'L02S']:
        prior = next(r for r in earlier if r['cpu']==cpu and r['returncode']!=5)
        application = next(r for r in applications if r['cpu']==cpu)
        cases.append((cpu, Path(application['application_case'])/'native-compile', Path(prior['directory'])))
    multi = P / 'native-allocation-inventory/case-10'
    cases.append(('Q03UDV-original-two-resources', trace.A / 'full-Q03UDV/native-compile', multi))
    results = []
    for index, (name, frozen, prior) in enumerate(cases):
        raw = (prior / 'input.gxw').read_bytes()
        for attempt in range(1, 17):
            directory = OUT / f'c{index}-a{attempt}'
            result = run(directory, frozen, raw)
            result.update(case=name, original=str(prior), source_bytes_exact=(directory/'input.gxw').read_bytes()==raw)
            results.append(result)
            trace.save(OUT / 'results.json', results)
            print(json.dumps(dict(case=name, returncode=result['returncode'],
                checker=result['checker_read_correspondence'], selected=len(result['selected_targets']),
                finished=len(result['native_target_results']), enumeration=result['enumeration'],
                diagnostic_count=len(result['original_native_diagnostics']), gate=result['query_gate_seen'],
                public_check=result['public_check'], observation_errors=result['observation_errors']),
                ensure_ascii=False), flush=True)
            if result['returncode'] != 5:
                break


if __name__ == '__main__':
    main()
