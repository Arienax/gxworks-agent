"""Observe original declaration construction before component table insertion."""
from pathlib import Path
import sys

P=Path(__file__).resolve().parent
sys.path.insert(0,str(P))
import probe_fbd_cold_status_boundary as boundary
status=boundary.status

HEADER_OBSERVER=r'''
const ownedHeaderBuildModules=new Set(),ownedHeaderBuildTargets=new Set();
function ownedHeaderBuildBind(m){
 if(!m||ownedHeaderBuildModules.has(m.base.toString()))return;
 ownedHeaderBuildModules.add(m.base.toString());
 Interceptor.attach(m.base.add(0x8ae58),{onEnter(){try{
  const worker=this.context.ecx,table=worker.readPointer();
  for(const [slot,returnRva] of [[0x6c,0x8b020],[0x7c,0x8b035]]){
   const target=table.add(slot).readPointer();
   if(ownedHeaderBuildTargets.has(target.toString()))continue;
   ownedHeaderBuildTargets.add(target.toString());
   send({event:'owned-header-build-hook',slot,target:loc(target)});
   Interceptor.attach(target,{
    onEnter(a){this.owned=phase==='source-check'&&this.returnAddress.equals(m.base.add(returnRva));
     if(!this.owned)return;
     this.worker=this.context.ecx;
     this.name=this.worker.add(0x3c).readPointer().add(0xc).readPointer().readCString();
     send({event:'owned-header-build-enter',slot,target:loc(target),name:this.name,
      argument0:a[0].toString(),root:this.worker.add(0x110).readPointer().toString()});
    },
    onLeave(r){if(this.owned)send({event:'owned-header-build-return',slot,target:loc(target),
     name:this.name,original_result:r.toInt32(),root:this.worker.add(0x110).readPointer().toString()});}
   });
  }
 }catch(e){send({event:'observation-error',phase:'header-build-bind',error:String(e)});}}});
}
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()==='dzdataabs_sicconverter_iec.dll')ownedHeaderBuildBind(m);
 if(m.name.toLowerCase()==='dzdataabs_compiler_iec.dll')Interceptor.attach(m.base.add(0x6f2c),{
  onEnter(){ownedHeaderBuildBind(Process.findModuleByAddress(m.base.add(0x10120).readPointer()));}
 });
}});
'''

if __name__=='__main__':
    status.OUT=P/'fbd-cold-header-binding-20261003-v1'
    status.EXTRA_OBSERVER+=HEADER_OBSERVER
    status.CASES=[('clean',[]),('local-declaration-pending',['FBD_MATRIX.Labels.lh'])]
    status.main()
    (status.OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
