'use strict';
Process.attachModuleObserver({
    onAdded(module) {
        if (module.name.toLowerCase() !== 'eccodegenerator2.dll') return;
        const relative = address => address.sub(module.base).toUInt32();
        Interceptor.attach(module.getExportByName('Open'), {
            onEnter(args) { this.handle = args[0]; this.cpu = args[1].toInt32(); },
            onLeave(code) {
                if (code.toInt32() !== 0) return;
                const manager = this.handle.add(12).readPointer();
                const count = manager.add(16).readU32();
                if (count > 32) throw new Error('Unmeasured provider list extent');
                let link = manager.add(4).readPointer();
                const objects = [];
                for (let i = 0; i < count; i++) {
                    if (link.isNull()) throw new Error('Provider list is truncated');
                    const object = link.add(12).readPointer();
                    const vtable = object.readPointer();
                    objects.push({kind: object.add(4).readU16(),vtable: relative(vtable),
                        forward:relative(vtable.add(4).readPointer()),reverse:relative(vtable.add(8).readPointer())});
                    link = link.add(8).readPointer();
                }
                send({event:'Q-context-open',cpu:this.cpu,native_cpu_word:module.base.add(0x16d12c).readU16(),objects});
            }
        });
    }
});
