"""Controlled FB instance/line diagnostics, using owned offline projects only."""
from copy import deepcopy
from pathlib import Path
import json
import struct
import sys

import probe_application_check_resources as trace
from probe_diagnostic_source_locations import errors

P = Path(__file__).resolve().parent
ROOT = P.parents[3]
sys.path.insert(0, str(ROOT / 'src'))
from gxw.object_model import read_project_context, generate_object_project
from gxw.container_writer import validate_cfb_streams, replace_project_stream
from gxw.project_metadata import logical_mapping, synchronize_history
from gxw.text_pou import parse_st_pou
from gxw.compiler_storage import parse_compiler_index, parse_compiler_link_map

OUT = P / 'diagnostic-callsite-module-20261002-v1'
A = P / 'application-fbd-v2-20261002-v1'


def replace_body(raw, text):
    outer = validate_cfb_streams(raw)
    nested = validate_cfb_streams(outer['_hdb'])
    logical = 'MODULE_FB.Program.pou'
    physical = logical_mapping(outer['projectdatalist.xml'])[logical]
    original = nested[physical]
    source = parse_st_pou(original)
    payload = (text + '\0').encode('utf-16le')
    changed = bytearray(original[:source.text_offset] + payload + original[-28:])
    struct.pack_into('<II', changed, source.text_offset - 16,
                     len(changed) - (source.text_offset - 17) - 29,
                     len(changed) - (source.text_offset - 17) - 29)
    struct.pack_into('<I', changed, source.text_offset - 4, len(payload)//2)
    changed = bytes(changed)
    if parse_st_pou(changed).text != text:
        raise ValueError('ST source envelope did not preserve the requested source')
    history, metadata, preserved = synchronize_history(outer['history.xml'],
                                                       {logical: (physical, original, changed)})
    hdb, _ = replace_project_stream(outer['_hdb'], physical, changed)
    result, _ = replace_project_stream(raw, '_hdb', hdb)
    result, _ = replace_project_stream(result, 'history.xml', history)
    if validate_cfb_streams(hdb) != dict(nested, **{physical: changed}):
        raise ValueError('ST edit disturbed another nested stream')
    if validate_cfb_streams(result) != dict(outer, _hdb=hdb, **{'history.xml': history}):
        raise ValueError('ST edit disturbed another outer stream')
    return result, dict(logical=logical, original_source=source.text, current_source=text,
                        unrelated_payloads='byte-identical', metadata_changes=metadata)


def candidate(raw, *, calls, writes):
    if calls == 2:
        context = read_project_context(raw, 'FBD_MATRIX.Program.pou')
        model = deepcopy(context.object_model())
        prototype = next(n for n in model['nodes'] if n['template'] == 'function_block:MODULE_FB')
        group = [n for n in model['nodes'] if n['y'] >= prototype['y']]
        for index, n in enumerate(group):
            node = {key: n[key] for key in ('template', 'symbol', 'x', 'y')}
            node.update(id=f'owned_call_b_{index}', y=n['y']+7)
            if n['template'] == 'function_block:MODULE_FB':
                node.update(symbol='APP_MODULE_STAGE_B', prototype_offset=n['source_offset'])
            elif n['symbol'] == 'MODULE_TEXT':
                node['symbol'] = 'MODULE_TEXT_B'
                model['declaration_edits'].setdefault('FBD_MATRIX.Labels.lh', {}).setdefault('upserts', []).append(
                    dict(name='MODULE_TEXT_B', data_type='STRING[20]', kind='variable', class_name='VAR', initial_value="''"))
            elif n['symbol'] == 'Y10':
                node['symbol'] = 'Y11'
            elif n['symbol'] == 'D30':
                node['symbol'] = 'D31'
            elif n['symbol'] == 'X0':
                node['symbol'] = 'X1'
            model['nodes'].append(node)
        model['canvas_height'] = max(n['y']+n.get('height',5) for n in model['nodes'])
        raw = generate_object_project(model, baseline=raw).data
    outer = validate_cfb_streams(raw)
    nested = validate_cfb_streams(outer['_hdb'])
    physical = logical_mapping(outer['projectdatalist.xml'])['MODULE_FB.Program.pou']
    original = parse_st_pou(nested[physical]).text
    text = original + 'Y1 := SIGNAL;\r\n' * writes
    raw, mutation = replace_body(raw, text)
    return raw, dict(mutation, calls=calls, direct_device_writes_per_body=writes,
                     model=read_project_context(raw, 'FBD_MATRIX.Program.pou').object_model())


def link_witness(directory):
    path = directory / 'compiler/ESCompiler.stg'
    if not path.exists():
        return None
    streams = validate_cfb_streams(path.read_bytes())
    index = parse_compiler_index(streams['Index'])
    entries = [e for e in index.entries if e.name_bytes == b'MAIN*MAIN.map']
    if len(entries) != 1:
        return dict(handling='unresolved-map', count=len(entries))
    mapping = parse_compiler_link_map(streams[entries[0].stream_name])
    resource = (directory / 'pcode-0-0.bin').read_bytes()
    rows = []
    for entry in mapping.entries:
        rows.append(dict(name=entry.name_bytes.decode('cp949'), fields=entry.fields,
                         step_start=entry.step_offset, step_count=entry.step_count,
                         token_offset=entry.token_offset, token_length=entry.token_length,
                         linked_token_hex=resource[entry.token_offset:entry.token_offset+entry.token_length].hex()))
    return dict(handling='stored-current-compiler-link-map', rows=rows,
                raw_hex=mapping.raw.hex(), opaque_tail_hex=mapping.opaque_tail.hex(),
                code_provenance='same owned compile; checker byte correspondence recorded separately')


def ranges():
    values = []
    for pou in ('MODULE_FB', 'FBD_MATRIX.APP_MODULE_STAGE_A', 'FBD_MATRIX.APP_MODULE_STAGE_B'):
        for line in (1, 2, 3, 4, 5):
            for mode in ('basic', 'debug'):
                values.append(dict(mode=mode, library='', pou=pou, resource='MAIN',
                                   program_kind=193, network=-1, start_step=line,
                                   step_count=1, element_id=-1))
    return values


def run_case(case, frozen, raw, query_steps=()):
    for attempt in range(1, 17):
        directory = case / ('native-attempt-' + str(attempt))
        script = trace.prepare(directory, frozen)
        (directory / 'input.gxw').write_bytes(raw)
        plan = json.loads((directory / 'plan.json').read_text())
        plan.update(analysis_version=3,
                    analysis_queries=[dict(name='all-references', keys=[], symbol='', scope='', declared=0, plural=0),
                                      dict(name='Y1-references', keys=[], symbol='Y1', scope='', declared=0, plural=0)],
                    pcode_range_queries=ranges())
        if query_steps:
            plan['pcode_location_queries'] = [dict(resource='MAIN', start_step=s, step_count=1, timestamp=0)
                                               for s in sorted(set(query_steps)) if s >= 0]
        trace.save(directory / 'plan.json', plan)
        returncode, messages = trace.run(directory, script)
        result = trace.summarize(directory, returncode, messages)
        result['link_witness'] = link_witness(directory)
        for file, field in [('native-pcode-locations.json', 'source_locations'),
                            ('native-pcode-ranges.json', 'source_ranges'),
                            ('native-program-analysis.json', 'source_references')]:
            path = directory / file
            result[field] = json.loads(path.read_text(encoding='utf-8-sig')) if path.exists() else None
        trace.save(directory / 'result-with-source-evidence.json', result)
        print(json.dumps(dict(case=str(case.relative_to(OUT)), attempt=attempt, returncode=returncode,
                              compile=result['compile_completed'], checker=result['checker_read_correspondence'],
                              projection=result['diagnostic_projection'], errors=len(errors(directory)) if returncode!=5 else None)), flush=True)
        if returncode != 5:
            return directory, result
    raise RuntimeError('Owned project-name collision retries exhausted')


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    resume = '--resume' in sys.argv
    OUT.mkdir(exist_ok=resume)
    frozen = A / 'full-FX3U-FX3UC/native-compile'
    baseline = (frozen / 'input.gxw').read_bytes()
    results = []
    for calls, writes in ((1, 1), (2, 1), (1, 2), (2, 2)):
        case = OUT / f'FX3U-FX3UC-calls-{calls}-writes-{writes}'
        if resume and case.exists():
            raw = (case / 'input.gxw').read_bytes()
            directory = next(d for d in case.glob('native-attempt-*')
                             if (d / 'result-with-source-evidence.json').exists()
                             and json.loads((d / 'result-with-source-evidence.json').read_text())['returncode'] != 5)
            result = json.loads((directory / 'result-with-source-evidence.json').read_text())
        else:
            case.mkdir()
            raw, mutation = candidate(baseline, calls=calls, writes=writes)
            (case / 'input.gxw').write_bytes(raw)
            trace.save(case / 'mutation.json', mutation)
            directory, result = run_case(case, frozen, raw)
        reports = errors(directory)
        if not result['compile_completed']:
            results.append(dict(case=case.name, result=result, followup='compile failure retained'))
            trace.save(OUT / 'results.json', results)
            continue
        steps = {r['step']+delta for r in reports for delta in (-1,0,1)}
        if reports:
            # Keep the native workspace path bounded. The first nested followup
            # failed ImportOneFileProject with 0x2d020013 before compilation;
            # preserve it and use a shorter sibling for the identical input.
            followup = OUT / f'fx-c{calls}-w{writes}-loc'
            if resume and followup.exists():
                queried_dir = next(d for d in followup.glob('native-attempt-*')
                                   if (d / 'result-with-source-evidence.json').exists()
                                   and json.loads((d / 'result-with-source-evidence.json').read_text())['returncode'] != 5)
                queried_result = json.loads((queried_dir / 'result-with-source-evidence.json').read_text())
            else:
                followup.mkdir()
                queried_dir, queried_result = run_case(followup, frozen, raw, steps)
            queried_result['pcode_equal_to_first_compile'] = all(
                (queried_dir / f'pcode-0-{i}.bin').exists() and
                (queried_dir / f'pcode-0-{i}.bin').read_bytes() == (directory / f'pcode-0-{i}.bin').read_bytes()
                for i in range(3))
            results.append(dict(case=case.name, calls=calls, writes=writes, result=result,
                                error_location_result=queried_result))
        else:
            results.append(dict(case=case.name, calls=calls, writes=writes, result=result))
        trace.save(OUT / ('results-with-partial-errors.json' if resume else 'results.json'), results)


if __name__ == '__main__':
    main()
