"""Owned offline source Check selections, derived from the original type library.

The two names and process-unit kind remain hypotheses until native controls
identify their meaning. All original return values and diagnostics are retained.
"""
from pathlib import Path
import json
import shutil
import sys

P = Path(__file__).resolve().parent
sys.path.insert(0, str(P))
import probe_public_source_check as source
import probe_source_check_dispatch as dispatch
import probe_native_check_drain as drain
import probe_application_check_resources as trace

OUT = P / 'source-unit-shape-20261002-v7'
CASES = [('empty-pou', 6, ['', 'FBD_MATRIX'])]
SOURCE_CHECK = '''
            if(plan.ContainsKey("owned_source_check_units")&&!compilerRejected) {
                foreach(Dictionary<string,object> query in
                    (System.Collections.IEnumerable)plan["owned_source_check_units"]) {
                    var rows=new List<Dictionary<string,object>>();
                    foreach(Dictionary<string,object> row in
                        (System.Collections.IEnumerable)query["selections"]) rows.Add(row);
                    IntPtr items=Marshal.AllocCoTaskMem(rows.Count*8),unit=Marshal.AllocCoTaskMem(12);
                    try {
                        for(int index=0;index<rows.Count;index++) {
                            var row=rows[index];
                            var selection=new OwnedSelectInformation{row=Convert.ToInt32(row["row"]),
                                name=BStr((string)row["name"])};
                            Marshal.StructureToPtr(selection,IntPtr.Add(items,index*8),false);
                        }
                        Marshal.StructureToPtr(new OwnedProcessUnit{
                            kind=Convert.ToInt32(query["kind"]),count=rows.Count,selections=items},unit,false);
                        Record(new {operation="PublicSourceCheckSelection",query=query,
                            unit_size=Marshal.SizeOf(typeof(OwnedProcessUnit)),
                            selection_size=Marshal.SizeOf(typeof(OwnedSelectInformation))});
                        Check("Compiler.SourceCheck",Slot<OwnedSourceCheckFn>(compiler,32)(compiler,
                            -1,1,unit,out code),code);
                        bool sourceRejected=WaitReports(compiler,40,"SourceCheckProgress");
                        Record(new {operation="PublicSourceCheckCompleted",query=query,rejected=sourceRejected});
                        compilerRejected|=sourceRejected;
                    } finally {Marshal.FreeCoTaskMem(unit);Marshal.FreeCoTaskMem(items);}
                }
            }
'''
OBSERVER = r'''
const ownedOriginalSourceUnits=new Map();
function ownedSourceName(p){
 if(p.isNull())return null;
 const bytes=[];
 for(let i=0;i<256;i++){
  const b=p.add(i).readU8();
  if(b===0)return String.fromCharCode(...bytes);
  bytes.push(b);
 }
 throw new Error('source name exceeds bounded terminated string');
}
function ownedNarrowUnit(p){
 const kind=p.readS32(),count=p.add(4).readS32(),data=p.add(8).readPointer(),rows=[],
  raw_header_hex=hex(p,12),pointer=p.toString(),data_pointer=data.toString();
 const result={kind,count,rows,pointer,data_pointer,raw_header_hex,descriptor_state:'bounded'};
 let expected=ownedOriginalSourceUnits.get(pointer);
 if(expected&&expected.raw_header_hex!==raw_header_hex)
  return {...result,descriptor_state:'header_changed_after_original_check'};
 if(!expected)expected=Array.from(ownedOriginalSourceUnits.values()).find(row=>row.raw_header_hex===raw_header_hex);
 if(kind<0||kind>20||count<0||count>32)
  return {...result,descriptor_state:'descriptor_outside_original_structural_bounds'};
 if(count>0&&data.isNull())return {...result,descriptor_state:'nonempty_null_selection_array'};
 for(let i=0;i<count;i++){
  const namePointer=data.add(i*8+4).readPointer(),name_pointer=namePointer.toString(),row=data.add(i*8).readS32();
  const prior=expected&&expected.rows[i];
  if(prior&&prior.name_pointer!==name_pointer){
   rows.push({row,name:null,name_pointer,name_state:namePointer.isNull()?'cleared':'pointer_changed'});
   continue;
  }
  if(prior&&prior.name!==null){
   const prefix_hex=hex(namePointer,prior.name.length+1);
   const expected_hex=Array.from(prior.name+'\0',c=>c.charCodeAt(0).toString(16).padStart(2,'0')).join('');
   rows.push({row,name:prefix_hex===expected_hex?prior.name:null,name_pointer,
    name_state:prefix_hex===expected_hex?'original_bytes':'bytes_changed'});
  }else rows.push({row,name:ownedSourceName(namePointer),name_pointer,name_state:'original_input'});
 }
 return result;
}
const ownedSourceSites=new Set();
function ownedAttachSourceModule(m){
 if(m.name.toLowerCase()==='dzdataabs_compileradapter.dll')Interceptor.attach(m.base.add(0x2cac),{
  onEnter(){if(!ownedSourceCheckDepth)return;this.owned=true;try{
   this.owner=this.context.ecx;
   const count=this.owner.add(8).readS32(),data=this.owner.add(4).readPointer(),units=[];
   if(!ownedOriginalSourceUnits.has(data.toString())){this.owned=false;return;}
   if(count<0||count>32)throw new Error('source cleanup unit count bound');
   if(!data.isNull())for(let i=0;i<count;i++)units.push(ownedNarrowUnit(data.add(i*12)));
   send({event:'native-source-owner-cleanup-enter',count,units});
  }catch(e){send({event:'observation-error',phase:'source-owner-cleanup-enter',error:String(e)});}},
  onLeave(){if(this.owned)send({event:'native-source-owner-cleanup-return',
   units_pointer_after:this.owner.add(4).readPointer().toString()});}
 });
 if(m.name.toLowerCase()==='dzdataabs_compiler_iec.dll')Interceptor.attach(m.base.add(0x6852),{
  onEnter(a){this.code=a[3];send({event:'native-source-compiler-initialize',cpu:a[2].toInt32(),
   temporary_path:ownedSourceName(a[1])});},
  onLeave(r){send({event:'native-source-compiler-initialize-return',hresult:r.toInt32(),
   code:this.code.readU32()});}
 });
 if(m.name.toLowerCase()==='dzdataabs_compiler_iec.dll')Interceptor.attach(m.base.add(0x6f2c),{
  onEnter(){try{
   const target=m.base.add(0x10120).readPointer();
   send({event:'native-source-iat-target',target:loc(target),address:target.toString(),
    prefix_hex:hex(target,20)});
   const converter=Process.findModuleByAddress(target);
   if(!converter||converter.name.toLowerCase()!=='dzdataabs_sicconverter_iec.dll')
    throw new Error('resolved source Check converter differs');
   ownedAttachSourceModule(converter);
   Interceptor.attach(target,{
    onEnter(a){try{send({event:'native-source-iat-check-enter',address:target.toString(),
     count:a[0].toInt32(),units_pointer:a[1].toString()});
    }catch(e){send({event:'observation-error',phase:'source-iat-check-enter',error:String(e)});}},
    onLeave(r){send({event:'native-source-iat-check-return',code:r.toUInt32()});}
   });
   send({event:'native-source-active-modules',modules:Process.enumerateModules()
    .filter(row=>/dataabs|compiler|converter/i.test(row.name))
    .map(row=>({name:row.name,path:row.path,base:row.base.toString()}))});
   send({event:'native-source-resolved-imports',imports:m.enumerateImports()
    .filter(row=>row.name&&row.name.startsWith('?Check@CDZDataABS_ProcessManager@'))
    .map(row=>({name:row.name,module:row.module,address:row.address?loc(row.address):null}))});
  }catch(e){send({event:'observation-error',phase:'native-source-module-inventory',error:String(e)});}}
 });
 if(m.name.toLowerCase().includes('sicconverter')||m.name.toLowerCase().includes('datamanager'))
  send({event:'native-source-module',name:m.name,path:m.path,base:m.base.toString()});
 if(m.name.toLowerCase()!=='dzdataabs_sicconverter_iec.dll')return;
 if(ownedSourceSites.has(m.base.toString()))return;
 ownedSourceSites.add(m.base.toString());
 send({event:'native-source-sites',worker:loc(m.base.add(0x2e8f6)),
  worker_prefix_hex:hex(m.base.add(0x2e8f6),16),reject_prefix_hex:hex(m.base.add(0x2f131),8)});
 const check=m.enumerateExports().find(row=>row.name.startsWith('?Check@CDZDataABS_ProcessManager@'));
 if(check)Interceptor.attach(check.address,{
  onEnter(a){this.owned=ownedSourceCheckEver;try{
   const count=a[0].toInt32(),originalUnits=[];
   if(count<0||count>32)throw new Error('original native Check unit count bound');
   for(let i=0;i<count;i++){
    const unit=ownedNarrowUnit(a[1].add(i*12));
    ownedOriginalSourceUnits.set(unit.pointer,unit);originalUnits.push(unit);
   }
   send({event:'native-source-process-check-enter',owned:this.owned,address:loc(check.address),
    count,units_pointer:a[1].toString(),original_units:originalUnits});
  }catch(e){send({event:'observation-error',phase:'process-check-enter',error:String(e)});}},
  onLeave(r){if(this.owned)send({event:'native-source-process-check-return',code:r.toUInt32()});}
 });
 Interceptor.attach(m.base.add(0x2e8f6),{
  onEnter(a){if(!ownedSourceCheckEver)return;this.owned=true;try{
   const count=a[0].toInt32(),units=[];
   if(count<0||count>32)throw new Error('worker unit count bound');
   for(let i=0;i<count;i++)units.push(ownedNarrowUnit(a[1].add(i*12)));
   send({event:'native-source-worker-enter',count,units});
  }catch(e){send({event:'observation-error',phase:'source-worker-enter',error:String(e)});}},
  onLeave(r){if(this.owned)send({event:'native-source-worker-return',code:r.toUInt32()});}
 });
 Interceptor.attach(m.base.add(0x2f131),{onEnter(){if(!ownedSourceCheckEver)return;try{
  const frame=this.context.ebp,array=frame.sub(0x28),size=array.add(8).readS32(),
   data=array.add(4).readPointer(),index=this.context.ebx.toInt32();
  if(size<0||size>32||index<0||index>=size)throw new Error('source rejection array bounds');
  const unit=data.add(index*4).readPointer();
  send({event:'native-source-shape-rejection',index,size,unit:ownedNarrowUnit(unit)});
 }catch(e){send({event:'observation-error',phase:'source-shape-rejection',error:String(e)});}}});
 Interceptor.attach(m.base.add(0x251cf),{
  onEnter(a){if(!ownedSourceCheckEver)return;this.owned=true;try{
   const slots={};
   for(const offset of [0x14,0x18]){
    const manager=this.context.ecx.add(offset).readPointer(),vtable=manager.readPointer(),methods={};
    for(const method of [0x80,0x110,0x114,0x118,0x128])methods['0x'+method.toString(16)]=loc(vtable.add(method).readPointer());
    slots['0x'+offset.toString(16)]={vtable:loc(vtable),methods};
   }
   send({event:'native-source-unit-enter',unit:ownedNarrowUnit(this.context.esp.add(4)),managers:slots});
  }catch(e){send({event:'observation-error',phase:'source-unit-enter',error:String(e)});}},
  onLeave(r){if(this.owned)send({event:'native-source-unit-return',code:r.toUInt32()});}
 });
}
const ownedSourceModuleObserver=Process.attachModuleObserver({onAdded:ownedAttachSourceModule});
'''


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    OUT.mkdir(exist_ok=False)
    shutil.copyfile(Path(__file__), OUT / Path(__file__).name)
    prior = next(row for row in json.loads((P / 'diag-cpu-20261002-v1/results.json').read_text(
        encoding='utf-8')) if row['cpu'] == 'FX3U/FX3UC' and row['returncode'] != 5)
    raw = (Path(prior['directory']) / 'input.gxw').read_bytes()
    frozen = trace.A / 'full-FX3U-FX3UC/native-compile'
    prepare, adapt, old_stage = trace.prepare, drain.adapt_helper, source.SOURCE_CHECK
    source.SOURCE_CHECK = SOURCE_CHECK
    drain.adapt_helper = source.adapt
    trace.prepare = lambda *args, **kwargs: prepare(*args, **kwargs) + dispatch.OBSERVER + OBSERVER
    try:
        results = []
        for label, kind, names in CASES:
            source.UNITS = [dict(kind=kind,selections=[dict(name=name,row=-1) for name in names])]
            for attempt in range(1,17):
                directory = OUT / f'{label}-a{attempt}'
                result = drain.run(directory, frozen, raw)
                observations = [json.loads(line) for line in (directory / 'observation-events.jsonl').read_text(
                    encoding='utf-8').splitlines()]
                events = [json.loads(line) for line in (directory / 'native-events.jsonl').read_text(
                    encoding='utf-8-sig').splitlines()]
                result.update(label=label, selected_units=source.UNITS,
                    source_dispatch=[row['payload'] for row in observations
                        if row.get('type')=='send' and 'source-' in row['payload'].get('event','')],
                    source_check_events=[row for row in events if row.get('operation','').startswith(
                        ('Compiler.SourceCheck','PublicSourceCheck','SourceCheckProgress'))])
                trace.save(directory/'result-with-source-check.json',result)
                results.append(result)
                trace.save(OUT/'results.json',results)
                print(json.dumps(dict(label=label,returncode=result['returncode'],
                    events=[row for row in result['source_dispatch']
                        if not row['event'].endswith('progress') and row['event']!='native-source-active-modules'],
                    source_errors=[row for row in result['source_check_events']
                        if any(report['kind'] in [2,3] for report in row.get('reports',[]))],
                    observation_errors=result['observation_errors']),ensure_ascii=False),flush=True)
                if result['returncode'] != 5:
                    break
    finally:
        trace.prepare, drain.adapt_helper, source.SOURCE_CHECK = prepare, adapt, old_stage


if __name__ == '__main__':
    main()
