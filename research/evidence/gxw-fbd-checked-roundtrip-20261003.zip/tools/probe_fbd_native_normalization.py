"""Controlled native frontend comparisons plus generated FBD edit properties.

Each run imports an owned offline GXW copy into a fresh workspace. The original
current backend Check and wide progress are used; public ProgramCheck failures
are retained separately. No PLC/simulator execution or digest check is added.
"""
from pathlib import Path
from dataclasses import replace
import base64
import json
import shutil
import sys

P = Path(__file__).resolve().parent
ROOT = P.parents[3]
sys.path[:0] = [str(ROOT/'src'), str(P), str(P/'skill-trial-20261002-v1/python-deps')]
import probe_current_source_bodies as bodies
import probe_current_source_check as probe
import probe_source_check_dispatch as dispatch
import probe_source_check_units as units
from probe_fbd_label_graph_binding import patch
from native_fbd_body_codec import normalized_payload
from gxw.object_model import read_project_context
from gxw.declarations import edit_declarations, serialize_declarations
from gxw.structured_pou_writer import serialize_structured_pou
from gxw.models import GXWFormatError
from hypothesis import given, example, settings, strategies as st

OUT = P/'fbd-native-normalization-20261002-v5'
BASE = P/'current-source-body-records-20261002-v4/c00-pou-a1/input.gxw'
FROZEN = probe.trace.A/'full-FX3U-FX3UC/native-compile'
RAW = BASE.read_bytes()
CONTEXT = read_project_context(RAW, 'FBD_MATRIX.Program.pou')

TEXT_OBSERVER = r'''
const ownedTextTargets = OWNED_TEXT_TARGETS, ownedTextSeen = new Set();
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='kernelbase.dll')return;
 const address=m.findExportByName('WideCharToMultiByte');if(!address)return;
 const acp=m.findExportByName('GetACP');
 send({event:'owned-native-text-observer',address:loc(address),
  process_acp:acp?new NativeFunction(acp,'uint',[])():null});
 Interceptor.attach(address,{
  onEnter(a){this.owned=false;
   const count=a[3].toInt32();if(count<-1||count>128||a[2].isNull())return;
   try{
    const text=count===-1?a[2].readUtf16String():a[2].readUtf16String(count);
    if(!ownedTextTargets.includes(text.replace(/\0+$/,'')))return;
    const trace=Thread.backtrace(this.context,Backtracer.ACCURATE).slice(0,6).map(loc);
    const key=JSON.stringify([a[0].toUInt32(),text,trace]);
    if(ownedTextSeen.has(key))return;ownedTextSeen.add(key);
    this.owned=true;this.output=a[4];this.row={event:'owned-native-label-encoding',
     code_page:a[0].toUInt32(),flags:a[1].toUInt32(),text,source_units:count,trace};
   }catch(e){send({event:'observation-error',phase:'label-encoding-enter',error:String(e)});}
  },
  onLeave(r){if(!this.owned)return;try{
   const size=r.toInt32();send({...this.row,original_size:size,
    output_hex:size>0&&!this.output.isNull()?hex(this.output,size):null});
  }catch(e){send({event:'observation-error',phase:'label-encoding-return',error:String(e)});}}
 });
}});
'''


def candidate(spec):
    nodes = list(CONTEXT.program.nodes)
    documents = {}
    renames = {old: spec[key] for old, key in (
        ('APP_MODULE_STAGE_A', 'instance'), ('MODULE_TEXT', 'terminal'))
        if spec.get(key) is not None and spec[key] != old}
    if renames:
        local = 'FBD_MATRIX.Labels.lh'
        documents[local] = edit_declarations(CONTEXT.declarations[local], renames=renames)
        nodes = [replace(node, symbol=renames.get(node.symbol, node.symbol)) for node in nodes]
    pair = spec.get('inout')
    if pair is not None:
        owner = next(n for n in CONTEXT.program.nodes if n.symbol == 'APP_MODULE_STAGE_A')
        points = {}
        for port in CONTEXT.sources.callable(owner)['ports']:
            if port['formal_name'] == 'STATE':
                points[port['side']] = (owner.bbox.left + port['x'], owner.bbox.top + port['y'])
        assert points['in'] != points['out']
        hits = {'in': 0, 'out': 0}
        changed = []
        for node in nodes:
            point = (node.port_point(0).x, node.port_point(0).y) if node.ports else None
            side = 'in' if node.kind_code == 13 else 'out' if node.kind_code == 14 else None
            if side and node.symbol == 'D30' and point == points[side]:
                hits[side] += 1
                node = replace(node, symbol='D' + str(pair[0 if side == 'in' else 1]))
            changed.append(node)
        assert hits == {'in': 1, 'out': 1}
        nodes = changed
    dx, dy = spec.get('dx', 0), spec.get('dy', 0)
    nodes = [replace(n, bbox=replace(n.bbox, left=n.bbox.left+dx, right=n.bbox.right+dx,
                     top=n.bbox.top+dy, bottom=n.bbox.bottom+dy)) for n in nodes]
    wires = [replace(w, end=replace(w.end, y=w.end.y+dy))
             if w.start.x == w.end.x == 1 and w.start.y == 0 else
             replace(w, start=replace(w.start, x=w.start.x+dx, y=w.start.y+dy),
                     end=replace(w.end, x=w.end.x+dx, y=w.end.y+dy)) for w in CONTEXT.program.wires]
    program = replace(CONTEXT.program, nodes=tuple(nodes), wires=tuple(wires),
                      canvas_height=CONTEXT.program.canvas_height+dy)
    gui = serialize_structured_pou(program)
    replacements = {'FBD_MATRIX.Program.pou': gui}
    replacements.update({name: serialize_declarations(doc) for name, doc in documents.items()})
    raw, preservation = patch(RAW, replacements)
    return raw, gui, preservation


def snapshot_matches(path, wanted):
    result = []
    def walk(value, cursor):
        if isinstance(value, dict):
            blob = value.get('raw')
            if blob is not None and base64.b64decode(blob) == wanted:
                result.append(cursor)
            for key, item in value.items():
                if isinstance(item, (dict, list)):walk(item, cursor+'/'+key)
        elif isinstance(value, list):
            for index, item in enumerate(value):walk(item, cursor+'/'+str(index))
    walk(json.loads(path.read_text(encoding='utf-8-sig')), '')
    return result


def snapshot_pou_bodies(path, name):
    build = json.loads(path.read_text(encoding='utf-8-sig'))['build']
    pool = next(r['data'] for r in build['relocations'] if r['offset'] == 44)
    raw = base64.b64decode(pool['raw'])
    if len(raw) % 56:raise ValueError('frontend POU pool stride differs')
    relocations = {r['offset']: r['data'] for r in pool['relocations']}
    found = []
    for start in range(0, len(raw), 56):
        selected = base64.b64decode(relocations[start+8]['raw'])
        if selected == name.encode('ascii') + b'\0':
            found.append(base64.b64decode(relocations[start+24]['raw']))
    if len(found) != 1:raise ValueError('frontend POU body selection absent or ambiguous')
    return found


RESULTS = []
ACTIVE_TEXT_OBSERVER = ''
EVALUATIONS = []
CACHED_NATIVE = []
NEXT_CASE = 0


def run_native(spec, *, label, assert_acceptance=True, encoding='ascii', encoding_errors='strict', configuration_key=None):
    global ACTIVE_TEXT_OBSERVER, NEXT_CASE
    raw, gui, preservation = candidate(spec)
    for prior in CACHED_NATIVE:
        if prior['spec'] != spec or prior.get('configuration_key') != configuration_key:continue
        directory = Path(prior['directory'])
        if (directory/'input.gxw').read_bytes() != raw:continue
        native = snapshot_pou_bodies(directory/'frontend-snapshot.json', 'FBD_MATRIX')[0]
        assert normalized_payload(gui, encoding=encoding, encoding_errors=encoding_errors) == native[64:]
        if assert_acceptance:
            assert len(prior['source_check']) == 1 and prior['source_check'][0]['acceptance'] == 'accepted'
        EVALUATIONS.append(dict(label=label, spec=spec, oracle_directory=str(directory),
            payload_bytes_exact=True, native_run_started=False))
        probe.trace.save(OUT/'property-evaluations.json', EVALUATIONS)
        return prior
    case = NEXT_CASE;NEXT_CASE += 1
    target_texts = [n.symbol for n in read_project_context(raw, 'FBD_MATRIX.Program.pou').program.nodes
                    if n.symbol.startswith('OWNED_') or any(ord(c)>127 for c in n.symbol)]
    ACTIVE_TEXT_OBSERVER = TEXT_OBSERVER.replace('OWNED_TEXT_TARGETS', json.dumps(target_texts, ensure_ascii=True))
    for attempt in range(1, 17):
        directory = OUT/f'c{case:03d}-{label}-a{attempt}'
        result = probe.run_case(directory, FROZEN, raw)
        if result['returncode'] == 5:
            row = dict(label=label, spec=spec, directory=str(directory), attempt=attempt,
                       returncode=5, native_case_started=False,
                       native_startup_failure=result['native_failures'], comparisons=[],
                       observation_errors=result['observation_errors'])
            RESULTS.append(row);probe.trace.save(OUT/'results.json', RESULTS)
            probe.trace.save(directory/'normalization-result.json', row)
            print(json.dumps(dict(label=label, attempt=attempt, native_case_started=False),ensure_ascii=False),flush=True)
            continue
        payloads = [row['payload'] for row in map(json.loads,
            (directory/'observation-events.jsonl').read_text(encoding='utf-8').splitlines())
            if row.get('type') == 'send']
        observed = [r for r in payloads if r.get('event') == 'native-source-body-record'
                    and r.get('original_getter_selection') == 'FBD_MATRIX']
        inputs = list(dict.fromkeys(bytes.fromhex(r['input_hex']) for r in observed))
        getter_captured = bool(inputs)
        if not inputs:inputs = snapshot_pou_bodies(directory/'frontend-snapshot.json', 'FBD_MATRIX')
        for index, native in enumerate(inputs):(directory/f'normalized-body-{index}.bin').write_bytes(native)
        accepted = [r for r in result['current_source_events']
                    if r['operation'] == 'CurrentSourceCheck.AcceptanceObserved']
        comparisons = []
        for native in inputs:
            expected = normalized_payload(gui, encoding=encoding, encoding_errors=encoding_errors)
            comparisons.append(dict(payload_bytes_exact=expected == native[64:],
                original_frontend_snapshot_byte_matches=snapshot_matches(directory/'frontend-snapshot.json', native),
                gui_bytes=len(gui), native_bytes=len(native), native_kind=native[42]))
        row = dict(label=label, spec=spec, directory=str(directory), attempt=attempt,
                   cpu=CONTEXT.object_model()['cpu'], returncode=result['returncode'],
                   configuration_key=configuration_key,
                   source_input_bytes_exact=result['source_bytes_exact'], source_check=accepted,
                   source_getter_captured=getter_captured,
                   compiled_resource_reads=result['checker_read_correspondence'],
                   original_public_check=result['public_check'],
                   observation_errors=result['observation_errors'], comparisons=comparisons,
                   label_encoding=[r for r in payloads if r.get('event','').startswith('owned-native-label-')
                                   or r.get('event')=='owned-native-text-observer'], preservation=preservation)
        probe.trace.save(directory/'normalization-result.json', row)
        RESULTS.append(row);probe.trace.save(OUT/'results.json', RESULTS)
        print(json.dumps(dict(label=label, attempt=attempt, returncode=row['returncode'],
            source_check=accepted, comparisons=comparisons, observation_errors=row['observation_errors']),
            ensure_ascii=False), flush=True)
        if row['returncode'] != 5:break
    assert not row['observation_errors'], 'owned observation failure, not a native codec counterexample'
    assert row['source_input_bytes_exact'] and row['comparisons']
    assert all(r['payload_bytes_exact'] and r['original_frontend_snapshot_byte_matches'] for r in comparisons)
    if assert_acceptance:
        assert len(accepted) == 1 and accepted[0]['execution_completion'] == 'completed'
        assert accepted[0]['acceptance'] == 'accepted'
    CACHED_NATIVE.append(row)
    EVALUATIONS.append(dict(label=label, spec=spec, oracle_directory=str(directory),
        payload_bytes_exact=True, native_run_started=True))
    probe.trace.save(OUT/'property-evaluations.json', EVALUATIONS)
    return row


@settings(max_examples=8, deadline=None, database=None, derandomize=True)
@example(name='A', dx=0, dy=0, left=0, right=1)
@example(name='Z'*12, dx=7, dy=7, left=98, right=99)
@given(name=st.text(alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_', min_size=1, max_size=12),
       dx=st.integers(0, 7), dy=st.integers(0, 7), left=st.integers(0, 98), right=st.integers(0, 99))
def native_property(name, dx, dy, left, right):
    run_native(dict(instance='OWNED_FB_'+name, dx=dx, dy=dy, inout=[left, right]),
               label='generated', assert_acceptance=False)


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    OUT.mkdir(exist_ok=False)
    for name in (Path(__file__).name, 'native_fbd_body_codec.py'):
        shutil.copyfile(P/name, OUT/name)
    for previous in sorted(P.glob('fbd-native-normalization-20261002-v[1-4]')):
        for file in previous.glob('c*/normalization-result.json'):
            value = json.loads(file.read_text(encoding='utf-8'))
            if value['returncode'] != 5 and value.get('comparisons') and all(
                c['payload_bytes_exact'] and c['original_frontend_snapshot_byte_matches']
                for c in value['comparisons']):CACHED_NATIVE.append(value)
    retained = []
    for relative, error in (
        ('fbd-native-normalization-20261002-v1/c000-baseline-a1', 'snapshot raw key was misread as raw_base64'),
        ('fbd-native-normalization-20261002-v2/c000-rename-instance-a1', None),
        ('fbd-native-normalization-20261002-v2/c001-grow-terminal-a1', 'compile rejection prevents source Check getter observation'),
        ('fbd-native-normalization-20261002-v3/c000-grow-terminal-a1', None),
        ('fbd-native-normalization-20261002-v3/c001-translate-geometry-a1', 'native geometry rejection; optional owned compiler-index decoder unsupported'),
    ):
        previous = P/relative
        gui = read_project_context((previous/'input.gxw').read_bytes(), 'FBD_MATRIX.Program.pou').program.raw
        native = snapshot_pou_bodies(previous/'frontend-snapshot.json', 'FBD_MATRIX')[0]
        matches = snapshot_matches(previous/'frontend-snapshot.json', native)
        assert matches and normalized_payload(gui) == native[64:]
        retained.append(dict(original_attempt=str(previous), owned_observation_or_property_error=error,
            original_frontend_snapshot_byte_matches=matches, payload_bytes_exact=True,
            native_run_repeated=False, original_public_check_promoted=False))
    probe.trace.save(OUT/'retained-oracle-corrections.json', retained)
    prepare, adapt_helper, cs = probe.trace.prepare, probe.drain.adapt_helper, probe.trace.CS
    def prepared(*args, **kwargs):
        active = probe.trace.CS;probe.trace.CS = cs
        try:return prepare(*args, **kwargs)+dispatch.OBSERVER+probe.BACKEND_OBSERVER+units.OBSERVER+ACTIVE_TEXT_OBSERVER
        finally:probe.trace.CS = active
    probe.trace.prepare = prepared;probe.drain.adapt_helper = probe.adapt
    probe.trace.CS = cs+(probe.SOURCE,)
    link_witness = probe.drain.link_witness
    def optional_link_witness(directory):
        try:return link_witness(directory)
        except GXWFormatError as error:
            return dict(status='not_established', owned_decoder_error=str(error),
                        evidence='original compiler storage retained', native_outcome_changed=False)
    probe.drain.link_witness = optional_link_witness
    probe.QUERY = dict(kind=6, selections=[dict(row=-1, name=''), dict(row=-1, name='FBD_MATRIX')], wide_progress=True)
    try:
        for label, spec in (
            ('translate-fixed-rail', dict(dx=3, dy=4)),
            ('separate-inout', dict(inout=[40, 50])),
        ):run_native(spec, label=label)
        native_property()
    finally:
        probe.trace.prepare, probe.drain.adapt_helper, probe.trace.CS = prepare, adapt_helper, cs
        probe.drain.link_witness = link_witness


if __name__ == '__main__':main()
