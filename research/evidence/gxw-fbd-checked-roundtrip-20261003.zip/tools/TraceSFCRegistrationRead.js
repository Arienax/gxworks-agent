(()=>{
'use strict';
function guard(f){try{return f();}catch(e){return {error:String(e)};}}
function prefix(p,n){return Array.from(new Uint8Array(p.readByteArray(n)),v=>v.toString(16).padStart(2,'0')).join('');}
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase().startsWith('dzdataabs_'))send({event:'native-data-module',name:m.name,path:m.path,image_size:m.size});
 if(m.name.toLowerCase()!=='dzdataabs_standarddatauni.dll')return;
 for(const [role,rva] of [['action',0x21277],['element-collection',0x2092d],['element',0x203a0]]){
   Interceptor.attach(m.base.add(rva),{
    onEnter(a){
      this.role=role;this.object=this.context.ecx;this.length=a[0].toUInt32();
      this.read=a[2];this.code=a[3];
      send({event:'source-registration-read-entry',role,rva,object:this.object.toString(),length:this.length,
            prefix:guard(()=>prefix(a[1],Math.min(this.length,192)))});
    },
    onLeave(r){send({event:'source-registration-read-return',role,rva,object:this.object.toString(),hresult:r.toInt32(),
      code:guard(()=>this.code.readU32()),consumed:guard(()=>this.read.readU32()),
      element_line_no:role==='element'?guard(()=>this.object.add(0x3c).readS32()):null});}
   });
 }
}});
})();
