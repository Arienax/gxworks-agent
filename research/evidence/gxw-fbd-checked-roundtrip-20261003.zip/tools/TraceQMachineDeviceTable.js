'use strict';
function bytes(address,size) {
    return Array.from(new Uint8Array(address.readByteArray(size))).map(b=>b.toString(16).padStart(2,'0')).join('');
}
Process.attachModuleObserver({
    onAdded(module) {
        if(module.name.toLowerCase()!=='eccodegenerator2.dll')return;
        Interceptor.attach(module.base.add(0x3fa51),{
            onEnter(args){this.table=args[1];this.sourceConfig=args[0];},
            onLeave(){
                const count=this.table.readU8();
                if(count>96)throw new Error('Unmeasured default device table extent');
                send({event:'Q-read-device-table',count,table:bytes(this.table,1+4*(count+1)),
                    context:bytes(this.sourceConfig,0x380),native_cpu_word:module.base.add(0x16d12c).readU16()});
            }
        });
    }
});
