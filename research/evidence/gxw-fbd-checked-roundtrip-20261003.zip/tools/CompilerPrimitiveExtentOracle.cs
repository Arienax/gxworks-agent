// Call only inspected constant-return and STRING branches of the offline
// type-extent helper. No compiler/project/device object is constructed.
using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
public static class CompilerPrimitiveExtentOracle {
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode)] static extern IntPtr LoadLibraryEx(string p,IntPtr f,uint flags);
    [UnmanagedFunctionPointer(CallingConvention.ThisCall)] delegate int SizeFn(IntPtr self,int type,int parameter);
    static void Guard(IntPtr m,int offset,byte[] bytes) {
        for(int i=0;i<bytes.Length;i++)if(Marshal.ReadByte(m,offset+i)!=bytes[i])throw new Exception("Uninspected native extent code");
    }
    public static int Main(string[] args) {
        if(IntPtr.Size!=4||args.Length!=2)return 2;
        if(FileVersionInfo.GetVersionInfo(args[0]).FileVersion!="15.50")throw new Exception("Uninspected compiler version");
        IntPtr m=LoadLibraryEx(args[0],IntPtr.Zero,8);if(m==IntPtr.Zero)throw new Exception("Load failed");
        Guard(m,0x519f0,new byte[]{0x64,0xa1,0,0,0,0,0x6a,0xff});
        Guard(m,0x51a62,new byte[]{0x8b,0x44,0x24,0x18,0x40});
        SizeFn size=(SizeFn)Marshal.GetDelegateForFunctionPointer(IntPtr.Add(m,0x519f0),typeof(SizeFn));
        using(StreamWriter output=new StreamWriter(args[1])) {
            foreach(int type in new int[]{0,2,3,9,11,15,17,18,65,66,67,68}) {
                int[] parameters=type==15?new int[]{0,1,2,3,4,7,8,15,16,20,255,256,32767}:new int[]{0};
                foreach(int parameter in parameters) {
                    int result=size(IntPtr.Zero,type,parameter);
                    output.WriteLine("{\"type\":"+type+",\"parameter\":"+parameter+",\"native_extent\":"+result+"}");output.Flush();
                }
            }
        }
        return 0;
    }
}
