(()=>{
'use strict';
const attached=new Set();
function location(p){const m=Process.findModuleByAddress(p);return m?{module:m.name,rva:p.sub(m.base).toString()}:null;}
function guard(f){try{return f();}catch(e){return {error:String(e)};}}
Process.attachModuleObserver({onAdded(m){
 const name=m.name.toLowerCase();
 if(name==='kernel32.dll'){
  const exit=m.findExportByName('ExitProcess');
  if(exit)Interceptor.attach(exit,{onEnter(a){send({event:'owned-process-exit',code:a[0].toUInt32()});}});
 }
 if(name==='dzdataabs_converter.dll'){
   const target=m.base.add(0x3d8a0),spec=location(target);
   if(attached.has(target.toString()))return;
   attached.add(target.toString());
   Interceptor.attach(target,{
    onEnter(a){this.outputs=[a[1],a[2],a[3]];send({event:'converter-sfc-entry',target:spec,object:a[0].toString()});},
    onLeave(r){send({event:'converter-sfc-return',target:spec,hresult:r.toInt32(),outputs:this.outputs.map(p=>guard(()=>p.readU32()))});}
   });
 }
}});
})();
