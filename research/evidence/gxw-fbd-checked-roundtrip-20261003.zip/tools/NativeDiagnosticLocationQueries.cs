// Additional read-only queries in an owned offline helper. The original failed
// public check is recorded first and the helper still exits with code 2.
using System;
using System.IO;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Threading;

partial class WorkspaceReplayOracle {
    static void QueryLocationsAfterNativeFailure(IntPtr compiler) {
        string root=Path.GetDirectoryName(Environment.GetCommandLineArgs()[1]);
        string input=Path.Combine(root,"diagnostic-query-input.json");
        File.WriteAllText(Path.Combine(root,"diagnostic-query-ready"),"owned-read-only-query");
        int gate=0;
        while(!File.Exists(input)&&gate++<1000)Thread.Sleep(10);
        if(!File.Exists(input)) {
            Record(new {operation="DiagnosticSourceQueryUnavailable",reason="owned query handoff timeout"});
            return;
        }
        try {
            var request=json.Deserialize<Dictionary<string,object>>(File.ReadAllText(input));
            var values=new List<object>();int queries=0;
            foreach(Dictionary<string,object> query in (System.Collections.IEnumerable)request["queries"]) {
                if(++queries>4096)throw new Exception("Diagnostic location query count exceeds bound");
                IntPtr location=Marshal.AllocCoTaskMem(32);
                try {
                    Marshal.Copy(new byte[32],0,location,32);
                    var range=new PCodeRange{resource=BStr((string)query["resource"]),
                        start=Convert.ToInt32(query["start_step"]),count=1,timestamp=0};
                    int code;
                    int hr=Slot<PCodeLocationFn>(compiler,100)(compiler,range,location,out code);
                    byte[] raw=new byte[32];Marshal.Copy(location,raw,0,32);object decoded=null;
                    if(hr>=0&&code==0)decoded=new {
                        library=ReadBStr(Marshal.ReadIntPtr(location)),pou=ReadBStr(Marshal.ReadIntPtr(location,4)),
                        program_kind=Marshal.ReadInt32(location,8),network=Marshal.ReadInt32(location,12),
                        start_step=Marshal.ReadInt32(location,16),step_count=Marshal.ReadInt32(location,20),
                        element_id=Marshal.ReadInt32(location,24),action_transition_present=Marshal.ReadIntPtr(location,28)!=IntPtr.Zero};
                    values.Add(new {query=query,hresult=hr,code=code,location=decoded,raw_base64=Convert.ToBase64String(raw)});
                } finally {
                    foreach(int offset in new int[]{0,4}) {
                        IntPtr value=Marshal.ReadIntPtr(location,offset);if(value!=IntPtr.Zero)Marshal.FreeBSTR(value);
                    }
                    IntPtr action=Marshal.ReadIntPtr(location,28);
                    if(action!=IntPtr.Zero) {
                        IntPtr name=Marshal.ReadIntPtr(action);if(name!=IntPtr.Zero)Marshal.FreeBSTR(name);
                        Marshal.FreeCoTaskMem(action);
                    }
                    Marshal.FreeCoTaskMem(location);
                }
            }
            File.WriteAllText(Path.Combine(root,"diagnostic-pcode-locations.json"),json.Serialize(values));
            Record(new {operation="DiagnosticSourceQueriesAfterPublicFailure",count=queries,
                public_check_status="incomplete",native_error_preserved=true});
        } catch(Exception e) {
            Record(new {operation="DiagnosticSourceQueryError",error=e.ToString(),native_error_preserved=true});
        }
    }
}
