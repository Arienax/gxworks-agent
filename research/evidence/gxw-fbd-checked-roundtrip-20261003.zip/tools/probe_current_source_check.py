"""Original Check on the actual backend observed during the current native build.

No vendor input, diagnostic, return value or program byte is patched. Narrow
source selections belong to the owned caller until native progress completes.
Source Check and compiled-resource ProgramCheck remain separate results.
"""
from pathlib import Path
import json
import os
import shutil
import sys

P=Path(__file__).resolve().parent
sys.path.insert(0,str(P))
import probe_application_check_resources as trace
import probe_native_check_drain as drain
import probe_source_check_dispatch as dispatch
import probe_source_check_units as units

OUT=P/'current-source-check-20261002-v4-wide-progress'
WIDE_PROGRESS=True
VERBOSE=True
CASES=[
    ('FX3U/FX3UC','pou',['','FBD_MATRIX']),
    ('FX3U/FX3UC','fb',['','MODULE_FB']),
    ('FX3U/FX3UC','absent',['','OWNED_ABSENT_POU']),
    ('FX3U/FX3UC','swapped',['FBD_MATRIX','']),
]
SOURCE='NativeCurrentSourceCheck.cs'
BACKEND_OBSERVER=r'''
const ownedCurrentSourceCpuKeys=new Map(),ownedCurrentSourceBindings=new Map();
let ownedCurrentSourceProgress=false;
const ownedPublicProgressMethods=new Set(),ownedPublicProgressDepth=new Map();
let ownedCurrentPublicCompiler=null,ownedCurrentBuildThread=null;
const ownedCurrentSourceObserver=Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()==='kernelbase.dll'){
  const target=m.findExportByName('OutputDebugStringW');
  if(!target)throw new Error('owned current build gate export absent');
  Interceptor.attach(target,{onEnter(a){
   if(a[0].isNull())return;
   const text=a[0].readUtf16String(64),prefix='GXW_OWNED_CURRENT_BUILD:';
   if(text==='GXW_OWNED_CURRENT_BUILD_END'){ownedCurrentPublicCompiler=null;return;}
   if(!text.startsWith(prefix))return;
   const address=text.slice(prefix.length);
   if(!/^[0-9a-fA-F]{8}$/.test(address))throw new Error('owned current compiler gate pointer format differs');
   ownedCurrentPublicCompiler=ptr('0x'+address);ownedCurrentBuildThread=this.threadId;
   const progress=ownedCurrentPublicCompiler.readPointer().add(40).readPointer();
   send({event:'owned-current-public-compiler',pointer:ownedCurrentPublicCompiler.toString(),progress:loc(progress)});
   if(ownedPublicProgressMethods.has(progress.toString()))return;
   ownedPublicProgressMethods.add(progress.toString());
   Interceptor.attach(progress,{
    onEnter(a){this.owned=ownedCurrentPublicCompiler!==null&&
      a[0].equals(ownedCurrentPublicCompiler)&&this.threadId===ownedCurrentBuildThread;
     if(this.owned)ownedPublicProgressDepth.set(this.threadId,(ownedPublicProgressDepth.get(this.threadId)||0)+1);},
    onLeave(){if(this.owned)ownedPublicProgressDepth.set(this.threadId,ownedPublicProgressDepth.get(this.threadId)-1);}
   });
  }});
 }
 if(m.name.toLowerCase()==='dzdataabs_compiler_iec.dll')Interceptor.attach(m.base.add(0x6852),{
  onEnter(a){ownedCurrentSourceCpuKeys.set(a[0].toString(),a[2].toInt32());}
 });
 if(m.name.toLowerCase()!=='dzdataabs_compileradapter.dll')return;
 Interceptor.attach(m.base.add(0x9674),{onEnter(){
  if(!(ownedPublicProgressDepth.get(this.threadId)>0)||ownedSourceCheckEver)return;
  try {
   const backend=this.context.ecx.add(0x14).readPointer();
   if(ownedCurrentSourceBindings.has(backend.toString()))return;
   const table=backend.readPointer(),check=table.add(36).readPointer(),progress=table.add(44).readPointer(),
    checkLocation=loc(check),progressLocation=loc(progress);
   if(checkLocation.module!=='DZDataABS_Compiler_IEC.dll'||checkLocation.rva!=='0x6f2c'||
      progressLocation.module!=='DZDataABS_Compiler_IEC.dll'||progressLocation.rva!=='0x700b')
    throw new Error('current backend differs from verified original narrow compiler ABI');
   const key=ownedCurrentSourceCpuKeys.get(backend.toString());
   if(typeof key!=='number')throw new Error('current backend Initialize CPU was not observed');
   const binding={event:'owned-current-source-backend-bound',pid:Process.id,backend:backend.toString(),
    check_address:check.toString(),progress_address:progress.toString(),native_cpu_engine_key:key,
    check:checkLocation,progress:progressLocation,source:'original GetProgress for the exact owned compiler after Build'};
   ownedCurrentSourceBindings.set(backend.toString(),binding);send(binding);
   Interceptor.attach(check,{
    onEnter(a){if(!a[0].equals(backend))return;
     ownedSourceCheckEver=true;ownedCurrentSourceProgress=true;phase='source-check';
     send({event:'owned-current-source-check-enter',backend:a[0].toString(),
      count:a[2].toInt32(),units_pointer:a[3].toString(),binding});}
   });
   Interceptor.attach(progress,{
    onEnter(a){this.owned=ownedCurrentSourceProgress&&phase==='source-check'&&
      a[0].equals(backend)&&this.threadId===ownedCurrentBuildThread;
     if(!this.owned){
      if(ownedCurrentSourceProgress&&phase==='source-check')send({event:'owned-current-source-unselected-progress',
       observed_self:a[0].toString(),selected_self:backend.toString(),thread:this.threadId,
       selected_thread:ownedCurrentBuildThread,output_handling:'unselected call outputs not interpreted'});
      return;
     }
     this.self=a[0];this.percent=a[1];this.count=a[2];this.reports=a[3];this.code=a[4];},
    onLeave(r){if(!this.owned)return;try{
     if(r.toInt32()<0||this.code.readU32()!==0){send({event:'owned-current-source-progress-failure',
      hresult:r.toInt32(),code:this.code.readU32(),reports:[],
      output_handling:'failed output pointers not interpreted'});return;}
     const count=this.count.readS32(),data=this.reports.readPointer(),reports=[];
     if(count<0||count>10000||(count>0&&data.isNull()))throw new Error('current source diagnostic count bound');
     for(let i=0;i<count;i++)reports.push(backendReport(data.add(i*68)));
     send({event:'owned-current-source-progress',hresult:r.toInt32(),code:this.code.readU32(),
      percent:this.percent.readS32(),count,reports});
     if(this.percent.readS32()===100)ownedCurrentSourceProgress=false;
    }catch(e){send({event:'observation-error',phase:'current-source-progress',error:String(e),
     self:this.self.toString(),count:this.count.readS32(),percent:this.percent.readS32(),
     reports_pointer:this.reports.readPointer().toString()});}}
   });
  }catch(e){send({event:'observation-error',phase:'current-source-backend-binding',error:String(e)});}
 }});
}});
'''


def adapt(path):
    ORIGINAL_ADAPT(path)
    anchor='            if(plan.ContainsKey("program_check_kind")&&!compilerRejected) {'
    text=path.read_text(encoding='utf-8')
    polling='            bool compilerRejected=WaitReports(compiler,changeSfc?168:40,"Progress",false,changeSfc);'
    if text.count(polling)!=1:
        raise ValueError('Exact owned compiler build polling gate differs')
    text=text.replace(polling,'''            OwnedDrainGate("GXW_OWNED_CURRENT_BUILD:"+compiler.ToString("x8"));
'''+polling+'''
            OwnedDrainGate("GXW_OWNED_CURRENT_BUILD_END");''')
    if text.count(anchor)!=1:
        raise ValueError('Current source Check insertion site differs')
    text=text.replace(anchor,'''            if(plan.ContainsKey("owned_current_source_selection")&&!compilerRejected) {
                bool sourceCompleted;
                bool sourceRejected=CheckCurrentNativeSources(
                    compiler,(Dictionary<string,object>)plan["owned_current_source_selection"],out sourceCompleted);
                Record(new {operation="CurrentSourceCheck.AcceptanceObserved",rejected=sourceRejected,
                    execution_completion=sourceCompleted?"completed":"incomplete",
                    acceptance=sourceRejected?"rejected":sourceCompleted?"accepted":"not_established",
                    public_program_check_promoted=false});
            }
'''+anchor)
    path.write_text(text,encoding='utf-8')
    shutil.copyfile(P/SOURCE,path.parent/SOURCE)
    plan= json.loads((path.parent/'plan.json').read_text(encoding='utf-8'))
    plan['owned_current_source_selection']=QUERY
    trace.save(path.parent/'plan.json',plan)


ORIGINAL_ADAPT=drain.adapt_helper
QUERY=None


def run_case(directory,frozen,raw):
    def handoff(value,data):
        row=value.get('payload',{})
        if row.get('event')!='owned-current-source-backend-bound':return
        output=directory/'current-source-backend.json'
        if output.exists():
            previous=json.loads(output.read_text(encoding='utf-8'))
            if previous['backend']!=row['backend']:
                raise ValueError('More than one backend reached the current compile polling stage')
            return
        temp=directory/'current-source-backend.tmp'
        trace.save(temp,row);os.replace(temp,output)
        (directory/'current-source-backend.json.ready').write_text('closed-input',encoding='utf-8')
    original=trace.run
    def observed_run(*args,**kwargs):
        existing=kwargs.pop('on_message',None)
        def receive(value,data):
            handoff(value,data)
            if existing is not None:existing(value,data)
        return original(*args,on_message=receive,**kwargs)
    trace.run=observed_run
    try:
        result=drain.run(directory,frozen,raw)
    finally:
        trace.run=original
    native=[json.loads(line) for line in (directory/'native-events.jsonl').read_text(
        encoding='utf-8-sig').splitlines()]
    messages=[json.loads(line) for line in (directory/'observation-events.jsonl').read_text(
        encoding='utf-8').splitlines()]
    observed=[row['payload'] for row in messages if row.get('type')=='send']
    result.update(query=QUERY,source_bytes_exact=(directory/'input.gxw').read_bytes()==raw,
        current_source_events=[row for row in native if row.get('operation','').startswith('CurrentSourceCheck.')],
        source_observations=[row for row in observed if 'source-' in row.get('event','')],
        current_source_reports=[report for row in observed if row.get('event')=='owned-current-source-progress'
            for report in row['reports'] if report['kind'] in (2,3)],
        original_public_program_check_promoted=False)
    trace.save(directory/'result-with-current-source-check.json',result)
    return result


def main():
    global QUERY
    sys.stdout.reconfigure(encoding='utf-8')
    OUT.mkdir(exist_ok=False)
    for name in (Path(__file__).name,SOURCE):shutil.copyfile(P/name,OUT/name)
    prior=[row for row in json.loads((P/'diag-cpu-20261002-v1/results.json').read_text(
        encoding='utf-8')) if row['returncode']!=5]
    applications=json.loads((trace.A/'native-results.json').read_text(encoding='utf-8'))
    prepare,adapt_helper,cs=trace.prepare,drain.adapt_helper,trace.CS
    def prepare_current(*args,**kwargs):
        active=trace.CS
        trace.CS=cs
        try:
            return prepare(*args,**kwargs)+dispatch.OBSERVER+BACKEND_OBSERVER+units.OBSERVER
        finally:
            trace.CS=active
    trace.prepare=prepare_current
    drain.adapt_helper=adapt
    trace.CS=cs+(SOURCE,)
    results=[]
    try:
        for index,(cpu,label,names) in enumerate(CASES):
            input_case=next(row for row in prior if row['cpu']==cpu)
            application=next(row for row in applications if row['cpu']==cpu)
            raw=(Path(input_case['directory'])/'input.gxw').read_bytes()
            frozen=Path(application['application_case'])/'native-compile'
            QUERY=dict(kind=6,selections=[dict(row=-1,name=name) for name in names],wide_progress=WIDE_PROGRESS)
            for attempt in range(1,17):
                directory=OUT/f'c{index:02d}-{label}-a{attempt}'
                result=run_case(directory,frozen,raw)
                result.update(cpu=cpu,label=label,original_input=str(Path(input_case['directory'])/'input.gxw'))
                results.append(result);trace.save(OUT/'results.json',results)
                detail=dict(cpu=cpu,label=label,attempt=attempt,returncode=result['returncode'],
                    source_execution=[row for row in result['current_source_events'] if row['operation'] not in (
                        'CurrentSourceCheck.Progress',)],
                    source_reports=result['current_source_reports'],
                    source_workers=[row for row in result['source_observations'] if row['event'] in (
                        'native-source-worker-enter','native-source-unit-enter','native-source-worker-return')],
                    public_check=result['public_check'],observation_errors=result['observation_errors'])
                if not VERBOSE:
                    detail=dict(cpu=cpu,label=label,attempt=attempt,returncode=result['returncode'],
                        source_outcome=[row for row in result['current_source_events'] if row['operation']==
                            'CurrentSourceCheck.AcceptanceObserved'],source_report_count=len(result['current_source_reports']),
                        checker=result['checker_read_correspondence'],observation_errors=result['observation_errors'])
                print(json.dumps(detail,ensure_ascii=False),flush=True)
                if result['returncode']!=5:break
    finally:
        trace.prepare,drain.adapt_helper,trace.CS=prepare,adapt_helper,cs


if __name__=='__main__':
    main()
