// Format copied UserInfo records after a real frontend obtains ESDeviceCode.
// The descriptor stays native-owned. Only private formatter/input copies change.
const assignmentInputs = __ASSIGNMENT_INPUTS__;
let assignmentDone=false;
function bytesHex(pointer,size) {
  return Array.from(new Uint8Array(pointer.readByteArray(size))).map(v=>v.toString(16).padStart(2,'0')).join('');
}
function formatInlineAssignments(cpuDescriptor) {
  if(assignmentDone||cpuDescriptor.isNull())return;
  assignmentDone=true;
  const compiler=Process.findModuleByName('ECCompiler.dll')||Module.load('D:/GXWORKS2/Easysocket/Compiler/ECCompiler.dll');
  if(bytesHex(compiler.base.add(0x51650),8)!=='64a1000000006aff' ||
     bytesHex(compiler.base.add(0x5167e),6)!=='8a063c070f85')throw new Error('Uninspected native formatter entry');
  const ctor=new NativeFunction(compiler.base.add(0x46fb0),'pointer',['pointer'],'thiscall');
  const destroy=new NativeFunction(compiler.base.add(0x47130),'void',['pointer'],'thiscall');
  const textCtor=new NativeFunction(compiler.base.add(0x6b90),'pointer',['pointer'],'thiscall');
  const textDestroy=new NativeFunction(compiler.base.add(0x11024c).readPointer(),'void',['pointer'],'thiscall');
  const format=new NativeFunction(compiler.base.add(0x51650),'void',['pointer','pointer','pointer','pointer'],'thiscall');
  const object=Memory.alloc(0x68c);object.writeByteArray(new Uint8Array(0x68c));ctor(object);
  if(!object.add(0x3a2).readPointer().isNull())throw new Error('Unexpected private constructor state');
  object.add(0x3a2).writePointer(cpuDescriptor);
  send({event:'inline-assignment-context',descriptor:cpuDescriptor.toString(),descriptor_head:bytesHex(cpuDescriptor,32),formatter_module:compiler.path,records:assignmentInputs.length});
  try {
    assignmentInputs.forEach((entry,index)=>{
      const raw=entry.raw.match(/../g).map(v=>parseInt(v,16));
      if(raw.length!==26||raw[0]!==7||raw.some((v,i)=>(i>=1&&(i<9||(i>=13&&i<21)||i>=22))&&v!==0))throw new Error('Inline input outside inspected form');
      if(!'KMDW'.includes(String.fromCharCode(raw[21]).toUpperCase()))throw new Error('Inline family outside inspected form');
      const user=Memory.alloc(26),text=Memory.alloc(12);user.writeByteArray(raw);textCtor(text);
      try {
        format(object,ptr(0),user,text);
        const chars=text.add(4).readPointer();const length=chars.readCString(4096).length;
        if(length>=4096)throw new Error('Native output outside bound');
        send({event:'inline-assignment-format',index,input_hex:entry.raw,output_hex:bytesHex(chars,length),after_hex:bytesHex(user,26)});
      } finally {textDestroy(text.add(4));}
    });
  } finally {object.add(0x3a2).writePointer(ptr(0));destroy(object);}
}
function attachAssignmentContext() {
  const module=Process.findModuleByName('DZDataABS_DataManager_IEC.dll');
  if(!module)return false;
  const getter=module.findExportByName('?GetESDeviceCode@CDZDataABS_OnMemoryDataManager@@QAEPAVESDeviceCode@@XZ');
  if(!getter)throw new Error('Native device descriptor getter absent');
  Interceptor.attach(getter,{onLeave(retval){
    if(!retval.isNull()&&!assignmentDone){
      try{formatInlineAssignments(retval);}catch(error){send({event:'inline-assignment-error',message:String(error),stack:error.stack});}
    }
  }});
  send({event:'inline-assignment-attached',module:module.path});
  return true;
}
if(!attachAssignmentContext()) {
  const timer=setInterval(()=>{if(attachAssignmentContext())clearInterval(timer);},10);
}
