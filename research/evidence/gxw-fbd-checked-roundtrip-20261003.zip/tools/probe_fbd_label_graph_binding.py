"""Prospective source-only FBD label/geometry proposals and fresh native checks."""
from pathlib import Path
from dataclasses import replace
import json
import sys

P = Path(__file__).resolve().parent
ROOT = P.parents[3]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'research'), str(P)]
from gxw.container_writer import validate_cfb_streams
from gxw.project_writer import replace_project_stream
from gxw.project_metadata import logical_mapping, mark_observed_source_compile_pending, current_rows
from gxw.declarations import edit_declarations, serialize_declarations
from gxw.structured_pou_writer import serialize_structured_pou, serialize_structured_node
from gxw.models import Point, GXWFormatError
from source_fbd_interfaces import SourceGraph
from probe_fx1s_lossless_project_patch import native_run
from probe_fx_operand_rules import traced_run

OUT = P/'fbd-label-graph-binding-20261001-v2'
SOURCE = P/'native-graph-inout-v2/base/source.gxw'


def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=True)+'\n')


def patch(raw, replacements):
    outer = validate_cfb_streams(raw)
    mapping = logical_mapping(outer['projectdatalist.xml'])
    inner = validate_cfb_streams(outer['_hdb'])
    hdb = outer['_hdb']
    allocations = []
    for name, value in replacements.items():
        if name not in mapping or mapping[name] not in inner:
            raise GXWFormatError('unresolved source proposal target')
        hdb, mode = replace_project_stream(hdb, mapping[name], value)
        allocations.append(dict(logical=name, mode=mode, delta=len(value)-len(inner[mapping[name]])))
    candidate, mode = replace_project_stream(raw, '_hdb', hdb)
    # The source buffers provided by the native project importer use the current
    # history sizes. Keep the original XML and all digest fields; adjust only
    # the source-bound decimal lengths. No new digest calculation/validation.
    rows, encoding = current_rows(outer['history.xml'], 'DSHISTORY', 'D_History')
    changes = []
    for name, value in replacements.items():
        hits = [r.fields() for r in rows if r.fields().get('iProjectdataID')
                and r.fields()['iProjectdataID'].text.strip()==mapping[name]]
        if len(hits)!=1 or hits[0]['szProjectdataName'].text.strip()!=name:
            raise GXWFormatError('source proposal has no unique current history row')
        field = hits[0]['iFileSize']
        if field.text.strip()!=str(len(inner[mapping[name]])):
            raise GXWFormatError('original source length and current history size differ')
        if len(value)!=len(inner[mapping[name]]):
            changes.append((field.content_start,field.content_end,str(len(value)).encode(encoding)))
    history = outer['history.xml']
    for start,end,value in sorted(changes,reverse=True):
        history = history[:start]+value+history[end:]
    if history!=outer['history.xml']:
        candidate, history_mode = replace_project_stream(candidate,'history.xml',history)
    else:
        history_mode = 'unchanged'
    expected_inner = dict(inner)
    expected_inner.update({mapping[k]:v for k,v in replacements.items()})
    expected_outer = dict(outer, _hdb=hdb)
    expected_outer['history.xml'] = history
    if validate_cfb_streams(hdb) != expected_inner or validate_cfb_streams(candidate) != expected_outer:
        raise GXWFormatError('proposal touched unrelated original stream payloads')
    return candidate, dict(allocations=allocations, outer_allocation=mode,
                          history_size_fields_updated=len(changes), history_allocation=history_mode,
                          untouched_inner_streams=len(inner)-len(replacements), untouched_outer_streams=len(outer)-1-int(bool(changes)),
                          unrelated_payloads_exact=True)


def endpoint(reader, node, side, formal, occurrence=1):
    hits = [p for p in reader.callable(node)['ports'] if p['side']==side
            and p['name']==formal and p['occurrence']==occurrence]
    if len(hits) != 1:
        raise GXWFormatError('formal endpoint is absent or ambiguous')
    return node.port_point(hits[0]['index'])


def prepare():
    OUT.mkdir()
    for name in ('source_fbd_interfaces.py', Path(__file__).name):
        (OUT/name).write_bytes((P/name).read_bytes())
    raw = SOURCE.read_bytes()
    reader = SourceGraph(raw, '1.Program.pou')
    source = reader.program
    local = reader.declarations['1.Labels.lh']
    glob = reader.declarations['Global1.gh']
    for case in ('original', 'rename-instance', 'grow-instance', 'rename-label-only', 'rename-graph-only',
                 'declaration-type-conflict', 'local-shadows-global', 'global-instance',
                 'named-global-terminal', 'named-port-bend', 'inout-output-binding'):
        directory = OUT/case
        directory.mkdir()
        nodes = list(source.nodes)
        wires = list(source.wires)
        replacements = {}
        expected = 'accepted'
        changed_documents = {}
        if case in ('rename-instance', 'grow-instance', 'rename-label-only', 'rename-graph-only'):
            renamed = 'SEQUENCE_DELAY_STAGE_A' if case=='grow-instance' else 'CYCLE_A'
            if case != 'rename-label-only':
                nodes = [replace(n, symbol=renamed) if n.symbol=='TIMER_A' else n for n in nodes]
            if case != 'rename-graph-only':
                changed_documents['1.Labels.lh'] = edit_declarations(local, renames={'TIMER_A':renamed})
            if case in ('rename-label-only', 'rename-graph-only'):
                expected = 'rejected'
        elif case=='declaration-type-conflict':
            changed_documents['1.Labels.lh'] = edit_declarations(local, upserts=[dict(name='TIMER_A', data_type='TON', kind='function_block')])
            expected = 'type-conflict-observe-native-without-assuming-acceptance'
        elif case=='local-shadows-global':
            changed_documents['Global1.gh'] = edit_declarations(glob, upserts=[dict(name='TIMER_A', data_type='TON', kind='function_block')])
        elif case=='global-instance':
            changed_documents['1.Labels.lh'] = edit_declarations(local, remove=['TIMER_A'])
            changed_documents['Global1.gh'] = edit_declarations(glob, upserts=[dict(name='TIMER_A', data_type='FLOW_PORTS', kind='function_block')])
        elif case=='named-global-terminal':
            nodes = [replace(n, symbol='Ready') if n.symbol=='X0' else n for n in nodes]
            changed_documents['Global1.gh'] = edit_declarations(glob, upserts=[dict(name='Ready', data_type='BOOL', device='X0')])
        elif case=='named-port-bend':
            a, = [n for n in nodes if n.symbol=='TIMER_A']
            b, = [n for n in nodes if n.symbol=='TIMER_B']
            moved = replace(b, bbox=replace(b.bbox, top=b.bbox.top+1, bottom=b.bbox.bottom+1))
            nodes = [moved if n==b else replace(n, bbox=replace(n.bbox, top=n.bbox.top+1, bottom=n.bbox.bottom+1))
                     if n.symbol in ('D20','Y0') else n for n in nodes]
            start = endpoint(reader, a, 'out', 'RESULT')
            end = endpoint(reader, moved, 'in', 'SIGNAL')
            previous = endpoint(reader, b, 'in', 'SIGNAL')
            link, = [w for w in wires if {w.start,w.end}=={start,previous}]
            wires.remove(link)
            path = [start, Point(16,start.y), Point(16,end.y), end]
            offset = max(r.offset for r in source.iter_records())+1
            wires += [replace(link, offset=offset+i, start=s, end=e) for i,(s,e) in enumerate(zip(path,path[1:]))]
        elif case=='inout-output-binding':
            a, = [n for n in nodes if n.symbol=='TIMER_A']
            terminal, = [n for n in nodes if n.symbol=='Y0']
            output = replace(terminal, offset=max(r.offset for r in source.iter_records())+1, symbol='D30',
                             bbox=replace(terminal.bbox,left=13,top=4,right=15,bottom=6))
            assert endpoint(reader,a,'out','STATE') == output.port_point(0)
            assert endpoint(reader,a,'in','STATE') != output.port_point(0)
            nodes.append(output)
        if nodes != list(source.nodes) or wires != list(source.wires):
            program = replace(source, nodes=tuple(nodes), wires=tuple(wires), record_count=len(nodes)+len(wires))
            # Existing controls have one block; retain the block header and add
            # new record membership without inventing object references.
            program = replace(program, blocks=(replace(source.blocks[0],record_offsets=tuple(
                r.offset for r in sorted([*nodes,*wires],key=lambda r:r.offset))),))
            replacements[source.logical_name] = mark_observed_source_compile_pending(serialize_structured_pou(program),logical_name=source.logical_name)
        for name,d in changed_documents.items():
            replacements[name] = mark_observed_source_compile_pending(serialize_declarations(d),logical_name=name)
        candidate, receipt = patch(raw, replacements) if replacements else (raw, dict(unrelated_payloads_exact=True))
        (directory/'source.gxw').write_bytes(candidate)
        projected = SourceGraph(candidate, source.logical_name).view()
        proposal = dict(case=case, expected=expected, source_file=str(SOURCE), changed_streams=list(replacements),
                        preservation=receipt, source_view=projected,
                        semantics_preserved_candidate=case in ('original','rename-instance','grow-instance','named-port-bend'))
        save(directory/'proposal-before-native.json',proposal)
        print(json.dumps(dict(prepared=case,expected=expected,source_gaps=projected['gaps'])),flush=True)


def observe(directory, plan, export, check=True, attempt=1):
    native = directory/('native-'+str(attempt))
    prepared = native_run(directory/'source.gxw',native,plan,compile=True,export=export,
                          check=check,alias='FBDLABELS',prepare_only=True)
    hook = (P/'TraceCallableFormals.js').read_text()
    (native/'source-interface-observer.js').write_text(hook)
    traced_run([prepared['executable'],prepared['plan_file']],hook,native,timeout=50)
    events = [json.loads(l) for l in (native/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    traces = [json.loads(l) for l in (native/'events.jsonl').read_text().splitlines()]
    diagnostics = {json.dumps({k:v for k,v in d.items() if k!='raw_base64'},sort_keys=True)
                   for e in events for d in e.get('reports',[]) if d['kind'] in (2,3)}
    failures = [e for e in events if e.get('hresult',0)<0 or e.get('code',0)!=0]
    formals = [e['payload'] for e in traces if e.get('payload',{}).get('event')=='native-callable-formals']
    errors = [e for e in traces if e.get('type')=='error' or e.get('payload',{}).get('event','').endswith(('failed','error'))]
    if any(e.get('operation')=='NativeTemporaryDirectoryCollision' for e in events):
        raise RuntimeError('Native temporary-directory collision retained; choose a new owned attempt')
    reader = SourceGraph((directory/'source.gxw').read_bytes(),'1.Program.pou')
    comparisons = []
    for observed in formals:
        n = observed['node']
        if n is None:
            continue
        candidates = [x for x in reader.program.nodes if x.symbol==n['symbol'] and
                      (x.type_name if x.kind_code==2 else x.symbol)==n['type']]
        if len(candidates)!=1:
            comparisons.append(dict(symbol=n['symbol'],gap='Native node cannot bind to exact source node'))
            continue
        try:
            predicted = reader.callable(candidates[0])
        except GXWFormatError as e:
            comparisons.append(dict(symbol=n['symbol'],source_gap=str(e),
                                    native_formals_empty=not observed['formals']))
            continue
        keys = ('name','class_code','type_code')
        a = [{k:p[k] for k in keys} for p in predicted['ports']]
        b = [{k:p[k] for k in keys} for p in observed['formals']]
        comparisons.append(dict(symbol=n['symbol'],formals_exact=a==b,
                                source_ports=[p['index'] for p in predicted['ports']]))
    sources = []
    for e in traces:
        row = e.get('payload',{})
        if row.get('event')!='enter' or row.get('name')!='Compile':
            continue
        buffers = {b['label']:b for b in row['buffers']}
        for k,b in buffers.items():
            if k.startswith('source_') and b['bytes']:
                value = bytes.fromhex(b['bytes'])
                if len(value)!=b['requested_size']:
                    raise RuntimeError('Truncated native SIC buffer')
                name = bytes.fromhex(buffers['name_'+k[7:]]['bytes']).split(b'\0')[0].decode('ascii')
                filename = 'compile-'+str(row['id'])+'-'+k[7:]+'.sic'
                (directory/filename).write_bytes(value)
                if name=='1':
                    sources.append(dict(file=filename,text=value.decode('ascii',errors='backslashreplace')))
    checks = [e for e in events if e.get('operation')=='ProgramCheckCompleted']
    codes = {x.name:x.read_bytes().hex() for x in native.glob('pcode-*-*.bin')}
    saved = native/'native-saved.gxw'
    row = dict(case=directory.name,native_directory=str(native),input_unchanged=(native/'input.gxw').read_bytes()==(directory/'source.gxw').read_bytes(),
               compiled=any(e.get('operation')=='Progress' and e.get('percent')==100 for e in events),
               diagnostics=[json.loads(d) for d in sorted(diagnostics)],failures=failures,checks=checks,
               formal_comparisons=comparisons,observation_errors=errors,sic=sources,pcode=codes,exported=saved.exists())
    if saved.exists():
        reopened_reader = SourceGraph(saved.read_bytes(),'1.Program.pou')
        row['saved_node_records_exact'] = [serialize_structured_node(n) for n in reader.program.nodes]==[
            serialize_structured_node(n) for n in reopened_reader.program.nodes]
        row['saved_wires_exact'] = [(w.start,w.end,w.prefix_fields,w.suffix) for w in reader.program.wires]==[
            (w.start,w.end,w.prefix_fields,w.suffix) for w in reopened_reader.program.wires]
        row['saved_labels_exact'] = {k:[r.raw.hex() for r in d.rows] for k,d in reader.declarations.items()}=={
            k:[r.raw.hex() for r in d.rows] for k,d in reopened_reader.declarations.items()}
        reopen = directory/('reopen-'+str(attempt))
        again = native_run(saved,reopen,plan,compile=True,export=False,check=False,alias='FBDLABELS')
        row['reopen'] = again
        row['reopen_code_exact'] = codes=={x.name:x.read_bytes().hex() for x in reopen.glob('pcode-*-*.bin')}
    expected = directory/'expected-original-pcode-0.bin'
    if expected.exists():
        row['unchanged_semantics_pcode_exact'] = codes.get('pcode-0-0.bin')==expected.read_bytes().hex()
    save(directory/'comparison.json',row)
    print(json.dumps({k:v for k,v in row.items() if k not in ('sic','pcode','reopen','failures','checks')},ensure_ascii=True),flush=True)
    return row


def main():
    if sys.argv[1:]==['prepare']:
        prepare()
        return
    plan = json.loads((P/'native-graph-inout-v2/base/native/plan.json').read_text())
    plan['project_owned_compiler'] = True
    rows=[]
    for case in sys.argv[1:]:
        directory = OUT/case
        if not (directory/'proposal-before-native.json').exists():
            raise ValueError('choose explicitly prepared proposals')
        proposal = json.loads((directory/'proposal-before-native.json').read_text())
        for attempt in range(1,5):
            if (directory/('native-'+str(attempt))).exists():
                continue
            try:
                rows.append(observe(directory,plan,export=proposal['expected']=='accepted',attempt=attempt))
                break
            except RuntimeError as e:
                if 'temporary-directory collision' not in str(e):
                    raise
        else:
            raise RuntimeError('Four retained native attempts exhausted')
        save(OUT/'latest-batch.json',rows)


if __name__=='__main__':
    main()
