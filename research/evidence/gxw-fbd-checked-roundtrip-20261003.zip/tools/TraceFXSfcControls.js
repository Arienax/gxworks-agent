'use strict';
// This script is appended to TraceFXSfcTokens.js, sharing the owned input.
Process.attachModuleObserver({onAdded(m) {
    if(m.name.toLowerCase() !== 'eccodegeneratorfx2.dll') return;
    for(const [rva,kind,sourceAt,cursorAt] of [
        [0x5f435,'step',5,6],[0x5f6aa,'transition',4,5],
        [0x5f5b8,'selective_target',2,3],[0x5f631,'parallel_target',2,3],[0x5f784,'target',2,3]]) {
        Interceptor.attach(m.base.add(rva),{
            onEnter(a) {
                this.emit=sfcInput !== null && a[sourceAt].equals(sfcInput);
                if(!this.emit)return;
                this.cursor=a[cursorAt];this.ptrs={key:a[0],number:a[1]};
                if(kind==='step')Object.assign(this.ptrs,{substep:a[2],program_length:a[3],program_offset:a[4]});
                if(kind==='transition')Object.assign(this.ptrs,{program_length:a[2],program_offset:a[3]});
                this.read=()=>Object.fromEntries(Object.entries(this.ptrs).map(([k,p])=>[k,k==='program_offset'?p.readU32():p.readU16()]));
                this.row={event:'sfc-control',kind:kind,offset:this.cursor.readU32(),initial:this.read()};
            },
            onLeave(r) {
                if(!this.emit)return;
                Object.assign(this.row,{result:sfcShort(r),offset_after:this.cursor.readU32(),fields:this.read()});
                send(this.row);
            }
        });
    }
}});
