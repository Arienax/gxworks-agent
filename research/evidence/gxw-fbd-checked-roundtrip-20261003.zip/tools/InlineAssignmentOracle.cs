// Isolated native UserInfo formatter with a native-owned CPU descriptor.
// No project, source build, simulator or device-operation API is invoked.
using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;

public static class InlineAssignmentOracle {
    [DllImport("kernel32.dll", CharSet=CharSet.Unicode)] static extern IntPtr LoadLibraryEx(string path, IntPtr file, uint flags);
    [DllImport("kernel32.dll", CharSet=CharSet.Unicode)] static extern bool SetDllDirectory(string path);
    [DllImport("kernel32.dll", CharSet=CharSet.Ansi)] static extern IntPtr GetProcAddress(IntPtr module, string name);
    [DllImport("kernel32.dll")] static extern uint SetErrorMode(uint mode);
    [DllImport("ole32.dll")] static extern int CoInitializeEx(IntPtr reserved, uint mode);
    [UnmanagedFunctionPointer(CallingConvention.ThisCall)] delegate IntPtr Construct(IntPtr self);
    [UnmanagedFunctionPointer(CallingConvention.ThisCall)] delegate void Destroy(IntPtr self);
    [UnmanagedFunctionPointer(CallingConvention.ThisCall)] delegate int Initialize(IntPtr self, int cpu, IntPtr path);
    [UnmanagedFunctionPointer(CallingConvention.ThisCall)] delegate IntPtr GetDevice(IntPtr self);
    [UnmanagedFunctionPointer(CallingConvention.ThisCall)] delegate void Format(IntPtr self, IntPtr table, IntPtr userInfo, IntPtr text);
    static T At<T>(IntPtr address) where T:class {
        return Marshal.GetDelegateForFunctionPointer(address, typeof(T)) as T;
    }
    static T Export<T>(IntPtr module, string name) where T:class {
        IntPtr address=GetProcAddress(module,name);
        if(address==IntPtr.Zero)throw new Exception("Missing export: "+name);
        return At<T>(address);
    }
    static void Guard(IntPtr module,int rva,byte[] expected) {
        for(int i=0;i<expected.Length;i++)
            if(Marshal.ReadByte(module,rva+i)!=expected[i])throw new Exception("Native entry bytes differ: "+rva.ToString("x"));
    }
    [STAThread] public static int Main(string[] args) {
        if(IntPtr.Size!=4||args.Length!=6)return 2;
        SetErrorMode(3);
        if(CoInitializeEx(IntPtr.Zero,2)<0)throw new Exception("COM initialization failed");
        if(FileVersionInfo.GetVersionInfo(args[0]).FileVersion!="15.22")throw new Exception("Uninspected formatter version");
        SetDllDirectory(Path.GetDirectoryName(args[1]));
        IntPtr memoryModule=LoadLibraryEx(args[1],IntPtr.Zero,8);
        IntPtr module=LoadLibraryEx(args[0],IntPtr.Zero,8);
        if(module==IntPtr.Zero||memoryModule==IntPtr.Zero)throw new Exception("Native load failed");
        Guard(module,0x51650,new byte[]{0x64,0xa1,0,0,0,0,0x6a,0xff});
        Guard(module,0x5167e,new byte[]{0x8a,0x06,0x3c,0x07,0x0f,0x85});
        Construct memoryCtor=Export<Construct>(memoryModule,"??0CDZDataABS_OnMemoryDataManager@@QAE@XZ");
        Destroy memoryDestroy=Export<Destroy>(memoryModule,"??1CDZDataABS_OnMemoryDataManager@@QAE@XZ");
        Initialize init=Export<Initialize>(memoryModule,"?Initialize@CDZDataABS_OnMemoryDataManager@@QAEJJPBD@Z");
        GetDevice device=Export<GetDevice>(memoryModule,"?GetESDeviceCode@CDZDataABS_OnMemoryDataManager@@QAEPAVESDeviceCode@@XZ");
        Construct ctor=At<Construct>(IntPtr.Add(module,0x46fb0)),textCtor=At<Construct>(IntPtr.Add(module,0x6b90));
        Destroy destroy=At<Destroy>(IntPtr.Add(module,0x47130));
        Destroy textDestroy=At<Destroy>(Marshal.ReadIntPtr(module,0x11024c));
        Format format=At<Format>(IntPtr.Add(module,0x51650));
        IntPtr memory=Marshal.AllocHGlobal(4096),obj=Marshal.AllocHGlobal(0x68c),user=Marshal.AllocHGlobal(26),text=Marshal.AllocHGlobal(12);
        IntPtr work=Marshal.StringToHGlobalAnsi(args[3]);
        Marshal.Copy(new byte[4096],0,memory,4096);Marshal.Copy(new byte[0x68c],0,obj,0x68c);
        memoryCtor(memory);ctor(obj);
        try {
            int code=init(memory,int.Parse(args[2]),work);
            Console.WriteLine("Memory.Initialize="+code);
            if(code!=0)throw new Exception("Native CPU descriptor initialization failed");
            IntPtr cpu=device(memory);
            if(cpu==IntPtr.Zero)throw new Exception("Native CPU descriptor missing");
            // Static formatter references ESDeviceCode at +0x3a2. The real
            // descriptor is initialized and owned by the memory manager;
            // only this private isolated formatter object receives the pointer.
            if(Marshal.ReadIntPtr(obj,0x3a2)!=IntPtr.Zero)throw new Exception("Unexpected constructor state");
            Marshal.WriteIntPtr(obj,0x3a2,cpu);
            using(StreamWriter rows=new StreamWriter(args[5])) {
                foreach(string line in File.ReadAllLines(args[4])) {
                    byte[] raw=Convert.FromBase64String(line);
                    if(raw.Length!=26||raw[0]!=7)throw new Exception("Outside inspected inline form");
                    for(int i=1;i<26;i++)
                        if((i<9||(i>=13&&i<21)||i>=22)&&raw[i]!=0)throw new Exception("Inline modifiers outside profile");
                    char prefix=Char.ToUpperInvariant((char)raw[21]);
                    if("KMDW".IndexOf(prefix)<0)throw new Exception("Outside measured inline families");
                    Marshal.Copy(raw,0,user,26);textCtor(text);
                    try {
                        format(obj,IntPtr.Zero,user,text);
                        IntPtr chars=Marshal.ReadIntPtr(text,4);int length=0;
                        while(length<4096&&Marshal.ReadByte(chars,length)!=0)length++;
                        if(length==4096)throw new Exception("Native text exceeds bound");
                        byte[] result=new byte[length],after=new byte[26];
                        Marshal.Copy(chars,result,0,length);Marshal.Copy(user,after,0,26);
                        rows.WriteLine("{\"input_base64\":\""+line+"\",\"output_base64\":\""+Convert.ToBase64String(result)+"\",\"after_base64\":\""+Convert.ToBase64String(after)+"\"}");
                        rows.Flush();
                    } finally {textDestroy(IntPtr.Add(text,4));}
                }
            }
        } finally {
            Marshal.WriteIntPtr(obj,0x3a2,IntPtr.Zero);
            destroy(obj);memoryDestroy(memory);
            Marshal.FreeHGlobal(work);Marshal.FreeHGlobal(memory);Marshal.FreeHGlobal(obj);Marshal.FreeHGlobal(user);Marshal.FreeHGlobal(text);
        }
        return 0;
    }
}
