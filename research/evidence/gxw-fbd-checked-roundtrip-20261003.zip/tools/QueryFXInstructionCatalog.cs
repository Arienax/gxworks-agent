// Public read-only descriptor queries for the inspected FX 15.31 ABI.
using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

public static class QueryFXInstructionCatalog {
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode)] static extern IntPtr LoadLibraryEx(string path,IntPtr file,uint flags);
    [DllImport("kernel32.dll",CharSet=CharSet.Ansi,ExactSpelling=true)] static extern IntPtr GetProcAddress(IntPtr module,string name);
    [DllImport("kernel32.dll")] static extern uint SetErrorMode(uint mode);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate IntPtr Create();
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Open(IntPtr h,int cpu,int mode);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Version(IntPtr h,int count,[In] uint[] versions);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Close(IntPtr h);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate void Destroy(IntPtr h);
    // 3cd6 -> 2700 -> 5a7e -> 3c387; 5a7e copies exactly 10 bytes.
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Find(IntPtr h,int family,int variant,IntPtr descriptor);
    static T Export<T>(IntPtr m,string n) where T:class {
        IntPtr p=GetProcAddress(m,n);if(p==IntPtr.Zero)throw new Exception(n);
        return Marshal.GetDelegateForFunctionPointer(p,typeof(T)) as T;
    }
    public static int Main(string[] args) {
        if(IntPtr.Size!=4||args.Length!=3)return 2;
        SetErrorMode(3);
        if(FileVersionInfo.GetVersionInfo(args[0]).FileVersion!="15.31")throw new Exception("Uninspected FX version");
        IntPtr m=LoadLibraryEx(args[0],IntPtr.Zero,8);if(m==IntPtr.Zero)throw new Exception("Load failed");
        uint moduleBase=unchecked((uint)m.ToInt32());int peOffset=Marshal.ReadInt32(m,0x3c);
        uint moduleSize=unchecked((uint)Marshal.ReadInt32(m,peOffset+0x50));
        Create create=Export<Create>(m,"ObjectNew");Open open=Export<Open>(m,"Open");
        Version version=Export<Version>(m,"SetVersion");Close close=Export<Close>(m,"Close");Destroy destroy=Export<Destroy>(m,"ObjectDelete");
        Find find=Export<Find>(m,"FindInstructionList");IntPtr h=create();
        if(h==IntPtr.Zero)throw new Exception("Create failed");
        IntPtr area=Marshal.AllocHGlobal(74);byte[] initial=new byte[74];
        for(int i=0;i<74;i++)initial[i]=(byte)((i>=32&&i<42)?0:0xA5);
        try {
            int code=open(h,521,0);if(code!=0)throw new Exception("Open "+code);
            code=version(h,0,new uint[0]);if(code!=0)throw new Exception("Version "+code);
            using(StreamWriter output=new StreamWriter(args[2])) {
                foreach(string line in File.ReadLines(args[1])) {
                    string[] parts=line.Split('\t');if(parts.Length!=3)throw new Exception("Request framing");
                    int id=int.Parse(parts[0]),family=int.Parse(parts[1]),variant=int.Parse(parts[2]);
                    if(family<0||family>121||variant<0||variant>249)throw new Exception("Outside inspected prefix graph");
                    Marshal.Copy(initial,0,area,initial.Length);
                    code=find(h,family,variant,IntPtr.Add(area,32));
                    byte[] whole=new byte[74];Marshal.Copy(area,whole,0,whole.Length);
                    for(int i=0;i<74;i++)if((i<32||i>=42)&&whole[i]!=0xA5)throw new Exception("Descriptor guard changed");
                    byte[] data=new byte[10];Array.Copy(whole,32,data,0,10);
                    uint pointer=BitConverter.ToUInt32(data,0),rva=pointer-moduleBase;
                    string name="";
                    if(code==0) {
                        if(rva>=moduleSize)throw new Exception("Mnemonic outside module");
                        StringBuilder s=new StringBuilder();bool ended=false;
                        for(uint i=0;i<64&&rva+i<moduleSize;i++) {
                            byte c=Marshal.ReadByte(IntPtr.Add(m,(int)(rva+i)));
                            if(c==0){ended=true;break;}if(c<32||c>126)throw new Exception("Non-ASCII mnemonic");s.Append((char)c);
                        }
                        if(!ended)throw new Exception("Mnemonic bound");
                        name=s.ToString().Replace("\\","\\\\").Replace("\"","\\\"");
                    }
                    string tail=BitConverter.ToString(data,4,6).Replace("-","").ToLowerInvariant();
                    // 2da16 reads this selector; no private function is called.
                    int cpuWord=unchecked((ushort)Marshal.ReadInt16(m,0x928ac));
                    output.WriteLine("{\"id\":"+id+",\"family\":"+family+",\"variant\":"+variant+",\"code\":"+code+",\"name\":\""+name+"\",\"name_rva\":"+(code==0?rva:0)+",\"tail_hex\":\""+tail+"\",\"cpu_word\":"+cpuWord+",\"guards_intact\":true}");
                }
            }
        } finally {Marshal.FreeHGlobal(area);close(h);destroy(h);}
        return 0;
    }
}
