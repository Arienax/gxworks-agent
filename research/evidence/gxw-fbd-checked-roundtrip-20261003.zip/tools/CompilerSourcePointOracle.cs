// Offline CGTable Restore / DBG_INFO Read. The helper owns a memory STREAM;
// it has no workspace, PLC or device interface. Copy borrowed bytes immediately.
using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;

public static class CompilerSourcePointOracle {
    [DllImport("kernel32.dll", CharSet=CharSet.Unicode)]
    static extern IntPtr LoadLibraryEx(string path, IntPtr file, uint flags);
    [DllImport("kernel32.dll", CharSet=CharSet.Ansi, ExactSpelling=true)]
    static extern IntPtr GetProcAddress(IntPtr module, string name);
    [DllImport("kernel32.dll")] static extern uint SetErrorMode(uint mode);
    [UnmanagedFunctionPointer(CallingConvention.ThisCall)] delegate IntPtr Construct(IntPtr self);
    [UnmanagedFunctionPointer(CallingConvention.ThisCall)] delegate int Initialize(IntPtr self);
    [UnmanagedFunctionPointer(CallingConvention.ThisCall)] delegate int TableStream(IntPtr self, IntPtr stream);
    [UnmanagedFunctionPointer(CallingConvention.ThisCall)] delegate void Destroy(IntPtr self);
    [UnmanagedFunctionPointer(CallingConvention.ThisCall)] delegate int ReadDebug(
        IntPtr self, ref int offset, IntPtr record, int option, IntPtr userInfo);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate void Dump(IntPtr self, IntPtr path);
    [UnmanagedFunctionPointer(CallingConvention.ThisCall)] delegate int StreamRead(IntPtr self, IntPtr dest, int length, int reserved);
    [UnmanagedFunctionPointer(CallingConvention.ThisCall)] delegate int StreamSeek(IntPtr self, int offset, int origin);
    static byte[] input;
    static int cursor;
    static T Export<T>(IntPtr module, string name) where T:class {
        IntPtr p=GetProcAddress(module,name);
        if(p==IntPtr.Zero)throw new Exception("Missing export: "+name);
        return Marshal.GetDelegateForFunctionPointer(p,typeof(T)) as T;
    }
    static int Read(IntPtr self, IntPtr dest, int length, int reserved) {
        if(length<0 || length>input.Length-cursor || reserved!=0)return 0;
        Marshal.Copy(input,cursor,dest,length);cursor+=length;return length;
    }
    static int Seek(IntPtr self, int offset, int origin) {
        long next=(origin==0?0:origin==1?cursor:input.Length)+(long)offset;
        if(origin<0 || origin>2 || next<0 || next>input.Length)return -1;
        cursor=(int)next;return cursor;
    }
    static void Clear(IntPtr p,int length) {Marshal.Copy(new byte[length],0,p,length);}
    public static int Main(string[] args) {
        if(IntPtr.Size!=4 || args.Length!=4)return 2;
        SetErrorMode(3);
        if(FileVersionInfo.GetVersionInfo(args[0]).FileVersion!="15.50")throw new Exception("Uninspected compiler version");
        input=File.ReadAllBytes(args[1]);if(input.Length>1048576)throw new Exception("Input bound");
        IntPtr module=LoadLibraryEx(args[0],IntPtr.Zero,8);if(module==IntPtr.Zero)throw new Exception("Load failed");
        Construct ctor=Export<Construct>(module,"??0CDZDataABS_CGTableDataManager@@QAE@XZ");
        Initialize init=Export<Initialize>(module,"?Initialize@CDZDataABS_CGTableDataManager@@UAEJXZ");
        TableStream restore=Export<TableStream>(module,"?Restore@CDZDataABS_CGTableDataManager@@UAEHAAVSTREAM@@@Z");
        Destroy destroy=Export<Destroy>(module,"??1CDZDataABS_CGTableDataManager@@QAE@XZ");
        ReadDebug read=Export<ReadDebug>(module,"?Read@CDZDataABS_CGTableDataManager@@UAEHAAJAAUDBG_INFO@CgTab@@HPAX@Z");
        Dump dump=Export<Dump>(module,"?TabsDump@CDZDataABS_CGTableDataManager@@UAGXPAD@Z");
        IntPtr obj=Marshal.AllocHGlobal(8),vt=Marshal.AllocHGlobal(0x50),stream=Marshal.AllocHGlobal(4);
        Clear(obj,8);Clear(vt,0x50);
        StreamRead readStream=Read;StreamSeek seekStream=Seek;
        Marshal.WriteIntPtr(vt,0x48,Marshal.GetFunctionPointerForDelegate(readStream));
        Marshal.WriteIntPtr(vt,0x24,Marshal.GetFunctionPointerForDelegate(seekStream));Marshal.WriteIntPtr(stream,vt);
        ctor(obj);int accepted=init(obj);Console.WriteLine("initialize="+accepted);if(accepted!=0)return 3;
        accepted=restore(obj,stream);Console.WriteLine("restore="+accepted+" consumed="+cursor+" input="+input.Length);
        if(accepted!=1 || cursor!=input.Length)return 4;
        IntPtr cg=Marshal.ReadIntPtr(obj,4);int userSize=Marshal.ReadInt32(cg,0x3c);
        if(userSize!=8)throw new Exception("Uninspected source point UserInfo size: "+userSize);
        IntPtr record=Marshal.AllocHGlobal(8),user=Marshal.AllocHGlobal(userSize);
        using(StreamWriter output=new StreamWriter(Path.Combine(args[3],"native-source-points.jsonl"))) {
            foreach(string line in File.ReadAllLines(args[2])) {
                int requested=int.Parse(line),next=requested;if(requested<0 || requested>=input.Length)throw new Exception("Offset bound");
                Clear(record,8);Clear(user,userSize);int result=read(obj,ref next,record,0,user);
                if(result!=1)throw new Exception("Source point read failed");
                int length=Marshal.ReadByte(record,4);IntPtr data=Marshal.ReadIntPtr(record);
                if(length>64 || (length!=0 && data==IntPtr.Zero))throw new Exception("Source data bound");
                byte[] value=new byte[length],tail=new byte[userSize];Marshal.Copy(data,value,0,length);Marshal.Copy(user,tail,0,userSize);
                output.WriteLine("{\"offset\":"+requested+",\"next_offset\":"+next+",\"result\":"+result+",\"data_base64\":\""+Convert.ToBase64String(value)+"\",\"user_info_base64\":\""+Convert.ToBase64String(tail)+"\"}");output.Flush();
            }
        }
        IntPtr path=Marshal.StringToHGlobalAnsi(Path.Combine(args[3],"native-table-dump.txt"));dump(obj,path);Marshal.FreeHGlobal(path);
        destroy(obj);Marshal.FreeHGlobal(record);Marshal.FreeHGlobal(user);Marshal.FreeHGlobal(stream);Marshal.FreeHGlobal(vt);Marshal.FreeHGlobal(obj);
        GC.KeepAlive(readStream);GC.KeepAlive(seekStream);return 0;
    }
}
