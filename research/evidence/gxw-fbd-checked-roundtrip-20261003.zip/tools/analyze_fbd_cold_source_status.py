"""Check a complete finite status domain against retained native oracles."""
from pathlib import Path
import json
import struct
import sys

P=Path(__file__).resolve().parent
sys.path.insert(0,str(P))
import probe_fbd_native_normalization as normal
from gxw.container_writer import validate_cfb_streams
from gxw.project_metadata import logical_mapping
from native_fbd_body_codec import normalized_payload
from hypothesis import given, settings, strategies as st

SOURCES=['FBD_MATRIX.Labels.lh','FBD_MATRIX.Program.pou','MODULE_FB.Labels.lh','MODULE_FB.Program.pou']
SAVE=P/'fbd-project-codepage-20261002-v1/persistence/c000-save-cp936-a1'
COLD=P/'fbd-project-codepage-20261002-v1/persistence-v2/c000-cold-reopen-cp936-a2'
OUT=P/'fbd-cold-source-status-20261003-v5'


def streams(raw):
    outer=validate_cfb_streams(raw)
    mapping=logical_mapping(outer['projectdatalist.xml'])
    inner=validate_cfb_streams(outer['_hdb'])
    return {name:inner[value] for name,value in mapping.items() if value in inner}


def native_events(directory):
    return [json.loads(line) for line in (directory/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]


def inspect(directory, original):
    selected=streams((directory/'input.gxw').read_bytes())
    mask=0
    for bit,name in enumerate(SOURCES):
        raw=selected[name]
        value=struct.unpack_from('<I',raw,50)[0]
        assert value in (0,1)
        mask|=value<<bit
        assert raw[:50]+bytes(4)+raw[54:]==original[name]
    gui=selected['FBD_MATRIX.Program.pou']
    native=normal.snapshot_pou_bodies(directory/'frontend-snapshot.json','FBD_MATRIX')[0]
    assert normalized_payload(gui,encoding='gb18030')==native[64:]
    assert struct.unpack_from('<I',native,68)[0]==bool(mask&2)
    messages=[json.loads(line) for line in (directory/'observation-events.jsonl').read_text().splitlines()]
    messages=[r['payload'] for r in messages if r.get('type')=='send']
    observed=[bytes.fromhex(r['input_hex']) for r in messages if r.get('event')=='native-source-body-record'
              and r.get('original_getter_selection')=='FBD_MATRIX']
    assert observed and all(raw==native for raw in observed)
    events=native_events(directory)
    acceptance=[r for r in events if r.get('operation')=='CurrentSourceCheck.AcceptanceObserved']
    assert len(acceptance)==1
    errors=[r['code'] for batch in events if batch.get('operation')=='CurrentSourceCheck.Progress'
            for r in batch['reports'] if r['kind']==2]
    public=[r for r in events if r.get('operation')=='NativeProgramCheckEnumerationFinished']
    assert len(public)==1 and public[0]['public_check_status']=='incomplete'
    assert [r['codepage'] for r in events if r.get('operation')=='NativeProjectCodePage']==[936]
    codepages=sorted({r['code_page'] for r in messages if r.get('event')=='owned-native-label-encoding'})
    assert codepages==[54936]
    return dict(mask=mask,directory=str(directory),source_check=acceptance[0],
                source_error_codes=[f'0x{code:08x}' for code in errors],
                native_payload_exact=True,source_getter_matches_frontend=True,
                native_program_status=struct.unpack_from('<I',native,68)[0],
                project_codepage=936,converter_codepages=codepages,public_check=public[0])


def main():
    original=streams((SAVE/'native-saved.gxw').read_bytes())
    directories=[COLD]
    for name in ['fbd-cold-source-status-20261002-v1','fbd-cold-source-status-20261002-v2',
                 'fbd-cold-source-status-20261003-v3','fbd-cold-source-status-20261003-v5']:
        directories.extend(f.parent for f in (P/name).glob('c*/normalization-result.json')
                           if json.loads(f.read_text())['returncode']!=5)
    rows=[inspect(d,original) for d in directories]
    by_mask={r['mask']:r for r in rows}
    assert len(rows)==len(by_mask)==16 and set(by_mask)==set(range(16))
    evaluated=[]
    @settings(max_examples=16,deadline=None,database=None,derandomize=True)
    @given(mask=st.integers(0,15))
    def property_status(mask):
        row=by_mask[mask]
        assert (row['source_check']['acceptance']=='accepted')==bool(mask&1)
        if mask&1:
            assert row['source_check']['execution_completion']=='completed'
            assert not row['source_error_codes']
        else:
            assert '0x5003000b' in row['source_error_codes']
        evaluated.append(mask)
    property_status()
    assert set(evaluated)==set(range(16))
    before=normal.read_project_context((SAVE/'input.gxw').read_bytes(),'FBD_MATRIX.Program.pou')
    after=normal.read_project_context((SAVE/'native-saved.gxw').read_bytes(),'FBD_MATRIX.Program.pou')
    assert [r.raw for r in before.program.iter_records()]==[r.raw for r in after.program.iter_records()]
    assert [b.raw_header for b in before.program.blocks]==[b.raw_header for b in after.program.blocks]
    assert {n:[r.raw for r in d.rows] for n,d in before.declarations.items()}=={
            n:[r.raw for r in d.rows] for n,d in after.declarations.items()}
    dirty=normal.snapshot_pou_bodies(SAVE/'frontend-snapshot.json','FBD_MATRIX')[0]
    clean=normal.snapshot_pou_bodies(COLD/'frontend-snapshot.json','FBD_MATRIX')[0]
    assert len(dirty)==len(clean)
    differences=[dict(offset=i,before=x,after=y) for i,(x,y) in enumerate(zip(dirty,clean)) if x!=y]
    assert differences==[dict(offset=68,before=1,after=0)]
    result=dict(cpu='FX3U/FX3UC',dll_version='1.635.0.1',source_names_by_bit=SOURCES,
                source_check_kind=6,source_check_names=['','FBD_MATRIX'],
                scope='one native-saved project; fresh project-owned compiler; 16 source pending-marker combinations',
                saved_graph_records_exact=True,saved_graph_block_headers_exact=True,saved_declaration_rows_exact=True,
                native_body_save_reopen_differences=differences,
                all_native_payloads_match=True,complete_four_flag_domain=True,
                hypothesis_evaluations=evaluated,rows=sorted(rows,key=lambda r:r['mask']),
                source_acceptance_condition='selected Program local-label pending marker is 1 within this finite domain',
                public_check_completion_promoted=False,plc_execution='not_run')
    normal.probe.trace.save(OUT/'status-domain-properties.json',result)
    print(json.dumps({k:v for k,v in result.items() if k not in ('rows','hypothesis_evaluations')},ensure_ascii=True))


if __name__=='__main__':main()
