// Owned process: open the inspected Q converter context and close it. No project or device APIs.
using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

public static class QMachineContextOracle {
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode)] static extern IntPtr LoadLibraryEx(string p,IntPtr f,uint flags);
    [DllImport("kernel32.dll",CharSet=CharSet.Ansi,ExactSpelling=true)] static extern IntPtr GetProcAddress(IntPtr m,string n);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate IntPtr Create();
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Open(IntPtr h,int cpu,int mode);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Version(IntPtr h,int count,[In] uint[] versions);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Close(IntPtr h);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate void Destroy(IntPtr h);
    static T Export<T>(IntPtr m,string n) where T:class {return Marshal.GetDelegateForFunctionPointer(GetProcAddress(m,n),typeof(T)) as T;}
    public static int Main(string[] args) {
        if(IntPtr.Size!=4||args.Length!=1)return 2;
        if(FileVersionInfo.GetVersionInfo(args[0]).FileVersion!="15.41")throw new Exception("Uninspected Q provider version");
        IntPtr m=LoadLibraryEx(args[0],IntPtr.Zero,8);if(m==IntPtr.Zero)throw new Exception("Provider load failed");
        IntPtr h=Export<Create>(m,"ObjectNew")();if(h==IntPtr.Zero)throw new Exception("Provider object is absent");
        try {
            int code=Export<Open>(m,"Open")(h,209,0);if(code!=0)throw new Exception("Open failed: "+code);
            code=Export<Version>(m,"SetVersion")(h,1,new uint[]{25});if(code!=0)throw new Exception("SetVersion failed: "+code);
            Console.WriteLine("{\"open_cpu\":209,\"open_mode\":0,\"versions\":[25],\"code\":0}");
        } finally {Export<Close>(m,"Close")(h);Export<Destroy>(m,"ObjectDelete")(h);}
        return 0;
    }
}
