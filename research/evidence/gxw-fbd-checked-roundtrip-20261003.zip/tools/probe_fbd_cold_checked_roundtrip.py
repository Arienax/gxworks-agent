"""Save and cold-reopen a Chinese FBD positive control after both checks.

Keep the prior intentional Y1 diagnostic example intact. Derive a positive
control by restoring the independently retained original MODULE_FB source.
Only native save state is produced; no extra hash verification is performed.
"""
from pathlib import Path
import json
import sys

P=Path(__file__).resolve().parent
sys.path.insert(0,str(P))
import probe_fbd_native_header_mode as mode
from probe_diagnostic_callsite_module import replace_body
from gxw.container_writer import validate_cfb_streams
from gxw.project_metadata import logical_mapping
from gxw.text_pou import parse_st_pou

status=mode.status
SAVE=True


def body(raw):
    outer=validate_cfb_streams(raw)
    inner=validate_cfb_streams(outer['_hdb'])
    mapping=logical_mapping(outer['projectdatalist.xml'])
    return parse_st_pou(inner[mapping['MODULE_FB.Program.pou']]).text


def adapt(path):
    mode.adapt(path)
    if not SAVE:return
    source=path.read_text(encoding='utf-8')
    gate='            if(plan.ContainsKey("owned_current_source_selection")&&!compilerRejected) {'
    complete='                    public_program_check_promoted=false});\n            }'
    export='            if(plan.ContainsKey("export_project")&&Convert.ToBoolean(plan["export_project"])) {'
    assert source.count(gate)==source.count(complete)==source.count(export)==1
    source=source.replace(gate,'            bool ownedSourceAcceptedForCheckedExport=false;\n'+gate)
    source=source.replace(complete,'''                    public_program_check_promoted=false});
                ownedSourceAcceptedForCheckedExport=sourceCompleted&&!sourceRejected;
            }''')
    # Keep the existing export block after the original public check and keep
    # its compilerRejected gate. Do not export merely because source Check ran.
    source=source.replace(export,'            if(ownedSourceAcceptedForCheckedExport) {')
    path.write_text(source,encoding='utf-8')


def events(directory):
    return [json.loads(l) for l in (directory/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]


def verified(directory,*,codepage_setter=False):
    result=json.loads((directory/'result.json').read_text())
    native=events(directory)
    assert result['returncode']==0
    assert result['compile_completed'] and result['publication_completed']
    assert result['checker_read_correspondence']=='current'
    assert result['diagnostic_projection']=='completed' and not result['projection_failures']
    acceptance=[r for r in native if r.get('operation')=='CurrentSourceCheck.AcceptanceObserved']
    assert len(acceptance)==1 and acceptance[0]['acceptance']=='accepted'
    assert acceptance[0]['execution_completion']=='completed'
    checks=[r for r in native if r.get('operation')=='ProgramCheckCompleted']
    assert len(checks)==1 and checks[0]['targets']>0 and not checks[0]['rejected']
    restored=[r for r in native if r.get('operation')=='CurrentSourceCheck.NativeHeaderModeDisabled']
    assert len(restored)==1 and restored[0]['original_after']==0
    codepages=[r['codepage'] for r in native if r.get('operation')=='NativeProjectCodePage']
    configured=[r for r in native if r.get('operation')=='OwnedProjectEncoding.Configured']
    if codepage_setter:
        assert len(configured)==1 and configured[0]['requested']==configured[0]['actual']==936
    else:
        assert codepages==[936] and not configured
        assert not any(r.get('operation','').startswith('OwnedProjectEncoding.') for r in native)
    return dict(directory=str(directory),compile_completed=True,publication_completed=True,
        checker_reads_current_resources=True,source_check=acceptance[0],public_check=checks[0],
        diagnostic_projection='completed',native_mode_restored=True,codepage=936,
        codepage_setter_used=codepage_setter,exported=result['exported'])


def main():
    global SAVE
    root=P/'fbd-cold-checked-roundtrip-20261003-v1'
    root.mkdir(exist_ok=False)
    (root/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    negative=status.SAVED.read_bytes()
    reference=(P/'application-fbd-v2-20261002-v1/full-FX3U-FX3UC/native-compile/native-saved.gxw').read_bytes()
    expected=body(reference)
    assert body(negative)==expected+'Y1 := SIGNAL;\r\n'
    positive,mutation=replace_body(negative,expected)
    positive,markers,preservation=status.marked(positive,['MODULE_FB.Program.pou'])
    assert body(positive)==expected
    seed=root/'positive-input.gxw'
    seed.write_bytes(positive)
    status.normal.probe.trace.save(root/'positive-control-mutation.json',dict(
        negative_source=str(status.SAVED),reference_source='application-fbd-v2-20261002-v1/full-FX3U-FX3UC/native-compile/native-saved.gxw',
        source_change=mutation,pending_markers=markers,preservation=preservation))
    status.SAVED=seed
    status.OUT=root/'save'
    status.ADAPT_EXTRA=adapt
    status.EXTRA_OBSERVER+=mode.header.HEADER_OBSERVER+mode.MODE_OBSERVER
    status.CASES=[('checked-chinese-positive',[],{'owned_current_source_selection':mode.query(True)})]
    status.main()
    save_directory=Path(status.normal.RESULTS[-1]['directory'])
    first=verified(save_directory)
    saved=save_directory/'native-saved.gxw'
    assert saved.exists() and body(saved.read_bytes())==expected
    before=status.normal.read_project_context(positive,'FBD_MATRIX.Program.pou')
    after=status.normal.read_project_context(saved.read_bytes(),'FBD_MATRIX.Program.pou')
    graph_equal=[r.raw for r in before.program.iter_records()]==[r.raw for r in after.program.iter_records()]
    blocks_equal=[b.raw_header for b in before.program.blocks]==[b.raw_header for b in after.program.blocks]
    labels_equal={n:[r.raw for r in d.rows] for n,d in before.declarations.items()}=={
        n:[r.raw for r in d.rows] for n,d in after.declarations.items()}
    assert graph_equal and blocks_equal and labels_equal
    SAVE=False
    status.SAVED=saved
    status.OUT=root/'cold-reopen'
    status.CASES=[('cold-checked-chinese-positive',[],{'owned_current_source_selection':mode.query(True)})]
    status.main()
    reopen_directory=Path(status.normal.RESULTS[-1]['directory'])
    second=verified(reopen_directory)
    assert (reopen_directory/'input.gxw').read_bytes()==saved.read_bytes()
    summary=dict(cpu='FX3U/FX3UC',native_cpu_engine_key=520,dll_version='1.635.0.1',
        save=first,cold_reopen=second,graph_records_exact=graph_equal,block_headers_exact=blocks_equal,
        declaration_rows_exact=labels_equal,st_source_exact=True,cold_input_is_native_saved_bytes=True,
        negative_control_retained=str(P/'fbd-native-header-mode-20261003-v1/c001-native-header-mode-a1'),
        plc_execution='not_run')
    status.normal.probe.trace.save(root/'checked-roundtrip.json',summary)
    print(json.dumps(summary,ensure_ascii=True),flush=True)


if __name__=='__main__':main()
