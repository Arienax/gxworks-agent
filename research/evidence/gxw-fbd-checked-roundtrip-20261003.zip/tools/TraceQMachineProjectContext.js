'use strict';
function bytes(address,size) {
    return Array.from(new Uint8Array(address.readByteArray(size))).map(b=>b.toString(16).padStart(2,'0')).join('');
}
Process.attachModuleObserver({
    onAdded(module) {
        if(module.name.toLowerCase()!=='eccodegenerator2.dll')return;
        const seen=new Set();
        if(bytes(module.base.add(0x4876b),5)!=='83ec145355')throw new Error('Uninspected Q config implementation');
        send({event:'Q-context-provider',path:module.path,image_bytes:module.size});
        Interceptor.attach(module.base.add(0x5a0f),{
            onEnter(args){
                const context=args[2];
                if(context.isNull())return;
                const count=context.add(4).readU16();
                if(count>128)throw new Error('Unmeasured Q parameter table count');
                const raw=bytes(context,6+4*count),key='input:'+raw;
                if(!seen.has(key)) {
                    seen.add(key);
                    send({event:'Q-project-memory-parameters',count,raw_hex:raw,native_cpu_word:module.base.add(0x16d12c).readU16()});
                }
            }
        });
        Interceptor.attach(module.base.add(0x4876b),{
            onEnter(args){
                this.sourceConfig=args[0];this.mode=args[2].toUInt32()&65535;this.cpu=args[3].toUInt32()&65535;
                if(this.mode!==0||args[1].isNull())return;
                const count=args[1].add(4).readU16();
                if(count>128)throw new Error('Unmeasured project parameter count');
                const raw=bytes(args[1],6+4*count),key='internal-input:'+raw;
                if(!seen.has(key)) {
                    seen.add(key);
                    send({event:'Q-project-memory-parameters',cpu:this.cpu,mode:this.mode,count,raw_hex:raw});
                }
            },
            onLeave(){
                const raw=bytes(this.sourceConfig,0x380),key='config:'+raw;
                if(!seen.has(key)) {
                    seen.add(key);
                    send({event:'Q-project-machine-config',cpu:this.cpu,mode:this.mode,raw_hex:raw});
                }
            }
        });
    }
});
