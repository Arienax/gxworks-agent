"""Select dependency POUs explicitly in one original native source Check.

Each unit keeps the established two-name ABI; the native API's count receives
the actual contiguous unit count. All names and descriptors remain owned until
native completion. Native return values and project bytes are not changed.
"""
from pathlib import Path
import json
import sys

P=Path(__file__).resolve().parent
sys.path.insert(0,str(P))
import probe_fbd_cold_status_boundary as boundary
status=boundary.status


def adapt(path):
    helper=path.parent/'NativeCurrentSourceCheck.cs'
    source=helper.read_text(encoding='utf-8')
    start=source.index('            var selections=new List<Dictionary<string,object>>();')
    end=source.index('            Record(new {operation="CurrentSourceCheck.Selection"',start)
    block='''            var ownedUnits=new List<Dictionary<string,object>>();
            if(query.ContainsKey("units")) {
                foreach(Dictionary<string,object> item in (System.Collections.IEnumerable)query["units"])ownedUnits.Add(item);
            } else ownedUnits.Add(query);
            if(ownedUnits.Count<1||ownedUnits.Count>8)throw new Exception("Owned unit count bound");
            IntPtr unit=Marshal.AllocCoTaskMem(12*ownedUnits.Count);buffers.Add(unit);
            for(int unitIndex=0;unitIndex<ownedUnits.Count;unitIndex++) {
                var selectedUnit=ownedUnits[unitIndex];
                var selections=new List<Dictionary<string,object>>();
                foreach(Dictionary<string,object> row in (System.Collections.IEnumerable)selectedUnit["selections"])selections.Add(row);
                if(selections.Count!=2||Convert.ToInt32(selectedUnit["kind"])!=6)
                    throw new Exception("Owned source units require the verified two-selection POU ABI");
                IntPtr items=Marshal.AllocCoTaskMem(16);buffers.Add(items);
                for(int i=0;i<selections.Count;i++) {
                    string name=(string)selections[i]["name"];
                    if(name.Length>128||Array.Exists(name.ToCharArray(),c=>c==0||c>127))
                        throw new Exception("Owned trial requires bounded ASCII selection names");
                    IntPtr value=Marshal.StringToCoTaskMemAnsi(name);buffers.Add(value);
                    Marshal.WriteInt32(items,i*8,Convert.ToInt32(selections[i]["row"]));
                    Marshal.WriteIntPtr(items,i*8+4,value);
                }
                IntPtr descriptor=IntPtr.Add(unit,12*unitIndex);
                Marshal.WriteInt32(descriptor,0,6);Marshal.WriteInt32(descriptor,4,2);Marshal.WriteIntPtr(descriptor,8,items);
            }
'''
    source=source[:start]+block+source[end:]
    old='(native,-1,1,unit,out code)'
    if source.count(old)!=1:raise ValueError('original narrow source Check call differs')
    source=source.replace(old,'(native,-1,ownedUnits.Count,unit,out code)')
    helper.write_text(source,encoding='utf-8')
    plan=json.loads((path.parent/'plan.json').read_text())
    status.normal.probe.QUERY=plan['owned_current_source_selection']


def query(names):
    selected=[('',item) if isinstance(item,str) else item for item in names]
    return dict(units=[dict(kind=6,selections=[dict(row=-1,name=library),dict(row=-1,name=name)])
                       for library,name in selected],wide_progress=True)


if __name__=='__main__':
    status.OUT=P/'fbd-cold-dependency-selection-20261003-v1'
    status.ADAPT_EXTRA=adapt
    status.CASES=[(label,[],{'owned_current_source_selection':query(names)}) for label,names in [
        ('selected-only',['FBD_MATRIX']),
        ('dependencies-first',['TON','MODULE_FB','FBD_MATRIX']),
        ('selected-first',['FBD_MATRIX','TON','MODULE_FB'])]]
    status.main()
    (status.OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
