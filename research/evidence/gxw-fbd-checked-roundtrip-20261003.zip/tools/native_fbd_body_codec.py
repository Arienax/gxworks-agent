"""Research-only GUI-to-native FBD payload hypothesis.

The generic native 64-byte header is intentionally not synthesized. This codec
covers bounded observed node/wire forms; unknown records are not translated.
Original native frontend bytes, rather than this codec's inverse, are the oracle.
"""
import struct

from gxw.structured_pou import parse_structured_pou


def _u32(raw, offset):
    return struct.unpack_from('<I', raw, offset)[0]


def _byte_from_u16(raw, offset):
    value = struct.unpack_from('<H', raw, offset)[0]
    if value > 255:
        raise ValueError('unverified narrowing of a non-byte GUI field')
    return bytes([value])


def _string(raw, cursor, encoding, encoding_errors):
    count = _u32(raw, cursor)
    end = cursor + 4 + count * 2
    text = raw[cursor + 4:end].decode('utf-16le')
    if not text.endswith('\0') or '\0' in text[:-1]:
        raise ValueError('unverified GUI string termination')
    encoded = text.encode(encoding, errors=encoding_errors)
    return struct.pack('<I', len(encoded)) + encoded, end


def _record(raw, encoding, encoding_errors):
    record_class = _u32(raw, 4)
    if record_class == 1:
        kind = _u32(raw, 8)
        if kind not in (2, 13, 14):
            raise ValueError('native normalization not verified for this node kind')
        parts = [raw[:12]]
        cursor = 12
        for _ in range(2 if kind == 2 else 1):
            text, cursor = _string(raw, cursor, encoding, encoding_errors)
            parts.append(text)
        if kind != 2:
            parts.extend([raw[cursor:cursor + 4], _byte_from_u16(raw, cursor + 4)])
            cursor += 6
        parts.append(raw[cursor:])
        result = bytearray(b''.join(parts))
    elif record_class == 2 and len(raw) == 44:
        result = bytearray(raw[:16] + _byte_from_u16(raw, 16)
                           + _byte_from_u16(raw, 18) + raw[20:])
    else:
        raise ValueError('native normalization not verified for this record class')
    struct.pack_into('<I', result, 0, len(result))
    return bytes(result)


def normalized_payload(gui, *, encoding='ascii', encoding_errors='strict'):
    program = parse_structured_pou(gui)
    blocks = []
    for block, records in program.block_records():
        content = b''.join(_record(record.raw, encoding, encoding_errors) for record in records)
        header = bytearray(block.raw_header[:8] + _byte_from_u16(block.raw_header, 8)
                           + _byte_from_u16(block.raw_header, 10) + block.raw_header[12:])
        struct.pack_into('<I', header, 0, len(header) + len(content))
        blocks.append(bytes(header) + content)
    # A native-saved cold input differs from the unsaved input here: changing
    # only GUI compile status @50 (0 -> 1) changes native DWORD @68 (0 -> 1).
    # GUI @63 is still 1 in both controls and cannot supply this native field.
    if _u32(gui, 50) not in (0, 1):
        raise ValueError('native payload status not verified for this GUI marker')
    result = bytearray(bytes(4) + gui[50:54] + gui[67:71] + b''.join(blocks))
    struct.pack_into('<I', result, 0, len(result))
    return bytes(result)
