// Owned offline work buffers, inspected public SFC conversion interface.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Web.Script.Serialization;

public static class FXSfcReadOracle {
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode)] static extern IntPtr LoadLibraryEx(string p,IntPtr f,uint flags);
    [DllImport("kernel32.dll",CharSet=CharSet.Ansi,ExactSpelling=true)] static extern IntPtr GetProcAddress(IntPtr m,string n);
    [DllImport("kernel32.dll")] static extern uint SetErrorMode(uint mode);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate IntPtr Create();
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Open(IntPtr h,int cpu,int mode);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Version(IntPtr h,int count,[In]uint[] values);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Close(IntPtr h);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate void Destroy(IntPtr h);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Bind(IntPtr h,IntPtr chars,IntPtr ladder,IntPtr changes,IntPtr work,IntPtr numbers,IntPtr fxNumbers,ushort kind);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Decode(IntPtr h,IntPtr input,out short result);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Dimensions(IntPtr h,out ushort x,out ushort y);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Symbol(IntPtr h,short x,short y,out short type,out short undefined,out short substep,out short number,out short branch,out short result);
    static T Export<T>(IntPtr m,string n) where T:class {
        IntPtr p=GetProcAddress(m,n);if(p==IntPtr.Zero)throw new Exception(n);
        return Marshal.GetDelegateForFunctionPointer(p,typeof(T)) as T;
    }
    static void Check(int code,string method){if(code!=0)throw new Exception(method+": "+code);}
    public static int Main(string[] args) {
        if(IntPtr.Size!=4||args.Length!=3)return 2;SetErrorMode(3);
        if(FileVersionInfo.GetVersionInfo(args[0]).FileVersion!="15.31")throw new Exception("Uninspected converter");
        byte[] source=File.ReadAllBytes(args[1]);if(source.Length<5||source.Length>65536)throw new Exception("Unbounded SFC input");
        IntPtr m=LoadLibraryEx(args[0],IntPtr.Zero,8);if(m==IntPtr.Zero)throw new Exception("Load failed");
        Create create=Export<Create>(m,"ObjectNew");Open open=Export<Open>(m,"Open");Version version=Export<Version>(m,"SetVersion");
        Close close=Export<Close>(m,"Close");Destroy destroy=Export<Destroy>(m,"ObjectDelete");
        Bind bind=Export<Bind>(m,"SAPOpen");Decode decode=Export<Decode>(m,"ConvertPcodeToSFC");
        Dimensions dimensions=Export<Dimensions>(m,"GetCmXY");Symbol symbol=Export<Symbol>(m,"ReadSymbol");
        const int capacity=1024*1024,guard=32;
        var areas=new List<byte[]>();var pins=new List<GCHandle>();var pointers=new List<IntPtr>();
        IntPtr h=create();if(h==IntPtr.Zero)throw new Exception("Create failed");
        try {
            for(int i=0;i<7;i++) {
                byte[] area=new byte[capacity+2*guard];for(int j=0;j<guard;j++)area[j]=area[guard+capacity+j]=0xa5;
                GCHandle pin=GCHandle.Alloc(area,GCHandleType.Pinned);areas.Add(area);pins.Add(pin);pointers.Add(IntPtr.Add(pin.AddrOfPinnedObject(),guard));
            }
            Marshal.WriteInt16(pointers[0],0,10);Marshal.WriteInt16(pointers[0],2,306);
            Marshal.WriteInt16(pointers[4],0,512);Marshal.WriteInt16(pointers[4],2,512);
            Marshal.WriteInt16(pointers[5],0,4096);Marshal.WriteInt16(pointers[5],2,512);
            Array.Copy(source,0,areas[6],guard,source.Length);
            Check(open(h,520,0),"Open");Check(version(h,0,new uint[0]),"SetVersion");
            Check(bind(h,pointers[0],pointers[1],pointers[2],pointers[3],pointers[4],pointers[5],3),"SAPOpen");
            short result;int code=decode(h,pointers[6],out result);
            var glyphs=new List<object>();ushort width=0,height=0;
            if(code==0&&result==0) {
                Check(dimensions(h,out width,out height),"GetCmXY");
                if(width==0||height==0||width>256||height>4096||(long)width*height>3072)throw new Exception("SFC glyph grid outside inspected fixed buffer");
                for(short y=0;y<height;y++)for(short x=0;x<width;x++) {
                    // ReadSymbol only writes fields belonging to its status.
                    // Reset every slot so other glyph fields stay unavailable.
                    short type=short.MinValue,undefined=short.MinValue,substep=short.MinValue,number=short.MinValue,branch=short.MinValue,status=short.MinValue;
                    Check(symbol(h,x,y,out type,out undefined,out substep,out number,out branch,out status),"ReadSymbol");
                    if(status!=0)glyphs.Add(new{x=x,y=y,type=type,undefined=undefined,substep=substep,number=number,branch=branch,status=status});
                }
            }
            for(int i=0;i<areas.Count;i++) {
                for(int j=0;j<guard;j++)if(areas[i][j]!=0xa5||areas[i][guard+capacity+j]!=0xa5)throw new Exception("Owned SFC buffer guard changed");
                byte[] data=new byte[capacity];Array.Copy(areas[i],guard,data,0,capacity);File.WriteAllBytes(Path.Combine(args[2],"buffer-"+i+".bin"),data);
            }
            for(int i=0;i<source.Length;i++)if(areas[6][guard+i]!=source[i])throw new Exception("Read-only SFC input changed");
            File.WriteAllText(Path.Combine(args[2],"outcome.json"),new JavaScriptSerializer().Serialize(new{
                cpu=520,converter="15.31",code=code,result=result,width=width,height=height,glyphs=glyphs,
                all_guards_intact=true,input_preserved=true,scope="Owned offline public SFC decode only; no project or device API"}));
            return 0;
        }finally {close(h);destroy(h);foreach(GCHandle pin in pins)if(pin.IsAllocated)pin.Free();}
    }
}
