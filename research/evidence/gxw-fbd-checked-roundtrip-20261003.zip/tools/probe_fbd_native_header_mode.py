"""Use the pinned native declaration-change mode on an owned source Check.

The original exported methods change transient compiler state. Input GXW bytes,
source descriptors, original diagnostic values, and public ProgramCheck remain
untouched. No DataManager field or return value is patched by the observer.
"""
from pathlib import Path
import json
import sys

P=Path(__file__).resolve().parent
sys.path.insert(0,str(P))
import probe_fbd_cold_header_binding as header
status=header.status

MODE_HELPER=r'''
partial class WorkspaceReplayOracle {
    [DllImport("kernel32",CharSet=CharSet.Ansi,EntryPoint="GetProcAddress",ExactSpelling=true)]
    static extern IntPtr OwnedHeaderExport(IntPtr module,string name);
    [UnmanagedFunctionPointer(CallingConvention.ThisCall)]
    delegate int OwnedHeaderGetManagerFn(IntPtr self,out IntPtr manager);
    [UnmanagedFunctionPointer(CallingConvention.ThisCall)]
    delegate void OwnedHeaderModeFn(IntPtr self);

    static IntPtr OwnedPinnedHeaderExport(string name,int rva) {
        IntPtr module=CrtModuleHandle("DZDataABS_DataManager_IEC.dll");
        if(module==IntPtr.Zero)throw new Exception("Observed DataManager is not loaded");
        IntPtr address=OwnedHeaderExport(module,name);
        if(address!=IntPtr.Add(module,rva))throw new Exception("Pinned DataManager export differs");
        return address;
    }
    static IntPtr OwnedBeginNativeHeaderMode(IntPtr native) {
        IntPtr get=OwnedPinnedHeaderExport("?GetManager@CDZDataABS_OnMemoryDataManager@@QAEJPAPAVCDZDataABS_POUDataManager@@@Z",0x1f2de);
        var getter=(OwnedHeaderGetManagerFn)Marshal.GetDelegateForFunctionPointer(get,typeof(OwnedHeaderGetManagerFn));
        IntPtr memory=Marshal.ReadIntPtr(native,0x10),manager;
        int result=getter(memory,out manager);
        if(result!=0||manager==IntPtr.Zero)throw new Exception("Original POU manager lookup failed");
        IntPtr module=CrtModuleHandle("DZDataABS_DataManager_IEC.dll");
        if(Marshal.ReadIntPtr(Marshal.ReadIntPtr(manager),0x80)!=IntPtr.Add(module,0x319da))
            throw new Exception("Original POU manager change-flag method differs");
        int before=Marshal.ReadInt32(manager,0x198);
        if(before!=0)throw new Exception("Owned scoped mode expected the original disabled state");
        IntPtr enable=OwnedPinnedHeaderExport("?EnableModeToAlwaysReturnDataChanged@CDZDataABS_POUDataManager@@QAEXXZ",0x32a8a);
        var start=(OwnedHeaderModeFn)Marshal.GetDelegateForFunctionPointer(enable,typeof(OwnedHeaderModeFn));
        start(manager);
        Record(new {operation="CurrentSourceCheck.NativeHeaderModeEnabled",manager="0x"+manager.ToString("x8"),
            original_before=before,original_after=Marshal.ReadInt32(manager,0x198),
            method="EnableModeToAlwaysReturnDataChanged",gxw_input_modified=false});
        return manager;
    }
    static void OwnedEndNativeHeaderMode(IntPtr manager) {
        IntPtr disable=OwnedPinnedHeaderExport("?DisableModeToAlwaysReturnDataChanged@CDZDataABS_POUDataManager@@QAEXXZ",0x32a95);
        var end=(OwnedHeaderModeFn)Marshal.GetDelegateForFunctionPointer(disable,typeof(OwnedHeaderModeFn));
        end(manager);
        Record(new {operation="CurrentSourceCheck.NativeHeaderModeDisabled",original_after=Marshal.ReadInt32(manager,0x198),
            method="DisableModeToAlwaysReturnDataChanged",native_execution_finished=true});
    }
}
'''

MODE_OBSERVER=r'''
const ownedChangeFlagModules=new Set();
function ownedChangeFlagBind(m){
 if(!m||ownedChangeFlagModules.has(m.base.toString()))return;
 ownedChangeFlagModules.add(m.base.toString());
 Interceptor.attach(m.base.add(0x319da),{
  onEnter(a){this.owned=phase==='source-check';if(!this.owned)return;
   this.out=a[3];this.row={event:'owned-header-change-flag',kind:a[0].toInt32(),
    library:a[1].add(4).readPointer().readCString(),name:a[2].add(4).readPointer().readCString(),
    original_mode:this.context.ecx.add(0x198).readU32(),caller:loc(this.returnAddress)};
  },
  onLeave(r){if(this.owned)send(Object.assign(this.row,{original_code:r.toUInt32(),
   original_flag:r.toInt32()===0?this.out.readU32():null}));}
 });
 for(const rva of [0x32a8a,0x32a95])Interceptor.attach(m.base.add(rva),{
  onEnter(){this.owner=this.context.ecx;this.before=this.owner.add(0x198).readU32();this.caller=loc(this.returnAddress);},
  onLeave(){send({event:'owned-native-header-mode-call',target:loc(m.base.add(rva)),caller:this.caller,
   before:this.before,after:this.owner.add(0x198).readU32()});}
 });
}
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()==='dzdataabs_datamanager_iec.dll')ownedChangeFlagBind(m);
 if(m.name.toLowerCase()==='dzdataabs_compiler_iec.dll')Interceptor.attach(m.base.add(0x6f2c),{
  onEnter(){ownedChangeFlagBind(Process.findModuleByName('DZDataABS_DataManager_IEC.dll'));}
 });
}});
'''


def adapt(path):
    source=path.parent/'NativeCurrentSourceCheck.cs'
    text=source.read_text(encoding='utf-8')
    replacements={
        'var buffers=new List<IntPtr>();bool rejected=false;':
            'var buffers=new List<IntPtr>();bool rejected=false;IntPtr ownedHeaderMode=IntPtr.Zero;',
        '            int code;':
            '''            int code;
            if(query.ContainsKey("owned_native_header_mode")&&Convert.ToBoolean(query["owned_native_header_mode"]))
                ownedHeaderMode=OwnedBeginNativeHeaderMode(native);''',
        '            if(hr<0||code!=0)return true;':
            '''            if(hr<0||code!=0) {
                if(ownedHeaderMode!=IntPtr.Zero)throw new Exception("Scoped header-mode Check did not start");
                return true;
            }''',
        '            return rejected;':
            '''            if(ownedHeaderMode!=IntPtr.Zero&&!finished)
                throw new Exception("Scoped header-mode Check incomplete; stopping owned helper");
            return rejected;''',
        '        } finally {\n            if(finished)':
            '''        } finally {
            if(ownedHeaderMode!=IntPtr.Zero&&finished)OwnedEndNativeHeaderMode(ownedHeaderMode);
            if(finished)''',
    }
    for before,after in replacements.items():
        assert text.count(before)==1,before
        text=text.replace(before,after)
    source.write_text(text+MODE_HELPER,encoding='utf-8')
    plan=json.loads((path.parent/'plan.json').read_text())
    status.normal.probe.QUERY=plan['owned_current_source_selection']


def query(enabled,name='FBD_MATRIX'):
    return dict(kind=6,selections=[dict(row=-1,name=''),dict(row=-1,name=name)],
                wide_progress=True,owned_native_header_mode=enabled)


if __name__=='__main__':
    status.OUT=P/'fbd-native-header-mode-20261003-v3'
    status.SAVED=P/'application-fbd-v2-20261002-v1/full-FX3U-FX3UC/native-compile/native-saved.gxw'
    status.ADAPT_EXTRA=adapt
    status.EXTRA_OBSERVER+=header.HEADER_OBSERVER+MODE_OBSERVER
    status.CASES=[('ascii-native-header-mode',[],{'owned_current_source_selection':query(True)})]
    status.main()
    (status.OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
