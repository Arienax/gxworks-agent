"""Observe original POU header selectors for project and library source Check."""
from pathlib import Path
import sys

P=Path(__file__).resolve().parent
sys.path.insert(0,str(P))
import probe_fbd_cold_dependency_selection as trial
status=trial.status

SELECTOR_OBSERVER=r'''
const ownedHeaderSelectorModules=new Set();
function ownedHeaderSpecified(p){
 return {row:p.readS32(),name:p.add(4).readPointer().readCString(),raw:hex(p,8)};
}
function ownedHeaderSelectorBind(m){
 if(!m||ownedHeaderSelectorModules.has(m.base.toString()))return;
 ownedHeaderSelectorModules.add(m.base.toString());
 for(const rva of [0x30dc7,0x30e5e]){
  Interceptor.attach(m.base.add(rva),{
   onEnter(a){this.owned=phase==='source-check';if(!this.owned)return;try{
    this.row={event:'owned-header-selection-enter',site:loc(m.base.add(rva)),
     first:ownedHeaderSpecified(a[0]),second:ownedHeaderSpecified(a[1]),
     resolver:loc(this.context.ecx.readPointer().add(0x18).readPointer())};
    send(this.row);
   }catch(e){send({event:'observation-error',phase:'header-selector-read',error:String(e)});}},
   onLeave(r){if(this.owned)send({event:'owned-header-selection-return',site:loc(m.base.add(rva)),original_code:r.toUInt32()});}
  });
 }
}
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()==='dzdataabs_compiler_iec.dll')Interceptor.attach(m.base.add(0x6f2c),{
  onEnter(){ownedHeaderSelectorBind(Process.findModuleByName('DZDataABS_DataManager_IEC.dll'));}
 });
}});
'''


if __name__=='__main__':
    status.OUT=P/'fbd-library-check-selection-20261003-v1'
    status.ADAPT_EXTRA=trial.adapt
    status.EXTRA_OBSERVER+=SELECTOR_OBSERVER
    status.CASES=[(label,[],{'owned_current_source_selection':trial.query(names)}) for label,names in [
        ('project-selector',['FBD_MATRIX']),
        ('library-selector',[('@IEC','TON')]),
        ('reversed-selector',[('TON','@IEC')])]]
    status.main()
    (status.OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
