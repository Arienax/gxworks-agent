"""Observe current frontend label conversion at an explicit code-page boundary.

Acceptance is recorded independently; these probes do not assume Unicode labels
are valid in the selected native compiler or that system ACP selects the codec.
"""
from pathlib import Path
import json
import shutil
import sys

P = Path(__file__).resolve().parent
sys.path.insert(0, str(P))
import probe_fbd_native_normalization as normal


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    normal.OUT = P/'fbd-native-label-encoding-20261002-v2'
    normal.OUT.mkdir(exist_ok=False)
    for name in (Path(__file__).name, 'probe_fbd_native_normalization.py', 'native_fbd_body_codec.py'):
        shutil.copyfile(P/name, normal.OUT/name)
    latin = P/'fbd-native-label-encoding-20261002-v1/c000-cp1252-latin-a1'
    native = normal.snapshot_pou_bodies(latin/'frontend-snapshot.json', 'FBD_MATRIX')[0]
    gui = normal.read_project_context((latin/'input.gxw').read_bytes(), 'FBD_MATRIX.Program.pou').program.raw
    events = [json.loads(x) for x in (latin/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    payloads = [x['payload'] for x in map(json.loads, (latin/'observation-events.jsonl').read_text(
        encoding='utf-8').splitlines()) if x.get('type')=='send']
    matches = normal.normalized_payload(gui, encoding='cp1252') == native[64:]
    assert matches
    normal.probe.trace.save(normal.OUT/'retained-latin-native-evidence.json', dict(
        original_native_directory=str(latin), payload_bytes_exact=matches, native_run_repeated=False,
        source_check=[x for x in events if x.get('operation')=='CurrentSourceCheck.AcceptanceObserved'],
        label_encoding=[x for x in payloads if x.get('event','').startswith('owned-native-label-')
                        or x.get('event')=='owned-native-text-observer'],
        owned_postprocessing_error='optional compiler-index decoder assumed cp949 for native byte 0xc9',
        native_outcome_changed=False))
    probe = normal.probe
    prepare, adapt_helper, cs = probe.trace.prepare, probe.drain.adapt_helper, probe.trace.CS
    def prepared(*args, **kwargs):
        active=probe.trace.CS;probe.trace.CS=cs
        try:return prepare(*args, **kwargs)+normal.dispatch.OBSERVER+probe.BACKEND_OBSERVER+normal.units.OBSERVER+normal.ACTIVE_TEXT_OBSERVER
        finally:probe.trace.CS=active
    link_witness=probe.drain.link_witness
    def optional_link(directory):
        try:return link_witness(directory)
        except (normal.GXWFormatError, UnicodeError) as error:
            return dict(status='not_established',owned_decoder_error=str(error),native_outcome_changed=False)
    probe.trace.prepare=prepared;probe.drain.adapt_helper=probe.adapt
    probe.trace.CS=cs+(probe.SOURCE,);probe.drain.link_witness=optional_link
    probe.QUERY=dict(kind=6,selections=[dict(row=-1,name=''),dict(row=-1,name='FBD_MATRIX')],wide_progress=True)
    try:
        # Only these two BMP characters are compared to the original observed
        # default substitution; this is not a general Windows best-fit table.
        normal.run_native(dict(instance='OWNED_\u6a21\u5757_A'),label='cp1252-unrepresentable',
                          encoding='cp1252',encoding_errors='replace',assert_acceptance=False)
    finally:
        probe.trace.prepare,probe.drain.adapt_helper,probe.trace.CS=prepare,adapt_helper,cs
        probe.drain.link_witness=link_witness


if __name__ == '__main__':main()
