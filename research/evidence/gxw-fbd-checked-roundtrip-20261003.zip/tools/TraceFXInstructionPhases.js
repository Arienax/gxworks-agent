// Append after the shared request-ID hooks; observe, never call private code.
Process.attachModuleObserver({ onAdded(m) {
    if (m.name.toLowerCase() !== 'eccodegeneratorfx2.dll') return;
    const base = m.base;
    Interceptor.attach(base.add(0x243a2), {
        onEnter(a) {
            this.b = a[0];
            const size = this.b.add(4).readU32();
            if (size > 512) throw new Error('Instruction phase outside single-record envelope');
            this.row = { event: 'instruction-phase', request,
                input: hex(this.b.add(8).readPointer(), size) };
        },
        onLeave(r) { this.row.result = shortResult(r); send(this.row); }
    });
    Interceptor.attach(base.add(0x3e534), {
        onEnter(a) {
            const size = a[1].toUInt32();
            if (size > 512) throw new Error('Width phase outside single-record envelope');
            this.p = a[0]; this.size = size;
            this.row = { event: 'width-phase', request, input: hex(this.p, size) };
        },
        onLeave(r) {
            this.row.result = shortResult(r);
            const size = this.row.result > 0 ? this.row.result : this.size;
            if (size > 1024) throw new Error('Width result outside owned helper buffer');
            this.row.output = hex(this.p, size); send(this.row);
        }
    });
    Interceptor.attach(base.add(0x24422), {
        onEnter(a) {
            this.row = { event: 'counter-specific-check', request, index: a[3].toUInt32() & 255,
                value: a[2].toInt32(), enabled: base.add(0x791cc).readU32() };
        },
        onLeave(r) { this.row.result = shortResult(r); send(this.row); }
    });
} });
