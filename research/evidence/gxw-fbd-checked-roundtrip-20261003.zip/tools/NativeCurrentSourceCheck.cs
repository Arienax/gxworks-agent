// Owned offline caller of the original initialized narrow compiler interface.
// Input buffers stay alive throughout asynchronous native execution.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

partial class WorkspaceReplayOracle {
    [UnmanagedFunctionPointer(CallingConvention.StdCall)]
    delegate int OwnedCurrentSourceCheckFn(IntPtr self,int reportKind,int count,IntPtr units,out int code);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)]
    delegate int OwnedCurrentSourceProgressFn(IntPtr self,ref int percent,ref int count,ref IntPtr reports,ref int code);

    static List<IntPtr> unfinishedOwnedSourceBuffers=new List<IntPtr>();

    static IntPtr OwnedBoundPointer(object text) {
        string value=Convert.ToString(text);
        if(!value.StartsWith("0x"))throw new Exception("Owned binding address format differs");
        return new IntPtr(unchecked((int)Convert.ToUInt32(value.Substring(2),16)));
    }

    static bool CheckCurrentNativeSources(IntPtr publicCompiler,Dictionary<string,object> query,out bool finished) {
        finished=false;
        string root=Path.GetDirectoryName(Environment.GetCommandLineArgs()[1]);
        string binding=Path.Combine(root,"current-source-backend.json");
        int gate=0;
        while(!File.Exists(binding+".ready")&&gate++<1000)Thread.Sleep(10);
        if(!File.Exists(binding+".ready"))throw new Exception("Current source backend was not observed during build progress");
        var observed=json.Deserialize<Dictionary<string,object>>(File.ReadAllText(binding));
        if(Convert.ToInt32(observed["pid"])!=Process.GetCurrentProcess().Id)
            throw new Exception("Owned source backend belongs to a different process");
        IntPtr borrowed=OwnedBoundPointer(observed["backend"]),native=IntPtr.Zero;
        Record(new {operation="CurrentSourceCheck.BindingInput",binding=observed});
        Guid iid=new Guid("174a0ebf-c472-4d2f-a2db-f3e712890638");
        int hr=Marshal.QueryInterface(borrowed,ref iid,out native);
        Record(new {operation="CurrentSourceCheck.QueryInterface",hresult=hr,iid=iid.ToString(),
            observed_backend=borrowed.ToString(),queried_pointer=native.ToString(),
            native_cpu_engine_key=observed["native_cpu_engine_key"]});
        if(hr<0||native==IntPtr.Zero)throw new Exception("Original compiler interface query failed");
        var buffers=new List<IntPtr>();bool rejected=false;
        try {
            IntPtr table=Marshal.ReadIntPtr(native);
            if(Marshal.ReadIntPtr(table,36)!=OwnedBoundPointer(observed["check_address"])||
               Marshal.ReadIntPtr(table,44)!=OwnedBoundPointer(observed["progress_address"]))
                throw new Exception("Queried compiler differs from observed Check/progress binding");
            var selections=new List<Dictionary<string,object>>();
            foreach(Dictionary<string,object> row in (System.Collections.IEnumerable)query["selections"])
                selections.Add(row);
            if(selections.Count!=2||Convert.ToInt32(query["kind"])!=6)
                throw new Exception("Current source trial is restricted to the verified two-selection POU ABI");
            IntPtr items=Marshal.AllocCoTaskMem(16),unit=Marshal.AllocCoTaskMem(12);
            buffers.Add(items);buffers.Add(unit);
            for(int i=0;i<selections.Count;i++) {
                string name=(string)selections[i]["name"];
                if(name.Length>128||Array.Exists(name.ToCharArray(),c=>c==0||c>127))
                    throw new Exception("Owned trial requires bounded ASCII selection names");
                IntPtr value=Marshal.StringToCoTaskMemAnsi(name);buffers.Add(value);
                Marshal.WriteInt32(items,i*8,Convert.ToInt32(selections[i]["row"]));
                Marshal.WriteIntPtr(items,i*8+4,value);
            }
            Marshal.WriteInt32(unit,0,6);Marshal.WriteInt32(unit,4,2);Marshal.WriteIntPtr(unit,8,items);
            Record(new {operation="CurrentSourceCheck.Selection",query=query,source_context="current initialized workspace backend",
                input_handling="owned narrow buffers retained while native execution runs",public_program_check_promoted=false});
            bool wide=query.ContainsKey("wide_progress")&&Convert.ToBoolean(query["wide_progress"]);
            int stride=wide?100:68;
            int code;
            hr=Slot<OwnedCurrentSourceCheckFn>(native,36)(native,-1,1,unit,out code);
            Record(new {operation="CurrentSourceCheck.Start",hresult=hr,code=code,code_hex="0x"+code.ToString("x8")});
            if(hr<0||code!=0)return true;
            var clock=Stopwatch.StartNew();int last=-1;
            while(clock.ElapsedMilliseconds<35000) {
                Application.DoEvents();int percent=0,count=0;IntPtr reports=IntPtr.Zero;code=0;
                // Original DataManager GetProgress leaves count untouched when
                // no report is pending. Do not reuse a previous poll's count.
                hr=Slot<OwnedCurrentSourceProgressFn>(wide?publicCompiler:native,wide?40:44)(wide?publicCompiler:native,
                    ref percent,ref count,ref reports,ref code);
                if(hr<0||code!=0) {
                    Record(new {operation="CurrentSourceCheck.ProgressFailure",hresult=hr,code=code,
                        code_hex="0x"+code.ToString("x8"),last_valid_percent=last,
                        output_handling="failed output pointers are not a new diagnostic batch"});
                    break;
                }
                if(count<0||count>10000||(count>0&&reports==IntPtr.Zero))
                    throw new Exception("Native current source reports exceed structural bounds");
                var rows=new List<object>();
                for(int i=0;i<count;i++) {
                    IntPtr row=IntPtr.Add(reports,i*stride);byte[] bytes=new byte[stride];Marshal.Copy(row,bytes,0,stride);
                    int kind=Marshal.ReadInt32(row),reportCode=Marshal.ReadInt32(row,4);
                    if(kind==2)rejected=true;
                    object projected=null;
                    if(wide) {
                        uint[] objectWords=new uint[12];
                        for(int word=0;word<12;word++)objectWords[word]=unchecked((uint)Marshal.ReadInt32(row,24+word*4));
                        projected=new {name=ReadBStr(Marshal.ReadIntPtr(row,8)),
                            instance=ReadBStr(Marshal.ReadIntPtr(row,16)),instance_kind=Marshal.ReadInt32(row,12),
                            program_kind=Marshal.ReadInt32(row,20),object_id=objectWords,step=Marshal.ReadInt32(row,72),
                            network=Marshal.ReadInt32(row,76),left=Marshal.ReadInt32(row,80),top=Marshal.ReadInt32(row,84),
                            right=Marshal.ReadInt32(row,88),bottom=Marshal.ReadInt32(row,92)};
                    }
                    rows.Add(new {kind=kind,code=reportCode,raw_base64=Convert.ToBase64String(bytes),projected=projected});
                }
                if(percent!=last||count>0)Record(new {operation="CurrentSourceCheck.Progress",hresult=hr,code=code,
                    percent=percent,count=count,reports=rows,
                    progress_interface=wide?"original wide CompilerAdapter":"original narrow CompilerIEC"});
                last=percent;
                if(percent==100) {
                    finished=true;
                    Record(new {operation="CurrentSourceCheck.ExecutionFinished",progress=percent,rejected=rejected,
                        original_public_program_check_promoted=false});
                    break;
                }
                Thread.Sleep(10);
            }
            if(!finished)Record(new {operation="CurrentSourceCheck.Incomplete",last_percent=last,
                rejected=rejected,public_program_check_promoted=false});
            return rejected;
        } finally {
            if(finished)foreach(IntPtr buffer in buffers)Marshal.FreeCoTaskMem(buffer);
            else unfinishedOwnedSourceBuffers.AddRange(buffers);
            Record(new {operation="CurrentSourceCheck.InputLifetime",native_execution_finished=finished,
                disposal=finished?"released after native progress 100":"retained until owned process exits"});
            Marshal.Release(native);
        }
    }
}
