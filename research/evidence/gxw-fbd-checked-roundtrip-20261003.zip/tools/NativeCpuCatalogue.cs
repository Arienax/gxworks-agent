// Owned, offline CPU metadata query. No controller connection or device calls.
using System;
using System.IO;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Web.Script.Serialization;
class NativeCpuCatalogue {
    [DllImport("ole32")] static extern int CoInitializeEx(IntPtr p,uint mode);
    [DllImport("ole32")] static extern int CoCreateInstance(ref Guid c,IntPtr p,uint context,ref Guid i,out IntPtr instance);
    [DllImport("kernel32")] static extern uint SetErrorMode(uint mode);
    [DllImport("kernel32",CharSet=CharSet.Unicode)] static extern bool SetDllDirectory(string path);
    [DllImport("kernel32",CharSet=CharSet.Unicode,EntryPoint="GetModuleHandleW")] static extern IntPtr Module(string name);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int SelfFn(IntPtr self);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int IntsFn(IntPtr self,int a,int b);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int InitFn(IntPtr self,IntPtr manager,int group,int connection);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int ListFn(IntPtr self,IntPtr data);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int IdListFn(IntPtr self,int id,IntPtr data);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int IdIntFn(IntPtr self,int id,out int value);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int IdStringFn(IntPtr self,int id,out IntPtr value);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int TypeInfoFn(IntPtr self,uint index,uint locale,out IntPtr value);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int StringWordFn(IntPtr self,ref IntPtr name,out ushort value);
    static JavaScriptSerializer json=new JavaScriptSerializer();
    static T Slot<T>(IntPtr self,int offset){return (T)(object)Marshal.GetDelegateForFunctionPointer(Marshal.ReadIntPtr(Marshal.ReadIntPtr(self),offset),typeof(T));}
    static void Emit(object value){Console.WriteLine(json.Serialize(value));}
    static void Check(string operation,int hr){Emit(new {operation=operation,hresult=hr});if(hr<0)throw new Exception(operation);}
    static string BStr(IntPtr p){if(p==IntPtr.Zero)return null;int size=Marshal.ReadInt32(p,-4);if(size<0||size>16384||(size&1)!=0)throw new Exception("unbounded name");return Marshal.PtrToStringUni(p,size/2);}
    static int[] Ids(IntPtr buffer){var ids=new List<int>();for(int n=0;n<4096;n++){int id=Marshal.ReadInt32(buffer,n*4);if(id==-1)return ids.ToArray();ids.Add(id);}throw new Exception("CPU list exceeded bound");}
    static void Clear(IntPtr buffer){for(int n=0;n<4096;n++)Marshal.WriteInt32(buffer,n*4,-1);}
    static IntPtr Create(string c,string i){Guid cls=new Guid(c),iid=new Guid(i);IntPtr p;Check("Create:"+c,CoCreateInstance(ref cls,IntPtr.Zero,1,ref iid,out p));return p;}
    [STAThread] static void Main(string[] args){
        SetErrorMode(3);CoInitializeEx(IntPtr.Zero,2);
        SetDllDirectory("D:/GXWORKS2/DNaviZero/DataAbsorber");
        IntPtr manager=Create("0bf65a7e-5f7d-4c34-927a-a24ef88a7c8a","00020400-0000-0000-c000-000000000046");
        Check("Manager.Initialize",Slot<SelfFn>(manager,28)(manager));
        Check("Manager.SupportControllerTypes",Slot<IntsFn>(manager,344)(manager,0x1fffff,1));
        IntPtr navigator=Create("04b63ec6-a740-4262-a2c0-eb007d570f4a","00020400-0000-0000-c000-000000000046");
        IntPtr module=Module("DZDataNavigatorServer.dll");
        for(int offset=0;offset<=28;offset+=4){IntPtr target=Marshal.ReadIntPtr(Marshal.ReadIntPtr(navigator),offset);Emit(new {operation="NavigatorSlot",offset=offset,rva=target.ToInt64()-module.ToInt64()});}
        Check("Navigator.Initialize",Slot<InitFn>(navigator,28)(navigator,manager,1,0));
        string[] interfaces={"9942d770-ee70-4a7d-975c-41a1592ae944","16c47b68-fd87-4f57-bf84-a7bb9be5b164","65646f2a-be8f-4220-807d-fddc7654dcf8","214a2571-cc61-477d-a029-f49e2ed44c5d","55d11c84-995b-4754-823b-3d264bc511e8","46d88051-0aaa-4ced-a92b-d8e491cc14c0","1bd333b4-b675-4708-b2f2-e139eabb1327","67b770b3-39b6-4d2d-a2b3-9d18afc83584","45a1b2bc-f308-4318-b81f-196c7ca7d9db","739d6d9a-1f84-4bc2-95eb-8639adea4a83","f48b168e-dfdf-4a17-9006-90f020c82bd4","622316bf-f268-41b6-92e2-e4d6d4fce7bd","ef8ac532-7918-4a9c-8017-251ab7bd7c5c","769a9ebc-499a-4383-b6c0-3ee8f4ac35ca","4d003920-9aa7-48a0-80fe-065abf6736c9","1627a5bc-a3b4-4d91-92fb-4d2239ed9b8e","e81f5339-ac3a-45ec-80e4-8ff705f97eb8"};
        if(args.Length>0&&(args[0]=="types"||args[0]=="interfaces")){
            foreach(string text in interfaces){
                Guid g=new Guid(text);IntPtr face,info;int result=Marshal.QueryInterface(navigator,ref g,out face);Check("Query:"+text,result);
                if(args[0]=="interfaces"){
                    for(int offset=28;offset<=36;offset+=4){IntPtr target=Marshal.ReadIntPtr(Marshal.ReadIntPtr(face),offset);Emit(new {operation="InterfaceSlot",guid=text,offset=offset,rva=target.ToInt64()-module.ToInt64()});}
                    Marshal.Release(face);continue;
                }
                result=Slot<TypeInfoFn>(face,16)(face,0,0,out info);
                if(result<0){Emit(new {operation="TypeInfoFailure",guid=text,hresult=result});continue;}
                var type=(ITypeInfo)Marshal.GetObjectForIUnknown(info);string name,doc,file;int context;
                type.GetDocumentation(-1,out name,out doc,out context,out file);
                Emit(new {operation="InterfaceType",guid=text,name=name});Marshal.Release(face);Marshal.Release(info);
            }
            return;
        }
        Guid iid=new Guid("f48b168e-dfdf-4a17-9006-90f020c82bd4");IntPtr foreign;
        Check("Navigator.QueryForeign",Marshal.QueryInterface(navigator,ref iid,out foreign));
        for(int offset=196;offset<=224;offset+=4){IntPtr target=Marshal.ReadIntPtr(Marshal.ReadIntPtr(foreign),offset);Emit(new {operation="ForeignSlot",offset=offset,rva=target.ToInt64()-module.ToInt64()});}
        if(args.Length>0&&args[0]=="map")return;
        IntPtr buffer=Marshal.AllocCoTaskMem(4096*4);
        Clear(buffer);Check("Foreign.GetPlcSeriesIDList",Slot<ListFn>(foreign,212)(foreign,buffer));int[] series=Ids(buffer);
        if(series.Length==0&&args.Length>1){
            string[] values=args[1].Split(',');series=new int[values.Length];
            for(int n=0;n<values.Length;n++)series[n]=Int32.Parse(values[n]);
            Emit(new {operation="InspectedNativeTableSeries",ids=series});
        }
        Emit(new {operation="SeriesIDs",ids=series});
        foreach(int s in series){
            Clear(buffer);Check("Foreign.GetPlcTypeIDList",Slot<IdListFn>(foreign,216)(foreign,s,buffer));int[] ids=Ids(buffer);
            foreach(int id in ids){
                IntPtr name;int language,seriesEx;
                Check("Foreign.GetPlcTypeString",Slot<IdStringFn>(foreign,200)(foreign,id,out name));string text=BStr(name);Marshal.FreeBSTR(name);
                Check("Foreign.GetPlcTypeLanguage",Slot<IdIntFn>(foreign,204)(foreign,id,out language));
                Check("Foreign.GetPlcSeriesEx",Slot<IdIntFn>(foreign,208)(foreign,id,out seriesEx));
                IntPtr str=Marshal.StringToBSTR(text);ushort cpu,es;
                Check("Foreign.GetCpuTypeID",Slot<StringWordFn>(foreign,32)(foreign,ref str,out cpu));
                Check("Foreign.GetESCpuTypeID",Slot<StringWordFn>(foreign,40)(foreign,ref str,out es));Marshal.FreeBSTR(str);
                Emit(new {operation="CpuCatalogue",series=s,id=id,name=text,language=language,series_ex=seriesEx,cpu=cpu,es_cpu=es});
            }
        }
        Marshal.FreeCoTaskMem(buffer);
    }
}
