"""Owned offline source-location queries; native reports remain unchanged."""
from pathlib import Path
import json
import sys

import probe_application_check_resources as trace

P = Path(__file__).resolve().parent
ROOT = P.parents[3]
sys.path.insert(0, str(ROOT / 'src'))
from gxw.object_model import read_project_context

OUT = P / 'diagnostic-source-locations-20261002-v1'
A = P / 'application-fbd-v2-20261002-v1'


def errors(directory):
    rows = [json.loads(line).get('payload', {}) for line in
            (directory / 'observation-events.jsonl').read_text().splitlines()]
    reports = []
    seen = set()
    for row in rows:
        if row.get('event') == 'backend-check-progress':
            values = row.get('reports', [])
        elif row.get('event') == 'diagnostic-projection-failure':
            values = [row['report']]
        else:
            continue
        for report in values:
            if report.get('kind') not in (2, 3):
                continue
            key = json.dumps({k: v for k, v in report.items() if k != 'raw_hex'}, sort_keys=True)
            if key not in seen:
                seen.add(key)
                reports.append(report)
    # A report returned before percent=100 is retained without asserting that
    # the backend completed or that this is its complete diagnostic list.
    return reports


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    OUT.mkdir(exist_ok=False)
    results = []
    for cpu, control in (
        ('Q03UDV', 'Q03UDV-attempt-2'),
        ('FX3U/FX3UC', 'FX3U-FX3UC-attempt-2'),
        ('L02', 'L02-attempt-1'),
    ):
        frozen = A / ('full-' + cpu.replace('/', '-')) / 'native-compile'
        original = P / 'owned-diagnostic-controls-20261002-v1' / control
        reports = errors(original)
        steps = sorted({0, *(report['step'] + delta for report in reports for delta in (-1, 0, 1))})
        queries = [dict(resource='MAIN', start_step=step, step_count=1, timestamp=stamp)
                   for step in steps for stamp in (0, -1)]
        for attempt in range(1, 17):
            directory = OUT / (cpu.replace('/', '-') + '-attempt-' + str(attempt))
            script = trace.prepare(directory, frozen)
            raw = (original / 'input.gxw').read_bytes()
            (directory / 'input.gxw').write_bytes(raw)
            context = read_project_context(raw, 'FBD_MATRIX.Program.pou')
            trace.save(directory / 'source-model.json', context.object_model())
            plan = json.loads((directory / 'plan.json').read_text())
            plan['pcode_location_queries'] = queries
            trace.save(directory / 'plan.json', plan)
            returncode, messages = trace.run(directory, script)
            result = trace.summarize(directory, returncode, messages)
            locations = directory / 'native-pcode-locations.json'
            result.update(cpu=cpu, control=str(original), expected_backend_errors=reports,
                          locations=json.loads(locations.read_text(encoding='utf-8-sig')) if locations.exists() else [],
                          current_pcode_equal_to_control=all(
                              (directory / f'pcode-0-{i}.bin').exists() and
                              (directory / f'pcode-0-{i}.bin').read_bytes() ==
                              (original / f'pcode-0-{i}.bin').read_bytes() for i in range(3)))
            trace.save(directory / 'result-with-locations.json', result)
            results.append(result)
            trace.save(OUT / 'results.json', results)
            print(json.dumps({key: result[key] for key in ('cpu', 'returncode',
                  'checker_read_correspondence', 'diagnostic_projection',
                  'current_pcode_equal_to_control', 'locations')}, ensure_ascii=False), flush=True)
            if returncode != 5:
                break


if __name__ == '__main__':
    main()
