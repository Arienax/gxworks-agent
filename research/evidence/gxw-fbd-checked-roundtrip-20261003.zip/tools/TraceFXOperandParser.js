// Append to TraceFXOperandRules.js so both observations share request IDs.
Process.attachModuleObserver({ onAdded(m) {
    if (m.name.toLowerCase() !== 'eccodegeneratorfx2.dll') return;
    const base = m.base;
    Interceptor.attach(base.add(0x25011), {
        onEnter(a) {
            this.ref = a[0]; this.start = a[0].readPointer();
            const index = a[2].toUInt32() & 255;
            if (index < 1 || index > 8) throw new Error('Unmeasured FX parser index');
            this.p = a[1].add((index - 1) * 9);
            this.row = { event: 'operand-parse', request, index,
                cpu: base.add(0x928a8).readU16(), cpu_class: base.add(0x928ac).readU16(),
                initial_descriptor: hex(this.p, 9) };
        },
        onLeave(r) {
            this.row.result = shortResult(r);
            const last = this.ref.readPointer();
            const delta = last.sub(this.start).toInt32();
            const length = last.readU8();
            if (delta < 0 || delta > 128 || length > 255) throw new Error('Parser observation outside bounded tokens');
            this.row.base_offset = delta;
            this.row.raw = hex(this.start, delta + Math.max(2, length));
            this.row.terminal_length = length;
            this.row.descriptor = hex(this.p, 9);
            this.row.last_value = base.add(0x928a0).readU32();
            send(this.row);
        }
    });
} });
