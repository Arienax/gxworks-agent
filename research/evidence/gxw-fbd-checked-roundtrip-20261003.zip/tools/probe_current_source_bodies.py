"""Read-only observation of the native POU body record used by source Check.

Offsets come from LocalConvertData's verified native implementation. Field
counts and text roles remain observations until controlled inputs identify them.
"""
from pathlib import Path
import json
import sys

P=Path(__file__).resolve().parent
sys.path.insert(0,str(P))
import probe_current_source_check as probe
from gxw.container_writer import validate_cfb_streams
from gxw.project_metadata import logical_mapping

probe.OUT=P/'current-source-body-records-20261002-v4'
probe.CASES=[('FX3U/FX3UC','pou',['','FBD_MATRIX']),('FX3U/FX3UC','fb',['','MODULE_FB'])]
probe.VERBOSE=False
BODY_OBSERVER=r'''
const ownedNativeBodyExpectedInputs=OWNED_EXPECTED_INPUTS;
const ownedNativeBodySites=new Set();
const ownedNativeBodyGetterScopes=new Map();
function ownedBindNativeBodyModule(m){
 if(!m||m.name.toLowerCase()!=='dzdataabs_datamanager_iec.dll'||ownedNativeBodySites.has(m.base.toString()))return;
 ownedNativeBodySites.add(m.base.toString());
 send({event:'owned-native-source-body-reader-hook',address:loc(m.base.add(0x3348e))});
 Interceptor.attach(m.base.add(0x331d5),{
  onEnter(a){this.owned=false;if(!ownedSourceCheckEver||phase!=='source-check')return;
   try {
    const bytes=[];
    for(let i=0;i<256;i++){const value=a[0].add(i).readU8();if(value===0)break;bytes.push(value);}
    const name=String.fromCharCode(...bytes);
    if(!name.includes('FBD_MATRIX')&&!name.includes('MODULE_FB'))return;
    this.owned=true;this.prior=ownedNativeBodyGetterScopes.get(this.threadId);
    ownedNativeBodyGetterScopes.set(this.threadId,name);
    send({event:'owned-native-source-body-getter-enter',name});
   }catch(e){send({event:'observation-error',phase:'native-source-body-getter-enter',error:String(e)});}
  },
  onLeave(){if(!this.owned)return;
   if(this.prior===undefined)ownedNativeBodyGetterScopes.delete(this.threadId);
   else ownedNativeBodyGetterScopes.set(this.threadId,this.prior);
  }
 });
 Interceptor.attach(m.base.add(0x3348e),{
  onEnter(a){this.getter=ownedNativeBodyGetterScopes.get(this.threadId);this.owned=!!this.getter;if(!this.owned)return;
   try{
    const size=a[0].toInt32();
    if(size<0x40||size>2097152)throw new Error('owned native source body input size bound');
    this.input=a[1];this.size=size;this.output=a[2];this.offset=a[3];
    this.raw=hex(this.input,size);
    this.ownedName=Object.keys(ownedNativeBodyExpectedInputs).find(name=>ownedNativeBodyExpectedInputs[name]===this.raw);
   }catch(e){this.owned=false;send({event:'observation-error',phase:'native-source-body-record-enter',error:String(e)});}
  },
  onLeave(r){if(!this.owned)return;try{
   const body=this.output.add(0x11).readPointer(),body_offset=body.sub(this.input).toInt32();
   send({event:'native-source-body-record',original_code:r.toUInt32(),input_size:this.size,input_hex:this.raw,
    matched_owned_source:this.ownedName,
    original_getter_selection:this.getter,
    input_pointer:this.input.toString(),record_pointer:this.output.toString(),
    record_version:this.output.readU16(),source_kind:this.output.add(2).readU8(),
    field_u32_at_5:this.output.add(5).readU32(),field_u32_at_9:this.output.add(9).readU32(),
    field_u32_at_13:this.output.add(13).readU32(),body_offset,
    body_pointer_inside_input:body_offset>=0&&body_offset<this.size,
    original_cursor:this.offset.isNull()?null:this.offset.readS32(),record_header_hex:hex(this.output,21)});
  }catch(e){send({event:'observation-error',phase:'native-source-body-record-return',error:String(e)});}}
 });
}
const ownedNativeBodyObserver=Process.attachModuleObserver({onAdded(m){
 ownedBindNativeBodyModule(m);
 if(m.name.toLowerCase()==='dzdataabs_compiler_iec.dll')Interceptor.attach(m.base.add(0x6f2c),{
  onEnter(){ownedBindNativeBodyModule(Process.findModuleByName('DZDataABS_DataManager_IEC.dll'));}
 });
}});
'''
prior=next(row for row in json.loads((P/'diag-cpu-20261002-v1/results.json').read_text(encoding='utf-8'))
    if row['cpu']=='FX3U/FX3UC' and row['returncode']!=5)
outer=validate_cfb_streams((Path(prior['directory'])/'input.gxw').read_bytes())
nested=validate_cfb_streams(outer['_hdb']);mapping=logical_mapping(outer['projectdatalist.xml'])
expected={name:nested[mapping[name]].hex() for name in ('FBD_MATRIX.Program.pou','MODULE_FB.Program.pou')}
BODY_OBSERVER=BODY_OBSERVER.replace('OWNED_EXPECTED_INPUTS',json.dumps(expected))
probe.BACKEND_OBSERVER+=BODY_OBSERVER


if __name__=='__main__':
    probe.main()
