'use strict';
let sfcInput = null;
function sfcHex(p,n) { return Array.from(new Uint8Array(p.readByteArray(n)), b => b.toString(16).padStart(2,'0')).join(''); }
function sfcShort(r) { return (r.toInt32() << 16) >> 16; }
Process.attachModuleObserver({onAdded(m) {
    if(m.name.toLowerCase() !== 'eccodegeneratorfx2.dll') return;
    const base=m.base;
    Interceptor.attach(m.findExportByName('ConvertPcodeToSFC'),{
        onEnter(a) {sfcInput=a[1];this.result=a[2];},
        onLeave(r) {send({event:'public-sfc-decode',code:r.toInt32(),result:this.result.readS16()});}
    });
    for(const [rva,event] of [[0x5f3cf,'sfc-primitive'],[0x5fbbc,'sfc-classified']]) {
        Interceptor.attach(base.add(rva),{
            onEnter(a) {
                this.emit=sfcInput !== null && a[4].equals(sfcInput);
                if(!this.emit)return;
                this.family=a[0];this.variant=a[1];this.value=a[2];this.length=a[3];this.cursor=a[5];
                const offset=this.cursor.readU32();
                if(offset>65536)throw new Error('SFC parser cursor outside owned bounded source');
                const token=a[4].add(offset),n=token.readU8();
                this.row={event:event,offset:offset,raw:sfcHex(token,n||1),peek:sfcHex(token,4),
                    initial:{family:this.family.readU8(),variant:this.variant.readU8(),value:this.value.readU16(),length:this.length.readU8()}};
            },
            onLeave(r) {
                if(!this.emit)return;
                this.row.result=sfcShort(r);this.row.offset_after=this.cursor.readU32();
                this.row.fields={family:this.family.readU8(),variant:this.variant.readU8(),value:this.value.readU16(),length:this.length.readU8()};
                send(this.row);
            }
        });
    }
}});
