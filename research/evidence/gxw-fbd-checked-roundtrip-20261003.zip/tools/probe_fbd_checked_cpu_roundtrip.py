"""Expand the checked Chinese FBD module over every retained native CPU seed.

Each case uses that exact CPU's native factory/save fixture. Preserve original
failures and distinguish unsupported or unverified menu choices from passes.
"""
from pathlib import Path
import json
import sys
import traceback

P=Path(__file__).resolve().parent
sys.path.insert(0,str(P))
import probe_fbd_cold_checked_roundtrip as checked
import probe_fbd_project_codepage as codepage

status=checked.status
normal=status.normal
OUT=P/'fbd-checked-cpu-roundtrip-20261003-v1'


def adapt(path):
    checked.adapt(path)
    if checked.SAVE:codepage.configure(path)


def stage(directory,input_path,label,save):
    checked.SAVE=save
    status.SAVED=input_path
    status.OUT=directory
    status.CASES=[(label,[],{'owned_current_source_selection':checked.mode.query(True)})]
    normal.RESULTS=[];normal.EVALUATIONS=[];normal.CACHED_NATIVE=[];normal.NEXT_CASE=0
    status.main()
    native=Path(normal.RESULTS[-1]['directory'])
    result=checked.verified(native,codepage_setter=save)
    events=checked.events(native)
    result['native_cpu_name']=[e['cpu'] for e in events if e.get('operation')=='NativeProjectAttributes']
    result['native_cpu_engine_key']=json.loads((native/'current-source-backend.json').read_text())['native_cpu_engine_key']
    return native,result


def preserved(before,after):
    a=normal.read_project_context(before,'FBD_MATRIX.Program.pou')
    b=normal.read_project_context(after,'FBD_MATRIX.Program.pou')
    graph=[r.raw for r in a.program.iter_records()]==[r.raw for r in b.program.iter_records()]
    blocks=[r.raw_header for r in a.program.blocks]==[r.raw_header for r in b.program.blocks]
    labels={n:[r.raw for r in d.rows] for n,d in a.declarations.items()}=={
        n:[r.raw for r in d.rows] for n,d in b.declarations.items()}
    assert graph and blocks and labels
    assert checked.body(before)==checked.body(after)
    return dict(graph_records_exact=graph,block_headers_exact=blocks,declaration_rows_exact=labels,st_source_exact=True)


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    OUT.mkdir(exist_ok=False)
    (OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    seeds=json.loads((P/'application-fbd-v2-20261002-v1/native-results.json').read_text())
    menu=json.loads((P/'cpu-fbd-matrix-20261002-v1/module-matrix-targets.json').read_text())
    prior=json.loads((P/'cpu-fbd-matrix-20261002-v1/module-matrix-results.json').read_text())
    known={row['cpu'] for row in seeds}
    assert len(seeds)==len(known)==55
    unverified=[dict(target=row,reason='no retained successful native FBD seed',
        prior_outcomes=[dict(status=r['status'],directory=r['directory']) for r in prior if r['cpu']==row['cpu']])
        for row in menu if row['cpu'] not in known]
    normal.probe.trace.save(OUT/'scope.json',dict(exact_cpu_options=len(menu),native_seed_options=len(seeds),
        unverified_options=unverified,independent_project_family_count=1,dll_version='1.635.0.1',
        scenario='Chinese instance/paired declaration rename, normalized FBD, current source and resource checks, save and cold reopen',
        plc_execution='not_run'))
    status.ADAPT_EXTRA=adapt
    status.EXTRA_OBSERVER+=checked.mode.header.HEADER_OBSERVER+checked.mode.MODE_OBSERVER
    rows=[]
    for index,seed in enumerate(seeds):
        cpu=seed['cpu'];root=OUT/f'cpu-{index:02d}';root.mkdir()
        row=dict(cpu=cpu,seed=seed['application_case'],directory=str(root),status='started')
        try:
            normal.FROZEN=Path(seed['application_case'])/'native-compile'
            normal.RAW=(normal.FROZEN/'native-saved.gxw').read_bytes()
            normal.CONTEXT=normal.read_project_context(normal.RAW,'FBD_MATRIX.Program.pou')
            assert normal.CONTEXT.object_model()['cpu']==cpu
            candidate,_,edit=normal.candidate(dict(instance='OWNED_\u6a21\u5757_A'))
            normal.probe.trace.save(root/'edit.json',edit)
            source=root/'chinese-input.gxw';source.write_bytes(candidate)
            native,row['save']=stage(root/'save',source,'checked-save',True)
            assert row['save']['native_cpu_name']==[cpu] and row['save']['exported']
            saved=native/'native-saved.gxw'
            row['preservation']=preserved(candidate,saved.read_bytes())
            reopened,row['cold_reopen']=stage(root/'cold-reopen',saved,'checked-cold-reopen',False)
            assert row['cold_reopen']['native_cpu_name']==[cpu]
            assert row['save']['native_cpu_engine_key']==row['cold_reopen']['native_cpu_engine_key']
            assert (reopened/'input.gxw').read_bytes()==saved.read_bytes()
            row['status']='passed'
        except Exception as error:
            row.update(status='not_verified',error=repr(error),traceback=traceback.format_exc())
            if normal.RESULTS:row['last_native_result']=normal.RESULTS[-1]
        rows.append(row)
        normal.probe.trace.save(OUT/'results.json',rows)
        print(json.dumps(dict(index=index,cpu=cpu,status=row['status'],completed=len(rows),
            passed=sum(r['status']=='passed' for r in rows),error=row.get('error')),ensure_ascii=True),flush=True)


if __name__=='__main__':main()
