// Complete an owned vendor export with its zero-length vendor-created marker.
// Uses the system compound-storage implementation; no project fields are edited.
using System;
using System.IO;
using System.Runtime.InteropServices;

class NativeStorageMarkerOracle {
    [DllImport("ole32")] static extern int CoInitializeEx(IntPtr reserved,uint mode);
    [DllImport("ole32")] static extern void CoUninitialize();
    [DllImport("ole32",CharSet=CharSet.Unicode)] static extern int StgOpenStorage(
        string name,IntPtr priority,uint mode,IntPtr exclusions,uint reserved,out IntPtr storage);
    [UnmanagedFunctionPointer(CallingConvention.StdCall,CharSet=CharSet.Unicode)]
    delegate int CreateStreamFn(IntPtr self,[MarshalAs(UnmanagedType.LPWStr)] string name,
        uint mode,uint reserved1,uint reserved2,out IntPtr stream);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int CommitFn(IntPtr self,uint flags);
    static T Slot<T>(IntPtr instance,int offset) {
        return (T)(object)Marshal.GetDelegateForFunctionPointer(Marshal.ReadIntPtr(Marshal.ReadIntPtr(instance),offset),typeof(T));
    }
    [STAThread] static void Main(string[] args) {
        if(args.Length!=3)throw new ArgumentException("input export, native marker, owned output");
        if(new FileInfo(args[1]).Length!=0)throw new ArgumentException("Only an observed empty native marker is accepted");
        string destination=Path.GetFullPath(args[2]);
        if(File.Exists(destination))throw new IOException("Owned destination exists");
        File.Copy(args[0],destination,false);
        Marshal.ThrowExceptionForHR(CoInitializeEx(IntPtr.Zero,2));
        IntPtr storage=IntPtr.Zero,stream=IntPtr.Zero;
        try {
            Marshal.ThrowExceptionForHR(StgOpenStorage(destination,IntPtr.Zero,0x12,IntPtr.Zero,0,out storage));
            Marshal.ThrowExceptionForHR(Slot<CreateStreamFn>(storage,12)(storage,"Project.gd2",0x12,0,0,out stream));
            Marshal.Release(stream);stream=IntPtr.Zero;
            Marshal.ThrowExceptionForHR(Slot<CommitFn>(storage,36)(storage,0));
            Console.WriteLine("{\"created_stream\":\"Project.gd2\",\"length\":0}");
        } finally {
            if(stream!=IntPtr.Zero)Marshal.Release(stream);
            if(storage!=IntPtr.Zero)Marshal.Release(storage);
            CoUninitialize();
        }
    }
}
