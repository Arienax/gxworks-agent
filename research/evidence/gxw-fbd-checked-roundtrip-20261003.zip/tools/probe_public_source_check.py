"""Compare typed public source Check with compiled-resource ProgramCheck.

The unit kinds 3, 5 and 6 are tentative selections borrowed from a different
diagnostic-object mapping. Their process-unit meaning is not established.
No native return or check output is replaced.
"""
from pathlib import Path
import json
import shutil
import sys

P = Path(__file__).resolve().parent
sys.path.insert(0, str(P))
import probe_native_check_drain as drain
import probe_application_check_resources as trace

OUT = P / 'public-source-check-20261002-v1'
DECLARATIONS = '''
    [StructLayout(LayoutKind.Sequential)] struct OwnedSelectInformation {
        public int row; public IntPtr name;
    }
    [StructLayout(LayoutKind.Sequential)] struct OwnedProcessUnit {
        public int kind; public int count; public IntPtr selections;
    }
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int OwnedSourceCheckFn(
        IntPtr self,int reportKind,int count,IntPtr units,out int code);
'''
SOURCE_CHECK = '''
            if(plan.ContainsKey("owned_source_check_units")&&!compilerRejected) {
                foreach(Dictionary<string,object> query in
                    (System.Collections.IEnumerable)plan["owned_source_check_units"]) {
                    var selection=new OwnedSelectInformation{row=Convert.ToInt32(query["row"]),
                        name=BStr((string)query["name"])};
                    IntPtr item=Marshal.AllocCoTaskMem(8),unit=Marshal.AllocCoTaskMem(12);
                    try {
                        Marshal.StructureToPtr(selection,item,false);
                        Marshal.StructureToPtr(new OwnedProcessUnit{
                            kind=Convert.ToInt32(query["kind"]),count=1,selections=item},unit,false);
                        Record(new {operation="PublicSourceCheckSelection",query=query,
                            unit_size=Marshal.SizeOf(typeof(OwnedProcessUnit)),
                            selection_size=Marshal.SizeOf(typeof(OwnedSelectInformation))});
                        Check("Compiler.SourceCheck",Slot<OwnedSourceCheckFn>(compiler,32)(compiler,
                            -1,1,unit,out code),code);
                        bool sourceRejected=WaitReports(compiler,40,"SourceCheckProgress");
                        Record(new {operation="PublicSourceCheckCompleted",query=query,rejected=sourceRejected});
                        compilerRejected|=sourceRejected;
                    } finally {Marshal.FreeCoTaskMem(unit);Marshal.FreeCoTaskMem(item);}
                }
            }
'''


def adapt(path):
    ORIGINAL_ADAPT(path)
    text = path.read_text(encoding='utf-8')
    anchor = '    static List<IntPtr> strings=new List<IntPtr>();'
    if text.count(anchor) != 1:
        raise ValueError('Owned source-check ABI insertion differs')
    text = text.replace(anchor, DECLARATIONS + anchor)
    anchor = '            if(plan.ContainsKey("program_check_kind")&&!compilerRejected) {'
    if text.count(anchor) != 1:
        raise ValueError('Owned source-check stage insertion differs')
    text = text.replace(anchor, SOURCE_CHECK + anchor)
    path.write_text(text, encoding='utf-8')
    plan_path = path.parent / 'plan.json'
    plan = json.loads(plan_path.read_text(encoding='utf-8'))
    plan['owned_source_check_units'] = UNITS
    trace.save(plan_path, plan)


ORIGINAL_ADAPT = drain.adapt_helper
UNITS = []


def main():
    global UNITS
    sys.stdout.reconfigure(encoding='utf-8')
    OUT.mkdir(exist_ok=False)
    shutil.copyfile(Path(__file__), OUT / Path(__file__).name)
    prior = next(row for row in json.loads((P / 'diag-cpu-20261002-v1/results.json').read_text(
        encoding='utf-8')) if row['cpu']=='FX3U/FX3UC' and row['returncode']!=5)
    raw = (Path(prior['directory']) / 'input.gxw').read_bytes()
    frozen = trace.A / 'full-FX3U-FX3UC/native-compile'
    results = []
    drain.adapt_helper = adapt
    try:
        for index, (kind, name) in enumerate([(3,'MAIN'),(6,'FBD_MATRIX'),(5,'MODULE_FB'),
                                            (6,'OWNED_ABSENT_POU')]):
            UNITS = [dict(kind=kind, name=name, row=-1)]
            for attempt in range(1,17):
                directory = OUT / f'c{index}-a{attempt}'
                result = drain.run(directory, frozen, raw)
                events = [json.loads(line) for line in (directory / 'native-events.jsonl').read_text(
                    encoding='utf-8-sig').splitlines()]
                source_events = [event for event in events if event.get('operation','').startswith(
                    ('Compiler.SourceCheck','PublicSourceCheck','SourceCheckProgress'))]
                result.update(source_check_events=source_events, selected_units=UNITS)
                trace.save(directory / 'result-with-source-check.json', result)
                results.append(result)
                trace.save(OUT / 'results.json', results)
                compact = [dict(operation=event['operation'],percent=event.get('percent'),
                    hresult=event.get('hresult'),code=event.get('code'),rejected=event.get('rejected'),
                    errors=[dict(kind=r['kind'],code=hex(r['code']),name=r['name'],instance=r['instance'])
                        for r in event.get('reports',[]) if r['kind'] in [2,3]])
                    for event in source_events if event.get('operation')!='SourceCheckProgress'
                    or event.get('percent')==100 or any(r['kind'] in [2,3] for r in event.get('reports',[]))]
                print(json.dumps(dict(selection=UNITS,returncode=result['returncode'],source=compact,
                    native_targets=len(result['native_target_results']),
                    original_diagnostics=len(result['original_native_diagnostics'])),ensure_ascii=False),flush=True)
                if result['returncode']!=5:
                    break
    finally:
        drain.adapt_helper = ORIGINAL_ADAPT


if __name__ == '__main__':
    main()
