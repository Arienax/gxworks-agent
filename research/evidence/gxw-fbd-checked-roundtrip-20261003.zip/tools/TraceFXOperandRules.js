'use strict';
let request = -1;
let encoding = 0;
function hex(p, n) {
    return Array.from(new Uint8Array(p.readByteArray(n)), b => b.toString(16).padStart(2, '0')).join('');
}
function shortResult(r) { return (r.toInt32() << 16) >> 16; }
Process.attachModuleObserver({ onAdded(m) {
    if (m.name.toLowerCase() !== 'eccodegeneratorfx2.dll') return;
    const base = m.base;
    function context() {
        return { request, cpu: base.add(0x928a8).readU16(), cpu_class: base.add(0x928ac).readU16() };
    }
    Interceptor.attach(m.findExportByName('ChangeILToPcode'), {
        onEnter(a) { request++; encoding++; this.row = { event: 'encode', ...context() }; },
        onLeave(r) { encoding--; this.row.result = r.toInt32(); send(this.row); }
    });
    Interceptor.attach(m.findExportByName('CheckInstructionCode2'), {
        onEnter(a) {
            if (!encoding) request++;
            this.row = { event: 'check', ...context() };
            this.buffers = a[1];
            this.status = a[4];
            this.row.input = hex(a[1].add(8).readPointer(), a[1].add(4).readU32());
        },
        onLeave(r) {
            this.row.result = r.toInt32(); this.row.status = this.status.readS16();
            this.row.output = hex(this.buffers.add(8).readPointer(), this.buffers.add(4).readU32());
            send(this.row);
        }
    });
    Interceptor.attach(base.add(0x251ab), {
        onEnter(a) {
            const index = a[1].toUInt32() & 255;
            if (index < 1 || index > 8) throw new Error('Unmeasured FX operand index');
            this.p = a[0].add((index - 1) * 9);
            this.row = { event: 'operand-capability', ...context(), index, before: hex(this.p, 9) };
        },
        onLeave(r) { this.row.result = shortResult(r); this.row.after = hex(this.p, 9); send(this.row); }
    });
    Interceptor.attach(base.add(0x25546), {
        onEnter(a) {
            const index = a[3].toUInt32() & 255;
            if (index < 1 || index > 8) throw new Error('Unmeasured FX rule index');
            this.row = { event: 'operand-rule', ...context(), family: a[0].toUInt32() & 255,
                variant: a[1].toUInt32() & 255, index, descriptors: hex(a[2], index * 9),
                descriptor: hex(a[2].add((index - 1) * 9), 9) };
        },
        onLeave(r) { this.row.result = shortResult(r); send(this.row); }
    });
    send({ event: 'module', name: m.name, size: m.size, module: m.path,
        capability_prefix: hex(base.add(0x251ab), 13), rule_prefix: hex(base.add(0x25546), 13) });
} });
