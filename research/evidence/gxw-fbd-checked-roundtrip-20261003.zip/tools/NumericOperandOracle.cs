// Offline public IL-to-token conversion; a fresh object for each request.
// No project, controller, simulator or private native interface is exposed.
using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;

public static class NumericOperandOracle {
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode)] static extern IntPtr LoadLibraryEx(string path,IntPtr file,uint flags);
    [DllImport("kernel32.dll",CharSet=CharSet.Ansi,ExactSpelling=true)] static extern IntPtr GetProcAddress(IntPtr module,string name);
    [DllImport("kernel32.dll")] static extern uint SetErrorMode(uint mode);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate IntPtr Create();
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Open(IntPtr h,int cpu,int mode);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Version(IntPtr h,int count,[In] uint[] versions);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Close(IntPtr h);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate void Destroy(IntPtr h);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Encode(IntPtr h,[In] byte[] input,int size,int option1,int option2,[Out] byte[] output,ref int capacity,ref int lastKind,IntPtr context);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int ErrorOffset(IntPtr h,ref int offset);
    static T Export<T>(IntPtr m,string n) where T:class {
        IntPtr p=GetProcAddress(m,n);if(p==IntPtr.Zero)throw new Exception("Missing export: "+n);
        return Marshal.GetDelegateForFunctionPointer(p,typeof(T)) as T;
    }
    public static int Main(string[] args) {
        if(IntPtr.Size!=4||args.Length!=4)return 2;
        SetErrorMode(3);
        int cpu=int.Parse(args[1]);
        if(cpu!=521&&cpu!=209)throw new Exception("Unmeasured CPU");
        string expectedVersion=cpu==521?"15.31":"15.41";
        if(FileVersionInfo.GetVersionInfo(args[0]).FileVersion!=expectedVersion)throw new Exception("Unmeasured converter version");
        IntPtr m=LoadLibraryEx(args[0],IntPtr.Zero,8);if(m==IntPtr.Zero)throw new Exception("Load failed");
        Create create=Export<Create>(m,"ObjectNew");Open open=Export<Open>(m,"Open");
        Version version=Export<Version>(m,"SetVersion");Close close=Export<Close>(m,"Close");Destroy destroy=Export<Destroy>(m,"ObjectDelete");
        Encode encode=Export<Encode>(m,"ChangeILToPcode");ErrorOffset error=Export<ErrorOffset>(m,"GetErrorOffset");
        using(StreamWriter output=new StreamWriter(args[3])) {
            foreach(string line in File.ReadLines(args[2])) {
                string[] parts=line.Split('\t');if(parts.Length!=3)throw new Exception("Request framing");
                int id=int.Parse(parts[0]),option=int.Parse(parts[1]);
                if(option!=0&&option!=1)throw new Exception("Unmeasured encoding option");
                byte[] raw=Convert.FromBase64String(parts[2]);
                if(raw.Length<2||raw.Length>2048||raw[raw.Length-1]!=0||raw[raw.Length-2]!=0)throw new Exception("Input bound or final delimiter");
                byte[] buffer=new byte[65536];int capacity=buffer.Length,lastKind=0,offset=-1,code;
                IntPtr h=create();if(h==IntPtr.Zero)throw new Exception("Create failed");
                try {
                    code=open(h,cpu,0);if(code!=0)throw new Exception("Open: "+code);
                    uint[] versions=cpu==521?new uint[0]:new uint[]{25};
                    code=version(h,versions.Length,versions);if(code!=0)throw new Exception("SetVersion: "+code);
                    code=encode(h,raw,raw.Length,option,0,buffer,ref capacity,ref lastKind,IntPtr.Zero);
                    if(capacity<0||capacity>buffer.Length)throw new Exception("Output bound");
                    if(code!=0)error(h,ref offset);
                } finally {close(h);destroy(h);}
                output.WriteLine("{\"id\":"+id+",\"code\":"+code+",\"capacity\":"+capacity+",\"last_kind\":"+lastKind+",\"error_offset\":"+offset+",\"output_base64\":\""+Convert.ToBase64String(buffer,0,code==0?capacity:0)+"\"}");
                output.Flush();
            }
        }
        return 0;
    }
}
