"""Set and observe only the imported owned project's native code page.

IDZDataABS_ProjectParameterOperation.SetCodePage slot 16 and GetCodePage slot 20
are read from this installation's Workspace type library. Application/CRT locale
and CPU selection remain those of the existing isolated frontend probe.
"""
from pathlib import Path
import json
import shutil
import sys

P = Path(__file__).resolve().parent
sys.path.insert(0, str(P))
import probe_fbd_native_normalization as normal

CODE_PAGE = 936


def adapt(path):
    normal.probe.adapt(path)
    configure(path)


def configure(path):
    source = path.read_text(encoding='utf-8')
    anchor = '                    Record(new {operation="NativeProjectCodePage",codepage=projectCodePage});'
    if source.count(anchor) != 1:raise ValueError('observed native project code-page query site differs')
    source = source.replace(anchor, anchor + '''
                    uint requestedCodePage=Convert.ToUInt32(plan["owned_project_codepage"]);
                    Check("OwnedProjectEncoding.SetCodePage",Slot<OwnedCodePageFn>(encodingInfo,16)(
                        encodingInfo,id,requestedCodePage,out code),code);
                    int actualCodePage;
                    Check("OwnedProjectEncoding.GetCodePage",Slot<IdOutIntFn>(encodingInfo,20)(
                        encodingInfo,id,out actualCodePage,out code),code);
                    Record(new {operation="OwnedProjectEncoding.Configured",before=projectCodePage,
                        requested=requestedCodePage,actual=actualCodePage,project=id.words});
                    if(actualCodePage!=requestedCodePage)throw new Exception("Owned code-page request did not take effect");
''')
    anchor = '    static List<IntPtr> strings=new List<IntPtr>();'
    if source.count(anchor) != 1:raise ValueError('owned delegate insertion site differs')
    source = source.replace(anchor, '''    [UnmanagedFunctionPointer(CallingConvention.StdCall)]
    delegate int OwnedCodePageFn(IntPtr self,ObjectId id,uint codePage,out int code);
''' + anchor)
    path.write_text(source, encoding='utf-8')
    plan = json.loads((path.parent/'plan.json').read_text(encoding='utf-8'))
    if not plan.get('native_attributes'):raise ValueError('native encoding observation is not enabled')
    plan['owned_project_codepage'] = CODE_PAGE
    normal.probe.trace.save(path.parent/'plan.json', plan)


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    normal.OUT = P/'fbd-project-codepage-20261002-v1/runs'
    normal.OUT.mkdir(exist_ok=False)
    for name in (Path(__file__).name, 'probe_fbd_native_normalization.py', 'native_fbd_body_codec.py'):
        shutil.copyfile(P/name, normal.OUT/name)
    probe = normal.probe
    prepare, adapt_helper, cs = probe.trace.prepare, probe.drain.adapt_helper, probe.trace.CS
    link_witness = probe.drain.link_witness
    def prepared(*args, **kwargs):
        active=probe.trace.CS;probe.trace.CS=cs
        try:return prepare(*args, **kwargs)+normal.dispatch.OBSERVER+probe.BACKEND_OBSERVER+normal.units.OBSERVER+normal.ACTIVE_TEXT_OBSERVER
        finally:probe.trace.CS=active
    def optional_link(directory):
        try:return link_witness(directory)
        except (normal.GXWFormatError, UnicodeError) as error:
            return dict(status='not_established',owned_decoder_error=str(error),native_outcome_changed=False)
    probe.trace.prepare=prepared;probe.drain.adapt_helper=adapt
    probe.trace.CS=cs+(probe.SOURCE,);probe.drain.link_witness=optional_link
    probe.QUERY=dict(kind=6,selections=[dict(row=-1,name=''),dict(row=-1,name='FBD_MATRIX')],wide_progress=True)
    try:
        normal.run_native(dict(instance='OWNED_ASCII_A'),label='cp936-ascii',encoding='gbk')
        normal.run_native(dict(instance='OWNED_\u6a21\u5757_A'),label='cp936-chinese',
                          encoding='gbk',assert_acceptance=False)
    finally:
        probe.trace.prepare,probe.drain.adapt_helper,probe.trace.CS=prepare,adapt_helper,cs
        probe.drain.link_witness=link_witness


if __name__ == '__main__':main()
