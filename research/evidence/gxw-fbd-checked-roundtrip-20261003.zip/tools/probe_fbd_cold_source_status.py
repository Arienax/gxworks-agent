"""Change only observed pending markers in an owned saved CP936 project.

The original clean reopen remains the negative control. No saved cache is
deleted, no native return is changed, and public Check is recorded separately.
"""
from pathlib import Path
import json
import shutil
import struct
import sys

P = Path(__file__).resolve().parent
sys.path.insert(0, str(P))
import probe_fbd_native_normalization as normal
from gxw.container_writer import validate_cfb_streams
from gxw.project_metadata import logical_mapping, mark_observed_source_compile_pending

SAVED = P/'fbd-project-codepage-20261002-v1/persistence/c000-save-cp936-a1/native-saved.gxw'
OUT = P/'fbd-cold-source-status-20261002-v1'
CASES = None
EXTRA_OBSERVER = ''
PLAN_OVERRIDES = {}
ADAPT_EXTRA = None


def marked(raw, names):
    outer = validate_cfb_streams(raw)
    mapping = logical_mapping(outer['projectdatalist.xml'])
    inner = validate_cfb_streams(outer['_hdb'])
    replacements, changes = {}, []
    for name in names:
        before = inner[mapping[name]]
        after = mark_observed_source_compile_pending(before, logical_name=name)
        differences = [i for i, (x, y) in enumerate(zip(before, after)) if x != y]
        assert differences in ([], [50])
        replacements[name] = after
        changes.append(dict(logical=name, before=struct.unpack_from('<I', before, 50)[0],
                            after=struct.unpack_from('<I', after, 50)[0], differences=differences))
    candidate, preservation = normal.patch(raw, replacements)
    return candidate, changes, preservation


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    OUT.mkdir(exist_ok=False)
    normal.OUT = OUT
    for name in (Path(__file__).name, 'probe_fbd_native_normalization.py', 'native_fbd_body_codec.py'):
        shutil.copyfile(P/name, OUT/name)
    probe = normal.probe
    prepare, adapt, cs = probe.trace.prepare, probe.drain.adapt_helper, probe.trace.CS
    link = probe.drain.link_witness
    def prepared(*args, **kwargs):
        active=probe.trace.CS;probe.trace.CS=cs
        try:return prepare(*args, **kwargs)+normal.dispatch.OBSERVER+probe.BACKEND_OBSERVER+normal.units.OBSERVER+normal.ACTIVE_TEXT_OBSERVER+EXTRA_OBSERVER
        finally:probe.trace.CS=active
    def optional_link(directory):
        cache = directory/'compiler/ESCompiler.stg'
        if cache.exists() and 'Index' not in validate_cfb_streams(cache.read_bytes()):
            return dict(status='not_established', owned_decoder_error='compiler cache has no Index stream',
                        native_outcome_changed=False)
        try:return link(directory)
        except (normal.GXWFormatError, UnicodeError) as error:
            return dict(status='not_established',owned_decoder_error=str(error),native_outcome_changed=False)
    def configured(path):
        probe.adapt(path)
        plan=json.loads((path.parent/'plan.json').read_text())
        plan.update(PLAN_OVERRIDES)
        probe.trace.save(path.parent/'plan.json',plan)
        if ADAPT_EXTRA is not None:ADAPT_EXTRA(path)
    probe.trace.prepare=prepared;probe.drain.adapt_helper=configured
    probe.trace.CS=cs+(probe.SOURCE,);probe.drain.link_witness=optional_link
    probe.QUERY=dict(kind=6,selections=[dict(row=-1,name=''),dict(row=-1,name='FBD_MATRIX')],wide_progress=True)
    saved = SAVED.read_bytes()
    outer = validate_cfb_streams(saved)
    mapping = logical_mapping(outer['projectdatalist.xml'])
    all_sources = [n for n in mapping if n.endswith(('.Program.pou', '.Labels.lh', '.gh'))]
    rows = []
    try:
        cases = CASES or [('selected-pou-pending', ['FBD_MATRIX.Program.pou']),
                          ('all-source-pending', all_sources)]
        for case in cases:
            label,names=case[:2]
            PLAN_OVERRIDES.clear()
            if len(case)==3:PLAN_OVERRIDES.update(case[2])
            raw, changes, preservation = marked(saved, names)
            normal.RAW = raw
            normal.CONTEXT = normal.read_project_context(raw, 'FBD_MATRIX.Program.pou')
            try:
                result = normal.run_native({}, label=label, assert_acceptance=False, encoding='gb18030',
                    configuration_key={'original_saved_project':str(SAVED),'pending_sources':names,
                                       'plan_overrides':dict(PLAN_OVERRIDES)})
                assertion = None
            except AssertionError as error:
                result = normal.RESULTS[-1]
                assertion = str(error) or 'owned comparison assertion failed; original native output retained'
            directory = Path(result['directory'])
            native = normal.snapshot_pou_bodies(directory/'frontend-snapshot.json', 'FBD_MATRIX')[0]
            events = [json.loads(line) for line in (directory/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
            row = dict(label=label, directory=str(directory), changes=changes, preservation=preservation,
                plan_overrides=dict(PLAN_OVERRIDES),
                gui_compile_status=struct.unpack_from('<I', normal.CONTEXT.program.raw, 50)[0],
                native_payload_word_at_68=struct.unpack_from('<I', native, 68)[0],
                source_check=result['source_check'], public_check=result['original_public_check'],
                project_codepage=[r for r in events if r.get('operation')=='NativeProjectCodePage'],
                original_public_check_events=[r for r in events if r.get('operation','').startswith(('ProgramCheck','NativeProgramCheck'))],
                native_errors=[r for r in events if r.get('hresult',0)<0],
                owned_assertion=assertion)
            rows.append(row)
            probe.trace.save(OUT/'status-controls.json', rows)
            print(json.dumps({k:row[k] for k in ('label','directory','changes','source_check','owned_assertion')},ensure_ascii=True),flush=True)
    finally:
        probe.trace.prepare,probe.drain.adapt_helper,probe.trace.CS=prepare,adapt,cs
        probe.drain.link_witness=link


if __name__ == '__main__':main()
