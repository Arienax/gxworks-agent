"""Observe native preparation on an unchanged, isolated saved FBD project."""
from pathlib import Path
import sys

P = Path(__file__).resolve().parent
sys.path.insert(0, str(P))
import probe_fbd_cold_status_boundary as boundary

status = boundary.status

BUILD_OBSERVER = r'''
let ownedBuildPreparationDepth=0;
const ownedBuildPreparationTargets=new Set();
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='dzdataabs_compileradapter.dll')return;
 Interceptor.attach(m.base.add(0x13cc0),{
  onEnter(a){ownedBuildPreparationDepth++;send({event:'owned-build-public-enter',
   identifier:a[1].toInt32(),report_kind:a[2].toInt32()});},
  onLeave(){ownedBuildPreparationDepth--;}
 });
 Interceptor.attach(m.base.add(0x13a2a),{
  onEnter(){this.owned=ownedBuildPreparationDepth>0;},
  onLeave(r){if(!this.owned)return;try{
   const object=r.readPointer(),vtable=object.readPointer(),target=vtable.add(8).readPointer();
   send({event:'owned-build-implementation-selected',vtable:loc(vtable),target:loc(target)});
   if(ownedBuildPreparationTargets.has(target.toString()))return;
   ownedBuildPreparationTargets.add(target.toString());
   Interceptor.attach(target,{
    onEnter(a){if(!ownedBuildPreparationDepth)return;
     const backend=this.context.ecx.add(0x14).readPointer(),table=backend.readPointer();
     send({event:'owned-build-implementation-enter',identifier:a[0].toInt32(),
      report_kind:a[1].toInt32(),native_build:loc(table.add(32).readPointer()),
      native_load:loc(table.add(20).readPointer()),native_set_data:loc(table.add(28).readPointer())});
    }
   });
  }catch(e){send({event:'observation-error',phase:'build-preparation-binding',error:String(e)});}}
 });
}});
'''


def adapt(path):
    source = path.read_text(encoding='utf-8')
    anchor = '                if(plan.ContainsKey("prepare_build_data")&&Convert.ToBoolean(plan["prepare_build_data"]))'
    assert source.count(anchor) == 1
    source = source.replace(anchor, '''                if(plan.ContainsKey("owned_load_saved_compiler")&&Convert.ToBoolean(plan["owned_load_saved_compiler"]))
                    Check("Compiler.LoadSavedDataAfterReinitialize",Slot<CompilerCacheFn>(compiler,20)(compiler,home,ws,project,out code),code);
                Record(new {operation="OwnedCompilerPreparationTargets",
                    prepare="0x"+Marshal.ReadIntPtr(Marshal.ReadIntPtr(compiler),132).ToString("x8"),
                    update_call_tree="0x"+Marshal.ReadIntPtr(Marshal.ReadIntPtr(compiler),128).ToString("x8"),
                    build="0x"+Marshal.ReadIntPtr(Marshal.ReadIntPtr(compiler),28).ToString("x8")});
'''+anchor)
    path.write_text(source, encoding='utf-8')


if __name__ == '__main__':
    status.OUT = P/'fbd-cold-preparation-20261003-v5'
    status.SAVED = P/'application-fbd-v2-20261002-v1/full-FX3U-FX3UC/native-compile/native-saved.gxw'
    status.ADAPT_EXTRA = adapt
    status.EXTRA_OBSERVER += BUILD_OBSERVER
    status.CASES = [('ascii-clean-control', []),
                    ('ascii-load-saved-data-clean', [], {'owned_load_saved_compiler': True})]
    status.main()
    (status.OUT/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
