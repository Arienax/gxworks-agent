"""Persist the native project code page, then cold-reopen without a setter.

Export is deliberately before the independent public ProgramCheck. Its original
projection failure is still exercised and recorded after export. A saved file
therefore establishes persistence only, never completion of public validation.
"""
from pathlib import Path
import json
import shutil
import sys

P = Path(__file__).resolve().parent
sys.path.insert(0, str(P))
import probe_fbd_project_codepage as codepage
normal = codepage.normal
SAVE = True


def adapt(path):
    (codepage.adapt if SAVE else normal.probe.adapt)(path)
    if not SAVE:return
    source = path.read_text(encoding='utf-8')
    beginning = source.index('            if(plan.ContainsKey("export_project")&&Convert.ToBoolean(plan["export_project"])) {')
    ending = source.index('            if(plan.ContainsKey("snapshot_compiler_cache")', beginning)
    export = source[beginning:ending]
    source = source[:beginning] + source[ending:]
    export = export.replace('if(plan.ContainsKey("export_project")&&Convert.ToBoolean(plan["export_project"]))',
                            'if(ownedSourceAcceptedForEncodingExport)')
    source_gate = '            if(plan.ContainsKey("owned_current_source_selection")&&!compilerRejected) {'
    if source.count(source_gate)!=1:raise ValueError('current-source export gate differs')
    source = source.replace(source_gate, '            bool ownedSourceAcceptedForEncodingExport=false;\n'+source_gate)
    completion = '                    public_program_check_promoted=false});\n            }'
    if source.count(completion)!=1:raise ValueError('source-check acceptance record differs')
    source = source.replace(completion, '''                    public_program_check_promoted=false});
                ownedSourceAcceptedForEncodingExport=sourceCompleted&&!sourceRejected;
            }''')
    check = '            if(plan.ContainsKey("program_check_kind")&&!compilerRejected) {'
    if source.count(check)!=1:raise ValueError('original public ProgramCheck entry differs')
    source = source.replace(check, export + check)
    path.write_text(source, encoding='utf-8')


def events(directory):
    return [json.loads(line) for line in (directory/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]


def main():
    global SAVE
    sys.stdout.reconfigure(encoding='utf-8')
    normal.OUT = P/'fbd-project-codepage-20261002-v1/persistence-v2'
    normal.OUT.mkdir(exist_ok=False)
    for name in (Path(__file__).name, 'probe_fbd_project_codepage.py', 'probe_fbd_native_normalization.py', 'native_fbd_body_codec.py'):
        shutil.copyfile(P/name, normal.OUT/name)
    probe = normal.probe
    prepare, adapt_helper, cs = probe.trace.prepare, probe.drain.adapt_helper, probe.trace.CS
    link_witness = probe.drain.link_witness
    def prepared(*args, **kwargs):
        active=probe.trace.CS;probe.trace.CS=cs
        try:return prepare(*args, **kwargs)+normal.dispatch.OBSERVER+probe.BACKEND_OBSERVER+normal.units.OBSERVER+normal.ACTIVE_TEXT_OBSERVER
        finally:probe.trace.CS=active
    def optional_link(directory):
        try:return link_witness(directory)
        except (normal.GXWFormatError, UnicodeError) as error:
            return dict(status='not_established',owned_decoder_error=str(error),native_outcome_changed=False)
    probe.trace.prepare=prepared;probe.drain.adapt_helper=adapt
    probe.trace.CS=cs+(probe.SOURCE,);probe.drain.link_witness=optional_link
    probe.QUERY=dict(kind=6,selections=[dict(row=-1,name=''),dict(row=-1,name='FBD_MATRIX')],wide_progress=True)
    try:
        previous = P/'fbd-project-codepage-20261002-v1/persistence/c000-save-cp936-a1'
        first = json.loads((previous/'normalization-result.json').read_text(encoding='utf-8'))
        directory = Path(first['directory'])
        saved = (directory/'native-saved.gxw').read_bytes()
        before = normal.read_project_context((directory/'input.gxw').read_bytes(), 'FBD_MATRIX.Program.pou')
        after = normal.read_project_context(saved, 'FBD_MATRIX.Program.pou')
        exact_graph = [r.raw for r in before.program.iter_records()] == [r.raw for r in after.program.iter_records()]
        exact_blocks = [b.raw_header for b in before.program.blocks] == [b.raw_header for b in after.program.blocks]
        stream_differences = [dict(offset=i,before=x,after=y) for i,(x,y) in enumerate(zip(before.program.raw,after.program.raw)) if x!=y]
        exact_labels = {n:[r.raw for r in d.rows] for n,d in before.declarations.items()} == {
            n:[r.raw for r in d.rows] for n,d in after.declarations.items()}
        assert exact_graph and exact_blocks and exact_labels
        assert len(before.program.raw)==len(after.program.raw)
        assert stream_differences == [dict(offset=50,before=1,after=0)]
        SAVE = False
        normal.RAW = saved;normal.CONTEXT = after
        second = normal.run_native({},label='cold-reopen-cp936',encoding='gbk',
                                   configuration_key={'project_codepage_from_saved_file':True})
        reopened = Path(second['directory'])
        observed = [r for r in events(reopened) if r.get('operation')=='NativeProjectCodePage']
        setters = [r for r in events(reopened) if r.get('operation','').startswith('OwnedProjectEncoding.')]
        assert len(observed)==1 and observed[0]['codepage']==936 and not setters
        native_first = normal.snapshot_pou_bodies(directory/'frontend-snapshot.json','FBD_MATRIX')[0]
        native_second = normal.snapshot_pou_bodies(reopened/'frontend-snapshot.json','FBD_MATRIX')[0]
        assert native_first == native_second
        result = dict(cpu='FX3U/FX3UC',dll_version='1.635.0.1',saved_native_directory=str(directory),
            cold_reopen_directory=str(reopened), original_save_repeated=False,
            saved_graph_records_exact=exact_graph, saved_graph_block_headers_exact=exact_blocks,
            saved_program_stream_bytes_exact=before.program.raw==after.program.raw,
            saved_program_stream_differences=stream_differences,
            saved_declaration_rows_exact=exact_labels,cold_reopen_codepage=936,
            cold_reopen_used_setter=False,cold_frontend_body_bytes_exact=True,
            source_checks=[first['source_check'],second['source_check']],
            public_checks=[first['original_public_check'],second['original_public_check']],
            public_check_completion_promoted=False,plc_execution='not_run')
        probe.trace.save(normal.OUT/'persistence-result.json',result)
        print(json.dumps(result,ensure_ascii=False),flush=True)
    finally:
        probe.trace.prepare,probe.drain.adapt_helper,probe.trace.CS=prepare,adapt_helper,cs
        probe.drain.link_witness=link_witness


if __name__ == '__main__':main()
