'use strict';
let request = -1;
function raw(address, size) {
    return Array.from(new Uint8Array(address.readByteArray(size))).map(b => b.toString(16).padStart(2,'0')).join('');
}
Process.attachModuleObserver({
    onAdded(module) {
        if (module.name.toLowerCase() !== 'eccodegenerator2.dll') return;
        if (raw(module.base.add(0x5db3f),8) !== '558becb848350000') throw new Error('Uninspected Q basic entry');
        Interceptor.attach(module.getExportByName('ChangePToMcode'), {
            onEnter() { request++; },
        });
        Interceptor.attach(module.base.add(0x5db3f), {
            onEnter(args) {
                this.buffers=args[0];this.machine=this.buffers.readPointer();
                const input=this.buffers.add(8).readPointer();this.opcode=input.add(1).readU8();
                this.row={event:'Q-basic-template',request,opcode:this.opcode,
                    source:raw(input,input.readU8()),template:raw(module.base.add(0xdcf40+6*this.opcode),6)};
            },
            onLeave(result) {
                const extent=this.buffers.readPointer().sub(this.machine).toInt32();
                if (extent<0||extent>512) throw new Error('Unmeasured Q machine record extent');
                this.row.words=(result.toInt32()<<16)>>16;this.row.template_after=raw(module.base.add(0xdcf40+6*this.opcode),6);
                this.row.machine=raw(this.machine,extent);send(this.row);
            }
        });
        Interceptor.attach(module.base.add(0x5d826), {
            onEnter(args) {
                this.valid=false;this.output=args[0];this.words=(args[1].toInt32()<<16)>>16;
                if(this.words<0||this.words>128) throw new Error('Unmeasured Q parity extent');
                this.row={event:'Q-even-parity',request,words:this.words,before:raw(this.output,4*this.words)};
                this.valid=true;
            },
            onLeave() {if(this.valid){this.row.after=raw(this.output,4*this.words);send(this.row);}}
        });
    }
});
