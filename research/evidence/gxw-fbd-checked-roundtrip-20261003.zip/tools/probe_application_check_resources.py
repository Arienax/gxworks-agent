"""Read-only observation of owned native checks; compare actual bytes."""
from pathlib import Path
from collections import Counter
import json
import shutil
import subprocess
import sys
import time

P=Path(__file__).resolve().parent
ROOT=P.parents[3]
sys.path[:0]=[str(ROOT/'research/experiments/re-tools'),str(ROOT/'src')]
import frida

OUT=P/'application-current-check-20261002-v1'
A=P/'application-fbd-v2-20261002-v1'
CS=('WorkspaceReplayOracle.cs','NativeFrontendSnapshot.cs','NativeSfcGraphOracle.cs','NativeWorkspaceCopyOracle.cs')

EXTRA=r'''
let projectionDepth=0;
const lookupObservers=new Set();
function textBstr(p){if(p.isNull())return null;const n=p.sub(4).readU32();if(n>131072||n%2)throw new Error('BSTR bound');return p.readUtf16String(n/2);}
Process.attachModuleObserver({onAdded(m){
 if(m.name.toLowerCase()!=='dzdataabs_compileradapter.dll')return;
 Interceptor.attach(m.base.add(0x8e48),{
  onEnter(a){projectionDepth++;try{
   const workspace=this.context.ecx.add(0x18).readPointer();
   const fn=workspace.readPointer().add(0x6f8).readPointer();
   if(!lookupObservers.has(fn.toString())){
    lookupObservers.add(fn.toString());
    send({event:'projection-lookup-observer',location:loc(fn)});
    Interceptor.attach(fn,{
     onEnter(a){if(!projectionDepth)return;try{
      this.code=a[16];this.output=a[15];
      this.row={event:'projection-object-lookup',check_index:checkIndex,caller:loc(this.returnAddress),
       parent:id(a),kind:a[13].toUInt32(),name:textBstr(a[14])};
     }catch(e){send({event:'observation-error',error:String(e)});}},
     onLeave(r){if(!this.row)return;try{send({...this.row,hresult:r.toInt32(),code:this.code.readU32(),
      output_id:r.toInt32()>=0?Array.from({length:12},(_,i)=>this.output.add(i*4).readU32()):null});
     }catch(e){send({event:'observation-error',error:String(e)});}}
    });
   }
  }catch(e){send({event:'observation-error',error:String(e)});}},
  onLeave(){projectionDepth--;}
 });
 for(const rva of [0x3def,0x1e27])Interceptor.attach(m.base.add(rva),{
  onEnter(a){if(!projectionDepth)return;this.code=a[2];this.row={event:'projection-argument-transfer',rva:'0x'+rva.toString(16),check_index:checkIndex};},
  onLeave(r){if(!this.row)return;try{send({...this.row,hresult:r.toInt32(),code:this.code.readU32()});}catch(e){send({event:'observation-error',error:String(e)});}}
 });
}});
'''


def save(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def prepare(directory,frozen,*,refresh=True):
    directory.mkdir()
    for sub in ('home','compiler'):(directory/sub).mkdir()
    for file in CS:shutil.copyfile(frozen/file,directory/file)
    shutil.copyfile(frozen/'input.gxw',directory/'input.gxw')
    plan=json.loads((frozen/'plan.json').read_text())
    plan.update(workspace_home=str(directory/'home')+'\\',compiler_work=str(directory/'compiler'),
        input_copy=str(directory/'input.gxw'),project_name='CURRENTCHECK',project_alias='CURRENTCHECK',
        refresh_program_check=refresh)
    save(directory/'plan.json',plan)
    path=directory/CS[0];source=path.read_text(encoding='utf-8')
    if 'CheckProjectHash' in source:raise ValueError('Frozen helper still performs a project hash check')
    anchor='log.AutoFlush=true;'
    if source.count(anchor)!=1:raise ValueError('Owned helper logging gate site differs')
    source=source.replace(anchor,anchor+'''
        File.WriteAllText(Path.Combine(root,"trace-ready"),"owned-helper");
        int gate=0;
        while(!File.Exists(Path.Combine(root,"trace-release"))&&gate++<1000)Thread.Sleep(10);
        if(!File.Exists(Path.Combine(root,"trace-release")))throw new Exception("Owned trace attach timeout");
''')
    path.write_text(source,encoding='utf-8')
    script=(P/'TraceCurrentCheckResources.js').read_text()+EXTRA
    (directory/'observer.js').write_text(script,encoding='utf-8')
    return script


def run(directory,script,*,on_message=None):
    exe=directory/'WorkspaceReplayOracle.exe'
    build=subprocess.run(['C:/Windows/Microsoft.NET/Framework/v4.0.30319/csc.exe','/nologo','/platform:x86',
        '/r:System.Web.Extensions.dll','/r:System.Windows.Forms.dll','/out:'+str(exe),
        *(str(directory/file) for file in CS)],capture_output=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
    (directory/'build.stdout.bin').write_bytes(build.stdout);(directory/'build.stderr.bin').write_bytes(build.stderr)
    build.check_returncode()
    process=subprocess.Popen([str(exe),str(directory/'plan.json')],stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=subprocess.CREATE_NO_WINDOW)
    messages=[];session=None
    try:
        deadline=time.monotonic()+12
        while not (directory/'trace-ready').exists():
            if process.poll() is not None:raise RuntimeError('Owned helper exited before observation gate')
            if time.monotonic()>deadline:raise TimeoutError('Owned helper observation gate')
            time.sleep(.01)
        session=frida.attach(process.pid)
        agent=session.create_script(script)
        def record_message(message,data):
            messages.append(message)
            if on_message is not None:on_message(message,data)
        agent.on('message',record_message)
        agent.load()
        (directory/'trace-release').write_text('attached',encoding='utf-8')
        stdout,stderr=process.communicate(timeout=50)
    finally:
        if process.poll() is None:process.kill();process.communicate()
        if session is not None:
            try:session.detach()
            except frida.InvalidOperationError:pass
        (directory/'observation-events.jsonl').write_text(''.join(json.dumps(m)+'\n' for m in messages),encoding='utf-8')
    (directory/'run.stdout.bin').write_bytes(stdout);(directory/'run.stderr.bin').write_bytes(stderr)
    return process.returncode,messages


def summarize(directory,returncode,messages,*,result_name='result.json'):
    events=[json.loads(l) for l in (directory/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    observed=[m['payload'] for m in messages if m.get('type')=='send']
    errors=[m for m in messages if m.get('type')=='error']+[e for e in observed if e.get('event')=='observation-error']
    reads=[];size_queries=[]
    resources=[e for e in events if e.get('operation')=='Resource']
    native_names={tuple(e['id']):e['name'] for e in events if e.get('operation')=='NativeObject' and e.get('name')}
    for row in observed:
        if row.get('event')!='workspace-pcode-read' or row.get('phase')!='check':continue
        if (row.get('hresult')==0 and row.get('code')==0 and row.get('requested_sizes')==[0,0,0]
                and any(b['size'] and b.get('raw_hex') is None for b in row['buffers'])):
            size_queries.append({k:v for k,v in row.items() if k!='buffers'})
            continue
        comparisons=[]
        for resource in resources:
            if native_names.get(tuple(row['target']))!=resource['name']:continue
            files=[directory/f"pcode-{resource['index']}-{i}.bin" for i in range(3)]
            if not all(p.exists() for p in files):continue
            actual=[bytes.fromhex(b['raw_hex']) if b.get('raw_hex') is not None else None for b in row['buffers']]
            if actual==[p.read_bytes() for p in files]:comparisons.append(resource['name'])
        record={k:v for k,v in row.items() if k!='buffers'}
        record.update(channel_sizes=[b['size'] for b in row['buffers']],matches_current_resource_names=comparisons)
        for i,b in enumerate(row['buffers']):
            if b.get('raw_hex') is not None:(directory/f"check-read-{row['serial']}-{i}.bin").write_bytes(bytes.fromhex(b['raw_hex']))
        reads.append(record)
    check_starts=[e for e in observed if e.get('event')=='check-start']
    backend=[e for e in observed if e.get('event')=='backend-check-progress']
    projections=[e for e in observed if e.get('event')=='diagnostic-projection-failure']
    completed=[e for e in events if e.get('operation')=='ProgramCheckCompleted']
    result={'directory':str(directory),'returncode':returncode,
        'selected_input':str(directory/'input.gxw'),'selected_configuration':str(directory/'plan.json'),
        'compile_completed':any(e.get('operation')=='Progress' and e.get('percent')==100 for e in events),
        'generated_resources':resources,
        'publication_completed':any(e.get('operation')=='Workspace.UpdatePCodeBeforeProgramCheck' and e.get('hresult')==0 for e in events),
        'selected_targets':[e['target'] for e in check_starts],'checker_reads':reads,'checker_size_queries':size_queries,
        'checker_read_correspondence':'current' if reads and all(r['matches_current_resource_names'] for r in reads) and not errors else 'not_established',
        'backend_completed_targets':[e['target'] for e in backend if e.get('percent')==100 and e.get('hresult')==0 and e.get('code')==0],
        'diagnostic_projection':'failed' if projections else ('completed' if completed else 'not_completed'),
        'projection_failures':projections,
        'projection_internal_events':[e for e in observed if e.get('event') in ('projection-object-lookup','projection-argument-transfer','projection-lookup-observer')],
        'public_check':completed,'exported':(directory/'native-saved.gxw').exists(),
        'native_failures':[e for e in events if e.get('hresult',0)<0 or e.get('code',0)!=0],
        'observation_errors':errors}
    save(directory/result_name,result)
    return result


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    OUT.mkdir(exist_ok=False)
    targets=[(cpu,A/('full-'+cpu.replace('/','-'))/'native-compile') for cpu in ('FX3U/FX3UC','Q03UDV','L02')]
    targets.append(('Q03UDV-diagnostic-negative',P/'q-label-contact-native-20261001-v1/case-00/candidate-check-1'))
    results=[]
    for name,frozen in targets:
        for attempt in range(1,17):
            directory=OUT/(name.replace('/','-')+'-attempt-'+str(attempt))
            script=prepare(directory,frozen)
            returncode,messages=run(directory,script)
            result=summarize(directory,returncode,messages)
            result['case']=name;results.append(result);save(OUT/'results.json',results)
            print(json.dumps({k:result[k] for k in ('case','returncode','compile_completed','checker_read_correspondence','diagnostic_projection')}) ,flush=True)
            last=result['native_failures'][-1] if result['native_failures'] else {}
            if returncode!=5:break


if __name__=='__main__':main()
