// Owned buffers; repeated memory-only conversions on one fresh CPU context.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;

public static class FXModernHistoryOracle {
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode)] static extern IntPtr LoadLibraryEx(string path,IntPtr file,uint flags);
    [DllImport("kernel32.dll",CharSet=CharSet.Ansi,ExactSpelling=true)] static extern IntPtr GetProcAddress(IntPtr module,string name);
    [DllImport("kernel32.dll")] static extern uint SetErrorMode(uint mode);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate IntPtr Create();
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Open(IntPtr h,int cpu,int mode);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Version(IntPtr h,int count,[In] uint[] versions);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Close(IntPtr h);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate void Destroy(IntPtr h);
    [StructLayout(LayoutKind.Sequential,Pack=1)] struct CodeBuffers {
        public IntPtr machine; public int remaining; public IntPtr pcode,deviceOffsets; public int reserved16,reserved20;
    }
    [StructLayout(LayoutKind.Sequential,Pack=1)] struct PackedNativeValue {public uint low;public ushort high;}
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int FromMachine(IntPtr h,ref CodeBuffers buffers,
        IntPtr context,ref int bytes,int option1,int option2,PackedNativeValue value1,PackedNativeValue value2);
    static T Export<T>(IntPtr module,string name) where T:class {
        IntPtr p=GetProcAddress(module,name);if(p==IntPtr.Zero)throw new Exception(name);
        return Marshal.GetDelegateForFunctionPointer(p,typeof(T)) as T;
    }
    sealed class Arena:IDisposable {
        public const int Guard=32; public byte[] data; public int capacity; GCHandle pin;
        public Arena(int size){capacity=size;data=new byte[size+2*Guard];for(int i=0;i<Guard;i++){data[i]=0xA5;data[Guard+size+i]=0xA5;}pin=GCHandle.Alloc(data,GCHandleType.Pinned);}
        public IntPtr Pointer{get{return IntPtr.Add(pin.AddrOfPinnedObject(),Guard);}}
        public void Verify(){for(int i=0;i<Guard;i++)if(data[i]!=0xA5||data[Guard+capacity+i]!=0xA5)throw new Exception("Owned guard changed");}
        public void Clear(){Array.Clear(data,Guard,capacity);}
        public void Dispose(){pin.Free();}
    }
    public static int Main(string[] args){
        if(IntPtr.Size!=4||args.Length!=3)return 2;SetErrorMode(3);
        if(FileVersionInfo.GetVersionInfo(args[0]).FileVersion!="15.31")throw new Exception("Uninspected converter version");
        IntPtr m=LoadLibraryEx(args[0],IntPtr.Zero,8);if(m==IntPtr.Zero)throw new Exception("Load failed");
        Create create=Export<Create>(m,"ObjectNew");Open open=Export<Open>(m,"Open");Version version=Export<Version>(m,"SetVersion");
        Close close=Export<Close>(m,"Close");Destroy destroy=Export<Destroy>(m,"ObjectDelete");FromMachine convert=Export<FromMachine>(m,"ChangeMToPcode");
        using(StreamWriter output=new StreamWriter(args[2]))foreach(string line in File.ReadLines(args[1])){
            string[] f=line.Split('\t');if(f.Length!=5||(f[1]!="520"&&f[1]!="521"))throw new Exception("Explicit request context required");
            int id=int.Parse(f[0]),cpu=int.Parse(f[1]);
            byte[][] inputs={Convert.FromBase64String(f[2]),Convert.FromBase64String(f[4]),Convert.FromBase64String(f[3]),Convert.FromBase64String(f[4])};
            foreach(byte[] raw in inputs)if(raw.Length<2||raw.Length>512||(raw.Length&1)!=0)throw new Exception("Bounded WORD envelope differs");
            List<string> answers=new List<string>();
            using(Arena input=new Arena(4096))using(Arena result=new Arena(1048576))using(Arena offsets=new Arena(128)){
                IntPtr h=create();if(h==IntPtr.Zero)throw new Exception("Create failed");
                try{
                    int code=open(h,cpu,0);if(code!=0)throw new Exception("Open failed");
                    code=version(h,0,new uint[0]);if(code!=0)throw new Exception("Version failed");
                    for(int phase=0;phase<4;phase++){
                        byte[] raw=inputs[phase];input.Clear();result.Clear();offsets.Clear();Array.Copy(raw,0,input.data,Arena.Guard,raw.Length);
                        CodeBuffers b=new CodeBuffers();b.machine=input.Pointer;b.remaining=raw.Length;b.pcode=result.Pointer;b.deviceOffsets=offsets.Pointer;
                        int bytes=result.capacity;code=convert(h,ref b,IntPtr.Zero,ref bytes,0,0,new PackedNativeValue(),new PackedNativeValue());
                        int consumed=b.machine.ToInt32()-input.Pointer.ToInt32();if(consumed<0||consumed>input.capacity||bytes<0||bytes>result.capacity)throw new Exception("Owned extent differs");
                        input.Verify();result.Verify();offsets.Verify();
                        bool unchanged=true;for(int i=0;i<raw.Length;i++)if(input.data[Arena.Guard+i]!=raw[i])unchanged=false;
                        answers.Add("{\"id\":"+id+",\"cpu\":"+cpu+",\"phase\":"+phase+",\"code\":"+code+",\"consumed\":"+consumed+",\"remaining\":"+b.remaining+",\"bytes\":"+bytes+",\"guards_intact\":true,\"input_unchanged\":"+(unchanged?"true":"false")+",\"output_base64\":\""+(code==0?Convert.ToBase64String(result.data,Arena.Guard,bytes):"")+"\"}");
                    }
                }finally{close(h);destroy(h);}
            }
            foreach(string answer in answers)output.WriteLine(answer);output.Flush();
        }
        return 0;
    }
}
