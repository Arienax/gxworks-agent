"""Offline native CGTable restore/dump/replay; no project or device APIs."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from gxw.lossless import sha256
from gxw.compiler_tables import parse_compiler_tables

DLL = Path("D:/GXWORKS2/Easysocket/Compiler/ECCompiler.dll")
DLL_SHA256 = "4f7b2398874c7a921f49f13f25a9a603562032b039de8a5bb74114df27fadf16"


def compare_table_dump(raw, dump):
    """Compare ordered native POU/component names, byte indexes and FB targets.

    Ignore the native textual rendering of binary UserInfo; retain its original
    bytes in the input and replay. This comparison does not cover every field.
    """
    tables = parse_compiler_tables(raw)
    pous = [tables.pou_at(r.table_offset) for r in tables.tables[1].records]
    components = [c for p in pous for c in tables.components(p)]
    native_pous = [(int(m[1]), m[2]) for m in re.finditer(rb"^Index\s+(\d+): ([^\r\n]+) \(POU_[^)]+\)", dump, re.M)]
    native_components = [(int(m[1]), m[2]) for m in re.finditer(rb"^ +Index\s+(\d+): ([^\r\n]+) \(TYPE_[^)]+\)", dump, re.M)]
    native_references = [int(m[1]) for m in re.finditer(rb"^ +PouIdx = (-?\d+)", dump, re.M)]
    references = [c.instance_pou_offset for c in components if c.instance_pou_offset is not None]
    for reference in references:
        tables.pou_at(reference)
    return {"pous_equal": native_pous == [(p.record.table_offset, p.name_bytes) for p in pous],
            "components_equal": native_components == [(c.record.table_offset, c.name_bytes) for c in components],
            "instance_refs_equal": native_references == references,
            "pous": len(pous), "components": len(components), "instances": len(references)}


def native_table_dump(raw, directory, *, dll=DLL):
    if os.name != "nt" or sha256(dll.read_bytes()) != DLL_SHA256:
        raise ValueError("requires Windows and the inspected ECCompiler.dll 15.22 hash")
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=False)
    source = directory / "CompilerTableOracle.cs"
    source.write_bytes((ROOT / "research/native/CompilerTableOracle.cs").read_bytes())
    input_path = directory / "CGTable.dat"
    input_path.write_bytes(raw)
    request = {"input_sha256": sha256(raw), "dll_sha256": DLL_SHA256,
               "adapter_source_sha256": sha256(source.read_bytes()),
               "scope": "offline table restore/dump/replay; no source freshness, execution or project acceptance claim"}
    (directory / "request.json").write_text(json.dumps(request, indent=2) + "\n", encoding="utf-8")
    executable = directory / "CompilerTableOracle.exe"
    compiler = Path(os.environ["WINDIR"]) / "Microsoft.NET/Framework/v4.0.30319/csc.exe"
    build = subprocess.run([str(compiler), "/nologo", "/platform:x86", "/out:" + str(executable), str(source)],
                           capture_output=True, timeout=30, creationflags=subprocess.CREATE_NO_WINDOW)
    (directory / "build-output.bin").write_bytes(build.stdout + build.stderr)
    if build.returncode:
        raise RuntimeError("native compiler-table adapter build failed; evidence retained")
    try:
        run = subprocess.run([str(executable.resolve()), str(dll.resolve()), str(input_path.resolve()), str(directory.resolve())],
                             capture_output=True, timeout=40, creationflags=subprocess.CREATE_NO_WINDOW)
        stdout, stderr, code = run.stdout, run.stderr, run.returncode
    except subprocess.TimeoutExpired as exc:
        stdout, stderr, code = exc.stdout or b"", exc.stderr or b"", "timeout"
    (directory / "stdout.txt").write_bytes(stdout)
    (directory / "stderr.txt").write_bytes(stderr)
    result = dict(request, returncode=code, adapter_sha256=sha256(executable.read_bytes()))
    replay = directory / "native-replay.bin"
    result["replay_equal"] = replay.exists() and replay.read_bytes() == raw
    (directory / "process.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    if code:
        raise RuntimeError("native compiler-table process failed; inputs and partial output retained")
    result.update(compare_table_dump(raw, (directory / "native-table-dump.txt").read_bytes()))
    (directory / "comparison.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path, help="extracted CGTable.dat")
    parser.add_argument("-o", "--output", type=Path, required=True)
    parser.add_argument("--dll", type=Path, default=DLL)
    args = parser.parse_args()
    print(json.dumps(native_table_dump(args.input.read_bytes(), args.output, dll=args.dll)))
