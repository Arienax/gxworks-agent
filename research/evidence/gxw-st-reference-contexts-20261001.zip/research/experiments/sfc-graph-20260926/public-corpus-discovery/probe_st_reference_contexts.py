"""Prospective two-instance and local/global binding controls; offline copies."""
from dataclasses import replace
from pathlib import Path
import json
import sys

ROOT=Path(__file__).resolve().parents[4]
P=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research'),str(P)]
from gxw.declarations import parse_declarations,edit_declarations,serialize_declarations
from gxw.project_metadata import mark_observed_source_compile_pending
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_st_sources import replace_observed_st
from probe_gxw_program_check_resources import SCRIPT
from probe_minimal_conditional_port_writes import streams,observe
from inspect_native_st_references import inspect


def save(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=True)+'\n',encoding='utf-8')


def main():
    out=P/'st-reference-contexts-20261001';out.mkdir(exist_ok=False)
    original=(P/'q-original-st-source-20261001/input.gxw').read_bytes();before=streams(original)
    labels='POU_01.Labels.lh';doc=parse_declarations(before[labels],logical_name=labels)
    existing=next(r for r in doc.rows if r.name=='Keypad_1')
    second=replace(existing,name='Keypad_2',record_id=max(r.record_id for r in doc.rows)+1)
    base=replace(doc,rows=doc.rows+(second,))
    main_text=('useLcd := TRUE;\n'
        'IF I_liveBit = 1 THEN\nline2 := "Probe";\nELSE\nline2 := "";\nEND_IF;\n'
        'OUT_T(I_in1,TC1,30);\nOUT(TS1,resetOutput);\n'
        'Keypad_1(number := line1,in_out_character := character);\n'
        'Keypad_2(number := line4,in_out_character := I_userId);\n').replace('\n','\r\n')
    trace=out/'trace.js';trace.write_text('(function(){\n'+(P/'native-allocation-bitmap-v2/observer.js').read_text(encoding='utf-8')+'\n'+(P/'trace_native_source_points.js').read_text(encoding='utf-8')+'\n})();\n(function(){\n'+SCRIPT+'\n})();\n',encoding='utf-8')
    ready=[]
    for case,shadow in [('two-instances',False),('local-shadow',True)]:
        d=out/case;d.mkdir()
        local=edit_declarations(base,upserts=[dict(name='useLcd',data_type='BOOL')]) if shadow else base
        raw=mark_observed_source_compile_pending(serialize_declarations(local),logical_name=labels)
        body,_=replace_observed_st(before['POU_01.Program.pou'],main_text)
        body=mark_observed_source_compile_pending(body,logical_name='POU_01.Program.pou')
        changes={labels:raw,'POU_01.Program.pou':body};source=original
        for name,value in changes.items():source,_=patch_raw(source,name,before[name],value)
        if streams(source)!=dict(before,**changes):raise ValueError('unrelated logical payload changed')
        (d/'input.gxw').write_bytes(source)
        save(d/'before-native.json',dict(scope='owned copied Q03UDV project; no device or simulator execution',
            changes=list(changes),unrelated_logical_payloads_byte_exact=True,original_keypad_body_byte_exact=True,
            local_shadow=shadow,main_source=main_text,
            hypotheses=['Both instances must resolve through distinct compiler POU offsets even though their type names are identical.',
                'The repeated physical FB source line numbers must retain their distinct expansion paths.',
                'If same-name local/global declarations are accepted, inspect which exact component offset the native frontend binds.'],
            assertions_to_measure=['Fresh native check acceptance or original refusal diagnostics.',
                'All reference boundaries, sink instructions and operands align with generated code.',
                'Accepted saved copy reopens and emits the same three channel buffers.']))
        ready.append((case,d))
    rows=[]
    for case,d in ready:
        native,result,process=observe(d/'input.gxw',d,trace)
        row=dict(case=case,native=str(native),check=result['check'],backend_rejected=result['backend_check_rejected'],
            diagnostics=result['diagnostics'],process=process)
        if result['check'] is not None and not result['check']['rejected']:
            analysis=inspect(native);save(d/'source-reference-correspondence.json',analysis);row['correspondence']=analysis['validation']
            call_sources=[s for s in analysis['normalized_sources'] if s['name']=='POU_01']
            first=next(r for r in call_sources[0]['references'] if r['spelling'].startswith('K'))
            row['useLcd_binding']=first
            # The accepted artifact is already separate from the original.
            saved=native/'native-saved.gxw';reopen=d/'reopen';reopen.mkdir()
            again,checked,traced=observe(saved,reopen,trace)
            channels=[]
            for g in result['generated']:
                for channel in range(3):
                    name=f'pcode-{g["index"]}-{channel}.bin'
                    channels.append(dict(file=name,bytes=(native/name).stat().st_size,
                        equal=(native/name).read_bytes()==(again/name).read_bytes()))
            row['reopen']=dict(native=str(again),check=checked['check'],backend_rejected=checked['backend_check_rejected'],
                channels=channels,process=traced)
            if checked['check'] is None or checked['check']['rejected'] or not all(c['equal'] for c in channels):
                raise ValueError('accepted saved copy did not reproduce')
        rows.append(row);save(out/'comparison.json',rows)
        print(json.dumps(row,ensure_ascii=True),flush=True)


if __name__=='__main__':main()
