// Append inside the existing observer's scope. Observe the compiler's own
// DBG_INFO reads, including its borrowed twelve-byte data and eight UserInfo
// bytes. No native calls are injected and no return value is changed.
Process.attachModuleObserver({onAdded(m) {
 if(m.name.toLowerCase()!=='eccompiler_iec.dll')return;
 try {
  if(Process.arch!=='ia32'||hex(m.base.add(0x13b20),9)!=='558bec83ec5c565789')throw new Error('source point reader guard');
  Interceptor.attach(m.base.add(0x13b20),{
   onEnter(a) {
    const c=contexts.get(this.threadId);if(!c)return;
    try {
     this.row={event:'source-point-read',compile_id:c.compile_id,thread_id:this.threadId,
      requested_offset:a[0].readS32(),caller:loc(this.returnAddress)};
     this.position=a[0];this.record=a[1];this.user=a[3];
     this.userSize=this.context.ecx.add(0x3c).readS32();
     if(this.userSize!==8)throw new Error('source point UserInfo size');
    }catch(e){emit({event:'source-point-error',error:String(e)});this.row=null;}
   },
   onLeave(r) {
    if(!this.row)return;
    try {
     const length=this.record.add(4).readU8(),data=this.record.readPointer();
     if(length>64||(length&&data.isNull()))throw new Error('source point data bound');
     emit({...this.row,result:r.toInt32(),next_offset:this.position.readS32(),
      data:!data.isNull()?hex(data,length):null,
      user_info:this.user.isNull()?null:hex(this.user,this.userSize)});
    }catch(e){emit({event:'source-point-error',error:String(e)});}
   }
  });
 }catch(e){emit({event:'source-point-guard-error',error:String(e)});}
}});
