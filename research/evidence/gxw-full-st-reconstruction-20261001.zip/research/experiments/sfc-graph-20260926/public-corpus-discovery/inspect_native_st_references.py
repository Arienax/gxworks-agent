"""Resolve fresh native ST references and join observed source reads to PCode.

References use the table snapshot accompanying that source, not a later cache.
Source reads copy actual native values: compile can rewrite the position table.
Syntax between references, record tails, compiler refusals and generated code
are retained. This is an observed compile trace, not a portable ST compiler.
"""
from pathlib import Path
import argparse
import base64
import collections
import json
import re
import struct
import sys

ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research'),str(Path(__file__).resolve().parent)]
from gxw.compiler_tables import parse_compiler_tables
from gxw.lossless import inspect_project
from gxw.text_pou import parse_st_pou
from probe_gxw_compiler_constants import constant_record
from witness_st_conditional_transfers import decode

REF=re.compile(rb'(?<![A-Za-z0-9_#%])([KFCD])([0-9]+)(?![A-Za-z0-9_])')


def b64(raw):return base64.b64encode(raw).decode('ascii')


def point(record):
    raw=record.payload
    if len(raw)!=21 or raw[0]!=12:raise ValueError('unmeasured source position layout')
    network,line,pou=struct.unpack_from('<iii',raw,1)
    return dict(network=network,line=line,parent_pou_offset=pou,
        expansion_offset=struct.unpack_from('<i',raw,17)[0],
        user_info_hex=raw[13:].hex(),raw_base64=b64(record.raw))


def source_identity(tables,location):
    root=tables.pou_at(location['parent_pou_offset'])
    result=dict(parent_name=root.name_bytes.decode('cp936'),instance=None,
        definition=root.name_bytes.decode('cp936'),line=location['line'],network=location['network'])
    if location['expansion_offset']!=-1:
        row=tables.tables[10].record_at(location['expansion_offset'])
        name,fields=row.named_fields()
        match=re.fullmatch(rb'POU_IDX:([0-9]+)',name)
        if not match or not fields.endswith(b'\0') or b'\0' in fields[:-1]:
            raise ValueError('unmeasured expansion record')
        definition=tables.pou_at(int(match[1]))
        result.update(instance=fields[:-1].decode('cp936'),definition=definition.name_bytes.decode('cp936'),
            expansion_raw_base64=b64(row.raw))
    return result


def resolve(tables,tag,offset):
    if tag=='K':
        c=tables.component_at(offset)
        address_offset=tables.component_address_offset(c)
        address=tables.address_at(address_offset) if address_offset>=0 else None
        return dict(table=2,name=c.name_bytes.decode('cp936'),scope_code=c.scope_code,
            type_code=tables.component_type(c),raw_base64=b64(c.record.raw),
            declared_address=None if address is None or address.iec_address_bytes is None else address.iec_address_bytes.decode('ascii'))
    if tag=='F':
        p=tables.pou_at(offset)
        return dict(table=1,name=p.name_bytes.decode('cp936'),fields=list(p.fields),raw_base64=b64(p.record.raw))
    if tag=='C':return dict(table=5,**constant_record(tables.tables[5].record_at(offset)))
    if tag=='D':
        p=point(tables.tables[0].record_at(offset))
        return dict(table=0,**p,source=source_identity(tables,p))
    raise ValueError('reference kind')


def read_events(native):
    return [x['payload'] for line in (native/'events.jsonl').read_text(encoding='utf-8').splitlines()
        if (x:=json.loads(line)).get('type')=='send']


def operand_view(operand):
    raw=bytes.fromhex(operand['raw'])
    if len(raw)!=25:raise ValueError('native operand width')
    flags=raw[24];kind=struct.unpack_from('<I',raw,20)[0]
    if flags==1 and kind==0 and raw[4:24]==bytes(20):
        text=operand.get('string')
        if not text or not text['terminated']:raise ValueError('borrowed string was not copied')
        data=bytes.fromhex(text['hex'])
        if not data.isascii() or b'"' in data:raise ValueError('unmeasured native string rendering')
        return dict(kind='string',text=data.decode('ascii'))
    families={0x404d:'SM',0x42:'B',0x50:'P',0x57:'W',0x48:'H',0x4d:'M',
        0x54:'T',0x4b:'K',0x44:'D',0x5a:'Z'}
    if flags not in (0,16) or kind not in families or raw[16:20]!=bytes(4):
        raise ValueError('unmeasured native operand type or modifiers')
    index=None
    if flags==16:
        if struct.unpack_from('<I',raw)[0]!=0x5a or families[kind]!='D':raise ValueError('unmeasured native index')
        index=struct.unpack_from('<I',raw,4)[0]
    elif raw[:8]!=bytes(8):raise ValueError('unmeasured native operand prefix')
    number=int.from_bytes(raw[8:16],'little',signed=True)
    if not 0<=number<=0x7fffffff:raise ValueError('unmeasured native scalar range')
    return dict(kind='number',family=families[kind],number=number,index=index)


def operand_equal(view,text):
    if view['kind']=='string':return text=='"'+view['text']+'"'
    family=view['family'];number=view['number'];index=view['index']
    if family in ('K','H'):
        if index is not None:return False
        if re.fullmatch(r'K-?[0-9]+',text):return int(text[1:])==number
        if re.fullmatch(r'H[0-9A-F]+',text):return int(text[1:],16)==number
        return False
    address=family+(format(number,'X') if family in ('B','W') else str(number))
    # Q formatter pads an initial A..F digit to distinguish hex coordinates.
    if family in ('B','W') and address[1:2] in 'ABCDEF':address=family+'0'+address[1:]
    if index is not None:address+='Z'+str(index)
    return address==text


def inspect(native):
    trace=read_events(native)
    errors=[r for r in trace if 'error' in r.get('event','')]
    if errors:raise ValueError('native trace observation failed')
    originals={s.logical_name:s.raw for s in inspect_project((native/'input.gxw').read_bytes()).streams if s.logical_name}
    source_text={name:parse_st_pou(raw).text.splitlines() for name,raw in originals.items()
        if name.endswith('.Program.pou') and _is_st(raw)}
    compilations={};sources=[];by_point={};roundtrips=[]
    for r in trace:
        if r.get('event')!='sink-compile':continue
        tables=parse_compiler_tables(bytes.fromhex(r['symbolic_data']))
        if tables.reconstruct()!=tables.raw:raise ValueError('table reconstruction')
        compilations[r['compile_id']]=tables
        for source in r['sources']:
            raw=bytes.fromhex(source['raw'])
            if not raw.startswith(b'ST_BODY\r\n'):continue
            refs=[];segments=[];cursor=0
            for match in REF.finditer(raw):
                tag=match[1].decode('ascii');offset=int(match[2]);binding=resolve(tables,tag,offset)
                segments.extend((raw[cursor:match.start()],match[0]));cursor=match.end()
                ref=dict(start=match.start(),end=match.end(),spelling=match[0].decode('ascii'),binding=binding)
                refs.append(ref)
                if tag=='D':
                    identity=binding['source'];key=(r['compile_id'],identity['definition'],identity['instance'],identity['line'])
                    by_point.setdefault(key,[]).append(ref)
            segments.append(raw[cursor:])
            if b''.join(segments)!=raw:raise ValueError('source segment reconstruction')
            roundtrips.append(True)
            sources.append(dict(compile_id=r['compile_id'],name=source['name']['latin1'],raw_base64=b64(raw),
                segments_base64=[b64(s) for s in segments],references=refs))
    latest={};sink=[];markers=[];transient_changes=[]
    for r in trace:
        if r.get('event')=='source-point-read' and r['result']==1 and r['user_info'] is not None:
            initial=compilations[r['compile_id']]
            before=initial.tables[0].record_at(r['requested_offset']).payload
            if before[1:13].hex()!=r['data'] or before[17:21].hex()!=r['user_info'][8:]:
                transient_changes.append(dict(caller=r['caller'],native_offset=r['requested_offset'],
                    input_record_base64=b64(initial.tables[0].record_at(r['requested_offset']).raw),
                    actual_data=r['data'],actual_user_info=r['user_info']))
        if r.get('event')=='source-point-read' and r['result']==1 and r['user_info'] is not None and r['caller']['rva']=='0x701ec':
            if len(bytes.fromhex(r['data']))!=12 or len(bytes.fromhex(r['user_info']))!=8:raise ValueError('native position width')
            network,line,pou=struct.unpack('<iii',bytes.fromhex(r['data']))
            location=dict(network=network,line=line,parent_pou_offset=pou,
                expansion_offset=struct.unpack('<i',bytes.fromhex(r['user_info'])[4:])[0])
            identity=source_identity(compilations[r['compile_id']],location)
            text=source_text.get(identity['definition']+'.Program.pou')
            if text is None or not 0<=line<len(text):raise ValueError('native point outside original ST source')
            identity['physical_text']=text[line]
            key=(r['compile_id'],identity['definition'],identity['instance'],line)
            matches=by_point.get(key,[])
            if len(matches)!=1:raise ValueError('native marker has no unique incoming ST point')
            marker=dict(sequence=r['sequence'],compile_id=r['compile_id'],native_offset=r['requested_offset'],
                native_data=r['data'],native_user_info=r['user_info'],incoming_ref=matches[0]['spelling'],source=identity)
            latest[r['compile_id']]=marker;markers.append(marker)
        if r.get('event')=='sink-record':
            sink.append(dict(sequence=r['sequence'],compile_id=r['compile_id'],name=r['name']['latin1'],
                opcode=r['opcode'],field8=r['source'],count=r['count'],operands=r['operands'],
                marker=latest.get(r['compile_id'])))
    raw=(native/'pcode-0-0.bin').read_bytes();decoded=decode(raw)
    if len(decoded)!=len(sink):raise ValueError('sink/generated instruction count differs')
    joined=[];step=0;operand_matches=0
    for observed,compiled in zip(sink,decoded,strict=True):
        name='P' if compiled['kind']=='label' else compiled['op']
        count=1 if compiled['kind']=='label' else len(compiled['args'])
        if observed['name']!=name or observed['count']!=count:raise ValueError('sink/generated name or arity differs')
        args=[compiled['text']] if compiled['kind']=='label' else compiled['args']
        views=[operand_view(o) for o in observed['operands']]
        if not all(operand_equal(v,a) for v,a in zip(views,args,strict=True)):
            raise ValueError('native sink operand differs from generated argument: '+str((views,args)))
        observed['operand_views']=views;operand_matches+=len(views)
        joined.append(dict(step=step,compiled=compiled,sink=observed))
        token=bytes.fromhex(compiled['raw']);step+=1 if token[0]<=3 else token[2]
    diagnostics=[]
    for r in trace:
        if r.get('event')!='backend-check-progress':continue
        for d in r['reports']:
            if d['kind'] not in (2,3):continue
            targets=[row for row in joined if row['step']==d['step']]
            diagnostics.append(dict(diagnostic=d,matching_instructions=targets))
    source_counts=collections.Counter((row['sink']['marker']['source']['definition'] if row['sink']['marker'] else '@generated') for row in joined)
    return dict(scope='Original UTF-16 ST plus fresh compiler input, native DBG_INFO reads, instruction sink and current PCode; no PLC execution',
        validation=dict(table_snapshots=len(compilations),normalized_sources=len(sources),source_reconstruction=all(roundtrips),
            reference_occurrences=sum(len(s['references']) for s in sources),source_markers=len(markers),
            native_sink_instructions=len(sink),generated_instructions=len(decoded),sink_names_and_arities_exact=True,
            native_operand_matches=operand_matches,instructions_by_definition=dict(source_counts),
            transient_offset_reinterpretations=len(transient_changes)),
        normalized_sources=sources,markers=markers,joined_instructions=joined,
        transient_position_changes=transient_changes,backend_diagnostics=diagnostics,
        limitations=['A captured lookup gives a physical point, not a whole multiline statement range.',
            'Operand interpretation is restricted to the measured scalar, ASCII string and D/Z16 index forms.',
            'Generated FEND/NOP/END have no original source point.',
            'The trace is compiler-version-specific. It does not establish source freshness for other stored caches.',
            'Backend refusals remain refusals; full instruction emission is not a successful project check.'])


def _is_st(raw):
    try:return parse_st_pou(raw).text is not None
    except ValueError:return False


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('native',type=Path);a=p.parse_args()
    result=inspect(a.native.resolve());output=a.native.parent/'source-reference-correspondence.json'
    output.write_text(json.dumps(result,indent=2,ensure_ascii=True)+'\n',encoding='utf-8')
    print(json.dumps(result['validation'],ensure_ascii=True))


if __name__=='__main__':main()
