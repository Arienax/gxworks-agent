"""New constants/trees; exact predictions are saved before native observations."""
import sys
import probe_full_st_reconstruction as batch


def boundary_source():
    parts=[]
    for ordinal,constant in enumerate((2,119,30001,33000,65001)):
        for operator in ('<','<=','>','>='):
            parts.append(f'IF currentUserId {operator} {constant} AND name1 <> "" THEN\nreadUserIdGlobal := {constant};\n')
            if ordinal%2:parts.append('ELSE\nreadUserIdGlobal := 0;\n')
            parts.append('END_IF;\n')
    return ''.join(parts)


if __name__=='__main__':
    sys.argv=[sys.argv[0],'st-full-source-20261001-v2']
    batch.CASES=[
        ('new-boundaries',False,boundary_source()),
        ('mixed-full-source',False,
         '''IF (I_userId > 33111 OR I_liveBit = FALSE) AND name1 <> "R,S;" THEN
line2 := CONCAT(I_name1,"~;");
ELSE
line2 := "";
END_IF;
IF currentUserId <= 11 THEN
readUserIdGlobal := 33001;
ELSE
readUserIdGlobal := 3;
END_IF;
IF currentUserId >= 65500 THEN
writeUserIdGlobal := 65002;
END_IF;
IF I_in1 AND I_liveBit = TRUE THEN
line4 := "t";
END_IF;
useLcd := I_liveBit = TRUE OR I_newIdFlag <> FALSE;
OUT_T(I_in1 AND I_in2,TC5,11);
OUT(TS5,resetOutput);
Keypad_1(number := line1,in_out_character := character);
'''),
        ('empty-compound-branches',False,
         '''IF I_in1 AND (I_liveBit = TRUE OR I_newIdFlag <> FALSE) THEN;
END_IF;
IF currentUserId > 40000 OR I_userId <= 13 THEN;
ELSE
line2 := "empty";
END_IF;
IF NOT (I_in1 AND I_in2) THEN
line3 := "p";
ELSE;
END_IF;
IF I_liveBit <> 0 THEN;
ELSE;
END_IF;
OUT_T(FALSE,TC15,2);
OUT(TS15,backLight);
'''),
    ]
    batch.main()
