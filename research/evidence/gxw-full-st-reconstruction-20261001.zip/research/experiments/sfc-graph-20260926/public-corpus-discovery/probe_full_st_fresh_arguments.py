"""Fresh scalar argument allocation and independent final whole-source holdout."""
import sys
import probe_full_st_reconstruction as batch


def timer_source():
    conditions=['I_liveBit = TRUE','NOT I_in2','I_in2 OR I_in1',
        'I_userId >= 28003','I_in2 AND I_in1','NOT (I_liveBit OR I_in2)']
    return ''.join(f'OUT_T({condition},TC{20+index},{31+index});\n' for index,condition in enumerate(conditions))+'OUT(TS20,useLcd);\n'


if __name__=='__main__':
    sys.argv=[sys.argv[0],'st-full-source-20261001-v4']
    batch.CASES=[('fresh-timer-arguments',False,timer_source()),
        ('out-enable-arguments',False,
         '''OUT(I_in1 AND I_in2,useLcd);
OUT(I_liveBit OR I_in2,backLight);
OUT(NOT I_in1,clearLcd);
OUT(I_liveBit = FALSE,showTime);
OUT(I_userId > 54832,Q_out1Ctrl);
OUT(NOT (I_in1 AND I_in2),Q_soundSetAccept);
'''),
        ('whole-program-new',True,
         '''useLcd := 1;
backLight := NOT I_in2;
IF (I_userId <= 43521 OR I_liveBit <> TRUE) AND name2 <> "" THEN
line2 := CONCAT(I_name1,"!");
ELSE
line2 := "all";
END_IF;
OUT_T(I_in1 AND I_in2,TC11,37);
OUT_T(I_liveBit OR I_in1,TC12,38);
OUT_T(NOT I_in2,TC13,39);
OUT(TS11,resetOutput);
Keypad_2(number := line4,in_out_character := I_userId);
Keypad_1(number := line1,in_out_character := character);
''')]
    batch.main()
