"""Freeze source-only predictions before compiling copied Q03UDV projects.

Direct complete-buffer equality and fresh native acceptance are separate
observations. Failed predictions and native refusals remain in their case
directories. No controller/simulator execution, cached compiler input or hash
comparison is used as a prediction oracle.
"""
from dataclasses import replace
from pathlib import Path
import json
import sys

ROOT=Path(__file__).resolve().parents[4]
P=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research'),str(P)]
from gxw.declarations import parse_declarations,serialize_declarations
from gxw.project_metadata import mark_observed_source_compile_pending
from probe_gxw_sfc_graph import patch_raw
from probe_gxw_st_sources import replace_observed_st
from probe_gxw_program_check_resources import SCRIPT
from probe_minimal_conditional_port_writes import streams,observe
from source_q_st_calls import predict
from witness_st_conditional_transfers import decode

OPTIONS=dict(definitions=('Keypad',),allow_global_names=True,
    allow_project_scalar_conditions=True,allow_q_timer_instructions=True,
    allow_concat=True,allow_dynamic_stores=True,allow_string_intrinsics=True,
    allow_enabled_instructions=True,allow_recursive_booleans=True,
    allow_general_conditions=True,allow_branch_trees=True,max_if_depth=2)

CASES=[
    ('word-string-compound',False,
     '''IF I_userId >= 32768 AND I_name1 <> "A,B;C" THEN
line2 := CONCAT(I_name2, ",");
ELSE
line2 := "";
END_IF;
IF currentUserId < 65535 THEN
readUserIdGlobal := 32768;
ELSE
readUserIdGlobal := currentUserId;
END_IF;
IF name1 = "" OR name2 <> "x" THEN
uid := I_uid;
END_IF;
Keypad_1(number := line1, in_out_character := character);
'''),
    ('boolean-blocks',False,
     '''IF I_liveBit <> FALSE AND (I_newIdFlag = TRUE OR Q_resetNewFlag <> 1) THEN
line2 := "q";
ELSE
line2 := "r";
END_IF;
IF NOT I_in1 THEN
line3 := "z";
END_IF;
useLcd := I_liveBit = FALSE;
OUT_T(I_in2,TC7,32767);
OUT(TS7,resetOutput);
Keypad_1(number := line1, in_out_character := character);
'''),
    ('empty-branches',False,
     '''IF I_liveBit = TRUE THEN; END_IF;
IF I_newIdFlag <> 0 THEN; ELSE line4 := "Empty"; END_IF;
IF currentUserId >= 65535 THEN; ELSE; END_IF;
IF name1 = "x;y,z" THEN line3 := "[]()"; ELSE; END_IF;
IF I_userId <= 32768 THEN; END_IF;
OUT_T(TRUE,TC0,0);
OUT(TS0,useLcd);
'''),
    ('reversed-two-instances',True,
     '''backLight := FALSE;
IF I_liveBit = 0 THEN
line2 := CONCAT(I_name1,"Z");
ELSE
line2 := "n";
END_IF;
IF I_userId <> 65535 THEN
readUserIdGlobal := currentUserId;
ELSE
readUserIdGlobal := 32768;
END_IF;
OUT_T(I_in1,TC2,255);
OUT(TS2,resetOutput);
Keypad_2(number := line4,in_out_character := I_userId);
Keypad_1(number := line1,in_out_character := character);
'''),
]


def save(path,value):
    path.write_text(json.dumps(value,indent=2,ensure_ascii=True)+'\n',encoding='utf-8')


def prediction(source,directory):
    try:
        result=predict(source,**OPTIONS)
    except (ValueError,KeyError,TypeError) as error:
        return dict(handling='unsupported',error_type=type(error).__name__,reason=str(error))
    raw=result['output'];(directory/'predicted-pcode-0-0.bin').write_bytes(raw)
    return dict(handling='predicted',bytes=len(raw),instruction_count=len(decode(raw)),
        declarations=result['declarations'],temporary_events=result['temporary_events'],
        transfers=result['transfers'],slots=result['slots'])


def compare(predicted,native):
    expected=(predicted/'predicted-pcode-0-0.bin').read_bytes()
    actual=(native/'pcode-0-0.bin').read_bytes()
    left,right=decode(expected),decode(actual)
    first=next((dict(index=i,predicted=a,native=b) for i,(a,b) in enumerate(zip(left,right)) if a!=b),None)
    if first is None and len(left)!=len(right):first=dict(index=min(len(left),len(right)),reason='record-count difference')
    return dict(byte_identical=expected==actual,predicted_bytes=len(expected),native_bytes=len(actual),
        predicted_instructions=len(left),native_instructions=len(right),first_difference=first)


def main():
    out=P/(sys.argv[1] if len(sys.argv)>1 else 'st-full-source-20261001-v1')
    out.mkdir(exist_ok=False)
    (out/'model-before-native.py').write_bytes((P/'source_q_st_calls.py').read_bytes())
    save(out/'options-before-native.json',OPTIONS)
    original=(P/'q-original-st-source-20261001/input.gxw').read_bytes()
    before=streams(original);labels='POU_01.Labels.lh'
    doc=parse_declarations(before[labels],logical_name=labels)
    existing=next(r for r in doc.rows if r.name=='Keypad_1')
    trace=out/'trace.js'
    trace.write_text('(function(){\n'+(P/'native-allocation-bitmap-v2/observer.js').read_text(encoding='utf-8')+
        '\n'+(P/'trace_native_source_points.js').read_text(encoding='utf-8')+'\n})();\n(function(){\n'+SCRIPT+'\n})();\n',encoding='utf-8')
    ready=[]
    for name,second,text in CASES:
        directory=out/name;directory.mkdir()
        changes={}
        if second:
            row=replace(existing,name='Keypad_2',record_id=max(r.record_id for r in doc.rows)+1)
            changes[labels]=mark_observed_source_compile_pending(serialize_declarations(replace(doc,rows=doc.rows+(row,))),logical_name=labels)
        text=text.replace('\n','\r\n')
        body,_=replace_observed_st(before['POU_01.Program.pou'],text)
        changes['POU_01.Program.pou']=mark_observed_source_compile_pending(body,logical_name='POU_01.Program.pou')
        source=original
        for stream,raw in changes.items():source,_=patch_raw(source,stream,before[stream],raw)
        if streams(source)!=dict(before,**changes):raise ValueError('unrelated logical payload changed')
        (directory/'input.gxw').write_bytes(source)
        before_prediction=prediction(source,directory)
        save(directory/'before-native.json',dict(scope='copied Q03UDV source project; no device or simulator execution',
            source=text,changed_streams=list(changes),unrelated_payloads_byte_exact=True,
            original_keypad_source_byte_exact=True,prediction=before_prediction,
            observations_to_measure=['Entire PCode byte equality, including labels, addressing, captures and instruction widths.',
                'Fresh native frontend/backend acceptance separately from equality.',
                'Accepted saved project reopens and reproduces every channel.']))
        ready.append((name,directory,before_prediction))
        print(json.dumps(dict(case=name,before_native=before_prediction['handling'],bytes=before_prediction.get('bytes'),reason=before_prediction.get('reason')),ensure_ascii=True),flush=True)
    results=[]
    for name,directory,predicted in ready:
        native,result,process=observe(directory/'input.gxw',directory,trace)
        row=dict(case=name,native=str(native),prediction_handling=predicted['handling'],
            check=result['check'],backend_rejected=result['backend_check_rejected'],diagnostics=result['diagnostics'],process=process)
        if predicted['handling']=='predicted' and (native/'pcode-0-0.bin').exists():row['comparison']=compare(directory,native)
        if result['check'] is not None and not result['check']['rejected']:
            saved=native/'native-saved.gxw';reopen=directory/'reopen';reopen.mkdir()
            again,checked,traced=observe(saved,reopen,trace)
            channels=[]
            for generated in result['generated']:
                for channel in range(3):
                    filename=f'pcode-{generated["index"]}-{channel}.bin'
                    channels.append(dict(file=filename,bytes=(native/filename).stat().st_size,
                        byte_identical=(native/filename).read_bytes()==(again/filename).read_bytes()))
            row['reopen']=dict(native=str(again),check=checked['check'],backend_rejected=checked['backend_check_rejected'],channels=channels,process=traced)
        results.append(row);save(out/'comparison.json',results)
        print(json.dumps(dict(case=name,check=row['check'],backend_rejected=row['backend_rejected'],
            diagnostic_counts={str(kind):sum(d['kind']==kind for d in row['diagnostics']) for kind in {d['kind'] for d in row['diagnostics']}},
            comparison=row.get('comparison'),reopen=row.get('reopen')),ensure_ascii=True),flush=True)


if __name__=='__main__':main()
