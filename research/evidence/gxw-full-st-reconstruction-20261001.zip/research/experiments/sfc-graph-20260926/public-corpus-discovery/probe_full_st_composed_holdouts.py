"""Prospective expression captures, association and complete two-FB holdouts."""
import sys
import probe_full_st_reconstruction as batch


def timer_source():
    conditions=['I_in1 AND I_in2','I_liveBit OR I_in2','NOT I_in1',
        'I_liveBit = FALSE','I_userId > 54832','NOT (I_in1 AND I_in2)']
    return ''.join(f'OUT_T({condition},TC{3+index},{19+index});\n' for index,condition in enumerate(conditions))+'OUT(TS3,useLcd);\n'


def associated_source():
    conditions=[
        'I_in1 AND I_liveBit = FALSE', 'I_liveBit <> TRUE AND I_in2',
        'I_in1 OR I_liveBit = TRUE', 'I_liveBit <> FALSE OR I_in2',
        'I_in1 AND (I_in2 AND I_liveBit = TRUE)',
        'I_in1 OR (I_in2 OR I_liveBit <> FALSE)',
        '(I_in1 AND I_in2) AND (I_liveBit = FALSE AND I_newIdFlag <> TRUE)',
        '(I_in1 OR I_in2) OR (I_liveBit = TRUE OR I_newIdFlag <> FALSE)',
        'NOT (I_in1 OR (I_liveBit = TRUE AND I_newIdFlag <> FALSE))',
        'NOT (I_in1 AND (I_liveBit = FALSE OR I_newIdFlag <> TRUE))',
        '(currentUserId > 54001 OR I_userId <= 19) OR I_liveBit = FALSE',
        '(currentUserId <= 54002 AND I_userId > 23) AND I_liveBit <> TRUE',
    ]
    return ''.join(f'IF {condition} THEN\nline2 := "a{index}";\nEND_IF;\n' for index,condition in enumerate(conditions))


if __name__=='__main__':
    sys.argv=[sys.argv[0],'st-full-source-20261001-v3']
    batch.CASES=[('timer-capture-lifetimes',False,timer_source()),
        ('associated-logical-blocks',False,associated_source()),
        ('complete-two-instances',True,
         '''useLcd := TRUE;
backLight := NOT I_in1;
IF (I_userId > 64555 AND name1 <> "") OR I_in1 = FALSE THEN
line2 := CONCAT(I_name2,"V");
ELSE
line2 := "done";
END_IF;
OUT_T(I_in2 OR I_liveBit,TC9,16);
OUT(TS9,resetOutput);
Keypad_2(number := line4,in_out_character := I_userId);
Keypad_1(number := line1,in_out_character := character);
''')]
    batch.main()
