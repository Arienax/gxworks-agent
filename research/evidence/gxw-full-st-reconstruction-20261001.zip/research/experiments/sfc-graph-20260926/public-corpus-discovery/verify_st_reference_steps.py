"""Independent native prefix counts and saved-debug identity comparisons."""
from pathlib import Path
import argparse
import base64
import json
import os
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[4];P=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research'),str(P)]
from gxw.compiler_debug import parse_compiler_debug,compiler_st_source_points
from gxw.compiler_tables import parse_compiler_tables
from gxw.lossless import inspect_project
from inspect_native_st_references import inspect,read_events,point,source_identity
from native_gxw_tokens import native_il_records


def save(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=True)+'\n',encoding='utf-8')


def verify(native):
    analysis=inspect(native);raw=(native/'pcode-0-0.bin').read_bytes()
    out=native.parent/'independent-step-reader'
    requests=[dict(id=i,mode='steps',byte_offset=row['compiled']['offset'],expected_steps=row['step'],
        input_base64=base64.b64encode(raw[:row['compiled']['offset']]).decode())
        for i,row in enumerate(analysis['joined_instructions'])]
    requests.append(dict(id=len(requests),mode='decode',input_base64=base64.b64encode(raw+b'\0').decode()))
    if not out.exists():
        out.mkdir()
        save(out/'before-native.json',requests)
        (out/'requests.tsv').write_text('\n'.join(str(r['id'])+'\t'+r['mode']+'\t'+r['input_base64'] for r in requests)+'\n',encoding='ascii')
        source=out/'QSourceStepOracle.cs';source.write_bytes((P/source.name).read_bytes());exe=out/'QSourceStepOracle.exe'
        build=subprocess.run([str(Path(os.environ['WINDIR'])/'Microsoft.NET/Framework/v4.0.30319/csc.exe'),'/nologo','/platform:x86','/out:'+str(exe),str(source)],capture_output=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
        (out/'build.txt').write_bytes(build.stdout+build.stderr)
        if build.returncode!=0:raise RuntimeError('helper build failed')
        process=subprocess.run([str(exe),'D:/GXWORKS2/Easysocket/CodeGenerator/ECCodeGenerator2.dll',str(out/'requests.tsv'),str(out/'outputs.jsonl')],capture_output=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
        (out/'stdout.bin').write_bytes(process.stdout);(out/'stderr.bin').write_bytes(process.stderr);save(out/'process.json',dict(returncode=process.returncode))
        if process.returncode!=0:raise RuntimeError('native step reader failed')
    elif json.loads((out/'before-native.json').read_text(encoding='utf-8'))!=requests:
        raise ValueError('existing native request evidence differs')
    answers=[json.loads(l) for l in (out/'outputs.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    if len(answers)!=len(requests) or any(a['id']!=r['id'] or a['code']!=0 for r,a in zip(requests,answers,strict=True)):
        raise ValueError('native responses incomplete')
    comparisons=[dict(id=req['id'],byte_offset=req['byte_offset'],expected=req['expected_steps'],native=ans['native_steps'],
        equal=req['expected_steps']==ans['native_steps']) for req,ans in zip(requests[:-1],answers[:-1],strict=True)]
    if not all(c['equal'] for c in comparisons):raise ValueError('prefix steps differ')
    il=base64.b64decode(answers[-1]['output_base64']);(out/'native-il.bin').write_bytes(il)
    listing=native_il_records(il,encoding='cp936')
    projection=[{k:row['compiled'][k] for k in ('kind','op','args','text') if k in row['compiled']} for row in analysis['joined_instructions']]
    if projection!=listing:raise ValueError('native whole-code listing differs')
    save(out/'comparison.json',comparisons);save(out/'native-listing.json',listing)
    snapshots=[parse_compiler_tables(bytes.fromhex(e['symbolic_data'])) for e in read_events(native) if e.get('event')=='sink-compile']
    tables=next(t for t in snapshots if t.tables[0].records and t.tables[0].records[0].payload[13:17]!=b'\xff\xff\xff\0')
    starts={row['step']:row for row in analysis['joined_instructions']};locations=[]
    for record in tables.tables[0].records:
        position=point(record);user=bytes.fromhex(position['user_info_hex']);step=int.from_bytes(user[:3],'little')
        if user[3]!=0 or step==0xffffff or step not in starts:raise ValueError('unmeasured compiled source position')
        locations.append(dict(source=source_identity(tables,position),compiled_step=step,
            native_prefix_steps=answers[analysis['joined_instructions'].index(starts[step])]['native_steps']))
    saved=native/'native-saved.gxw';saved_rows=[];debug_bytes=None
    if saved.exists():
        debug_bytes=next(s.raw for s in inspect_project(saved.read_bytes()).streams if s.logical_name=='DebugInformation2.dat')
        debug=parse_compiler_debug(debug_bytes)
        if debug.reconstruct()!=debug_bytes:raise ValueError('saved debug reconstruction')
        actual=compiler_st_source_points(debug)
        for loc in locations:
            source=loc['source'];instance=None if source['instance'] is None else source['instance'].rsplit('.',1)[1]
            matches=[p for p in actual if (p.definition_name_bytes.decode('cp936'),p.context_names[4].decode('cp936') or None,p.source_line,p.compiled_step_start)==
                (source['definition'],instance,source['line'],loc['compiled_step'])]
            if len(matches)!=1:raise ValueError('saved debug source identity differs')
            p=matches[0];saved_rows.append(dict(element_index=debug.elements.index(p.element),row_index=p.row_index,
                source_line=source['line'],compiled_step_start=loc['compiled_step'],compiled_step_end=p.compiled_step_end,
                context_names=[n.decode('cp936') for n in p.context_names],resource=p.element.resource_bytes.decode('cp936'),
                native_prefix_steps=loc['native_prefix_steps']))
        if len(saved_rows)!=len(actual):raise ValueError('saved debug has additional unmeasured ST points')
    summary=dict(prefix_step_queries=len(comparisons),prefix_step_matches=len(comparisons),
        whole_code_native_listing_exact=True,whole_code_instructions=len(listing),
        post_compile_source_points=len(locations),saved_source_point_matches=len(saved_rows),
        debug_reconstruction_exact=None if debug_bytes is None else True)
    save(native.parent/'source-step-correspondence.json',dict(summary=summary,locations=locations,saved_rows=saved_rows,
        debug_base64=None if debug_bytes is None else base64.b64encode(debug_bytes).decode(),
        limitations=['Start coordinates are checked; stored endpoints do not establish statement ownership.',
            'Other cached artifacts do not gain a source-freshness claim from this compile.']))
    return summary


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('native',type=Path);a=p.parse_args()
    print(json.dumps(verify(a.native.resolve()),ensure_ascii=True))


if __name__=='__main__':main()
