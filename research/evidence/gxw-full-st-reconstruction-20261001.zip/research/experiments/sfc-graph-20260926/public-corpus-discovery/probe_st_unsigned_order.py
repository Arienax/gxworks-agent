"""One batch separates unsigned relation, branch inversion and BOOL order rules."""
import sys
import probe_full_st_reconstruction as batch


def word_source(otherwise):
    parts=[]
    for constant in (0,1,32767,32768,65534,65535):
        for operator in ('<','<=','>','>='):
            parts.append(f'IF currentUserId {operator} {constant} THEN\nreadUserIdGlobal := 1;\n')
            if otherwise:parts.append('ELSE\nreadUserIdGlobal := 2;\n')
            parts.append('END_IF;\n')
    return ''.join(parts)


def bool_source():
    a='I_liveBit = TRUE';b='I_newIdFlag <> FALSE';c='Q_resetNewFlag = TRUE'
    conditions=[
        f'{a} AND ({b} OR {c})',f'({a} OR {b}) AND {c}',
        f'{a} OR ({b} AND {c})',f'({a} AND {b}) OR {c}',
        f'I_in1 AND ({a} OR {b})',f'({a} OR {b}) AND I_in1',
        f'I_in1 OR ({a} AND {b})',f'({a} AND {b}) OR I_in1',
        f'{a} AND {b}',f'{a} OR {b}',
        'NOT I_in1','NOT (I_in1 OR I_in2)',
    ]
    return ''.join(f'IF {condition} THEN\nline2 := "{index}";\nEND_IF;\n' for index,condition in enumerate(conditions))


if __name__=='__main__':
    sys.argv=[sys.argv[0],'st-unsigned-order-20261001-v1']
    batch.CASES=[('word-with-else',False,word_source(True)),
        ('word-without-else',False,word_source(False)),('boolean-evaluation-order',False,bool_source())]
    batch.main()
