"""Classify saved native check observations without running GX Works2.

Compilation, actual resource reads, backend completion, public diagnostics and
save/reopen are independent facts. Publication alone is not read evidence.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path


def _id(value):
    return tuple(value) if isinstance(value, list) and len(value) == 12 else None


def analyze_check(events, observations, generated, *, selection=None, reopened=None):
    """generated maps native resource IDs to three exact GetPCode buffers."""
    trace = [row.get('payload', row) for row in observations if row.get('type') != 'error']
    observation_errors = [row for row in observations if row.get('type') == 'error']
    observation_errors += [row for row in trace if row.get('event') == 'observation-error']
    planned, collection = [], None
    collecting = False
    for row in events:
        if row.get('operation') == 'Workspace.GetProgramCheckCollection':
            collecting = True
        elif collecting and row.get('operation') == 'InventoryCount':
            collection = _id(row.get('id'))
        elif collecting and row.get('operation') == 'NativeObject' and _id(row.get('parent')) == collection:
            planned.append(_id(row['id']))
        elif row.get('operation') == 'ProgramCheckTarget':
            collecting = False
    started = [_id(row['id']) for row in events if row.get('operation') == 'ProgramCheckTarget']
    planned = list(dict.fromkeys(planned or started))
    reads, queries = [], []
    for row in trace:
        if row.get('event') != 'workspace-pcode-read' or row.get('phase') != 'check':
            continue
        buffers = row.get('buffers', [])
        query = (row.get('hresult') == row.get('code') == 0 and row.get('requested_sizes') == [0, 0, 0]
                 and any(b.get('size') and b.get('raw_hex') is None for b in buffers))
        if query:
            queries.append(row['serial'])
            continue
        actual = []
        for buffer in buffers:
            raw = buffer.get('raw_hex')
            # A successful zero-length channel has no bytes even with NULL.
            if raw is None and buffer.get('size') == 0 and row.get('hresult') == row.get('code') == 0:
                raw = ''
            actual.append(bytes.fromhex(raw) if raw is not None else None)
        expected = generated.get(_id(row.get('target')))
        if (row.get('hresult') != 0 or row.get('code') != 0 or len(actual) != 3 or any(b is None for b in actual)
                or any(len(data) != buffer.get('size') for data, buffer in zip(actual, buffers) if data is not None)):
            status = 'unreadable'
        elif expected is None:
            status = 'unbound_resource'
        else:
            status = 'current' if tuple(actual) == tuple(expected) else 'stale'
        reads.append({'serial': row['serial'], 'check_target': row.get('check_target'),
                      'resource': row.get('target'), 'channel_sizes': [b.get('size') for b in buffers], 'status': status})
    completed_backend = list(dict.fromkeys(_id(row.get('target')) for row in trace
        if row.get('event') == 'backend-check-progress' and row.get('percent') == 100
        and row.get('hresult') == row.get('code') == 0))
    public_completion = [row for row in events if row.get('operation') == 'ProgramCheckCompleted']
    projection_failures = [row for row in trace if row.get('event') == 'diagnostic-projection-failure']
    failed_public_poll = any(row.get('operation') == 'ProgramCheckProgress.GetProgress'
        and (row.get('hresult', 0) < 0 or row.get('code', 0) != 0) for row in events)
    public_diagnostics = [report for row in events if row.get('operation', '').startswith('ProgramCheckProgress')
        for report in row.get('reports', []) if report.get('kind') in (2, 3)]
    backend_diagnostics = [report for row in trace if row.get('event') == 'backend-check-progress'
        for report in row.get('reports', []) if report.get('kind') in (2, 3)]
    whole_completed = (bool(planned) and len(set(started)) == len(planned) and bool(public_completion)
        and public_completion[-1].get('targets') == len(planned) and not projection_failures and not failed_public_poll)
    public_status = ('rejected' if public_completion[-1].get('rejected') or any(d['kind'] == 2 for d in public_diagnostics)
                     else 'passed') if whole_completed else 'incomplete'
    requested = any(row.get('operation') == 'Workspace.GetProgramCheckCollection' for row in events) or bool(started)
    if not requested:
        public_status = 'not_requested'
    if not reads:
        correspondence = 'not_observed'
    elif observation_errors or any(row['status'] not in ('current', 'stale') for row in reads):
        correspondence = 'not_established'
    elif any(row['status'] == 'stale' for row in reads):
        correspondence = 'stale'
    elif not planned or any(not any(_id(row['check_target']) == target for row in reads) for target in planned):
        correspondence = 'partial_targets'
    else:
        correspondence = 'current'
    compile_completed = any(row.get('operation') == 'Progress' and row.get('percent') == 100 for row in events)
    selected = selection or {'status': 'not_observed'}
    selection_current = (selected.get('status') == 'verified' and selected.get('source_bytes_current') is True
        and selected.get('configuration_bytes_current') is True and bool(selected.get('selected_sources'))
        and not selected.get('empty_task'))
    current_source_check = ('established' if selection_current and compile_completed
        and correspondence == 'current' and whole_completed else 'not_established')
    return {
        'selection': selected,
        'compilation': {'completed': compile_completed,
            'returned_resources': sum(row.get('operation') == 'Resource' for row in events), 'bound_resources': len(generated)},
        'publication': {'completed': any(row.get('operation') == 'Workspace.UpdatePCodeBeforeProgramCheck'
            and row.get('hresult') == row.get('code') == 0 for row in events)},
        'checker_resources': {'correspondence': correspondence, 'reads': reads, 'size_queries': queries,
                              'observation_errors': observation_errors},
        'targets': {'planned': [list(t) for t in planned], 'started': [list(t) for t in started],
                    'backend_completed': [list(t) for t in completed_backend]},
        'public_check': {'status': public_status, 'completed': whole_completed},
        'diagnostic_projection': {'status': 'failed' if projection_failures or failed_public_poll else
            'completed' if whole_completed else 'not_completed', 'failures': projection_failures,
            'public_diagnostics': public_diagnostics, 'backend_diagnostics': backend_diagnostics,
            'empty_public_list_means_no_errors': whole_completed and not public_diagnostics and not backend_diagnostics},
        'save': {'completed': any(row.get('operation') == 'SaveProject' and row.get('hresult') == row.get('code') == 0
            for row in events), 'exported': any(row.get('operation') == 'NativeExport' for row in events)},
        'reopen': reopened or {'status': 'not_observed'},
        'current_source_check': current_source_check,
    }


def analyze_directory(directory):
    directory = Path(directory)
    events = [json.loads(line) for line in (directory/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    observed = next((directory/name for name in ('observation-events.jsonl', 'events.jsonl') if (directory/name).exists()), None)
    observations = [json.loads(line) for line in observed.read_text(encoding='utf-8').splitlines()] if observed else []
    names = {_id(row['id']): row['name'] for row in events if row.get('operation') == 'NativeObject' and row.get('name')}
    resources = {row['name']: tuple((directory/f"pcode-{row['index']}-{i}.bin").read_bytes() for i in range(3))
                 for row in events if row.get('operation') == 'Resource'}
    generated = {identity: resources[name] for identity, name in names.items() if name in resources}
    return analyze_check(events, observations, generated)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', type=Path)
    args = parser.parse_args()
    print(json.dumps(analyze_directory(args.directory), ensure_ascii=False, indent=2))
