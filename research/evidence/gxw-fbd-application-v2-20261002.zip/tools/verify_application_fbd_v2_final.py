"""Recheck final Core bytes and retain bounded edits beside source gaps."""
from pathlib import Path
import base64
import json
import sys

P = Path(__file__).resolve().parent
ROOT = P.parents[3]
sys.path[:0] = [str(ROOT/'src'), str(P)]
import validate_application_fbd_v2 as matrix
from gxw.object_model import read_project_context, generate_object_project
from gxw.editor import edit_draft
from application.workbench import WorkbenchService

A = matrix.OUT


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    original = {(r['group'], r['cpu']):r for r in matrix.selected_cases()}
    rows = json.loads((A/'application-results.json').read_text())
    replay=[]
    for row in rows:
        if row['application_status']!='passed': continue
        raw=(Path(row['prior_native_case'])/'candidate.gxw').read_bytes()
        context=read_project_context(raw,'FBD_MATRIX.Program.pou')
        model=context.object_model()
        target=next(n for n in model['nodes'] if n['template']=='function_block:MODULE_FB')
        draft=edit_draft(model,{'action':'update_node','id':target['id'],'field':'symbol',
            'value':'APP_MODULE_STAGE_A'},templates=context.catalog(),context=context)['model']
        replay.append({'cpu':row['cpu'],'group':row['group'],
            'candidate_bytes_exact':generate_object_project(draft,baseline=raw).data==
            (Path(row['directory'])/'candidate.gxw').read_bytes()})
    save(A/'current-core-replay.json',replay)
    print(json.dumps({'current_core_cases':len(replay),'exact':sum(r['candidate_bytes_exact'] for r in replay)}),flush=True)
    out=A/'source-gap-controls'
    out.mkdir(exist_ok=False)
    wb=WorkbenchService(out/'workspace',out/'state',model_factory=lambda:(_ for _ in ()).throw(RuntimeError('provider must not run')))
    controls=[]
    wb.start()
    try:
        for row in rows:
            if row['application_status']!='exception':continue
            prior=original[row['group'],row['cpu']]
            raw=(Path(prior['directory'])/'candidate.gxw').read_bytes()
            context=read_project_context(raw,'FBD_MATRIX.Program.pou')
            case=out/row['cpu'].replace('/','-');case.mkdir()
            project=wb.create_project(name='Preserved callable gap '+row['cpu'],target_mode='fbd')
            imported=wb.fbd.propose({'operation':'import','project_id':project['id'],
                'request_id':'import-'+case.name,'program':'FBD_MATRIX.Program.pou',
                'data_base64':base64.b64encode(raw).decode()})
            base=imported['result']['version_id']
            model=wb.projects.program(project['id'],base)
            node=next(n for n in model['nodes'] if n['template']=='input' and n['symbol']=='X0')
            edited=wb.fbd.editor(project['id'],model,{'action':'update_node','id':node['id'],
                'field':'symbol','value':'X1'},base)['model']
            preview=wb.fbd.preview(project['id'],edited,base)
            candidate=wb.agent_call({'project_id':project['id'],'version_id':base,
                'name':'create_fbd_candidate','call_id':'edit-'+case.name,
                'arguments':{'operation':'edit','model':edited,'summary':'Known input edit beside preserved source gaps'}})
            if candidate['is_error']:raise RuntimeError(candidate['content'])
            saved=wb.decide(candidate['proposal_id'],'accept')['proposal']['result']['version_id']
            actual=wb.projects.artifact(project['id'],saved,'gxw').read_bytes()
            (case/'candidate.gxw').write_bytes(actual)
            current=read_project_context(actual,'FBD_MATRIX.Program.pou')
            result={'cpu':row['cpu'],'edit':'input X0 -> X1','prior_native_status':prior['status'],
                'original_harness_failure_retained':True,
                'missing_module_fb_in_input':not any(n['template']=='function_block:MODULE_FB' for n in model['nodes']),
                'schema_version':current.object_model()['schema_version'],
                'preview_and_reread_exact':current.object_model()==preview['model'],
                'saved_known_edit':any(n.symbol=='X1' for n in current.program.nodes),
                'unresolved_callable_records_exact':[n.raw for n in context.program.nodes if n.type_name]==
                    [n.raw for n in current.program.nodes if n.type_name],
                'source_gap_issues_exact':model['issues']==current.object_model()['issues'],
                'original_version_bytes_exact':wb.projects.artifact(project['id'],base,'gxw').read_bytes()==raw,
                'native_check':'not_rerun; retained original module rejection',
                'directory':str(case)}
            result['status']='bounded_edit_passed' if all(result[k] for k in (
                'missing_module_fb_in_input','preview_and_reread_exact','saved_known_edit',
                'unresolved_callable_records_exact','source_gap_issues_exact','original_version_bytes_exact')) else 'failed'
            save(case/'case-result.json',result)
            controls.append(result);save(out/'results.json',controls)
            print(json.dumps({'source_gap_cpu':row['cpu'],'status':result['status']}),flush=True)
    finally:wb.close()


if __name__=='__main__':main()
