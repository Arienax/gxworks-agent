"""Completed application module against the existing exact-CPU native corpus.

All projects, helper processes and outputs are owned offline copies. Native
phases and rejected controls remain separate; no digest verification is added.
"""
from pathlib import Path
from collections import Counter
import json
import shutil
import sys
import traceback

P = Path(__file__).resolve().parent
ROOT = P.parents[3]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'research'), str(P)]
import probe_cpu_fbd_matrix as native
from application.workbench import WorkbenchService
from application.fbd import decode_upload
from gxw.object_model import read_project_context, generate_object_project

OUT = P/'application-fbd-v2-20261002-v1'
M = native.OUT
CS = ('WorkspaceReplayOracle.cs', 'NativeFrontendSnapshot.cs',
      'NativeSfcGraphOracle.cs', 'NativeWorkspaceCopyOracle.cs')


def selected_cases():
    rows=[]
    for group, name in [('full','module-combined-v2-results.json'),
                        ('type-control','module-fx-type-boundaries-results.json')]:
        for row in json.loads((M/name).read_text()):
            rows.append({'group':group, **row})
    for cpu in ('FX1','FX0S-FX0','FX0N','LJ72GF15-T2','LJ72MS15'):
        path=M/('factory-'+cpu+'-project-only-boundary-v1')/'matrix-result.json'
        row=json.loads(path.read_text())
        if row['cpu']=='FX0N':
            retry=path.parent/'reopen-native-retry-v1/retry-comparison.json'
            row['retained_initial_status']=row['status']
            row['retry_comparison']=str(retry)
            row['status']=json.loads(retry.read_text())['status']
        rows.append({'group':'project-only', **row})
    return rows


def native_phase(source, directory, frozen):
    directory.mkdir()
    for name in ('home','compiler'): (directory/name).mkdir()
    for name in CS: shutil.copyfile(frozen/name, directory/name)
    shutil.copyfile(source, directory/'input.gxw')
    plan=json.loads((frozen/'plan.json').read_text())
    plan.update(workspace_home=str(directory/'home')+'\\',
                compiler_work=str(directory/'compiler'), input_copy=str(directory/'input.gxw'),
                project_name='APPFBD', project_alias='APPFBD')
    native.save(directory/'plan.json',plan)
    result=native.execute_owned(directory,'compile')
    events=[json.loads(l) for l in (directory/'native-events.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    diagnostics={json.dumps({k:v for k,v in d.items() if k!='raw_base64'},sort_keys=True)
                 for e in events for d in e.get('reports',[]) if d['kind'] in (2,3)}
    result.update(
        compile_completed=any(e.get('operation')=='Progress' and e.get('percent')==100 for e in events),
        diagnostics=[json.loads(d) for d in sorted(diagnostics)],
        publication=[e for e in events if e.get('operation')=='Workspace.UpdatePCodeBeforeProgramCheck'],
        check_targets=[e for e in events if e.get('operation')=='ProgramCheckTarget'],
        checks=[e for e in events if e.get('operation')=='ProgramCheckCompleted'],
        diagnostic_projection_completed=any(e.get('operation')=='ProgramCheckCompleted' for e in events),
        checker_resource_reads='not_instrumented_in_this_pass',
        plan_file=str(directory/'plan.json'))
    native.save(directory/'phase-result.json',result)
    return result


def accepted(phase):
    return (phase['returncode']==0 and phase['compile_completed'] and phase['exported']
            and phase['publication'] and phase['checks'] and phase['check_targets']
            and not any(d['kind']==2 for d in phase['diagnostics'])
            and all(not c['rejected'] for c in phase['checks']))


def records(raw):
    context=read_project_context(raw,'FBD_MATRIX.Program.pou')
    return ([r.raw for r in context.program.iter_records()],
            {n:[r.raw for r in doc.rows] for n,doc in context.declarations.items()})


def codes(directory):
    return {p.name:p.read_bytes() for p in directory.glob('pcode-*.bin')}


def application_case(wb, original):
    cpu=original['cpu']; slug=cpu.replace('/','-').replace('(','').replace(')','')
    case=OUT/(original['group']+'-'+slug)
    case.mkdir()
    result={'cpu':cpu,'group':original['group'],'prior_native_status':original['status'],
            'prior_native_case':original['directory'],'directory':str(case)}
    path=Path(original['directory'])/'candidate.gxw'
    if not path.exists():
        result['application_status']='no_native_project_input'
        result['factory_failure']=original.get('factory')
        native.save(case/'case-result.json',result)
        return result
    raw=path.read_bytes()
    import base64
    project=wb.create_project(name='FBD application '+cpu,target_mode='fbd')
    proposal=wb.fbd.propose({'operation':'import','project_id':project['id'],
        'request_id':'import-'+case.name,'program':'FBD_MATRIX.Program.pou',
        'data_base64':base64.b64encode(raw).decode()})
    base=proposal['result']['version_id']
    graph=wb.projects.program(project['id'],base)
    target=next(n for n in graph['nodes'] if n['template']=='function_block:MODULE_FB')
    edited=wb.fbd.editor(project['id'],graph,{'action':'update_node','id':target['id'],
        'field':'symbol','value':'APP_MODULE_STAGE_A'},base)['model']
    preview=wb.fbd.preview(project['id'],edited,base)
    candidate=wb.agent_call({'project_id':project['id'],'version_id':base,
        'name':'create_fbd_candidate','call_id':'edit-'+case.name,
        'arguments':{'operation':'edit','model':edited,'summary':'Owned FBD application module'}})
    if candidate['is_error']:raise RuntimeError(candidate['content'])
    saved=wb.decide(candidate['proposal_id'],'accept')['proposal']['result']['version_id']
    actual=wb.projects.artifact(project['id'],saved,'gxw').read_bytes()
    (case/'candidate.gxw').write_bytes(actual)
    for name in ('fbd','svg','write_report'):
        shutil.copyfile(wb.projects.artifact(project['id'],saved,name),case/wb.projects.artifact(project['id'],saved,name).name)
    reread=wb.projects.program(project['id'],saved)
    result.update(project_id=project['id'],base_version=base,saved_version=saved,
        source_cpu=reread['cpu'],schema_version=reread['schema_version'],
        preview_model_exact=reread==preview['model'],
        preview_svg_exact=wb.projects.svg_preview(project['id'],saved)==preview['svg'],
        previous_version_bytes_exact=wb.projects.artifact(project['id'],base,'gxw').read_bytes()==raw,
        core_candidate_bytes_exact=actual==generate_object_project(edited,baseline=raw).data,
        unknown_records_exact=[r.raw for r in read_project_context(actual,'FBD_MATRIX.Program.pou').program.unknown_records]==
            [r.raw for r in read_project_context(raw,'FBD_MATRIX.Program.pou').program.unknown_records],
        instance_decl_renamed=any(r['name']=='APP_MODULE_STAGE_A' for r in reread['labels']['FBD_MATRIX.Labels.lh']),
        source_binding_issues=reread['issues'],native_automatic_status=candidate['data']['data']['verification'])
    result['application_status']='passed' if all(result[k] for k in ('preview_model_exact','preview_svg_exact',
        'previous_version_bytes_exact','core_candidate_bytes_exact','unknown_records_exact','instance_decl_renamed')) and result['source_cpu']==cpu else 'application_roundtrip_failed'
    native.save(case/'case-result.json',result)
    return result


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    OUT.mkdir(exist_ok=False)
    shutil.copyfile(Path(__file__),OUT/Path(__file__).name)
    original=selected_cases(); results=[]
    wb=WorkbenchService(OUT/'workspace',OUT/'state',model_factory=lambda: (_ for _ in ()).throw(RuntimeError('provider must not run')))
    wb.start()
    try:
        for row in original:
            try: result=application_case(wb,row)
            except Exception as error:
                result={'cpu':row['cpu'],'group':row['group'],'prior_native_status':row['status'],
                    'application_status':'exception','error':str(error),'traceback':traceback.format_exc()}
            results.append(result);native.save(OUT/'application-results.json',results)
            print(json.dumps({'phase':'application','completed':len(results),'targets':len(original),
                'statuses':dict(Counter(r['application_status'] for r in results))}),flush=True)
    finally: wb.close()
    chosen={}
    for source,result in zip(original,results):
        if source['status']=='passed' and result['application_status']=='passed':
            chosen.setdefault(source['cpu'],(source,result))
    native_rows=[]
    for source,result in chosen.values():
        case=Path(result['directory']); frozen=Path(source['directory'])/'compile-native'
        row={'cpu':source['cpu'],'application_case':str(case),'prior_native_case':source['directory']}
        try:
            first=native_phase(case/'candidate.gxw',case/'native-compile',frozen);row['compile']=first
            if accepted(first):
                saved=case/'native-compile/native-saved.gxw'
                row['saved_graph_and_labels_exact']=records(saved.read_bytes())==records((case/'candidate.gxw').read_bytes())
                cold=native_phase(saved,case/'native-reopen',frozen);row['reopen']=cold
                row['cold_pcode_exact']=codes(case/'native-compile')==codes(case/'native-reopen')
                row['cold_graph_and_labels_exact']=cold['exported'] and records((case/'native-reopen/native-saved.gxw').read_bytes())==records(saved.read_bytes())
                row['status']='passed' if accepted(cold) and row['saved_graph_and_labels_exact'] and row['cold_pcode_exact'] and row['cold_graph_and_labels_exact'] else 'native_roundtrip_failed'
            else: row['status']='native_compile_or_check_failed'
        except Exception as error:row.update(status='exception',error=str(error),traceback=traceback.format_exc())
        native_rows.append(row);native.save(case/'native-result.json',row);native.save(OUT/'native-results.json',native_rows)
        print(json.dumps({'phase':'native','cpu':row['cpu'],'completed':len(native_rows),'targets':len(chosen),
            'statuses':dict(Counter(r['status'] for r in native_rows))}),flush=True)
    native.save(OUT/'summary.json',{'application_cases':len(results),
        'application_statuses':dict(Counter(r['application_status'] for r in results)),
        'native_distinct_cpu_options':len(native_rows),'native_statuses':dict(Counter(r['status'] for r in native_rows)),
        'scope':'Specific native CPU options and owned FBD modules; no PLC or simulator execution; checker reads are not traced in this pass'})


if __name__=='__main__':main()
