"""One-factor owned native POU-name control for diagnostic projection."""
from pathlib import Path
import json
import sys

P=Path(__file__).resolve().parent
sys.path.insert(0,str(P))
import probe_application_check_resources as probe


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    parent=P/'q-diagnostic-name-control-20261002-v1';parent.mkdir(exist_ok=False)
    frozen=P/'q-label-contact-native-20261001-v1/case-00/candidate-check-1'
    for attempt in range(1,17):
        directory=parent/('attempt-'+str(attempt))
        script=probe.prepare(directory,frozen)
        path=directory/'WorkspaceReplayOracle.cs';source=path.read_text(encoding='utf-8')
        anchor='            if(plan.ContainsKey("snapshot_frontend")&&Convert.ToBoolean(plan["snapshot_frontend"])) {'
        if source.count(anchor)!=1:raise ValueError('Owned source-control site differs')
        snippet='''            ObjectId sourceCollection;
            Check("ProjectionControl.GetPOUCollection",Slot<CollectionFn>(workspace,36)(workspace,id,25,out sourceCollection,out code),code);
            var sourceObjects=Inventory(workspace,sourceCollection);
            bool renamed=false;
            foreach(ObjectId sourceObject in sourceObjects) {
                IntPtr sourceName;
                Check("ProjectionControl.GetPOUName",Slot<IdNameFn>(workspace,64)(workspace,sourceObject,out sourceName,out code),code);
                string priorName=ReadBStr(sourceName);if(sourceName!=IntPtr.Zero)Marshal.FreeBSTR(sourceName);
                if(!renamed) {
                    Check("ProjectionControl.RenameOnePOU",Slot<CopyNameFn>(workspace,60)(workspace,sourceObject,BStr("MAIN"),out code),code);
                    Record(new {operation="ProjectionNameControl",prior=priorName,current="MAIN",id=sourceObject.words});
                    renamed=true;
                }
            }
            if(!renamed)throw new Exception("Projection name control has no POU");
'''
        path.write_text(source.replace(anchor,snippet+anchor),encoding='utf-8')
        returncode,messages=probe.run(directory,script)
        result=probe.summarize(directory,returncode,messages)
        reference=P/'application-current-check-20261002-v1/Q03UDV-diagnostic-negative-attempt-1'
        result['pcode_channels_exact_to_original']={file.name:file.read_bytes()==(reference/file.name).read_bytes()
            for file in directory.glob('pcode-*.bin') if (reference/file.name).is_file()}
        result['controlled_change']='One native POU name changed to MAIN before frontend selection; input file remains unchanged'
        probe.save(directory/'control-result.json',result)
        print(json.dumps({k:result[k] for k in ('returncode','compile_completed','diagnostic_projection','public_check','pcode_channels_exact_to_original')}),flush=True)
        if returncode!=5:break


if __name__=='__main__':main()
