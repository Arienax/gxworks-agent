"""The same duplicate-output module on three owned exact-CPU projects."""
from pathlib import Path
import json
import sys

P=Path(__file__).resolve().parent
ROOT=P.parents[3]
sys.path[:0]=[str(P),str(ROOT/'src'),str(ROOT/'research')]
import probe_application_check_resources as probe
from gxw.object_model import read_project_context,generate_object_project
from program_check_evidence import analyze_directory


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    out=P/'owned-diagnostic-controls-20261002-v1';out.mkdir(exist_ok=False)
    rows=[]
    for cpu in ('FX3U/FX3UC','Q03UDV','L02'):
        frozen=probe.A/('full-'+cpu.replace('/','-'))/'native-compile'
        raw=(frozen/'input.gxw').read_bytes()
        context=read_project_context(raw,'FBD_MATRIX.Program.pou')
        model=context.object_model();target=next(n for n in model['nodes'] if n['template']=='output' and n['symbol']=='Y10')
        target['symbol']='Y0'
        changed=generate_object_project(model,baseline=raw).data
        for attempt in range(1,17):
            directory=out/(cpu.replace('/','-')+'-attempt-'+str(attempt))
            script=probe.prepare(directory,frozen)
            (directory/'input.gxw').write_bytes(changed)
            result=probe.summarize(directory,*probe.run(directory,script))
            result['cpu']=cpu;result['controlled_change']='Existing output Y10 -> Y0; a second Y0 output remains'
            result['classification']=analyze_directory(directory)
            probe.save(directory/'control-result.json',result)
            rows.append(result);probe.save(out/'results.json',rows)
            print(json.dumps({'cpu':cpu,'returncode':result['returncode'],'public_check':result['classification']['public_check'],
                'projection':result['classification']['diagnostic_projection']['status']}),flush=True)
            if result['returncode']!=5:break


if __name__=='__main__':main()
